/*
 * Abora-Gold
 * Part of the Abora hypertext project: http://www.abora.org
 * Copyright 2003 David G Jones
 * 
 * Translated from Udanax-Gold source code: http://www.udanax.com
 * Copyright 1979-1999 Udanax.com. All rights reserved
 */
package org.abora.gold.counter;

import org.abora.gold.counter.Counter;
import org.abora.gold.java.missing.IntegerVar;
import org.abora.gold.java.missing.Sema4;
import org.abora.gold.xcvr.Rcvr;
import org.abora.gold.xcvr.Xmtr;
import org.abora.gold.xpp.basic.Heaper;


/**
 * Instances preallocate a bunch of numbers and record the preallocations to disk.  It then
 * increments purely in memory until the preallocated counts are used up.  It then
 * preallocates another bunch of numbers.  If the system crashes, all numbers between the
 * in-memory count and the on-disk count simply never get used.  This reduces the access to
 * disk for shepherd hashes and GrandMap IDs.
 */
public class BatchCounter extends Counter {
	protected IntegerVar myCount;
	protected IntegerVar myPersistentCount;
	protected Sema4 myMutex;
	protected IntegerVar myBatchCount;
/*
udanax-top.st:5660:
Counter subclass: #BatchCounter
	instanceVariableNames: '
		myCount {IntegerVar NOCOPY}
		myPersistentCount {IntegerVar}
		myMutex {Sema4 NOCOPY}
		myBatchCount {IntegerVar}'
	classVariableNames: ''
	poolDictionaries: ''
	category: 'Xanadu-counter'!
*/
/*
udanax-top.st:5668:
BatchCounter comment:
'Instances preallocate a bunch of numbers and record the preallocations to disk.  It then increments purely in memory until the preallocated counts are used up.  It then preallocates another bunch of numbers.  If the system crashes, all numbers between the in-memory count and the on-disk count simply never get used.  This reduces the access to disk for shepherd hashes and GrandMap IDs.'!
*/
/*
udanax-top.st:5670:
(BatchCounter getOrMakeCxxClassDescription)
	attributes: ((Set new) add: #LOCKED; add: #COPY; add: #CONCRETE; add: #NOT.A.TYPE; yourself)!
*/
/*
udanax-top.st:5769:
BatchCounter class
	instanceVariableNames: ''!
*/
/*
udanax-top.st:5772:
(BatchCounter getOrMakeCxxClassDescription)
	attributes: ((Set new) add: #LOCKED; add: #COPY; add: #CONCRETE; add: #NOT.A.TYPE; yourself)!
*/

public IntegerVar count() {
throw new UnsupportedOperationException();/*
udanax-top.st:5675:BatchCounter methodsFor: 'accessing'!
{IntegerVar} count
	^myCount!
*/
}

public IntegerVar decrement() {
throw new UnsupportedOperationException();/*
udanax-top.st:5678:BatchCounter methodsFor: 'accessing'!
{IntegerVar} decrement
	
	myMutex critical: 
		[DiskManager consistent: 1 with:
			[myCount _ myCount - 1.
			self diskUpdate]].
	^myCount!
*/
}

public IntegerVar decrementBy(IntegerVar count) {
throw new UnsupportedOperationException();/*
udanax-top.st:5686:BatchCounter methodsFor: 'accessing'!
{IntegerVar} decrementBy: count {IntegerVar}
	
	count >= IntegerVarZero ifFalse:
		[Heaper BLAST: #InvalidRequest].
	myMutex critical: 
		[DiskManager consistent: 1 with:
			[myCount _ myCount - count.
			self diskUpdate]].
	^myCount!
*/
}

public IntegerVar increment() {
throw new UnsupportedOperationException();/*
udanax-top.st:5696:BatchCounter methodsFor: 'accessing'!
{IntegerVar} increment
	myMutex critical:
	[myCount _ myCount + 1.
	myCount > myPersistentCount ifTrue:
		[DiskManager consistent: 1 with:
		[myPersistentCount _ myCount + myBatchCount.
		self diskUpdate]]].
	^myCount!
*/
}

public IntegerVar incrementBy(IntegerVar count) {
throw new UnsupportedOperationException();/*
udanax-top.st:5705:BatchCounter methodsFor: 'accessing'!
{IntegerVar} incrementBy: count {IntegerVar}
	count >= IntegerVarZero ifFalse:
		[Heaper BLAST: #InvalidRequest].
	myMutex critical:
	[myCount _ myCount + count.
	myCount > myPersistentCount ifTrue:
		[DiskManager consistent: 1 with:
		[myPersistentCount _ myCount + myBatchCount.
		self diskUpdate]]].
	^myCount!
*/
}

public void setCount(IntegerVar count) {
throw new UnsupportedOperationException();/*
udanax-top.st:5717:BatchCounter methodsFor: 'accessing'!
{void} setCount: count {IntegerVar} 
	
	myMutex critical: 
		[DiskManager consistent: 1 with:
			[myCount _ count.
			self diskUpdate]]!
*/
}

/**
 * re-initialize the non-persistent part
 */
public void restartBatchCounter(Rcvr trans) {
throw new UnsupportedOperationException();/*
udanax-top.st:5726:BatchCounter methodsFor: 'receiver: stubble'!
{void RECEIVE.HOOK} restartBatchCounter: trans {Rcvr unused default: NULL}
	"re-initialize the non-persistent part"
	myCount _ myPersistentCount.
	myMutex _ Sema4 make: 1.!
*/
}

public  BatchCounter(IntegerVar count, IntegerVar batchCount) {
throw new UnsupportedOperationException();/*
udanax-top.st:5733:BatchCounter methodsFor: 'protected: create'!
create: count {IntegerVar} with: batchCount {IntegerVar}
	super create.
	DiskManager consistent: 1 with:
		[myPersistentCount _ myCount _ count.
		myBatchCount _ batchCount.
		self restartBatchCounter: NULL.
		self newShepherd.
		self remember]!
*/
}

public  BatchCounter(IntegerVar count, IntegerVar batchCount, int hash) {
throw new UnsupportedOperationException();/*
udanax-top.st:5742:BatchCounter methodsFor: 'protected: create'!
create: count {IntegerVar} with: batchCount {IntegerVar} with: hash {UInt32}
	super create: hash.
	myPersistentCount _ myCount _ count.
	myBatchCount _ batchCount.
	self restartBatchCounter: NULL.!
*/
}

public int contentsHash() {
throw new UnsupportedOperationException();/*
udanax-top.st:5750:BatchCounter methodsFor: 'testing'!
{UInt32} contentsHash
	^super contentsHash
		bitXor: (IntegerPos integerHash: myPersistentCount)!
*/
}

public  BatchCounter(Rcvr receiver) {
throw new UnsupportedOperationException();/*
udanax-top.st:5757:BatchCounter methodsFor: 'generated:'!
create.Rcvr: receiver {Rcvr}
	super create.Rcvr: receiver.
	myPersistentCount _ receiver receiveIntegerVar.
	myBatchCount _ receiver receiveIntegerVar.
	self restartBatchCounter: receiver.!
*/
}

public void sendSelfTo(Xmtr xmtr) {
throw new UnsupportedOperationException();/*
udanax-top.st:5763:BatchCounter methodsFor: 'generated:'!
{void} sendSelfTo: xmtr {Xmtr}
	super sendSelfTo: xmtr.
	xmtr sendIntegerVar: myPersistentCount.
	xmtr sendIntegerVar: myBatchCount.!
*/
}

public static Heaper make(IntegerVar count, IntegerVar batchCount) {
throw new UnsupportedOperationException();/*
udanax-top.st:5777:BatchCounter class methodsFor: 'pseudo-constructors'!
{Counter} make: count {IntegerVar} with: batchCount {IntegerVar}
	^self create: count with: batchCount!
*/
}

public static Counter makeFakeCounter(IntegerVar count, IntegerVar batchCount, int hash) {
throw new UnsupportedOperationException();/*
udanax-top.st:5780:BatchCounter class methodsFor: 'pseudo-constructors'!
{Counter} makeFakeCounter: count {IntegerVar} with: batchCount {IntegerVar} with: hash {UInt32}
	^self create: count with: batchCount with: hash!
*/
}
}
