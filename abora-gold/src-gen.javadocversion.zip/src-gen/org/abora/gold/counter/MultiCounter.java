/*
 * Abora-Gold
 * Part of the Abora hypertext project: http://www.abora.org
 * Copyright 2003 David G Jones
 * 
 * Translated from Udanax-Gold source code: http://www.udanax.com
 * Copyright 1979-1999 Udanax.com. All rights reserved
 */
package org.abora.gold.counter;

import java.io.PrintWriter;
import org.abora.gold.counter.Counter;
import org.abora.gold.java.missing.IntegerVar;
import org.abora.gold.snarf.Abraham;
import org.abora.gold.xcvr.Rcvr;
import org.abora.gold.xcvr.Xmtr;
import org.abora.gold.xpp.basic.Heaper;


public class MultiCounter extends Abraham {
	protected Counter myFirst;
	protected Counter mySecond;
/*
udanax-top.st:7154:
Abraham subclass: #MultiCounter
	instanceVariableNames: '
		myFirst {Counter}
		mySecond {Counter}'
	classVariableNames: ''
	poolDictionaries: ''
	category: 'Xanadu-counter'!
*/
/*
udanax-top.st:7160:
(MultiCounter getOrMakeCxxClassDescription)
	attributes: ((Set new) add: #LOCKED; add: #COPY; add: #SHEPHERD.PATRIARCH; add: #CONCRETE; yourself)!
*/
/*
udanax-top.st:7244:
MultiCounter class
	instanceVariableNames: ''!
*/
/*
udanax-top.st:7247:
(MultiCounter getOrMakeCxxClassDescription)
	attributes: ((Set new) add: #LOCKED; add: #COPY; add: #SHEPHERD.PATRIARCH; add: #CONCRETE; yourself)!
*/

public void decrementBoth() {
throw new UnsupportedOperationException();/*
udanax-top.st:7165:MultiCounter methodsFor: 'accessing'!
{void} decrementBoth
	
	DiskManager consistent: 2 with:
		[myFirst decrement.
		mySecond decrement]!
*/
}

public IntegerVar decrementFirst() {
throw new UnsupportedOperationException();/*
udanax-top.st:7171:MultiCounter methodsFor: 'accessing'!
{IntegerVar} decrementFirst
	^myFirst decrement!
*/
}

public IntegerVar decrementSecond() {
throw new UnsupportedOperationException();/*
udanax-top.st:7174:MultiCounter methodsFor: 'accessing'!
{IntegerVar} decrementSecond
	^mySecond decrement!
*/
}

public IntegerVar firstCount() {
throw new UnsupportedOperationException();/*
udanax-top.st:7177:MultiCounter methodsFor: 'accessing'!
{IntegerVar} firstCount
	^myFirst count!
*/
}

public void incrementBoth() {
throw new UnsupportedOperationException();/*
udanax-top.st:7180:MultiCounter methodsFor: 'accessing'!
{void} incrementBoth
	
	DiskManager consistent: 2 with:
		[myFirst increment.
		mySecond increment]!
*/
}

public IntegerVar incrementFirst() {
throw new UnsupportedOperationException();/*
udanax-top.st:7186:MultiCounter methodsFor: 'accessing'!
{IntegerVar} incrementFirst
	^myFirst increment!
*/
}

public IntegerVar incrementSecond() {
throw new UnsupportedOperationException();/*
udanax-top.st:7189:MultiCounter methodsFor: 'accessing'!
{IntegerVar} incrementSecond
	^mySecond increment!
*/
}

public IntegerVar secondCount() {
throw new UnsupportedOperationException();/*
udanax-top.st:7192:MultiCounter methodsFor: 'accessing'!
{IntegerVar} secondCount
	^mySecond count!
*/
}

public  MultiCounter() {
throw new UnsupportedOperationException();/*
udanax-top.st:7197:MultiCounter methodsFor: 'creation'!
create
	super create.
	myFirst _ Counter make: IntegerVar0.
	mySecond _ Counter make: IntegerVar0.
	self newShepherd.
	self remember!
*/
}

public  MultiCounter(IntegerVar first) {
throw new UnsupportedOperationException();/*
udanax-top.st:7204:MultiCounter methodsFor: 'creation'!
create: first {IntegerVar}
	super create.
	myFirst _ Counter make: first.
	mySecond _ Counter make: IntegerVar0.
	self newShepherd.
	self remember!
*/
}

public  MultiCounter(IntegerVar first, IntegerVar second) {
throw new UnsupportedOperationException();/*
udanax-top.st:7211:MultiCounter methodsFor: 'creation'!
create: first {IntegerVar} with: second {IntegerVar}
	super create.
	myFirst _ Counter make: first.
	mySecond _ Counter make: second.
	self newShepherd.
	self remember!
*/
}

public void printOn(PrintWriter oo) {
throw new UnsupportedOperationException();/*
udanax-top.st:7220:MultiCounter methodsFor: 'printing'!
{void} printOn: oo {ostream reference}
	oo << self getCategory name << '(' << myFirst count << ', ' << mySecond count << ')'!
*/
}

public int contentsHash() {
throw new UnsupportedOperationException();/*
udanax-top.st:7225:MultiCounter methodsFor: 'testing'!
{UInt32} contentsHash
	^(super contentsHash
		bitXor: myFirst hashForEqual)
		bitXor: mySecond hashForEqual!
*/
}

public  MultiCounter(Rcvr receiver) {
throw new UnsupportedOperationException();/*
udanax-top.st:7233:MultiCounter methodsFor: 'generated:'!
create.Rcvr: receiver {Rcvr}
	super create.Rcvr: receiver.
	myFirst _ receiver receiveHeaper.
	mySecond _ receiver receiveHeaper.!
*/
}

public void sendSelfTo(Xmtr xmtr) {
throw new UnsupportedOperationException();/*
udanax-top.st:7238:MultiCounter methodsFor: 'generated:'!
{void} sendSelfTo: xmtr {Xmtr}
	super sendSelfTo: xmtr.
	xmtr sendHeaper: myFirst.
	xmtr sendHeaper: mySecond.!
*/
}

public static Heaper make() {
throw new UnsupportedOperationException();/*
udanax-top.st:7252:MultiCounter class methodsFor: 'pseudo constructors '!
make
	^self create.!
*/
}

public static Heaper make(IntegerVar count) {
throw new UnsupportedOperationException();/*
udanax-top.st:7255:MultiCounter class methodsFor: 'pseudo constructors '!
make: count {IntegerVar}
	^self create: count!
*/
}
}
