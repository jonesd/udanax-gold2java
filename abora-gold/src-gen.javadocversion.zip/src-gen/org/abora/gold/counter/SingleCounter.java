/*
 * Abora-Gold
 * Part of the Abora hypertext project: http://www.abora.org
 * Copyright 2003 David G Jones
 * 
 * Translated from Udanax-Gold source code: http://www.udanax.com
 * Copyright 1979-1999 Udanax.com. All rights reserved
 */
package org.abora.gold.counter;

import org.abora.gold.counter.Counter;
import org.abora.gold.java.missing.IntegerVar;
import org.abora.gold.java.missing.Sema4;
import org.abora.gold.xcvr.Rcvr;
import org.abora.gold.xcvr.Xmtr;
import org.abora.gold.xpp.basic.Heaper;


/**
 * This counter separates a very simple state change into another flock so that big objects
 * like GrandMaps and GrandHashTables don''t ned to flush their entirety to disk.  It
 * localizes the state change of a counter.
 */
public class SingleCounter extends Counter {
	protected IntegerVar myCount;
	protected Sema4 myMutex;
/*
udanax-top.st:5783:
Counter subclass: #SingleCounter
	instanceVariableNames: '
		myCount {IntegerVar}
		myMutex {Sema4 NOCOPY}'
	classVariableNames: ''
	poolDictionaries: ''
	category: 'Xanadu-counter'!
*/
/*
udanax-top.st:5789:
SingleCounter comment:
'This counter separates a very simple state change into another flock so that big objects like GrandMaps and GrandHashTables don''t ned to flush their entirety to disk.  It localizes the state change of a counter.'!
*/
/*
udanax-top.st:5791:
(SingleCounter getOrMakeCxxClassDescription)
	attributes: ((Set new) add: #LOCKED; add: #COPY; add: #CONCRETE; add: #NOT.A.TYPE; yourself)!
*/
/*
udanax-top.st:5883:
SingleCounter class
	instanceVariableNames: ''!
*/
/*
udanax-top.st:5886:
(SingleCounter getOrMakeCxxClassDescription)
	attributes: ((Set new) add: #LOCKED; add: #COPY; add: #CONCRETE; add: #NOT.A.TYPE; yourself)!
*/

public IntegerVar count() {
throw new UnsupportedOperationException();/*
udanax-top.st:5796:SingleCounter methodsFor: 'accessing'!
{IntegerVar} count
	^myCount!
*/
}

public IntegerVar decrement() {
throw new UnsupportedOperationException();/*
udanax-top.st:5799:SingleCounter methodsFor: 'accessing'!
{IntegerVar} decrement
	
	myMutex critical: 
		[DiskManager consistent: 1 with:
			[myCount _ myCount - 1.
			self diskUpdate]].
	^myCount!
*/
}

public IntegerVar decrementBy(IntegerVar count) {
throw new UnsupportedOperationException();/*
udanax-top.st:5807:SingleCounter methodsFor: 'accessing'!
{IntegerVar} decrementBy: count {IntegerVar}
	
	count >= IntegerVarZero ifFalse:
		[Heaper BLAST: #InvalidRequest].
	myMutex critical: 
		[DiskManager consistent: 1 with:
			[myCount _ myCount - count.
			self diskUpdate]].
	^myCount!
*/
}

public IntegerVar increment() {
throw new UnsupportedOperationException();/*
udanax-top.st:5817:SingleCounter methodsFor: 'accessing'!
{IntegerVar} increment
	
	myMutex critical: 
		[DiskManager consistent: 1 with:
			[myCount _ myCount + 1.
			self diskUpdate]].
	^myCount!
*/
}

public IntegerVar incrementBy(IntegerVar count) {
throw new UnsupportedOperationException();/*
udanax-top.st:5825:SingleCounter methodsFor: 'accessing'!
{IntegerVar} incrementBy: count {IntegerVar}
	
	count >= IntegerVarZero ifFalse:
		[Heaper BLAST: #InvalidRequest].
	myMutex critical: 
		[DiskManager consistent: 1 with:
			[myCount _ myCount + count.
			self diskUpdate]].
	^myCount!
*/
}

public void setCount(IntegerVar count) {
throw new UnsupportedOperationException();/*
udanax-top.st:5835:SingleCounter methodsFor: 'accessing'!
{void} setCount: count {IntegerVar} 
	
	myMutex critical: 
		[DiskManager consistent: 1 with:
			[myCount _ count.
			self diskUpdate]]!
*/
}

/**
 * re-initialize the non-persistent part
 */
public void restartSingleCounter(Rcvr trans) {
throw new UnsupportedOperationException();/*
udanax-top.st:5844:SingleCounter methodsFor: 'receiver: restart'!
{void RECEIVE.HOOK} restartSingleCounter: trans {Rcvr unused default: NULL}
	"re-initialize the non-persistent part"
	myMutex _ Sema4 make: 1.!
*/
}

public  SingleCounter() {
throw new UnsupportedOperationException();/*
udanax-top.st:5850:SingleCounter methodsFor: 'protected: create'!
create
	super create.
	myCount _ IntegerVar0.
	self restartSingleCounter: NULL.
	self newShepherd.
	self remember!
*/
}

public  SingleCounter(IntegerVar count) {
throw new UnsupportedOperationException();/*
udanax-top.st:5857:SingleCounter methodsFor: 'protected: create'!
create: count {IntegerVar}
	super create.
	myCount _ count.
	self restartSingleCounter: NULL.
	self newShepherd.
	self remember!
*/
}

public int contentsHash() {
throw new UnsupportedOperationException();/*
udanax-top.st:5866:SingleCounter methodsFor: 'testing'!
{UInt32} contentsHash
	^super contentsHash
		bitXor: (IntegerPos integerHash: myCount)!
*/
}

public  SingleCounter(Rcvr receiver) {
throw new UnsupportedOperationException();/*
udanax-top.st:5873:SingleCounter methodsFor: 'generated:'!
create.Rcvr: receiver {Rcvr}
	super create.Rcvr: receiver.
	myCount _ receiver receiveIntegerVar.
	self restartSingleCounter: receiver.!
*/
}

public void sendSelfTo(Xmtr xmtr) {
throw new UnsupportedOperationException();/*
udanax-top.st:5878:SingleCounter methodsFor: 'generated:'!
{void} sendSelfTo: xmtr {Xmtr}
	super sendSelfTo: xmtr.
	xmtr sendIntegerVar: myCount.!
*/
}

public static Heaper make() {
throw new UnsupportedOperationException();/*
udanax-top.st:5891:SingleCounter class methodsFor: 'pseudo-constructors'!
{Counter} make
	^self create.!
*/
}

public static Heaper make(IntegerVar count) {
throw new UnsupportedOperationException();/*
udanax-top.st:5894:SingleCounter class methodsFor: 'pseudo-constructors'!
{Counter} make: count {IntegerVar}
	^self create: count!
*/
}
}
