/*
 * Abora-Gold
 * Part of the Abora hypertext project: http://www.abora.org
 * Copyright 2003 David G Jones
 * 
 * Translated from Udanax-Gold source code: http://www.udanax.com
 * Copyright 1979-1999 Udanax.com. All rights reserved
 */
package org.abora.gold.brange2;

import org.abora.gold.be.basic.BeGrandMap;
import org.abora.gold.collection.sets.MuSet;
import org.abora.gold.turtle.AgendaItem;
import org.abora.gold.xcvr.Rcvr;
import org.abora.gold.xcvr.Xmtr;
import org.abora.gold.xpp.basic.Heaper;


/**
 * This carries on the updating of transitive superclass IDs for the given club.
 */
public class UpdateTransitiveSuperClubIDs extends AgendaItem {
	protected MuSet myClubs;
	protected BeGrandMap myGrandMap;
/*
udanax-top.st:1410:
AgendaItem subclass: #UpdateTransitiveSuperClubIDs
	instanceVariableNames: '
		myClubs {MuSet of: BeClub | NULL}
		myGrandMap {BeGrandMap}'
	classVariableNames: ''
	poolDictionaries: ''
	category: 'Xanadu-brange2'!
*/
/*
udanax-top.st:1416:
UpdateTransitiveSuperClubIDs comment:
'This carries on the updating of transitive superclass IDs for the given club.'!
*/
/*
udanax-top.st:1418:
(UpdateTransitiveSuperClubIDs getOrMakeCxxClassDescription)
	attributes: ((Set new) add: #LOCKED; add: #COPY; add: #SHEPHERD.PATRIARCH; add: #CONCRETE; yourself)!
*/
/*
udanax-top.st:1455:
UpdateTransitiveSuperClubIDs class
	instanceVariableNames: ''!
*/
/*
udanax-top.st:1458:
(UpdateTransitiveSuperClubIDs getOrMakeCxxClassDescription)
	attributes: ((Set new) add: #LOCKED; add: #COPY; add: #SHEPHERD.PATRIARCH; add: #CONCRETE; yourself)!
*/

public boolean step() {
throw new UnsupportedOperationException();/*
udanax-top.st:1423:UpdateTransitiveSuperClubIDs methodsFor: 'accessing'!
{BooleanVar} step
	myClubs isEmpty ifFalse:
		[DiskManager consistent: 2 with:
			[| club {BeClub} stomp {Stepper} |
			club := (stomp := myClubs stepper) fetch cast: BeClub.
			stomp destroy.
			CurrentGrandMap fluidBind: myGrandMap during: [club updateTransitiveSuperClubIDs].
			myClubs remove: club.
			self diskUpdate]].
	^ myClubs isEmpty not!
*/
}

public  UpdateTransitiveSuperClubIDs(MuSet clubs, BeGrandMap grandMap) {
throw new UnsupportedOperationException();/*
udanax-top.st:1436:UpdateTransitiveSuperClubIDs methodsFor: 'protected: creation'!
create: clubs {MuSet of: BeClub} with: grandMap {BeGrandMap}
	super create.
	myClubs := clubs.
	myGrandMap := grandMap.
	self newShepherd.!
*/
}

public  UpdateTransitiveSuperClubIDs(Rcvr receiver) {
throw new UnsupportedOperationException();/*
udanax-top.st:1444:UpdateTransitiveSuperClubIDs methodsFor: 'generated:'!
create.Rcvr: receiver {Rcvr}
	super create.Rcvr: receiver.
	myClubs _ receiver receiveHeaper.
	myGrandMap _ receiver receiveHeaper.!
*/
}

public void sendSelfTo(Xmtr xmtr) {
throw new UnsupportedOperationException();/*
udanax-top.st:1449:UpdateTransitiveSuperClubIDs methodsFor: 'generated:'!
{void} sendSelfTo: xmtr {Xmtr}
	super sendSelfTo: xmtr.
	xmtr sendHeaper: myClubs.
	xmtr sendHeaper: myGrandMap.!
*/
}

public static Heaper make(MuSet clubs, BeGrandMap grandMap) {
throw new UnsupportedOperationException();/*
udanax-top.st:1463:UpdateTransitiveSuperClubIDs class methodsFor: 'creation'!
make: clubs {MuSet of: BeClub} with: grandMap {BeGrandMap}
	^ self create: clubs with: grandMap!
*/
}
}
