/*
 * Abora-Gold
 * Part of the Abora hypertext project: http://www.abora.org
 * Copyright 2003 David G Jones
 * 
 * Translated from Udanax-Gold source code: http://www.udanax.com
 * Copyright 1979-1999 Udanax.com. All rights reserved
 */
package org.abora.gold.brange2;

import org.abora.gold.collection.sets.MuSet;
import org.abora.gold.turtle.AgendaItem;
import org.abora.gold.xcvr.Rcvr;
import org.abora.gold.xcvr.Xmtr;
import org.abora.gold.xpp.basic.Heaper;


/**
 * This carries on the updating of transitive member IDs for the given club.
 */
public class UpdateTransitiveMemberIDs extends AgendaItem {
	protected MuSet myClubs;
/*
udanax-top.st:1359:
AgendaItem subclass: #UpdateTransitiveMemberIDs
	instanceVariableNames: 'myClubs {MuSet of: BeClub}'
	classVariableNames: ''
	poolDictionaries: ''
	category: 'Xanadu-brange2'!
*/
/*
udanax-top.st:1363:
UpdateTransitiveMemberIDs comment:
'This carries on the updating of transitive member IDs for the given club.'!
*/
/*
udanax-top.st:1365:
(UpdateTransitiveMemberIDs getOrMakeCxxClassDescription)
	attributes: ((Set new) add: #LOCKED; add: #COPY; add: #SHEPHERD.PATRIARCH; add: #CONCRETE; yourself)!
*/
/*
udanax-top.st:1399:
UpdateTransitiveMemberIDs class
	instanceVariableNames: ''!
*/
/*
udanax-top.st:1402:
(UpdateTransitiveMemberIDs getOrMakeCxxClassDescription)
	attributes: ((Set new) add: #LOCKED; add: #COPY; add: #SHEPHERD.PATRIARCH; add: #CONCRETE; yourself)!
*/

public boolean step() {
throw new UnsupportedOperationException();/*
udanax-top.st:1370:UpdateTransitiveMemberIDs methodsFor: 'accessing'!
{BooleanVar} step
	myClubs isEmpty ifFalse:
		[DiskManager consistent: 5 with:
			[| club {BeClub} stomp {Stepper} |
			club := (stomp := myClubs stepper) fetch cast: BeClub.
			stomp destroy.
			club updateTransitiveMemberIDs.
			myClubs remove: club.
			self diskUpdate]].
	^ myClubs isEmpty not!
*/
}

public  UpdateTransitiveMemberIDs(MuSet clubs) {
throw new UnsupportedOperationException();/*
udanax-top.st:1383:UpdateTransitiveMemberIDs methodsFor: 'protected: creation'!
create: clubs {MuSet of: BeClub}
	super create.
	myClubs := clubs.
	self newShepherd.!
*/
}

public  UpdateTransitiveMemberIDs(Rcvr receiver) {
throw new UnsupportedOperationException();/*
udanax-top.st:1390:UpdateTransitiveMemberIDs methodsFor: 'generated:'!
create.Rcvr: receiver {Rcvr}
	super create.Rcvr: receiver.
	myClubs _ receiver receiveHeaper.!
*/
}

public void sendSelfTo(Xmtr xmtr) {
throw new UnsupportedOperationException();/*
udanax-top.st:1394:UpdateTransitiveMemberIDs methodsFor: 'generated:'!
{void} sendSelfTo: xmtr {Xmtr}
	super sendSelfTo: xmtr.
	xmtr sendHeaper: myClubs.!
*/
}

public static Heaper make(MuSet clubs) {
throw new UnsupportedOperationException();/*
udanax-top.st:1407:UpdateTransitiveMemberIDs class methodsFor: 'creation'!
make: clubs {MuSet of: BeClub}
	^ self create: clubs!
*/
}
}
