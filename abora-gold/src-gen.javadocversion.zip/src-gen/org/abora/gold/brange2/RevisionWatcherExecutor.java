/*
 * Abora-Gold
 * Part of the Abora hypertext project: http://www.abora.org
 * Copyright 2003 David G Jones
 * 
 * Translated from Udanax-Gold source code: http://www.udanax.com
 * Copyright 1979-1999 Udanax.com. All rights reserved
 */
package org.abora.gold.brange2;

import org.abora.gold.be.basic.BeWork;
import org.abora.gold.wparray.XnExecutor;
import org.abora.gold.xpp.basic.Heaper;


/**
 * This executor tells its BeWork when the last of its revision watchers have gone away.
 */
public class RevisionWatcherExecutor extends XnExecutor {
	protected BeWork myWork;
/*
udanax-top.st:44859:
XnExecutor subclass: #RevisionWatcherExecutor
	instanceVariableNames: 'myWork {BeWork}'
	classVariableNames: ''
	poolDictionaries: ''
	category: 'Xanadu-brange2'!
*/
/*
udanax-top.st:44863:
RevisionWatcherExecutor comment:
'This executor tells its BeWork when the last of its revision watchers have gone away.'!
*/
/*
udanax-top.st:44865:
(RevisionWatcherExecutor getOrMakeCxxClassDescription)
	attributes: ((Set new) add: #CONCRETE; add: #NOT.A.TYPE; yourself)!
*/
/*
udanax-top.st:44881:
RevisionWatcherExecutor class
	instanceVariableNames: ''!
*/
/*
udanax-top.st:44884:
(RevisionWatcherExecutor getOrMakeCxxClassDescription)
	attributes: ((Set new) add: #CONCRETE; add: #NOT.A.TYPE; yourself)!
*/

public  RevisionWatcherExecutor(BeWork work) {
throw new UnsupportedOperationException();/*
udanax-top.st:44870:RevisionWatcherExecutor methodsFor: 'protected: create'!
create: work {BeWork}
	super create.
	myWork := work!
*/
}

public void execute(int arg) {
throw new UnsupportedOperationException();/*
udanax-top.st:44876:RevisionWatcherExecutor methodsFor: 'execute'!
{void} execute: arg {Int32}
	arg == Int32Zero ifTrue: [
		myWork removeLastRevisionWatcher]!
*/
}

public static Heaper make(BeWork work) {
throw new UnsupportedOperationException();/*
udanax-top.st:44889:RevisionWatcherExecutor class methodsFor: 'create'!
{XnExecutor} make: work {BeWork}
	^ self create: work!
*/
}
}
