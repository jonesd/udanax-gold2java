/*
 * Abora-Gold
 * Part of the Abora hypertext project: http://www.abora.org
 * Copyright 2003 David G Jones
 * 
 * Translated from Udanax-Gold source code: http://www.udanax.com
 * Copyright 1979-1999 Udanax.com. All rights reserved
 */
package org.abora.gold.brange2;

import org.abora.gold.be.basic.BeWork;
import org.abora.gold.wparray.XnExecutor;
import org.abora.gold.xpp.basic.Heaper;


public class BeWorkLockExecutor extends XnExecutor {
	protected BeWork myWork;
/*
udanax-top.st:12910:
XnExecutor subclass: #BeWorkLockExecutor
	instanceVariableNames: 'myWork {BeWork}'
	classVariableNames: ''
	poolDictionaries: ''
	category: 'Xanadu-brange2'!
*/
/*
udanax-top.st:12914:
(BeWorkLockExecutor getOrMakeCxxClassDescription)
	attributes: ((Set new) add: #CONCRETE; yourself)!
*/
/*
udanax-top.st:12930:
BeWorkLockExecutor class
	instanceVariableNames: ''!
*/
/*
udanax-top.st:12933:
(BeWorkLockExecutor getOrMakeCxxClassDescription)
	attributes: ((Set new) add: #CONCRETE; yourself)!
*/

/**
 * The work's locking pointer will already be NULL, so we only have to update
 */
public void execute(int estateIndex) {
throw new UnsupportedOperationException();/*
udanax-top.st:12919:BeWorkLockExecutor methodsFor: 'invoking'!
{void} execute: estateIndex {Int32 unused}
	"The work's locking pointer will already be NULL, so we only have to update"
	myWork updateFeStatus!
*/
}

public  BeWorkLockExecutor(BeWork work) {
throw new UnsupportedOperationException();/*
udanax-top.st:12925:BeWorkLockExecutor methodsFor: 'create'!
create: work {BeWork}
	super create.
	myWork := work!
*/
}

public static Heaper make(BeWork work) {
throw new UnsupportedOperationException();/*
udanax-top.st:12938:BeWorkLockExecutor class methodsFor: 'pseudoconstructors'!
make: work {BeWork}
	^ BeWorkLockExecutor create: work!
*/
}
}
