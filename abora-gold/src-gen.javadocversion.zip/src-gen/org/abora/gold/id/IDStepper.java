/*
 * Abora-Gold
 * Part of the Abora hypertext project: http://www.abora.org
 * Copyright 2003 David G Jones
 * 
 * Translated from Udanax-Gold source code: http://www.udanax.com
 * Copyright 1979-1999 Udanax.com. All rights reserved
 */
package org.abora.gold.id;

import org.abora.gold.be.basic.ID;
import org.abora.gold.collection.steppers.Stepper;
import org.abora.gold.id.IDRegion;
import org.abora.gold.xpp.basic.Heaper;


public class IDStepper extends Stepper {
	protected IDRegion myRegion;
	protected Stepper myBackends;
	protected Stepper myIDs;
	protected ID myValue;
/*
udanax-top.st:54313:
Stepper subclass: #IDStepper
	instanceVariableNames: '
		myRegion {IDRegion}
		myBackends {Stepper | NULL of: Sequence}
		myIDs {Stepper | NULL of: IntegerPos}
		myValue {ID | NULL}'
	classVariableNames: ''
	poolDictionaries: ''
	category: 'Xanadu-id'!
*/
/*
udanax-top.st:54321:
(IDStepper getOrMakeCxxClassDescription)
	attributes: ((Set new) add: #CONCRETE; add: #NOT.A.TYPE; yourself)!
*/

public Stepper copy() {
throw new UnsupportedOperationException();/*
udanax-top.st:54326:IDStepper methodsFor: 'create'!
{Stepper} copy
	
	^IDStepper create: myRegion with: myBackends copy with: myIDs copy!
*/
}

public  IDStepper(IDRegion region) {
throw new UnsupportedOperationException();/*
udanax-top.st:54330:IDStepper methodsFor: 'create'!
create: region {IDRegion}
	super create.
	myRegion := region.
	myBackends := region backends stepper.
	myBackends hasValue
		ifTrue: [myIDs := (region iDNumbersFrom: (myBackends fetch cast: Sequence)) stepper]
		ifFalse: [myIDs := NULL. myBackends := NULL].
	myValue := NULL.!
*/
}

public  IDStepper(IDRegion region, Stepper backends, Stepper iDs) {
throw new UnsupportedOperationException();/*
udanax-top.st:54340:IDStepper methodsFor: 'create'!
create: region {IDRegion} with: backends {Stepper of: Sequence} with: iDs {Stepper of: IntegerPos}
	super create.
	myRegion := region.
	myBackends := backends.
	myIDs := iDs.
	myValue := NULL.!
*/
}

public Heaper fetch() {
throw new UnsupportedOperationException();/*
udanax-top.st:54349:IDStepper methodsFor: 'operations'!
{Heaper wimpy} fetch
	(myValue == NULL and: [myBackends ~~ NULL]) ifTrue:
		[myValue := ID usingx: myRegion fetchSpace
			with: (myBackends fetch cast: Sequence)
			with: (myIDs fetch cast: IntegerPos) asIntegerVar].
	^myValue!
*/
}

public boolean hasValue() {
throw new UnsupportedOperationException();/*
udanax-top.st:54357:IDStepper methodsFor: 'operations'!
{BooleanVar} hasValue
	^myBackends ~~ NULL!
*/
}

public void step() {
throw new UnsupportedOperationException();/*
udanax-top.st:54361:IDStepper methodsFor: 'operations'!
{void} step
	myBackends ~~ NULL ifTrue:
		[myValue := NULL.
		myIDs step.
		myIDs hasValue ifFalse:
			[myBackends step.
			myBackends hasValue ifFalse:
				[myBackends := NULL.
				myIDs := NULL.
				^VOID].
			myIDs := (myRegion iDNumbersFrom: (myBackends fetch cast: Sequence)) stepper]]!
*/
}
}
