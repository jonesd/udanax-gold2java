/*
 * Abora-Gold
 * Part of the Abora hypertext project: http://www.abora.org
 * Copyright 2003 David G Jones
 * 
 * Translated from Udanax-Gold source code: http://www.udanax.com
 * Copyright 1979-1999 Udanax.com. All rights reserved
 */
package org.abora.gold.nbacken;

import org.abora.gold.collection.steppers.Stepper;
import org.abora.gold.collection.steppers.TableStepper;
import org.abora.gold.nkernel.FeEdition;
import org.abora.gold.spaces.basic.Position;
import org.abora.gold.xpp.basic.Heaper;


public class EditionStepper extends TableStepper {
	protected Stepper myKeys;
	protected FeEdition myEdition;
/*
udanax-top.st:55617:
TableStepper subclass: #EditionStepper
	instanceVariableNames: '
		myKeys {Stepper of: Position}
		myEdition {FeEdition}'
	classVariableNames: ''
	poolDictionaries: ''
	category: 'Xanadu-nbacken'!
*/
/*
udanax-top.st:55623:
(EditionStepper getOrMakeCxxClassDescription)
	attributes: ((Set new) add: #CONCRETE; add: #NOT.A.TYPE; yourself)!
*/

public Stepper copy() {
throw new UnsupportedOperationException();/*
udanax-top.st:55628:EditionStepper methodsFor: 'create'!
{Stepper} copy
	^EditionStepper create: myKeys copy with: myEdition!
*/
}

public  EditionStepper(Stepper keys, FeEdition edition) {
throw new UnsupportedOperationException();/*
udanax-top.st:55632:EditionStepper methodsFor: 'create'!
create: keys {Stepper of: Position} with: edition {FeEdition}
	
	super create.
	myKeys := keys.
	myEdition := edition.!
*/
}

public Position position() {
throw new UnsupportedOperationException();/*
udanax-top.st:55640:EditionStepper methodsFor: 'special'!
{Position} position
	^myKeys get cast: Position!
*/
}

public Heaper fetch() {
throw new UnsupportedOperationException();/*
udanax-top.st:55646:EditionStepper methodsFor: 'operations'!
{Heaper wimpy} fetch
	myKeys hasValue
		ifTrue: [^myEdition get: (myKeys fetch cast: Position)]
		ifFalse: [^NULL]!
*/
}

public boolean hasValue() {
throw new UnsupportedOperationException();/*
udanax-top.st:55652:EditionStepper methodsFor: 'operations'!
{BooleanVar} hasValue
	^myKeys hasValue!
*/
}

public void step() {
throw new UnsupportedOperationException();/*
udanax-top.st:55656:EditionStepper methodsFor: 'operations'!
{void} step
	myKeys step!
*/
}
}
