/*
 * Abora-Gold
 * Part of the Abora hypertext project: http://www.abora.org
 * Copyright 2003 David G Jones
 * 
 * Translated from Udanax-Gold source code: http://www.udanax.com
 * Copyright 1979-1999 Udanax.com. All rights reserved
 */
package org.abora.gold.nbacken;

import org.abora.gold.be.basic.BeEdition;
import org.abora.gold.collection.steppers.Stepper;
import org.abora.gold.collection.steppers.TableStepper;
import org.abora.gold.id.IDRegion;
import org.abora.gold.spaces.basic.Position;
import org.abora.gold.xpp.basic.Heaper;


/**
 * Has a Bundle Stepper on a piece of the Edition defining the grants for this Server, and
 * views it as a sequence of associations from ClubIDs to IDRegions (which is the inverse of
 * its actual format)
 */
public class GrantStepper extends TableStepper {
	protected Stepper myBundles;
	protected IDRegion myClubIDs;
/*
udanax-top.st:55728:
TableStepper subclass: #GrantStepper
	instanceVariableNames: '
		myBundles {Stepper of: FeBundle}
		myClubIDs {IDRegion | NULL}'
	classVariableNames: ''
	poolDictionaries: ''
	category: 'Xanadu-nbacken'!
*/
/*
udanax-top.st:55734:
GrantStepper comment:
'Has a Bundle Stepper on a piece of the Edition defining the grants for this Server, and views it as a sequence of associations from ClubIDs to IDRegions (which is the inverse of its actual format)'!
*/
/*
udanax-top.st:55736:
(GrantStepper getOrMakeCxxClassDescription)
	attributes: ((Set new) add: #CONCRETE; add: #NOT.A.TYPE; yourself)!
*/
/*
udanax-top.st:55778:
GrantStepper class
	instanceVariableNames: ''!
*/
/*
udanax-top.st:55781:
(GrantStepper getOrMakeCxxClassDescription)
	attributes: ((Set new) add: #CONCRETE; add: #NOT.A.TYPE; yourself)!
*/

public Position position() {
throw new UnsupportedOperationException();/*
udanax-top.st:55741:GrantStepper methodsFor: 'special'!
{Position} position
	Ravi thingToDo. "in future implementations this might also get back an ArrayBundle"
	^CurrentGrandMap fluidGet iDOf: (myBundles get cast: FeElementBundle) element getOrMakeBe!
*/
}

public Heaper fetch() {
throw new UnsupportedOperationException();/*
udanax-top.st:55748:GrantStepper methodsFor: 'operations'!
{Heaper wimpy} fetch
	| bundle {FeBundle} |
	bundle := myBundles fetch cast: FeBundle.
	bundle == NULL ifTrue: [^NULL].
	^bundle region!
*/
}

public boolean hasValue() {
throw new UnsupportedOperationException();/*
udanax-top.st:55755:GrantStepper methodsFor: 'operations'!
{BooleanVar} hasValue
	^myBundles hasValue!
*/
}

public void step() {
throw new UnsupportedOperationException();/*
udanax-top.st:55759:GrantStepper methodsFor: 'operations'!
{void} step
	[myBundles hasValue] whileTrue:
		[myBundles step.
		(myClubIDs == NULL or: [myClubIDs hasMember: self position])
			ifTrue: [^VOID]]!
*/
}

public Stepper copy() {
throw new UnsupportedOperationException();/*
udanax-top.st:55767:GrantStepper methodsFor: 'create'!
{Stepper} copy
	^GrantStepper create: myBundles copy with: myClubIDs!
*/
}

public  GrantStepper(Stepper bundles, IDRegion clubIDs) {
throw new UnsupportedOperationException();/*
udanax-top.st:55771:GrantStepper methodsFor: 'create'!
create: bundles {Stepper of: FeBundle} with: clubIDs {IDRegion | NULL}
	super create.
	myBundles := bundles.
	myClubIDs := clubIDs.!
*/
}

public static Heaper make(BeEdition grants, IDRegion clubIDs) {
throw new UnsupportedOperationException();/*
udanax-top.st:55786:GrantStepper class methodsFor: 'create'!
{TableStepper} make: grants {BeEdition} with: clubIDs {IDRegion | NULL}
	^self create: grants retrieve with: clubIDs!
*/
}
}
