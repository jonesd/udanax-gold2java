/*
 * Abora-Gold
 * Part of the Abora hypertext project: http://www.abora.org
 * Copyright 2003 David G Jones
 * 
 * Translated from Udanax-Gold source code: http://www.udanax.com
 * Copyright 1979-1999 Udanax.com. All rights reserved
 */
package org.abora.gold.srvloop;

import org.abora.gold.rcmain.ServerChunk;


public class TestChunk extends ServerChunk {
/*
udanax-top.st:51131:
ServerChunk subclass: #TestChunk
	instanceVariableNames: ''
	classVariableNames: ''
	poolDictionaries: ''
	category: 'Xanadu-srvloop'!
*/
/*
udanax-top.st:51135:
(TestChunk getOrMakeCxxClassDescription)
	attributes: ((Set new) add: #CONCRETE; yourself)!
*/

public void processInput() {
throw new UnsupportedOperationException();/*
udanax-top.st:51140:TestChunk methodsFor: 'accessing'!
{void} processInput!
*/
}

public boolean execute() {
throw new UnsupportedOperationException();/*
udanax-top.st:51144:TestChunk methodsFor: 'execute'!
{BooleanVar} execute
	^ false!
*/
}
}
