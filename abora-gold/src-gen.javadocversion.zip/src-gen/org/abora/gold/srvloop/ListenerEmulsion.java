/*
 * Abora-Gold
 * Part of the Abora hypertext project: http://www.abora.org
 * Copyright 2003 David G Jones
 * 
 * Translated from Udanax-Gold source code: http://www.udanax.com
 * Copyright 1979-1999 Udanax.com. All rights reserved
 */
package org.abora.gold.srvloop;

import org.abora.gold.java.missing.VoidStar;
import org.abora.gold.xpp.basic.Heaper;
import org.abora.gold.xpp.fluid.Emulsion;


public class ListenerEmulsion extends Emulsion {
	protected char defaultFluidSpace;
/*
udanax-top.st:27879:
Emulsion subclass: #ListenerEmulsion
	instanceVariableNames: 'defaultFluidSpace {char star}'
	classVariableNames: ''
	poolDictionaries: ''
	category: 'Xanadu-srvloop'!
*/
/*
udanax-top.st:27910:
ListenerEmulsion class
	instanceVariableNames: ''!
*/

public VoidStar fetchNewRawSpace(int size) {
throw new UnsupportedOperationException();/*
udanax-top.st:27887:ListenerEmulsion methodsFor: 'accessing'!
{void star} fetchNewRawSpace: size {#size.U.t var}
	(CurrentChunk == NULL) ifTrue: [
		["cxx: return (defaultFluidSpace = (char *) fcalloc (size, sizeof(char)));"] translateOnly.
		[^defaultFluidSpace _ Array new: size] smalltalkOnly]
	ifFalse: [
		["cxx: return CurrentChunk->fluidSpace( (char *) fcalloc (size, sizeof(char)) );"] translateOnly.
		[^CurrentChunk fluidSpace: (Array new: size)] smalltalkOnly]!
*/
}

public VoidStar fetchOldRawSpace() {
throw new UnsupportedOperationException();/*
udanax-top.st:27896:ListenerEmulsion methodsFor: 'accessing'!
{void star} fetchOldRawSpace
	(CurrentChunk == NULL) ifTrue: [
		^defaultFluidSpace. ]
	ifFalse: [
		^CurrentChunk fluidSpace.]!
*/
}

public  ListenerEmulsion() {
throw new UnsupportedOperationException();/*
udanax-top.st:27905:ListenerEmulsion methodsFor: 'creation'!
create
	super create.
	defaultFluidSpace _ NULL.!
*/
}

public static Heaper make() {
throw new UnsupportedOperationException();/*
udanax-top.st:27917:ListenerEmulsion class methodsFor: 'smalltalk: passe'!
make
	
	self passe. "use 'Listener listenerEmulsion'"!
*/
}
}
