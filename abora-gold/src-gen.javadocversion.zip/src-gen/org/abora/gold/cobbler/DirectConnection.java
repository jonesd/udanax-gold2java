/*
 * Abora-Gold
 * Part of the Abora hypertext project: http://www.abora.org
 * Copyright 2003 David G Jones
 * 
 * Translated from Udanax-Gold source code: http://www.udanax.com
 * Copyright 1979-1999 Udanax.com. All rights reserved
 */
package org.abora.gold.cobbler;

import org.abora.gold.cobbler.Connection;
import org.abora.gold.xpp.basic.Category;
import org.abora.gold.xpp.basic.Heaper;


/**
 * We just made the object, so the connection is just a reference to the object.
 */
public class DirectConnection extends Connection {
	protected Category myCategory;
	protected Heaper myHeaper;
/*
udanax-top.st:13914:
Connection subclass: #DirectConnection
	instanceVariableNames: '
		myCategory {Category}
		myHeaper {Heaper}'
	classVariableNames: ''
	poolDictionaries: ''
	category: 'Xanadu-cobbler'!
*/
/*
udanax-top.st:13920:
DirectConnection comment:
'We just made the object, so the connection is just a reference to the object.'!
*/
/*
udanax-top.st:13922:
(DirectConnection getOrMakeCxxClassDescription)
	attributes: ((Set new) add: #CONCRETE; add: #NOT.A.TYPE; yourself)!
*/

public Category bootCategory() {
throw new UnsupportedOperationException();/*
udanax-top.st:13927:DirectConnection methodsFor: 'accessing'!
{Category} bootCategory
	^myCategory!
*/
}

public Heaper bootHeaper() {
throw new UnsupportedOperationException();/*
udanax-top.st:13930:DirectConnection methodsFor: 'accessing'!
{Heaper} bootHeaper
	^myHeaper!
*/
}

public  DirectConnection(Category cat, Heaper heaper) {
throw new UnsupportedOperationException();/*
udanax-top.st:13935:DirectConnection methodsFor: 'creation'!
create: cat {Category} with: heaper {Heaper}
	super create.
	myCategory _ cat.
	myHeaper _ heaper!
*/
}

/**
 * myHeaper destroy. There are bootHeapers that you REALLY don't want to destroy, such as the
 * GrandMap
 */
public void destruct() {
throw new UnsupportedOperationException();/*
udanax-top.st:13940:DirectConnection methodsFor: 'creation'!
{void} destruct
	"myHeaper destroy. There are bootHeapers that you REALLY don't want to destroy, such as the GrandMap"
	super destruct!
*/
}
}
