/*
 * Abora-Gold
 * Part of the Abora hypertext project: http://www.abora.org
 * Copyright 2003 David G Jones
 * 
 * Translated from Udanax-Gold source code: http://www.udanax.com
 * Copyright 1979-1999 Udanax.com. All rights reserved
 */
package org.abora.gold.cobbler;

import java.io.PrintWriter;
import org.abora.gold.cobbler.Cookbook;
import org.abora.gold.collection.basic.PtrArray;
import org.abora.gold.collection.basic.UInt32Array;
import org.abora.gold.java.missing.IntegerVar;
import org.abora.gold.xcvr.Rcvr;
import org.abora.gold.xcvr.Recipe;
import org.abora.gold.xcvr.Xmtr;
import org.abora.gold.xpp.basic.Category;
import org.abora.gold.xpp.basic.Heaper;


/**
 * We internally map from Category to preorder number for the category and lookup using that
 * preorder number.
 */
public class ActualCookbook extends Cookbook {
	protected char myName;
	protected Category myBootCategory;
	protected Cookbook myNext;
	protected PtrArray myRecipes;
	protected PtrArray myDecoding;
	protected UInt32Array myEncoding;
	protected static Cookbook TheCookbooks;
/*
udanax-top.st:14137:
Cookbook subclass: #ActualCookbook
	instanceVariableNames: '
		myName {char star}
		myBootCategory {Category}
		myNext {Cookbook}
		myRecipes {PtrArray of: Recipe}
		myDecoding {PtrArray of: Category}
		myEncoding {UInt32Array}'
	classVariableNames: 'TheCookbooks {Cookbook} '
	poolDictionaries: ''
	category: 'Xanadu-cobbler'!
*/
/*
udanax-top.st:14147:
ActualCookbook comment:
'We internally map from Category to preorder number for the category and lookup using that preorder number.'!
*/
/*
udanax-top.st:14149:
(ActualCookbook getOrMakeCxxClassDescription)
	attributes: ((Set new) add: #CONCRETE; add: #NOT.A.TYPE; yourself)!
*/
/*
udanax-top.st:14240:
ActualCookbook class
	instanceVariableNames: ''!
*/
/*
udanax-top.st:14243:
(ActualCookbook getOrMakeCxxClassDescription)
	attributes: ((Set new) add: #CONCRETE; add: #NOT.A.TYPE; yourself)!
*/

public Category bootCategory() {
throw new UnsupportedOperationException();/*
udanax-top.st:14154:ActualCookbook methodsFor: 'accessing'!
{Category} bootCategory
	^myBootCategory!
*/
}

public Recipe fetchRecipe(Category cat) {
throw new UnsupportedOperationException();/*
udanax-top.st:14157:ActualCookbook methodsFor: 'accessing'!
{Recipe} fetchRecipe: cat {Category}
	^(myRecipes fetch: cat preorderNumber) cast: Recipe!
*/
}

public Category getCategoryFor(IntegerVar no) {
throw new UnsupportedOperationException();/*
udanax-top.st:14160:ActualCookbook methodsFor: 'accessing'!
{Category} getCategoryFor: no {IntegerVar}
	| category {Category} |
	category _ (myDecoding fetch: no DOTasLong) cast: Category.
	category == NULL ifTrue: [Heaper BLAST: #NotInTable].
	^category!
*/
}

public Recipe getRecipe(Category cat) {
throw new UnsupportedOperationException();/*
udanax-top.st:14166:ActualCookbook methodsFor: 'accessing'!
{Recipe} getRecipe: cat {Category}
	| recipe {Recipe} |
	recipe _ (myRecipes fetch: cat preorderNumber) cast: Recipe.
	recipe == NULL ifTrue: [Heaper BLAST: #NotInTable].
	^recipe!
*/
}

public String id() {
throw new UnsupportedOperationException();/*
udanax-top.st:14172:ActualCookbook methodsFor: 'accessing'!
{char star} id
	^myName!
*/
}

public Cookbook next() {
throw new UnsupportedOperationException();/*
udanax-top.st:14175:ActualCookbook methodsFor: 'accessing'!
{Cookbook} next
	^myNext!
*/
}

public IntegerVar numberOfCategory(Category cat) {
throw new UnsupportedOperationException();/*
udanax-top.st:14178:ActualCookbook methodsFor: 'accessing'!
{IntegerVar} numberOfCategory: cat {Category}
	| num {Int32} |
	num _ myEncoding uIntAt: cat preorderNumber.
	num >= myRecipes count ifTrue: [Heaper BLAST: #UnencodedCategory].
	^num!
*/
}

public PtrArray recipes() {
throw new UnsupportedOperationException();/*
udanax-top.st:14184:ActualCookbook methodsFor: 'accessing'!
{PtrArray} recipes 
	^myRecipes!
*/
}

public  ActualCookbook(Category cat, String id, PtrArray recipes, int count) {
throw new UnsupportedOperationException();/*
udanax-top.st:14189:ActualCookbook methodsFor: 'creation'!
create: cat {Category} with: id {char star} with: recipes {PtrArray of: Recipe} with: count {Int32}
	| preorderLimit {Int32} code {Int32} |
	super create.
	myName _ id.
	myBootCategory _ cat.
	preorderLimit _ Heaper preorderMax + 1.
	"preorder -> recipe."
	myRecipes _ recipes.
	"preorder -> code."
	myEncoding _ UInt32Array make: preorderLimit.
	"code -> category"
	myDecoding _ PtrArray nulls: count.
	code _ Int32Zero.
	Int32Zero almostTo: preorderLimit do: 
		[:i {Int32} |
		| recipe {Recipe} |
		recipe _ (myRecipes fetch: i) cast: Recipe.
		recipe == NULL
			ifTrue: [myEncoding at: i storeUInt: preorderLimit]
			ifFalse:
				[myEncoding at: i storeUInt: code.
				myDecoding at: code store: recipe categoryOfDish.
				code _ code + 1]].
	myNext _ TheCookbooks.
	TheCookbooks _ self!
*/
}

/**
 * ActualCookbooks last for the whole run.
 */
public void destroy() {
throw new UnsupportedOperationException();/*
udanax-top.st:14215:ActualCookbook methodsFor: 'creation'!
{void} destroy
	"ActualCookbooks last for the whole run."!
*/
}

public void printOn(PrintWriter oo) {
throw new UnsupportedOperationException();/*
udanax-top.st:14220:ActualCookbook methodsFor: 'printing'!
{void} printOn: oo {ostream reference}
	oo << 'an ' << self getCategory name!
*/
}

public void receiveClassList(Rcvr rcvr) {
throw new UnsupportedOperationException();/*
udanax-top.st:14225:ActualCookbook methodsFor: 'smalltalk: hooks:'!
{void RECEIVE.HOOK} receiveClassList: rcvr {Rcvr}
	| count {IntegerVar} |
	count _ rcvr receiveIntegerVar.
	myRecipes  _ MuTable make: HeaperSpace make.
	Int32Zero almostTo: count do: 
		[:i {Int32} | | clName {String} cl {Category} |
		clName _ rcvr receiveString.
		[cl _ Smalltalk at: clName asSymbol ifAbsent: [Cookbook BLAST: 'class name not recognized']] smalltalkOnly.
		myRecipes at: cl store: cl getRecipe.]!
*/
}

public void sendClassList(Xmtr xmtr) {
throw new UnsupportedOperationException();/*
udanax-top.st:14235:ActualCookbook methodsFor: 'smalltalk: hooks:'!
{void SEND.HOOK} sendClassList: xmtr {Xmtr}
	xmtr sendIntegerVar: myRecipes count.
	myRecipes stepper forEach: [:rec | xmtr sendString: rec categoryOfDish name]!
*/
}

public static int addCuisineTo(Recipe cuisine, PtrArray recipes) {
throw new UnsupportedOperationException();/*
udanax-top.st:14248:ActualCookbook class methodsFor: 'global: utility'!
{Int32} addCuisine: cuisine {Recipe} to: recipes {PtrArray}
	| recipe {Recipe} count {Int32} |
	count _ Int32Zero.
	recipe _ cuisine.
	[recipe ~~ NULL] whileTrue:
		[recipes at: recipe categoryOfDish preorderNumber store: recipe.
		count _ count + 1.
		recipe _ recipe next].
	^count!
*/
}

public static Heaper make(Category bootCat) {
throw new UnsupportedOperationException();/*
udanax-top.st:14260:ActualCookbook class methodsFor: 'creation'!
{Cookbook} make.Category: bootCat {Category}
	| cookbook {Cookbook} |
	cookbook _ TheCookbooks.
	[cookbook ~~ NULL] whileTrue:
		[(cookbook bootCategory isEqual: bootCat) ifTrue: [^cookbook].
		cookbook _ cookbook next].
	Heaper BLAST: #UnknownCookbook.
	^NULL "fodder"!
*/
}

public static Heaper make(String id) {
throw new UnsupportedOperationException();/*
udanax-top.st:14269:ActualCookbook class methodsFor: 'creation'!
{Cookbook} make.String: id {char star}
	| cookbook {Cookbook} |
	cookbook _ TheCookbooks.
	[cookbook ~~ NULL] whileTrue:
		[(String strcmp: cookbook id with: id) == Int32Zero ifTrue: [^cookbook].
		cookbook _ cookbook next].
	Heaper BLAST: #UnknownCookbook.
	^NULL "fodder"!
*/
}

public static void cleanupGarbage() {
throw new UnsupportedOperationException();/*
udanax-top.st:14280:ActualCookbook class methodsFor: 'smalltalk: initialization'!
{void} cleanupGarbage
	TheCookbooks _ NULL!
*/
}

public static void initTimeNonInherited() {
throw new UnsupportedOperationException();/*
udanax-top.st:14283:ActualCookbook class methodsFor: 'smalltalk: initialization'!
initTimeNonInherited
	Cookbook declareCookbook: 'empty' with: Heaper with: NULL!
*/
}

public static void linkTimeNonInherited() {
throw new UnsupportedOperationException();/*
udanax-top.st:14286:ActualCookbook class methodsFor: 'smalltalk: initialization'!
{void} linkTimeNonInherited
	TheCookbooks _ NULL!
*/
}
}
