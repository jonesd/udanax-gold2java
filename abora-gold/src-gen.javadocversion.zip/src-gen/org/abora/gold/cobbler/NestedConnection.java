/*
 * Abora-Gold
 * Part of the Abora hypertext project: http://www.abora.org
 * Copyright 2003 David G Jones
 * 
 * Translated from Udanax-Gold source code: http://www.udanax.com
 * Copyright 1979-1999 Udanax.com. All rights reserved
 */
package org.abora.gold.cobbler;

import org.abora.gold.cobbler.Connection;
import org.abora.gold.xpp.basic.Category;
import org.abora.gold.xpp.basic.Heaper;


/**
 * We just made an object that wraps another object, so the connection needs to wrap the
 * connection by which that other object was obtained.
 */
public class NestedConnection extends Connection {
	protected Category myCategory;
	protected Heaper myHeaper;
	protected Connection mySub;
/*
udanax-top.st:13977:
Connection subclass: #NestedConnection
	instanceVariableNames: '
		myCategory {Category}
		myHeaper {Heaper}
		mySub {Connection}'
	classVariableNames: ''
	poolDictionaries: ''
	category: 'Xanadu-cobbler'!
*/
/*
udanax-top.st:13984:
NestedConnection comment:
'We just made an object that wraps another object, so the connection needs to wrap the connection by which that other object was obtained.'!
*/
/*
udanax-top.st:13986:
(NestedConnection getOrMakeCxxClassDescription)
	attributes: ((Set new) add: #CONCRETE; add: #NOT.A.TYPE; yourself)!
*/
/*
udanax-top.st:14011:
NestedConnection class
	instanceVariableNames: ''!
*/
/*
udanax-top.st:14014:
(NestedConnection getOrMakeCxxClassDescription)
	attributes: ((Set new) add: #CONCRETE; add: #NOT.A.TYPE; yourself)!
*/

public Category bootCategory() {
throw new UnsupportedOperationException();/*
udanax-top.st:13991:NestedConnection methodsFor: 'accessing'!
{Category} bootCategory
	^myCategory!
*/
}

public Heaper bootHeaper() {
throw new UnsupportedOperationException();/*
udanax-top.st:13994:NestedConnection methodsFor: 'accessing'!
{Heaper} bootHeaper
	^myHeaper!
*/
}

public  NestedConnection(Category cat, Heaper heaper, Connection sub) {
throw new UnsupportedOperationException();/*
udanax-top.st:13999:NestedConnection methodsFor: 'creation'!
create: cat {Category} with: heaper {Heaper} with: sub {Connection}
	super create.
	myCategory _ cat.
	myHeaper _ heaper.
	mySub _ sub!
*/
}

public void destruct() {
throw new UnsupportedOperationException();/*
udanax-top.st:14005:NestedConnection methodsFor: 'creation'!
{void} destruct
	mySub destroy.
	myHeaper destroy.
	super destruct!
*/
}

public static Heaper make(Category cat, Heaper heaper, Connection sub) {
throw new UnsupportedOperationException();/*
udanax-top.st:14019:NestedConnection class methodsFor: 'creation'!
{Connection} make: cat {Category} with: heaper {Heaper} with: sub {Connection}
	^self create: cat with: heaper with: sub!
*/
}
}
