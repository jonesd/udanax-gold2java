/*
 * Abora-Gold
 * Part of the Abora hypertext project: http://www.abora.org
 * Copyright 2003 David G Jones
 * 
 * Translated from Udanax-Gold source code: http://www.udanax.com
 * Copyright 1979-1999 Udanax.com. All rights reserved
 */
package org.abora.gold.cobbler;

import java.io.PrintWriter;
import org.abora.gold.cobbler.BootPlan;
import org.abora.gold.cobbler.Connection;
import org.abora.gold.xpp.basic.Category;
import org.abora.gold.xpp.basic.Heaper;


public class BootMaker extends BootPlan {
/*
udanax-top.st:56841:
BootPlan subclass: #BootMaker
	instanceVariableNames: ''
	classVariableNames: ''
	poolDictionaries: ''
	category: 'Xanadu-cobbler'!
*/
/*
udanax-top.st:56845:
(BootMaker getOrMakeCxxClassDescription)
	attributes: ((Set new) add: #NOT.A.TYPE; add: #DEFERRED; yourself)!
*/

public Category bootCategory() {
throw new UnsupportedOperationException();/*
udanax-top.st:56850:BootMaker methodsFor: 'accessing'!
{Category} bootCategory
	self subclassResponsibility!
*/
}

/**
 * Return the object representing the connection.  This gives the client a handle by which to
 * terminate the connection.
 */
public Connection connection() {
throw new UnsupportedOperationException();/*
udanax-top.st:56853:BootMaker methodsFor: 'accessing'!
{Connection} connection
	"Return the object representing the connection.  This gives the client a handle by which to terminate the connection."
	
	^DirectConnection create: self bootCategory with: self bootHeaper!
*/
}

public void printOn(PrintWriter oo) {
throw new UnsupportedOperationException();/*
udanax-top.st:56860:BootMaker methodsFor: 'printing'!
{void} printOn: oo {ostream reference}
	oo << self getCategory name.!
*/
}

/**
 * Subclasses of maker only need to define the routine that makes the boot heaper.
 */
public Heaper bootHeaper() {
throw new UnsupportedOperationException();/*
udanax-top.st:56865:BootMaker methodsFor: 'protected:'!
{Heaper} bootHeaper
	"Subclasses of maker only need to define the routine that makes the boot heaper."
	
	self subclassResponsibility!
*/
}
}
