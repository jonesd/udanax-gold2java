/*
 * Abora-Gold
 * Part of the Abora hypertext project: http://www.abora.org
 * Copyright 2003 David G Jones
 * 
 * Translated from Udanax-Gold source code: http://www.udanax.com
 * Copyright 1979-1999 Udanax.com. All rights reserved
 */
package org.abora.gold.cobbler;

import org.abora.gold.cobbler.Connection;
import org.abora.gold.fm.support.Thunk;
import org.abora.gold.xpp.basic.Category;


public class BootPlan extends Thunk {
/*
udanax-top.st:56798:
Thunk subclass: #BootPlan
	instanceVariableNames: ''
	classVariableNames: ''
	poolDictionaries: ''
	category: 'Xanadu-cobbler'!
*/
/*
udanax-top.st:56802:
(BootPlan getOrMakeCxxClassDescription)
	attributes: ((Set new) add: #DEFERRED; yourself)!
*/
/*
udanax-top.st:56824:
BootPlan class
	instanceVariableNames: ''!
*/
/*
udanax-top.st:56827:
(BootPlan getOrMakeCxxClassDescription)
	attributes: ((Set new) add: #DEFERRED; yourself)!
*/

public Category bootCategory() {
throw new UnsupportedOperationException();/*
udanax-top.st:56807:BootPlan methodsFor: 'accessing'!
{Category} bootCategory
	self subclassResponsibility!
*/
}

/**
 * Return the object representing the connection.  This gives the client a handle by which to
 * terminate the connection.
 */
public Connection connection() {
throw new UnsupportedOperationException();/*
udanax-top.st:56810:BootPlan methodsFor: 'accessing'!
{Connection} connection
	"Return the object representing the connection.  This gives the client a handle by which to terminate the connection."
	
	self subclassResponsibility!
*/
}

/**
 * A comm hook couldn't register the bootPlan because it's working with a not-fully
 * constructed object, so we have to make bootPlans thunks and register them here.
 */
public void execute() {
throw new UnsupportedOperationException();/*
udanax-top.st:56817:BootPlan methodsFor: 'operate'!
{void} execute
	"A comm hook couldn't register the bootPlan because it's working with a not-fully
	 constructed object, so we have to make bootPlans thunks and register them here."
	Connection registerBootPlan: self!
*/
}

public static void cleanupGarbage() {
throw new UnsupportedOperationException();/*
udanax-top.st:56832:BootPlan class methodsFor: 'smalltalk: init'!
cleanupGarbage
	BootCuisine _ NULL!
*/
}

public static void initTimeNonInherited() {
throw new UnsupportedOperationException();/*
udanax-top.st:56835:BootPlan class methodsFor: 'smalltalk: init'!
initTimeNonInherited
	Cookbook declareCookbook: 'boot' with: BootPlan with: BootCuisine with: XppCuisine!
*/
}

public static void linkTimeNonInherited() {
throw new UnsupportedOperationException();/*
udanax-top.st:56838:BootPlan class methodsFor: 'smalltalk: init'!
linkTimeNonInherited
	Recipe star defineGlobal: #BootCuisine with: NULL.!
*/
}
}
