/*
 * Abora-Gold
 * Part of the Abora hypertext project: http://www.abora.org
 * Copyright 2003 David G Jones
 * 
 * Translated from Udanax-Gold source code: http://www.udanax.com
 * Copyright 1979-1999 Udanax.com. All rights reserved
 */
package org.abora.gold.schunk;

import org.abora.gold.schunk.ChunkCleaner;
import org.abora.gold.xpp.basic.Heaper;


/**
 * Chunk cleaners perform end-of-session cleanup work.  This includes making sure that
 * session level objects are released.
 */
public class ChunkCleaner extends Heaper {
	protected ChunkCleaner myNext;
	protected static ChunkCleaner FirstCleaner;
/*
udanax-top.st:13642:
Heaper subclass: #ChunkCleaner
	instanceVariableNames: 'myNext {ChunkCleaner}'
	classVariableNames: 'FirstCleaner {ChunkCleaner} '
	poolDictionaries: ''
	category: 'Xanadu-schunk'!
*/
/*
udanax-top.st:13646:
ChunkCleaner comment:
'Chunk cleaners perform end-of-session cleanup work.  This includes making sure that session level objects are released.'!
*/
/*
udanax-top.st:13648:
(ChunkCleaner getOrMakeCxxClassDescription)
	attributes: ((Set new) add: #DEFERRED; add: #EQ; yourself)!
*/
/*
udanax-top.st:13675:
ChunkCleaner class
	instanceVariableNames: ''!
*/
/*
udanax-top.st:13678:
(ChunkCleaner getOrMakeCxxClassDescription)
	attributes: ((Set new) add: #DEFERRED; add: #EQ; yourself)!
*/

public ChunkCleaner next() {
throw new UnsupportedOperationException();/*
udanax-top.st:13653:ChunkCleaner methodsFor: 'private: accessing'!
{ChunkCleaner} next
	^ myNext!
*/
}

public void cleanup() {
throw new UnsupportedOperationException();/*
udanax-top.st:13658:ChunkCleaner methodsFor: 'invoking'!
{void} cleanup
	self subclassResponsibility!
*/
}

public  ChunkCleaner() {
throw new UnsupportedOperationException();/*
udanax-top.st:13663:ChunkCleaner methodsFor: 'protected: create'!
create
	super create.
	myNext := FirstCleaner.
	FirstCleaner := self.!
*/
}

public int actualHashForEqual() {
throw new UnsupportedOperationException();/*
udanax-top.st:13670:ChunkCleaner methodsFor: 'generated:'!
actualHashForEqual ^self asOop!
*/
}

public boolean isEqual(Object other) {
throw new UnsupportedOperationException();/*
udanax-top.st:13672:ChunkCleaner methodsFor: 'generated:'!
isEqual: other ^self == other!
*/
}

public static void beClean() {
throw new UnsupportedOperationException();/*
udanax-top.st:13683:ChunkCleaner class methodsFor: 'cleanup'!
{void} beClean
	| cleaner {ChunkCleaner} |
	cleaner := FirstCleaner.
	[cleaner ~~ NULL] whileTrue: [
		cleaner cleanup.
		cleaner := cleaner next].!
*/
}

public static void linkTimeNonInherited() {
throw new UnsupportedOperationException();/*
udanax-top.st:13692:ChunkCleaner class methodsFor: 'smalltalk: init'!
linkTimeNonInherited
	FirstCleaner := NULL!
*/
}
}
