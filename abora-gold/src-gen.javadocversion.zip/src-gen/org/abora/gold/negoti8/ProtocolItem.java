/*
 * Abora-Gold
 * Part of the Abora hypertext project: http://www.abora.org
 * Copyright 2003 David G Jones
 * 
 * Translated from Udanax-Gold source code: http://www.udanax.com
 * Copyright 1979-1999 Udanax.com. All rights reserved
 */
package org.abora.gold.negoti8;

import org.abora.gold.negoti8.ProtocolItem;
import org.abora.gold.xpp.basic.Heaper;


public class ProtocolItem extends Heaper {
	protected char myName;
	protected ProtocolItem myNext;
	protected Heaper myItem;
/*
udanax-top.st:40984:
Heaper subclass: #ProtocolItem
	instanceVariableNames: '
		myName {char star}
		myNext {ProtocolItem}
		myItem {Heaper}'
	classVariableNames: ''
	poolDictionaries: ''
	category: 'Xanadu-negoti8'!
*/
/*
udanax-top.st:40991:
(ProtocolItem getOrMakeCxxClassDescription)
	attributes: ((Set new) add: #CONCRETE; yourself)!
*/

public Heaper get(String name) {
throw new UnsupportedOperationException();/*
udanax-top.st:40996:ProtocolItem methodsFor: 'accessing'!
{Heaper} get: name {char star}
	(String strcmp: name with: myName) == Int32Zero ifTrue:
		[ ^ myItem ].
	myNext ~~ NULL
		ifTrue: [ ^ myNext get: name ]
		ifFalse: [ Heaper BLAST: #NotInList ].
	^NULL "fodder"!
*/
}

public  ProtocolItem(String name, Heaper item, ProtocolItem next) {
throw new UnsupportedOperationException();/*
udanax-top.st:41006:ProtocolItem methodsFor: 'create'!
create: name {char star} with: item {Heaper} with: next {ProtocolItem} 
	super create.
	myName _ name.
	myItem _ item.
	myNext _ next!
*/
}

public int actualHashForEqual() {
throw new UnsupportedOperationException();/*
udanax-top.st:41014:ProtocolItem methodsFor: 'testing'!
{UInt32} actualHashForEqual
	^Heaper takeOop!
*/
}
}
