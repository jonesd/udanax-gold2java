/*
 * Abora-Gold
 * Part of the Abora hypertext project: http://www.abora.org
 * Copyright 2003 David G Jones
 * 
 * Translated from Udanax-Gold source code: http://www.udanax.com
 * Copyright 1979-1999 Udanax.com. All rights reserved
 */
package org.abora.gold.negoti8;

import org.abora.gold.negoti8.ProtocolItem;
import org.abora.gold.xcvr.XcvrMaker;
import org.abora.gold.xpp.basic.Heaper;


public class ProtocolBroker extends Heaper {
	protected static ProtocolItem CommProtocols;
	protected static ProtocolItem DiskProtocols;
	protected static XcvrMaker TheCommProtocol;
	protected static XcvrMaker TheDiskProtocol;
/*
udanax-top.st:40920:
Heaper subclass: #ProtocolBroker
	instanceVariableNames: ''
	classVariableNames: '
		CommProtocols {ProtocolItem} 
		DiskProtocols {ProtocolItem} 
		TheCommProtocol {XcvrMaker} 
		TheDiskProtocol {XcvrMaker} '
	poolDictionaries: ''
	category: 'Xanadu-negoti8'!
*/
/*
udanax-top.st:40928:
(ProtocolBroker getOrMakeCxxClassDescription)
	attributes: ((Set new) add: #DEFERRED; add: #EQ; yourself)!
*/
/*
udanax-top.st:40938:
ProtocolBroker class
	instanceVariableNames: ''!
*/
/*
udanax-top.st:40941:
(ProtocolBroker getOrMakeCxxClassDescription)
	attributes: ((Set new) add: #DEFERRED; add: #EQ; yourself)!
*/

public int actualHashForEqual() {
throw new UnsupportedOperationException();/*
udanax-top.st:40933:ProtocolBroker methodsFor: 'generated:'!
actualHashForEqual ^self asOop!
*/
}

public boolean isEqual(Object other) {
throw new UnsupportedOperationException();/*
udanax-top.st:40935:ProtocolBroker methodsFor: 'generated:'!
isEqual: other ^self == other!
*/
}

public static void linkTimeNonInherited() {
throw new UnsupportedOperationException();/*
udanax-top.st:40946:ProtocolBroker class methodsFor: 'smalltalk: initialization'!
linkTimeNonInherited
	DiskProtocols _ NULL.
	CommProtocols _ NULL.
	TheCommProtocol _ NULL.
	TheDiskProtocol _ NULL!
*/
}

/**
 * return whichever is the best current protocol.
 */
public static XcvrMaker commProtocol() {
throw new UnsupportedOperationException();/*
udanax-top.st:40954:ProtocolBroker class methodsFor: 'configuration'!
{XcvrMaker} commProtocol
	"return whichever is the best current protocol."
	TheCommProtocol == NULL ifTrue: [TheCommProtocol _ (CommProtocols get: 'binary1') cast: XcvrMaker].
	^TheCommProtocol!
*/
}

public static XcvrMaker commProtocol(String id) {
throw new UnsupportedOperationException();/*
udanax-top.st:40959:ProtocolBroker class methodsFor: 'configuration'!
{XcvrMaker} commProtocol: id {char star}
	^(CommProtocols get: id) cast: XcvrMaker!
*/
}

/**
 * return whichever is the best current protocol.
 */
public static XcvrMaker diskProtocol() {
throw new UnsupportedOperationException();/*
udanax-top.st:40962:ProtocolBroker class methodsFor: 'configuration'!
{XcvrMaker} diskProtocol
	"return whichever is the best current protocol."
	TheDiskProtocol == NULL ifTrue: [TheDiskProtocol _ (DiskProtocols get: 'binary1') cast: XcvrMaker].
	^TheDiskProtocol!
*/
}

public static XcvrMaker diskProtocol(String id) {
throw new UnsupportedOperationException();/*
udanax-top.st:40967:ProtocolBroker class methodsFor: 'configuration'!
{XcvrMaker} diskProtocol: id {char star}
	^(DiskProtocols get: id) cast: XcvrMaker!
*/
}

public static void registerXcvrProtocol(XcvrMaker maker) {
throw new UnsupportedOperationException();/*
udanax-top.st:40970:ProtocolBroker class methodsFor: 'configuration'!
{void} registerXcvrProtocol: maker {XcvrMaker}
	CommProtocols _ ProtocolItem create: maker id with: maker with: CommProtocols.
	DiskProtocols _ ProtocolItem create: maker id with: maker with: DiskProtocols.!
*/
}

/**
 * Set the protocol.
 */
public static void setCommProtocol(XcvrMaker maker) {
throw new UnsupportedOperationException();/*
udanax-top.st:40974:ProtocolBroker class methodsFor: 'configuration'!
{void} setCommProtocol: maker {XcvrMaker}
	"Set the protocol."
	
	TheCommProtocol _ maker!
*/
}

/**
 * Set the protocol.
 */
public static void setDiskProtocol(XcvrMaker maker) {
throw new UnsupportedOperationException();/*
udanax-top.st:40979:ProtocolBroker class methodsFor: 'configuration'!
{void} setDiskProtocol: maker {XcvrMaker}
	"Set the protocol."
	
	TheDiskProtocol _ maker!
*/
}
}
