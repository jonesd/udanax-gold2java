/*
 * Abora-Gold
 * Part of the Abora hypertext project: http://www.abora.org
 * Copyright 2003 David G Jones
 * 
 * Translated from Udanax-Gold source code: http://www.udanax.com
 * Copyright 1979-1999 Udanax.com. All rights reserved
 */
package org.abora.gold.hspace;

import org.abora.gold.collection.sets.ImmuSet;
import org.abora.gold.collection.sets.ScruSet;
import org.abora.gold.spaces.basic.CoordinateSpace;
import org.abora.gold.spaces.basic.OrderSpec;
import org.abora.gold.spaces.basic.XnRegion;
import org.abora.gold.spaces.unordered.HeaperAsPosition;
import org.abora.gold.spaces.unordered.SetRegion;
import org.abora.gold.xcvr.Rcvr;
import org.abora.gold.xcvr.Xmtr;
import org.abora.gold.xpp.basic.Heaper;


public class HeaperRegion extends SetRegion {
/*
udanax-top.st:70180:
SetRegion subclass: #HeaperRegion
	instanceVariableNames: ''
	classVariableNames: ''
	poolDictionaries: ''
	category: 'Xanadu-hspace'!
*/
/*
udanax-top.st:70184:
(HeaperRegion getOrMakeCxxClassDescription)
	attributes: ((Set new) add: #CONCRETE; add: #NOT.A.TYPE; add: #COPY; yourself)!
*/
/*
udanax-top.st:70217:
HeaperRegion class
	instanceVariableNames: ''!
*/
/*
udanax-top.st:70220:
(HeaperRegion getOrMakeCxxClassDescription)
	attributes: ((Set new) add: #CONCRETE; add: #NOT.A.TYPE; add: #COPY; yourself)!
*/

public CoordinateSpace coordinateSpace() {
throw new UnsupportedOperationException();/*
udanax-top.st:70189:HeaperRegion methodsFor: 'accessing'!
{CoordinateSpace} coordinateSpace
	^HeaperSpace make!
*/
}

public XnRegion makeNew(boolean isComplement, ImmuSet positions) {
throw new UnsupportedOperationException();/*
udanax-top.st:70194:HeaperRegion methodsFor: 'protected: protected'!
{XnRegion} makeNew: isComplement {BooleanVar} with: positions {ImmuSet of: Position}
	^HeaperRegion create: isComplement with: positions!
*/
}

public boolean isEnumerable(OrderSpec order) {
throw new UnsupportedOperationException();/*
udanax-top.st:70199:HeaperRegion methodsFor: 'testing'!
{BooleanVar} isEnumerable: order {OrderSpec default: NULL}
	^false!
*/
}

public  HeaperRegion(boolean isComplement, ImmuSet positions) {
	super(isComplement, positions);
throw new UnsupportedOperationException();/*
udanax-top.st:70205:HeaperRegion methodsFor: 'creation'!
create: isComplement {BooleanVar} with: positions {ImmuSet of: HeaperAsPosition}
	super create: isComplement with: positions!
*/
}

public  HeaperRegion(Rcvr receiver) {
	super(receiver);
throw new UnsupportedOperationException();/*
udanax-top.st:70210:HeaperRegion methodsFor: 'generated:'!
create.Rcvr: receiver {Rcvr}
	super create.Rcvr: receiver.!
*/
}

public void sendSelfTo(Xmtr xmtr) {
throw new UnsupportedOperationException();/*
udanax-top.st:70213:HeaperRegion methodsFor: 'generated:'!
{void} sendSelfTo: xmtr {Xmtr}
	super sendSelfTo: xmtr.!
*/
}

public static SetRegion allHeaperAsPositions() {
throw new UnsupportedOperationException();/*
udanax-top.st:70225:HeaperRegion class methodsFor: 'pseudo constructors'!
{SetRegion} allHeaperAsPositions
	^HeaperRegion create: true with: ImmuSet make!
*/
}

public static Heaper make() {
throw new UnsupportedOperationException();/*
udanax-top.st:70228:HeaperRegion class methodsFor: 'pseudo constructors'!
{SetRegion} make
	^HeaperRegion create: false with: ImmuSet make!
*/
}

public static Heaper make(HeaperAsPosition heaper) {
throw new UnsupportedOperationException();/*
udanax-top.st:70231:HeaperRegion class methodsFor: 'pseudo constructors'!
{SetRegion} make.HeaperAsPosition: heaper {HeaperAsPosition}
	^HeaperRegion create: false with: (ImmuSet make with: heaper)!
*/
}

public static Heaper make(ScruSet heapers) {
throw new UnsupportedOperationException();/*
udanax-top.st:70234:HeaperRegion class methodsFor: 'pseudo constructors'!
{SetRegion} make.ScruSet: heapers {ScruSet of: HeaperAsPosition}
	^HeaperRegion create: false with: heapers asImmuSet!
*/
}
}
