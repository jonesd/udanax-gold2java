/*
 * Abora-Gold
 * Part of the Abora hypertext project: http://www.abora.org
 * Copyright 2003 David G Jones
 * 
 * Translated from Udanax-Gold source code: http://www.udanax.com
 * Copyright 1979-1999 Udanax.com. All rights reserved
 */
package org.abora.gold.chameleon;

import org.abora.gold.chameleon.Chameleon;
import org.abora.gold.java.missing.IntegerVar;
import org.abora.gold.xcvr.Rcvr;
import org.abora.gold.xcvr.Xmtr;
import org.abora.gold.xpp.basic.Heaper;


public class Butterfly extends Chameleon {
	protected IntegerVar myE;
	protected Heaper myF;
/*
udanax-top.st:13487:
Chameleon subclass: #Butterfly
	instanceVariableNames: '
		myE {IntegerVar}
		myF {Heaper}'
	classVariableNames: ''
	poolDictionaries: ''
	category: 'Xanadu-Chameleon'!
*/
/*
udanax-top.st:13493:
(Butterfly getOrMakeCxxClassDescription)
	attributes: ((Set new) add: #CONCRETE; add: #COPY; yourself)!
*/

public  Butterfly() {
throw new UnsupportedOperationException();/*
udanax-top.st:13498:Butterfly methodsFor: 'instance creation'!
create
	super create.
	myE _ IntegerVar0.
	myF _ NULL.!
*/
}

public  Butterfly(Rcvr receiver) {
throw new UnsupportedOperationException();/*
udanax-top.st:13505:Butterfly methodsFor: 'generated:'!
create.Rcvr: receiver {Rcvr}
	super create.Rcvr: receiver.
	myE _ receiver receiveIntegerVar.
	myF _ receiver receiveHeaper.!
*/
}

public void sendSelfTo(Xmtr xmtr) {
throw new UnsupportedOperationException();/*
udanax-top.st:13510:Butterfly methodsFor: 'generated:'!
{void} sendSelfTo: xmtr {Xmtr}
	super sendSelfTo: xmtr.
	xmtr sendIntegerVar: myE.
	xmtr sendHeaper: myF.!
*/
}
}
