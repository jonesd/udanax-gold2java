/*
 * Abora-Gold
 * Part of the Abora hypertext project: http://www.abora.org
 * Copyright 2003 David G Jones
 * 
 * Translated from Udanax-Gold source code: http://www.udanax.com
 * Copyright 1979-1999 Udanax.com. All rights reserved
 */
package org.abora.gold.chameleon;

import org.abora.gold.chameleon.Butterfly;


public class LeadButterfly extends Butterfly {
/*
udanax-top.st:13529:
Butterfly subclass: #LeadButterfly
	instanceVariableNames: ''
	classVariableNames: ''
	poolDictionaries: ''
	category: 'Xanadu-Chameleon'!
*/
/*
udanax-top.st:13533:
(LeadButterfly getOrMakeCxxClassDescription)
	attributes: ((Set new) add: #(MAY.BECOME DeadMoth ); add: #(MAY.BECOME Butterfly ); add: #CONCRETE; yourself)!
*/
}
