/*
 * Abora-Gold
 * Part of the Abora hypertext project: http://www.abora.org
 * Copyright 2003 David G Jones
 * 
 * Translated from Udanax-Gold source code: http://www.udanax.com
 * Copyright 1979-1999 Udanax.com. All rights reserved
 */
package org.abora.gold.cxx.classx.stuff;

import org.abora.gold.chameleon.Chameleon;
import org.abora.gold.java.missing.IntegerVar;
import org.abora.gold.xcvr.Rcvr;
import org.abora.gold.xcvr.Xmtr;
import org.abora.gold.xpp.basic.Heaper;


public class DeadButterfly extends Chameleon {
	protected IntegerVar myJ;
	protected Heaper myK;
	protected Heaper myL;
	protected Heaper myM;
/*
udanax-top.st:13536:
Chameleon subclass: #DeadButterfly
	instanceVariableNames: '
		myJ {IntegerVar}
		myK {Heaper}
		myL {Heaper}
		myM {Heaper}'
	classVariableNames: ''
	poolDictionaries: ''
	category: 'Cxx-class-stuff'!
*/
/*
udanax-top.st:13544:
(DeadButterfly getOrMakeCxxClassDescription)
	attributes: ((Set new) add: #CONCRETE; add: #COPY; yourself)!
*/

public  DeadButterfly() {
throw new UnsupportedOperationException();/*
udanax-top.st:13549:DeadButterfly methodsFor: 'instance creation'!
create
	super create.
	myJ _ IntegerVar0.
	myK _ NULL.!
*/
}

public  DeadButterfly(Rcvr receiver) {
throw new UnsupportedOperationException();/*
udanax-top.st:13556:DeadButterfly methodsFor: 'generated:'!
create.Rcvr: receiver {Rcvr}
	super create.Rcvr: receiver.
	myJ _ receiver receiveIntegerVar.
	myK _ receiver receiveHeaper.
	myL _ receiver receiveHeaper.
	myM _ receiver receiveHeaper.!
*/
}

public void sendSelfTo(Xmtr xmtr) {
throw new UnsupportedOperationException();/*
udanax-top.st:13563:DeadButterfly methodsFor: 'generated:'!
{void} sendSelfTo: xmtr {Xmtr}
	super sendSelfTo: xmtr.
	xmtr sendIntegerVar: myJ.
	xmtr sendHeaper: myK.
	xmtr sendHeaper: myL.
	xmtr sendHeaper: myM.!
*/
}
}
