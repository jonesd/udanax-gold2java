/*
 * Abora-Gold
 * Part of the Abora hypertext project: http://www.abora.org
 * Copyright 2003 David G Jones
 * 
 * Translated from Udanax-Gold source code: http://www.udanax.com
 * Copyright 1979-1999 Udanax.com. All rights reserved
 */
package org.abora.gold.cxx.classx.stuff;

import org.abora.gold.collection.grand.GrandDataPage;
import org.abora.gold.collection.grand.GrandEntry;
import org.abora.gold.collection.steppers.Stepper;
import org.abora.gold.java.missing.IntegerVar;
import org.abora.gold.xpp.basic.Heaper;


public class GrandDataPageStepper extends Stepper {
	protected GrandDataPage page;
	protected IntegerVar entryIndex;
/*
udanax-top.st:53875:
Stepper subclass: #GrandDataPageStepper
	instanceVariableNames: '
		page {GrandDataPage}
		entryIndex {IntegerVar}'
	classVariableNames: ''
	poolDictionaries: ''
	category: 'Cxx-class-stuff'!
*/
/*
udanax-top.st:53881:
(GrandDataPageStepper getOrMakeCxxClassDescription)
	attributes: ((Set new) add: #CONCRETE; yourself)!
*/

public GrandEntry entry() {
throw new UnsupportedOperationException();/*
udanax-top.st:53886:GrandDataPageStepper methodsFor: 'operations'!
{GrandEntry} entry
	^ (page entryAt: entryIndex) basicCast: GrandEntry!
*/
}

public Heaper fetch() {
throw new UnsupportedOperationException();/*
udanax-top.st:53889:GrandDataPageStepper methodsFor: 'operations'!
{Heaper wimpy} fetch
	self shouldNotImplement.
	^ NULL!
*/
}

public boolean hasValue() {
throw new UnsupportedOperationException();/*
udanax-top.st:53893:GrandDataPageStepper methodsFor: 'operations'!
{BooleanVar} hasValue
	^ entryIndex < page entryCount!
*/
}

public void step() {
throw new UnsupportedOperationException();/*
udanax-top.st:53896:GrandDataPageStepper methodsFor: 'operations'!
{void} step
	entryIndex _ entryIndex + 1.
	self verifyEntry!
*/
}

public  GrandDataPageStepper(GrandDataPage aPage, IntegerVar index) {
throw new UnsupportedOperationException();/*
udanax-top.st:53902:GrandDataPageStepper methodsFor: 'private: create'!
create: aPage {GrandDataPage} with: index {IntegerVar}
	super create.
	page _ aPage.
	entryIndex _ index.
	self verifyEntry.!
*/
}

public void verifyEntry() {
throw new UnsupportedOperationException();/*
udanax-top.st:53910:GrandDataPageStepper methodsFor: 'private: private'!
{void} verifyEntry
	[entryIndex < page entryCount and: [(page entryAt: entryIndex) == NULL]]
		whileTrue:
			[entryIndex _ entryIndex + 1]!
*/
}

public Stepper copy() {
throw new UnsupportedOperationException();/*
udanax-top.st:53917:GrandDataPageStepper methodsFor: 'create'!
{Stepper} copy
	^ GrandDataPageStepper create: page with: entryIndex!
*/
}

public  GrandDataPageStepper(GrandDataPage aPage) {
throw new UnsupportedOperationException();/*
udanax-top.st:53920:GrandDataPageStepper methodsFor: 'create'!
create: aPage {GrandDataPage}
	super create.
	page _ aPage.
	entryIndex _ IntegerVar0.
	self verifyEntry!
*/
}
}
