/*
 * Abora-Gold
 * Part of the Abora hypertext project: http://www.abora.org
 * Copyright 2003 David G Jones
 * 
 * Translated from Udanax-Gold source code: http://www.udanax.com
 * Copyright 1979-1999 Udanax.com. All rights reserved
 */
package org.abora.gold.cxx.classx.stuff;

import org.abora.gold.collection.grand.GrandEntry;
import org.abora.gold.collection.grand.GrandOverflow;
import org.abora.gold.collection.steppers.Stepper;
import org.abora.gold.cxx.classx.stuff.GrandOverflowStepper;
import org.abora.gold.java.missing.IntegerVar;
import org.abora.gold.xpp.basic.Heaper;


public class GrandOverflowStepper extends Stepper {
	protected GrandOverflow overflow;
	protected IntegerVar entryIndex;
	protected GrandOverflowStepper childStepper;
	protected IntegerVar childIndex;
/*
udanax-top.st:54075:
Stepper subclass: #GrandOverflowStepper
	instanceVariableNames: '
		overflow {GrandOverflow}
		entryIndex {IntegerVar}
		childStepper {GrandOverflowStepper}
		childIndex {IntegerVar}'
	classVariableNames: ''
	poolDictionaries: ''
	category: 'Cxx-class-stuff'!
*/
/*
udanax-top.st:54083:
(GrandOverflowStepper getOrMakeCxxClassDescription)
	attributes: ((Set new) add: #CONCRETE; yourself)!
*/

public void verifyEntry() {
throw new UnsupportedOperationException();/*
udanax-top.st:54088:GrandOverflowStepper methodsFor: 'private:'!
{void} verifyEntry
	entryIndex < overflow entryCount
		ifTrue:
			[[entryIndex < overflow entryCount and: [(overflow entryAt: entryIndex) == NULL]]
				whileTrue: [entryIndex _ entryIndex + 1]].
	entryIndex < overflow entryCount ifTrue: [ ^ VOID ].
	
	childIndex < overflow childCount
		ifTrue:
			[[childIndex < overflow childCount and: [(overflow childAt: childIndex) == NULL]]
				whileTrue: [childIndex _ childIndex + 1].
				childIndex < overflow childCount
					ifTrue: [ childStepper _ GrandOverflowStepper create: (overflow childAt: childIndex) ]]!
*/
}

public GrandEntry entry() {
throw new UnsupportedOperationException();/*
udanax-top.st:54105:GrandOverflowStepper methodsFor: 'operations'!
{GrandEntry} entry
	childStepper == NULL
		ifTrue: [ ^ overflow entryAt: entryIndex ]
		ifFalse: [ ^ childStepper entry ]!
*/
}

public Heaper fetch() {
throw new UnsupportedOperationException();/*
udanax-top.st:54110:GrandOverflowStepper methodsFor: 'operations'!
{Heaper wimpy} fetch
	self shouldNotImplement.
	^ NULL!
*/
}

public boolean hasValue() {
throw new UnsupportedOperationException();/*
udanax-top.st:54114:GrandOverflowStepper methodsFor: 'operations'!
{BooleanVar} hasValue
	childStepper ~~ NULL
		ifTrue: [ ^ childStepper hasValue ]
		ifFalse: [ ^ entryIndex < overflow entryCount and: [childIndex < overflow childCount]]!
*/
}

public void step() {
throw new UnsupportedOperationException();/*
udanax-top.st:54119:GrandOverflowStepper methodsFor: 'operations'!
{void} step
	childStepper ~~ NULL
		ifTrue:
			[childStepper step.
			childStepper hasValue
				ifTrue: [ ^VOID ]
				ifFalse:
					[childStepper destroy.
					childStepper _ NULL.
					childIndex _ childIndex + 1]]
		ifFalse:
			[entryIndex _ entryIndex + 1].
	self verifyEntry!
*/
}

public Stepper copy() {
throw new UnsupportedOperationException();/*
udanax-top.st:54135:GrandOverflowStepper methodsFor: 'create'!
{Stepper} copy
	^ GrandOverflowStepper create: overflow with: entryIndex with: childStepper with: childIndex!
*/
}

public  GrandOverflowStepper(GrandOverflow aPage) {
throw new UnsupportedOperationException();/*
udanax-top.st:54138:GrandOverflowStepper methodsFor: 'create'!
create: aPage {GrandOverflow}
	super create.
	overflow _ aPage.
	entryIndex _ childIndex _ IntegerVar0.
	childStepper _ NULL.
	self verifyEntry.!
*/
}

public  GrandOverflowStepper(GrandOverflow anOverflow, IntegerVar entryIdx, GrandOverflowStepper child, IntegerVar childIdx) {
throw new UnsupportedOperationException();/*
udanax-top.st:54147:GrandOverflowStepper methodsFor: 'protected: creation'!
create: anOverflow {GrandOverflow} with: entryIdx {IntegerVar} with: child {GrandOverflowStepper} with: childIdx {IntegerVar}
	super create.
	overflow _ anOverflow.
	entryIndex _ entryIdx.
	childStepper _ child.
	childIndex _ childIdx.!
*/
}

public void destruct() {
throw new UnsupportedOperationException();/*
udanax-top.st:54154:GrandOverflowStepper methodsFor: 'protected: creation'!
{void} destruct
	childStepper ~~ NULL ifTrue: [ childStepper destroy ].
	super destruct.!
*/
}
}
