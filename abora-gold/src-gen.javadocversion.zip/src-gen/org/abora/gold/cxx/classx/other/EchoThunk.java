/*
 * Abora-Gold
 * Part of the Abora hypertext project: http://www.abora.org
 * Copyright 2003 David G Jones
 * 
 * Translated from Udanax-Gold source code: http://www.udanax.com
 * Copyright 1979-1999 Udanax.com. All rights reserved
 */
package org.abora.gold.cxx.classx.other;

import org.abora.gold.fm.support.Thunk;
import org.abora.gold.xcvr.Rcvr;
import org.abora.gold.xcvr.Xmtr;


public class EchoThunk extends Thunk {
	protected char message;
/*
udanax-top.st:57263:
Thunk subclass: #EchoThunk
	instanceVariableNames: 'message {char star}'
	classVariableNames: ''
	poolDictionaries: ''
	category: 'Cxx-class-other'!
*/
/*
udanax-top.st:57267:
(EchoThunk getOrMakeCxxClassDescription)
	attributes: ((Set new) add: #CONCRETE; add: #COPY; add: #NOT.A.TYPE; yourself)!
*/

/**
 * Execute the action defined by this thunk.
 */
public void execute() {
throw new UnsupportedOperationException();/*
udanax-top.st:57272:EchoThunk methodsFor: 'action'!
{void} execute
	"Execute the action defined by this thunk."
	
	cerr << message << '
'!
*/
}

public void restartEchoThunk(Rcvr rcvr) {
throw new UnsupportedOperationException();/*
udanax-top.st:57280:EchoThunk methodsFor: 'hooks:'!
{void} restartEchoThunk: rcvr {Rcvr unused default: NULL}
	DeleteExecutor registerHolder: self with: message!
*/
}

public  EchoThunk(Rcvr receiver) {
throw new UnsupportedOperationException();/*
udanax-top.st:57285:EchoThunk methodsFor: 'generated:'!
create.Rcvr: receiver {Rcvr}
	super create.Rcvr: receiver.
	message _ receiver receiveString.!
*/
}

public void sendSelfTo(Xmtr xmtr) {
throw new UnsupportedOperationException();/*
udanax-top.st:57289:EchoThunk methodsFor: 'generated:'!
{void} sendSelfTo: xmtr {Xmtr}
	super sendSelfTo: xmtr.
	xmtr sendString: message.!
*/
}
}
