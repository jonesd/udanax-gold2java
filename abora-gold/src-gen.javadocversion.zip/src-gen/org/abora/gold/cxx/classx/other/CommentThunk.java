/*
 * Abora-Gold
 * Part of the Abora hypertext project: http://www.abora.org
 * Copyright 2003 David G Jones
 * 
 * Translated from Udanax-Gold source code: http://www.udanax.com
 * Copyright 1979-1999 Udanax.com. All rights reserved
 */
package org.abora.gold.cxx.classx.other;

import org.abora.gold.fm.support.Thunk;
import org.abora.gold.xcvr.Rcvr;
import org.abora.gold.xcvr.Xmtr;


public class CommentThunk extends Thunk {
	protected char message;
/*
udanax-top.st:57164:
Thunk subclass: #CommentThunk
	instanceVariableNames: 'message {char star}'
	classVariableNames: ''
	poolDictionaries: ''
	category: 'Cxx-class-other'!
*/
/*
udanax-top.st:57168:
(CommentThunk getOrMakeCxxClassDescription)
	attributes: ((Set new) add: #CONCRETE; add: #COPY; add: #NOT.A.TYPE; yourself)!
*/

public void restartCommentThunk(Rcvr rcvr) {
throw new UnsupportedOperationException();/*
udanax-top.st:57173:CommentThunk methodsFor: 'hooks:'!
{void} restartCommentThunk: rcvr {Rcvr unused default: NULL}
	DeleteExecutor registerHolder: self with: message.!
*/
}

public void execute() {
throw new UnsupportedOperationException();/*
udanax-top.st:57178:CommentThunk methodsFor: 'action'!
{void} execute!
*/
}

public  CommentThunk(Rcvr receiver) {
throw new UnsupportedOperationException();/*
udanax-top.st:57182:CommentThunk methodsFor: 'generated:'!
create.Rcvr: receiver {Rcvr}
	super create.Rcvr: receiver.
	message _ receiver receiveString.!
*/
}

public void sendSelfTo(Xmtr xmtr) {
throw new UnsupportedOperationException();/*
udanax-top.st:57186:CommentThunk methodsFor: 'generated:'!
{void} sendSelfTo: xmtr {Xmtr}
	super sendSelfTo: xmtr.
	xmtr sendString: message.!
*/
}
}
