/*
 * Abora-Gold
 * Part of the Abora hypertext project: http://www.abora.org
 * Copyright 2003 David G Jones
 * 
 * Translated from Udanax-Gold source code: http://www.udanax.com
 * Copyright 1979-1999 Udanax.com. All rights reserved
 */
package org.abora.gold.cxx.classx.stuff;

import org.abora.gold.collection.grand.GrandEntry;
import org.abora.gold.collection.grand.GrandNode;
import org.abora.gold.collection.steppers.Stepper;
import org.abora.gold.cxx.classx.stuff.GrandDataPageStepper;
import org.abora.gold.cxx.classx.stuff.GrandOverflowStepper;
import org.abora.gold.java.missing.IntegerVar;
import org.abora.gold.xpp.basic.Heaper;


public class GrandNodeStepper extends Stepper {
	protected GrandNode node;
	protected GrandDataPageStepper pageStepper;
	protected IntegerVar pageIndex;
	protected GrandOverflowStepper overflowStepper;
/*
udanax-top.st:53990:
Stepper subclass: #GrandNodeStepper
	instanceVariableNames: '
		node {GrandNode}
		pageStepper {GrandDataPageStepper}
		pageIndex {IntegerVar}
		overflowStepper {GrandOverflowStepper}'
	classVariableNames: ''
	poolDictionaries: ''
	category: 'Cxx-class-stuff'!
*/
/*
udanax-top.st:53998:
(GrandNodeStepper getOrMakeCxxClassDescription)
	attributes: ((Set new) add: #CONCRETE; yourself)!
*/

public  GrandNodeStepper(GrandNode aNode, GrandDataPageStepper curPageStepper, IntegerVar curPageIndex, GrandOverflowStepper oflowStepper) {
throw new UnsupportedOperationException();/*
udanax-top.st:54003:GrandNodeStepper methodsFor: 'protected: creation'!
create: aNode {GrandNode} with: curPageStepper {GrandDataPageStepper} with: curPageIndex {IntegerVar} with: oflowStepper {GrandOverflowStepper}
	super create.
	node _ aNode.
	pageStepper _ curPageStepper.
	pageIndex _ curPageIndex.
	overflowStepper _ oflowStepper.!
*/
}

public void destruct() {
throw new UnsupportedOperationException();/*
udanax-top.st:54010:GrandNodeStepper methodsFor: 'protected: creation'!
{void} destruct
	pageStepper ~~ NULL ifTrue: [ pageStepper destroy ].
	overflowStepper ~~ NULL ifTrue: [ overflowStepper destroy ].
	super destruct.!
*/
}

public void verifyEntry() {
throw new UnsupportedOperationException();/*
udanax-top.st:54017:GrandNodeStepper methodsFor: 'private:'!
{void} verifyEntry
	[pageIndex < node pageCount and: [(node pageAt: pageIndex) isEmpty]]
		whileTrue:
			[pageIndex _ pageIndex + 1].
	pageIndex < node pageCount
		ifTrue:		
			[pageStepper _ GrandDataPageStepper create: (node pageAt: pageIndex)]
		ifFalse:
			[(overflowStepper == NULL and: [node fetchOverflow ~~ NULL])
				ifTrue:
					[overflowStepper _ GrandOverflowStepper create: node fetchOverflow]
				ifFalse:
					[overflowStepper ~~ NULL ifTrue:
						[overflowStepper destroy].
					overflowStepper _ NULL.
					node fetchOldOverflow ~~ NULL ifTrue:
						[overflowStepper _ GrandOverflowStepper create: node fetchOldOverflow]]]!
*/
}

public GrandEntry entry() {
throw new UnsupportedOperationException();/*
udanax-top.st:54037:GrandNodeStepper methodsFor: 'operations'!
{GrandEntry} entry
	overflowStepper ~~ NULL 
		ifTrue: [ ^ overflowStepper entry ]
		ifFalse: [ ^ pageStepper entry ]!
*/
}

public Heaper fetch() {
throw new UnsupportedOperationException();/*
udanax-top.st:54042:GrandNodeStepper methodsFor: 'operations'!
{Heaper wimpy} fetch
	self shouldNotImplement.
	^ NULL!
*/
}

public boolean hasValue() {
throw new UnsupportedOperationException();/*
udanax-top.st:54046:GrandNodeStepper methodsFor: 'operations'!
{BooleanVar} hasValue
	overflowStepper ~~ NULL
		ifTrue: [ ^ overflowStepper hasValue ]
		ifFalse: [ ^ pageStepper ~~ NULL and: [pageStepper hasValue] ]!
*/
}

public void step() {
throw new UnsupportedOperationException();/*
udanax-top.st:54051:GrandNodeStepper methodsFor: 'operations'!
{void} step
	overflowStepper ~~ NULL
		ifTrue: [ overflowStepper step ]
		ifFalse:
			[pageStepper step.
			pageStepper hasValue ifFalse:
				[pageStepper destroy.
				pageStepper _ NULL.
				pageIndex _ pageIndex + 1.
				self verifyEntry]]!
*/
}

public Stepper copy() {
throw new UnsupportedOperationException();/*
udanax-top.st:54064:GrandNodeStepper methodsFor: 'create'!
{Stepper} copy
	^ GrandNodeStepper create: node with: pageStepper with: pageIndex with: overflowStepper!
*/
}

public  GrandNodeStepper(GrandNode aNode) {
throw new UnsupportedOperationException();/*
udanax-top.st:54067:GrandNodeStepper methodsFor: 'create'!
create: aNode {GrandNode}
	super create.
	node _ aNode.
	pageIndex _ IntegerVar0.
	pageStepper _ NULL.
	overflowStepper _ NULL.
	self verifyEntry.!
*/
}
}
