/*
 * Abora-Gold
 * Part of the Abora hypertext project: http://www.abora.org
 * Copyright 2003 David G Jones
 * 
 * Translated from Udanax-Gold source code: http://www.udanax.com
 * Copyright 1979-1999 Udanax.com. All rights reserved
 */
package org.abora.gold.cxx.classx.stuff;

import org.abora.gold.collection.grand.GrandHashTable;
import org.abora.gold.collection.steppers.Stepper;
import org.abora.gold.collection.steppers.TableStepper;
import org.abora.gold.cxx.classx.stuff.GrandNodeStepper;
import org.abora.gold.java.missing.IntegerVar;
import org.abora.gold.spaces.basic.Position;
import org.abora.gold.xpp.basic.Heaper;


public class GrandHashTableStepper extends TableStepper {
	protected GrandHashTable table;
	protected GrandNodeStepper nodeStepper;
	protected IntegerVar nodeIndex;
/*
udanax-top.st:55659:
TableStepper subclass: #GrandHashTableStepper
	instanceVariableNames: '
		table {GrandHashTable}
		nodeStepper {GrandNodeStepper | NULL}
		nodeIndex {IntegerVar}'
	classVariableNames: ''
	poolDictionaries: ''
	category: 'Cxx-class-stuff'!
*/
/*
udanax-top.st:55666:
(GrandHashTableStepper getOrMakeCxxClassDescription)
	attributes: ((Set new) add: #CONCRETE; add: #NOT.A.TYPE; yourself)!
*/

public void verifyEntry() {
throw new UnsupportedOperationException();/*
udanax-top.st:55671:GrandHashTableStepper methodsFor: 'private: private'!
{void} verifyEntry
	[nodeIndex < table nodeCount and: [(table nodeAt: nodeIndex) isEmpty]]
		whileTrue:
			[nodeIndex _ nodeIndex + 1 ].
	nodeIndex < table nodeCount ifTrue:
		[nodeStepper _ GrandNodeStepper create: (table nodeAt: nodeIndex)]!
*/
}

public Heaper fetch() {
throw new UnsupportedOperationException();/*
udanax-top.st:55680:GrandHashTableStepper methodsFor: 'operations'!
{Heaper wimpy} fetch
	(nodeStepper ~~ NULL and: [nodeStepper hasValue])
		ifTrue: [^ nodeStepper entry value]
		ifFalse: [^NULL]!
*/
}

public boolean hasValue() {
throw new UnsupportedOperationException();/*
udanax-top.st:55685:GrandHashTableStepper methodsFor: 'operations'!
{BooleanVar} hasValue
	^ nodeStepper ~~ NULL!
*/
}

public void step() {
throw new UnsupportedOperationException();/*
udanax-top.st:55688:GrandHashTableStepper methodsFor: 'operations'!
{void} step
	nodeStepper step.
	nodeStepper hasValue ifFalse:
		[nodeStepper destroy.
		nodeStepper _ NULL.
		nodeIndex _ nodeIndex + 1.
		self verifyEntry]!
*/
}

public Position position() {
throw new UnsupportedOperationException();/*
udanax-top.st:55698:GrandHashTableStepper methodsFor: 'special'!
{Position} position
	^ (nodeStepper entry cast: GrandTableEntry) position!
*/
}

public Stepper copy() {
throw new UnsupportedOperationException();/*
udanax-top.st:55703:GrandHashTableStepper methodsFor: 'create'!
{Stepper} copy
	^ GrandHashTableStepper create: table with: nodeStepper with: nodeIndex!
*/
}

public  GrandHashTableStepper(GrandHashTable aTable) {
throw new UnsupportedOperationException();/*
udanax-top.st:55706:GrandHashTableStepper methodsFor: 'create'!
create: aTable {GrandHashTable}
	super create.
	table _ aTable.
	table moreSteppers.
	nodeIndex _ IntegerVar0.
	nodeStepper _ NULL.
	self verifyEntry!
*/
}

public  GrandHashTableStepper(GrandHashTable aTable, GrandNodeStepper aNodeStepper, IntegerVar aNodeIndex) {
throw new UnsupportedOperationException();/*
udanax-top.st:55716:GrandHashTableStepper methodsFor: 'protected: creation'!
create: aTable {GrandHashTable} with: aNodeStepper {GrandNodeStepper} with: aNodeIndex {IntegerVar}
	super create.
	table _ aTable.
	table moreSteppers.
	nodeStepper _ aNodeStepper.
	nodeIndex _ aNodeIndex.!
*/
}

public void destruct() {
throw new UnsupportedOperationException();/*
udanax-top.st:55723:GrandHashTableStepper methodsFor: 'protected: creation'!
{void} destruct
	nodeStepper ~~ NULL ifTrue: [ nodeStepper destroy ].
	table fewerSteppers.
	super destruct.!
*/
}
}
