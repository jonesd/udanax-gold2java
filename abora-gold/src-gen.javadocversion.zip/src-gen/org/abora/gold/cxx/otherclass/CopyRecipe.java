/*
 * Abora-Gold
 * Part of the Abora hypertext project: http://www.abora.org
 * Copyright 2003 David G Jones
 * 
 * Translated from Udanax-Gold source code: http://www.udanax.com
 * Copyright 1979-1999 Udanax.com. All rights reserved
 */
package org.abora.gold.cxx.otherclass;

import org.abora.gold.java.missing.VoidStar;
import org.abora.gold.xcvr.Rcvr;
import org.abora.gold.xcvr.Recipe;
import org.abora.gold.xcvr.SpecialistRcvr;
import org.abora.gold.xpp.basic.Category;
import org.abora.gold.xpp.basic.Heaper;


public class CopyRecipe extends Recipe {
/*
udanax-top.st:41933:
Recipe subclass: #CopyRecipe
	instanceVariableNames: ''
	classVariableNames: ''
	poolDictionaries: ''
	category: 'Cxx-OtherClass'!
*/
/*
udanax-top.st:41937:
(CopyRecipe getOrMakeCxxClassDescription)
	attributes: ((Set new) add: #DEFERRED; yourself)!
*/

/**
 * create a new object from the information in the transceiver
 */
public Heaper parse(SpecialistRcvr rcvr) {
throw new UnsupportedOperationException();/*
udanax-top.st:41942:CopyRecipe methodsFor: 'accessing'!
{Heaper} parse: rcvr {SpecialistRcvr}
	"create a new object from the information in the transceiver"
	| result {void star} |	
	
	' 
	result = Heaper::operator new (0, xcsj, this->categoryOfDish());' translateOnly.
	
	[result _ DeletedHeaper create] smalltalkOnly.
	
	rcvr registerIbid: (result basicCast: Heaper).
	self parse: rcvr into: result.
	^ result basicCast: Heaper.!
*/
}

/**
 * create a new object from the information in the rcvr and give it the identity
 * of memory. The c++ version of this builds the first object received into the
 * area of supplied memory.
 */
public void parseInto(Rcvr rcvr, VoidStar memory) {
throw new UnsupportedOperationException();/*
udanax-top.st:41956:CopyRecipe methodsFor: 'accessing'!
{void} parse: rcvr {Rcvr} into: memory {void star} 
	"create a new object from the information in the rcvr and give it the identity 
	of memory. The c++ version of this builds the first object received into the 
	area of supplied memory."
	
	self subclassResponsibility!
*/
}

/**
 * cuisine points to the *variable* in which the receiver should be registered.
 */
public  CopyRecipe(Category cat, Recipe cuisine) {
	super(cat, cuisine);
throw new UnsupportedOperationException();/*
udanax-top.st:41965:CopyRecipe methodsFor: 'protected: creation'!
create: cat {Category} with: cuisine {Recipe star vector}
	"cuisine points to the *variable* in which the receiver should be registered."
	
	super create: cat with: cuisine!
*/
}
}
