/*
 * Abora-Gold
 * Part of the Abora hypertext project: http://www.abora.org
 * Copyright 2003 David G Jones
 * 
 * Translated from Udanax-Gold source code: http://www.udanax.com
 * Copyright 1979-1999 Udanax.com. All rights reserved
 */
package org.abora.gold.be.canopy.prop;

import java.io.PrintWriter;
import org.abora.gold.be.canopy.prop.Prop;
import org.abora.gold.be.canopy.prop.SensorProp;
import org.abora.gold.filter.Filter;
import org.abora.gold.id.IDRegion;
import org.abora.gold.java.missing.PropJoint;
import org.abora.gold.spaces.cross.CrossRegion;
import org.abora.gold.xcvr.Rcvr;
import org.abora.gold.xcvr.Xmtr;
import org.abora.gold.xpp.basic.Heaper;


/**
 * The properties which are nevigable towards using the Sensor Canopy.  The permissions and
 * endorsements are those whose changes may affect the triggering of the recorders that
 * decorate the canopy.  myPartialFlag is a property of the o-leaf-stuff which are at the
 * leaves of the Sensor Canopy.
 */
public class SensorProp extends Prop {
	protected IDRegion myRelevantPermissions;
	protected CrossRegion myRelevantEndorsements;
	protected boolean myPartialFlag;
	protected static SensorProp TheIdentitySensorProp;
	protected static SensorProp ThePartialSensorProp;
/*
udanax-top.st:38392:
Prop subclass: #SensorProp
	instanceVariableNames: '
		myRelevantPermissions {IDRegion}
		myRelevantEndorsements {CrossRegion of: IDRegion and: IDRegion}
		myPartialFlag {BooleanVar}'
	classVariableNames: '
		TheIdentitySensorProp {SensorProp} 
		ThePartialSensorProp {SensorProp} '
	poolDictionaries: ''
	category: 'Xanadu-Be-Canopy-Prop'!
*/
/*
udanax-top.st:38401:
SensorProp comment:
'The properties which are nevigable towards using the Sensor Canopy.  The permissions and endorsements are those whose changes may affect the triggering of the recorders that decorate the canopy.  myPartialFlag is a property of the o-leaf-stuff which are at the leaves of the Sensor Canopy.'!
*/
/*
udanax-top.st:38403:
(SensorProp getOrMakeCxxClassDescription)
	attributes: ((Set new) add: #CONCRETE; add: #COPY; yourself)!
*/
/*
udanax-top.st:38507:
SensorProp class
	instanceVariableNames: ''!
*/
/*
udanax-top.st:38510:
(SensorProp getOrMakeCxxClassDescription)
	attributes: ((Set new) add: #CONCRETE; add: #COPY; yourself)!
*/

public  SensorProp(IDRegion relevantPermissions, CrossRegion relevantEndorsements, boolean isPartial) {
throw new UnsupportedOperationException();/*
udanax-top.st:38408:SensorProp methodsFor: 'creation'!
create: relevantPermissions {IDRegion} 
	with: relevantEndorsements {CrossRegion of: IDRegion and: IDRegion} 
	with: isPartial {BooleanVar}
	
	super create.
	myRelevantPermissions _ relevantPermissions.
	myRelevantEndorsements _ relevantEndorsements.
	myPartialFlag _ isPartial.!
*/
}

public int flags() {
throw new UnsupportedOperationException();/*
udanax-top.st:38419:SensorProp methodsFor: 'accessing'!
{UInt32} flags
	^SensorCrum flagsFor: myRelevantPermissions
		with: myRelevantEndorsements
		with: myPartialFlag!
*/
}

public boolean isPartial() {
throw new UnsupportedOperationException();/*
udanax-top.st:38425:SensorProp methodsFor: 'accessing'!
{BooleanVar} isPartial
	^myPartialFlag!
*/
}

public CrossRegion relevantEndorsements() {
throw new UnsupportedOperationException();/*
udanax-top.st:38428:SensorProp methodsFor: 'accessing'!
{CrossRegion} relevantEndorsements
	^myRelevantEndorsements!
*/
}

public IDRegion relevantPermissions() {
throw new UnsupportedOperationException();/*
udanax-top.st:38432:SensorProp methodsFor: 'accessing'!
{IDRegion} relevantPermissions
	^myRelevantPermissions!
*/
}

public Prop with(Prop other) {
throw new UnsupportedOperationException();/*
udanax-top.st:38436:SensorProp methodsFor: 'accessing'!
{Prop} with: other {Prop}
	
	other cast: SensorProp into: [ :o |
		^SensorProp make: ((myRelevantPermissions
				unionWith: o relevantPermissions) cast: IDRegion)
			with: ((myRelevantEndorsements
				unionWith: o relevantEndorsements) cast: CrossRegion)
			with: (myPartialFlag or: [o isPartial])].
	^ NULL "compiler fodder"!
*/
}

public int actualHashForEqual() {
throw new UnsupportedOperationException();/*
udanax-top.st:38448:SensorProp methodsFor: 'testing'!
{UInt32} actualHashForEqual
	^myRelevantPermissions hashForEqual
		bitXor: myRelevantEndorsements hashForEqual!
*/
}

public boolean isEqual(Heaper heaper) {
throw new UnsupportedOperationException();/*
udanax-top.st:38453:SensorProp methodsFor: 'testing'!
{BooleanVar} isEqual: heaper {Heaper}
	heaper
		cast: SensorProp into: [ :prop |
			^(myRelevantEndorsements isEqual: prop relevantEndorsements)
				and: [(myRelevantPermissions isEqual: prop relevantPermissions)
				and: [myPartialFlag == prop isPartial]]]
		others:
			[^false].
	^ false "compiler fodder"!
*/
}

public void printOn(PrintWriter oo) {
throw new UnsupportedOperationException();/*
udanax-top.st:38466:SensorProp methodsFor: 'printing'!
{void} printOn: oo {ostream reference}
	oo << 'SensorProp(P: ' << myRelevantPermissions
		<< '; E: ' << myRelevantEndorsements.
	myPartialFlag ifTrue: [oo << '; partial'].
	oo << ')'!
*/
}

public Filter endorsementsFilter() {
throw new UnsupportedOperationException();/*
udanax-top.st:38475:SensorProp methodsFor: 'smalltalk: passe'!
{Filter of: (XuRegion of: ID)} endorsementsFilter
	self passe!
*/
}

public Filter permissionsFilter() {
throw new UnsupportedOperationException();/*
udanax-top.st:38479:SensorProp methodsFor: 'smalltalk: passe'!
{Filter of: (XuRegion of: ID)} permissionsFilter
	self passe!
*/
}

public PropJoint joint() {
throw new UnsupportedOperationException();/*
udanax-top.st:38485:SensorProp methodsFor: 'smalltalk: suspended'!
{PropJoint} joint
	Ravi thingToDo. "implement proper simpleRegions so we can use simpleUnion"
	^SensorPropJoint make: (myRelevantPermissions "asSimpleRegion" cast: IDRegion)
		with: (myRelevantEndorsements "asSimpleRegion" cast: CrossRegion)
		with: myPartialFlag!
*/
}

public  SensorProp(Rcvr receiver) {
throw new UnsupportedOperationException();/*
udanax-top.st:38494:SensorProp methodsFor: 'generated:'!
create.Rcvr: receiver {Rcvr}
	super create.Rcvr: receiver.
	myRelevantPermissions _ receiver receiveHeaper.
	myRelevantEndorsements _ receiver receiveHeaper.
	myPartialFlag _ receiver receiveBooleanVar.!
*/
}

public void sendSelfTo(Xmtr xmtr) {
throw new UnsupportedOperationException();/*
udanax-top.st:38500:SensorProp methodsFor: 'generated:'!
{void} sendSelfTo: xmtr {Xmtr}
	super sendSelfTo: xmtr.
	xmtr sendHeaper: myRelevantPermissions.
	xmtr sendHeaper: myRelevantEndorsements.
	xmtr sendBooleanVar: myPartialFlag.!
*/
}

/**
 * returns an empty SensorProp
 */
public static Heaper make() {
throw new UnsupportedOperationException();/*
udanax-top.st:38515:SensorProp class methodsFor: 'creation'!
make
	"returns an empty SensorProp"
	
	TheIdentitySensorProp == NULL ifTrue:
		[TheIdentitySensorProp := self
			create: (CurrentGrandMap fluidGet globalIDSpace emptyRegion cast: IDRegion)
			with: (CurrentGrandMap fluidGet endorsementSpace emptyRegion cast: CrossRegion)
			with: false].
	^TheIdentitySensorProp!
*/
}

public static Heaper make(IDRegion relevantPermissions, CrossRegion relevantEndorsements, boolean isPartial) {
throw new UnsupportedOperationException();/*
udanax-top.st:38525:SensorProp class methodsFor: 'creation'!
make: relevantPermissions {IDRegion} 
	with: relevantEndorsements {CrossRegion} 
	with: isPartial {BooleanVar}
	^self create: relevantPermissions with: relevantEndorsements with: isPartial!
*/
}

/**
 * returns an empty SensorProp with the partial flag on
 */
public static SensorProp partial() {
throw new UnsupportedOperationException();/*
udanax-top.st:38531:SensorProp class methodsFor: 'creation'!
{SensorProp} partial
	"returns an empty SensorProp with the partial flag on"
	ThePartialSensorProp == NULL ifTrue:
		[ThePartialSensorProp := self
			create: (CurrentGrandMap fluidGet globalIDSpace emptyRegion cast: IDRegion)
			with: (CurrentGrandMap fluidGet endorsementSpace emptyRegion cast: CrossRegion)
			with: true].
	^ThePartialSensorProp!
*/
}

public static void linkTimeNonInherited() {
throw new UnsupportedOperationException();/*
udanax-top.st:38543:SensorProp class methodsFor: 'smalltalk: initialization'!
linkTimeNonInherited
	TheIdentitySensorProp _ NULL.
	ThePartialSensorProp _ NULL.!
*/
}
}
