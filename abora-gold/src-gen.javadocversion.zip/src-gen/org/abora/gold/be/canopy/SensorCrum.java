/*
 * Abora-Gold
 * Part of the Abora hypertext project: http://www.abora.org
 * Copyright 2003 David G Jones
 * 
 * Translated from Udanax-Gold source code: http://www.udanax.com
 * Copyright 1979-1999 Udanax.com. All rights reserved
 */
package org.abora.gold.be.canopy;

import org.abora.gold.be.basic.BeEdition;
import org.abora.gold.be.canopy.CanopyCache;
import org.abora.gold.be.canopy.CanopyCrum;
import org.abora.gold.be.canopy.PropFinder;
import org.abora.gold.be.canopy.SensorCrum;
import org.abora.gold.collection.sets.ImmuSet;
import org.abora.gold.fossil.RecorderFossil;
import org.abora.gold.id.IDRegion;
import org.abora.gold.java.missing.Stamp;
import org.abora.gold.props.PropChange;
import org.abora.gold.spaces.cross.CrossRegion;
import org.abora.gold.turtle.AgendaItem;
import org.abora.gold.xcvr.Rcvr;
import org.abora.gold.xcvr.Xmtr;
import org.abora.gold.xpp.basic.Heaper;


/**
 * This implementation is the same as BertCrums.  This will require
 * pointers into the ent to implement delete (for archiving).  Canopy
 * reorganization could be achieved by removing several orgls, then
 * re-adding them (archive then restore).
 */
public class SensorCrum extends CanopyCrum {
	protected ImmuSet myBackfollowRecorders;
/*
udanax-top.st:5277:
CanopyCrum subclass: #SensorCrum
	instanceVariableNames: 'myBackfollowRecorders {ImmuSet of: RecorderFossil}'
	classVariableNames: ''
	poolDictionaries: ''
	category: 'Xanadu-Be-Canopy'!
*/
/*
udanax-top.st:5281:
SensorCrum comment:
'This implementation is the same as BertCrums.  This will require 
pointers into the ent to implement delete (for archiving).  Canopy 
reorganization could be achieved by removing several orgls, then 
re-adding them (archive then restore).'!
*/
/*
udanax-top.st:5286:
(SensorCrum getOrMakeCxxClassDescription)
	friends:
'friend class RecorderHoister;
';
	attributes: ((Set new) add: #LOCKED; add: #COPY; add: #SHEPHERD.PATRIARCH; add: #CONCRETE; yourself)!
*/
/*
udanax-top.st:5539:
SensorCrum class
	instanceVariableNames: ''!
*/
/*
udanax-top.st:5542:
(SensorCrum getOrMakeCxxClassDescription)
	friends:
'friend class RecorderHoister;
';
	attributes: ((Set new) add: #LOCKED; add: #COPY; add: #SHEPHERD.PATRIARCH; add: #CONCRETE; yourself)!
*/

/**
 * Make a canopyCrum for a root:  it has no children.
 */
public  SensorCrum() {
	super(0);
throw new UnsupportedOperationException();/*
udanax-top.st:5294:SensorCrum methodsFor: 'private: creation'!
create
	"Make a canopyCrum for a root:  it has no children."
	super create: UInt32Zero.
	myBackfollowRecorders _ ImmuSet make.
	self newShepherd!
*/
}

/**
 * Make a canopyCrum for a root:  it has no children.
 */
public  SensorCrum(int flags) {
	super(flags);
throw new UnsupportedOperationException();/*
udanax-top.st:5300:SensorCrum methodsFor: 'private: creation'!
create: flags {UInt32}
	"Make a canopyCrum for a root:  it has no children."
	super create: flags.
	myBackfollowRecorders _ ImmuSet make.
	self newShepherd!
*/
}

/**
 * SensorCrum create verify2.
 */
public CanopyCrum another() {
throw new UnsupportedOperationException();/*
udanax-top.st:5309:SensorCrum methodsFor: 'smalltalk:'!
{CanopyCrum} another
	"SensorCrum create verify2."
	^SensorCrum create!
*/
}

public String displayString() {
throw new UnsupportedOperationException();/*
udanax-top.st:5314:SensorCrum methodsFor: 'smalltalk:'!
displayString
	^String
		streamContents: 
			[:aStream | 
			aStream print: self maxHeight.
			self maxHeight == self minHeight 
				ifFalse: [aStream nextPut: $-; print: self minHeight]]!
*/
}

public void inspectMenuArray() {
throw new UnsupportedOperationException();/*
udanax-top.st:5322:SensorCrum methodsFor: 'smalltalk:'!
inspectMenuArray
	^#(
		('inspect oparts'	inspectOParts		''))!
*/
}

public void inspectOParts() {
throw new UnsupportedOperationException();/*
udanax-top.st:5326:SensorCrum methodsFor: 'smalltalk:'!
inspectOParts
	| owners |
	owners _ self allOwners select: [ :each | each isKindOf: OPart].
	owners isEmpty ifTrue:
		[Transcript show: 'Nobody'; cr]
	ifFalse: [owners size = 1 ifTrue:
		[owners first inspect]
	ifFalse:
		[owners inspect]]!
*/
}

public void printOn(Object aStream) {
throw new UnsupportedOperationException();/*
udanax-top.st:5336:SensorCrum methodsFor: 'smalltalk:'!
{void} printOn: aStream 
	[myBackfollowRecorders == nil ifTrue: [
		aStream << self getCategory name << '(nil)'. ^ VOID]] smalltalkOnly.
		
	aStream << self getCategory name << '(' << (self flags printStringRadix: 2) << ')'.
	myBackfollowRecorders isEmpty ifFalse:
		[aStream << ' *']!
*/
}

/**
 * should have one per Ent
 */
public CanopyCache canopyCache() {
throw new UnsupportedOperationException();/*
udanax-top.st:5346:SensorCrum methodsFor: 'protected:'!
{CanopyCache wimpy} canopyCache
	"should have one per Ent"
	^CurrentSensorCanopyCache fluidGet!
*/
}

public CanopyCrum makeNew() {
throw new UnsupportedOperationException();/*
udanax-top.st:5350:SensorCrum methodsFor: 'protected:'!
{CanopyCrum} makeNew
	Dean thingToDo. "is this right? I want to preserve the partiality flag when a partial loaf splits /ravi/5/7/92/"
	self isPartial ifTrue:
		[^SensorCrum create: SensorCrum isPartialFlag]
	ifFalse:
		[^SensorCrum create]!
*/
}

/**
 * Set off all recorders that respond to the change either in me or in any of my ancestors up
 * to but not including sCrum
 * (If I am the same as sCrum, skip me as well.)
 * (If sCrum is null, search through all my ancestors to a root of the sensor canopy.)
 * return simplest finder for looking at children
 */
public PropFinder checkRecorders(PropFinder finder, SensorCrum scrum) {
throw new UnsupportedOperationException();/*
udanax-top.st:5360:SensorCrum methodsFor: 'accessing'!
{PropFinder} checkRecorders: finder {PropFinder} 
	with: scrum {SensorCrum | NULL} 
	
	"Set off all recorders that respond to the change either in me or in any of my ancestors up to but not including sCrum
	(If I am the same as sCrum, skip me as well.)
	(If sCrum is null, search through all my ancestors to a root of the sensor canopy.)
	return simplest finder for looking at children"
	
	| next {SensorCrum | NULL} |
	
	"from self rootward until told to stop (at sCrum or the root)
		trigger any matching recorders
	return a simplified finder for examining children."
	
	next := self.
	[next ~~ NULL] whileTrue:
		[next := next fetchNextAfterTriggeringRecorders: finder with: scrum].
	^finder pass: self!
*/
}

/**
 * Set off all recorders in me that respond to the change, if appropriate
 * (If I am the same as sCrum, skip me.)
 * If sCrum is null or not me, return my parent so caller can iterate through my ancestors to
 * sCrum or a root.
 */
public SensorCrum fetchNextAfterTriggeringRecorders(PropFinder finder, SensorCrum sCrum) {
throw new UnsupportedOperationException();/*
udanax-top.st:5379:SensorCrum methodsFor: 'accessing'!
{SensorCrum | NULL} fetchNextAfterTriggeringRecorders: finder {PropFinder} 
	with: sCrum {SensorCrum | NULL}
	
	"Set off all recorders in me that respond to the change, if appropriate
	(If I am the same as sCrum, skip me.)
	If sCrum is null or not me, return my parent so caller can iterate through my ancestors to sCrum or a root."
	
	|  |
	
	"One step of the leafward walk of the O-plane, triggering recorders:
	Walk rootward on the sensor canopy, where many steps may correspond to this single leafward step."
	
	"If we're the designated sCrum (where this work was already done)
	 	return without doing anything.  We're done.
	For each of our recorders
		if it hasn't gone extinct
			reanimate it long enough to
				trigger it, recording stamp if finder matches.
	Return a pointer to our parent (so caller can iterate this operation rootward)."
	
	(sCrum ~~ NULL and: [self isEqual: sCrum]) ifTrue:
		[^NULL].
	myBackfollowRecorders stepper forEach: [ :fossil {RecorderFossil} |
		fossil isExtinct ifFalse:
			[fossil reanimate: [:recorder {ResultRecorder} |
				recorder triggerIfMatching: finder with: fossil]]].
	^self fetchParent cast: SensorCrum.!
*/
}

public boolean isPartial() {
throw new UnsupportedOperationException();/*
udanax-top.st:5407:SensorCrum methodsFor: 'accessing'!
{BooleanVar} isPartial
	^(self flags bitAnd: SensorCrum isPartialFlag) ~= UInt32Zero!
*/
}

public ImmuSet recorders() {
throw new UnsupportedOperationException();/*
udanax-top.st:5411:SensorCrum methodsFor: 'accessing'!
{ImmuSet of: RecorderFossil} recorders
	^myBackfollowRecorders!
*/
}

/**
 * NOTE: The AgendaItem returned is not yet scheduled.  Doing so is up to my caller.
 */
public AgendaItem recordingAgent(RecorderFossil recorder) {
throw new UnsupportedOperationException();/*
udanax-top.st:5414:SensorCrum methodsFor: 'accessing'!
{AgendaItem} recordingAgent: recorder {RecorderFossil}
	"NOTE: The AgendaItem returned is not yet scheduled.  Doing so is up to my caller."
	
	|  |
	
	"If the recorder we're adding isn't already present here
		pack up the fossil for shipment to the hoister
		atomically
			Install the recorder here
			return a RecorderHoister to propagate the side-effects and anneal the canopy
			(The RecorderHoister will update myFlags)
	return an empty agenda (to satisfy our contract)"
	
	(myBackfollowRecorders hasMember: recorder) ifFalse:
		[ | cargo {ImmuSet of: RecorderFossil} |
		cargo := ImmuSet make with: recorder.
		DiskManager consistent: 2 with:
			[self installRecorders: cargo.
			self diskUpdate.
			^RecorderHoister make: self with: cargo]].
	^Agenda make!
*/
}

/**
 * Remove recorders because they have migrated rootward.
 * Recalculate myOwnFlags and myFlags.
 */
public void removeRecorders(ImmuSet recorders) {
throw new UnsupportedOperationException();/*
udanax-top.st:5436:SensorCrum methodsFor: 'accessing'!
{void} removeRecorders: recorders {ImmuSet of: RecorderFossil}
	"Remove recorders because they have migrated rootward.
	Recalculate myOwnFlags and myFlags."
	
	| f {UInt32} |
	myBackfollowRecorders _ myBackfollowRecorders minus: recorders.
	self diskUpdate.
	f := UInt32Zero.
	myBackfollowRecorders stepper forEach: [ :fossil {RecorderFossil} |
		fossil isExtinct ifFalse:
			[fossil reanimate: [:recorder {ResultRecorder} |
				f := f bitOr: recorder sensorProp flags]]].
	self setOwnFlags: f.
	self changeCanopy!
*/
}

/**
 * Installs the recorders in my set and updates myOwnProp accordingly.
 * The caller has already checked that none of these recorders are already installed here.
 * The caller also handles updating myFlags.
 * The caller also handles all issues of rootward propagation of these changes.
 * The caller also does the 'diskUpdate'.
 * This is a separate method because it's called once by the code that installs a new
 * recorder, and again by the code that recursively hoists recurders up the canopy.
 * add the new recorders to my set
 * for each new recorder
 * if it hasn't gone extinct
 * extract its properties
 * union them into my own
 */
public void installRecorders(ImmuSet recorders) {
throw new UnsupportedOperationException();/*
udanax-top.st:5453:SensorCrum methodsFor: 'private:'!
{void} installRecorders: recorders {ImmuSet of: RecorderFossil}
	"Installs the recorders in my set and updates myOwnProp accordingly.
	The caller has already checked that none of these recorders are already installed here.
	The caller also handles updating myFlags.
	The caller also handles all issues of rootward propagation of these changes.
	The caller also does the 'diskUpdate'.
	
	This is a separate method because it's called once by the code that installs a new recorder, and again by the code that recursively hoists recurders up the canopy.
	
	add the new recorders to my set
	for each new recorder
		if it hasn't gone extinct
			extract its properties
			union them into my own"
	myBackfollowRecorders _ myBackfollowRecorders unionWith: recorders.
	recorders stepper forEach: [ :fossil {RecorderFossil} |
		fossil isExtinct ifFalse: [ | prop {Prop} |
			fossil reanimate: [:recorder {ResultRecorder} |
				prop := recorder sensorProp].
			self setOwnFlags: (self ownFlags bitOr: prop flags)]]!
*/
}

public CanopyCrum makeNewParent(CanopyCrum first, CanopyCrum second) {
throw new UnsupportedOperationException();/*
udanax-top.st:5477:SensorCrum methodsFor: 'protected'!
{CanopyCrum} makeNewParent: first {CanopyCrum} with: second {CanopyCrum}
	DiskManager consistent: 3 with:
		[^SensorCrum create: (first cast: SensorCrum)
	 		with: (second cast: SensorCrum)]!
*/
}

public PropFinder checkRecorders(BeEdition stamp, PropFinder finder, SensorCrum sCrum) {
throw new UnsupportedOperationException();/*
udanax-top.st:5485:SensorCrum methodsFor: 'smalltalk: passe'!
{PropFinder} checkRecorders: stamp {BeEdition} 
	with: finder {PropFinder} 
	with: sCrum {SensorCrum | NULL}
	
self passe "fewer args"!
*/
}

public SensorCrum fetchNextAfterTriggeringRecorders(BeEdition stamp, PropFinder finder, SensorCrum sCrum) {
throw new UnsupportedOperationException();/*
udanax-top.st:5491:SensorCrum methodsFor: 'smalltalk: passe'!
{SensorCrum | NULL} fetchNextAfterTriggeringRecorders: stamp {BeEdition} 
	with: finder {PropFinder} 
	with: sCrum {SensorCrum | NULL}
	
	self passe "fewer args"!
*/
}

public void record(RecorderFossil recorder) {
throw new UnsupportedOperationException();/*
udanax-top.st:5497:SensorCrum methodsFor: 'smalltalk: passe'!
{void} record: recorder {RecorderFossil}
	
	self passe. "equivalent to '(self recordingAgent: recorder) schedule"!
*/
}

public void triggerRecorders(Stamp stamp, PropFinder finder, SensorCrum sCrum) {
throw new UnsupportedOperationException();/*
udanax-top.st:5501:SensorCrum methodsFor: 'smalltalk: passe'!
{void} triggerRecorders: stamp {Stamp} 
	with: finder {PropFinder} 
	with: sCrum {SensorCrum | NULL}
	
	self passe.	"Use fetchNextAfterTriggeringRecorders:with:with:"!
*/
}

/**
 * Create a new parent for two SensorCrums.
 * This constructor just makes a new parent whose properties are empty. My client must bring
 * my properties up to date.
 */
public  SensorCrum(SensorCrum first, SensorCrum second) {
	super(0, first, second);
throw new UnsupportedOperationException();/*
udanax-top.st:5509:SensorCrum methodsFor: 'instance creation'!
create: first {SensorCrum} with: second {SensorCrum}
	"Create a new parent for two SensorCrums.
	This constructor just makes a new parent whose properties are empty. My client must bring my properties up to date."
	| |
	"Have the super do the basic creation."
	
	super create: UInt32Zero with: first with: second.
	self newShepherd.
	myBackfollowRecorders _ ImmuSet make.
	self canopyCache updateCache: self fetchChild1 forParent: self.
	self canopyCache updateCache: self fetchChild2 forParent: self!
*/
}

public void changeCanopy(Object f) {
throw new UnsupportedOperationException();/*
udanax-top.st:5523:SensorCrum methodsFor: 'smalltalk: suspended'!
changeCanopy: f!
*/
}

public PropChange fullChange() {
throw new UnsupportedOperationException();/*
udanax-top.st:5525:SensorCrum methodsFor: 'smalltalk: suspended'!
{PropChange} fullChange
	^PropChange sensorPropChange!
*/
}

public  SensorCrum(Rcvr receiver) {
	super(receiver);
throw new UnsupportedOperationException();/*
udanax-top.st:5530:SensorCrum methodsFor: 'generated:'!
create.Rcvr: receiver {Rcvr}
	super create.Rcvr: receiver.
	myBackfollowRecorders _ receiver receiveHeaper.!
*/
}

public void sendSelfTo(Xmtr xmtr) {
throw new UnsupportedOperationException();/*
udanax-top.st:5534:SensorCrum methodsFor: 'generated:'!
{void} sendSelfTo: xmtr {Xmtr}
	super sendSelfTo: xmtr.
	xmtr sendHeaper: myBackfollowRecorders.!
*/
}

public static void staticTimeNonInherited() {
throw new UnsupportedOperationException();/*
udanax-top.st:5550:SensorCrum class methodsFor: 'smalltalk: init'!
staticTimeNonInherited
	
	CanopyCache defineFluid: #CurrentSensorCanopyCache with: DiskManager emulsion with: [CanopyCache make]!
*/
}

public static Heaper make() {
throw new UnsupportedOperationException();/*
udanax-top.st:5556:SensorCrum class methodsFor: 'pseudo constructors'!
make
	DiskManager consistent: 2 with: [
		^SensorCrum create]!
*/
}

public static SensorCrum partial() {
throw new UnsupportedOperationException();/*
udanax-top.st:5560:SensorCrum class methodsFor: 'pseudo constructors'!
{SensorCrum} partial
	DiskManager consistent: 1 with: [
		^SensorCrum create: SensorCrum isPartialFlag]!
*/
}

/**
 * The flag word corresponding to the given props
 */
public static int flagsFor(IDRegion permissions, CrossRegion endorsements, boolean isPartial) {
throw new UnsupportedOperationException();/*
udanax-top.st:5566:SensorCrum class methodsFor: 'flags'!
{UInt32} flagsFor: permissions {IDRegion | NULL}
	with: endorsements {CrossRegion | NULL}
	with: isPartial {BooleanVar}
	"The flag word corresponding to the given props"
	
	| result {UInt32} |
	result := UInt32Zero.
	permissions ~~ NULL ifTrue:
		[result := result bitOr: (CanopyCrum permissionsFlags: permissions)].
	endorsements ~~ NULL ifTrue:
		[result := result bitOr: (CanopyCrum endorsementsFlags: endorsements)].
	isPartial ifTrue:
		[result := result bitOr: self isPartialFlag].
	^result!
*/
}

/**
 * Flag bit for existence of partiality
 */
public static int isPartialFlag() {
throw new UnsupportedOperationException();/*
udanax-top.st:5581:SensorCrum class methodsFor: 'flags'!
{UInt32 constFn} isPartialFlag
	"Flag bit for existence of partiality" 
	^16r08000000!
*/
}
}
