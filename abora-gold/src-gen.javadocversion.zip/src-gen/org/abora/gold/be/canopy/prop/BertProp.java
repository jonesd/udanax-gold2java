/*
 * Abora-Gold
 * Part of the Abora hypertext project: http://www.abora.org
 * Copyright 2003 David G Jones
 * 
 * Translated from Udanax-Gold source code: http://www.udanax.com
 * Copyright 1979-1999 Udanax.com. All rights reserved
 */
package org.abora.gold.be.canopy.prop;

import java.io.PrintWriter;
import org.abora.gold.be.canopy.prop.BertProp;
import org.abora.gold.be.canopy.prop.Prop;
import org.abora.gold.java.missing.PropJoint;
import org.abora.gold.spaces.basic.XnRegion;
import org.abora.gold.spaces.cross.CrossRegion;
import org.abora.gold.xcvr.Rcvr;
import org.abora.gold.xcvr.Xmtr;
import org.abora.gold.xpp.basic.Heaper;


/**
 * The properties which are nevigable towards using the Bert Canopy.  All of these are
 * properties of the Stamps at the leaves of the Bert Canopy.
 */
public class BertProp extends Prop {
	protected XnRegion myPermissions;
	protected XnRegion myEndorsements;
	protected boolean mySensorWaitingFlag;
	protected boolean myCannotPartializeFlag;
	protected static BertProp TheIdentityBertProp;
/*
udanax-top.st:38217:
Prop subclass: #BertProp
	instanceVariableNames: '
		myPermissions {XnRegion of: ID}
		myEndorsements {XnRegion of: ID}
		mySensorWaitingFlag {BooleanVar}
		myCannotPartializeFlag {BooleanVar}'
	classVariableNames: 'TheIdentityBertProp {BertProp} '
	poolDictionaries: ''
	category: 'Xanadu-Be-Canopy-Prop'!
*/
/*
udanax-top.st:38225:
BertProp comment:
'The properties which are nevigable towards using the Bert Canopy.  All of these are properties of the Stamps at the leaves of the Bert Canopy.'!
*/
/*
udanax-top.st:38227:
(BertProp getOrMakeCxxClassDescription)
	attributes: ((Set new) add: #CONCRETE; add: #COPY; yourself)!
*/
/*
udanax-top.st:38327:
BertProp class
	instanceVariableNames: ''!
*/
/*
udanax-top.st:38330:
(BertProp getOrMakeCxxClassDescription)
	attributes: ((Set new) add: #CONCRETE; add: #COPY; yourself)!
*/

public CrossRegion endorsements() {
throw new UnsupportedOperationException();/*
udanax-top.st:38232:BertProp methodsFor: 'accessing'!
{CrossRegion} endorsements
	^myEndorsements cast: CrossRegion!
*/
}

public int flags() {
throw new UnsupportedOperationException();/*
udanax-top.st:38235:BertProp methodsFor: 'accessing'!
{UInt32} flags
	^BertCrum flagsFor: (myPermissions cast: IDRegion)
		with: (myEndorsements cast: CrossRegion)
		with: myCannotPartializeFlag
		with: mySensorWaitingFlag!
*/
}

public boolean isNotPartializable() {
throw new UnsupportedOperationException();/*
udanax-top.st:38242:BertProp methodsFor: 'accessing'!
{BooleanVar} isNotPartializable
	^myCannotPartializeFlag!
*/
}

public boolean isSensorWaiting() {
throw new UnsupportedOperationException();/*
udanax-top.st:38245:BertProp methodsFor: 'accessing'!
{BooleanVar} isSensorWaiting
	^mySensorWaitingFlag!
*/
}

public XnRegion permissions() {
throw new UnsupportedOperationException();/*
udanax-top.st:38248:BertProp methodsFor: 'accessing'!
{XnRegion of: ID} permissions
	^myPermissions!
*/
}

public Prop with(Prop other) {
throw new UnsupportedOperationException();/*
udanax-top.st:38251:BertProp methodsFor: 'accessing'!
{Prop} with: other {Prop}
	| o {BertProp} |
	o _ other cast: BertProp.
	^BertProp make: (myPermissions unionWith: o permissions)
		with: (myEndorsements unionWith: o endorsements)
		with: (mySensorWaitingFlag or: [o isSensorWaiting])
		with: (myCannotPartializeFlag or: [o isNotPartializable])!
*/
}

public  BertProp(XnRegion permissions, XnRegion endorsements, boolean isSensorWaiting, boolean isNotPartializable) {
throw new UnsupportedOperationException();/*
udanax-top.st:38261:BertProp methodsFor: 'creation'!
create: permissions {XnRegion of: ID} 
	with: endorsements {XnRegion of: ID} 
	with: isSensorWaiting {BooleanVar} 
	with: isNotPartializable {BooleanVar}
	super create.
	myPermissions _ permissions.
	myEndorsements _ endorsements.
	mySensorWaitingFlag _ isSensorWaiting.
	myCannotPartializeFlag _ isNotPartializable.!
*/
}

public int actualHashForEqual() {
throw new UnsupportedOperationException();/*
udanax-top.st:38273:BertProp methodsFor: 'testing'!
{UInt32} actualHashForEqual
	^myPermissions hashForEqual bitXor: myEndorsements hashForEqual!
*/
}

/**
 * Does this do the right thing.
 */
public boolean isEmpty() {
throw new UnsupportedOperationException();/*
udanax-top.st:38276:BertProp methodsFor: 'testing'!
{BooleanVar} isEmpty
	"Does this do the right thing."
	
	self knownBug.
	^myEndorsements isEmpty and: [myPermissions isEmpty]!
*/
}

public boolean isEqual(Heaper other) {
throw new UnsupportedOperationException();/*
udanax-top.st:38282:BertProp methodsFor: 'testing'!
{BooleanVar} isEqual: other {Heaper}
	other
		cast: BertProp into: [:b |
			^(b endorsements isEqual: myEndorsements)
			 and: [(b permissions isEqual: myPermissions)
			 and: [b isSensorWaiting == mySensorWaitingFlag
			 and: [b isNotPartializable == myCannotPartializeFlag]]]]
		others: [^false].
	^ false "compiler fodder"!
*/
}

public void printOn(PrintWriter oo) {
throw new UnsupportedOperationException();/*
udanax-top.st:38295:BertProp methodsFor: 'printing'!
{void} printOn: oo {ostream reference}
	oo << self getCategory name << '(P: ' << myPermissions << '; E: ' << myEndorsements.
	mySensorWaitingFlag ifTrue: [oo << '; sensor'].
	myCannotPartializeFlag ifTrue: [oo << '; cannot partialize'].
	oo << ')'!
*/
}

public PropJoint joint() {
throw new UnsupportedOperationException();/*
udanax-top.st:38303:BertProp methodsFor: 'smalltalk: suspended'!
{PropJoint} joint
	^BertPropJoint
		make: (Joint make: myPermissions)
		with: (Joint make: myEndorsements)
		with: mySensorWaitingFlag
		with: myCannotPartializeFlag!
*/
}

public  BertProp(Rcvr receiver) {
throw new UnsupportedOperationException();/*
udanax-top.st:38312:BertProp methodsFor: 'generated:'!
create.Rcvr: receiver {Rcvr}
	super create.Rcvr: receiver.
	myPermissions _ receiver receiveHeaper.
	myEndorsements _ receiver receiveHeaper.
	mySensorWaitingFlag _ receiver receiveBooleanVar.
	myCannotPartializeFlag _ receiver receiveBooleanVar.!
*/
}

public void sendSelfTo(Xmtr xmtr) {
throw new UnsupportedOperationException();/*
udanax-top.st:38319:BertProp methodsFor: 'generated:'!
{void} sendSelfTo: xmtr {Xmtr}
	super sendSelfTo: xmtr.
	xmtr sendHeaper: myPermissions.
	xmtr sendHeaper: myEndorsements.
	xmtr sendBooleanVar: mySensorWaitingFlag.
	xmtr sendBooleanVar: myCannotPartializeFlag.!
*/
}

public static BertProp cannotPartializeProp() {
throw new UnsupportedOperationException();/*
udanax-top.st:38335:BertProp class methodsFor: 'creation'!
{BertProp} cannotPartializeProp
	[BeGrandMap] USES.
	^BertProp make: IDSpace global emptyRegion
		with: CurrentGrandMap fluidGet endorsementSpace emptyRegion
		with: false
		with: true!
*/
}

public static BertProp detectorWaitingProp() {
throw new UnsupportedOperationException();/*
udanax-top.st:38342:BertProp class methodsFor: 'creation'!
{BertProp} detectorWaitingProp
	^BertProp make: CurrentGrandMap fluidGet globalIDSpace emptyRegion
			with: CurrentGrandMap fluidGet endorsementSpace emptyRegion
			with: true
			with: false!
*/
}

public static BertProp endorsementsProp(XnRegion endorsements) {
throw new UnsupportedOperationException();/*
udanax-top.st:38349:BertProp class methodsFor: 'creation'!
{BertProp} endorsementsProp: endorsements {XnRegion}
	^BertProp make: IDSpace global emptyRegion
		with: endorsements
		with: false
		with: false!
*/
}

public static Heaper make() {
throw new UnsupportedOperationException();/*
udanax-top.st:38356:BertProp class methodsFor: 'creation'!
{BertProp} make
	TheIdentityBertProp == NULL ifTrue:
		[TheIdentityBertProp := BertProp make: IDSpace global emptyRegion
			with: CurrentGrandMap fluidGet endorsementSpace emptyRegion
			with: false
			with: false].
	^TheIdentityBertProp!
*/
}

public static Heaper make(XnRegion permissions, XnRegion endorsements, boolean isSensorWaiting, boolean isNotPartializable) {
throw new UnsupportedOperationException();/*
udanax-top.st:38365:BertProp class methodsFor: 'creation'!
make: permissions {XnRegion of: ID} 
	with: endorsements {XnRegion} 
	with: isSensorWaiting {BooleanVar} 
	with: isNotPartializable {BooleanVar} 
	^self
		create: permissions
		with: endorsements
		with: isSensorWaiting
		with: isNotPartializable!
*/
}

public static BertProp permissionsProp(XnRegion iDs) {
throw new UnsupportedOperationException();/*
udanax-top.st:38375:BertProp class methodsFor: 'creation'!
{BertProp} permissionsProp: iDs {XnRegion of: ID}
	^BertProp make: iDs
		with: CurrentGrandMap fluidGet endorsementSpace emptyRegion
		with: false
		with: false!
*/
}

public static void linkTimeNonInherited() {
throw new UnsupportedOperationException();/*
udanax-top.st:38383:BertProp class methodsFor: 'smalltalk: initialization'!
linkTimeNonInherited
	TheIdentityBertProp _ NULL.!
*/
}

public static BertProp sensorWaitingProp() {
throw new UnsupportedOperationException();/*
udanax-top.st:38388:BertProp class methodsFor: 'smalltalk: passe'!
{BertProp} sensorWaitingProp
	self passe!
*/
}
}
