/*
 * Abora-Gold
 * Part of the Abora hypertext project: http://www.abora.org
 * Copyright 2003 David G Jones
 * 
 * Translated from Udanax-Gold source code: http://www.udanax.com
 * Copyright 1979-1999 Udanax.com. All rights reserved
 */
package org.abora.gold.be.canopy;

import org.abora.gold.be.basic.BeEdition;
import org.abora.gold.be.canopy.AnyRecorderFinder;
import org.abora.gold.be.canopy.PropFinder;
import org.abora.gold.be.canopy.prop.Prop;
import org.abora.gold.filter.RegionDelta;
import org.abora.gold.id.IDRegion;
import org.abora.gold.java.missing.PropJoint;
import org.abora.gold.xcvr.Rcvr;
import org.abora.gold.xcvr.Xmtr;
import org.abora.gold.xpp.basic.Heaper;


/**
 * Generates finders for recorders triggered by an increase in permissions
 */
public class AnyRecorderPFinder extends AnyRecorderFinder {
	protected RegionDelta myPermissionsDelta;
	protected IDRegion myPermissions;
/*
udanax-top.st:40116:
AnyRecorderFinder subclass: #AnyRecorderPFinder
	instanceVariableNames: '
		myPermissionsDelta {RegionDelta of: IDRegion}
		myPermissions {IDRegion}'
	classVariableNames: ''
	poolDictionaries: ''
	category: 'Xanadu-Be-Canopy'!
*/
/*
udanax-top.st:40122:
AnyRecorderPFinder comment:
'Generates finders for recorders triggered by an increase in permissions'!
*/
/*
udanax-top.st:40124:
(AnyRecorderPFinder getOrMakeCxxClassDescription)
	attributes: ((Set new) add: #CONCRETE; add: #COPY; add: #NOT.A.TYPE; yourself)!
*/
/*
udanax-top.st:40198:
AnyRecorderPFinder class
	instanceVariableNames: ''!
*/
/*
udanax-top.st:40201:
(AnyRecorderPFinder getOrMakeCxxClassDescription)
	attributes: ((Set new) add: #CONCRETE; add: #COPY; add: #NOT.A.TYPE; yourself)!
*/

public boolean match(Prop prop) {
throw new UnsupportedOperationException();/*
udanax-top.st:40129:AnyRecorderPFinder methodsFor: 'accessing'!
{BooleanVar} match: prop {Prop}
	prop cast: SensorProp into: [ :p |
		^p relevantPermissions intersects: myPermissions].
	^false "fodder"!
*/
}

public PropFinder nextFinder(BeEdition edition) {
throw new UnsupportedOperationException();/*
udanax-top.st:40135:AnyRecorderPFinder methodsFor: 'accessing'!
{PropFinder} nextFinder: edition {BeEdition}
	^ResultRecorderPFinder make: edition
		with: myPermissionsDelta
		with: myPermissions
		with: edition totalEndorsements!
*/
}

public IDRegion permissions() {
throw new UnsupportedOperationException();/*
udanax-top.st:40142:AnyRecorderPFinder methodsFor: 'accessing'!
{IDRegion} permissions 
	
	^myPermissions!
*/
}

public RegionDelta permissionsDelta() {
throw new UnsupportedOperationException();/*
udanax-top.st:40146:AnyRecorderPFinder methodsFor: 'accessing'!
{RegionDelta of: IDRegion} permissionsDelta
	
	^myPermissionsDelta!
*/
}

public  AnyRecorderPFinder(int flags, RegionDelta permissionsDelta, IDRegion permissions) {
throw new UnsupportedOperationException();/*
udanax-top.st:40152:AnyRecorderPFinder methodsFor: 'create'!
create: flags {UInt32}
	with: permissionsDelta {RegionDelta of: IDRegion}
	with: permissions {IDRegion}
	
	super create: flags.
	myPermissionsDelta := permissionsDelta.
	myPermissions := permissions.!
*/
}

public int actualHashForEqual() {
throw new UnsupportedOperationException();/*
udanax-top.st:40162:AnyRecorderPFinder methodsFor: 'testing'!
{UInt32} actualHashForEqual
	^myPermissionsDelta hashForEqual
		bitXor: myPermissions hashForEqual!
*/
}

public boolean isEqual(Heaper heaper) {
throw new UnsupportedOperationException();/*
udanax-top.st:40167:AnyRecorderPFinder methodsFor: 'testing'!
{BooleanVar} isEqual: heaper {Heaper}
	heaper cast: AnyRecorderPFinder into: [ :other |
		^(myPermissionsDelta isEqual: other permissionsDelta)
			and: [myPermissions isEqual: other permissions]]
	others:
		[^false].
	^false "fodder"!
*/
}

public PropFinder oldPass(PropJoint parent) {
throw new UnsupportedOperationException();/*
udanax-top.st:40178:AnyRecorderPFinder methodsFor: 'smalltalk: suspended'!
{PropFinder} oldPass: parent {PropJoint}
	parent cast: SensorPropJoint into: [ :p |
		^AnyRecorderPFinder make: myPermissionsDelta
			with: ((p relevantPermissions intersect: myPermissions) cast: IDRegion)].
	^NULL "fodder"!
*/
}

public  AnyRecorderPFinder(Rcvr receiver) {
throw new UnsupportedOperationException();/*
udanax-top.st:40187:AnyRecorderPFinder methodsFor: 'generated:'!
create.Rcvr: receiver {Rcvr}
	super create.Rcvr: receiver.
	myPermissionsDelta _ receiver receiveHeaper.
	myPermissions _ receiver receiveHeaper.!
*/
}

public void sendSelfTo(Xmtr xmtr) {
throw new UnsupportedOperationException();/*
udanax-top.st:40192:AnyRecorderPFinder methodsFor: 'generated:'!
{void} sendSelfTo: xmtr {Xmtr}
	super sendSelfTo: xmtr.
	xmtr sendHeaper: myPermissionsDelta.
	xmtr sendHeaper: myPermissions.!
*/
}

public static Heaper make(RegionDelta permissionsDelta) {
throw new UnsupportedOperationException();/*
udanax-top.st:40206:AnyRecorderPFinder class methodsFor: 'create'!
{PropFinder} make: permissionsDelta {RegionDelta of: IDRegion}
	
	^self make: permissionsDelta
		with: ((permissionsDelta after minus: permissionsDelta before) cast: IDRegion)!
*/
}

public static Heaper make(RegionDelta permissionsDelta, IDRegion newPermissions) {
throw new UnsupportedOperationException();/*
udanax-top.st:40211:AnyRecorderPFinder class methodsFor: 'create'!
{PropFinder} make: permissionsDelta {RegionDelta of: IDRegion}
	with: newPermissions {IDRegion}
	
	newPermissions isEmpty ifTrue:
		[^PropFinder closedPropFinder].
	^self create: (SensorCrum flagsFor: newPermissions with: NULL with: false)
		with: permissionsDelta with: newPermissions.!
*/
}
}
