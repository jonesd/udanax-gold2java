/*
 * Abora-Gold
 * Part of the Abora hypertext project: http://www.abora.org
 * Copyright 2003 David G Jones
 * 
 * Translated from Udanax-Gold source code: http://www.udanax.com
 * Copyright 1979-1999 Udanax.com. All rights reserved
 */
package org.abora.gold.be.canopy;

import org.abora.gold.be.basic.BeEdition;
import org.abora.gold.be.canopy.BertPropFinder;
import org.abora.gold.be.canopy.PropFinder;
import org.abora.gold.be.canopy.prop.Prop;
import org.abora.gold.filter.Filter;
import org.abora.gold.java.missing.PropJoint;
import org.abora.gold.xcvr.Rcvr;
import org.abora.gold.xcvr.Xmtr;
import org.abora.gold.xpp.basic.Heaper;


/**
 * Finder used to filter the htree walk by the bert canopy when doing a backFollow which uses
 * both permissions and endorsement filters
 */
public class BackfollowFinder extends BertPropFinder {
	protected Filter myPermissionsFilter;
	protected Filter myEndorsementsFilter;
/*
udanax-top.st:39478:
BertPropFinder subclass: #BackfollowFinder
	instanceVariableNames: '
		myPermissionsFilter {Filter of: (XnRegion of: ID)}
		myEndorsementsFilter {Filter of: (XnRegion of: ID)}'
	classVariableNames: ''
	poolDictionaries: ''
	category: 'Xanadu-Be-Canopy'!
*/
/*
udanax-top.st:39484:
BackfollowFinder comment:
'Finder used to filter the htree walk by the bert canopy when doing a backFollow which uses both permissions and endorsement filters'!
*/
/*
udanax-top.st:39486:
(BackfollowFinder getOrMakeCxxClassDescription)
	attributes: ((Set new) add: #CONCRETE; add: #COPY; add: #NOT.A.TYPE; yourself)!
*/

public  BackfollowFinder(int flags, Filter permissionsFilter, Filter endorsementsFilter) {
throw new UnsupportedOperationException();/*
udanax-top.st:39491:BackfollowFinder methodsFor: 'creation'!
create: flags {UInt32}
	with: permissionsFilter {Filter of: (XnRegion of: ID)} 
	with: endorsementsFilter {Filter of: (CrossRegion of: ID)}
	
	super create: flags.
	myPermissionsFilter _ permissionsFilter.
	myEndorsementsFilter _ endorsementsFilter!
*/
}

public Filter endorsementsFilter() {
throw new UnsupportedOperationException();/*
udanax-top.st:39501:BackfollowFinder methodsFor: 'accessing'!
{Filter of: (XnRegion of: ID)} endorsementsFilter
	^myEndorsementsFilter!
*/
}

public PropFinder findPast(BeEdition edition) {
throw new UnsupportedOperationException();/*
udanax-top.st:39504:BackfollowFinder methodsFor: 'accessing'!
{PropFinder} findPast: edition {BeEdition}
	| canSee {BooleanVar} endorsements {XnRegion} |
	Ravi thingToDo. "use regions in finder so that we don't need to create intermediate objects"
	canSee := false.
	endorsements := edition endorsements.
	edition currentWorks stepper forEach: [ :work {BeWork} |
		((work fetchReadClub ~~ NULL
			and: [myPermissionsFilter match: work fetchReadClub asRegion])
		or:
			[work fetchEditClub ~~ NULL
				and: [myPermissionsFilter match: work fetchEditClub asRegion]])
			ifTrue:
				[canSee := true.
				endorsements := endorsements unionWith: work endorsements]].
	(myEndorsementsFilter match: endorsements) ifTrue:
		[canSee ifTrue:
			[^PropFinder openPropFinder]
		ifFalse:
			[^PropFinder backfollowFinder: myPermissionsFilter]].
	^self!
*/
}

/**
 * tell whether a prop matches this filter
 */
public boolean match(Prop prop) {
throw new UnsupportedOperationException();/*
udanax-top.st:39526:BackfollowFinder methodsFor: 'accessing'!
{BooleanVar} match: prop {Prop}
	"tell whether a prop matches this filter"
	| p {BertProp wimpy} |
	p _ prop cast: BertProp.
	^(myPermissionsFilter match: p permissions) and: [myEndorsementsFilter match: p endorsements]!
*/
}

public Filter permissionsFilter() {
throw new UnsupportedOperationException();/*
udanax-top.st:39532:BackfollowFinder methodsFor: 'accessing'!
{Filter of: (XnRegion of: ID)} permissionsFilter
	^myPermissionsFilter!
*/
}

public int actualHashForEqual() {
throw new UnsupportedOperationException();/*
udanax-top.st:39537:BackfollowFinder methodsFor: 'testing'!
{UInt32} actualHashForEqual
	^(self getCategory hashForEqual bitXor: myPermissionsFilter hashForEqual)
	  bitXor: myEndorsementsFilter hashForEqual!
*/
}

public boolean isEqual(Heaper other) {
throw new UnsupportedOperationException();/*
udanax-top.st:39542:BackfollowFinder methodsFor: 'testing'!
{BooleanVar} isEqual: other {Heaper}
	other 
		cast: BackfollowFinder into: [:o |
			^(myPermissionsFilter isEqual: o permissionsFilter) 
			 and: [myEndorsementsFilter isEqual: o endorsementsFilter]]
		others:
			[^false].
	^false "fodder"!
*/
}

/**
 * return a simple enough finder for looking at the children
 */
public PropFinder oldPass(PropJoint parent) {
throw new UnsupportedOperationException();/*
udanax-top.st:39554:BackfollowFinder methodsFor: 'smalltalk: suspended'!
{PropFinder} oldPass: parent {PropJoint} 
	"return a simple enough finder for looking at the children"
	| p {BertPropJoint wimpy} |
	p _ parent cast: BertPropJoint.
	^PropFinder  
		backfollowFinder: (myPermissionsFilter pass: p permissionsJoint)
		with: (myEndorsementsFilter pass: p endorsementsJoint)!
*/
}

public  BackfollowFinder(Rcvr receiver) {
throw new UnsupportedOperationException();/*
udanax-top.st:39565:BackfollowFinder methodsFor: 'generated:'!
create.Rcvr: receiver {Rcvr}
	super create.Rcvr: receiver.
	myPermissionsFilter _ receiver receiveHeaper.
	myEndorsementsFilter _ receiver receiveHeaper.!
*/
}

public void sendSelfTo(Xmtr xmtr) {
throw new UnsupportedOperationException();/*
udanax-top.st:39570:BackfollowFinder methodsFor: 'generated:'!
{void} sendSelfTo: xmtr {Xmtr}
	super sendSelfTo: xmtr.
	xmtr sendHeaper: myPermissionsFilter.
	xmtr sendHeaper: myEndorsementsFilter.!
*/
}
}
