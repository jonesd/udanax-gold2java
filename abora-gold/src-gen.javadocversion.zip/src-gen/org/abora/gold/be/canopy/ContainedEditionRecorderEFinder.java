/*
 * Abora-Gold
 * Part of the Abora hypertext project: http://www.abora.org
 * Copyright 2003 David G Jones
 * 
 * Translated from Udanax-Gold source code: http://www.udanax.com
 * Copyright 1979-1999 Udanax.com. All rights reserved
 */
package org.abora.gold.be.canopy;

import org.abora.gold.backrec.ResultRecorder;
import org.abora.gold.be.basic.BeRangeElement;
import org.abora.gold.be.canopy.PropFinder;
import org.abora.gold.be.canopy.SimpleRecorderFinder;
import org.abora.gold.be.canopy.prop.Prop;
import org.abora.gold.filter.RegionDelta;
import org.abora.gold.fossil.RecorderFossil;
import org.abora.gold.id.IDRegion;
import org.abora.gold.java.missing.PropJoint;
import org.abora.gold.spaces.cross.CrossRegion;
import org.abora.gold.xcvr.Rcvr;
import org.abora.gold.xcvr.Xmtr;
import org.abora.gold.xpp.basic.Heaper;


/**
 * Looks for recorders which might be triggered by an increase in endorsements in something
 * containing my edition. Keep the total endorsements on my edition for quick reject?
 */
public class ContainedEditionRecorderEFinder extends SimpleRecorderFinder {
	protected IDRegion myPermissions;
	protected RegionDelta myEndorsementsDelta;
	protected CrossRegion myNewEndorsements;
/*
udanax-top.st:40451:
SimpleRecorderFinder subclass: #ContainedEditionRecorderEFinder
	instanceVariableNames: '
		myPermissions {IDRegion}
		myEndorsementsDelta {RegionDelta of: CrossRegion}
		myNewEndorsements {CrossRegion}'
	classVariableNames: ''
	poolDictionaries: ''
	category: 'Xanadu-Be-Canopy'!
*/
/*
udanax-top.st:40458:
ContainedEditionRecorderEFinder comment:
'Looks for recorders which might be triggered by an increase in endorsements in something containing my edition. Keep the total endorsements on my edition for quick reject?'!
*/
/*
udanax-top.st:40460:
(ContainedEditionRecorderEFinder getOrMakeCxxClassDescription)
	attributes: ((Set new) add: #CONCRETE; add: #COPY; add: #NOT.A.TYPE; yourself)!
*/
/*
udanax-top.st:40558:
ContainedEditionRecorderEFinder class
	instanceVariableNames: ''!
*/
/*
udanax-top.st:40561:
(ContainedEditionRecorderEFinder getOrMakeCxxClassDescription)
	attributes: ((Set new) add: #CONCRETE; add: #COPY; add: #NOT.A.TYPE; yourself)!
*/

public boolean shouldTrigger(ResultRecorder recorder, RecorderFossil fossil) {
throw new UnsupportedOperationException();/*
udanax-top.st:40465:ContainedEditionRecorderEFinder methodsFor: 'recording'!
{BooleanVar} shouldTrigger: recorder {ResultRecorder}
	with: fossil {RecorderFossil}
	recorder cast: EditionRecorder into: [ :er |
		[FeServer] USES.
		CurrentKeyMaster fluidBind: er keyMaster during:
			[^(er indirectFilter isSwitchedOnBy: myEndorsementsDelta)
				and: [(er directFilter match: self edition visibleEndorsements)
				and: [self edition anyPasses: (PropFinder
					backfollowFinder: er permissionsFilter)]]]].
	^false "fodder"!
*/
}

public RegionDelta endorsementsDelta() {
throw new UnsupportedOperationException();/*
udanax-top.st:40479:ContainedEditionRecorderEFinder methodsFor: 'accessing'!
{RegionDelta of: CrossRegion} endorsementsDelta
	^myEndorsementsDelta!
*/
}

public boolean match(Prop prop) {
throw new UnsupportedOperationException();/*
udanax-top.st:40483:ContainedEditionRecorderEFinder methodsFor: 'accessing'!
{BooleanVar} match: prop {Prop}
	prop cast: SensorProp into: [ :p |
		^(p relevantPermissions intersects: myPermissions)
			and: [p relevantEndorsements intersects: myNewEndorsements]].
	^false "fodder"!
*/
}

public CrossRegion newEndorsements() {
throw new UnsupportedOperationException();/*
udanax-top.st:40490:ContainedEditionRecorderEFinder methodsFor: 'accessing'!
{CrossRegion} newEndorsements
	^myNewEndorsements!
*/
}

public IDRegion permissions() {
throw new UnsupportedOperationException();/*
udanax-top.st:40494:ContainedEditionRecorderEFinder methodsFor: 'accessing'!
{IDRegion} permissions 
	
	^myPermissions!
*/
}

public  ContainedEditionRecorderEFinder(int flags, BeRangeElement element, IDRegion permissions, RegionDelta endorsementsDelta, CrossRegion newEndorsements) {
throw new UnsupportedOperationException();/*
udanax-top.st:40500:ContainedEditionRecorderEFinder methodsFor: 'create'!
create: flags {UInt32}
	with: element {BeRangeElement}
	with: permissions {IDRegion}
	with: endorsementsDelta {RegionDelta of: CrossRegion}
	with: newEndorsements {CrossRegion}
	
	super create: flags with: element.
	myPermissions := permissions.
	myEndorsementsDelta := endorsementsDelta.
	myNewEndorsements := newEndorsements.!
*/
}

public int actualHashForEqual() {
throw new UnsupportedOperationException();/*
udanax-top.st:40513:ContainedEditionRecorderEFinder methodsFor: 'testing'!
{UInt32	} actualHashForEqual
	^((self rangeElement hashForEqual
		bitXor: myPermissions hashForEqual)
		bitXor: myEndorsementsDelta hashForEqual)
		bitXor: myNewEndorsements hashForEqual!
*/
}

public boolean isEqual(Heaper heaper) {
throw new UnsupportedOperationException();/*
udanax-top.st:40520:ContainedEditionRecorderEFinder methodsFor: 'testing'!
{BooleanVar} isEqual: heaper {Heaper}
	heaper cast: ContainedEditionRecorderEFinder into: [ :other |
		^(self rangeElement isEqual: other rangeElement)
			and: [(myPermissions isEqual: other permissions)
			and: [(myEndorsementsDelta isEqual: other endorsementsDelta)
			and: [myNewEndorsements isEqual: other newEndorsements]]]]
	others:
		[^false].
	^ false "compiler fodder"!
*/
}

public PropFinder oldPass(PropJoint parent) {
throw new UnsupportedOperationException();/*
udanax-top.st:40533:ContainedEditionRecorderEFinder methodsFor: 'smalltalk: suspended'!
{PropFinder} oldPass: parent {PropJoint}
	parent cast: SensorPropJoint into: [ :p |
		^ContainedEditionRecorderEFinder
			make: self edition
			with: ((myPermissions intersect: p relevantPermissions) cast: IDRegion)
			with: myEndorsementsDelta
			with: ((myNewEndorsements intersect: p relevantEndorsements) cast: CrossRegion)].
	^NULL "fodder"!
*/
}

public  ContainedEditionRecorderEFinder(Rcvr receiver) {
throw new UnsupportedOperationException();/*
udanax-top.st:40545:ContainedEditionRecorderEFinder methodsFor: 'generated:'!
create.Rcvr: receiver {Rcvr}
	super create.Rcvr: receiver.
	myPermissions _ receiver receiveHeaper.
	myEndorsementsDelta _ receiver receiveHeaper.
	myNewEndorsements _ receiver receiveHeaper.!
*/
}

public void sendSelfTo(Xmtr xmtr) {
throw new UnsupportedOperationException();/*
udanax-top.st:40551:ContainedEditionRecorderEFinder methodsFor: 'generated:'!
{void} sendSelfTo: xmtr {Xmtr}
	super sendSelfTo: xmtr.
	xmtr sendHeaper: myPermissions.
	xmtr sendHeaper: myEndorsementsDelta.
	xmtr sendHeaper: myNewEndorsements.!
*/
}

public static Heaper make(BeRangeElement element, IDRegion permissions, RegionDelta endorsementsDelta) {
throw new UnsupportedOperationException();/*
udanax-top.st:40566:ContainedEditionRecorderEFinder class methodsFor: 'create'!
{PropFinder} make: element {BeRangeElement}
	with: permissions {IDRegion}
	with: endorsementsDelta {RegionDelta of: CrossRegion}
	
	Ravi thingToDo. "Separate out relevant endorsements from new endorsements; relevant is those on contained edition - so you can exclude paths which would never care to record that Edition. At the moment all spawned Contained...Finders will vanish at the same time, i.e. when noone cares about the new endorsements any more. Putting in the relevant endorsements as well allows them to vanish earlier. This could also be done by testing self edition totalEndorsements in match and pass."
	
	^self make: element
		with: permissions
		with: endorsementsDelta
		with: ((endorsementsDelta after minus: endorsementsDelta before) cast: CrossRegion)!
*/
}

public static Heaper make(BeRangeElement element, IDRegion permissions, RegionDelta endorsementsDelta, CrossRegion newEndorsements) {
throw new UnsupportedOperationException();/*
udanax-top.st:40577:ContainedEditionRecorderEFinder class methodsFor: 'create'!
{PropFinder} make: element {BeRangeElement}
	with: permissions {IDRegion}
	with: endorsementsDelta {RegionDelta of: CrossRegion}
	with: newEndorsements {CrossRegion}
	
	(permissions isEmpty or: [newEndorsements isEmpty]) ifTrue:
		[^PropFinder closedPropFinder].
	^self create: (SensorCrum
			flagsFor: permissions
			with: newEndorsements
			with: false)
		with: element
		with: permissions
		with: endorsementsDelta
		with: newEndorsements.!
*/
}
}
