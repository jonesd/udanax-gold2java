/*
 * Abora-Gold
 * Part of the Abora hypertext project: http://www.abora.org
 * Copyright 2003 David G Jones
 * 
 * Translated from Udanax-Gold source code: http://www.udanax.com
 * Copyright 1979-1999 Udanax.com. All rights reserved
 */
package org.abora.gold.be.canopy;

import org.abora.gold.backrec.ResultRecorder;
import org.abora.gold.be.basic.BeEdition;
import org.abora.gold.be.basic.BeRangeElement;
import org.abora.gold.be.basic.BeWork;
import org.abora.gold.be.canopy.AbstractRecorderFinder;
import org.abora.gold.be.canopy.PropFinder;
import org.abora.gold.be.canopy.prop.Prop;
import org.abora.gold.fossil.RecorderFossil;
import org.abora.gold.java.missing.PropJoint;
import org.abora.gold.xcvr.Rcvr;
import org.abora.gold.xcvr.Xmtr;


/**
 * A finder which holds onto a RangeElement and looks for ResultRecorders which might want to
 * record it NOT.A.TYPE
 */
public class SimpleRecorderFinder extends AbstractRecorderFinder {
	protected BeRangeElement myRangeElement;
/*
udanax-top.st:40377:
AbstractRecorderFinder subclass: #SimpleRecorderFinder
	instanceVariableNames: 'myRangeElement {BeRangeElement}'
	classVariableNames: ''
	poolDictionaries: ''
	category: 'Xanadu-Be-Canopy'!
*/
/*
udanax-top.st:40381:
SimpleRecorderFinder comment:
'A finder which holds onto a RangeElement and looks for ResultRecorders which might want to record it NOT.A.TYPE '!
*/
/*
udanax-top.st:40383:
(SimpleRecorderFinder getOrMakeCxxClassDescription)
	attributes: ((Set new) add: #DEFERRED; add: #COPY; yourself)!
*/

public PropFinder findPast(BeEdition edition) {
throw new UnsupportedOperationException();/*
udanax-top.st:40388:SimpleRecorderFinder methodsFor: 'accessing'!
{PropFinder} findPast: edition {BeEdition unused}
	
	^self!
*/
}

public boolean match(Prop prop) {
throw new UnsupportedOperationException();/*
udanax-top.st:40392:SimpleRecorderFinder methodsFor: 'accessing'!
{BooleanVar} match: prop {Prop}
	self subclassResponsibility!
*/
}

public void checkRecorder(ResultRecorder recorder, RecorderFossil fossil) {
throw new UnsupportedOperationException();/*
udanax-top.st:40398:SimpleRecorderFinder methodsFor: 'recording'!
{void} checkRecorder: recorder {ResultRecorder}
	with: fossil {RecorderFossil}
	((recorder accepts: self rangeElement) and: [self shouldTrigger: recorder with: fossil]) ifTrue:
		[(RecorderTrigger make: fossil with: myRangeElement) schedule]!
*/
}

/**
 * Whether the recorder should be triggered with my RangeElement
 */
public boolean shouldTrigger(ResultRecorder recorder, RecorderFossil fossil) {
throw new UnsupportedOperationException();/*
udanax-top.st:40404:SimpleRecorderFinder methodsFor: 'recording'!
{BooleanVar} shouldTrigger: recorder {ResultRecorder}
	with: fossil {RecorderFossil}
	"Whether the recorder should be triggered with my RangeElement"
	
	self subclassResponsibility!
*/
}

public  SimpleRecorderFinder() {
throw new UnsupportedOperationException();/*
udanax-top.st:40412:SimpleRecorderFinder methodsFor: 'create'!
create
	super create "for generated code"!
*/
}

public  SimpleRecorderFinder(int flags, BeRangeElement element) {
throw new UnsupportedOperationException();/*
udanax-top.st:40415:SimpleRecorderFinder methodsFor: 'create'!
create: flags {UInt32}
	with: element {BeRangeElement}
	super create: flags.
	myRangeElement := element.!
*/
}

public BeEdition edition() {
throw new UnsupportedOperationException();/*
udanax-top.st:40423:SimpleRecorderFinder methodsFor: 'protected:'!
{BeEdition} edition
	^myRangeElement cast: BeEdition!
*/
}

public BeRangeElement rangeElement() {
throw new UnsupportedOperationException();/*
udanax-top.st:40427:SimpleRecorderFinder methodsFor: 'protected:'!
{BeRangeElement} rangeElement
	^myRangeElement!
*/
}

public BeWork work() {
throw new UnsupportedOperationException();/*
udanax-top.st:40431:SimpleRecorderFinder methodsFor: 'protected:'!
{BeWork} work
	^myRangeElement cast: BeWork!
*/
}

public PropFinder oldPass(PropJoint parent) {
throw new UnsupportedOperationException();/*
udanax-top.st:40437:SimpleRecorderFinder methodsFor: 'smalltalk: suspended'!
{PropFinder} oldPass: parent {PropJoint}
	self subclassResponsibility!
*/
}

public  SimpleRecorderFinder(Rcvr receiver) {
throw new UnsupportedOperationException();/*
udanax-top.st:40443:SimpleRecorderFinder methodsFor: 'generated:'!
create.Rcvr: receiver {Rcvr}
	super create.Rcvr: receiver.
	myRangeElement _ receiver receiveHeaper.!
*/
}

public void sendSelfTo(Xmtr xmtr) {
throw new UnsupportedOperationException();/*
udanax-top.st:40447:SimpleRecorderFinder methodsFor: 'generated:'!
{void} sendSelfTo: xmtr {Xmtr}
	super sendSelfTo: xmtr.
	xmtr sendHeaper: myRangeElement.!
*/
}
}
