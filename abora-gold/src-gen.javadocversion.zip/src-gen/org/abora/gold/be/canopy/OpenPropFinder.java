/*
 * Abora-Gold
 * Part of the Abora hypertext project: http://www.abora.org
 * Copyright 2003 David G Jones
 * 
 * Translated from Udanax-Gold source code: http://www.udanax.com
 * Copyright 1979-1999 Udanax.com. All rights reserved
 */
package org.abora.gold.be.canopy;

import org.abora.gold.be.basic.BeEdition;
import org.abora.gold.be.canopy.CanopyCrum;
import org.abora.gold.be.canopy.PropFinder;
import org.abora.gold.be.canopy.prop.Prop;
import org.abora.gold.xcvr.Rcvr;
import org.abora.gold.xcvr.Xmtr;
import org.abora.gold.xpp.basic.Heaper;


/**
 * The finder which matches everything.  Used to indicate that everything below here
 * necessarily matches.
 */
public class OpenPropFinder extends PropFinder {
/*
udanax-top.st:39796:
PropFinder subclass: #OpenPropFinder
	instanceVariableNames: ''
	classVariableNames: ''
	poolDictionaries: ''
	category: 'Xanadu-Be-Canopy'!
*/
/*
udanax-top.st:39800:
OpenPropFinder comment:
'The finder which matches everything.  Used to indicate that everything below here necessarily matches.'!
*/
/*
udanax-top.st:39802:
(OpenPropFinder getOrMakeCxxClassDescription)
	attributes: ((Set new) add: #CONCRETE; add: #COPY; add: #NOT.A.TYPE; yourself)!
*/

public PropFinder findPast(BeEdition stamp) {
throw new UnsupportedOperationException();/*
udanax-top.st:39807:OpenPropFinder methodsFor: 'accessing'!
{PropFinder} findPast: stamp {BeEdition unused}
	
	^self!
*/
}

public boolean isFull() {
throw new UnsupportedOperationException();/*
udanax-top.st:39811:OpenPropFinder methodsFor: 'accessing'!
{BooleanVar} isFull
	
	^true!
*/
}

/**
 * tell whether a prop matches this filter
 */
public boolean match(Prop prop) {
throw new UnsupportedOperationException();/*
udanax-top.st:39815:OpenPropFinder methodsFor: 'accessing'!
{BooleanVar} match: prop {Prop unused}
	"tell whether a prop matches this filter"
	^true!
*/
}

public PropFinder pass(CanopyCrum crum) {
throw new UnsupportedOperationException();/*
udanax-top.st:39819:OpenPropFinder methodsFor: 'accessing'!
{PropFinder} pass: crum {CanopyCrum unused}
	^self!
*/
}

public int actualHashForEqual() {
throw new UnsupportedOperationException();/*
udanax-top.st:39825:OpenPropFinder methodsFor: 'testing'!
{UInt32} actualHashForEqual
	^self getCategory hashForEqual!
*/
}

public boolean isEqual(Heaper other) {
throw new UnsupportedOperationException();/*
udanax-top.st:39829:OpenPropFinder methodsFor: 'testing'!
{BooleanVar} isEqual: other {Heaper}
	^other isKindOf: OpenPropFinder!
*/
}

public  OpenPropFinder() {
throw new UnsupportedOperationException();/*
udanax-top.st:39835:OpenPropFinder methodsFor: 'create'!
create
	super create: UInt32Zero bitInvert!
*/
}

public  OpenPropFinder(Rcvr receiver) {
throw new UnsupportedOperationException();/*
udanax-top.st:39841:OpenPropFinder methodsFor: 'generated:'!
create.Rcvr: receiver {Rcvr}
	super create.Rcvr: receiver.!
*/
}

public void sendSelfTo(Xmtr xmtr) {
throw new UnsupportedOperationException();/*
udanax-top.st:39844:OpenPropFinder methodsFor: 'generated:'!
{void} sendSelfTo: xmtr {Xmtr}
	super sendSelfTo: xmtr.!
*/
}
}
