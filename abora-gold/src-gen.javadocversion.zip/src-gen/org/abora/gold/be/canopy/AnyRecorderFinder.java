/*
 * Abora-Gold
 * Part of the Abora hypertext project: http://www.abora.org
 * Copyright 2003 David G Jones
 * 
 * Translated from Udanax-Gold source code: http://www.udanax.com
 * Copyright 1979-1999 Udanax.com. All rights reserved
 */
package org.abora.gold.be.canopy;

import org.abora.gold.backrec.ResultRecorder;
import org.abora.gold.be.basic.BeEdition;
import org.abora.gold.be.canopy.AbstractRecorderFinder;
import org.abora.gold.be.canopy.PropFinder;
import org.abora.gold.be.canopy.prop.Prop;
import org.abora.gold.fossil.RecorderFossil;
import org.abora.gold.java.missing.PropJoint;


/**
 * NOT.A.TYPE A general superclass for finders that looks for all recorders, and all elements
 * they might find, resulting from a given change.
 */
public class AnyRecorderFinder extends AbstractRecorderFinder {
/*
udanax-top.st:39949:
AbstractRecorderFinder subclass: #AnyRecorderFinder
	instanceVariableNames: ''
	classVariableNames: ''
	poolDictionaries: ''
	category: 'Xanadu-Be-Canopy'!
*/
/*
udanax-top.st:39953:
AnyRecorderFinder comment:
'NOT.A.TYPE A general superclass for finders that looks for all recorders, and all elements they might find, resulting from a given change.'!
*/
/*
udanax-top.st:39955:
(AnyRecorderFinder getOrMakeCxxClassDescription)
	attributes: ((Set new) add: #DEFERRED; yourself)!
*/

public  AnyRecorderFinder() {
throw new UnsupportedOperationException();/*
udanax-top.st:39960:AnyRecorderFinder methodsFor: 'create'!
create
	super create "for generated code"!
*/
}

public  AnyRecorderFinder(int flags) {
throw new UnsupportedOperationException();/*
udanax-top.st:39963:AnyRecorderFinder methodsFor: 'create'!
create: flags {UInt32}
	super create: flags!
*/
}

/**
 * do nothing
 */
public void checkRecorder(ResultRecorder recorder, RecorderFossil fossil) {
throw new UnsupportedOperationException();/*
udanax-top.st:39969:AnyRecorderFinder methodsFor: 'recording'!
{void} checkRecorder: recorder {ResultRecorder}
	with: fossil {RecorderFossil}
	"do nothing"!
*/
}

public PropFinder findPast(BeEdition stamp) {
throw new UnsupportedOperationException();/*
udanax-top.st:39976:AnyRecorderFinder methodsFor: 'accessing'!
{PropFinder} findPast: stamp {BeEdition unused}
	
	^self!
*/
}

public boolean match(Prop prop) {
throw new UnsupportedOperationException();/*
udanax-top.st:39980:AnyRecorderFinder methodsFor: 'accessing'!
{BooleanVar} match: prop {Prop}
	self subclassResponsibility!
*/
}

/**
 * An additional finder to use below the given Edition
 */
public PropFinder nextFinder(BeEdition edition) {
throw new UnsupportedOperationException();/*
udanax-top.st:39984:AnyRecorderFinder methodsFor: 'accessing'!
{PropFinder} nextFinder: edition {BeEdition}
	"An additional finder to use below the given Edition"
	
	self subclassResponsibility!
*/
}

public PropFinder oldPass(PropJoint parent) {
throw new UnsupportedOperationException();/*
udanax-top.st:39991:AnyRecorderFinder methodsFor: 'smalltalk: suspended'!
{PropFinder} oldPass: parent {PropJoint}
	self subclassResponsibility!
*/
}
}
