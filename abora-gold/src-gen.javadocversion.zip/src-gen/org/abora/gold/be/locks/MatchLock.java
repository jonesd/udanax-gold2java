/*
 * Abora-Gold
 * Part of the Abora hypertext project: http://www.abora.org
 * Copyright 2003 David G Jones
 * 
 * Translated from Udanax-Gold source code: http://www.udanax.com
 * Copyright 1979-1999 Udanax.com. All rights reserved
 */
package org.abora.gold.be.locks;

import org.abora.gold.be.basic.ID;
import org.abora.gold.be.locks.Lock;
import org.abora.gold.collection.basic.PrimIntArray;
import org.abora.gold.nadmin.FeMatchLockSmith;
import org.abora.gold.nkernel.FeKeyMaster;
import org.abora.gold.xpp.basic.Heaper;


/**
 * The correct password will open the lock. The password is actually stored in the club`s
 * MatchLockSmith in scrambled form, using a Scrambler identified by scramblerName(). The
 * scrambled cleartext supplied as a password is compared to the scrambledPassword in the
 * MatchLockSmith. If they match, the lock is opened.
 * The actual process is a bit more complicated than this. The user supplies a password in
 * clear, which is encrypted with the current system public key and then sent to the server.
 * There, it is first decrypted with the private key known only to the server. It is then
 * scrambled and compared with the scrambled password stored in the MatchLockSmith of the
 * club. This procedure both avoids sending passwords in clear over the network, and also
 * allows the MatchLockSmith to be made readable without compromising security.
 */
public class MatchLock extends Lock {
/*
udanax-top.st:28084:
Lock subclass: #MatchLock
	instanceVariableNames: ''
	classVariableNames: ''
	poolDictionaries: ''
	category: 'Xanadu-Be-Locks'!
*/
/*
udanax-top.st:28088:
MatchLock comment:
'The correct password will open the lock. The password is actually stored in the club`s MatchLockSmith in scrambled form, using a Scrambler identified by scramblerName(). The scrambled cleartext supplied as a password is compared to the scrambledPassword in the MatchLockSmith. If they match, the lock is opened. 
The actual process is a bit more complicated than this. The user supplies a password in clear, which is encrypted with the current system public key and then sent to the server. There, it is first decrypted with the private key known only to the server. It is then scrambled and compared with the scrambled password stored in the MatchLockSmith of the club. This procedure both avoids sending passwords in clear over the network, and also allows the MatchLockSmith to be made readable without compromising security.'!
*/
/*
udanax-top.st:28092:
(MatchLock getOrMakeCxxClassDescription)
	attributes: ((Set new) add: #ON.CLIENT; add: #CONCRETE; yourself)!
*/
/*
udanax-top.st:28115:
MatchLock class
	instanceVariableNames: ''!
*/
/*
udanax-top.st:28118:
(MatchLock getOrMakeCxxClassDescription)
	attributes: ((Set new) add: #ON.CLIENT; add: #CONCRETE; yourself)!
*/

/**
 * Send the encrypted password to the server to be checked.
 * NOTE: (for protocol review) The password must have been encrypted using a
 * (yet-to-be-defined) front end library function, since this sort of front end computation
 * can't be done with Promises.
 */
public FeKeyMaster encryptedPassword(PrimIntArray encrypted) {
throw new UnsupportedOperationException();/*
udanax-top.st:28097:MatchLock methodsFor: 'accessing'!
{FeKeyMaster CLIENT login} encryptedPassword: encrypted {PrimIntArray}
	"Send the encrypted password to the server to be checked.
	NOTE: (for protocol review) The password must have been encrypted using a (yet-to-be-defined) front end library function, since this sort of front end computation can't be done with Promises."
	| cs {FeServer} |
	cs := CurrentServer fluidGet.
	(self fetchLoginClubID ~~ NULL
			and: [(self lockSmith cast: FeMatchLockSmith) scrambledPassword
				contentsEqual: (cs encrypter decrypt: (encrypted cast: UInt8Array))])
		ifFalse: [Heaper BLAST: #DoesNotMatch].
	^self makeKeyMaster!
*/
}

public  MatchLock(ID loginID, FeMatchLockSmith lockSmith) {
	super(null, null);
throw new UnsupportedOperationException();/*
udanax-top.st:28110:MatchLock methodsFor: 'private: create'!
create: loginID {ID} with: lockSmith {FeMatchLockSmith}
	super create: loginID with: lockSmith!
*/
}

public static void problems() {
throw new UnsupportedOperationException();/*
udanax-top.st:28123:MatchLock class methodsFor: 'exceptions: exceptions'!
problems.PasswordDoesNotMatch
	^self signals: #(PasswordDoesNotMatch)!
*/
}

public static Heaper make(ID clubID, FeMatchLockSmith lockSmith) {
throw new UnsupportedOperationException();/*
udanax-top.st:28130:MatchLock class methodsFor: 'pseudo constructors'!
make: clubID {ID | NULL} with: lockSmith {FeMatchLockSmith}
	^self create: clubID with: lockSmith!
*/
}

/**
 * {FeKeyMaster CLIENT} encryptedPassword: encrypted {UInt8Array}
 */
public static void info() {
throw new UnsupportedOperationException();/*
udanax-top.st:28136:MatchLock class methodsFor: 'smalltalk: system'!
info.stProtocol
"{FeKeyMaster CLIENT} encryptedPassword: encrypted {UInt8Array}
"!
*/
}
}
