/*
 * Abora-Gold
 * Part of the Abora hypertext project: http://www.abora.org
 * Copyright 2003 David G Jones
 * 
 * Translated from Udanax-Gold source code: http://www.udanax.com
 * Copyright 1979-1999 Udanax.com. All rights reserved
 */
package org.abora.gold.be.locks;

import org.abora.gold.be.basic.ID;
import org.abora.gold.be.locks.Lock;
import org.abora.gold.nadmin.FeLockSmith;
import org.abora.gold.xpp.basic.Heaper;


/**
 * A Wall cannot be opened. Sorry, dude!!!!
 * Clubs can have WallLockSmiths for a variety of reasons. Clubs that represent groups of
 * users, and to which noone should be able to login directly (only as a member using
 * loginToSuperClub), will have WallLockSmiths. Or, if you want to make a document read-only,
 * remove all the members from its editClub, make it self-reading, and put a WallLockSmith on
 * it; then, noone can login to the club, either directly or as a member, and noone can
 * change it.
 */
public class WallLock extends Lock {
/*
udanax-top.st:28188:
Lock subclass: #WallLock
	instanceVariableNames: ''
	classVariableNames: ''
	poolDictionaries: ''
	category: 'Xanadu-Be-Locks'!
*/
/*
udanax-top.st:28192:
WallLock comment:
'A Wall cannot be opened. Sorry, dude!!!!
Clubs can have WallLockSmiths for a variety of reasons. Clubs that represent groups of users, and to which noone should be able to login directly (only as a member using loginToSuperClub), will have WallLockSmiths. Or, if you want to make a document read-only, remove all the members from its editClub, make it self-reading, and put a WallLockSmith on it; then, noone can login to the club, either directly or as a member, and noone can change it. '!
*/
/*
udanax-top.st:28196:
(WallLock getOrMakeCxxClassDescription)
	attributes: ((Set new) add: #ON.CLIENT; add: #CONCRETE; yourself)!
*/
/*
udanax-top.st:28206:
WallLock class
	instanceVariableNames: ''!
*/
/*
udanax-top.st:28209:
(WallLock getOrMakeCxxClassDescription)
	attributes: ((Set new) add: #ON.CLIENT; add: #CONCRETE; yourself)!
*/

public  WallLock(ID loginID, FeLockSmith lockSmith) {
	super(null, null);
throw new UnsupportedOperationException();/*
udanax-top.st:28201:WallLock methodsFor: 'private: create'!
create: loginID {ID} with: lockSmith {FeLockSmith}
	super create: loginID with: lockSmith!
*/
}

public static Heaper make(ID clubID, FeLockSmith lockSmith) {
throw new UnsupportedOperationException();/*
udanax-top.st:28214:WallLock class methodsFor: 'pseudo constructors'!
make: clubID {ID | NULL} with: lockSmith {FeLockSmith}
	^self create: clubID with: lockSmith!
*/
}
}
