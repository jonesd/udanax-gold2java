/*
 * Abora-Gold
 * Part of the Abora hypertext project: http://www.abora.org
 * Copyright 2003 David G Jones
 * 
 * Translated from Udanax-Gold source code: http://www.udanax.com
 * Copyright 1979-1999 Udanax.com. All rights reserved
 */
package org.abora.gold.be.locks;

import org.abora.gold.be.basic.ID;
import org.abora.gold.be.locks.Lock;
import org.abora.gold.nadmin.FeLockSmith;
import org.abora.gold.nkernel.FeKeyMaster;
import org.abora.gold.xpp.basic.Heaper;


/**
 * A BooLock is very easy to open. Just say "boo".
 * Since anyone can get in, only public clubs with little authority, such as System Public,
 * should have BooLockSmiths.
 */
public class BooLock extends Lock {
/*
udanax-top.st:27976:
Lock subclass: #BooLock
	instanceVariableNames: ''
	classVariableNames: ''
	poolDictionaries: ''
	category: 'Xanadu-Be-Locks'!
*/
/*
udanax-top.st:27980:
BooLock comment:
'A BooLock is very easy to open. Just say "boo". 
Since anyone can get in, only public clubs with little authority, such as System Public, should have BooLockSmiths.'!
*/
/*
udanax-top.st:27984:
(BooLock getOrMakeCxxClassDescription)
	attributes: ((Set new) add: #ON.CLIENT; add: #CONCRETE; yourself)!
*/
/*
udanax-top.st:28001:
BooLock class
	instanceVariableNames: ''!
*/
/*
udanax-top.st:28004:
(BooLock getOrMakeCxxClassDescription)
	attributes: ((Set new) add: #ON.CLIENT; add: #CONCRETE; yourself)!
*/

/**
 * Essential.  This is a very easy lock to open. Just say `boo'.
 */
public FeKeyMaster boo() {
throw new UnsupportedOperationException();/*
udanax-top.st:27989:BooLock methodsFor: 'accessing'!
{FeKeyMaster CLIENT login} boo
	"Essential.  This is a very easy lock to open. Just say `boo'."
	^self makeKeyMaster!
*/
}

public  BooLock(ID clubID, FeLockSmith lockSmith) {
	super(clubID, lockSmith);
throw new UnsupportedOperationException();/*
udanax-top.st:27996:BooLock methodsFor: 'private: create'!
create: clubID {ID} with: lockSmith {FeLockSmith}
	super create: clubID with: lockSmith!
*/
}

public static Heaper make(ID clubID, FeLockSmith lockSmith) {
throw new UnsupportedOperationException();/*
udanax-top.st:28009:BooLock class methodsFor: 'pseudo constructors'!
make: clubID {ID} with: lockSmith {FeLockSmith}
	^self create: clubID with: lockSmith!
*/
}

/**
 * {FeKeyMaster CLIENT} boo
 */
public static void info() {
throw new UnsupportedOperationException();/*
udanax-top.st:28015:BooLock class methodsFor: 'smalltalk: system'!
info.stProtocol
"{FeKeyMaster CLIENT} boo
"!
*/
}
}
