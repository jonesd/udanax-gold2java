/*
 * Abora-Gold
 * Part of the Abora hypertext project: http://www.abora.org
 * Copyright 2003 David G Jones
 * 
 * Translated from Udanax-Gold source code: http://www.udanax.com
 * Copyright 1979-1999 Udanax.com. All rights reserved
 */
package org.abora.gold.be.ents;

import org.abora.gold.arrange.Arrangement;
import org.abora.gold.collection.basic.PrimArray;
import org.abora.gold.collection.basic.PrimDataArray;
import org.abora.gold.snarf.Abraham;
import org.abora.gold.spaces.basic.Dsp;
import org.abora.gold.spaces.basic.Position;
import org.abora.gold.spaces.basic.XnRegion;
import org.abora.gold.x.PrimSpec;
import org.abora.gold.xcvr.Rcvr;
import org.abora.gold.xcvr.Xmtr;
import org.abora.gold.xpp.basic.Heaper;


public class SharedData extends Abraham {
	protected Arrangement myArrangement;
	protected PrimArray myData;
/*
udanax-top.st:11059:
Abraham subclass: #SharedData
	instanceVariableNames: '
		myArrangement {Arrangement}
		myData {PrimArray}'
	classVariableNames: ''
	poolDictionaries: ''
	category: 'Xanadu-Be-Ents'!
*/
/*
udanax-top.st:11065:
(SharedData getOrMakeCxxClassDescription)
	attributes: ((Set new) add: #LOCKED; add: #COPY; add: #SHEPHERD.PATRIARCH; add: #CONCRETE; yourself)!
*/

public int contentsHash() {
throw new UnsupportedOperationException();/*
udanax-top.st:11070:SharedData methodsFor: 'accessing'!
{UInt32} contentsHash
	^super contentsHash
		bitXor: myData contentsHash!
*/
}

public Heaper fetch(Position key) {
throw new UnsupportedOperationException();/*
udanax-top.st:11075:SharedData methodsFor: 'accessing'!
{Heaper | NULL} fetch: key {Position}
	^myData fetchValue: (myArrangement indexOf: key) DOTasLong!
*/
}

/**
 * Transfer my data into the toArray mapping through my arrangement and his arrangement.
 */
public void fill(XnRegion keys, Arrangement toArrange, PrimArray toArray, Dsp dsp) {
throw new UnsupportedOperationException();/*
udanax-top.st:11078:SharedData methodsFor: 'accessing'!
{void} fill: keys {XnRegion} with: toArrange {Arrangement} with: toArray {PrimArray} with: dsp {Dsp} 
	"Transfer my data into the toArray mapping through my arrangement and his arrangement."
	
	keys isEmpty ifFalse:
		[toArrange
			copyElements: toArray
			with: dsp
			with: myData
			with: myArrangement
			with: (dsp inverseOfAll: keys)]!
*/
}

/**
 * Return the primSpec for my data.
 */
public PrimSpec spec() {
throw new UnsupportedOperationException();/*
udanax-top.st:11089:SharedData methodsFor: 'accessing'!
{PrimSpec} spec
	"Return the primSpec for my data."
	
	^myData spec!
*/
}

public  SharedData(PrimDataArray data, Arrangement arrange) {
throw new UnsupportedOperationException();/*
udanax-top.st:11096:SharedData methodsFor: 'creation'!
create: data {PrimDataArray} with: arrange {Arrangement} 
	super create.
	myData _ data.
	myArrangement _ arrange.
	myData count = myArrangement region count DOTasLong assert: 'Invalid arrangement'.
	self newShepherd.
	self remember!
*/
}

public  SharedData(Rcvr receiver) {
throw new UnsupportedOperationException();/*
udanax-top.st:11106:SharedData methodsFor: 'generated:'!
create.Rcvr: receiver {Rcvr}
	super create.Rcvr: receiver.
	myArrangement _ receiver receiveHeaper.
	myData _ receiver receiveHeaper.!
*/
}

public void sendSelfTo(Xmtr xmtr) {
throw new UnsupportedOperationException();/*
udanax-top.st:11111:SharedData methodsFor: 'generated:'!
{void} sendSelfTo: xmtr {Xmtr}
	super sendSelfTo: xmtr.
	xmtr sendHeaper: myArrangement.
	xmtr sendHeaper: myData.!
*/
}
}
