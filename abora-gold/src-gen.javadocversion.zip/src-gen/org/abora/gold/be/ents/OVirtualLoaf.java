/*
 * Abora-Gold
 * Part of the Abora hypertext project: http://www.abora.org
 * Copyright 2003 David G Jones
 * 
 * Translated from Udanax-Gold source code: http://www.udanax.com
 * Copyright 1979-1999 Udanax.com. All rights reserved
 */
package org.abora.gold.be.ents;

import java.io.PrintWriter;
import org.abora.gold.arrange.Arrangement;
import org.abora.gold.be.basic.BeEdition;
import org.abora.gold.be.basic.BeRangeElement;
import org.abora.gold.be.basic.ID;
import org.abora.gold.be.canopy.SensorCrum;
import org.abora.gold.be.ents.HUpperCrum;
import org.abora.gold.be.ents.OExpandingLoaf;
import org.abora.gold.be.ents.OrglRoot;
import org.abora.gold.be.ents.SharedData;
import org.abora.gold.collection.basic.PrimArray;
import org.abora.gold.collection.steppers.Stepper;
import org.abora.gold.detect.FeFillRangeDetector;
import org.abora.gold.java.missing.XnSensor;
import org.abora.gold.nkernel.FeRangeElement;
import org.abora.gold.spaces.basic.Dsp;
import org.abora.gold.spaces.basic.OrderSpec;
import org.abora.gold.spaces.basic.Position;
import org.abora.gold.spaces.basic.XnRegion;
import org.abora.gold.tclude.TrailBlazer;
import org.abora.gold.x.PrimSpec;
import org.abora.gold.xcvr.Rcvr;
import org.abora.gold.xcvr.Xmtr;


public class OVirtualLoaf extends OExpandingLoaf {
	protected ID myOwner;
	protected SharedData myData;
/*
udanax-top.st:9071:
OExpandingLoaf subclass: #OVirtualLoaf
	instanceVariableNames: '
		myOwner {ID}
		myData {SharedData}'
	classVariableNames: ''
	poolDictionaries: ''
	category: 'Xanadu-Be-Ents'!
*/
/*
udanax-top.st:9077:
(OVirtualLoaf getOrMakeCxxClassDescription)
	attributes: ((Set new) add: #COPY; add: #SHEPHERD.ANCESTOR; add: #LOCKED; add: #NOT.A.TYPE; add: #CONCRETE; yourself)!
*/

/**
 * Make a virtual DataHolder.
 */
public FeRangeElement fetch(Position key, BeEdition edition, Position globalKey) {
throw new UnsupportedOperationException();/*
udanax-top.st:9082:OVirtualLoaf methodsFor: 'accessing'!
{FeRangeElement | NULL} fetch: key {Position} with: edition {BeEdition} with: globalKey {Position}
	"Make a virtual DataHolder."
	(self domain hasMember: key) 
		ifTrue: 
			[^FeDataHolder fake: ((myData fetch: key) cast: PrimValue)
				with: globalKey
				with: edition] 
		ifFalse: [^NULL]!
*/
}

/**
 * Get or make the BeRangeElement at the location.
 */
public BeRangeElement getBe(Position key) {
throw new UnsupportedOperationException();/*
udanax-top.st:9092:OVirtualLoaf methodsFor: 'accessing'!
{BeRangeElement} getBe: key {Position}
	"Get or make the BeRangeElement at the location."
	
	"My region had better be just onto the key.
	 become a RegionLoaf onto a new BeDataHolder containing the 
	 data extracted from my SharedData object."
		
	| element {BeRangeElement}  domain {XnRegion}
	 hcrum {HUpperCrum} hash {UInt32} info {FlockInfo}|
	domain _ key asRegion.
	(self domain isEqual: domain) ifFalse: [Heaper BLAST: #NotInTable].
	hcrum _ self hCrum cast: HUpperCrum.
	hash _ self hashForEqual.
	info _ self fetchInfo.
	DiskManager consistent:
		[| oldSensorCrum {CanopyCrum} |
		oldSensorCrum _ self sensorCrum.
		[Ent] USES.
		InitialOwner fluidBind: self owner
			during: [CurrentTrace fluidBind: self hCrum hCut
			during: [CurrentBertCrum fluidBind: BertCrum make
			during:
				[element _ BeDataHolder create: ((myData fetch: key) cast: PrimValue)]]].
		(RegionLoaf new.Become: self)
			create: domain
			with: element 
			with: hcrum
			with: hash 
			with: info.
		oldSensorCrum removePointer: self].
	^element!
*/
}

/**
 * Return the owner of the atoms represented by the receiver.
 */
public ID owner() {
throw new UnsupportedOperationException();/*
udanax-top.st:9124:OVirtualLoaf methodsFor: 'accessing'!
{ID} owner
	"Return the owner of the atoms represented by the receiver."
	
	^myOwner!
*/
}

/**
 * Return the primSpec for my data.
 */
public PrimSpec spec() {
throw new UnsupportedOperationException();/*
udanax-top.st:9129:OVirtualLoaf methodsFor: 'accessing'!
{PrimSpec} spec
	"Return the primSpec for my data."
	
	^myData spec!
*/
}

public XnRegion usedDomain() {
throw new UnsupportedOperationException();/*
udanax-top.st:9134:OVirtualLoaf methodsFor: 'accessing'!
{XnRegion} usedDomain
	^self domain!
*/
}

/**
 * Return a stepper of bundles according to the order.
 */
public Stepper bundleStepper(XnRegion region, OrderSpec order, Dsp globalDsp) {
throw new UnsupportedOperationException();/*
udanax-top.st:9139:OVirtualLoaf methodsFor: 'operations'!
{Stepper} bundleStepper: region {XnRegion} with: order {OrderSpec} with: globalDsp {Dsp} 
	"Return a stepper of bundles according to the order."
	| bundleRegion {XnRegion} array {PrimArray} |
	bundleRegion _ region intersect: (globalDsp ofAll: self domain).
	bundleRegion isEmpty ifTrue: [^Stepper emptyStepper].
	array _ myData spec array: bundleRegion count DOTasLong.
	myData fill: bundleRegion with: (order arrange: bundleRegion) with: array with: globalDsp.
	^Stepper itemStepper: 
		(FeArrayBundle 
			make: bundleRegion 
			with: array
			with: order)!
*/
}

public void fill(XnRegion keys, Arrangement toArrange, PrimArray toArray, Dsp dsp, BeEdition edition) {
throw new UnsupportedOperationException();/*
udanax-top.st:9153:OVirtualLoaf methodsFor: 'operations'!
{void} fill: keys {XnRegion} with: toArrange {Arrangement} with: toArray {PrimArray} with: dsp {Dsp} with: edition {BeEdition} 
	
	myData fill: (keys intersect: self domain) with: toArrange with: toArray with: dsp!
*/
}

public void informTo(OrglRoot orgl) {
throw new UnsupportedOperationException();/*
udanax-top.st:9157:OVirtualLoaf methodsFor: 'operations'!
{void} informTo: orgl {OrglRoot unused}
	self unimplemented!
*/
}

/**
 * If the CurrentKeyMaster includes the owner of this loaf
 * then change the owner and return NULL
 * else just return self.
 */
public OrglRoot setAllOwners(ID owner) {
throw new UnsupportedOperationException();/*
udanax-top.st:9160:OVirtualLoaf methodsFor: 'operations'!
{OrglRoot} setAllOwners: owner {ID} 
	"If the CurrentKeyMaster includes the owner of this loaf
		then change the owner and return NULL
		else just return self."
		
	(CurrentKeyMaster fluidGet hasAuthority: myOwner)
		ifTrue:
			[myOwner _ owner.
			^OrglRoot make: self domain coordinateSpace]
		ifFalse: [^ActualOrglRoot make: self with: self domain]!
*/
}

public void printOn(PrintWriter aStream) {
throw new UnsupportedOperationException();/*
udanax-top.st:9173:OVirtualLoaf methodsFor: 'printing'!
{void} printOn: aStream {ostream reference}
	aStream << self getCategory name << '(' << "(myData table subTable: self domain) <<" ', ' << self hCrum hCut << ')'!
*/
}

/**
 * Don't expand my virtual tree in place.  Just move it closer to the top.
 */
public byte actualSoftSplay(XnRegion region, XnRegion limitRegion) {
throw new UnsupportedOperationException();/*
udanax-top.st:9178:OVirtualLoaf methodsFor: 'protected: splay'!
{Int8} actualSoftSplay: region {XnRegion} with: limitRegion {XnRegion unused} 
	"Don't expand my virtual tree in place.  Just move it closer to the top."
	
	^2!
*/
}

/**
 * Expand my partial tree in place. The area in the region must go
 * into the leftCrum of my substitute, or the splay algorithm will fail!!
 */
public byte actualSplay(XnRegion region, XnRegion limitRegion) {
throw new UnsupportedOperationException();/*
udanax-top.st:9183:OVirtualLoaf methodsFor: 'protected: splay'!
{Int8} actualSplay: region {XnRegion} with: limitRegion {XnRegion unused} 
	"Expand my partial tree in place. The area in the region must go 
	into the leftCrum of my substitute, or the splay algorithm will fail!!"
	
	| crums {Pair of: SensorCrum} tmp1 {Loaf} tmp2 {Loaf} |
	crums _ self sensorCrum expand.
	InitialOwner fluidBind: self owner during:
	[DiskManager consistent: 3 with:
		[tmp1 _ OVirtualLoaf
					create: (self domain intersect: region)
					with: myData  
					with: (HUpperCrum make: (self hCrum cast: HUpperCrum))
					with: (crums left cast: SensorCrum)].
	DiskManager consistent: 3 with:
		[tmp2 _ OVirtualLoaf
					create: (self domain intersect: region complement)
					with: myData 
					with: (HUpperCrum make: (self hCrum cast: HUpperCrum))
					with: (crums right cast: SensorCrum)].
	DiskManager consistent: 5 with:
		[| hcrum {HUpperCrum} 
		   hash {UInt32} 
		   info {FlockInfo} 
		   oldSensorCrum {CanopyCrum} |
		hcrum _ self hCrum cast: HUpperCrum.
		hash _ self hashForEqual.
		oldSensorCrum _ self sensorCrum.
		info _ self fetchInfo.
		(SplitLoaf new.Become: self)
			create: region
			with: tmp1
			with: tmp2
			with: hcrum
			with: hash
			with: info.
		"The new SplitLoaf will add itself."
		oldSensorCrum removePointer: self]].
	^1!
*/
}

public  OVirtualLoaf(XnRegion region, SharedData data) {
	super(region);
throw new UnsupportedOperationException();/*
udanax-top.st:9224:OVirtualLoaf methodsFor: 'create'!
create: region {XnRegion} with: data {SharedData}
	super create: region.
	myData _ data.
	myOwner _ InitialOwner fluidFetch.
	self newShepherd!
*/
}

public  OVirtualLoaf(XnRegion region, SharedData data, HUpperCrum hcrum, SensorCrum scrum) {
	super(region, hcrum, scrum);
throw new UnsupportedOperationException();/*
udanax-top.st:9230:OVirtualLoaf methodsFor: 'create'!
create: region {XnRegion} with: data {SharedData} with: hcrum {HUpperCrum} with: scrum {SensorCrum}
	super create: region with: hcrum with: scrum.
	myData _ data.
	myOwner _ InitialOwner fluidFetch.
	self newShepherd!
*/
}

public int contentsHash() {
throw new UnsupportedOperationException();/*
udanax-top.st:9238:OVirtualLoaf methodsFor: 'testing'!
{UInt32} contentsHash
	^super contentsHash
		bitXor: myData contentsHash!
*/
}

public void showOn(Object oo) {
throw new UnsupportedOperationException();/*
udanax-top.st:9245:OVirtualLoaf methodsFor: 'smalltalk:'!
showOn: oo
	oo << myData!
*/
}

public void wait(XnSensor sensor) {
throw new UnsupportedOperationException();/*
udanax-top.st:9250:OVirtualLoaf methodsFor: 'smalltalk: passe'!
{void} wait: sensor {XnSensor}
	
	self passe!
*/
}

public XnRegion attachTrailBlazer(TrailBlazer blazer) {
throw new UnsupportedOperationException();/*
udanax-top.st:9256:OVirtualLoaf methodsFor: 'backfollow'!
{XnRegion} attachTrailBlazer: blazer {TrailBlazer}
	
	^self domain coordinateSpace emptyRegion!
*/
}

/**
 * it's OK
 */
public void checkTrailBlazer(TrailBlazer blazer) {
throw new UnsupportedOperationException();/*
udanax-top.st:9260:OVirtualLoaf methodsFor: 'backfollow'!
{void} checkTrailBlazer: blazer {TrailBlazer}
	
	"it's OK"!
*/
}

public TrailBlazer fetchTrailBlazer() {
throw new UnsupportedOperationException();/*
udanax-top.st:9264:OVirtualLoaf methodsFor: 'backfollow'!
{TrailBlazer | NULL} fetchTrailBlazer
	
	^NULL!
*/
}

public void triggerDetector(FeFillRangeDetector detect) {
throw new UnsupportedOperationException();/*
udanax-top.st:9268:OVirtualLoaf methodsFor: 'backfollow'!
{void} triggerDetector: detect {FeFillRangeDetector}
	
	detect rangeFilled: self asFeEdition!
*/
}

public  OVirtualLoaf(Rcvr receiver) {
	super(receiver);
throw new UnsupportedOperationException();/*
udanax-top.st:9274:OVirtualLoaf methodsFor: 'generated:'!
create.Rcvr: receiver {Rcvr}
	super create.Rcvr: receiver.
	myOwner _ receiver receiveHeaper.
	myData _ receiver receiveHeaper.!
*/
}

public void sendSelfTo(Xmtr xmtr) {
throw new UnsupportedOperationException();/*
udanax-top.st:9279:OVirtualLoaf methodsFor: 'generated:'!
{void} sendSelfTo: xmtr {Xmtr}
	super sendSelfTo: xmtr.
	xmtr sendHeaper: myOwner.
	xmtr sendHeaper: myData.!
*/
}
}
