/*
 * Abora-Gold
 * Part of the Abora hypertext project: http://www.abora.org
 * Copyright 2003 David G Jones
 * 
 * Translated from Udanax-Gold source code: http://www.udanax.com
 * Copyright 1979-1999 Udanax.com. All rights reserved
 */
package org.abora.gold.be.ents;

import java.io.PrintWriter;
import org.abora.gold.arrange.Arrangement;
import org.abora.gold.backrec.ResultRecorder;
import org.abora.gold.be.basic.BeEdition;
import org.abora.gold.be.basic.BeLabel;
import org.abora.gold.be.basic.BeRangeElement;
import org.abora.gold.be.basic.ID;
import org.abora.gold.be.canopy.BertCrum;
import org.abora.gold.be.canopy.PropFinder;
import org.abora.gold.be.ents.HUpperCrum;
import org.abora.gold.be.ents.HistoryCrum;
import org.abora.gold.be.ents.OExpandingLoaf;
import org.abora.gold.be.ents.OPart;
import org.abora.gold.be.ents.OrglRoot;
import org.abora.gold.collection.basic.PrimArray;
import org.abora.gold.collection.cache.HashSetCache;
import org.abora.gold.collection.steppers.Stepper;
import org.abora.gold.detect.FeFillRangeDetector;
import org.abora.gold.fossil.RecorderFossil;
import org.abora.gold.java.missing.XnSensor;
import org.abora.gold.nkernel.FeRangeElement;
import org.abora.gold.snarf.FlockInfo;
import org.abora.gold.spaces.basic.Dsp;
import org.abora.gold.spaces.basic.Mapping;
import org.abora.gold.spaces.basic.OrderSpec;
import org.abora.gold.spaces.basic.Position;
import org.abora.gold.spaces.basic.XnRegion;
import org.abora.gold.tclude.TrailBlazer;
import org.abora.gold.traces.TracePosition;
import org.abora.gold.turtle.Agenda;
import org.abora.gold.x.PrimSpec;
import org.abora.gold.xcvr.Rcvr;
import org.abora.gold.xcvr.Xmtr;


public class RegionLoaf extends OExpandingLoaf {
	protected BeRangeElement myRangeElement;
	protected BeLabel myLabel;
/*
udanax-top.st:9284:
OExpandingLoaf subclass: #RegionLoaf
	instanceVariableNames: '
		myRangeElement {BeRangeElement}
		myLabel {BeLabel}'
	classVariableNames: ''
	poolDictionaries: ''
	category: 'Xanadu-Be-Ents'!
*/
/*
udanax-top.st:9290:
(RegionLoaf getOrMakeCxxClassDescription)
	attributes: ((Set new) add: #COPY; add: #SHEPHERD.ANCESTOR; add: #LOCKED; add: #NOT.A.TYPE; add: #CONCRETE; yourself)!
*/

/**
 * return a mapping from my data to corresponding stuff in the given trace
 */
public Mapping compare(TracePosition trace, XnRegion region) {
throw new UnsupportedOperationException();/*
udanax-top.st:9295:RegionLoaf methodsFor: 'accessing'!
{Mapping} compare: trace {TracePosition} with: region {XnRegion}
	"return a mapping from my data to corresponding stuff in the given trace"
	^myRangeElement mappingTo: trace with: (region coordinateSpace identityDsp restrict: region)!
*/
}

/**
 * Make a virtual DataHolder.
 */
public FeRangeElement fetch(Position key, BeEdition edition, Position globalKey) {
throw new UnsupportedOperationException();/*
udanax-top.st:9299:RegionLoaf methodsFor: 'accessing'!
{FeRangeElement | NULL} fetch: key {Position} with: edition {BeEdition} with: globalKey {Position}
	"Make a virtual DataHolder."
	(self domain hasMember: key)
		ifTrue: [^myRangeElement makeFe: myLabel]
		ifFalse: [^NULL]!
*/
}

/**
 * Make an FeRangeElement for each position.
 */
public void fill(XnRegion keys, Arrangement toArrange, PrimArray toArray, Dsp dsp, BeEdition edition) {
throw new UnsupportedOperationException();/*
udanax-top.st:9306:RegionLoaf methodsFor: 'accessing'!
{void} fill: keys {XnRegion} with: toArrange {Arrangement} with: toArray {PrimArray} with: dsp {Dsp} with: edition {BeEdition} 
	"Make an FeRangeElement for each position."
	
	(keys intersect: self domain) stepper forEach: 
		[:key {Position} |
		| globalKey {Position} fe {FeRangeElement} |
		globalKey _ dsp of: key.
		fe := myRangeElement makeFe: myLabel.
		toArray at: (toArrange indexOf: globalKey) DOTasLong
			storeValue: fe]!
*/
}

public void forwardTo(BeRangeElement rangeElement) {
throw new UnsupportedOperationException();/*
udanax-top.st:9317:RegionLoaf methodsFor: 'accessing'!
{void} forwardTo: rangeElement {BeRangeElement}
	DiskManager consistent:
		[rangeElement addOParent: self.
		myRangeElement removeOParent: self.
		myRangeElement _ rangeElement.
		self diskUpdate].
	Ravi thingToDo. "Is there a lazier way to make the FeEdition?"
	self hCrum bertCrum isSensorWaiting ifTrue:
		[self hCrum ringDetectors: self asFeEdition]!
*/
}

/**
 * If I'm here it must be non-virtual.
 */
public BeRangeElement getBe(Position key) {
throw new UnsupportedOperationException();/*
udanax-top.st:9328:RegionLoaf methodsFor: 'accessing'!
{BeRangeElement} getBe: key {Position}
	"If I'm here it must be non-virtual."
	(self domain hasMember: key)
		ifTrue: [^myRangeElement]
		ifFalse: [Heaper BLAST: #NotInTable.  ^NULL]!
*/
}

/**
 * The keys in this Edition at which there are Editions with the given label.
 */
public XnRegion keysLabelled(BeLabel label) {
throw new UnsupportedOperationException();/*
udanax-top.st:9335:RegionLoaf methodsFor: 'accessing'!
{XnRegion} keysLabelled: label {BeLabel}
	"The keys in this Edition at which there are Editions with the given label."
	
	(myLabel ~~ NULL and: [myLabel isEqual: label])
		ifTrue: [^self domain]
		ifFalse: [^self domain coordinateSpace emptyRegion]!
*/
}

/**
 * return the mapping into the domain space of the given trace
 */
public Mapping mappingTo(TracePosition trace, Mapping initial) {
throw new UnsupportedOperationException();/*
udanax-top.st:9342:RegionLoaf methodsFor: 'accessing'!
{Mapping} mappingTo: trace {TracePosition} with: initial {Mapping}
	"return the mapping into the domain space of the given trace"
	^self hCrum mappingTo: trace
		with: ((Mapping make: initial coordinateSpace with: self domain) restrict: initial domain)!
*/
}

/**
 * Return the owner of the atoms represented by the receiver.
 */
public ID owner() {
throw new UnsupportedOperationException();/*
udanax-top.st:9347:RegionLoaf methodsFor: 'accessing'!
{ID} owner
	"Return the owner of the atoms represented by the receiver."
	
	^myRangeElement owner!
*/
}

/**
 * Return a region describing the stuff that can backfollow to trace.  Redefine this to pass
 * down to my hRoot.
 */
public XnRegion sharedRegion(TracePosition trace, XnRegion limitRegion) {
throw new UnsupportedOperationException();/*
udanax-top.st:9352:RegionLoaf methodsFor: 'accessing'!
{XnRegion} sharedRegion: trace {TracePosition} with: limitRegion {XnRegion unused}
	"Return a region describing the stuff that can backfollow to trace.  Redefine this to pass down to my hRoot."
	(myRangeElement inTrace: trace)
		ifTrue: [^self domain]
		ifFalse: [^self domain coordinateSpace emptyRegion]!
*/
}

/**
 * Return the PrimSpec that describes the representation of the data.
 */
public PrimSpec spec() {
throw new UnsupportedOperationException();/*
udanax-top.st:9358:RegionLoaf methodsFor: 'accessing'!
{PrimSpec} spec
	"Return the PrimSpec that describes the representation of the data."
	
	self unimplemented.
	^PrimSpec pointer!
*/
}

public XnRegion usedDomain() {
throw new UnsupportedOperationException();/*
udanax-top.st:9364:RegionLoaf methodsFor: 'accessing'!
{XnRegion} usedDomain
	^self domain!
*/
}

/**
 * Return a stepper of bundles according to the order.
 */
public Stepper bundleStepper(XnRegion region, OrderSpec order, Dsp globalDsp) {
throw new UnsupportedOperationException();/*
udanax-top.st:9369:RegionLoaf methodsFor: 'operations'!
{Stepper} bundleStepper: region {XnRegion} with: order {OrderSpec} with: globalDsp {Dsp} 
	"Return a stepper of bundles according to the order."
	| bundleRegion {XnRegion} |
	bundleRegion _ region intersect: (globalDsp ofAll: self domain).
	bundleRegion isEmpty ifTrue: [^Stepper emptyStepper].
	^Stepper itemStepper: 
		(FeElementBundle 
			make: bundleRegion 
			with: (myRangeElement makeFe: myLabel))!
*/
}

public void informTo(OrglRoot orgl) {
throw new UnsupportedOperationException();/*
udanax-top.st:9380:RegionLoaf methodsFor: 'operations'!
{void} informTo: orgl {OrglRoot unused}
	self unimplemented!
*/
}

/**
 * If the CurrentKeyMaster includes the owner of this loaf
 * then change the owner and return NULL
 * else just return self.
 */
public OrglRoot setAllOwners(ID owner) {
throw new UnsupportedOperationException();/*
udanax-top.st:9383:RegionLoaf methodsFor: 'operations'!
{OrglRoot} setAllOwners: owner {ID} 
	"If the CurrentKeyMaster includes the owner of this loaf
		then change the owner and return NULL
		else just return self."
	
	(CurrentKeyMaster fluidGet hasAuthority: myRangeElement owner)
		ifTrue:
			[myRangeElement setOwner: owner.
			^OrglRoot make: self domain coordinateSpace]
		ifFalse: [^ActualOrglRoot make: self with: self domain]!
*/
}

public void printOn(PrintWriter aStream) {
throw new UnsupportedOperationException();/*
udanax-top.st:9396:RegionLoaf methodsFor: 'printing'!
{void} printOn: aStream {ostream reference}
	aStream << self getCategory name << '(' << self domain << ', ' << myRangeElement << ')'!
*/
}

/**
 * Don't expand me in place.  Just move it closer to the top.
 */
public byte actualSoftSplay(XnRegion region, XnRegion limitRegion) {
throw new UnsupportedOperationException();/*
udanax-top.st:9401:RegionLoaf methodsFor: 'protected: splay'!
{Int8} actualSoftSplay: region {XnRegion} with: limitRegion {XnRegion unused} 
	"Don't expand me in place.  Just move it closer to the top."
	
	^2!
*/
}

/**
 * Expand my partial tree in place.  The area in the region must go
 * into the leftCrum of my substitute, or the splay algorithm will fail!!
 */
public byte actualSplay(XnRegion region, XnRegion limitRegion) {
throw new UnsupportedOperationException();/*
udanax-top.st:9406:RegionLoaf methodsFor: 'protected: splay'!
{Int8} actualSplay: region {XnRegion} with: limitRegion {XnRegion unused}
	"Expand my partial tree in place.  The area in the region must go
	 into the leftCrum of my substitute, or the splay algorithm will fail!!"
	
	| tmp1 {Loaf} tmp2 {Loaf} |
	DiskManager consistent: 4 with:
		[tmp1 _ RegionLoaf
			create: (self domain intersect: region)
			with: myLabel
			with: myRangeElement
			with: (HUpperCrum make: (self hCrum cast: HUpperCrum))].
	DiskManager consistent: 4 with:
		[tmp2 _ RegionLoaf
			create: (self domain intersect: region complement)
			with: myLabel
			with: myRangeElement
			with: (HUpperCrum make: (self hCrum cast: HUpperCrum))].
	DiskManager consistent: 4 with:
		[ | hcrum {HUpperCrum} hash {UInt32} info {FlockInfo} |
		hcrum _ self hCrum cast: HUpperCrum.
		hash _ self hashForEqual.
		info _ self fetchInfo.
		(SplitLoaf new.Become: self) 
			create: region 
			with: tmp1 
			with: tmp2 
			with: hcrum 
			with: hash 
			with: info].
	^1!
*/
}

public  RegionLoaf(XnRegion region, BeLabel label, BeRangeElement element, HUpperCrum hcrum) {
	super(region, hcrum, element.sensorCrum());
throw new UnsupportedOperationException();/*
udanax-top.st:9439:RegionLoaf methodsFor: 'create'!
create: region {XnRegion} with: label {BeLabel | NULL} with: element {BeRangeElement} with: hcrum {HUpperCrum | NULL}
	super create: region with: hcrum with: element sensorCrum.
	myLabel _ label.
	myRangeElement _ element.
	self newShepherd.
	myRangeElement addOParent: self.!
*/
}

public  RegionLoaf(XnRegion region, BeRangeElement element, HUpperCrum hcrum, int hash, FlockInfo info) {
	super(hash, region, hcrum, element.sensorCrum());
throw new UnsupportedOperationException();/*
udanax-top.st:9446:RegionLoaf methodsFor: 'create'!
create: region {XnRegion} with: element {BeRangeElement} with: hcrum {HUpperCrum} with: hash {UInt32} with: info {FlockInfo}
	super create: hash with: region with: hcrum with: element sensorCrum.
	(element isKindOf: BeEdition) ifTrue: [Heaper BLAST: #EditionsRequireLabels].
	myLabel _ NULL.  self knownBug.  "This doesn't deal with labels."
	self flockInfo: info.
	myRangeElement _ element.
	myRangeElement addOParent: self.
	self diskUpdate!
*/
}

/**
 * add oparent to the set of upward pointers and update the bertCrums my child.
 */
public void addOParent(OPart oparent) {
throw new UnsupportedOperationException();/*
udanax-top.st:9457:RegionLoaf methodsFor: 'backfollow'!
{void} addOParent: oparent {OPart} 
	"add oparent to the set of upward pointers and update the bertCrums my child."
	| bCrum {BertCrum} newBCrum {BertCrum} |
	bCrum _ self hCrum bertCrum.
	super addOParent: oparent.
	newBCrum _ self hCrum bertCrum.
	(bCrum isLE: newBCrum) not
		ifTrue: [myRangeElement updateBCrumTo: newBCrum]!
*/
}

public XnRegion attachTrailBlazer(TrailBlazer blazer) {
throw new UnsupportedOperationException();/*
udanax-top.st:9467:RegionLoaf methodsFor: 'backfollow'!
{XnRegion} attachTrailBlazer: blazer {TrailBlazer}
	
	myRangeElement cast: BePlaceHolder into: [ :p |
		p attachTrailBlazer: blazer.
		^self domain]
	others:
		[^self domain coordinateSpace emptyRegion]!
*/
}

public void checkChildRecorders(PropFinder finder) {
throw new UnsupportedOperationException();/*
udanax-top.st:9475:RegionLoaf methodsFor: 'backfollow'!
{void} checkChildRecorders: finder {PropFinder}
	myRangeElement checkRecorders: finder with: self sensorCrum!
*/
}

public void checkTrailBlazer(TrailBlazer blazer) {
throw new UnsupportedOperationException();/*
udanax-top.st:9479:RegionLoaf methodsFor: 'backfollow'!
{void} checkTrailBlazer: blazer {TrailBlazer}
	
	myRangeElement cast: BePlaceHolder into: [ :p |
		p checkTrailBlazer: blazer]
	others:
		["OK"]!
*/
}

/**
 * RegionLoaf is the one kind of o-leaf which actually shares range-element identity with
 * other o-leafs.  The range element identity is in myRangeElement rather than myself, so I
 * override my super's version of this method to forward it south one more step to
 * myRangeElement.
 */
public void delayedStoreMatching(PropFinder finder, RecorderFossil fossil, ResultRecorder recorder, HashSetCache hCrumCache) {
throw new UnsupportedOperationException();/*
udanax-top.st:9486:RegionLoaf methodsFor: 'backfollow'!
{void} delayedStoreMatching: finder {PropFinder} 
	with: fossil {RecorderFossil} 
	with: recorder {ResultRecorder}
	with: hCrumCache {HashSetCache of: HistoryCrum}
	"RegionLoaf is the one kind of o-leaf which actually shares range-element identity with other o-leafs.  The range element identity is in myRangeElement rather than myself, so I override my super's version of this method to forward it south one more step to myRangeElement."
	
	 recorder delayedStoreMatching: myRangeElement
	 	with: finder
	 	with: fossil
	 	with: hCrumCache!
*/
}

public TrailBlazer fetchTrailBlazer() {
throw new UnsupportedOperationException();/*
udanax-top.st:9497:RegionLoaf methodsFor: 'backfollow'!
{TrailBlazer | NULL} fetchTrailBlazer
	
	myRangeElement cast: BePlaceHolder into: [ :p |
		^p fetchTrailBlazer]
	others:
		[^NULL]!
*/
}

public void storeRecordingAgents(RecorderFossil recorder, Agenda agenda) {
throw new UnsupportedOperationException();/*
udanax-top.st:9504:RegionLoaf methodsFor: 'backfollow'!
{void} storeRecordingAgents: recorder {RecorderFossil}
	with: agenda {Agenda}  
	
	recorder storeRangeElementRecordingAgents: myRangeElement
		with: myRangeElement sensorCrum
		with: agenda!
*/
}

/**
 * Return true if child is a child.  Used for debugging.
 */
public boolean testHChild(HistoryCrum child) {
throw new UnsupportedOperationException();/*
udanax-top.st:9511:RegionLoaf methodsFor: 'backfollow'!
{BooleanVar} testHChild: child {HistoryCrum}
	"Return true if child is a child.  Used for debugging."
	
	^(myRangeElement hCrum basicCast: Heaper star) == child!
*/
}

public void triggerDetector(FeFillRangeDetector detect) {
throw new UnsupportedOperationException();/*
udanax-top.st:9516:RegionLoaf methodsFor: 'backfollow'!
{void} triggerDetector: detect {FeFillRangeDetector}
	
	(myRangeElement isKindOf: BePlaceHolder) ifFalse:
		[detect rangeFilled: self asFeEdition]!
*/
}

/**
 * My bertCrum must not be leafward of newBCrum.
 * Thus it must be LE to newCrum. Otherwise correct it and recur.
 */
public boolean updateBCrumTo(BertCrum newBCrum) {
throw new UnsupportedOperationException();/*
udanax-top.st:9521:RegionLoaf methodsFor: 'backfollow'!
{BooleanVar} updateBCrumTo: newBCrum {BertCrum} 
	"My bertCrum must not be leafward of newBCrum. 
	Thus it must be LE to newCrum. Otherwise correct it and recur."
	(super updateBCrumTo: newBCrum) ifTrue: 
		[myRangeElement updateBCrumTo: newBCrum.
		^true].
	^false!
*/
}

public void dismantle() {
throw new UnsupportedOperationException();/*
udanax-top.st:9532:RegionLoaf methodsFor: 'protected: delete'!
{void} dismantle
	DiskManager consistent: 4 with:
		[(Heaper isConstructed: myRangeElement) 
			ifTrue: [myRangeElement removeOParent: self].
		super dismantle]!
*/
}

public int contentsHash() {
throw new UnsupportedOperationException();/*
udanax-top.st:9540:RegionLoaf methodsFor: 'testing'!
{UInt32} contentsHash
	^super contentsHash
		bitXor: myRangeElement hashForEqual!
*/
}

public void wait(XnSensor sensor) {
throw new UnsupportedOperationException();/*
udanax-top.st:9547:RegionLoaf methodsFor: 'smalltalk: passe'!
{void} wait: sensor {XnSensor}
	
	self passe!
*/
}

public  RegionLoaf(Rcvr receiver) {
	super(receiver);
throw new UnsupportedOperationException();/*
udanax-top.st:9553:RegionLoaf methodsFor: 'generated:'!
create.Rcvr: receiver {Rcvr}
	super create.Rcvr: receiver.
	myRangeElement _ receiver receiveHeaper.
	myLabel _ receiver receiveHeaper.!
*/
}

public void sendSelfTo(Xmtr xmtr) {
throw new UnsupportedOperationException();/*
udanax-top.st:9558:RegionLoaf methodsFor: 'generated:'!
{void} sendSelfTo: xmtr {Xmtr}
	super sendSelfTo: xmtr.
	xmtr sendHeaper: myRangeElement.
	xmtr sendHeaper: myLabel.!
*/
}
}
