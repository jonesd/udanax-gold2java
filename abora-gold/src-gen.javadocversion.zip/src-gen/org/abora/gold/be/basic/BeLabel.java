/*
 * Abora-Gold
 * Part of the Abora hypertext project: http://www.abora.org
 * Copyright 2003 David G Jones
 * 
 * Translated from Udanax-Gold source code: http://www.udanax.com
 * Copyright 1979-1999 Udanax.com. All rights reserved
 */
package org.abora.gold.be.basic;

import org.abora.gold.be.basic.BeLabel;
import org.abora.gold.be.basic.BeRangeElement;
import org.abora.gold.nkernel.FeRangeElement;
import org.abora.gold.xcvr.Rcvr;
import org.abora.gold.xcvr.Xmtr;


public class BeLabel extends BeRangeElement {
/*
udanax-top.st:3391:
BeRangeElement subclass: #BeLabel
	instanceVariableNames: ''
	classVariableNames: ''
	poolDictionaries: ''
	category: 'Xanadu-Be-Basic'!
*/
/*
udanax-top.st:3395:
(BeLabel getOrMakeCxxClassDescription)
	attributes: ((Set new) add: #LOCKED; add: #COPY; add: #SHEPHERD.PATRIARCH; add: #CONCRETE; yourself)!
*/

public FeRangeElement makeFe(BeLabel label) {
throw new UnsupportedOperationException();/*
udanax-top.st:3400:BeLabel methodsFor: 'accessing'!
{FeRangeElement} makeFe: label {BeLabel | NULL}
	^FeLabel on: self!
*/
}

public  BeLabel() {
throw new UnsupportedOperationException();/*
udanax-top.st:3405:BeLabel methodsFor: 'creation'!
create
	super create.
	self newShepherd.
	self hack.  "Labels don't know when they're pointed to as labels instead of range elements, so just remember them."
	self remember!
*/
}

public  BeLabel(Rcvr receiver) {
throw new UnsupportedOperationException();/*
udanax-top.st:3413:BeLabel methodsFor: 'generated:'!
create.Rcvr: receiver {Rcvr}
	super create.Rcvr: receiver.!
*/
}

public void sendSelfTo(Xmtr xmtr) {
throw new UnsupportedOperationException();/*
udanax-top.st:3416:BeLabel methodsFor: 'generated:'!
{void} sendSelfTo: xmtr {Xmtr}
	super sendSelfTo: xmtr.!
*/
}
}
