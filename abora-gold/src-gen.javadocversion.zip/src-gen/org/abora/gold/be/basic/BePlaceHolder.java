/*
 * Abora-Gold
 * Part of the Abora hypertext project: http://www.abora.org
 * Copyright 2003 David G Jones
 * 
 * Translated from Udanax-Gold source code: http://www.udanax.com
 * Copyright 1979-1999 Udanax.com. All rights reserved
 */
package org.abora.gold.be.basic;

import org.abora.gold.be.basic.BeLabel;
import org.abora.gold.be.basic.BeRangeElement;
import org.abora.gold.detect.FeFillDetector;
import org.abora.gold.nkernel.FeRangeElement;
import org.abora.gold.primtab.PrimSet;
import org.abora.gold.tclude.TrailBlazer;
import org.abora.gold.xcvr.Rcvr;
import org.abora.gold.xcvr.Xmtr;


public class BePlaceHolder extends BeRangeElement {
	protected TrailBlazer myTrailBlazer;
	protected PrimSet myDetectors;
/*
udanax-top.st:3419:
BeRangeElement subclass: #BePlaceHolder
	instanceVariableNames: '
		myTrailBlazer {TrailBlazer | NULL}
		myDetectors {PrimSet NOCOPY | NULL of: FeFillDetector}'
	classVariableNames: ''
	poolDictionaries: ''
	category: 'Xanadu-Be-Basic'!
*/
/*
udanax-top.st:3425:
(BePlaceHolder getOrMakeCxxClassDescription)
	attributes: ((Set new) add: #LOCKED; add: #COPY; add: #SHEPHERD.PATRIARCH; add: #CONCRETE; yourself)!
*/

public void addDetector(FeFillDetector detector) {
throw new UnsupportedOperationException();/*
udanax-top.st:3430:BePlaceHolder methodsFor: 'accessing'!
{void} addDetector: detector {FeFillDetector}
	myDetectors == NULL ifTrue:
		[myDetectors := PrimSet weak: 7 with: (FillDetectorExecutor make: self)].
	myDetectors store: detector!
*/
}

public boolean isPurgeable() {
throw new UnsupportedOperationException();/*
udanax-top.st:3436:BePlaceHolder methodsFor: 'accessing'!
{BooleanVar} isPurgeable
	^super isPurgeable and: [myDetectors == NULL]!
*/
}

public FeRangeElement makeFe(BeLabel label) {
throw new UnsupportedOperationException();/*
udanax-top.st:3439:BePlaceHolder methodsFor: 'accessing'!
{FeRangeElement} makeFe: label {BeLabel | NULL}
	^FePlaceHolder on: self!
*/
}

/**
 * Change the identity of this object to that of the other.
 */
public boolean makeIdentical(BeRangeElement other) {
throw new UnsupportedOperationException();/*
udanax-top.st:3442:BePlaceHolder methodsFor: 'accessing'!
{BooleanVar} makeIdentical: other {BeRangeElement}
	"Change the identity of this object to that of the other."
	
	"Make all my persistent oParents point at the other guy.
	make all the session level FeRangeElements point at the other guy."
	
	| oParents {ScruSet of: OPart} |
	oParents _ self hCrum oParents.
	self knownBug. "if there are several oParents then a given Detector may be rung more than once"
	DiskManager consistent: -1 with:
		[oParents stepper forEach: 
			[:loaf {Loaf} |
			(loaf cast: RegionLoaf) forwardTo: other]].
	self feRangeElements stepper forEach: 
		[:elem {FePlaceHolder} |
		(elem cast: FeActualPlaceHolder) forwardTo: other].
	myDetectors ~~ NULL ifTrue:
		[ | fe {FeRangeElement} |
		other cast: BeEdition into: [ :ed |
			fe := ed makeFe: CurrentGrandMap fluidGet newLabel]
		others:
			[fe := other makeFe: NULL].
		myDetectors stepper forEach: [ :det {FeFillDetector} |
			det filled: fe]].
	^false "fodder"!
*/
}

public void removeDetector(FeFillDetector detector) {
throw new UnsupportedOperationException();/*
udanax-top.st:3468:BePlaceHolder methodsFor: 'accessing'!
{void} removeDetector: detector {FeFillDetector}
	(Heaper isDestructed: myDetectors) ifTrue:
		[^VOID].
	myDetectors == NULL ifTrue:
		[Heaper BLAST: #NotInSet].
	myDetectors remove: detector.
	myDetectors isEmpty ifTrue:
		[myDetectors := NULL].!
*/
}

public void removeLastDetector() {
throw new UnsupportedOperationException();/*
udanax-top.st:3478:BePlaceHolder methodsFor: 'accessing'!
{void} removeLastDetector
	myDetectors := NULL!
*/
}

public  BePlaceHolder() {
throw new UnsupportedOperationException();/*
udanax-top.st:3484:BePlaceHolder methodsFor: 'creation'!
create
	super create: SensorCrum partial.
	myTrailBlazer := NULL.
	myDetectors := NULL.
	self newShepherd!
*/
}

public  BePlaceHolder(TrailBlazer blazer) {
throw new UnsupportedOperationException();/*
udanax-top.st:3490:BePlaceHolder methodsFor: 'creation'!
create: blazer {TrailBlazer | NULL}
	super create: SensorCrum partial.
	myTrailBlazer := blazer.
	blazer ~~ NULL ifTrue:
		[blazer addReference: self].
	myDetectors := NULL.
	self newShepherd!
*/
}

public void attachTrailBlazer(TrailBlazer blazer) {
throw new UnsupportedOperationException();/*
udanax-top.st:3500:BePlaceHolder methodsFor: 'backfollow'!
{void} attachTrailBlazer: blazer {TrailBlazer}
	
	DiskManager consistent: 3 with:
		[myTrailBlazer ~~ NULL ifTrue:
			[myTrailBlazer isAlive
				ifTrue: [Heaper BLAST: #FatalError]
				ifFalse: [myTrailBlazer removeReference: self]].
		myTrailBlazer := blazer.
		blazer addReference: self.
		self diskUpdate]!
*/
}

public void checkTrailBlazer(TrailBlazer blazer) {
throw new UnsupportedOperationException();/*
udanax-top.st:3511:BePlaceHolder methodsFor: 'backfollow'!
{void} checkTrailBlazer: blazer {TrailBlazer}
	(myTrailBlazer ~~ NULL and: [myTrailBlazer isEqual: blazer])
		ifFalse: [Heaper BLAST: #InvalidTrail]!
*/
}

public TrailBlazer fetchTrailBlazer() {
throw new UnsupportedOperationException();/*
udanax-top.st:3516:BePlaceHolder methodsFor: 'backfollow'!
{TrailBlazer | NULL} fetchTrailBlazer
	
	(myTrailBlazer == NULL or: [myTrailBlazer isAlive])
		ifTrue: [^myTrailBlazer].
	"it was not successfully attached, so clean it up"
	DiskManager consistent: 2 with:
		[myTrailBlazer removeReference: self.
		myTrailBlazer := NULL.
		self diskUpdate.
		^NULL]!
*/
}

public void restartP(Rcvr rcvr) {
throw new UnsupportedOperationException();/*
udanax-top.st:3529:BePlaceHolder methodsFor: 'hooks:'!
{void RECEIVE.HOOK} restartP: rcvr {Rcvr unused}
	myDetectors := NULL.!
*/
}

public  BePlaceHolder(Rcvr receiver) {
throw new UnsupportedOperationException();/*
udanax-top.st:3535:BePlaceHolder methodsFor: 'generated:'!
create.Rcvr: receiver {Rcvr}
	super create.Rcvr: receiver.
	myTrailBlazer _ receiver receiveHeaper.
	self restartP: receiver.!
*/
}

public void sendSelfTo(Xmtr xmtr) {
throw new UnsupportedOperationException();/*
udanax-top.st:3540:BePlaceHolder methodsFor: 'generated:'!
{void} sendSelfTo: xmtr {Xmtr}
	super sendSelfTo: xmtr.
	xmtr sendHeaper: myTrailBlazer.!
*/
}
}
