/*
 * Abora-Gold
 * Part of the Abora hypertext project: http://www.abora.org
 * Copyright 2003 David G Jones
 * 
 * Translated from Udanax-Gold source code: http://www.udanax.com
 * Copyright 1979-1999 Udanax.com. All rights reserved
 */
package org.abora.gold.be.basic;

import org.abora.gold.be.basic.BeLabel;
import org.abora.gold.be.basic.BeRangeElement;
import org.abora.gold.nkernel.FeRangeElement;
import org.abora.gold.x.PrimValue;
import org.abora.gold.xcvr.Rcvr;
import org.abora.gold.xcvr.Xmtr;


public class BeDataHolder extends BeRangeElement {
	protected PrimValue myValue;
/*
udanax-top.st:2469:
BeRangeElement subclass: #BeDataHolder
	instanceVariableNames: 'myValue {PrimValue}'
	classVariableNames: ''
	poolDictionaries: ''
	category: 'Xanadu-Be-Basic'!
*/
/*
udanax-top.st:2473:
(BeDataHolder getOrMakeCxxClassDescription)
	attributes: ((Set new) add: #LOCKED; add: #COPY; add: #SHEPHERD.PATRIARCH; add: #CONCRETE; yourself)!
*/

/**
 * Return me wrapped with a session level DataHolder.
 */
public FeRangeElement makeFe(BeLabel label) {
throw new UnsupportedOperationException();/*
udanax-top.st:2478:BeDataHolder methodsFor: 'accessing'!
{FeRangeElement} makeFe: label {BeLabel | NULL}
	"Return me wrapped with a session level DataHolder."
	
	^FeDataHolder on: self!
*/
}

public PrimValue value() {
throw new UnsupportedOperationException();/*
udanax-top.st:2483:BeDataHolder methodsFor: 'accessing'!
{PrimValue} value
	^myValue!
*/
}

public  BeDataHolder(PrimValue value) {
throw new UnsupportedOperationException();/*
udanax-top.st:2488:BeDataHolder methodsFor: 'create'!
create: value {PrimValue}
	super create.
	myValue := value.
	self newShepherd!
*/
}

public  BeDataHolder(Rcvr receiver) {
throw new UnsupportedOperationException();/*
udanax-top.st:2496:BeDataHolder methodsFor: 'generated:'!
create.Rcvr: receiver {Rcvr}
	super create.Rcvr: receiver.
	myValue _ receiver receiveHeaper.!
*/
}

public void sendSelfTo(Xmtr xmtr) {
throw new UnsupportedOperationException();/*
udanax-top.st:2500:BeDataHolder methodsFor: 'generated:'!
{void} sendSelfTo: xmtr {Xmtr}
	super sendSelfTo: xmtr.
	xmtr sendHeaper: myValue.!
*/
}
}
