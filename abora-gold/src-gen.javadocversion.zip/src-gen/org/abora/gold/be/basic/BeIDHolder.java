/*
 * Abora-Gold
 * Part of the Abora hypertext project: http://www.abora.org
 * Copyright 2003 David G Jones
 * 
 * Translated from Udanax-Gold source code: http://www.udanax.com
 * Copyright 1979-1999 Udanax.com. All rights reserved
 */
package org.abora.gold.be.basic;

import org.abora.gold.be.basic.BeLabel;
import org.abora.gold.be.basic.BeRangeElement;
import org.abora.gold.be.basic.ID;
import org.abora.gold.nkernel.FeRangeElement;
import org.abora.gold.xcvr.Rcvr;
import org.abora.gold.xcvr.Xmtr;
import org.abora.gold.xpp.basic.Heaper;


public class BeIDHolder extends BeRangeElement {
	protected ID myID;
/*
udanax-top.st:3340:
BeRangeElement subclass: #BeIDHolder
	instanceVariableNames: 'myID {ID}'
	classVariableNames: ''
	poolDictionaries: ''
	category: 'Xanadu-Be-Basic'!
*/
/*
udanax-top.st:3344:
(BeIDHolder getOrMakeCxxClassDescription)
	attributes: ((Set new) add: #LOCKED; add: #COPY; add: #SHEPHERD.PATRIARCH; add: #CONCRETE; yourself)!
*/
/*
udanax-top.st:3380:
BeIDHolder class
	instanceVariableNames: ''!
*/
/*
udanax-top.st:3383:
(BeIDHolder getOrMakeCxxClassDescription)
	attributes: ((Set new) add: #LOCKED; add: #COPY; add: #SHEPHERD.PATRIARCH; add: #CONCRETE; yourself)!
*/

public ID iD() {
throw new UnsupportedOperationException();/*
udanax-top.st:3349:BeIDHolder methodsFor: 'accessing'!
{ID} iD
	^myID!
*/
}

public FeRangeElement makeFe(BeLabel label) {
throw new UnsupportedOperationException();/*
udanax-top.st:3352:BeIDHolder methodsFor: 'accessing'!
{FeRangeElement} makeFe: label {BeLabel | NULL}
	^FeIDHolder on: self!
*/
}

/**
 * Does this need to clear the GrandMap table?
 */
public void dismantle() {
throw new UnsupportedOperationException();/*
udanax-top.st:3357:BeIDHolder methodsFor: 'protected: dismantle'!
{void} dismantle
	"Does this need to clear the GrandMap table?"
	
	self unimplemented!
*/
}

public  BeIDHolder(ID iD) {
throw new UnsupportedOperationException();/*
udanax-top.st:3364:BeIDHolder methodsFor: 'protected: creation'!
create: iD {ID}
	super create.
	myID _ iD.
	self newShepherd!
*/
}

public  BeIDHolder(Rcvr receiver) {
throw new UnsupportedOperationException();/*
udanax-top.st:3371:BeIDHolder methodsFor: 'generated:'!
create.Rcvr: receiver {Rcvr}
	super create.Rcvr: receiver.
	myID _ receiver receiveHeaper.!
*/
}

public void sendSelfTo(Xmtr xmtr) {
throw new UnsupportedOperationException();/*
udanax-top.st:3375:BeIDHolder methodsFor: 'generated:'!
{void} sendSelfTo: xmtr {Xmtr}
	super sendSelfTo: xmtr.
	xmtr sendHeaper: myID.!
*/
}

public static Heaper make(ID iD) {
throw new UnsupportedOperationException();/*
udanax-top.st:3388:BeIDHolder class methodsFor: 'creation'!
make: iD {ID}
	^ self create: iD!
*/
}
}
