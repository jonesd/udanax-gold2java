/*
 * Abora-Gold
 * Part of the Abora hypertext project: http://www.abora.org
 * Copyright 2003 David G Jones
 * 
 * Translated from Udanax-Gold source code: http://www.udanax.com
 * Copyright 1979-1999 Udanax.com. All rights reserved
 */
package org.abora.gold.snarf;

import org.abora.gold.cobbler.Cookbook;
import org.abora.gold.collection.sets.MuSet;
import org.abora.gold.collection.tables.IntegerTable;
import org.abora.gold.java.missing.IntegerVar;
import org.abora.gold.java.missing.SnarfID;
import org.abora.gold.snarf.Abraham;
import org.abora.gold.snarf.DiskManager;
import org.abora.gold.snarf.FlockInfo;
import org.abora.gold.snarf.TestPacker;
import org.abora.gold.snarf.Turtle;
import org.abora.gold.xcvr.SpecialistRcvr;
import org.abora.gold.xcvr.SpecialistXmtr;
import org.abora.gold.xcvr.XcvrMaker;
import org.abora.gold.xcvr.XnReadStream;
import org.abora.gold.xcvr.XnWriteStream;
import org.abora.gold.xpp.basic.Heaper;


/**
 * Does not actually go to disk, but just tests that the protocol is being followed
 * correctly. Some of these tests may make it into the real SnarfPacker, but some of them
 * will remain debugging tools. Most operations only do enough real stuff to be able to check
 * that they work.
 * The TestPacker holds onto an IntegerTable of UInt8Arrays that contain the disk
 * representations of all the flocks.  It also holds
 * myDisk contains a UInt8Array for every flock that made it to disk.  They are assigned
 * sequential numbers.
 * myNewFlocks contains the flockInfos for new flocks, and thus contains the new flocks
 * wimpily.
 * myAlmostNewFlocks contains flocks that are under construction but have not yet finished.
 * myDestroyedFlocks contains flocks that will be destroyed upon exiting the current
 * consistent block.
 * myChangedFlocks points strongly at flocks that must be rewritten to disk.
 */
public class TestPacker extends DiskManager {
	protected int myNextHash;
	protected Abraham myInitialFlock;
	protected IntegerTable myFlocks;
	protected IntegerTable myChangedFlocks;
	protected IntegerTable myDestroyedFlocks;
	protected MuSet myAlmostNewFlocks;
	protected IntegerTable myNewFlocks;
	protected XcvrMaker myXcvrMaker;
	protected IntegerVar myCountDown;
	protected IntegerVar myPersistInterval;
	protected IntegerTable myDisk;
	protected Cookbook myBook;
	protected boolean amCommitting;
	protected boolean blastOnError;
/*
udanax-top.st:17648:
DiskManager subclass: #TestPacker
	instanceVariableNames: '
		myNextHash {UInt32}
		myInitialFlock {Abraham}
		myFlocks {IntegerTable of: FlockInfo}
		myChangedFlocks {IntegerTable of: Abraham}
		myDestroyedFlocks {IntegerTable of: Abraham}
		myAlmostNewFlocks {MuSet of: Abraham}
		myNewFlocks {IntegerTable of: FlockInfo}
		myXcvrMaker {XcvrMaker}
		myCountDown {IntegerVar}
		myPersistInterval {IntegerVar}
		myDisk {IntegerTable of: UInt8Array}
		myBook {Cookbook}
		amCommitting {BooleanVar}
		blastOnError {BooleanVar}'
	classVariableNames: ''
	poolDictionaries: ''
	category: 'Xanadu-Snarf'!
*/
/*
udanax-top.st:17666:
TestPacker comment:
'Does not actually go to disk, but just tests that the protocol is being followed correctly. Some of these tests may make it into the real SnarfPacker, but some of them will remain debugging tools. Most operations only do enough real stuff to be able to check that they work.
The TestPacker holds onto an IntegerTable of UInt8Arrays that contain the disk representations of all the flocks.  It also holds 
myDisk contains a UInt8Array for every flock that made it to disk.  They are assigned sequential numbers.
myNewFlocks contains the flockInfos for new flocks, and thus contains the new flocks wimpily.
myAlmostNewFlocks contains flocks that are under construction but have not yet finished.
myDestroyedFlocks contains flocks that will be destroyed upon exiting the current consistent block.
myChangedFlocks points strongly at flocks that must be rewritten to disk.
'!
*/
/*
udanax-top.st:17678:
(TestPacker getOrMakeCxxClassDescription)
	friends:
'friend class EndCommit_Bomb;';
	attributes: ((Set new) add: #CONCRETE; yourself)!
*/
/*
udanax-top.st:18117:
TestPacker class
	instanceVariableNames: ''!
*/
/*
udanax-top.st:18120:
(TestPacker getOrMakeCxxClassDescription)
	friends:
'friend class EndCommit_Bomb;';
	attributes: ((Set new) add: #CONCRETE; yourself)!
*/

/**
 * Queue destroy of the given flock.  The destroy will probably happen later.
 */
public void destroyFlock(FlockInfo info) {
throw new UnsupportedOperationException();/*
udanax-top.st:17685:TestPacker methodsFor: 'shepherds'!
{void} destroyFlock: info {FlockInfo} 
	"Queue destroy of the given flock.  The destroy will probably happen later."
	| flock {Abraham} |
	flock _ info getShepherd cast: Abraham. "Check for destructed essentially"
	self mustKnowShepherd: info.
	self mustBeInsideTransaction.
	self mustNotBeCommitting.
	self countDown.
	
	info markDestroyed.
	info markForgotten ifTrue: [self recordUpdate: info].
	myDestroyedFlocks atInt: myDestroyedFlocks count introduce: flock!
*/
}

public void diskUpdate(FlockInfo info) {
throw new UnsupportedOperationException();/*
udanax-top.st:17699:TestPacker methodsFor: 'shepherds'!
{void} diskUpdate: info {FlockInfo} 
	info == NULL ifTrue: [^VOID].  "noop for new shepherds."
	self mustKnowShepherd: info.
	self mustBeInsideTransaction.
	self mustNotBeCommitting.
	self countDown.
	info markContentsDirty
		ifTrue: [self recordUpdate: info]
		ifFalse: 
			["sanity check"
			info isNew
				ifTrue: [(myNewFlocks includesIntKey: info index) assert: 'Something is wrong']
				ifFalse: [(myChangedFlocks includesIntKey: info index) assert: 'Something is wrong']]!
*/
}

/**
 * The flock designated by info has completed all dismantling actions; throw it off the disk.
 */
public void dismantleFlock(FlockInfo info) {
throw new UnsupportedOperationException();/*
udanax-top.st:17713:TestPacker methodsFor: 'shepherds'!
{void} dismantleFlock: info {FlockInfo} 
	"The flock designated by info has completed all dismantling actions; throw it off the disk."
	| flock {Abraham} |
	flock _ info getShepherd cast: Abraham. "Check for destructed essentially"
	self mustKnowShepherd: info.
	self mustNotBeCommitting.
	self countDown.
	
	info markDismantled.
	info isNew ifFalse:
		[myChangedFlocks atInt: info index store: Pumpkin make].!
*/
}

public void dropFlock(int token) {
throw new UnsupportedOperationException();/*
udanax-top.st:17726:TestPacker methodsFor: 'shepherds'!
{void} dropFlock: token {Int32}
	| info {FlockInfo} |
	info := FlockInfo getInfo: token.
	info isNew
		ifTrue: 
			[myNewFlocks intRemove: info index]
		ifFalse: 
			[info isForgotten ifFalse: [Heaper BLAST: #OnlyRemoveUnchangedFlocks].
			myChangedFlocks intWipe: info index.
			myFlocks intRemove: info index].
	FlockInfo removeInfo: token!
*/
}

public void forgetFlock(FlockInfo info) {
throw new UnsupportedOperationException();/*
udanax-top.st:17738:TestPacker methodsFor: 'shepherds'!
{void} forgetFlock: info {FlockInfo} 
	self mustKnowShepherd: info.
	self mustBeInsideTransaction.
	self mustNotBeCommitting.
	self countDown.
	info markForgotten ifTrue: [self recordUpdate: info]!
*/
}

public Turtle getInitialFlock() {
throw new UnsupportedOperationException();/*
udanax-top.st:17746:TestPacker methodsFor: 'shepherds'!
{Turtle} getInitialFlock
	^myInitialFlock cast: Turtle!
*/
}

public int nextHashForEqual() {
throw new UnsupportedOperationException();/*
udanax-top.st:17750:TestPacker methodsFor: 'shepherds'!
{UInt32} nextHashForEqual
	 
	myNextHash _ myNextHash + 1.
	"This actually needs to roll over the UInt32 limit."
	^myNextHash!
*/
}

public void rememberFlock(FlockInfo info) {
throw new UnsupportedOperationException();/*
udanax-top.st:17756:TestPacker methodsFor: 'shepherds'!
{void} rememberFlock: info {FlockInfo} 
	self mustBeInsideTransaction.
	self countDown.
	info markRemembered ifTrue: [self recordUpdate: info]!
*/
}

public void storeAlmostNewShepherd(Abraham shep) {
throw new UnsupportedOperationException();/*
udanax-top.st:17762:TestPacker methodsFor: 'shepherds'!
{void} storeAlmostNewShepherd: shep {Abraham} 
	myAlmostNewFlocks store: shep!
*/
}

public void storeInitialFlock(Abraham turtle, XcvrMaker protocol, Cookbook cookbook) {
throw new UnsupportedOperationException();/*
udanax-top.st:17766:TestPacker methodsFor: 'shepherds'!
{void} storeInitialFlock: turtle {Abraham}
	with: protocol {XcvrMaker}
	with: cookbook {Cookbook}
	
	myInitialFlock := turtle.
	myXcvrMaker := protocol.
	myBook := cookbook.
	self storeNewFlock: turtle.!
*/
}

/**
 * Shep just got created!! On some later commit, assign it to a snarf
 * and write it to the disk.
 */
public void storeNewFlock(Abraham shep) {
throw new UnsupportedOperationException();/*
udanax-top.st:17775:TestPacker methodsFor: 'shepherds'!
{void} storeNewFlock: shep {Abraham} 
	"Shep just got created!! On some later commit, assign it to a snarf 
	and write it to the disk."
	| info {FlockInfo} |
	shep fetchInfo == NULL ifFalse:
		[Heaper BLAST: #NewShepherdMustNotHaveInfo].
	self countDown.
	myAlmostNewFlocks wipe: shep.
	info _ TestFlockInfo make: shep with: myNewFlocks highestIndex + 1.
	myNewFlocks atInt: myNewFlocks highestIndex + 1 introduce: info.
	shep flockInfo: info!
*/
}

public void checkNewFlockIndices() {
throw new UnsupportedOperationException();/*
udanax-top.st:17790:TestPacker methodsFor: 'private: testing'!
{void} checkNewFlockIndices
	myNewFlocks stepper forIndices: [ :index {IntegerVar} :value {FlockInfo} |
		index DOTasLong = value index ifFalse:
			[Heaper BLAST: #NewFlockIndexDoesNotMatch]]!
*/
}

public void committing(boolean flag) {
throw new UnsupportedOperationException();/*
udanax-top.st:17796:TestPacker methodsFor: 'private: testing'!
{void} committing: flag {BooleanVar}
	amCommitting := flag!
*/
}

/**
 * Decrement the countdown and return its new value
 */
public IntegerVar countDown() {
throw new UnsupportedOperationException();/*
udanax-top.st:17800:TestPacker methodsFor: 'private: testing'!
{IntegerVar} countDown
	"Decrement the countdown and return its new value"
	
	myCountDown := myCountDown - 1.
	^myCountDown!
*/
}

public void mustBeInsideTransaction() {
throw new UnsupportedOperationException();/*
udanax-top.st:17806:TestPacker methodsFor: 'private: testing'!
{void} mustBeInsideTransaction
	InsideTransactionFlag fluidFetch
		ifFalse: [blastOnError ifTrue:
				[Heaper BLAST: #MustBeInsideTransaction].
			[cerr << 'Method '<< thisContext sender sender selector << ' must call ' << thisContext sender selector << ' inside a transaction
'] smalltalkOnly.
			cerr << 'A consistent block is missing
']!
*/
}

/**
 * Check that I know about this shepherd
 */
public void mustKnowShepherd(FlockInfo info) {
throw new UnsupportedOperationException();/*
udanax-top.st:17816:TestPacker methodsFor: 'private: testing'!
{void} mustKnowShepherd: info {FlockInfo} 
	"Check that I know about this shepherd"
	| t {Heaper} |
	info isNew
		ifTrue: [t := myNewFlocks intFetch: info index]
		ifFalse: [t := myFlocks intFetch: info index].
	(t ~~ NULL and: [t isEqual: info])
		ifFalse: [Heaper BLAST: #IncorrectFlockInfo]!
*/
}

public void mustNotBeCommitting() {
throw new UnsupportedOperationException();/*
udanax-top.st:17826:TestPacker methodsFor: 'private: testing'!
{void} mustNotBeCommitting
	amCommitting ifTrue:
		[Heaper BLAST: #MustNotChangeDuringCommit]!
*/
}

public void resetCountDown() {
throw new UnsupportedOperationException();/*
udanax-top.st:17831:TestPacker methodsFor: 'private: testing'!
{void} resetCountDown
	myCountDown := myPersistInterval.!
*/
}

public Abraham fetchCanonical(int hash, SnarfID snarfID, int index) {
throw new UnsupportedOperationException();/*
udanax-top.st:17837:TestPacker methodsFor: 'stubs'!
{Abraham} fetchCanonical: hash {UInt32 unused} with: snarfID {SnarfID unused} with: index {Int32}
	^(myFlocks intFetch: index) cast: Abraham!
*/
}

public void makeReal(FlockInfo info) {
throw new UnsupportedOperationException();/*
udanax-top.st:17841:TestPacker methodsFor: 'stubs'!
{void} makeReal: info {FlockInfo}
	| stub {Abraham} oldHash {UInt32} stream {XnReadStream} rcvr {Rcvr} |
	stub := info getShepherd.
	stub isStub ifFalse:
		[Heaper BLAST: #MustBeAStub].
	oldHash := stub hashForEqual.
	(rcvr _ self makeRcvr: (stream _ self readStream: info)) receiveInto: stub.
	rcvr destroy.
	stream destroy.
	stub hashForEqual == oldHash
		ifFalse: [Heaper BLAST: #HashMustNotChange].
	info setSize: (self computeSize: info getShepherd).
	"Receiving the flock will have cleared its info, so put it back."
	stub flockInfo: info!
*/
}

public void registerStub(Abraham shep, SnarfID snarfID, int index) {
throw new UnsupportedOperationException();/*
udanax-top.st:17857:TestPacker methodsFor: 'stubs'!
{void} registerStub: shep {Abraham} with: snarfID {SnarfID} with: index {Int32}
	| info {FlockInfo} |
	shep isStub assert: 'Must be stub'.
	info _ TestFlockInfo remembered: shep with: snarfID with: index.
	shep flockInfo: info.
	myFlocks atInt: index introduce: info!
*/
}

/**
 * Send the snarf over a transmitter into a stream that just counts the bytes put into it.
 */
public int computeSize(Abraham flock) {
throw new UnsupportedOperationException();/*
udanax-top.st:17866:TestPacker methodsFor: 'private: streams'!
{Int32} computeSize: flock {Abraham}
	"Send the snarf over a transmitter into a stream that just counts the bytes put into it."
	
	| counter {XnWriteStream} xmtr {Xmtr} size {Int32} | 
	counter := CountStream make.
	xmtr _ self makeXmtr: counter.
	xmtr sendHeaper: flock.
	size _ (counter cast: CountStream) size.
	xmtr destroy.
	counter destroy.
	^size!
*/
}

public SpecialistRcvr makeRcvr(XnReadStream readStream) {
throw new UnsupportedOperationException();/*
udanax-top.st:17878:TestPacker methodsFor: 'private: streams'!
{SpecialistRcvr} makeRcvr: readStream {XnReadStream}
	^myXcvrMaker makeRcvr: (DiskSpecialist make: myBook with: self) with: readStream!
*/
}

public SpecialistXmtr makeXmtr(XnWriteStream writeStream) {
throw new UnsupportedOperationException();/*
udanax-top.st:17882:TestPacker methodsFor: 'private: streams'!
{SpecialistXmtr} makeXmtr: writeStream {XnWriteStream}
	^myXcvrMaker makeXmtr: (DiskSpecialist make: myBook with: self) with: writeStream!
*/
}

/**
 * Get a read stream on the disk contents of the info
 */
public XnReadStream readStream(FlockInfo info) {
throw new UnsupportedOperationException();/*
udanax-top.st:17886:TestPacker methodsFor: 'private: streams'!
{XnReadStream} readStream: info {FlockInfo}
	"Get a read stream on the disk contents of the info"
	
	^XnReadStream make: ((myDisk intGet: info index) cast: UInt8Array)!
*/
}

/**
 * Get a write stream on the disk contents of the info
 */
public XnWriteStream writeStream(FlockInfo info) {
throw new UnsupportedOperationException();/*
udanax-top.st:17891:TestPacker methodsFor: 'private: streams'!
{XnWriteStream} writeStream: info {FlockInfo}
	"Get a write stream on the disk contents of the info"
	
	| result {UInt8Array} |
	result := UInt8Array make: (self computeSize: info getShepherd).
	myDisk atInt: info index store: result.
	self hack.  "You can't use gutsOf in something that will do an allocation."
	^XnWriteStream make: result!
*/
}

public void assignSnarf(Abraham shep) {
throw new UnsupportedOperationException();/*
udanax-top.st:17902:TestPacker methodsFor: 'private: disk'!
{void} assignSnarf: shep {Abraham}
	| oldInfo {FlockInfo} snarf {SnarfID} |
	oldInfo := shep getInfo.
	snarf := myDisk highestIndex DOTasLong + 1.
	myDisk atInt: snarf store: (UInt8Array make: UInt32Zero).
	shep flockInfo: (TestFlockInfo make: oldInfo with: snarf with: snarf).
	"Destroy the old location if it is for a new flock (rather than forwarded)."
	oldInfo isNew ifTrue:
		[myNewFlocks intWipe: oldInfo index.
		oldInfo destroy.
		(shep getInfo cast: TestFlockInfo) updateContentsInfo].
	oldInfo := NULL.
	myFlocks atInt: snarf introduce: shep getInfo.
	myChangedFlocks atInt: snarf store: shep!
*/
}

/**
 * Rewrite all flocks that have changed in this snarf.
 */
public void flushChanges() {
throw new UnsupportedOperationException();/*
udanax-top.st:17918:TestPacker methodsFor: 'private: disk'!
{void} flushChanges
	"Rewrite all flocks that have changed in this snarf."
	"check that all changed flocks are in fact in myChangedFlocks"
	| flocks {TableStepper} |
	myFlocks stepper forEach: [:info {TestFlockInfo} | 
		(info fetchShepherd ~~ NULL
			and: [(info isNew not)
			and: [(info updateContentsInfo or: [info isContentsDirty])
			and: [(myChangedFlocks includesIntKey: info snarfID) not]]])
			ifTrue: 
				[blastOnError ifTrue: [Heaper BLAST: #ShouldHaveDoneDiskUpdateOnChangedShepherd].
				cerr << 'Shepherd ' << info fetchShepherd << ' with info ' << info << ' should have done a diskUpdate
'.
				self recordUpdate: info]].
	"actually write changed flocks to disk"
	(flocks := myChangedFlocks stepper) forEach: [:thing {Heaper} | thing
		cast: Pumpkin into: [:pumpkin |
			myDisk intWipe: flocks index]
		cast: Abraham into: [:shep | | inf {FlockInfo} |
			inf := shep fetchInfo.
			inf == NULL ifTrue: [Heaper BLAST: #ShepherdMustNotHaveNullFlockInfo].
			inf index == flocks index DOTasLong ifTrue: 
				[| xmtr {Xmtr} stream {XnWriteStream} |
				"Not forwarded."
				shep isStub ifTrue: [Heaper BLAST: #MustBeInstantiated].
				(xmtr _ self makeXmtr: (stream _ self writeStream: inf)) sendHeaper: shep.
				xmtr destroy.
				stream destroy.
				(inf cast: TestFlockInfo) setContents: ((myDisk intFetch: inf index) cast: UInt8Array).
				inf commitFlags]
			ifFalse:
				["We only get here for forwarded flocks."
				Heaper BLAST: #TestPackerDoesNotForward]]].
	myChangedFlocks destroy.
	myChangedFlocks := IntegerTable make!
*/
}

/**
 * The flock represented by info has changed.  Record it in the
 * bookkeeping data-structures.  This must be called by all things
 * that affect whether the flock gets rewritten to disk.
 */
public void recordUpdate(FlockInfo info) {
throw new UnsupportedOperationException();/*
udanax-top.st:17955:TestPacker methodsFor: 'private: disk'!
{void} recordUpdate: info {FlockInfo} 
	"The flock represented by info has changed.  Record it in the
	 bookkeeping data-structures.  This must be called by all things 
	 that affect whether the flock gets rewritten to disk."
	| shep {Abraham} |
	
	info isNew not ifTrue: 
		[(shep _ info fetchShepherd) ~~ NULL ifTrue:
			[(shep isEqual: Pumpkin make)
				ifTrue: 
					[blastOnError ifTrue: [Heaper BLAST: #MustNotRecordChangesForPumpkins].
					cerr << 'Pumpkin ' << info << ' tried to diskUpdate
'.
					^VOID]].
		myChangedFlocks atInt: info index store: shep]!
*/
}

/**
 * do nothing for now
 */
public void refitFlocks() {
throw new UnsupportedOperationException();/*
udanax-top.st:17971:TestPacker methodsFor: 'private: disk'!
{void} refitFlocks
	"do nothing for now"!
*/
}

public  TestPacker(boolean blast, IntegerVar persistInterval) {
throw new UnsupportedOperationException();/*
udanax-top.st:17977:TestPacker methodsFor: 'create'!
create: blast {BooleanVar} with: persistInterval {IntegerVar}
	super create.
	myNextHash := UInt32Zero.
	myInitialFlock := NULL.
	myFlocks := IntegerTable make.
	myChangedFlocks := IntegerTable make.
	myDestroyedFlocks _ MuArray array.
	myAlmostNewFlocks := MuSet make.
	myNewFlocks := IntegerTable make.
	myXcvrMaker := NULL.
	myBook := NULL.
	myPersistInterval := persistInterval.
	self resetCountDown.
	myDisk := IntegerTable make.
	amCommitting := false.
	blastOnError := blast.!
*/
}

/**
 * Compute a hash on the contents
 */
public int computeHash(Abraham flock) {
throw new UnsupportedOperationException();/*
udanax-top.st:17997:TestPacker methodsFor: 'internals'!
{UInt32} computeHash: flock {Abraham}
	"Compute a hash on the contents"
	| hasher {XnWriteStream} hash {UInt32} xmtr {SpecialistXmtr} |
	hasher := HashStream make.
	xmtr := self makeXmtr: hasher.
	xmtr sendHeaper: flock.
	hash := (hasher cast: HashStream) hash.
	xmtr destroy.
	hasher destroy.
	^hash!
*/
}

public void purgeClean() {
throw new UnsupportedOperationException();/*
udanax-top.st:18010:TestPacker methodsFor: 'smalltalk: defaults'!
{void} purgeClean
	self purgeClean: false!
*/
}

public void beginConsistent(IntegerVar dirty) {
throw new UnsupportedOperationException();/*
udanax-top.st:18015:TestPacker methodsFor: 'transactions'!
{void} beginConsistent: dirty {IntegerVar unused}
	InsideTransactionFlag fluidFetch
		ifFalse: 
			[self countDown < IntegerVar0
				ifTrue: 
					[self makePersistent.
					self resetCountDown]]!
*/
}

public void endConsistent(IntegerVar dirty) {
throw new UnsupportedOperationException();/*
udanax-top.st:18023:TestPacker methodsFor: 'transactions'!
{void} endConsistent: dirty {IntegerVar unused} 
	| agenda {Agenda | NULL} |
	
	InsideTransactionFlag fluidFetch ifTrue: [^VOID].
	myAlmostNewFlocks isEmpty
		ifFalse: 
			[blastOnError
				ifTrue: [Heaper BLAST: #MustDoNewShepherdAfterDiskUpdate].
			cerr << 'These flocks should have done a newShepherd: ' << myAlmostNewFlocks << '
'.
			myAlmostNewFlocks stepper forEach: [:each {Abraham} | 
				each newShepherd]].
		
	InsideAgenda fluidFetch ifTrue: [^VOID].
	agenda _ (myInitialFlock cast: Turtle) fetchAgenda.
	agenda ~~ NULL ifTrue: 
		[InsideAgenda fluidBind: true during:
			[[agenda step] whileTrue]].
	myDestroyedFlocks isEmpty ifTrue: [^VOID].
	InsideAgenda fluidBind: true during:
		[[myDestroyedFlocks isEmpty]
			whileFalse:
				[| flock {Abraham} |
				flock _ (myDestroyedFlocks intGet: myDestroyedFlocks count - 1) cast: Abraham.
				myDestroyedFlocks intRemove: myDestroyedFlocks count - 1.
				flock getInfo isForgotten ifTrue: [flock dismantle]]]!
*/
}

public boolean insideCommit() {
throw new UnsupportedOperationException();/*
udanax-top.st:18051:TestPacker methodsFor: 'transactions'!
{BooleanVar} insideCommit
	^ amCommitting!
*/
}

public void makePersistent() {
throw new UnsupportedOperationException();/*
udanax-top.st:18054:TestPacker methodsFor: 'transactions'!
{void} makePersistent
	[amCommitting := true.
	self refitFlocks.
	myNewFlocks stepper forEach: [:info {FlockInfo} | | shep {Abraham} |
		(shep _ info fetchShepherd) ~~ NULL ifTrue:
			[self assignSnarf: shep]].
	self flushChanges.
	myNewFlocks destroy.
	myNewFlocks := IntegerTable make: 500]
		valueNowOrOnUnwindDo:
			(TestPacker bomb.EndCommit: self)!
*/
}

public void purge() {
throw new UnsupportedOperationException();/*
udanax-top.st:18067:TestPacker methodsFor: 'transactions'!
{void} purge
	InsideTransactionFlag fluidFetch ifFalse:
		[self makePersistent.
		self purgeClean: true]!
*/
}

public void purgeClean(boolean noneLocked) {
throw new UnsupportedOperationException();/*
udanax-top.st:18073:TestPacker methodsFor: 'transactions'!
{void} purgeClean: noneLocked {BooleanVar default: false}
	
	 | stackPtrs {PrimPtrTable} |
	[Transcript show: 'Starting purge...'] smalltalkOnly.
	noneLocked
		ifTrue: [stackPtrs _ PrimPtrTable make: 1]
		ifFalse: [stackPtrs _ StackExaminer pointersOnStack].
	myFlocks stepper forEach:
		[ :info {FlockInfo} |
		| shep {Abraham} |
		shep := info fetchShepherd.
		[(shep ~~ NULL
				and: [shep isStub not
				and: [(stackPtrs fetch: shep asOop) == NULL
				and: [shep isPurgeable
				and: [info isDirty not]]]])
			ifTrue: [shep becomeStub]] smalltalkOnly.
		'if (shep && shep->fetchInfo() == info && !!shep->isStub() && (stackPtrs->fetch((Int32)(void*)shep) == NULL) && shep->isPurgeable() && !!info->isDirty()) {
			shep->becomeStub();
			}' translateOnly.].
	[Transcript show: 'done.'; cr] smalltalkOnly!
*/
}

public void makeConsistent() {
throw new UnsupportedOperationException();/*
udanax-top.st:18097:TestPacker methodsFor: 'smalltalk: passe'!
{void} makeConsistent
	self passe.
	myAlmostNewFlocks isEmpty ifFalse:
		[blastOnError ifTrue:
			[Heaper BLAST: #MustDoNewShepherdAfterDiskUpdate].
		cerr << 'These flocks should have done a newShepherd: ' << myAlmostNewFlocks << '
'.
		myAlmostNewFlocks stepper forEach: [ :each {Abraham} |
			each newShepherd]].
	self countDown < IntegerVar0 ifTrue: 
		[self makePersistent.
		self resetCountDown]!
*/
}

public boolean isFake() {
throw new UnsupportedOperationException();/*
udanax-top.st:18113:TestPacker methodsFor: 'testing'!
{BooleanVar} isFake
	^ false!
*/
}

public static void bomb(TestPacker CHARGE) {
throw new UnsupportedOperationException();/*
udanax-top.st:18127:TestPacker class methodsFor: 'exceptions: private:'!
bomb.EndCommit: CHARGE {TestPacker star}
	^[CHARGE committing: false]!
*/
}

public static Heaper make(boolean blast, IntegerVar persistInterval) {
throw new UnsupportedOperationException();/*
udanax-top.st:18133:TestPacker class methodsFor: 'pseudo constructors'!
{DiskManager} make: blast {BooleanVar} with: persistInterval {IntegerVar}
	| result {DiskManager} |
	result := self create: blast with: persistInterval.
	CurrentPacker fluidSet: result.
	^result!
*/
}
}
