/*
 * Abora-Gold
 * Part of the Abora hypertext project: http://www.abora.org
 * Copyright 2003 David G Jones
 * 
 * Translated from Udanax-Gold source code: http://www.udanax.com
 * Copyright 1979-1999 Udanax.com. All rights reserved
 */
package org.abora.gold.snarf;

import java.io.PrintWriter;
import org.abora.gold.collection.sets.MuSet;
import org.abora.gold.java.missing.IntegerVar;
import org.abora.gold.snarf.CBlockTracker;
import org.abora.gold.snarf.FlockInfo;
import org.abora.gold.xpp.basic.Heaper;


public class CBlockTracker extends Heaper {
	protected char myFileName;
	protected byte myLineNo;
	protected IntegerVar myMaxDirty;
	protected IntegerVar myLimit;
	protected IntegerVar myDirtySoFar;
	protected IntegerVar myTrulyDirtySoFar;
	protected MuSet myDirtyInfos;
	protected IntegerVar myDirtyInfosCount;
	protected CBlockTracker myOuterTracker;
	protected IntegerVar myOccurencesCount;
	protected static CBlockTracker TheTrackerList;
/*
udanax-top.st:13220:
Heaper subclass: #CBlockTracker
	instanceVariableNames: '
		myFileName {char star | NULL}
		myLineNo {Int4}
		myMaxDirty {IntegerVar}
		myLimit {IntegerVar}
		myDirtySoFar {IntegerVar}
		myTrulyDirtySoFar {IntegerVar}
		myDirtyInfos {MuSet of: IntegerPos}
		myDirtyInfosCount {IntegerVar}
		myOuterTracker {CBlockTracker | NULL}
		myOccurencesCount {IntegerVar}'
	classVariableNames: 'TheTrackerList {CBlockTracker | NULL} '
	poolDictionaries: ''
	category: 'Xanadu-Snarf'!
*/
/*
udanax-top.st:13234:
(CBlockTracker getOrMakeCxxClassDescription)
	attributes: ((Set new) add: #CONCRETE; yourself)!
*/
/*
udanax-top.st:13405:
CBlockTracker class
	instanceVariableNames: ''!
*/
/*
udanax-top.st:13408:
(CBlockTracker getOrMakeCxxClassDescription)
	attributes: ((Set new) add: #CONCRETE; yourself)!
*/

public  CBlockTracker(IntegerVar dirty, CBlockTracker outer) {
throw new UnsupportedOperationException();/*
udanax-top.st:13239:CBlockTracker methodsFor: 'creation'!
create: dirty {IntegerVar} with: outer {CBlockTracker | NULL} 
	
	super create.
	dirty = -1
		ifTrue: [myMaxDirty _ 1000]
		ifFalse: [myMaxDirty _ dirty].
	myOuterTracker _ outer.
	myFileName _ NULL.
	myLineNo _ Int32Zero.
	myDirtySoFar _ Int32Zero.
	myTrulyDirtySoFar _ Int32Zero.
	myDirtyInfos _ MuSet make.
	myDirtyInfosCount _ Int32Zero.
	myOccurencesCount _ 1.
	outer == NULL
		ifTrue: [myLimit _ myMaxDirty]
		ifFalse: [myLimit _ outer slack min: myMaxDirty]!
*/
}

public void dirty(FlockInfo info) {
throw new UnsupportedOperationException();/*
udanax-top.st:13259:CBlockTracker methodsFor: 'accessing'!
{void} dirty: info {FlockInfo | NULL} 
	
	myDirtySoFar _ myDirtySoFar + 1.
	myTrulyDirtySoFar _ myTrulyDirtySoFar + 1.
	(info ~~ NULL) assert.
	myDirtyInfos store: (IntegerPos make: info getShepherd hashForEqual).
	myDirtyInfosCount _ myDirtyInfos count.
	self reportProblems!
*/
}

public CBlockTracker fetchUnwrapped() {
throw new UnsupportedOperationException();/*
udanax-top.st:13268:CBlockTracker methodsFor: 'accessing'!
{CBlockTracker | NULL} fetchUnwrapped
	
	| result {CBlockTracker | NULL} stored {CBlockTracker | NULL} |
	result _ myOuterTracker.
	result ~~ NULL
		ifTrue: 
			[result innerDirtied: myMaxDirty.
			result innerTrulyDirtied: myTrulyDirtySoFar.
			result innerDirtyInfos: myDirtyInfos.
			result reportProblems].
	myFileName ~~ NULL
		ifTrue: 
			[(TheTrackerList == NULL 
			  or: [(stored _ TheTrackerList fetchMatch: self) == NULL])
				ifTrue: 
					[myOuterTracker _ TheTrackerList.
					myDirtyInfos _ MuSet make.
					TheTrackerList _ self]
				ifFalse: [stored updateFrom: self]].
	^result!
*/
}

public void track(String fileName, int lineNo) {
throw new UnsupportedOperationException();/*
udanax-top.st:13289:CBlockTracker methodsFor: 'accessing'!
{void} track: fileName {char star} with: lineNo {Int32}
	myFileName _ fileName.
	myLineNo _ lineNo.!
*/
}

public void printAllOn(PrintWriter oo) {
throw new UnsupportedOperationException();/*
udanax-top.st:13296:CBlockTracker methodsFor: 'printing'!
{void} printAllOn: oo {ostream reference} 
	
	oo << self << '
'.
	myOuterTracker ~~ NULL
		ifTrue: [myOuterTracker printAllOn: oo]!
*/
}

public void printOn(PrintWriter oo) {
throw new UnsupportedOperationException();/*
udanax-top.st:13303:CBlockTracker methodsFor: 'printing'!
{void} printOn: oo {ostream reference}
	oo << '"' << myFileName << '"' << ', line ' << myLineNo << ': ' << self getCategory name << '('.
	oo << myMaxDirty << ',	' 
		<< myLimit << ',	' 
		<< myDirtySoFar << ',	' 
		<< myTrulyDirtySoFar << ', ' 
		<< myDirtyInfosCount << ', '
		<< myOccurencesCount << ')'!
*/
}

public IntegerVar dirtyInfosCount() {
throw new UnsupportedOperationException();/*
udanax-top.st:13315:CBlockTracker methodsFor: 'private: accessing'!
{IntegerVar} dirtyInfosCount
	^myDirtyInfosCount!
*/
}

public IntegerVar dirtySoFar() {
throw new UnsupportedOperationException();/*
udanax-top.st:13319:CBlockTracker methodsFor: 'private: accessing'!
{IntegerVar} dirtySoFar
	^myDirtySoFar!
*/
}

public CBlockTracker fetchMatch(CBlockTracker other) {
throw new UnsupportedOperationException();/*
udanax-top.st:13323:CBlockTracker methodsFor: 'private: accessing'!
{CBlockTracker | NULL} fetchMatch: other {CBlockTracker} 
	
	(myFileName ~~ NULL
	 and: [other fileName ~~ NULL
	 and: [(String strcmp: myFileName with: other fileName) = Int32Zero 
	 and: [myLineNo = other lineNo]]])
		ifTrue: [^self]
		ifFalse: 
			[myOuterTracker == NULL
				ifTrue: [^NULL]
				ifFalse: [^myOuterTracker fetchMatch: other]]!
*/
}

public String fileName() {
throw new UnsupportedOperationException();/*
udanax-top.st:13335:CBlockTracker methodsFor: 'private: accessing'!
{char star | NULL} fileName
	^myFileName!
*/
}

public void innerDirtied(IntegerVar dirty) {
throw new UnsupportedOperationException();/*
udanax-top.st:13339:CBlockTracker methodsFor: 'private: accessing'!
{void} innerDirtied: dirty {IntegerVar} 
	
	myDirtySoFar _ myDirtySoFar + dirty!
*/
}

public void innerDirtyInfos(MuSet dirties) {
throw new UnsupportedOperationException();/*
udanax-top.st:13343:CBlockTracker methodsFor: 'private: accessing'!
{void} innerDirtyInfos: dirties {MuSet of: IntegerPos}
	myDirtyInfos storeAll: dirties.
	myDirtyInfosCount _ myDirtyInfos count!
*/
}

public void innerTrulyDirtied(IntegerVar dirty) {
throw new UnsupportedOperationException();/*
udanax-top.st:13348:CBlockTracker methodsFor: 'private: accessing'!
{void} innerTrulyDirtied: dirty {IntegerVar}
	myTrulyDirtySoFar _ myTrulyDirtySoFar + dirty!
*/
}

public IntegerVar limit() {
throw new UnsupportedOperationException();/*
udanax-top.st:13352:CBlockTracker methodsFor: 'private: accessing'!
{IntegerVar} limit
	^myLimit!
*/
}

public int lineNo() {
throw new UnsupportedOperationException();/*
udanax-top.st:13356:CBlockTracker methodsFor: 'private: accessing'!
{Int32} lineNo
	^myLineNo!
*/
}

public IntegerVar maxDirty() {
throw new UnsupportedOperationException();/*
udanax-top.st:13360:CBlockTracker methodsFor: 'private: accessing'!
{IntegerVar} maxDirty
	^myMaxDirty!
*/
}

public IntegerVar occurencesCount() {
throw new UnsupportedOperationException();/*
udanax-top.st:13364:CBlockTracker methodsFor: 'private: accessing'!
{IntegerVar} occurencesCount
	^ myOccurencesCount!
*/
}

public void reportProblems() {
throw new UnsupportedOperationException();/*
udanax-top.st:13367:CBlockTracker methodsFor: 'private: accessing'!
{void} reportProblems
	
	^VOID
	"(myLimit < 1000 
	 and: [myDirtyInfosCount > myMaxDirty 
	 		""((myDirtySoFar max: myTrulyDirtySoFar) max: myDirtyInfosCount) > myLimit""])
		ifTrue: 
			[cerr << '
Limit exceeded [
'.
			self printAllOn: cerr.
			[cerr endEntry.
			""myDirtyInfosCount > myMaxDirty
				ifTrue: [self halt]""] smalltalkOnly]"!
*/
}

public IntegerVar slack() {
throw new UnsupportedOperationException();/*
udanax-top.st:13382:CBlockTracker methodsFor: 'private: accessing'!
{IntegerVar} slack
	^myLimit - myDirtySoFar!
*/
}

public IntegerVar trulyDirtySoFar() {
throw new UnsupportedOperationException();/*
udanax-top.st:13386:CBlockTracker methodsFor: 'private: accessing'!
{IntegerVar} trulyDirtySoFar
	^myTrulyDirtySoFar!
*/
}

public void updateFrom(CBlockTracker other) {
throw new UnsupportedOperationException();/*
udanax-top.st:13390:CBlockTracker methodsFor: 'private: accessing'!
{void} updateFrom: other {CBlockTracker}
	myMaxDirty _ myMaxDirty max: other maxDirty.
	myLimit _ myLimit min: other limit.
	myDirtySoFar _ myDirtySoFar max: other dirtySoFar.
	myTrulyDirtySoFar _ myTrulyDirtySoFar max: other trulyDirtySoFar.
	myDirtyInfosCount _ myDirtyInfosCount max: other dirtyInfosCount.
	myOccurencesCount _ myOccurencesCount + other occurencesCount!
*/
}

public int actualHashForEqual() {
throw new UnsupportedOperationException();/*
udanax-top.st:13401:CBlockTracker methodsFor: 'testing'!
{UInt32} actualHashForEqual
	^Heaper takeOop!
*/
}

public static Heaper make(IntegerVar dirty, CBlockTracker outer) {
throw new UnsupportedOperationException();/*
udanax-top.st:13413:CBlockTracker class methodsFor: 'creation'!
make: dirty {IntegerVar} with: outer {CBlockTracker | NULL}
	^self create: dirty with: outer!
*/
}

public static void linkTimeNonInherited() {
throw new UnsupportedOperationException();/*
udanax-top.st:13419:CBlockTracker class methodsFor: 'smalltalk: init'!
linkTimeNonInherited
	TheTrackerList _ NULL!
*/
}

/**
 * CBlockTracker printTrackersOn: cerr. cerr endEntry
 */
public static void printTrackersOn(PrintWriter oo) {
throw new UnsupportedOperationException();/*
udanax-top.st:13425:CBlockTracker class methodsFor: 'printing'!
{void} printTrackersOn: oo {ostream reference} 
	"CBlockTracker printTrackersOn: cerr. cerr endEntry"
	
	oo << '
Consistent-Block Behavior
'.
	TheTrackerList ~~ NULL
		ifTrue: [TheTrackerList printAllOn: oo].
	oo << '
'.!
*/
}
}
