/*
 * Abora-Gold
 * Part of the Abora hypertext project: http://www.abora.org
 * Copyright 2003 David G Jones
 * 
 * Translated from Udanax-Gold source code: http://www.udanax.com
 * Copyright 1979-1999 Udanax.com. All rights reserved
 */
package org.abora.gold.snarf;

import java.io.PrintWriter;
import org.abora.gold.snarf.Abraham;
import org.abora.gold.xcvr.Rcvr;
import org.abora.gold.xcvr.Xmtr;
import org.abora.gold.xpp.basic.Heaper;


public class DoublingFlock extends Abraham {
	protected int myCount;
/*
udanax-top.st:6009:
Abraham subclass: #DoublingFlock
	instanceVariableNames: 'myCount {Int32}'
	classVariableNames: ''
	poolDictionaries: ''
	category: 'Xanadu-Snarf'!
*/
/*
udanax-top.st:6013:
(DoublingFlock getOrMakeCxxClassDescription)
	attributes: ((Set new) add: #SHEPHERD.PATRIARCH; add: #COPY; add: #EQ; add: #LOCKED; add: #CONCRETE; yourself)!
*/
/*
udanax-top.st:6077:
DoublingFlock class
	instanceVariableNames: ''!
*/
/*
udanax-top.st:6080:
(DoublingFlock getOrMakeCxxClassDescription)
	attributes: ((Set new) add: #SHEPHERD.PATRIARCH; add: #COPY; add: #EQ; add: #LOCKED; add: #CONCRETE; yourself)!
*/

public int count() {
throw new UnsupportedOperationException();/*
udanax-top.st:6018:DoublingFlock methodsFor: 'accessing'!
{Int32} count
	^myCount!
*/
}

public void doDouble() {
throw new UnsupportedOperationException();/*
udanax-top.st:6021:DoublingFlock methodsFor: 'accessing'!
{void} doDouble
	
	DiskManager consistent: 1 with:
		[myCount _ myCount * 2.
		self diskUpdate]!
*/
}

public void receiveTestFlock(Rcvr rcvr) {
throw new UnsupportedOperationException();/*
udanax-top.st:6029:DoublingFlock methodsFor: 'hooks:'!
{void RECEIVE.HOOK} receiveTestFlock: rcvr {Rcvr} 
	Int32Zero almostTo: myCount do: 
		[:i {Int32} | rcvr receiveInt32 ~~ i ifTrue: [Heaper BLAST: #MustMatch]]!
*/
}

public void sendTestFlock(Xmtr xmtr) {
throw new UnsupportedOperationException();/*
udanax-top.st:6033:DoublingFlock methodsFor: 'hooks:'!
{void SEND.HOOK} sendTestFlock: xmtr {Xmtr}
	Int32Zero almostTo: myCount do: [:i {Int32} | xmtr sendInt32: i]!
*/
}

public void printOn(PrintWriter oo) {
throw new UnsupportedOperationException();/*
udanax-top.st:6038:DoublingFlock methodsFor: 'printing'!
{void} printOn: oo {ostream reference}
	oo << self getCategory name << '(' << self hashForEqual <<', ' << myCount << ')'!
*/
}

public  DoublingFlock(int hash) {
throw new UnsupportedOperationException();/*
udanax-top.st:6043:DoublingFlock methodsFor: 'creation'!
create: hash {UInt32}
	super create: hash.
	myCount _ 1.
	self newShepherd!
*/
}

public  DoublingFlock(int hash, int count) {
throw new UnsupportedOperationException();/*
udanax-top.st:6048:DoublingFlock methodsFor: 'creation'!
create: hash {UInt32} with: count {Int32}
	super create: hash.
	myCount _ count.
	self newShepherd!
*/
}

public int contentsHash() {
throw new UnsupportedOperationException();/*
udanax-top.st:6055:DoublingFlock methodsFor: 'testing'!
{UInt32} contentsHash
	^super contentsHash
		bitXor: (IntegerPos integerHash: myCount)!
*/
}

public int actualHashForEqual() {
throw new UnsupportedOperationException();/*
udanax-top.st:6062:DoublingFlock methodsFor: 'generated:'!
actualHashForEqual ^self asOop!
*/
}

public  DoublingFlock(Rcvr receiver) {
throw new UnsupportedOperationException();/*
udanax-top.st:6064:DoublingFlock methodsFor: 'generated:'!
create.Rcvr: receiver {Rcvr}
	super create.Rcvr: receiver.
	myCount _ receiver receiveInt32.
	self receiveTestFlock: receiver.!
*/
}

public boolean isEqual(Object other) {
throw new UnsupportedOperationException();/*
udanax-top.st:6069:DoublingFlock methodsFor: 'generated:'!
isEqual: other ^self == other!
*/
}

public void sendSelfTo(Xmtr xmtr) {
throw new UnsupportedOperationException();/*
udanax-top.st:6071:DoublingFlock methodsFor: 'generated:'!
{void} sendSelfTo: xmtr {Xmtr}
	super sendSelfTo: xmtr.
	xmtr sendInt32: myCount.
	self sendTestFlock: xmtr.!
*/
}

public static Heaper make(int hash) {
throw new UnsupportedOperationException();/*
udanax-top.st:6085:DoublingFlock class methodsFor: 'creation'!
make: hash {UInt32}
	^self create: hash!
*/
}

public static Heaper make(int hash, int count) {
throw new UnsupportedOperationException();/*
udanax-top.st:6088:DoublingFlock class methodsFor: 'creation'!
make: hash {UInt32} with: count {Int32}
	^self create: hash with: count!
*/
}
}
