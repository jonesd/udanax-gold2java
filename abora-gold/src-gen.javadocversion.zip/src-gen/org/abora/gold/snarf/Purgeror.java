/*
 * Abora-Gold
 * Part of the Abora hypertext project: http://www.abora.org
 * Copyright 2003 David G Jones
 * 
 * Translated from Udanax-Gold source code: http://www.udanax.com
 * Copyright 1979-1999 Udanax.com. All rights reserved
 */
package org.abora.gold.snarf;

import org.abora.gold.gchooks.SanitationEngineer;
import org.abora.gold.java.missing.IntegerVar;
import org.abora.gold.snarf.DiskManager;
import org.abora.gold.xpp.basic.Heaper;


/**
 * We are about to garbage collect.  Every so often, purge the objects that are clean so
 * their flocks can be garbage collected.
 */
public class Purgeror extends SanitationEngineer {
	protected IntegerVar myCount;
	protected DiskManager myPacker;
	protected boolean myPurgePending;
	protected static IntegerVar PurgeRate;
/*
udanax-top.st:44966:
SanitationEngineer subclass: #Purgeror
	instanceVariableNames: '
		myCount {IntegerVar}
		myPacker {DiskManager}
		myPurgePending {BooleanVar}'
	classVariableNames: 'PurgeRate {IntegerVar} '
	poolDictionaries: ''
	category: 'Xanadu-Snarf'!
*/
/*
udanax-top.st:44973:
Purgeror comment:
'We are about to garbage collect.  Every so often, purge the objects that are clean so their flocks can be garbage collected.'!
*/
/*
udanax-top.st:44975:
(Purgeror getOrMakeCxxClassDescription)
	attributes: ((Set new) add: #CONCRETE; yourself)!
*/
/*
udanax-top.st:45013:
Purgeror class
	instanceVariableNames: ''!
*/
/*
udanax-top.st:45016:
(Purgeror getOrMakeCxxClassDescription)
	attributes: ((Set new) add: #CONCRETE; yourself)!
*/

public void clearPurgePending() {
throw new UnsupportedOperationException();/*
udanax-top.st:44980:Purgeror methodsFor: 'accessing'!
{void INLINE} clearPurgePending
	myPurgePending := false.
	myCount := IntegerVar0!
*/
}

public boolean purgePending() {
throw new UnsupportedOperationException();/*
udanax-top.st:44984:Purgeror methodsFor: 'accessing'!
{BooleanVar INLINE} purgePending
	^ myPurgePending!
*/
}

public  Purgeror(DiskManager packer) {
throw new UnsupportedOperationException();/*
udanax-top.st:44989:Purgeror methodsFor: 'protected: creation'!
create: packer {DiskManager}
	super create.
	myPacker _ packer.
	myCount _ IntegerVar0.
	myPurgePending _ false!
*/
}

public void recycle(boolean required) {
throw new UnsupportedOperationException();/*
udanax-top.st:44997:Purgeror methodsFor: 'invoking'!
{void} recycle: required {BooleanVar}
	required ifTrue: [
		myPurgePending := true.
		^VOID].
	(myCount >= PurgeRate and: [PurgeRate > IntegerVarZero])
		ifTrue:
			[(InsideTransactionFlag fluidFetch or: [myPacker insideCommit])
				ifFalse:
					[myPacker purgeClean.
					myCount _ IntegerVarZero.
					myPurgePending _ false]
				ifTrue:
					[myPurgePending _ true]]
		ifFalse: [myCount _ myCount + 1]!
*/
}

public static void linkTimeNonInherited() {
throw new UnsupportedOperationException();/*
udanax-top.st:45021:Purgeror class methodsFor: 'smalltalk: init'!
linkTimeNonInherited
	PurgeRate _ 40.
	[Abraham] USES!
*/
}

public static Heaper make(DiskManager packer) {
throw new UnsupportedOperationException();/*
udanax-top.st:45027:Purgeror class methodsFor: 'creation'!
make: packer {DiskManager}
	^self create: packer!
*/
}

public static void setPurgeRate(IntegerVar count) {
throw new UnsupportedOperationException();/*
udanax-top.st:45032:Purgeror class methodsFor: 'setting'!
{void} setPurgeRate: count {IntegerVar}
	PurgeRate _ count!
*/
}
}
