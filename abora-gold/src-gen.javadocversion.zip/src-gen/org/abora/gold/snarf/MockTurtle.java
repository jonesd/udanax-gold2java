/*
 * Abora-Gold
 * Part of the Abora hypertext project: http://www.abora.org
 * Copyright 2003 David G Jones
 * 
 * Translated from Udanax-Gold source code: http://www.udanax.com
 * Copyright 1979-1999 Udanax.com. All rights reserved
 */
package org.abora.gold.snarf;

import org.abora.gold.cobbler.Cookbook;
import org.abora.gold.counter.Counter;
import org.abora.gold.snarf.Turtle;
import org.abora.gold.turtle.Agenda;
import org.abora.gold.xcvr.Rcvr;
import org.abora.gold.xcvr.XcvrMaker;
import org.abora.gold.xcvr.Xmtr;
import org.abora.gold.xpp.basic.Category;
import org.abora.gold.xpp.basic.Heaper;


/**
 * The MockTurtle is used with the FakePacker.  All it provides is an Agenda
 */
public class MockTurtle extends Turtle {
	protected Agenda myAgenda;
	protected Category myBootCategory;
/*
udanax-top.st:11362:
Turtle subclass: #MockTurtle
	instanceVariableNames: '
		myAgenda {Agenda | NULL}
		myBootCategory {Category}'
	classVariableNames: ''
	poolDictionaries: ''
	category: 'Xanadu-Snarf'!
*/
/*
udanax-top.st:11368:
MockTurtle comment:
'The MockTurtle is used with the FakePacker.  All it provides is an Agenda'!
*/
/*
udanax-top.st:11370:
(MockTurtle getOrMakeCxxClassDescription)
	attributes: ((Set new) add: #CONCRETE; add: #LOCKED; add: #COPY; yourself)!
*/
/*
udanax-top.st:11428:
MockTurtle class
	instanceVariableNames: ''!
*/
/*
udanax-top.st:11431:
(MockTurtle getOrMakeCxxClassDescription)
	attributes: ((Set new) add: #CONCRETE; add: #LOCKED; add: #COPY; yourself)!
*/

public Category bootCategory() {
throw new UnsupportedOperationException();/*
udanax-top.st:11375:MockTurtle methodsFor: 'accessing'!
{Category} bootCategory
	^ myBootCategory!
*/
}

public Heaper bootHeaper() {
throw new UnsupportedOperationException();/*
udanax-top.st:11378:MockTurtle methodsFor: 'accessing'!
{Heaper} bootHeaper
	self unimplemented.
	^NULL "fodder"!
*/
}

public Cookbook cookbook() {
throw new UnsupportedOperationException();/*
udanax-top.st:11382:MockTurtle methodsFor: 'accessing'!
{Cookbook} cookbook
	self willNotImplement.
	^ NULL!
*/
}

public Counter counter() {
throw new UnsupportedOperationException();/*
udanax-top.st:11386:MockTurtle methodsFor: 'accessing'!
{Counter} counter
	self willNotImplement.
	^NULL "fodder"!
*/
}

public Agenda fetchAgenda() {
throw new UnsupportedOperationException();/*
udanax-top.st:11390:MockTurtle methodsFor: 'accessing'!
{Agenda | NULL} fetchAgenda
	^myAgenda!
*/
}

public XcvrMaker protocol() {
throw new UnsupportedOperationException();/*
udanax-top.st:11394:MockTurtle methodsFor: 'accessing'!
{XcvrMaker} protocol
	self willNotImplement.
	^ NULL!
*/
}

/**
 * Right
 */
public void saveBootHeaper(Heaper boot) {
throw new UnsupportedOperationException();/*
udanax-top.st:11398:MockTurtle methodsFor: 'accessing'!
{void} saveBootHeaper: boot {Heaper}
	"Right"
	self willNotImplement.!
*/
}

/**
 * Right
 */
public void setProtocol(XcvrMaker xcvrMaker, Cookbook book) {
throw new UnsupportedOperationException();/*
udanax-top.st:11402:MockTurtle methodsFor: 'accessing'!
{void} setProtocol: xcvrMaker {XcvrMaker} with: book {Cookbook}
	"Right"
	self willNotImplement.!
*/
}

public  MockTurtle(Category bootCategory) {
throw new UnsupportedOperationException();/*
udanax-top.st:11408:MockTurtle methodsFor: 'protected: creation'!
create: bootCategory {Category}
	super create.
	(CurrentPacker fluidGet cast: FakePacker) storeTurtle: self.
	myAgenda _ NULL.
	myBootCategory _ bootCategory.
	myAgenda _ Agenda make.!
*/
}

public  MockTurtle(Rcvr receiver) {
throw new UnsupportedOperationException();/*
udanax-top.st:11417:MockTurtle methodsFor: 'generated:'!
create.Rcvr: receiver {Rcvr}
	super create.Rcvr: receiver.
	myAgenda _ receiver receiveHeaper.
	myBootCategory _ receiver receiveHeaper.!
*/
}

public void sendSelfTo(Xmtr xmtr) {
throw new UnsupportedOperationException();/*
udanax-top.st:11422:MockTurtle methodsFor: 'generated:'!
{void} sendSelfTo: xmtr {Xmtr}
	super sendSelfTo: xmtr.
	xmtr sendHeaper: myAgenda.
	xmtr sendHeaper: myBootCategory.!
*/
}

public static Heaper make(Category category) {
throw new UnsupportedOperationException();/*
udanax-top.st:11436:MockTurtle class methodsFor: 'pseudo-constructor'!
{Turtle} make: category {Category}
	^ self create: category!
*/
}
}
