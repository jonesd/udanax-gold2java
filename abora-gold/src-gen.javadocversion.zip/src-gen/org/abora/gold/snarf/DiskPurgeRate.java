/*
 * Abora-Gold
 * Part of the Abora hypertext project: http://www.abora.org
 * Copyright 2003 David G Jones
 * 
 * Translated from Udanax-Gold source code: http://www.udanax.com
 * Copyright 1979-1999 Udanax.com. All rights reserved
 */
package org.abora.gold.snarf;

import org.abora.gold.fm.support.Thunk;
import org.abora.gold.java.missing.IntegerVar;
import org.abora.gold.xcvr.Rcvr;
import org.abora.gold.xcvr.Xmtr;


/**
 * Set the number of GCs between purges of the packer.
 */
public class DiskPurgeRate extends Thunk {
	protected IntegerVar myCount;
/*
udanax-top.st:57237:
Thunk subclass: #DiskPurgeRate
	instanceVariableNames: 'myCount {IntegerVar}'
	classVariableNames: ''
	poolDictionaries: ''
	category: 'Xanadu-Snarf'!
*/
/*
udanax-top.st:57241:
DiskPurgeRate comment:
'Set the number of GCs between purges of the packer.'!
*/
/*
udanax-top.st:57243:
(DiskPurgeRate getOrMakeCxxClassDescription)
	attributes: ((Set new) add: #CONCRETE; add: #(COPY boot ); add: #NOT.A.TYPE; yourself)!
*/

/**
 * Set the number of GCs between packer purges.
 */
public void execute() {
throw new UnsupportedOperationException();/*
udanax-top.st:57248:DiskPurgeRate methodsFor: 'operate'!
{void} execute
	"Set the number of GCs between packer purges."
	
	Purgeror setPurgeRate: myCount!
*/
}

public  DiskPurgeRate(Rcvr receiver) {
throw new UnsupportedOperationException();/*
udanax-top.st:57255:DiskPurgeRate methodsFor: 'generated:'!
create.Rcvr: receiver {Rcvr}
	super create.Rcvr: receiver.
	myCount _ receiver receiveIntegerVar.!
*/
}

public void sendSelfTo(Xmtr xmtr) {
throw new UnsupportedOperationException();/*
udanax-top.st:57259:DiskPurgeRate methodsFor: 'generated:'!
{void} sendSelfTo: xmtr {Xmtr}
	super sendSelfTo: xmtr.
	xmtr sendIntegerVar: myCount.!
*/
}
}
