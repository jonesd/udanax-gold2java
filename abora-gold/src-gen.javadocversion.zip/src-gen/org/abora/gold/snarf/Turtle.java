/*
 * Abora-Gold
 * Part of the Abora hypertext project: http://www.abora.org
 * Copyright 2003 David G Jones
 * 
 * Translated from Udanax-Gold source code: http://www.udanax.com
 * Copyright 1979-1999 Udanax.com. All rights reserved
 */
package org.abora.gold.snarf;

import org.abora.gold.cobbler.Cookbook;
import org.abora.gold.counter.Counter;
import org.abora.gold.snarf.Abraham;
import org.abora.gold.turtle.Agenda;
import org.abora.gold.xcvr.Rcvr;
import org.abora.gold.xcvr.XcvrMaker;
import org.abora.gold.xcvr.Xmtr;
import org.abora.gold.xpp.basic.Category;
import org.abora.gold.xpp.basic.Heaper;


public class Turtle extends Abraham {
/*
udanax-top.st:11290:
Abraham subclass: #Turtle
	instanceVariableNames: ''
	classVariableNames: ''
	poolDictionaries: ''
	category: 'Xanadu-Snarf'!
*/
/*
udanax-top.st:11294:
(Turtle getOrMakeCxxClassDescription)
	attributes: ((Set new) add: #DEFERRED; add: #COPY; add: #SHEPHERD.PATRIARCH; add: #DEFERRED.LOCKED; yourself)!
*/
/*
udanax-top.st:11351:
Turtle class
	instanceVariableNames: ''!
*/
/*
udanax-top.st:11354:
(Turtle getOrMakeCxxClassDescription)
	attributes: ((Set new) add: #DEFERRED; add: #COPY; add: #SHEPHERD.PATRIARCH; add: #DEFERRED.LOCKED; yourself)!
*/

public Category bootCategory() {
throw new UnsupportedOperationException();/*
udanax-top.st:11299:Turtle methodsFor: 'accessing'!
{Category} bootCategory
	self subclassResponsibility!
*/
}

public Heaper bootHeaper() {
throw new UnsupportedOperationException();/*
udanax-top.st:11302:Turtle methodsFor: 'accessing'!
{Heaper} bootHeaper
	self subclassResponsibility!
*/
}

public Cookbook cookbook() {
throw new UnsupportedOperationException();/*
udanax-top.st:11305:Turtle methodsFor: 'accessing'!
{Cookbook} cookbook
	self subclassResponsibility!
*/
}

public Counter counter() {
throw new UnsupportedOperationException();/*
udanax-top.st:11308:Turtle methodsFor: 'accessing'!
{Counter} counter
	self subclassResponsibility!
*/
}

/**
 * Under all normal conditions, a Turtle has an Agenda.  However, during the construction of
 * a Turtle, there may arise situations when a piece of code is invoked which normally asks
 * the Turtle for its agenda before the Turtle is mature enough to have one.
 */
public Agenda fetchAgenda() {
throw new UnsupportedOperationException();/*
udanax-top.st:11311:Turtle methodsFor: 'accessing'!
{Agenda | NULL} fetchAgenda
	"Under all normal conditions, a Turtle has an Agenda.  However, during the construction of a Turtle, there may arise situations when a piece of code is invoked which normally asks the Turtle for its agenda before the Turtle is mature enough to have one."
	
	self subclassResponsibility!
*/
}

/**
 * See Turtle::fetchAgenda()
 */
public Agenda getAgenda() {
throw new UnsupportedOperationException();/*
udanax-top.st:11316:Turtle methodsFor: 'accessing'!
{Agenda} getAgenda
	"See Turtle::fetchAgenda()"
	
	| result {Agenda | NULL} |
	result _ self fetchAgenda.
	result == NULL
		ifTrue: [Heaper BLAST: #TurtleNotMature].
	^result!
*/
}

public XcvrMaker protocol() {
throw new UnsupportedOperationException();/*
udanax-top.st:11325:Turtle methodsFor: 'accessing'!
{XcvrMaker} protocol
	self subclassResponsibility!
*/
}

public void saveBootHeaper(Heaper boot) {
throw new UnsupportedOperationException();/*
udanax-top.st:11328:Turtle methodsFor: 'accessing'!
{void} saveBootHeaper: boot {Heaper}
	self subclassResponsibility!
*/
}

public void setProtocol(XcvrMaker xcvrMaker, Cookbook book) {
throw new UnsupportedOperationException();/*
udanax-top.st:11331:Turtle methodsFor: 'accessing'!
{void} setProtocol: xcvrMaker {XcvrMaker} with: book {Cookbook}
	self subclassResponsibility!
*/
}

public  Turtle() {
throw new UnsupportedOperationException();/*
udanax-top.st:11336:Turtle methodsFor: 'protected: creation'!
create
	super create!
*/
}

public  Turtle(int hash) {
throw new UnsupportedOperationException();/*
udanax-top.st:11339:Turtle methodsFor: 'protected: creation'!
create: hash {UInt32}
	super create: hash!
*/
}

public  Turtle(Rcvr receiver) {
throw new UnsupportedOperationException();/*
udanax-top.st:11344:Turtle methodsFor: 'generated:'!
create.Rcvr: receiver {Rcvr}
	super create.Rcvr: receiver.!
*/
}

public void sendSelfTo(Xmtr xmtr) {
throw new UnsupportedOperationException();/*
udanax-top.st:11347:Turtle methodsFor: 'generated:'!
{void} sendSelfTo: xmtr {Xmtr}
	super sendSelfTo: xmtr.!
*/
}

public static Heaper make(Cookbook cookbook, Category bootCategory, XcvrMaker maker) {
throw new UnsupportedOperationException();/*
udanax-top.st:11359:Turtle class methodsFor: 'pseudo-constructors'!
make: cookbook {Cookbook} with:  bootCategory {Category} with: maker {XcvrMaker}
	^SimpleTurtle make: cookbook with: bootCategory with: maker!
*/
}
}
