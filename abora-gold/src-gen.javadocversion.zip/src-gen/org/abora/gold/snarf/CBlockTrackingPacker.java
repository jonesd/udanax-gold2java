/*
 * Abora-Gold
 * Part of the Abora hypertext project: http://www.abora.org
 * Copyright 2003 David G Jones
 * 
 * Translated from Udanax-Gold source code: http://www.udanax.com
 * Copyright 1979-1999 Udanax.com. All rights reserved
 */
package org.abora.gold.snarf;

import org.abora.gold.cobbler.Cookbook;
import org.abora.gold.java.missing.IntegerVar;
import org.abora.gold.java.missing.SnarfID;
import org.abora.gold.snarf.Abraham;
import org.abora.gold.snarf.CBlockTracker;
import org.abora.gold.snarf.DiskManager;
import org.abora.gold.snarf.FlockInfo;
import org.abora.gold.snarf.Turtle;
import org.abora.gold.xcvr.XcvrMaker;
import org.abora.gold.xpp.basic.Heaper;


public class CBlockTrackingPacker extends DiskManager {
	protected DiskManager myPacker;
	protected CBlockTracker myTracker;
/*
udanax-top.st:16528:
DiskManager subclass: #CBlockTrackingPacker
	instanceVariableNames: '
		myPacker {DiskManager}
		myTracker {CBlockTracker | NULL}'
	classVariableNames: ''
	poolDictionaries: ''
	category: 'Xanadu-Snarf'!
*/
/*
udanax-top.st:16534:
(CBlockTrackingPacker getOrMakeCxxClassDescription)
	attributes: ((Set new) add: #CONCRETE; yourself)!
*/
/*
udanax-top.st:16681:
CBlockTrackingPacker class
	instanceVariableNames: ''!
*/
/*
udanax-top.st:16684:
(CBlockTrackingPacker getOrMakeCxxClassDescription)
	attributes: ((Set new) add: #CONCRETE; yourself)!
*/

public void beginConsistent(IntegerVar dirty) {
throw new UnsupportedOperationException();/*
udanax-top.st:16539:CBlockTrackingPacker methodsFor: 'transactions'!
{void} beginConsistent: dirty {IntegerVar}
	myTracker _ CBlockTracker make: dirty with: myTracker.
	myPacker beginConsistent: dirty!
*/
}

public void consistentBlockAt(String fileName, int lineNo) {
throw new UnsupportedOperationException();/*
udanax-top.st:16544:CBlockTrackingPacker methodsFor: 'transactions'!
{void} consistentBlockAt: fileName {char star} with: lineNo {Int32}
	
	self checkTracker ifTrue:
		[myTracker track: fileName with: lineNo.
		myPacker consistentBlockAt: fileName with: lineNo]!
*/
}

public void endConsistent(IntegerVar dirty) {
throw new UnsupportedOperationException();/*
udanax-top.st:16550:CBlockTrackingPacker methodsFor: 'transactions'!
{void} endConsistent: dirty {IntegerVar} 
	
	self checkTracker ifTrue:
		[myTracker _ myTracker fetchUnwrapped.
		myPacker endConsistent: dirty]!
*/
}

public boolean insideCommit() {
throw new UnsupportedOperationException();/*
udanax-top.st:16556:CBlockTrackingPacker methodsFor: 'transactions'!
{BooleanVar} insideCommit
	^ myPacker insideCommit!
*/
}

public void purge() {
throw new UnsupportedOperationException();/*
udanax-top.st:16559:CBlockTrackingPacker methodsFor: 'transactions'!
{void} purge
	myPacker purge!
*/
}

public void purgeClean(boolean noneLocked) {
throw new UnsupportedOperationException();/*
udanax-top.st:16563:CBlockTrackingPacker methodsFor: 'transactions'!
{void} purgeClean: noneLocked {BooleanVar default: false}
	myPacker purgeClean: noneLocked!
*/
}

/**
 * Queue destroy of the given flock.  The destroy will probably happen later.
 */
public void destroyFlock(FlockInfo info) {
throw new UnsupportedOperationException();/*
udanax-top.st:16570:CBlockTrackingPacker methodsFor: 'shepherds'!
{void} destroyFlock: info {FlockInfo} 
	"Queue destroy of the given flock.  The destroy will probably happen later."
	
	myPacker destroyFlock: info!
*/
}

public void diskUpdate(FlockInfo info) {
throw new UnsupportedOperationException();/*
udanax-top.st:16575:CBlockTrackingPacker methodsFor: 'shepherds'!
{void} diskUpdate: info {FlockInfo | NULL} 
	
	self checkTracker ifTrue:
		[myTracker dirty: info.
		myPacker diskUpdate: info]!
*/
}

/**
 * The flock designated by info has completed all dismantling actions; throw it off the disk.
 */
public void dismantleFlock(FlockInfo info) {
throw new UnsupportedOperationException();/*
udanax-top.st:16581:CBlockTrackingPacker methodsFor: 'shepherds'!
{void} dismantleFlock: info {FlockInfo} 
	"The flock designated by info has completed all dismantling actions; throw it off the disk."
	
	myPacker dismantleFlock: info!
*/
}

public void dropFlock(int token) {
throw new UnsupportedOperationException();/*
udanax-top.st:16586:CBlockTrackingPacker methodsFor: 'shepherds'!
{void} dropFlock: token {Int32} 
	myPacker dropFlock: token!
*/
}

public void forgetFlock(FlockInfo info) {
throw new UnsupportedOperationException();/*
udanax-top.st:16590:CBlockTrackingPacker methodsFor: 'shepherds'!
{void} forgetFlock: info {FlockInfo} 
	self checkTracker ifTrue:
		[myTracker dirty: info.
		myPacker forgetFlock: info]!
*/
}

public Turtle getInitialFlock() {
throw new UnsupportedOperationException();/*
udanax-top.st:16596:CBlockTrackingPacker methodsFor: 'shepherds'!
{Turtle} getInitialFlock
	 
	^myPacker getInitialFlock!
*/
}

public int nextHashForEqual() {
throw new UnsupportedOperationException();/*
udanax-top.st:16600:CBlockTrackingPacker methodsFor: 'shepherds'!
{UInt32} nextHashForEqual
	
	^myPacker nextHashForEqual!
*/
}

public void rememberFlock(FlockInfo info) {
throw new UnsupportedOperationException();/*
udanax-top.st:16604:CBlockTrackingPacker methodsFor: 'shepherds'!
{void} rememberFlock: info {FlockInfo} 
	
	self checkTracker ifTrue:
		[myTracker dirty: info.
		myPacker rememberFlock: info]!
*/
}

public void storeAlmostNewShepherd(Abraham shep) {
throw new UnsupportedOperationException();/*
udanax-top.st:16610:CBlockTrackingPacker methodsFor: 'shepherds'!
{void} storeAlmostNewShepherd: shep {Abraham} 
	myPacker storeAlmostNewShepherd: shep!
*/
}

public void storeInitialFlock(Abraham turtle, XcvrMaker protocol, Cookbook cookbook) {
throw new UnsupportedOperationException();/*
udanax-top.st:16614:CBlockTrackingPacker methodsFor: 'shepherds'!
{void} storeInitialFlock: turtle {Abraham} with: protocol {XcvrMaker} with: cookbook {Cookbook}
	myPacker storeInitialFlock: turtle with: protocol with: cookbook!
*/
}

public void storeNewFlock(Abraham shep) {
throw new UnsupportedOperationException();/*
udanax-top.st:16617:CBlockTrackingPacker methodsFor: 'shepherds'!
{void} storeNewFlock: shep {Abraham} 
	self checkTracker ifTrue:
		[myPacker storeNewFlock: shep.
		myTracker dirty: shep getInfo]!
*/
}

public Abraham fetchCanonical(int hash, SnarfID snarfID, int index) {
throw new UnsupportedOperationException();/*
udanax-top.st:16625:CBlockTrackingPacker methodsFor: 'stubs'!
{Abraham} fetchCanonical: hash {UInt32} with: snarfID {SnarfID} with: index {Int32}
	
	^myPacker fetchCanonical: hash with: snarfID with: index!
*/
}

public void makeReal(FlockInfo info) {
throw new UnsupportedOperationException();/*
udanax-top.st:16629:CBlockTrackingPacker methodsFor: 'stubs'!
{void} makeReal: info {FlockInfo}
	
	myPacker makeReal: info!
*/
}

public void registerStub(Abraham shep, SnarfID snarfID, int index) {
throw new UnsupportedOperationException();/*
udanax-top.st:16633:CBlockTrackingPacker methodsFor: 'stubs'!
{void} registerStub: shep {Abraham} with: snarfID {SnarfID} with: index {Int32}
	myPacker registerStub: shep with: snarfID with: index!
*/
}

public void consistentCount() {
throw new UnsupportedOperationException();/*
udanax-top.st:16639:CBlockTrackingPacker methodsFor: 'smalltalk: testing'!
consistentCount
	^myPacker consistentCount!
*/
}

public  CBlockTrackingPacker(DiskManager subPacker) {
throw new UnsupportedOperationException();/*
udanax-top.st:16644:CBlockTrackingPacker methodsFor: 'create'!
create: subPacker {DiskManager} 
	super create.
	myPacker _ subPacker.
	myTracker _ NULL.
	self flockTable: myPacker flockTable.
	self flockInfoTable: myPacker flockInfoTable.!
*/
}

public void destruct() {
throw new UnsupportedOperationException();/*
udanax-top.st:16654:CBlockTrackingPacker methodsFor: 'protected: destruction'!
{void} destruct
	
	(myTracker == NULL) assert.
	myPacker destroy.
	super destruct!
*/
}

public boolean isFake() {
throw new UnsupportedOperationException();/*
udanax-top.st:16662:CBlockTrackingPacker methodsFor: 'testing'!
{BooleanVar} isFake
	^ myPacker isFake!
*/
}

public boolean checkTracker() {
throw new UnsupportedOperationException();/*
udanax-top.st:16667:CBlockTrackingPacker methodsFor: 'private:'!
{BooleanVar} checkTracker 
	
	myTracker ~~ NULL ifTrue:
		[^true].
	[Logger] USES.
	ErrorLog << 'Must be inside consistent block
'!
*/
}

/**
 * Used by ResetCommit bomb
 */
public void commitState(boolean flag) {
throw new UnsupportedOperationException();/*
udanax-top.st:16675:CBlockTrackingPacker methodsFor: 'private:'!
{void} commitState: flag {BooleanVar}
	"Used by ResetCommit bomb"
	
	(myPacker cast: SnarfPacker) commitState: flag!
*/
}

public static Heaper make(DiskManager subPacker) {
throw new UnsupportedOperationException();/*
udanax-top.st:16689:CBlockTrackingPacker class methodsFor: 'creation'!
{DiskManager} make: subPacker {DiskManager} 
	
	^CBlockTrackingPacker create: subPacker!
*/
}
}
