/*
 * Abora-Gold
 * Part of the Abora hypertext project: http://www.abora.org
 * Copyright 2003 David G Jones
 * 
 * Translated from Udanax-Gold source code: http://www.udanax.com
 * Copyright 1979-1999 Udanax.com. All rights reserved
 */
package org.abora.gold.snarf;

import org.abora.gold.cache.InstanceCache;
import org.abora.gold.cobbler.Cookbook;
import org.abora.gold.xcvr.SpecialistRcvr;
import org.abora.gold.xcvr.SpecialistXmtr;
import org.abora.gold.xcvr.TransferSpecialist;
import org.abora.gold.xpp.basic.Category;
import org.abora.gold.xpp.basic.Heaper;


public class DiskCountSpecialist extends TransferSpecialist {
	protected boolean myInsideShepherd;
	protected static int MaxFlocks;
	protected static int MaxSnarfs;
	protected static InstanceCache SomeSpecialists;
/*
udanax-top.st:63125:
TransferSpecialist subclass: #DiskCountSpecialist
	instanceVariableNames: 'myInsideShepherd {BooleanVar}'
	classVariableNames: '
		MaxFlocks {Int32} 
		MaxSnarfs {Int32} 
		SomeSpecialists {InstanceCache} '
	poolDictionaries: ''
	category: 'Xanadu-Snarf'!
*/
/*
udanax-top.st:63132:
(DiskCountSpecialist getOrMakeCxxClassDescription)
	attributes: ((Set new) add: #CONCRETE; add: #NOT.A.TYPE; yourself)!
*/
/*
udanax-top.st:63181:
DiskCountSpecialist class
	instanceVariableNames: ''!
*/
/*
udanax-top.st:63184:
(DiskCountSpecialist getOrMakeCxxClassDescription)
	attributes: ((Set new) add: #CONCRETE; add: #NOT.A.TYPE; yourself)!
*/

public  DiskCountSpecialist(Cookbook cookbook) {
	super(cookbook);
throw new UnsupportedOperationException();/*
udanax-top.st:63137:DiskCountSpecialist methodsFor: 'creation'!
create: cookbook {Cookbook}
	super create: cookbook.
	myInsideShepherd _ false!
*/
}

public void destroy() {
throw new UnsupportedOperationException();/*
udanax-top.st:63141:DiskCountSpecialist methodsFor: 'creation'!
{void} destroy
	(SomeSpecialists store: self) ifFalse: [super destroy]!
*/
}

/**
 * DiskCountSpecialist are only for sending.
 */
public Heaper receiveHeaperFrom(Category cat, SpecialistRcvr rcvr) {
throw new UnsupportedOperationException();/*
udanax-top.st:63146:DiskCountSpecialist methodsFor: 'communication'!
{Heaper} receiveHeaper: cat {Category unused} from: rcvr {SpecialistRcvr unused}
 	"DiskCountSpecialist are only for sending."
	Heaper BLAST: #IncompleteAbstraction.
	^NULL!
*/
}

/**
 * DiskCountSpecialist are only for sending.
 */
public void receiveHeaperIntoFrom(Category cat, Heaper memory, SpecialistRcvr rcvr) {
throw new UnsupportedOperationException();/*
udanax-top.st:63152:DiskCountSpecialist methodsFor: 'communication'!
{void} receiveHeaper: cat {Category unused} into: memory {Heaper unused} from: rcvr {SpecialistRcvr unused} 
	"DiskCountSpecialist are only for sending."
	
	Heaper BLAST: #IncompleteAbstraction!
*/
}

/**
 * Handle sending Shepherds specially.
 */
public void sendHeaperTo(Heaper hpr, SpecialistXmtr xmtr) {
throw new UnsupportedOperationException();/*
udanax-top.st:63157:DiskCountSpecialist methodsFor: 'communication'!
{void} sendHeaper: hpr {Heaper} to: xmtr {SpecialistXmtr} 
	"Handle sending Shepherds specially."
	hpr cast: Abraham into: [:abe |
			myInsideShepherd
				ifTrue: 
					[abe getInfo.  "Test to verify that all persistently pointed-at sheps didi newShepherd."
					xmtr startInstance: abe with: abe getShepherdStubCategory.
					xmtr sendUInt32: abe hashForEqual.
					[xmtr sendCategory:
						(abe isStub
							ifTrue: [abe getCategoryFromStub]
							ifFalse: [abe getCategory])] smalltalkOnly.
					xmtr sendUInt32: MaxSnarfs.
					xmtr sendUInt32: MaxFlocks.
					xmtr endInstance]
				ifFalse: 
					[myInsideShepherd _ true.
					super sendHeaper: abe to: xmtr.
					myInsideShepherd _ false].
			^VOID]
		others: [super sendHeaper: hpr to: xmtr]!
*/
}

public static Heaper make(Cookbook aBook) {
throw new UnsupportedOperationException();/*
udanax-top.st:63189:DiskCountSpecialist class methodsFor: 'creation'!
{TransferSpecialist} make: aBook {Cookbook}
	| result {Heaper} |
	result := SomeSpecialists fetch.
	result == NULL
		ifTrue: [^self create: aBook]
		ifFalse: [^(self new.Become: result) create: aBook]!
*/
}

public static void initTimeNonInherited() {
throw new UnsupportedOperationException();/*
udanax-top.st:63198:DiskCountSpecialist class methodsFor: 'smalltalk: initialization'!
initTimeNonInherited
	SomeSpecialists := InstanceCache make: 16!
*/
}

public static void linkTimeNonInherited() {
throw new UnsupportedOperationException();/*
udanax-top.st:63201:DiskCountSpecialist class methodsFor: 'smalltalk: initialization'!
linkTimeNonInherited
	MaxSnarfs _ 3000000.
	MaxFlocks _ 3000000.
	SomeSpecialists := NULL!
*/
}
}
