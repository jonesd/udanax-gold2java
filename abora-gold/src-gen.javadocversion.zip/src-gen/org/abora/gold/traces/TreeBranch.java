/*
 * Abora-Gold
 * Part of the Abora hypertext project: http://www.abora.org
 * Copyright 2003 David G Jones
 * 
 * Translated from Udanax-Gold source code: http://www.udanax.com
 * Copyright 1979-1999 Udanax.com. All rights reserved
 */
package org.abora.gold.traces;

import org.abora.gold.primtab.PrimIndexTable;
import org.abora.gold.traces.BranchDescription;
import org.abora.gold.traces.DagWood;
import org.abora.gold.traces.TracePosition;
import org.abora.gold.xcvr.Rcvr;
import org.abora.gold.xcvr.Xmtr;


public class TreeBranch extends BranchDescription {
	protected TracePosition parent;
/*
udanax-top.st:4466:
BranchDescription subclass: #TreeBranch
	instanceVariableNames: 'parent {TracePosition}'
	classVariableNames: ''
	poolDictionaries: ''
	category: 'Xanadu-Traces'!
*/
/*
udanax-top.st:4470:
(TreeBranch getOrMakeCxxClassDescription)
	attributes: ((Set new) add: #COPY; add: #SHEPHERD.ANCESTOR; add: #LOCKED; add: #NOT.A.TYPE; add: #CONCRETE; yourself)!
*/

public void cacheRecur(PrimIndexTable navCache) {
throw new UnsupportedOperationException();/*
udanax-top.st:4475:TreeBranch methodsFor: 'caching'!
{void} cacheRecur: navCache {PrimIndexTable}
	parent cacheIn: navCache!
*/
}

public  TreeBranch(DagWood ft, TracePosition p) {
	super(ft);
throw new UnsupportedOperationException();/*
udanax-top.st:4480:TreeBranch methodsFor: 'create'!
create: ft {DagWood} with: p {TracePosition}
	super create: ft.
	parent _ p.
	self newShepherd.
	self remember!
*/
}

public int contentsHash() {
throw new UnsupportedOperationException();/*
udanax-top.st:4488:TreeBranch methodsFor: 'testing'!
{UInt32} contentsHash
	^super contentsHash
		bitXor: parent hashForEqual!
*/
}

public  TreeBranch(Rcvr receiver) {
	super(receiver);
throw new UnsupportedOperationException();/*
udanax-top.st:4495:TreeBranch methodsFor: 'generated:'!
create.Rcvr: receiver {Rcvr}
	super create.Rcvr: receiver.
	parent _ receiver receiveHeaper.!
*/
}

public void sendSelfTo(Xmtr xmtr) {
throw new UnsupportedOperationException();/*
udanax-top.st:4499:TreeBranch methodsFor: 'generated:'!
{void} sendSelfTo: xmtr {Xmtr}
	super sendSelfTo: xmtr.
	xmtr sendHeaper: parent.!
*/
}
}
