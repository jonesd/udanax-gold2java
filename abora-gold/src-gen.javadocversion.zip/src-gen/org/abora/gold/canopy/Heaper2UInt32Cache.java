/*
 * Abora-Gold
 * Part of the Abora hypertext project: http://www.abora.org
 * Copyright 2003 David G Jones
 * 
 * Translated from Udanax-Gold source code: http://www.udanax.com
 * Copyright 1979-1999 Udanax.com. All rights reserved
 */
package org.abora.gold.canopy;

import org.abora.gold.collection.basic.PtrArray;
import org.abora.gold.collection.basic.UInt32Array;
import org.abora.gold.xpp.basic.Heaper;


/**
 * Caches a mapping from Heapers (using isEqual / hashForEqual) to UInt32s. Returns
 * myEmptyValue if there is no cached mapping.
 */
public class Heaper2UInt32Cache extends Heaper {
	protected PtrArray myKeys;
	protected UInt32Array myValues;
	protected int myEmptyValue;
/*
udanax-top.st:27019:
Heaper subclass: #Heaper2UInt32Cache
	instanceVariableNames: '
		myKeys {PtrArray}
		myValues {UInt32Array}
		myEmptyValue {UInt32}'
	classVariableNames: ''
	poolDictionaries: ''
	category: 'Xanadu-canopy'!
*/
/*
udanax-top.st:27026:
Heaper2UInt32Cache comment:
'Caches a mapping from Heapers (using isEqual / hashForEqual) to UInt32s. Returns myEmptyValue if there is no cached mapping.'!
*/
/*
udanax-top.st:27028:
(Heaper2UInt32Cache getOrMakeCxxClassDescription)
	attributes: ((Set new) add: #CONCRETE; add: #EQ; yourself)!
*/
/*
udanax-top.st:27079:
Heaper2UInt32Cache class
	instanceVariableNames: ''!
*/
/*
udanax-top.st:27082:
(Heaper2UInt32Cache getOrMakeCxxClassDescription)
	attributes: ((Set new) add: #CONCRETE; add: #EQ; yourself)!
*/

/**
 * Cache a value for a key
 */
public void atCache(Heaper key, int value) {
throw new UnsupportedOperationException();/*
udanax-top.st:27033:Heaper2UInt32Cache methodsFor: 'accessing'!
{void} at: key {Heaper} cache: value {UInt32}
	"Cache a value for a key"
	
	| index {Int32} |
	index := key hashForEqual \\ myKeys count.
	myKeys at: index store: key.
	myValues at: index storeUInt: value.!
*/
}

/**
 * Return the cached value for the key, or my empty value if there is none
 */
public int fetch(Heaper key) {
throw new UnsupportedOperationException();/*
udanax-top.st:27041:Heaper2UInt32Cache methodsFor: 'accessing'!
{UInt32} fetch: key {Heaper}
	"Return the cached value for the key, or my empty value if there is none"
	
	| index {Int32} k {Heaper} |
	index := key hashForEqual \\ myKeys count.
	k := myKeys fetch: index.
	(k ~~ NULL and: [k == key or: [k isEqual: key]])
		ifTrue: [^myValues uIntAt: index]
		ifFalse: [^myEmptyValue]!
*/
}

/**
 * Return the cached value for the key, or BLAST if there is none
 */
public int get(Heaper key) {
throw new UnsupportedOperationException();/*
udanax-top.st:27051:Heaper2UInt32Cache methodsFor: 'accessing'!
{UInt32} get: key {Heaper}
	"Return the cached value for the key, or BLAST if there is none"
	
	| index {Int32} k {Heaper} |
	index := key hashForEqual \\ myKeys count.
	k := myKeys fetch: index.
	(k ~~ NULL and: [k == key or: [k isEqual: key]])
		ifFalse: [Heaper BLAST: #NotInTable].
	^myValues uIntAt: index!
*/
}

public  Heaper2UInt32Cache(int count, int empty) {
throw new UnsupportedOperationException();/*
udanax-top.st:27063:Heaper2UInt32Cache methodsFor: 'create'!
create: count {Int32} with: empty {UInt32}
	super create.
	myKeys := PtrArray nulls: count.
	myValues := UInt32Array make: count.
	myEmptyValue := empty.
	empty ~~ UInt32Zero ifTrue:
		[myValues storeAll: (PrimIntValue make: empty)]!
*/
}

public int actualHashForEqual() {
throw new UnsupportedOperationException();/*
udanax-top.st:27074:Heaper2UInt32Cache methodsFor: 'generated:'!
actualHashForEqual ^self asOop!
*/
}

public boolean isEqual(Object other) {
throw new UnsupportedOperationException();/*
udanax-top.st:27076:Heaper2UInt32Cache methodsFor: 'generated:'!
isEqual: other ^self == other!
*/
}

public static Heaper make(Object n) {
throw new UnsupportedOperationException();/*
udanax-top.st:27087:Heaper2UInt32Cache class methodsFor: 'smalltalk: defaults'!
make: n
	^self make: n with: 0!
*/
}

public static Heaper make(int count, int empty) {
throw new UnsupportedOperationException();/*
udanax-top.st:27092:Heaper2UInt32Cache class methodsFor: 'create'!
make: count {Int32} with: empty {UInt32 default: UInt32Zero}
	^self create: (PrimeSizeProvider make uInt32PrimeAfter: count) with: empty!
*/
}

public static void initTimeNonInherited() {
throw new UnsupportedOperationException();/*
udanax-top.st:27098:Heaper2UInt32Cache class methodsFor: 'smalltalk: init'!
initTimeNonInherited
	self REQUIRES: PrimArray.
	self REQUIRES: PrimeSizeProvider.!
*/
}
}
