/*
 * Abora-Gold
 * Part of the Abora hypertext project: http://www.abora.org
 * Copyright 2003 David G Jones
 * 
 * Translated from Udanax-Gold source code: http://www.udanax.com
 * Copyright 1979-1999 Udanax.com. All rights reserved
 */
package org.abora.gold.spaces;

import java.io.PrintWriter;
import org.abora.gold.collection.sets.ImmuSet;
import org.abora.gold.spaces.basic.CoordinateSpace;
import org.abora.gold.spaces.basic.Dsp;
import org.abora.gold.spaces.basic.Mapping;
import org.abora.gold.spaces.basic.Position;
import org.abora.gold.spaces.basic.XnRegion;
import org.abora.gold.xcvr.Rcvr;
import org.abora.gold.xcvr.Xmtr;
import org.abora.gold.xpp.basic.Heaper;


public class ConstantMapping extends Mapping {
	protected CoordinateSpace myCoordinateSpace;
	protected XnRegion myValues;
/*
udanax-top.st:28866:
Mapping subclass: #ConstantMapping
	instanceVariableNames: '
		myCoordinateSpace {CoordinateSpace}
		myValues {XnRegion}'
	classVariableNames: ''
	poolDictionaries: ''
	category: 'Xanadu-Spaces'!
*/
/*
udanax-top.st:28872:
(ConstantMapping getOrMakeCxxClassDescription)
	attributes: ((Set new) add: #CONCRETE; add: #NOT.A.TYPE; add: #COPY; yourself)!
*/

public  ConstantMapping(CoordinateSpace cs, XnRegion values) {
throw new UnsupportedOperationException();/*
udanax-top.st:28877:ConstantMapping methodsFor: 'creation'!
create: cs {CoordinateSpace} with: values {XnRegion}
	super create.
	myCoordinateSpace _ cs.
	myValues _ values!
*/
}

public Position inverseOf(Position pos) {
throw new UnsupportedOperationException();/*
udanax-top.st:28884:ConstantMapping methodsFor: 'transforming'!
{Position} inverseOf: pos {Position unused}
	Heaper BLAST: #MultiplePreImages.
	^NULL!
*/
}

public XnRegion inverseOfAll(XnRegion reg) {
throw new UnsupportedOperationException();/*
udanax-top.st:28889:ConstantMapping methodsFor: 'transforming'!
{XnRegion} inverseOfAll: reg {XnRegion}
	(reg intersects: myValues)
		ifTrue: [^self domain]
		ifFalse: [^self coordinateSpace emptyRegion]!
*/
}

public Position of(Position pos) {
throw new UnsupportedOperationException();/*
udanax-top.st:28895:ConstantMapping methodsFor: 'transforming'!
{Position} of: pos {Position unused}
	(myValues isFinite and: [myValues count == 1])
		ifTrue: [^myValues theOne]
		ifFalse: [Heaper BLAST: #MultipleImages].
	^NULL "fodder"!
*/
}

public XnRegion ofAll(XnRegion reg) {
throw new UnsupportedOperationException();/*
udanax-top.st:28902:ConstantMapping methodsFor: 'transforming'!
{XnRegion} ofAll: reg {XnRegion}
	reg isEmpty
		ifTrue: [^self rangeSpace emptyRegion]
		ifFalse: [^self range]!
*/
}

public Mapping appliedAfter(Dsp dsp) {
throw new UnsupportedOperationException();/*
udanax-top.st:28910:ConstantMapping methodsFor: 'accessing'!
{Mapping} appliedAfter: dsp {Dsp unused}
	^self!
*/
}

public CoordinateSpace coordinateSpace() {
throw new UnsupportedOperationException();/*
udanax-top.st:28914:ConstantMapping methodsFor: 'accessing'!
{CoordinateSpace} coordinateSpace
	^ myCoordinateSpace!
*/
}

public XnRegion domain() {
throw new UnsupportedOperationException();/*
udanax-top.st:28918:ConstantMapping methodsFor: 'accessing'!
{XnRegion} domain
	
	^myCoordinateSpace fullRegion!
*/
}

public Dsp fetchDsp() {
throw new UnsupportedOperationException();/*
udanax-top.st:28922:ConstantMapping methodsFor: 'accessing'!
{Dsp | NULL} fetchDsp
	^ NULL!
*/
}

public boolean isComplete() {
throw new UnsupportedOperationException();/*
udanax-top.st:28925:ConstantMapping methodsFor: 'accessing'!
{BooleanVar} isComplete
	^true!
*/
}

public boolean isIdentity() {
throw new UnsupportedOperationException();/*
udanax-top.st:28929:ConstantMapping methodsFor: 'accessing'!
{BooleanVar} isIdentity
	^false!
*/
}

public Mapping preCompose(Dsp dsp) {
throw new UnsupportedOperationException();/*
udanax-top.st:28933:ConstantMapping methodsFor: 'accessing'!
{Mapping} preCompose: dsp {Dsp}
	^Mapping make.CoordinateSpace: myCoordinateSpace 
		with.Region: (dsp ofAll: myValues)!
*/
}

public XnRegion range() {
throw new UnsupportedOperationException();/*
udanax-top.st:28938:ConstantMapping methodsFor: 'accessing'!
{XnRegion} range
	^myValues!
*/
}

public CoordinateSpace rangeSpace() {
throw new UnsupportedOperationException();/*
udanax-top.st:28941:ConstantMapping methodsFor: 'accessing'!
{CoordinateSpace} rangeSpace
	^myValues coordinateSpace!
*/
}

public ImmuSet simpleMappings() {
throw new UnsupportedOperationException();/*
udanax-top.st:28945:ConstantMapping methodsFor: 'accessing'!
{ImmuSet of: Mapping} simpleMappings
	^ ImmuSet make with: self.!
*/
}

public ImmuSet simpleRegionMappings() {
throw new UnsupportedOperationException();/*
udanax-top.st:28948:ConstantMapping methodsFor: 'accessing'!
{ImmuSet of: Mapping} simpleRegionMappings
	^ ImmuSet make with: self.!
*/
}

public Mapping transformedBy(Dsp dsp) {
throw new UnsupportedOperationException();/*
udanax-top.st:28952:ConstantMapping methodsFor: 'accessing'!
{Mapping} transformedBy: dsp {Dsp}
	^Mapping make.CoordinateSpace: myCoordinateSpace 
		with.Region: (dsp ofAll: myValues)!
*/
}

public void printOn(PrintWriter oo) {
throw new UnsupportedOperationException();/*
udanax-top.st:28959:ConstantMapping methodsFor: 'printing'!
{void} printOn: oo {ostream reference}
	oo << self getCategory name << '(' << myValues << ')'!
*/
}

public int actualHashForEqual() {
throw new UnsupportedOperationException();/*
udanax-top.st:28965:ConstantMapping methodsFor: 'testing'!
{UInt32} actualHashForEqual
	^myCoordinateSpace hashForEqual + myValues hashForEqual!
*/
}

public boolean isEqual(Heaper other) {
throw new UnsupportedOperationException();/*
udanax-top.st:28968:ConstantMapping methodsFor: 'testing'!
{BooleanVar} isEqual: other {Heaper}
	other
		cast: ConstantMapping into: [:cm |
			^(cm coordinateSpace isEqual: myCoordinateSpace)
			 and: [cm values isEqual: myValues]]
		others: [^false].
	^false "fodder"!
*/
}

public XnRegion values() {
throw new UnsupportedOperationException();/*
udanax-top.st:28978:ConstantMapping methodsFor: 'private: private'!
{XnRegion} values
	^myValues!
*/
}

public Mapping inverse() {
throw new UnsupportedOperationException();/*
udanax-top.st:28983:ConstantMapping methodsFor: 'operations'!
{Mapping} inverse
	^(Mapping make.CoordinateSpace: self rangeSpace
		with.Region: self domainSpace fullRegion) restrict: self range!
*/
}

public Mapping restrict(XnRegion region) {
throw new UnsupportedOperationException();/*
udanax-top.st:28988:ConstantMapping methodsFor: 'operations'!
{Mapping} restrict: region {XnRegion}
	^SimpleMapping restrictTo: region with: self!
*/
}

public Mapping restrictRange(XnRegion region) {
throw new UnsupportedOperationException();/*
udanax-top.st:28992:ConstantMapping methodsFor: 'operations'!
{Mapping} restrictRange: region {XnRegion}
	^Mapping make.CoordinateSpace: myCoordinateSpace
		with.Region: (myValues intersect: region)!
*/
}

public Mapping fetchCombine(Mapping aMapping) {
throw new UnsupportedOperationException();/*
udanax-top.st:28999:ConstantMapping methodsFor: 'protected'!
{Mapping} fetchCombine: aMapping {Mapping}
	aMapping 
		cast: ConstantMapping into: [:cm |
			^Mapping make.CoordinateSpace: self coordinateSpace
				with.Region: (myValues unionWith: cm values)]
		others: [^NULL].
	^NULL "fodder"!
*/
}

public  ConstantMapping(Rcvr receiver) {
throw new UnsupportedOperationException();/*
udanax-top.st:29010:ConstantMapping methodsFor: 'generated:'!
create.Rcvr: receiver {Rcvr}
	super create.Rcvr: receiver.
	myCoordinateSpace _ receiver receiveHeaper.
	myValues _ receiver receiveHeaper.!
*/
}

public void sendSelfTo(Xmtr xmtr) {
throw new UnsupportedOperationException();/*
udanax-top.st:29015:ConstantMapping methodsFor: 'generated:'!
{void} sendSelfTo: xmtr {Xmtr}
	super sendSelfTo: xmtr.
	xmtr sendHeaper: myCoordinateSpace.
	xmtr sendHeaper: myValues.!
*/
}
}
