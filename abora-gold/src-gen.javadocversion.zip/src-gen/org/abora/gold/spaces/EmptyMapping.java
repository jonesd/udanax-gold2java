/*
 * Abora-Gold
 * Part of the Abora hypertext project: http://www.abora.org
 * Copyright 2003 David G Jones
 * 
 * Translated from Udanax-Gold source code: http://www.udanax.com
 * Copyright 1979-1999 Udanax.com. All rights reserved
 */
package org.abora.gold.spaces;

import java.io.PrintWriter;
import org.abora.gold.collection.sets.ImmuSet;
import org.abora.gold.spaces.basic.CoordinateSpace;
import org.abora.gold.spaces.basic.Dsp;
import org.abora.gold.spaces.basic.Mapping;
import org.abora.gold.spaces.basic.Position;
import org.abora.gold.spaces.basic.XnRegion;
import org.abora.gold.xcvr.Rcvr;
import org.abora.gold.xcvr.Xmtr;
import org.abora.gold.xpp.basic.Heaper;


public class EmptyMapping extends Mapping {
	protected CoordinateSpace myCS;
	protected CoordinateSpace myRS;
	protected static Mapping LastEmptyMapping;
	protected static CoordinateSpace LastEmptyMappingCoordinateSpace;
	protected static CoordinateSpace LastEmptyMappingRangeSpace;
/*
udanax-top.st:30122:
Mapping subclass: #EmptyMapping
	instanceVariableNames: '
		myCS {CoordinateSpace}
		myRS {CoordinateSpace}'
	classVariableNames: '
		LastEmptyMapping {Mapping} 
		LastEmptyMappingCoordinateSpace {CoordinateSpace} 
		LastEmptyMappingRangeSpace {CoordinateSpace} '
	poolDictionaries: ''
	category: 'Xanadu-Spaces'!
*/
/*
udanax-top.st:30131:
(EmptyMapping getOrMakeCxxClassDescription)
	friends:
'/- friends for class EmptyMapping -/
friend SPTR(Mapping) emptyMapping (CoordinateSpace * cs, CoordinateSpace * rs);
';
	attributes: ((Set new) add: #CONCRETE; add: #NOT.A.TYPE; add: #COPY; yourself)!
*/
/*
udanax-top.st:30263:
EmptyMapping class
	instanceVariableNames: ''!
*/
/*
udanax-top.st:30266:
(EmptyMapping getOrMakeCxxClassDescription)
	friends:
'/- friends for class EmptyMapping -/
friend SPTR(Mapping) emptyMapping (CoordinateSpace * cs, CoordinateSpace * rs);
';
	attributes: ((Set new) add: #CONCRETE; add: #NOT.A.TYPE; add: #COPY; yourself)!
*/

public CoordinateSpace coordinateSpace() {
throw new UnsupportedOperationException();/*
udanax-top.st:30140:EmptyMapping methodsFor: 'accessing'!
{CoordinateSpace} coordinateSpace
	^myCS!
*/
}

public XnRegion domain() {
throw new UnsupportedOperationException();/*
udanax-top.st:30144:EmptyMapping methodsFor: 'accessing'!
{XnRegion} domain
	^ self coordinateSpace emptyRegion.!
*/
}

public Dsp fetchDsp() {
throw new UnsupportedOperationException();/*
udanax-top.st:30148:EmptyMapping methodsFor: 'accessing'!
{Dsp | NULL} fetchDsp
	^NULL!
*/
}

public boolean isComplete() {
throw new UnsupportedOperationException();/*
udanax-top.st:30151:EmptyMapping methodsFor: 'accessing'!
{BooleanVar} isComplete
	^true!
*/
}

public boolean isIdentity() {
throw new UnsupportedOperationException();/*
udanax-top.st:30155:EmptyMapping methodsFor: 'accessing'!
{BooleanVar} isIdentity
	^false!
*/
}

public XnRegion range() {
throw new UnsupportedOperationException();/*
udanax-top.st:30159:EmptyMapping methodsFor: 'accessing'!
{XnRegion} range
	^ self rangeSpace emptyRegion.!
*/
}

public CoordinateSpace rangeSpace() {
throw new UnsupportedOperationException();/*
udanax-top.st:30162:EmptyMapping methodsFor: 'accessing'!
{CoordinateSpace} rangeSpace
	^myRS!
*/
}

public ImmuSet simpleMappings() {
throw new UnsupportedOperationException();/*
udanax-top.st:30166:EmptyMapping methodsFor: 'accessing'!
{ImmuSet of: Mapping} simpleMappings
	^ ImmuSet make!
*/
}

public ImmuSet simpleRegionMappings() {
throw new UnsupportedOperationException();/*
udanax-top.st:30170:EmptyMapping methodsFor: 'accessing'!
{ImmuSet of: Mapping} simpleRegionMappings
	^ ImmuSet make with: self.!
*/
}

public Position inverseOf(Position pos) {
throw new UnsupportedOperationException();/*
udanax-top.st:30176:EmptyMapping methodsFor: 'transforming'!
{Position} inverseOf: pos {Position unused}
	Heaper BLAST: #NotInRange.
	^ NULL!
*/
}

public XnRegion inverseOfAll(XnRegion reg) {
throw new UnsupportedOperationException();/*
udanax-top.st:30181:EmptyMapping methodsFor: 'transforming'!
{XnRegion} inverseOfAll: reg {XnRegion unused}
	^ self coordinateSpace emptyRegion.!
*/
}

public Position of(Position pos) {
throw new UnsupportedOperationException();/*
udanax-top.st:30185:EmptyMapping methodsFor: 'transforming'!
{Position} of: pos {Position unused}
	Heaper BLAST: #NotInDomain.
	^ NULL!
*/
}

public XnRegion ofAll(XnRegion reg) {
throw new UnsupportedOperationException();/*
udanax-top.st:30190:EmptyMapping methodsFor: 'transforming'!
{XnRegion} ofAll: reg {XnRegion unused}
	^self rangeSpace emptyRegion.!
*/
}

public  EmptyMapping(CoordinateSpace cs, CoordinateSpace rs) {
throw new UnsupportedOperationException();/*
udanax-top.st:30196:EmptyMapping methodsFor: 'private: private creation'!
create: cs {CoordinateSpace} with: rs {CoordinateSpace}
	super create.
	myCS _ cs.
	myRS _ rs.!
*/
}

public void printOn(PrintWriter stream) {
throw new UnsupportedOperationException();/*
udanax-top.st:30203:EmptyMapping methodsFor: 'printing'!
{void} printOn: stream {ostream reference}
	stream << self getCategory name.
	stream << '()'!
*/
}

public int actualHashForEqual() {
throw new UnsupportedOperationException();/*
udanax-top.st:30210:EmptyMapping methodsFor: 'testing'!
{UInt32} actualHashForEqual
	^#cat.U.EmptyMapping hashForEqual!
*/
}

/**
 * This, and the CompositeMapping version, don't check CoordinateSpaces.  Should they?
 */
public boolean isEqual(Heaper other) {
throw new UnsupportedOperationException();/*
udanax-top.st:30213:EmptyMapping methodsFor: 'testing'!
{BooleanVar} isEqual: other {Heaper}
	"This, and the CompositeMapping version, don't check CoordinateSpaces.  Should they?"
	^(other isKindOf: EmptyMapping)!
*/
}

public Mapping appliedAfter(Dsp dsp) {
throw new UnsupportedOperationException();/*
udanax-top.st:30219:EmptyMapping methodsFor: 'operations'!
{Mapping} appliedAfter: dsp {Dsp unused}
	^self!
*/
}

public Mapping inverse() {
throw new UnsupportedOperationException();/*
udanax-top.st:30223:EmptyMapping methodsFor: 'operations'!
{Mapping} inverse
	^Mapping make.CoordinateSpace: self rangeSpace
		with.CoordinateSpace: self domainSpace!
*/
}

public Mapping preCompose(Dsp dsp) {
throw new UnsupportedOperationException();/*
udanax-top.st:30228:EmptyMapping methodsFor: 'operations'!
{Mapping} preCompose: dsp {Dsp unused}
	^ self!
*/
}

public Mapping restrict(XnRegion region) {
throw new UnsupportedOperationException();/*
udanax-top.st:30232:EmptyMapping methodsFor: 'operations'!
{Mapping} restrict: region {XnRegion unused}
	^self!
*/
}

public Mapping restrictRange(XnRegion region) {
throw new UnsupportedOperationException();/*
udanax-top.st:30236:EmptyMapping methodsFor: 'operations'!
{Mapping} restrictRange: region {XnRegion unused}
	^self!
*/
}

public Mapping transformedBy(Dsp dsp) {
throw new UnsupportedOperationException();/*
udanax-top.st:30240:EmptyMapping methodsFor: 'operations'!
{Mapping} transformedBy: dsp {Dsp unused}
	^ self!
*/
}

public Mapping fetchCombine(Mapping mapping) {
throw new UnsupportedOperationException();/*
udanax-top.st:30246:EmptyMapping methodsFor: 'protected: protected'!
{Mapping} fetchCombine: mapping {Mapping}
	^ mapping!
*/
}

public  EmptyMapping(Rcvr receiver) {
throw new UnsupportedOperationException();/*
udanax-top.st:30252:EmptyMapping methodsFor: 'generated:'!
create.Rcvr: receiver {Rcvr}
	super create.Rcvr: receiver.
	myCS _ receiver receiveHeaper.
	myRS _ receiver receiveHeaper.!
*/
}

public void sendSelfTo(Xmtr xmtr) {
throw new UnsupportedOperationException();/*
udanax-top.st:30257:EmptyMapping methodsFor: 'generated:'!
{void} sendSelfTo: xmtr {Xmtr}
	super sendSelfTo: xmtr.
	xmtr sendHeaper: myCS.
	xmtr sendHeaper: myRS.!
*/
}

public static void linkTimeNonInherited() {
throw new UnsupportedOperationException();/*
udanax-top.st:30275:EmptyMapping class methodsFor: 'smalltalk: initialization'!
linkTimeNonInherited
	LastEmptyMapping _ NULL.
	LastEmptyMappingCoordinateSpace _ NULL.
	LastEmptyMappingRangeSpace _ NULL.!
*/
}

public static Heaper make(CoordinateSpace cs, CoordinateSpace rs) {
throw new UnsupportedOperationException();/*
udanax-top.st:30282:EmptyMapping class methodsFor: 'pseudoconstructor'!
{Mapping} make: cs {CoordinateSpace} with: rs {CoordinateSpace}
	(LastEmptyMapping == NULL
	 or: [(cs isEqual: LastEmptyMappingCoordinateSpace) not
	 or: [(rs isEqual: LastEmptyMappingRangeSpace) not]])
		ifTrue:
			[LastEmptyMappingCoordinateSpace _ cs.
			LastEmptyMappingRangeSpace _ rs.
			LastEmptyMapping _ EmptyMapping create: cs with: rs].
	^ LastEmptyMapping!
*/
}
}
