/*
 * Abora-Gold
 * Part of the Abora hypertext project: http://www.abora.org
 * Copyright 2003 David G Jones
 * 
 * Translated from Udanax-Gold source code: http://www.udanax.com
 * Copyright 1979-1999 Udanax.com. All rights reserved
 */
package org.abora.gold.spaces.integers;

import org.abora.gold.collection.sets.ImmuSet;
import org.abora.gold.spaces.integers.RegionTester;
import org.abora.gold.xcvr.Rcvr;
import org.abora.gold.xcvr.Xmtr;


public class IntegerRegionTester extends RegionTester {
/*
udanax-top.st:60072:
RegionTester subclass: #IntegerRegionTester
	instanceVariableNames: ''
	classVariableNames: ''
	poolDictionaries: ''
	category: 'Xanadu-Spaces-Integers'!
*/
/*
udanax-top.st:60076:
(IntegerRegionTester getOrMakeCxxClassDescription)
	attributes: ((Set new) add: #CONCRETE; add: #(COPY boot ); yourself)!
*/

/**
 * IntegerRegionTester runTest
 */
public ImmuSet initExamples() {
throw new UnsupportedOperationException();/*
udanax-top.st:60081:IntegerRegionTester methodsFor: 'init'!
{ImmuSet of: XnRegion} initExamples
	"IntegerRegionTester runTest"
	| acc {SetAccumulator of: XnRegion} |
	acc _ SetAccumulator make.
	acc step: IntegerRegion make.
	acc step: IntegerRegion make complement.
	acc step: (IntegerRegion make: 3 with: 7).
	acc step: (IntegerRegion make: 3 with: 7) complement.
	acc step: (IntegerRegion after: 5).
	acc step: (IntegerRegion before: 5).
	^acc value cast: ImmuSet!
*/
}

public  IntegerRegionTester(Rcvr receiver) {
throw new UnsupportedOperationException();/*
udanax-top.st:60095:IntegerRegionTester methodsFor: 'generated:'!
create.Rcvr: receiver {Rcvr}
	super create.Rcvr: receiver.!
*/
}

public void sendSelfTo(Xmtr xmtr) {
throw new UnsupportedOperationException();/*
udanax-top.st:60098:IntegerRegionTester methodsFor: 'generated:'!
{void} sendSelfTo: xmtr {Xmtr}
	super sendSelfTo: xmtr.!
*/
}
}
