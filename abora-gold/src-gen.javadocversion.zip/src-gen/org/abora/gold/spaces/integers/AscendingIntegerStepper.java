/*
 * Abora-Gold
 * Part of the Abora hypertext project: http://www.abora.org
 * Copyright 2003 David G Jones
 * 
 * Translated from Udanax-Gold source code: http://www.udanax.com
 * Copyright 1979-1999 Udanax.com. All rights reserved
 */
package org.abora.gold.spaces.integers;

import org.abora.gold.cache.InstanceCache;
import org.abora.gold.collection.basic.IntegerVarArray;
import org.abora.gold.collection.steppers.Stepper;
import org.abora.gold.java.missing.IntegerVar;
import org.abora.gold.xpp.basic.Heaper;


public class AscendingIntegerStepper extends Stepper {
	protected IntegerVarArray myEdges;
	protected int myIndex;
	protected int myCount;
	protected IntegerVar myPosition;
	protected static InstanceCache SomeSteppers;
/*
udanax-top.st:52949:
Stepper subclass: #AscendingIntegerStepper
	instanceVariableNames: '
		myEdges {IntegerVarArray}
		myIndex {UInt32}
		myCount {UInt32}
		myPosition {IntegerVar}'
	classVariableNames: 'SomeSteppers {InstanceCache} '
	poolDictionaries: ''
	category: 'Xanadu-Spaces-Integers'!
*/
/*
udanax-top.st:52957:
(AscendingIntegerStepper getOrMakeCxxClassDescription)
	attributes: ((Set new) add: #CONCRETE; add: #NOT.A.TYPE; yourself)!
*/
/*
udanax-top.st:53007:
AscendingIntegerStepper class
	instanceVariableNames: ''!
*/
/*
udanax-top.st:53010:
(AscendingIntegerStepper getOrMakeCxxClassDescription)
	attributes: ((Set new) add: #CONCRETE; add: #NOT.A.TYPE; yourself)!
*/

public  AscendingIntegerStepper(IntegerVarArray edges, int count) {
throw new UnsupportedOperationException();/*
udanax-top.st:52962:AscendingIntegerStepper methodsFor: 'protected: creation'!
create: edges {IntegerVarArray} with: count {UInt32}
	super create.
	myEdges _ edges.
	myIndex _ 1.
	myCount _ count.
	myCount > Int32Zero
		ifTrue: [myPosition _ myEdges integerVarAt: Int32Zero]
		ifFalse: [myPosition _ IntegerVar0]!
*/
}

public  AscendingIntegerStepper(IntegerVarArray edges, int index, int count, IntegerVar position) {
throw new UnsupportedOperationException();/*
udanax-top.st:52972:AscendingIntegerStepper methodsFor: 'protected: creation'!
create: edges {IntegerVarArray} with: index {UInt32} with: count {UInt32} with: position {IntegerVar}
	super create.
	myEdges _ edges.
	myIndex _ index.
	myCount _ count.
	myPosition _ position!
*/
}

public Stepper copy() {
throw new UnsupportedOperationException();/*
udanax-top.st:52981:AscendingIntegerStepper methodsFor: 'creation'!
{Stepper} copy
	| result {Heaper} |
	result := SomeSteppers fetch.
	result == NULL
		ifTrue: [^AscendingIntegerStepper create: myEdges with: myIndex with: myCount with: myPosition]
		ifFalse:[^(AscendingIntegerStepper new.Become: result) create: myEdges with: myIndex with: myCount with: myPosition]!
*/
}

public void destroy() {
throw new UnsupportedOperationException();/*
udanax-top.st:52988:AscendingIntegerStepper methodsFor: 'creation'!
{void} destroy
	(SomeSteppers store: self) ifFalse: [super destroy]!
*/
}

public Heaper fetch() {
throw new UnsupportedOperationException();/*
udanax-top.st:52993:AscendingIntegerStepper methodsFor: 'accessing'!
{Heaper wimpy} fetch
	self hasValue ifTrue: [^myPosition integer] ifFalse: [^NULL]!
*/
}

public boolean hasValue() {
throw new UnsupportedOperationException();/*
udanax-top.st:52996:AscendingIntegerStepper methodsFor: 'accessing'!
{BooleanVar} hasValue
	^myIndex <= myCount!
*/
}

public void step() {
throw new UnsupportedOperationException();/*
udanax-top.st:52999:AscendingIntegerStepper methodsFor: 'accessing'!
{void} step
	myPosition _ myPosition + 1.
	(myIndex < myCount and: [myPosition = (myEdges integerVarAt: myIndex)]) ifTrue:
		[myIndex _ myIndex + 2.
		myIndex <= myCount ifTrue:
			[myPosition _ myEdges integerVarAt: myIndex - 1]]!
*/
}

public static void initTimeNonInherited() {
throw new UnsupportedOperationException();/*
udanax-top.st:53015:AscendingIntegerStepper class methodsFor: 'smalltalk: init'!
initTimeNonInherited
	SomeSteppers := InstanceCache make: 16!
*/
}

public static void linkTimeNonInherited() {
throw new UnsupportedOperationException();/*
udanax-top.st:53018:AscendingIntegerStepper class methodsFor: 'smalltalk: init'!
linkTimeNonInherited
	SomeSteppers := NULL!
*/
}

public static Heaper make(IntegerVarArray edges, int count) {
throw new UnsupportedOperationException();/*
udanax-top.st:53023:AscendingIntegerStepper class methodsFor: 'creation'!
{Stepper} make: edges {IntegerVarArray} with: count {UInt32}
	| result {Heaper} |
	result := SomeSteppers fetch.
	result == NULL
		ifTrue: [^ self create: edges with: count]
		ifFalse: [^ (self new.Become: result) create: edges with: count]!
*/
}
}
