/*
 * Abora-Gold
 * Part of the Abora hypertext project: http://www.abora.org
 * Copyright 2003 David G Jones
 * 
 * Translated from Udanax-Gold source code: http://www.udanax.com
 * Copyright 1979-1999 Udanax.com. All rights reserved
 */
package org.abora.gold.spaces.integers;

import org.abora.gold.collection.basic.IntegerVarArray;
import org.abora.gold.collection.steppers.Stepper;
import org.abora.gold.java.missing.IntegerVar;
import org.abora.gold.xpp.basic.Heaper;


public class DescendingIntegerStepper extends Stepper {
	protected IntegerVarArray myEdges;
	protected int myIndex;
	protected IntegerVar myPosition;
/*
udanax-top.st:53412:
Stepper subclass: #DescendingIntegerStepper
	instanceVariableNames: '
		myEdges {IntegerVarArray}
		myIndex {Int32}
		myPosition {IntegerVar}'
	classVariableNames: ''
	poolDictionaries: ''
	category: 'Xanadu-Spaces-Integers'!
*/
/*
udanax-top.st:53419:
(DescendingIntegerStepper getOrMakeCxxClassDescription)
	attributes: ((Set new) add: #CONCRETE; add: #NOT.A.TYPE; yourself)!
*/
/*
udanax-top.st:53459:
DescendingIntegerStepper class
	instanceVariableNames: ''!
*/
/*
udanax-top.st:53462:
(DescendingIntegerStepper getOrMakeCxxClassDescription)
	attributes: ((Set new) add: #CONCRETE; add: #NOT.A.TYPE; yourself)!
*/

public  DescendingIntegerStepper(IntegerVarArray edges, int count) {
throw new UnsupportedOperationException();/*
udanax-top.st:53424:DescendingIntegerStepper methodsFor: 'protected: create'!
create: edges {IntegerVarArray} with: count {UInt32}
	super create.
	myEdges _ edges.
	myIndex _ count - 2.
	myIndex >= -1
		ifTrue: [myPosition _ (myEdges integerVarAt: myIndex + 1) - 1]
		ifFalse: [myPosition _ IntegerVar0]!
*/
}

public  DescendingIntegerStepper(IntegerVarArray edges, int index, IntegerVar position) {
throw new UnsupportedOperationException();/*
udanax-top.st:53432:DescendingIntegerStepper methodsFor: 'protected: create'!
create: edges {IntegerVarArray} with: index {Int32} with: position {IntegerVar}
	super create.
	myEdges _ edges.
	myIndex _ index.
	myPosition _ position!
*/
}

public Stepper copy() {
throw new UnsupportedOperationException();/*
udanax-top.st:53440:DescendingIntegerStepper methodsFor: 'creation'!
{Stepper} copy
	^DescendingIntegerStepper create: myEdges with: myIndex with: myPosition!
*/
}

public Heaper fetch() {
throw new UnsupportedOperationException();/*
udanax-top.st:53445:DescendingIntegerStepper methodsFor: 'accessing'!
{Heaper wimpy} fetch
	self hasValue ifTrue: [^myPosition integer] ifFalse: [^NULL]!
*/
}

public boolean hasValue() {
throw new UnsupportedOperationException();/*
udanax-top.st:53448:DescendingIntegerStepper methodsFor: 'accessing'!
{BooleanVar} hasValue
	^myIndex >= -1!
*/
}

public void step() {
throw new UnsupportedOperationException();/*
udanax-top.st:53451:DescendingIntegerStepper methodsFor: 'accessing'!
{void} step
	myPosition _ myPosition - 1.
	(myIndex >= Int32Zero and: [myPosition < (myEdges integerVarAt: myIndex)]) ifTrue:
		[myIndex _ myIndex - 2.
		myIndex >= -1 ifTrue:
			[myPosition _ (myEdges integerVarAt: myIndex + 1) - 1]]!
*/
}

public static Heaper make(IntegerVarArray edges, int count) {
throw new UnsupportedOperationException();/*
udanax-top.st:53467:DescendingIntegerStepper class methodsFor: 'creation'!
{Stepper} make: edges {IntegerVarArray} with: count {UInt32}
	^ self create: edges with: count!
*/
}
}
