/*
 * Abora-Gold
 * Part of the Abora hypertext project: http://www.abora.org
 * Copyright 2003 David G Jones
 * 
 * Translated from Udanax-Gold source code: http://www.udanax.com
 * Copyright 1979-1999 Udanax.com. All rights reserved
 */
package org.abora.gold.spaces.integers;

import java.io.PrintWriter;
import org.abora.gold.cache.InstanceCache;
import org.abora.gold.collection.basic.IntegerVarArray;
import org.abora.gold.collection.steppers.Accumulator;
import org.abora.gold.java.missing.IntegerVar;
import org.abora.gold.spaces.integers.IntegerEdgeStepper;
import org.abora.gold.spaces.integers.IntegerRegion;
import org.abora.gold.xpp.basic.Heaper;


public class IntegerEdgeAccumulator extends Accumulator {
	protected boolean myStartsInside;
	protected IntegerVarArray myEdges;
	protected int myIndex;
	protected boolean havePending;
	protected IntegerVar myPending;
	protected static InstanceCache SomeAccumulators;
/*
udanax-top.st:12132:
Accumulator subclass: #IntegerEdgeAccumulator
	instanceVariableNames: '
		myStartsInside {BooleanVar}
		myEdges {IntegerVarArray}
		myIndex {UInt32}
		havePending {BooleanVar}
		myPending {IntegerVar}'
	classVariableNames: 'SomeAccumulators {InstanceCache} '
	poolDictionaries: ''
	category: 'Xanadu-Spaces-Integers'!
*/
/*
udanax-top.st:12141:
(IntegerEdgeAccumulator getOrMakeCxxClassDescription)
	attributes: ((Set new) add: #CONCRETE; yourself)!
*/
/*
udanax-top.st:12237:
IntegerEdgeAccumulator class
	instanceVariableNames: ''!
*/
/*
udanax-top.st:12240:
(IntegerEdgeAccumulator getOrMakeCxxClassDescription)
	attributes: ((Set new) add: #CONCRETE; yourself)!
*/

public  IntegerEdgeAccumulator(boolean startsInside, int count) {
throw new UnsupportedOperationException();/*
udanax-top.st:12146:IntegerEdgeAccumulator methodsFor: 'protected: creation'!
create: startsInside {BooleanVar} with: count {UInt32}
	super create.
	myStartsInside _ startsInside.
	myEdges _ IntegerVarArray zeros: count.
	myIndex _ Int32Zero.
	havePending _ false.
	myPending _ IntegerVar0!
*/
}

public  IntegerEdgeAccumulator(boolean startsInside, IntegerVarArray edges, int index, boolean hasPending, IntegerVar pending) {
throw new UnsupportedOperationException();/*
udanax-top.st:12154:IntegerEdgeAccumulator methodsFor: 'protected: creation'!
create: startsInside {BooleanVar} with: edges {IntegerVarArray} with: index {UInt32} with: hasPending {BooleanVar} with: pending {IntegerVar}
	super create.
	myStartsInside _ startsInside.
	myEdges _ edges.
	myIndex _ index.
	havePending _ hasPending.
	myPending _ pending!
*/
}

public Accumulator copy() {
throw new UnsupportedOperationException();/*
udanax-top.st:12164:IntegerEdgeAccumulator methodsFor: 'creation'!
{Accumulator} copy
	| result {Heaper} |
	result := SomeAccumulators fetch.
	result == NULL
		ifTrue: [
			^IntegerEdgeAccumulator create: myStartsInside with: myEdges with: myIndex with: havePending with: myPending]
		ifFalse: [	
				^(IntegerEdgeAccumulator new.Become: result)
					create: myStartsInside with: myEdges with: myIndex with: havePending with: myPending]!
*/
}

public void destroy() {
throw new UnsupportedOperationException();/*
udanax-top.st:12174:IntegerEdgeAccumulator methodsFor: 'creation'!
{void} destroy
	(SomeAccumulators store: self) ifFalse: [super destroy]!
*/
}

public void step(Heaper someObj) {
throw new UnsupportedOperationException();/*
udanax-top.st:12179:IntegerEdgeAccumulator methodsFor: 'operations'!
{void} step: someObj {Heaper}
	self edge: (someObj cast: IntegerPos) asIntegerVar!
*/
}

public Heaper value() {
throw new UnsupportedOperationException();/*
udanax-top.st:12182:IntegerEdgeAccumulator methodsFor: 'operations'!
{Heaper} value
	^self region!
*/
}

public void printOn(PrintWriter oo) {
throw new UnsupportedOperationException();/*
udanax-top.st:12187:IntegerEdgeAccumulator methodsFor: 'printing'!
{void} printOn: oo {ostream reference}
	oo << self getCategory name << '(' << self region << ')'!
*/
}

/**
 * add a transition at the given position. doing it again cancels it.  This particular coding
 * is used for C++ inlinability
 */
public void edge(IntegerVar x) {
throw new UnsupportedOperationException();/*
udanax-top.st:12192:IntegerEdgeAccumulator methodsFor: 'edge operations'!
{void} edge: x {IntegerVar}
	"add a transition at the given position. doing it again cancels it.  This particular coding is used for C++ inlinability"
	havePending ifTrue:
		[myPending = x
			ifTrue:
				[havePending _ false]
			ifFalse:
				[myEdges at: myIndex storeIntegerVar: myPending.
				myIndex _ myIndex + 1.
				myPending _ x]]
	ifFalse:
		[havePending _ true.
		myPending _ x].!
*/
}

/**
 * add a whole bunch of edges at once, assuming that they are sorted and there are no
 * duplicates
 */
public void edges(IntegerEdgeStepper stepper) {
throw new UnsupportedOperationException();/*
udanax-top.st:12206:IntegerEdgeAccumulator methodsFor: 'edge operations'!
{void} edges: stepper {IntegerEdgeStepper}
	"add a whole bunch of edges at once, assuming that they are sorted and there are no duplicates"
	stepper hasValue ifTrue:
		[self edge: stepper edge.
		stepper step.
		stepper hasValue ifTrue:
			[havePending ifFalse:
				[myPending _ stepper edge.
				havePending _ true.
				stepper step].
			[stepper hasValue] whileTrue:
				[myEdges at: myIndex storeIntegerVar: myPending.
				myIndex _ myIndex + 1.
				myPending _ stepper edge.
				stepper step]]]!
*/
}

/**
 * make a region out of the accumulated edges
 */
public IntegerRegion region() {
throw new UnsupportedOperationException();/*
udanax-top.st:12222:IntegerEdgeAccumulator methodsFor: 'edge operations'!
{IntegerRegion} region
	"make a region out of the accumulated edges"
	
	havePending ifTrue:
		[myEdges at: myIndex storeIntegerVar: myPending.
		^IntegerRegion create: myStartsInside with: myIndex + 1 with: myEdges]
	ifFalse:
		[myIndex == Int32Zero ifTrue:
			[myStartsInside
				ifTrue: [^IntegerRegion allIntegers]
				ifFalse: [^IntegerRegion make]]
		ifFalse: 
			[^IntegerRegion create: myStartsInside with: myIndex with: myEdges]]!
*/
}

public static Heaper make(boolean startsInside, int count) {
throw new UnsupportedOperationException();/*
udanax-top.st:12245:IntegerEdgeAccumulator class methodsFor: 'creation'!
make: startsInside {BooleanVar} with: count {UInt32}
	| result {Heaper} |
	result := SomeAccumulators fetch.
	result == NULL
		ifTrue: [^ self create: startsInside with: count]
		ifFalse: [^ (self new.Become: result) create: startsInside with: count]!
*/
}

public static void initTimeNonInherited() {
throw new UnsupportedOperationException();/*
udanax-top.st:12254:IntegerEdgeAccumulator class methodsFor: 'smalltalk: init'!
initTimeNonInherited
	SomeAccumulators := InstanceCache make: 16!
*/
}

public static void linkTimeNonInherited() {
throw new UnsupportedOperationException();/*
udanax-top.st:12257:IntegerEdgeAccumulator class methodsFor: 'smalltalk: init'!
linkTimeNonInherited
	SomeAccumulators := NULL!
*/
}
}
