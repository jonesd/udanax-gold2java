/*
 * Abora-Gold
 * Part of the Abora hypertext project: http://www.abora.org
 * Copyright 2003 David G Jones
 * 
 * Translated from Udanax-Gold source code: http://www.udanax.com
 * Copyright 1979-1999 Udanax.com. All rights reserved
 */
package org.abora.gold.spaces.integers;

import java.io.PrintWriter;
import org.abora.gold.cache.InstanceCache;
import org.abora.gold.collection.basic.IntegerVarArray;
import org.abora.gold.collection.steppers.Stepper;
import org.abora.gold.java.missing.IntegerVar;
import org.abora.gold.xpp.basic.Heaper;


/**
 * A single instance of this class is cached.  To take advantage of this, a method
 * that uses IntegerEdgeSteppers should explicitly destroy at least one of them.
 */
public class IntegerEdgeStepper extends Stepper {
	protected boolean myEntering;
	protected int myIndex;
	protected int myCount;
	protected IntegerVarArray myEdges;
	protected static InstanceCache SomeEdgeSteppers;
/*
udanax-top.st:54373:
Stepper subclass: #IntegerEdgeStepper
	instanceVariableNames: '
		myEntering {BooleanVar}
		myIndex {UInt32}
		myCount {UInt32}
		myEdges {IntegerVarArray}'
	classVariableNames: 'SomeEdgeSteppers {InstanceCache} '
	poolDictionaries: ''
	category: 'Xanadu-Spaces-Integers'!
*/
/*
udanax-top.st:54381:
IntegerEdgeStepper comment:
'A single instance of this class is cached.  To take advantage of this, a method
that uses IntegerEdgeSteppers should explicitly destroy at least one of them.'!
*/
/*
udanax-top.st:54384:
(IntegerEdgeStepper getOrMakeCxxClassDescription)
	attributes: ((Set new) add: #CONCRETE; yourself)!
*/
/*
udanax-top.st:54450:
IntegerEdgeStepper class
	instanceVariableNames: ''!
*/
/*
udanax-top.st:54453:
(IntegerEdgeStepper getOrMakeCxxClassDescription)
	attributes: ((Set new) add: #CONCRETE; yourself)!
*/

public Heaper fetch() {
throw new UnsupportedOperationException();/*
udanax-top.st:54389:IntegerEdgeStepper methodsFor: 'operations'!
{Heaper wimpy} fetch
	self hasValue ifTrue: [^IntegerPos make: self edge] ifFalse: [^NULL]!
*/
}

public boolean hasValue() {
throw new UnsupportedOperationException();/*
udanax-top.st:54392:IntegerEdgeStepper methodsFor: 'operations'!
{BooleanVar INLINE} hasValue
	^myIndex < myCount!
*/
}

public void step() {
throw new UnsupportedOperationException();/*
udanax-top.st:54395:IntegerEdgeStepper methodsFor: 'operations'!
{void INLINE} step
	myEntering _ myEntering not.
	myIndex _ myIndex + 1!
*/
}

/**
 * the current transition
 */
public IntegerVar edge() {
throw new UnsupportedOperationException();/*
udanax-top.st:54401:IntegerEdgeStepper methodsFor: 'edge accessing'!
{IntegerVar INLINE} edge
	"the current transition"
	(myIndex >= myCount) ifTrue: [ IntegerEdgeStepper outOfBounds ].
	^myEdges integerVarAt: myIndex!
*/
}

/**
 * whether the current transition is entering or leaving the set
 */
public boolean isEntering() {
throw new UnsupportedOperationException();/*
udanax-top.st:54406:IntegerEdgeStepper methodsFor: 'edge accessing'!
{BooleanVar INLINE} isEntering
	"whether the current transition is entering or leaving the set"
	^myEntering!
*/
}

public  IntegerEdgeStepper(boolean entering, int count, IntegerVarArray edges) {
throw new UnsupportedOperationException();/*
udanax-top.st:54412:IntegerEdgeStepper methodsFor: 'protected: create'!
create: entering {BooleanVar} with: count {UInt32} with: edges {IntegerVarArray}
	super create.
	myEntering _ entering.
	myIndex _ Int32Zero.
	myCount _ count.
	myEdges _ edges!
*/
}

public  IntegerEdgeStepper(boolean entering, int index, int count, IntegerVarArray edges) {
throw new UnsupportedOperationException();/*
udanax-top.st:54419:IntegerEdgeStepper methodsFor: 'protected: create'!
create: entering {BooleanVar} with: index {UInt32} with: count {UInt32} with: edges {IntegerVarArray}
	super create.
	myEntering _ entering.
	myIndex _ index.
	myCount _ count.
	myEdges _ edges!
*/
}

public void destroy() {
throw new UnsupportedOperationException();/*
udanax-top.st:54428:IntegerEdgeStepper methodsFor: 'destroy'!
{void} destroy
	(SomeEdgeSteppers store: self) ifFalse:
		[super destroy]!
*/
}

public Stepper copy() {
throw new UnsupportedOperationException();/*
udanax-top.st:54434:IntegerEdgeStepper methodsFor: 'create'!
{Stepper} copy
	^IntegerEdgeStepper create: myEntering with: myIndex with: myCount with: myEdges!
*/
}

public void printOn(PrintWriter oo) {
throw new UnsupportedOperationException();/*
udanax-top.st:54439:IntegerEdgeStepper methodsFor: 'printing'!
{void} printOn: oo {ostream reference}
	oo << self getCategory name << '('.
	self hasValue ifTrue:
		[self isEntering ifTrue: 
			[oo << 'entering ']
		ifFalse: 
			[oo << 'leaving '].
		oo << self edge].
	oo << ')'.!
*/
}

public static void outOfBounds() {
throw new UnsupportedOperationException();/*
udanax-top.st:54458:IntegerEdgeStepper class methodsFor: 'errors'!
{void} outOfBounds
	self BLAST: #OutOfBounds!
*/
}

public static Heaper make(boolean entering, int count, IntegerVarArray edges) {
throw new UnsupportedOperationException();/*
udanax-top.st:54463:IntegerEdgeStepper class methodsFor: 'create'!
make: entering {BooleanVar} with: count {UInt32} with: edges {IntegerVarArray}
	| result {Heaper} |
	result := SomeEdgeSteppers fetch.
	result == NULL ifTrue: [
		^ self create: entering with: count with: edges]
	ifFalse: [
		^ (self new.Become: result) create: entering with: count with: edges]!
*/
}

public static void initTimeNonInherited() {
throw new UnsupportedOperationException();/*
udanax-top.st:54473:IntegerEdgeStepper class methodsFor: 'smalltalk: init'!
initTimeNonInherited
	SomeEdgeSteppers := InstanceCache make: 2!
*/
}

public static void linkTimeNonInherited() {
throw new UnsupportedOperationException();/*
udanax-top.st:54476:IntegerEdgeStepper class methodsFor: 'smalltalk: init'!
linkTimeNonInherited
	SomeEdgeSteppers := NULL!
*/
}
}
