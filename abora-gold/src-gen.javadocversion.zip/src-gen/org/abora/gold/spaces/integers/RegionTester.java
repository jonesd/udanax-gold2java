/*
 * Abora-Gold
 * Part of the Abora hypertext project: http://www.abora.org
 * Copyright 2003 David G Jones
 * 
 * Translated from Udanax-Gold source code: http://www.udanax.com
 * Copyright 1979-1999 Udanax.com. All rights reserved
 */
package org.abora.gold.spaces.integers;

import java.io.PrintWriter;
import org.abora.gold.collection.sets.ImmuSet;
import org.abora.gold.spaces.basic.XnRegion;
import org.abora.gold.testing.Tester;
import org.abora.gold.xcvr.Rcvr;


public class RegionTester extends Tester {
	protected ImmuSet myExampleRegions;
/*
udanax-top.st:59681:
Tester subclass: #RegionTester
	instanceVariableNames: 'myExampleRegions {ImmuSet NOCOPY of: XnRegion}'
	classVariableNames: ''
	poolDictionaries: ''
	category: 'Xanadu-Spaces-Integers'!
*/
/*
udanax-top.st:59685:
(RegionTester getOrMakeCxxClassDescription)
	attributes: ((Set new) add: #DEFERRED; yourself)!
*/
/*
udanax-top.st:59792:
RegionTester class
	instanceVariableNames: ''!
*/
/*
udanax-top.st:59795:
(RegionTester getOrMakeCxxClassDescription)
	attributes: ((Set new) add: #DEFERRED; yourself)!
*/

public ImmuSet initExamples() {
throw new UnsupportedOperationException();/*
udanax-top.st:59690:RegionTester methodsFor: 'deferred: init'!
{ImmuSet of: XnRegion} initExamples
	self subclassResponsibility!
*/
}

public void allTestsOn(PrintWriter oo) {
throw new UnsupportedOperationException();/*
udanax-top.st:59695:RegionTester methodsFor: 'testing'!
{void} allTestsOn: oo {ostream reference}
	myExampleRegions _ self initExamples.
	self testExtraOn: oo.
	self testUnaryRegionOpsOn: oo.
	self testBinaryRegionOpsOn: oo.!
*/
}

public void binaryCheck(XnRegion a, XnRegion b) {
throw new UnsupportedOperationException();/*
udanax-top.st:59701:RegionTester methodsFor: 'testing'!
{void} binaryCheck: a {XnRegion} with: b {XnRegion}
	| anb {XnRegion} amb {XnRegion} aub {XnRegion} |
	anb _ a intersect: b.
	(anb isEqual: (b intersect: a)) assert: 'intersect test failed.'.
	(anb isSubsetOf: a) assert: 'intersect/subset test failed.'.
	(anb isSubsetOf: b) assert: 'intersect/subset test failed.'.
	(a intersects: b) == anb isEmpty not assert: 'intersects test failed.'.
	amb _ a minus: b.
	(amb intersects: b) not assert: 'minus/intersect test failed.'.
	(amb isSubsetOf: a) assert: 'minus/subset test failed.'.
	
	aub _ a unionWith: b.
	(aub isEqual: (b unionWith: a)) assert: 'unionWith test failed.'.
	(a isSubsetOf: aub) assert: 'union/subset test failed.'.
	(b isSubsetOf: aub) assert: 'union/subset test failed.'.
	
	(((a isSubsetOf: b) and: [b isSubsetOf: a]) == (a isEqual: b)) assert: 'subset/equals test failed.'.!
*/
}

public void testBinaryRegionOpsOn(PrintWriter oo) {
throw new UnsupportedOperationException();/*
udanax-top.st:59720:RegionTester methodsFor: 'testing'!
{void} testBinaryRegionOpsOn: oo {ostream reference}
	myExampleRegions stepper forEach: [:one {XnRegion} |
		myExampleRegions stepper forEach: [:two {XnRegion} |
			one hashForEqual <= two hashForEqual ifTrue: [
				Heaper problems.AllBlasts
					handle: [ :ex |
						| prob {Problem} |
						'prob = &PROBLEM(ex);' translateOnly.
						[prob _ Problem create: ex PROBLEM with: ex parameter
									with: ex initialContext sender printString with: 0] smalltalkOnly.
						[cerr <<prob] smalltalkOnly .
						'operator<<(cerr,prob);'translateOnly.
						cerr << '
'.
						oo << 'problem checking binary ops of ' << one << ' and ' << two << '
'.
						ex return]
					do: [self binaryCheck: one with: two]]]].
	oo << 'binary regions tests succeeded
'!
*/
}

public void testExtraOn(PrintWriter oo) {
throw new UnsupportedOperationException();/*
udanax-top.st:59741:RegionTester methodsFor: 'testing'!
{void} testExtraOn: oo {ostream reference}!
*/
}

public void testUnaryRegionOpsOn(PrintWriter oo) {
throw new UnsupportedOperationException();/*
udanax-top.st:59743:RegionTester methodsFor: 'testing'!
{void} testUnaryRegionOpsOn: oo {ostream reference}
	myExampleRegions stepper forEach: [:one {XnRegion} |
		Heaper problems.AllBlasts
			handle: [ :ex |
				| prob {Problem} |
				'prob = &PROBLEM(ex);' translateOnly.
				[prob _ Problem create: ex PROBLEM with: ex parameter
							with: ex initialContext sender printString with: 0] smalltalkOnly.
					[cerr <<prob] smalltalkOnly .
						'operator<<(cerr,prob);'translateOnly.
						cerr << '
'.
				oo << 'problem checking unary ops of ' << one << '
'.
				ex return]
			do: [self unaryCheck: one]].
	oo << 'unary regions tests succeeded
'!
*/
}

public void unaryCheck(XnRegion a) {
throw new UnsupportedOperationException();/*
udanax-top.st:59763:RegionTester methodsFor: 'testing'!
{void} unaryCheck: a {XnRegion}
	(a isEqual: a) assert: 'identity test failed.'.
	a isEmpty not == (a intersects: a) assert: 'intersects test failed.'.
	(a minus: a) isEmpty assert: 'self minus/isEmpty failed.'.
	(a isSubsetOf: a) assert: 'self subset test failed.'.
	((a intersect: a) isEqual: a) assert: 'intersect/isEqual test failed.'.
	a isFull == a complement isEmpty assert: 'infinity inverse test failed.'.
	(a intersect: a complement) isEmpty assert: 'intersect/complement test failed.'.
	((a minus: a complement) isEqual: a) assert: 'minus/complement test failed.'.
	(a complement complement isEqual: a) assert: 'double complement test failed.'.
	(a unionWith: a complement) isFull assert: 'union/complement test failed.'.!
*/
}

public ImmuSet exampleRegions() {
throw new UnsupportedOperationException();/*
udanax-top.st:59777:RegionTester methodsFor: 'protected: accessing'!
{ImmuSet of: XnRegion} exampleRegions
	^myExampleRegions!
*/
}

public  RegionTester() {
throw new UnsupportedOperationException();/*
udanax-top.st:59782:RegionTester methodsFor: 'protected: creation'!
create
	super create.
	myExampleRegions _ NULL.!
*/
}

public void restartRegionTester(Rcvr rcvr) {
throw new UnsupportedOperationException();/*
udanax-top.st:59788:RegionTester methodsFor: 'hooks:'!
{void RECEIVE.HOOK} restartRegionTester: rcvr {Rcvr unused default: NULL}
	myExampleRegions _ NULL.!
*/
}

public static void suppressInitTimeInherited() {
throw new UnsupportedOperationException();/*
udanax-top.st:59800:RegionTester class methodsFor: 'smalltalk: initialization'!
suppressInitTimeInherited!
*/
}

public static void suppressLinkTimeInherited() {
throw new UnsupportedOperationException();/*
udanax-top.st:59802:RegionTester class methodsFor: 'smalltalk: initialization'!
suppressLinkTimeInherited!
*/
}
}
