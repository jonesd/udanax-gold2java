/*
 * Abora-Gold
 * Part of the Abora hypertext project: http://www.abora.org
 * Copyright 2003 David G Jones
 * 
 * Translated from Udanax-Gold source code: http://www.udanax.com
 * Copyright 1979-1999 Udanax.com. All rights reserved
 */
package org.abora.gold.spaces.unordered;

import org.abora.gold.spaces.basic.CoordinateSpace;
import org.abora.gold.spaces.unordered.IDSpace;
import org.abora.gold.spaces.unordered.IdentityDsp;
import org.abora.gold.xcvr.Rcvr;
import org.abora.gold.xcvr.Xmtr;
import org.abora.gold.xpp.basic.Heaper;


/**
 * There are no non-trivial Dsps on IDs.
 */
public class IDDsp extends IdentityDsp {
	protected IDSpace mySpace;
/*
udanax-top.st:29676:
IdentityDsp subclass: #IDDsp
	instanceVariableNames: 'mySpace {IDSpace}'
	classVariableNames: ''
	poolDictionaries: ''
	category: 'Xanadu-Spaces-Unordered'!
*/
/*
udanax-top.st:29680:
IDDsp comment:
'There are no non-trivial Dsps on IDs.'!
*/
/*
udanax-top.st:29682:
(IDDsp getOrMakeCxxClassDescription)
	attributes: ((Set new) add: #CONCRETE; add: #PSEUDO.COPY; yourself)!
*/
/*
udanax-top.st:29706:
IDDsp class
	instanceVariableNames: ''!
*/
/*
udanax-top.st:29709:
(IDDsp getOrMakeCxxClassDescription)
	attributes: ((Set new) add: #CONCRETE; add: #PSEUDO.COPY; yourself)!
*/

public CoordinateSpace coordinateSpace() {
throw new UnsupportedOperationException();/*
udanax-top.st:29687:IDDsp methodsFor: 'accessing'!
{CoordinateSpace} coordinateSpace
	^mySpace!
*/
}

public  IDDsp() {
throw new UnsupportedOperationException();/*
udanax-top.st:29693:IDDsp methodsFor: 'creation'!
create
	super create!
*/
}

public  IDDsp(IDSpace space) {
throw new UnsupportedOperationException();/*
udanax-top.st:29696:IDDsp methodsFor: 'creation'!
create: space {IDSpace}
	super create.
	mySpace := space.!
*/
}

public void sendSelfTo(Xmtr xmtr) {
throw new UnsupportedOperationException();/*
udanax-top.st:29703:IDDsp methodsFor: 'generated:'!
{void} sendSelfTo: xmtr {Xmtr}!
*/
}

public static Heaper make(Rcvr rcvr) {
throw new UnsupportedOperationException();/*
udanax-top.st:29714:IDDsp class methodsFor: 'rcvr pseudo constructors'!
{Heaper} make.Rcvr: rcvr {Rcvr}
	(rcvr cast: SpecialistRcvr) registerIbid: theDsp.
	^theDsp!
*/
}

public static Heaper make(IDSpace space) {
throw new UnsupportedOperationException();/*
udanax-top.st:29720:IDDsp class methodsFor: 'pseudo constructors'!
make: space {IDSpace}
	^self create: space!
*/
}

public static Heaper make() {
throw new UnsupportedOperationException();/*
udanax-top.st:29726:IDDsp class methodsFor: 'smalltalk: passe'!
make
	self passe.
	^theDsp cast: IDDsp!
*/
}
}
