/*
 * Abora-Gold
 * Part of the Abora hypertext project: http://www.abora.org
 * Copyright 2003 David G Jones
 * 
 * Translated from Udanax-Gold source code: http://www.udanax.com
 * Copyright 1979-1999 Udanax.com. All rights reserved
 */
package org.abora.gold.spaces.unordered;

import java.io.PrintWriter;
import org.abora.gold.spaces.basic.CoordinateSpace;
import org.abora.gold.spaces.unordered.HeaperAsPosition;
import org.abora.gold.xcvr.Rcvr;
import org.abora.gold.xcvr.Xmtr;
import org.abora.gold.xpp.basic.Heaper;


public class StrongAsPosition extends HeaperAsPosition {
	protected Heaper itsHeaper;
/*
udanax-top.st:33036:
HeaperAsPosition subclass: #StrongAsPosition
	instanceVariableNames: 'itsHeaper {Heaper}'
	classVariableNames: ''
	poolDictionaries: ''
	category: 'Xanadu-Spaces-Unordered'!
*/
/*
udanax-top.st:33040:
(StrongAsPosition getOrMakeCxxClassDescription)
	attributes: ((Set new) add: #CONCRETE; add: #NOT.A.TYPE; add: #COPY; yourself)!
*/

public int actualHashForEqual() {
throw new UnsupportedOperationException();/*
udanax-top.st:33045:StrongAsPosition methodsFor: 'testing'!
{UInt32} actualHashForEqual
	^itsHeaper hashForEqual!
*/
}

public boolean isEqual(Heaper other) {
throw new UnsupportedOperationException();/*
udanax-top.st:33048:StrongAsPosition methodsFor: 'testing'!
{BooleanVar} isEqual: other {Heaper}
	other cast: HeaperAsPosition into: [:hap | 
			^itsHeaper == hap heaper 
				or: [itsHeaper isEqual: hap heaper]]
		others: [^false].
	^false "fodder"!
*/
}

public CoordinateSpace coordinateSpace() {
throw new UnsupportedOperationException();/*
udanax-top.st:33058:StrongAsPosition methodsFor: 'accessing'!
{CoordinateSpace} coordinateSpace
	^ HeaperSpace make!
*/
}

public Heaper heaper() {
throw new UnsupportedOperationException();/*
udanax-top.st:33061:StrongAsPosition methodsFor: 'accessing'!
{Heaper} heaper
	^ itsHeaper!
*/
}

public void printOn(PrintWriter oo) {
throw new UnsupportedOperationException();/*
udanax-top.st:33066:StrongAsPosition methodsFor: 'printing'!
{void} printOn: oo {ostream reference} 
	oo << 'position of (' << itsHeaper << ')'!
*/
}

public  StrongAsPosition(Heaper aHeaper) {
throw new UnsupportedOperationException();/*
udanax-top.st:33071:StrongAsPosition methodsFor: 'instance creation'!
create: aHeaper {Heaper}
	super create.
	aHeaper ~~ NULL assert: 'Heapers in StrongAsPosition must be real'.
	itsHeaper _ aHeaper!
*/
}

public  StrongAsPosition(Rcvr receiver) {
throw new UnsupportedOperationException();/*
udanax-top.st:33078:StrongAsPosition methodsFor: 'generated:'!
create.Rcvr: receiver {Rcvr}
	super create.Rcvr: receiver.
	itsHeaper _ receiver receiveHeaper.!
*/
}

public void sendSelfTo(Xmtr xmtr) {
throw new UnsupportedOperationException();/*
udanax-top.st:33082:StrongAsPosition methodsFor: 'generated:'!
{void} sendSelfTo: xmtr {Xmtr}
	super sendSelfTo: xmtr.
	xmtr sendHeaper: itsHeaper.!
*/
}
}
