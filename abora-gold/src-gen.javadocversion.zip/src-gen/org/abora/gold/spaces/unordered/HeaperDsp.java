/*
 * Abora-Gold
 * Part of the Abora hypertext project: http://www.abora.org
 * Copyright 2003 David G Jones
 * 
 * Translated from Udanax-Gold source code: http://www.udanax.com
 * Copyright 1979-1999 Udanax.com. All rights reserved
 */
package org.abora.gold.spaces.unordered;

import org.abora.gold.spaces.basic.CoordinateSpace;
import org.abora.gold.spaces.basic.Dsp;
import org.abora.gold.spaces.unordered.IdentityDsp;
import org.abora.gold.xcvr.Rcvr;
import org.abora.gold.xcvr.Xmtr;
import org.abora.gold.xpp.basic.Heaper;


public class HeaperDsp extends IdentityDsp {
/*
udanax-top.st:29638:
IdentityDsp subclass: #HeaperDsp
	instanceVariableNames: ''
	classVariableNames: ''
	poolDictionaries: ''
	category: 'Xanadu-Spaces-Unordered'!
*/
/*
udanax-top.st:29642:
(HeaperDsp getOrMakeCxxClassDescription)
	attributes: ((Set new) add: #PSEUDO.COPY; add: #CONCRETE; add: #NOT.A.TYPE; yourself)!
*/
/*
udanax-top.st:29661:
HeaperDsp class
	instanceVariableNames: ''!
*/
/*
udanax-top.st:29664:
(HeaperDsp getOrMakeCxxClassDescription)
	attributes: ((Set new) add: #PSEUDO.COPY; add: #CONCRETE; add: #NOT.A.TYPE; yourself)!
*/

public CoordinateSpace coordinateSpace() {
throw new UnsupportedOperationException();/*
udanax-top.st:29647:HeaperDsp methodsFor: 'accessing'!
{CoordinateSpace} coordinateSpace
	^HeaperSpace make!
*/
}

public  HeaperDsp() {
throw new UnsupportedOperationException();/*
udanax-top.st:29653:HeaperDsp methodsFor: 'creation'!
create
	super create!
*/
}

public void sendSelfTo(Xmtr xmtr) {
throw new UnsupportedOperationException();/*
udanax-top.st:29658:HeaperDsp methodsFor: 'generated:'!
{void} sendSelfTo: xmtr {Xmtr}!
*/
}

public static Heaper make() {
throw new UnsupportedOperationException();/*
udanax-top.st:29669:HeaperDsp class methodsFor: 'pseudo constructors'!
{Dsp} make 
	^(theDsp basicCast: IdentityDsp) basicCast: HeaperDsp!
*/
}

public static Heaper make(Rcvr rcvr) {
throw new UnsupportedOperationException();/*
udanax-top.st:29672:HeaperDsp class methodsFor: 'pseudo constructors'!
{Heaper} make.Rcvr: rcvr {Rcvr}
	(rcvr cast: SpecialistRcvr) registerIbid: theDsp.
	^theDsp!
*/
}
}
