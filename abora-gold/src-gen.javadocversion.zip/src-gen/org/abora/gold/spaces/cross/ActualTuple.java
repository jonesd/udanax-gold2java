/*
 * Abora-Gold
 * Part of the Abora hypertext project: http://www.abora.org
 * Copyright 2003 David G Jones
 * 
 * Translated from Udanax-Gold source code: http://www.udanax.com
 * Copyright 1979-1999 Udanax.com. All rights reserved
 */
package org.abora.gold.spaces.cross;

import org.abora.gold.collection.basic.PtrArray;
import org.abora.gold.spaces.basic.CoordinateSpace;
import org.abora.gold.spaces.basic.Position;
import org.abora.gold.spaces.basic.XnRegion;
import org.abora.gold.spaces.cross.Tuple;
import org.abora.gold.xcvr.Rcvr;
import org.abora.gold.xcvr.Xmtr;
import org.abora.gold.xpp.basic.Heaper;


/**
 * Default implementation of position in a crossed coordinate space. NOT.A.TYPE
 */
public class ActualTuple extends Tuple {
	protected PtrArray myCoordinates;
/*
udanax-top.st:32857:
Tuple subclass: #ActualTuple
	instanceVariableNames: 'myCoordinates {PtrArray of: Position}'
	classVariableNames: ''
	poolDictionaries: ''
	category: 'Xanadu-Spaces-Cross'!
*/
/*
udanax-top.st:32861:
ActualTuple comment:
'Default implementation of position in a crossed coordinate space. NOT.A.TYPE'!
*/
/*
udanax-top.st:32863:
(ActualTuple getOrMakeCxxClassDescription)
	friends:
'friend class GenericCrossDsp;
';
	attributes: ((Set new) add: #CONCRETE; add: #COPY; yourself)!
*/
/*
udanax-top.st:32938:
ActualTuple class
	instanceVariableNames: ''!
*/
/*
udanax-top.st:32941:
(ActualTuple getOrMakeCxxClassDescription)
	friends:
'friend class GenericCrossDsp;
';
	attributes: ((Set new) add: #CONCRETE; add: #COPY; yourself)!
*/

public XnRegion asRegion() {
throw new UnsupportedOperationException();/*
udanax-top.st:32871:ActualTuple methodsFor: 'accessing'!
{XnRegion} asRegion
	
	| result {PtrArray of: XnRegion} |
	result := PtrArray nulls: myCoordinates count.
	Int32Zero almostTo: result count do: [:i {Int32} |
		result at: i store: (self coordinate: i) asRegion].
	^GenericCrossRegion make: (self coordinateSpace cast: CrossSpace) with: 1 with: result!
*/
}

public PtrArray coordinates() {
throw new UnsupportedOperationException();/*
udanax-top.st:32879:ActualTuple methodsFor: 'accessing'!
{PtrArray of: Position} coordinates
	
	^myCoordinates copy cast: PtrArray!
*/
}

public CoordinateSpace coordinateSpace() {
throw new UnsupportedOperationException();/*
udanax-top.st:32883:ActualTuple methodsFor: 'accessing'!
{CoordinateSpace} coordinateSpace
	
	| result {PtrArray of: CoordinateSpace} |
	result := PtrArray nulls: myCoordinates count.
	Int32Zero almostTo: result count do: [:i {Int32} |
		result at: i store: (self coordinate: i) coordinateSpace].
	^CrossSpace make: result!
*/
}

public int count() {
throw new UnsupportedOperationException();/*
udanax-top.st:32891:ActualTuple methodsFor: 'accessing'!
{Int32} count
	^ myCoordinates count!
*/
}

public Position positionAt(int dimension) {
throw new UnsupportedOperationException();/*
udanax-top.st:32894:ActualTuple methodsFor: 'accessing'!
{Position} positionAt: dimension {Int32}
	^ (myCoordinates fetch: dimension) cast: Position!
*/
}

public int actualHashForEqual() {
throw new UnsupportedOperationException();/*
udanax-top.st:32899:ActualTuple methodsFor: 'comparing'!
{UInt32} actualHashForEqual
	
	^myCoordinates contentsHash!
*/
}

public boolean isEqual(Heaper other) {
throw new UnsupportedOperationException();/*
udanax-top.st:32903:ActualTuple methodsFor: 'comparing'!
{BooleanVar} isEqual: other {Heaper}
	other cast: ActualTuple into: [ :actual |
		^myCoordinates contentsEqual: actual secretCoordinates]
	cast: Tuple into: [ :tuple |
		^myCoordinates contentsEqual: tuple coordinates]
	others:
		[^false].
	^ false "compiler fodder"!
*/
}

public  ActualTuple(PtrArray coordinates) {
	super(null);
throw new UnsupportedOperationException();/*
udanax-top.st:32915:ActualTuple methodsFor: 'private: creation'!
create: coordinates {PtrArray of: Position}
	super create.
	myCoordinates := coordinates!
*/
}

/**
 * The internal array of coordinates. Do not modify this array!!
 */
public PtrArray secretCoordinates() {
throw new UnsupportedOperationException();/*
udanax-top.st:32922:ActualTuple methodsFor: 'private: accessing'!
{PtrArray of: Position} secretCoordinates
	"The internal array of coordinates. Do not modify this array!!"
	
	^myCoordinates!
*/
}

public  ActualTuple(Rcvr receiver) {
	super(receiver);
throw new UnsupportedOperationException();/*
udanax-top.st:32929:ActualTuple methodsFor: 'generated:'!
create.Rcvr: receiver {Rcvr}
	super create.Rcvr: receiver.
	myCoordinates _ receiver receiveHeaper.!
*/
}

public void sendSelfTo(Xmtr xmtr) {
throw new UnsupportedOperationException();/*
udanax-top.st:32933:ActualTuple methodsFor: 'generated:'!
{void} sendSelfTo: xmtr {Xmtr}
	super sendSelfTo: xmtr.
	xmtr sendHeaper: myCoordinates.!
*/
}

public static Heaper make(PtrArray coordinates) {
throw new UnsupportedOperationException();/*
udanax-top.st:32949:ActualTuple class methodsFor: 'pseudoconstructors'!
{Tuple} make: coordinates {PtrArray of: Position}
	^self create: coordinates!
*/
}
}
