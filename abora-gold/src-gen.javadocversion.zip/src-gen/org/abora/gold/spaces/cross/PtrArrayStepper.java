/*
 * Abora-Gold
 * Part of the Abora hypertext project: http://www.abora.org
 * Copyright 2003 David G Jones
 * 
 * Translated from Udanax-Gold source code: http://www.udanax.com
 * Copyright 1979-1999 Udanax.com. All rights reserved
 */
package org.abora.gold.spaces.cross;

import org.abora.gold.collection.basic.PtrArray;
import org.abora.gold.collection.steppers.Stepper;
import org.abora.gold.collection.steppers.TableStepper;
import org.abora.gold.java.missing.IntegerVar;
import org.abora.gold.spaces.basic.Position;
import org.abora.gold.xcvr.Rcvr;
import org.abora.gold.xcvr.Xmtr;
import org.abora.gold.xpp.basic.Heaper;


/**
 * A Stepper for stepping over the elements of a PtrArray in ascending or descending order.
 * This is a TableStepper even though it is stepping over a PtrArray instead of a table.
 * Should probably eventually be generalized to PrimArrays. NOT.A.TYPE
 */
public class PtrArrayStepper extends TableStepper {
	protected PtrArray myArray;
	protected int myIndex;
	protected int myPastEnd;
	protected int myStep;
/*
udanax-top.st:56230:
TableStepper subclass: #PtrArrayStepper
	instanceVariableNames: '
		myArray {PtrArray of: Heaper}
		myIndex {Int32}
		myPastEnd {Int32}
		myStep {Int32}'
	classVariableNames: ''
	poolDictionaries: ''
	category: 'Xanadu-Spaces-Cross'!
*/
/*
udanax-top.st:56238:
PtrArrayStepper comment:
'A Stepper for stepping over the elements of a PtrArray in ascending or descending order.  This is a TableStepper even though it is stepping over a PtrArray instead of a table.  Should probably eventually be generalized to PrimArrays. NOT.A.TYPE'!
*/
/*
udanax-top.st:56240:
(PtrArrayStepper getOrMakeCxxClassDescription)
	attributes: ((Set new) add: #CONCRETE; add: #COPY; yourself)!
*/
/*
udanax-top.st:56303:
PtrArrayStepper class
	instanceVariableNames: ''!
*/
/*
udanax-top.st:56306:
(PtrArrayStepper getOrMakeCxxClassDescription)
	attributes: ((Set new) add: #CONCRETE; add: #COPY; yourself)!
*/

public Stepper copy() {
throw new UnsupportedOperationException();/*
udanax-top.st:56245:PtrArrayStepper methodsFor: 'operations'!
{Stepper} copy
	
	^PtrArrayStepper create: (myArray copy cast: PtrArray) with: myIndex with: myPastEnd with: myStep!
*/
}

public Heaper fetch() {
throw new UnsupportedOperationException();/*
udanax-top.st:56249:PtrArrayStepper methodsFor: 'operations'!
{Heaper wimpy} fetch
	
	myIndex >= myPastEnd ifTrue:
		[^NULL].
	^myArray fetch: myIndex!
*/
}

public boolean hasValue() {
throw new UnsupportedOperationException();/*
udanax-top.st:56255:PtrArrayStepper methodsFor: 'operations'!
{BooleanVar} hasValue
	
	^myIndex < myPastEnd!
*/
}

public void step() {
throw new UnsupportedOperationException();/*
udanax-top.st:56259:PtrArrayStepper methodsFor: 'operations'!
{void} step
	myIndex _ myIndex + myStep!
*/
}

public IntegerVar index() {
throw new UnsupportedOperationException();/*
udanax-top.st:56264:PtrArrayStepper methodsFor: 'special'!
{IntegerVar} index
	
	myIndex >= myPastEnd ifTrue:
		[Heaper BLAST: #EmptyStepper].
	^myIndex!
*/
}

public Position position() {
throw new UnsupportedOperationException();/*
udanax-top.st:56270:PtrArrayStepper methodsFor: 'special'!
{Position} position
	
	myIndex >= myPastEnd ifTrue:
		[Heaper BLAST: #EmptyStepper].
	^myIndex integer!
*/
}

public  PtrArrayStepper(PtrArray array, int start, int pastEnd, int step) {
throw new UnsupportedOperationException();/*
udanax-top.st:56278:PtrArrayStepper methodsFor: 'private: creation'!
create: array {PtrArray} with: start {Int32} with: pastEnd {Int32} with: step {Int32}
	super create.
	myArray := array.
	myIndex := start.
	myPastEnd := pastEnd.
	myStep := step!
*/
}

public  PtrArrayStepper(Rcvr receiver) {
throw new UnsupportedOperationException();/*
udanax-top.st:56288:PtrArrayStepper methodsFor: 'generated:'!
create.Rcvr: receiver {Rcvr}
	super create.Rcvr: receiver.
	myArray _ receiver receiveHeaper.
	myIndex _ receiver receiveInt32.
	myPastEnd _ receiver receiveInt32.
	myStep _ receiver receiveInt32.!
*/
}

public void sendSelfTo(Xmtr xmtr) {
throw new UnsupportedOperationException();/*
udanax-top.st:56295:PtrArrayStepper methodsFor: 'generated:'!
{void} sendSelfTo: xmtr {Xmtr}
	super sendSelfTo: xmtr.
	xmtr sendHeaper: myArray.
	xmtr sendInt32: myIndex.
	xmtr sendInt32: myPastEnd.
	xmtr sendInt32: myStep.!
*/
}

/**
 * Note: this being a low level operation, and there being no lightweight form of immutable
 * or lazily copied PtrArray, it is my caller's responsibility to pass me a PtrArray which
 * will in fact not be changed during the life of this stepper.  This is an unchecked an
 * uncheckable precondition on my clients.
 */
public static TableStepper ascending(PtrArray array) {
throw new UnsupportedOperationException();/*
udanax-top.st:56311:PtrArrayStepper class methodsFor: 'creation'!
{TableStepper} ascending: array {PtrArray}
	"Note: this being a low level operation, and there being no lightweight form of immutable or lazily copied PtrArray, it is my caller's responsibility to pass me a PtrArray which will in fact not be changed during the life of this stepper.  This is an unchecked an uncheckable precondition on my clients."
	 
	^self create: array with: Int32Zero with: array count with: 1!
*/
}

/**
 * Note: this being a low level operation, and there being no lightweight form of immutable
 * or lazily copied PtrArray, it is my caller's responsibility to pass me a PtrArray which
 * will in fact not be changed during the life of this stepper.  This is an unchecked an
 * uncheckable precondition on my clients.
 */
public static TableStepper descending(PtrArray array) {
throw new UnsupportedOperationException();/*
udanax-top.st:56316:PtrArrayStepper class methodsFor: 'creation'!
{TableStepper} descending: array {PtrArray}
	"Note: this being a low level operation, and there being no lightweight form of immutable or lazily copied PtrArray, it is my caller's responsibility to pass me a PtrArray which will in fact not be changed during the life of this stepper.  This is an unchecked an uncheckable precondition on my clients."
	
	^self create: array with: array count - 1 with: -1 with: -1!
*/
}
}
