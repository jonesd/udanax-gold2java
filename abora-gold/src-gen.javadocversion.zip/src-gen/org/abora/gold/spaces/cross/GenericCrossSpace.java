/*
 * Abora-Gold
 * Part of the Abora hypertext project: http://www.abora.org
 * Copyright 2003 David G Jones
 * 
 * Translated from Udanax-Gold source code: http://www.udanax.com
 * Copyright 1979-1999 Udanax.com. All rights reserved
 */
package org.abora.gold.spaces.cross;

import java.io.PrintWriter;
import org.abora.gold.collection.basic.PrimIntArray;
import org.abora.gold.collection.basic.PtrArray;
import org.abora.gold.cross.CrossOrderSpec;
import org.abora.gold.spaces.basic.Mapping;
import org.abora.gold.spaces.basic.XnRegion;
import org.abora.gold.spaces.cross.CrossRegion;
import org.abora.gold.spaces.cross.CrossSpace;
import org.abora.gold.spaces.cross.Tuple;
import org.abora.gold.xcvr.Rcvr;
import org.abora.gold.xcvr.Xmtr;
import org.abora.gold.xpp.basic.Heaper;


/**
 * Default implementation of cross coordinate space.
 * was NOT.A.TYPE but that prevented compilation
 */
public class GenericCrossSpace extends CrossSpace {
/*
udanax-top.st:14769:
CrossSpace subclass: #GenericCrossSpace
	instanceVariableNames: ''
	classVariableNames: ''
	poolDictionaries: ''
	category: 'Xanadu-Spaces-Cross'!
*/
/*
udanax-top.st:14773:
GenericCrossSpace comment:
'Default implementation of cross coordinate space.
was NOT.A.TYPE but that prevented compilation'!
*/
/*
udanax-top.st:14776:
(GenericCrossSpace getOrMakeCxxClassDescription)
	attributes: ((Set new) add: #CONCRETE; add: #PSEUDO.COPY; yourself)!
*/
/*
udanax-top.st:14860:
GenericCrossSpace class
	instanceVariableNames: ''!
*/
/*
udanax-top.st:14863:
(GenericCrossSpace getOrMakeCxxClassDescription)
	attributes: ((Set new) add: #CONCRETE; add: #PSEUDO.COPY; yourself)!
*/

public Mapping crossOfMappings(PtrArray subMappings) {
throw new UnsupportedOperationException();/*
udanax-top.st:14781:GenericCrossSpace methodsFor: 'making'!
{Mapping} crossOfMappings: subMappings {(PtrArray of: Mapping | NULL) default: NULL}
	subMappings == NULL ifTrue:
		[^CrossMapping make: self].
	Int32Zero almostTo: subMappings count do: [:i {Int32} |
		| subM {Mapping | NULL} |
		subM := (subMappings fetch: i) cast: Mapping.
		(subM ~~ NULL and: [(subM isKindOf: Dsp) not]) ifTrue:
			[MarkM shouldImplement]].
	^CrossMapping make: self with: subMappings!
*/
}

public CrossOrderSpec crossOfOrderSpecs(PtrArray subOrderings, PrimIntArray subSpaceOrdering) {
throw new UnsupportedOperationException();/*
udanax-top.st:14792:GenericCrossSpace methodsFor: 'making'!
{CrossOrderSpec} crossOfOrderSpecs: subOrderings {(PtrArray of: OrderSpec | NULL) default: NULL}
	with: subSpaceOrdering {PrimIntArray default: NULL}
	
	^CrossOrderSpec make: self with: subOrderings with: subSpaceOrdering!
*/
}

public Tuple crossOfPositions(PtrArray coordinates) {
throw new UnsupportedOperationException();/*
udanax-top.st:14797:GenericCrossSpace methodsFor: 'making'!
{Tuple} crossOfPositions: coordinates {PtrArray of: Position}
	
	^ActualTuple make: coordinates!
*/
}

public CrossRegion crossOfRegions(PtrArray subRegions) {
throw new UnsupportedOperationException();/*
udanax-top.st:14801:GenericCrossSpace methodsFor: 'making'!
{CrossRegion} crossOfRegions: subRegions {PtrArray of: XnRegion | NULL}
	
	| result {PtrArray of: XnRegion} |
	result := subRegions copy cast: PtrArray.
	Int32Zero almostTo: result count do: [ :dimension {Int32} |
		(result fetch: dimension) == NULL ifTrue:
			[result at: dimension
				store: (self axis: dimension) fullRegion]
		ifFalse: [((result fetch: dimension) cast: XnRegion) isEmpty ifTrue:
			[^self emptyRegion cast: CrossRegion]]].
	^GenericCrossRegion make: self with: 1 with: result!
*/
}

public CrossRegion extrusion(int dimension, XnRegion subRegion) {
throw new UnsupportedOperationException();/*
udanax-top.st:14813:GenericCrossSpace methodsFor: 'making'!
{CrossRegion} extrusion: dimension {Int32} with: subRegion {XnRegion}
	
	| projs {PtrArray of: XnRegion} |
	subRegion isEmpty ifTrue: [^self emptyRegion cast: CrossRegion].
	projs := PtrArray nulls: mySubSpaces count.
	Int32Zero almostTo: mySubSpaces count do: [ :i {Int32} |
		i = dimension ifTrue:
			[projs at: i store: subRegion]
		ifFalse:
			[projs at: i
				store: ((mySubSpaces fetch: i) cast: CoordinateSpace) fullRegion]].
	^GenericCrossRegion make: self with: 1 with: projs!
*/
}

public  GenericCrossSpace(PtrArray subSpaces) {
throw new UnsupportedOperationException();/*
udanax-top.st:14828:GenericCrossSpace methodsFor: 'private: creation'!
create: subSpaces {PtrArray of: CoordinateSpace}
	
	super create: subSpaces.
	self finishCreate: (GenericCrossRegion empty: self)
		with: (GenericCrossRegion full: self with: subSpaces)
		with: (GenericCrossDsp identity: self with: subSpaces)
		with: (CrossOrderSpec fetchAscending: self with: subSpaces)
		with: (CrossOrderSpec fetchDescending: self with: subSpaces).!
*/
}

public void printOn(PrintWriter oo) {
throw new UnsupportedOperationException();/*
udanax-top.st:14839:GenericCrossSpace methodsFor: 'printing'!
{void} printOn: oo {ostream reference}
	oo << '<'.
	Int32Zero almostTo: mySubSpaces count do: [ :i {Int32} |
		i > Int32Zero ifTrue: [oo << ' x '].
		oo << (mySubSpaces fetch: i)].
	oo << '>'!
*/
}

public void sendGenericCrossSpaceTo(Xmtr xmtr) {
throw new UnsupportedOperationException();/*
udanax-top.st:14849:GenericCrossSpace methodsFor: 'hooks:'!
{void SEND.HOOK} sendGenericCrossSpaceTo: xmtr {Xmtr}
	xmtr sendHeaper: mySubSpaces.!
*/
}

public void sendSelfTo(Xmtr xmtr) {
throw new UnsupportedOperationException();/*
udanax-top.st:14855:GenericCrossSpace methodsFor: 'generated:'!
{void} sendSelfTo: xmtr {Xmtr}
	
	self sendGenericCrossSpaceTo: xmtr.!
*/
}

public static Heaper make(Rcvr rcvr) {
throw new UnsupportedOperationException();/*
udanax-top.st:14868:GenericCrossSpace class methodsFor: 'rcvr pseudoconstructors'!
{Heaper} make.Rcvr: rcvr {Rcvr}
	^(GenericCrossSpace new.Become: ((rcvr cast: SpecialistRcvr) makeIbid: GenericCrossSpace))
		 create: (rcvr receiveHeaper cast: PtrArray)!
*/
}

public static Heaper make(PtrArray subSpaces) {
throw new UnsupportedOperationException();/*
udanax-top.st:14875:GenericCrossSpace class methodsFor: 'pseudoconstructors'!
{CrossSpace} make: subSpaces {PtrArray of: CoordinateSpace}
	^GenericCrossSpace create: subSpaces!
*/
}
}
