/*
 * Abora-Gold
 * Part of the Abora hypertext project: http://www.abora.org
 * Copyright 2003 David G Jones
 * 
 * Translated from Udanax-Gold source code: http://www.udanax.com
 * Copyright 1979-1999 Udanax.com. All rights reserved
 */
package org.abora.gold.spaces.basic;

import org.abora.gold.collection.sets.ImmuSet;
import org.abora.gold.spaces.integers.RegionTester;
import org.abora.gold.xcvr.Rcvr;
import org.abora.gold.xcvr.Xmtr;


public class RealTester extends RegionTester {
/*
udanax-top.st:60101:
RegionTester subclass: #RealTester
	instanceVariableNames: ''
	classVariableNames: ''
	poolDictionaries: ''
	category: 'Xanadu-Spaces-Basic'!
*/
/*
udanax-top.st:60105:
(RealTester getOrMakeCxxClassDescription)
	attributes: ((Set new) add: #CONCRETE; add: #(COPY boot ); yourself)!
*/

public ImmuSet initExamples() {
throw new UnsupportedOperationException();/*
udanax-top.st:60110:RealTester methodsFor: 'deferred: init'!
{ImmuSet of: XnRegion} initExamples
	| reals {SetAccumulator} result {SetAccumulator} base {ImmuSet} |
	reals := SetAccumulator make.
	reals step: (RealPos make: 0.0).
	reals step: (RealPos make: 1.0).
	reals step: (RealPos make: 2.0).
	result := SetAccumulator make.
	(reals value cast: ScruSet) stepper forEach: [ :real {RealPos} |
		result step: (RealSpace make above: real with: true).
		result step: (RealSpace make above: real with: false).
		result step: (RealSpace make below: real with: true).
		result step: (RealSpace make below: real with: false)].
	base := result value cast: ImmuSet.
	base stepper forEach: [ :r {RealRegion} |
		base stepper forEach: [ :r2 {RealRegion} |
			r hashForEqual < r2 hashForEqual ifTrue:
				[result step: (r unionWith: r2).
				result step: (r intersect: r2)]]].
	^result value cast: ImmuSet!
*/
}

public  RealTester(Rcvr receiver) {
throw new UnsupportedOperationException();/*
udanax-top.st:60132:RealTester methodsFor: 'generated:'!
create.Rcvr: receiver {Rcvr}
	super create.Rcvr: receiver.!
*/
}

public void sendSelfTo(Xmtr xmtr) {
throw new UnsupportedOperationException();/*
udanax-top.st:60135:RealTester methodsFor: 'generated:'!
{void} sendSelfTo: xmtr {Xmtr}
	super sendSelfTo: xmtr.!
*/
}
}
