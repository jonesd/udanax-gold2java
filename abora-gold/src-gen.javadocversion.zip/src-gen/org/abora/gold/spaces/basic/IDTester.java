/*
 * Abora-Gold
 * Part of the Abora hypertext project: http://www.abora.org
 * Copyright 2003 David G Jones
 * 
 * Translated from Udanax-Gold source code: http://www.udanax.com
 * Copyright 1979-1999 Udanax.com. All rights reserved
 */
package org.abora.gold.spaces.basic;

import java.io.PrintWriter;
import org.abora.gold.be.basic.ID;
import org.abora.gold.cobbler.Connection;
import org.abora.gold.collection.sets.ImmuSet;
import org.abora.gold.spaces.integers.RegionTester;
import org.abora.gold.spaces.unordered.IDSpace;
import org.abora.gold.xcvr.Rcvr;
import org.abora.gold.xcvr.Xmtr;
import org.abora.gold.xpp.basic.Heaper;


public class IDTester extends RegionTester {
	protected Connection myConnection;
/*
udanax-top.st:59918:
RegionTester subclass: #IDTester
	instanceVariableNames: 'myConnection {Connection NOCOPY}'
	classVariableNames: ''
	poolDictionaries: ''
	category: 'Xanadu-Spaces-Basic'!
*/
/*
udanax-top.st:59922:
(IDTester getOrMakeCxxClassDescription)
	attributes: ((Set new) add: #CONCRETE; add: #(COPY boot ); yourself)!
*/

public void destruct() {
throw new UnsupportedOperationException();/*
udanax-top.st:59927:IDTester methodsFor: 'init'!
{void} destruct
	myConnection destroy.
	super destruct!
*/
}

public ImmuSet initExamples() {
throw new UnsupportedOperationException();/*
udanax-top.st:59932:IDTester methodsFor: 'init'!
{ImmuSet of: XnRegion} initExamples
	| iDs {SetAccumulator} result {SetAccumulator}
	  backend {Sequence} base {ImmuSet}
	  s {IDSpace} |
	myConnection := Connection make: FeServer.
	myConnection bootHeaper.
	iDs := SetAccumulator make.
	backend := FeServer identifier.
	s := IDSpace make: (backend withLast: 3) with: 1.
	iDs step: (ID usingx: s with: backend with: 3).
	iDs step: (ID usingx: s with: backend with: 30).
	iDs step: (ID usingx: s with: (backend withLast: 7) with: 77).
	iDs step: (ID usingx: s with: (backend withLast: 7) with: 33).
	iDs step: (ID usingx: s with: (backend withLast: 5) with: 99).
	result := SetAccumulator make.
	(iDs value cast: ImmuSet) stepper forEach: [ :iD {ID} |
		result step: iD asRegion.
		result step: iD asRegion complement].
	"result step: (s iDsFromServer: backend).
	result step: (s iDsFromServer: (backend withLast: 7)).
	result step: (s iDsFromServer: (backend withLast: 9)).
	result step: (s iDsFromServer: backend) complement.
	result step: (s iDsFromServer: (backend withLast: 7))complement.
	result step: (s iDsFromServer: (backend withLast: 9))complement."
	
	base := result value cast: ImmuSet.
	base stepper forEach: [ :r {IDRegion} |
		base stepper forEach: [ :r2 {IDRegion} |
			r hashForEqual < r2 hashForEqual ifTrue:
				[result step: (r unionWith: r2).
				result step: (r intersect: r2)]]].
	^result value cast: ImmuSet!
*/
}

public void allTestsOn(PrintWriter oo) {
throw new UnsupportedOperationException();/*
udanax-top.st:59970:IDTester methodsFor: 'testing'!
{void} allTestsOn: oo {ostream reference}
	super allTestsOn: oo.
	self testImportExportOn: oo.!
*/
}

public void shouldBeEqual(PrintWriter oo, Heaper original, Heaper imported, Heaper importedAgain) {
throw new UnsupportedOperationException();/*
udanax-top.st:59974:IDTester methodsFor: 'testing'!
{void} shouldBeEqual: oo {ostream reference}
	with: original {Heaper}
	with: imported {Heaper}
	with: importedAgain {Heaper}
	
	| oi {BooleanVar} oa {BooleanVar} ia {BooleanVar} |
	oi := original isEqual: imported.
	oa := original isEqual: importedAgain.
	ia := imported isEqual: importedAgain.
	(oi and: [oa not and: [ia not]]) ifTrue:
		[oo << '2nd import ' << importedAgain << ' is different from ' << original << '
'].
	(oa and: [oi not and: [ia not]]) ifTrue:
		[oo << 'import ' << imported << ' is different from ' << original << '
'].
	(ia and: [oa not and: [oi not]]) ifTrue:
		[oo << 'original ' << importedAgain << ' is different from ' << original << '
'].!
*/
}

public void shouldBeUnEqual(PrintWriter oo, Heaper original, Heaper imported, Heaper importedAgain) {
throw new UnsupportedOperationException();/*
udanax-top.st:59993:IDTester methodsFor: 'testing'!
{void} shouldBeUnEqual: oo {ostream reference}
	with: original {Heaper}
	with: imported {Heaper}
	with: importedAgain {Heaper}
	
	(original isEqual: imported) ifTrue:
		[oo << 'original and import are the same: ' << original << '
'].
	(original isEqual: importedAgain) ifTrue:
		[oo << 'original and 2nd import are the same: ' << original << '
'].
	( imported isEqual: importedAgain) ifTrue:
		[oo << '1st and 2nd import are the same: ' << imported << '
'].!
*/
}

/**
 * Test an ID
 */
public void testIDOn(PrintWriter oo, ID iD) {
throw new UnsupportedOperationException();/*
udanax-top.st:60008:IDTester methodsFor: 'testing'!
{void} testIDOn: oo {ostream reference} with: iD {ID}
	"Test an ID"
	
	| exported {UInt8Array} exportedAgain {UInt8Array} imported {ID} importedAgain {ID} |
	exported := iD export.
	exportedAgain := iD export.
	(exported contentsEqual: exportedAgain) ifFalse:
		[oo << 'ID ' << iD << ' exported once to ' << exported << ' and then to ' << exportedAgain << '
'].
	imported := ID import: exported.
	importedAgain := ID import: exported.
	self shouldBeEqual: oo with: iD with: imported with: importedAgain.
	self shouldBeEqual: oo with: iD coordinateSpace
		with: imported coordinateSpace
		with: importedAgain coordinateSpace.
	self shouldBeUnEqual: oo
		with: (iD coordinateSpace cast: IDSpace) newID
		with: (imported coordinateSpace cast: IDSpace) newID
		with: (importedAgain coordinateSpace cast: IDSpace) newID.
	oo << 'Finished testing ID ' << iD << '
'!
*/
}

/**
 * Test an IDSpace
 */
public void testIDSpaceOn(PrintWriter oo, IDSpace space, IDSpace special) {
throw new UnsupportedOperationException();/*
udanax-top.st:60031:IDTester methodsFor: 'testing'!
{void} testIDSpaceOn: oo {ostream reference} with: space {IDSpace} with: special {IDSpace  | NULL}
	"Test an IDSpace"
	
	| exported {UInt8Array} exportedAgain {UInt8Array} imported {IDSpace} importedAgain {IDSpace} |
	exported := space export.
	exportedAgain := space export.
	(exported contentsEqual: exportedAgain) ifFalse:
		[oo << 'IDSpace ' << space << ' exported once to ' << exported << ' and then to ' << exportedAgain << '
'].
	imported := IDSpace import: exported.
	importedAgain := IDSpace import: exported.
	self shouldBeEqual: oo with: space with: imported with: importedAgain.
	self shouldBeUnEqual: oo
		with: space newID
		with: imported newID
		with: importedAgain newID.
	self testIDOn: oo with: space newID.
	[BeGrandMap] USES.
	self testIDOn: oo with: (ID
		usingx: special with: (CurrentGrandMap fluidGet identifier withLast: 33) with: 1).
	oo << 'Finished testing IDSpace ' << space << '
'!
*/
}

/**
 * Test import/export of ID objects
 */
public void testImportExportOn(PrintWriter oo) {
throw new UnsupportedOperationException();/*
udanax-top.st:60054:IDTester methodsFor: 'testing'!
{void} testImportExportOn: oo {ostream reference}
	"Test import/export of ID objects"
	
	| s {IDSpace} |
	s := IDSpace make: (CurrentGrandMap fluidGet identifier withLast: 22) with: 7.
	self testIDSpaceOn: oo with: s with: s.
	s := CurrentGrandMap fluidGet newIDSpace.
	self testIDSpaceOn: oo with: s with: s.
	self testIDSpaceOn: oo with: CurrentGrandMap fluidGet globalIDSpace with: NULL.!
*/
}

public  IDTester(Rcvr receiver) {
throw new UnsupportedOperationException();/*
udanax-top.st:60066:IDTester methodsFor: 'generated:'!
create.Rcvr: receiver {Rcvr}
	super create.Rcvr: receiver.!
*/
}

public void sendSelfTo(Xmtr xmtr) {
throw new UnsupportedOperationException();/*
udanax-top.st:60069:IDTester methodsFor: 'generated:'!
{void} sendSelfTo: xmtr {Xmtr}
	super sendSelfTo: xmtr.!
*/
}
}
