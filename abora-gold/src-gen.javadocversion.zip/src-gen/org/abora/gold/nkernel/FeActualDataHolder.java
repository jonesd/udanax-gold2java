/*
 * Abora-Gold
 * Part of the Abora hypertext project: http://www.abora.org
 * Copyright 2003 David G Jones
 * 
 * Translated from Udanax-Gold source code: http://www.udanax.com
 * Copyright 1979-1999 Udanax.com. All rights reserved
 */
package org.abora.gold.nkernel;

import org.abora.gold.be.basic.BeDataHolder;
import org.abora.gold.be.basic.BeRangeElement;
import org.abora.gold.nkernel.FeDataHolder;
import org.abora.gold.nkernel.FeRangeElement;
import org.abora.gold.x.PrimValue;


/**
 * Actually has a persistent individual DataHolder on the Server
 */
public class FeActualDataHolder extends FeDataHolder {
	protected BeDataHolder myBeDataHolder;
/*
udanax-top.st:20609:
FeDataHolder subclass: #FeActualDataHolder
	instanceVariableNames: 'myBeDataHolder {BeDataHolder}'
	classVariableNames: ''
	poolDictionaries: ''
	category: 'Xanadu-nkernel'!
*/
/*
udanax-top.st:20613:
FeActualDataHolder comment:
'Actually has a persistent individual DataHolder on the Server'!
*/
/*
udanax-top.st:20615:
(FeActualDataHolder getOrMakeCxxClassDescription)
	attributes: ((Set new) add: #CONCRETE; add: #NOT.A.TYPE; yourself)!
*/

/**
 * I'm completely reified.  Just return me.
 */
public FeRangeElement again() {
throw new UnsupportedOperationException();/*
udanax-top.st:20620:FeActualDataHolder methodsFor: 'client accessing'!
{FeRangeElement} again
	"I'm completely reified.  Just return me."
	
	^self!
*/
}

/**
 * The actual data value
 */
public PrimValue value() {
throw new UnsupportedOperationException();/*
udanax-top.st:20625:FeActualDataHolder methodsFor: 'client accessing'!
{PrimValue} value
	"The actual data value"
	
	^myBeDataHolder value!
*/
}

public BeRangeElement fetchBe() {
throw new UnsupportedOperationException();/*
udanax-top.st:20632:FeActualDataHolder methodsFor: 'server accessing'!
{BeRangeElement | NULL} fetchBe
	^myBeDataHolder!
*/
}

public BeRangeElement getOrMakeBe() {
throw new UnsupportedOperationException();/*
udanax-top.st:20636:FeActualDataHolder methodsFor: 'server accessing'!
{BeRangeElement} getOrMakeBe
	^myBeDataHolder!
*/
}

public  FeActualDataHolder(BeDataHolder be) {
throw new UnsupportedOperationException();/*
udanax-top.st:20642:FeActualDataHolder methodsFor: 'private: create'!
create: be {BeDataHolder}
	super create.
	myBeDataHolder := be.!
*/
}

public void destruct() {
throw new UnsupportedOperationException();/*
udanax-top.st:20649:FeActualDataHolder methodsFor: 'destruct'!
{void} destruct
	myBeDataHolder removeFeRangeElement: self.
	super destruct.!
*/
}
}
