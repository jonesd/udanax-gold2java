/*
 * Abora-Gold
 * Part of the Abora hypertext project: http://www.abora.org
 * Copyright 2003 David G Jones
 * 
 * Translated from Udanax-Gold source code: http://www.udanax.com
 * Copyright 1979-1999 Udanax.com. All rights reserved
 */
package org.abora.gold.nkernel;

import java.io.PrintWriter;
import org.abora.gold.be.basic.ID;
import org.abora.gold.detect.FeStatusDetector;
import org.abora.gold.java.missing.IntegerVar;
import org.abora.gold.nkernel.FeWork;
import org.abora.gold.xpp.basic.Heaper;


public class WorksTestStatusDetector extends FeStatusDetector {
	protected Character myTag;
	protected PrintWriter myOutput;
/*
udanax-top.st:19868:
FeStatusDetector subclass: #WorksTestStatusDetector
	instanceVariableNames: '
		myTag {Character star}
		myOutput {ostream star}'
	classVariableNames: ''
	poolDictionaries: ''
	category: 'Xanadu-nkernel'!
*/
/*
udanax-top.st:19874:
(WorksTestStatusDetector getOrMakeCxxClassDescription)
	attributes: ((Set new) add: #CONCRETE; add: #EQ; add: #NOT.A.TYPE; yourself)!
*/
/*
udanax-top.st:19907:
WorksTestStatusDetector class
	instanceVariableNames: ''!
*/
/*
udanax-top.st:19910:
(WorksTestStatusDetector getOrMakeCxxClassDescription)
	attributes: ((Set new) add: #CONCRETE; add: #EQ; add: #NOT.A.TYPE; yourself)!
*/

public void grabbed(FeWork work, ID author, IntegerVar reason) {
throw new UnsupportedOperationException();/*
udanax-top.st:19879:WorksTestStatusDetector methodsFor: 'triggering'!
{void} grabbed: work {FeWork} with: author {ID} with: reason {IntegerVar}
	[myOutput << myTag << ' canRevise (' << author << ')
'] smalltalkOnly.
	'(*myOutput) << myTag << " canRevise (" << author << ")\n";' translateOnly.!
*/
}

public void released(FeWork work, IntegerVar reason) {
throw new UnsupportedOperationException();/*
udanax-top.st:19885:WorksTestStatusDetector methodsFor: 'triggering'!
{void} released: work {FeWork} with: reason {IntegerVar}
	[myOutput << myTag << ' released
'] smalltalkOnly.
	'(*myOutput) << myTag << " released\n";' translateOnly!
*/
}

public  WorksTestStatusDetector(PrintWriter oo, String tag) {
throw new UnsupportedOperationException();/*
udanax-top.st:19893:WorksTestStatusDetector methodsFor: 'private: create'!
create: oo {ostream reference} with: tag {Character star}
	super create.
	[myOutput := oo] smalltalkOnly.
	'myOutput = &oo;' translateOnly.
	myTag := tag.!
*/
}

public int actualHashForEqual() {
throw new UnsupportedOperationException();/*
udanax-top.st:19902:WorksTestStatusDetector methodsFor: 'generated:'!
actualHashForEqual ^self asOop!
*/
}

public boolean isEqual(Object other) {
throw new UnsupportedOperationException();/*
udanax-top.st:19904:WorksTestStatusDetector methodsFor: 'generated:'!
isEqual: other ^self == other!
*/
}

public static Heaper make(PrintWriter oo, String tag) {
throw new UnsupportedOperationException();/*
udanax-top.st:19915:WorksTestStatusDetector class methodsFor: 'pseudo constructors'!
{FeStatusDetector} make: oo {ostream reference} with: tag {Character star}
	^self create: oo with: tag.!
*/
}
}
