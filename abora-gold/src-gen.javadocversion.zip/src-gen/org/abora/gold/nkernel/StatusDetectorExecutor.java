/*
 * Abora-Gold
 * Part of the Abora hypertext project: http://www.abora.org
 * Copyright 2003 David G Jones
 * 
 * Translated from Udanax-Gold source code: http://www.udanax.com
 * Copyright 1979-1999 Udanax.com. All rights reserved
 */
package org.abora.gold.nkernel;

import org.abora.gold.nkernel.FeWork;
import org.abora.gold.wparray.XnExecutor;
import org.abora.gold.xpp.basic.Heaper;


/**
 * This class informs its work when its last status detector has gone away.
 */
public class StatusDetectorExecutor extends XnExecutor {
	protected FeWork myWork;
/*
udanax-top.st:52725:
XnExecutor subclass: #StatusDetectorExecutor
	instanceVariableNames: 'myWork {FeWork}'
	classVariableNames: ''
	poolDictionaries: ''
	category: 'Xanadu-nkernel'!
*/
/*
udanax-top.st:52729:
StatusDetectorExecutor comment:
'This class informs its work when its last status detector has gone away.'!
*/
/*
udanax-top.st:52731:
(StatusDetectorExecutor getOrMakeCxxClassDescription)
	attributes: ((Set new) add: #CONCRETE; add: #NOT.A.TYPE; yourself)!
*/
/*
udanax-top.st:52747:
StatusDetectorExecutor class
	instanceVariableNames: ''!
*/
/*
udanax-top.st:52750:
(StatusDetectorExecutor getOrMakeCxxClassDescription)
	attributes: ((Set new) add: #CONCRETE; add: #NOT.A.TYPE; yourself)!
*/

public void execute(int arg) {
throw new UnsupportedOperationException();/*
udanax-top.st:52736:StatusDetectorExecutor methodsFor: 'executing'!
{void} execute: arg {Int32}
	arg == Int32Zero ifTrue: [
		myWork removeLastStatusDetector]!
*/
}

public  StatusDetectorExecutor(FeWork work) {
throw new UnsupportedOperationException();/*
udanax-top.st:52742:StatusDetectorExecutor methodsFor: 'protected: create'!
create: work {FeWork}
	super create.
	myWork := work.!
*/
}

public static Heaper make(FeWork work) {
throw new UnsupportedOperationException();/*
udanax-top.st:52755:StatusDetectorExecutor class methodsFor: 'create'!
{XnExecutor} make: work {FeWork}
	^ self create: work!
*/
}
}
