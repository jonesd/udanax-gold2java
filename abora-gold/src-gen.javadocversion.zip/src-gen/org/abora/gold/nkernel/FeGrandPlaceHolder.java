/*
 * Abora-Gold
 * Part of the Abora hypertext project: http://www.abora.org
 * Copyright 2003 David G Jones
 * 
 * Translated from Udanax-Gold source code: http://www.udanax.com
 * Copyright 1979-1999 Udanax.com. All rights reserved
 */
package org.abora.gold.nkernel;

import org.abora.gold.be.basic.BeRangeElement;
import org.abora.gold.be.basic.ID;
import org.abora.gold.detect.FeFillDetector;
import org.abora.gold.nkernel.FePlaceHolder;
import org.abora.gold.nkernel.FeRangeElement;


/**
 * Fakes a PlaceHolder in the GrandMap by just remembering the key.
 */
public class FeGrandPlaceHolder extends FePlaceHolder {
	protected ID myID;
/*
udanax-top.st:21937:
FePlaceHolder subclass: #FeGrandPlaceHolder
	instanceVariableNames: 'myID {ID}'
	classVariableNames: ''
	poolDictionaries: ''
	category: 'Xanadu-nkernel'!
*/
/*
udanax-top.st:21941:
FeGrandPlaceHolder comment:
'Fakes a PlaceHolder in the GrandMap by just remembering the key.'!
*/
/*
udanax-top.st:21943:
(FeGrandPlaceHolder getOrMakeCxxClassDescription)
	attributes: ((Set new) add: #OBSOLETE; add: #SMALLTALK.ONLY; add: #CONCRETE; add: #NOT.A.TYPE; yourself)!
*/

public FeRangeElement again() {
throw new UnsupportedOperationException();/*
udanax-top.st:21948:FeGrandPlaceHolder methodsFor: 'client accessing'!
{FeRangeElement} again
	^CurrentGrandMap fluidGet getOrMakeFe: myID!
*/
}

public boolean canMakeIdentical(FeRangeElement newIdentity) {
throw new UnsupportedOperationException();/*
udanax-top.st:21952:FeGrandPlaceHolder methodsFor: 'client accessing'!
{BooleanVar} canMakeIdentical: newIdentity {FeRangeElement}
	(self isIdentical: newIdentity) ifFalse:
		[self unimplemented].
	^true!
*/
}

/**
 * Consolidate this PlaceHolder to the newIdentity.  Return true if successful.
 */
public void makeIdentical(FeRangeElement newIdentity) {
throw new UnsupportedOperationException();/*
udanax-top.st:21958:FeGrandPlaceHolder methodsFor: 'client accessing'!
{void} makeIdentical: newIdentity {FeRangeElement}
	"Consolidate this PlaceHolder to the newIdentity.  Return true if successful."
	"Check permissions
		and then try storing the other guy into the grandMap."
	self thingToDo.  "This doesn't need to force newIdentity into a BeRangeElement."
	
	(CurrentKeyMaster fluidGet hasAuthority: self owner)
		ifFalse: [Heaper BLAST: #MustBeOwner].
	(CurrentGrandMap fluidGet at: myID tryIntroduce: newIdentity getOrMakeBe)
		ifFalse: [Heaper BLAST: #CantMakeIdentical]!
*/
}

/**
 * Ask the GrandMap who owns this ID
 */
public ID owner() {
throw new UnsupportedOperationException();/*
udanax-top.st:21970:FeGrandPlaceHolder methodsFor: 'client accessing'!
{ID} owner
	"Ask the GrandMap who owns this ID"
	^CurrentGrandMap fluidGet placeOwnerID: myID!
*/
}

public void removeFillDetector(FeFillDetector detector) {
throw new UnsupportedOperationException();/*
udanax-top.st:21975:FeGrandPlaceHolder methodsFor: 'client accessing'!
{void} removeFillDetector: detector {FeFillDetector}
	Heaper BLAST: #NotInSet!
*/
}

public BeRangeElement fetchBe() {
throw new UnsupportedOperationException();/*
udanax-top.st:21981:FeGrandPlaceHolder methodsFor: 'server accessing'!
{BeRangeElement | NULL} fetchBe
	^NULL!
*/
}

/**
 * Create a new persistent PlaceHolder and register it in the GrandMap.
 */
public BeRangeElement getOrMakeBe() {
throw new UnsupportedOperationException();/*
udanax-top.st:21985:FeGrandPlaceHolder methodsFor: 'server accessing'!
{BeRangeElement} getOrMakeBe
	"Create a new persistent PlaceHolder and register it in the GrandMap."
	| result {BeRangeElement} |
	InitialOwner fluidBind: self owner during:
		[result _ CurrentGrandMap fluidGet newPlaceHolder.
		(CurrentGrandMap fluidGet at: myID tryIntroduce: result)
			ifTrue: [^result]
			ifFalse: [^self again getOrMakeBe]]!
*/
}

public  FeGrandPlaceHolder(ID iD) {
throw new UnsupportedOperationException();/*
udanax-top.st:21997:FeGrandPlaceHolder methodsFor: 'private: create'!
create: iD {ID}
	super create.
	myID := iD!
*/
}
}
