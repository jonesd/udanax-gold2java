/*
 * Abora-Gold
 * Part of the Abora hypertext project: http://www.abora.org
 * Copyright 2003 David G Jones
 * 
 * Translated from Udanax-Gold source code: http://www.udanax.com
 * Copyright 1979-1999 Udanax.com. All rights reserved
 */
package org.abora.gold.nkernel;

import java.io.PrintWriter;
import org.abora.gold.detect.FeFillRangeDetector;
import org.abora.gold.nkernel.FeEdition;
import org.abora.gold.xpp.basic.Heaper;


public class WorksTestFillRangeDetector extends FeFillRangeDetector {
	protected Character myTag;
	protected PrintWriter myOutput;
/*
udanax-top.st:19626:
FeFillRangeDetector subclass: #WorksTestFillRangeDetector
	instanceVariableNames: '
		myTag {Character star}
		myOutput {ostream star}'
	classVariableNames: ''
	poolDictionaries: ''
	category: 'Xanadu-nkernel'!
*/
/*
udanax-top.st:19632:
(WorksTestFillRangeDetector getOrMakeCxxClassDescription)
	attributes: ((Set new) add: #CONCRETE; add: #EQ; add: #NOT.A.TYPE; yourself)!
*/
/*
udanax-top.st:19659:
WorksTestFillRangeDetector class
	instanceVariableNames: ''!
*/
/*
udanax-top.st:19662:
(WorksTestFillRangeDetector getOrMakeCxxClassDescription)
	attributes: ((Set new) add: #CONCRETE; add: #EQ; add: #NOT.A.TYPE; yourself)!
*/

public void rangeFilled(FeEdition transclusions) {
throw new UnsupportedOperationException();/*
udanax-top.st:19637:WorksTestFillRangeDetector methodsFor: 'triggering'!
{void} rangeFilled: transclusions {FeEdition}
	[myOutput << myTag << transclusions << '
'] smalltalkOnly.
	'(*myOutput) << myTag << transclusions << "\n";' translateOnly.!
*/
}

public  WorksTestFillRangeDetector(PrintWriter oo, String tag) {
throw new UnsupportedOperationException();/*
udanax-top.st:19645:WorksTestFillRangeDetector methodsFor: 'private: create'!
create: oo {ostream reference} with: tag {Character star}
	super create.
	[myOutput := oo] smalltalkOnly.
	'myOutput = &oo;' translateOnly.
	myTag := tag.!
*/
}

public int actualHashForEqual() {
throw new UnsupportedOperationException();/*
udanax-top.st:19654:WorksTestFillRangeDetector methodsFor: 'generated:'!
actualHashForEqual ^self asOop!
*/
}

public boolean isEqual(Object other) {
throw new UnsupportedOperationException();/*
udanax-top.st:19656:WorksTestFillRangeDetector methodsFor: 'generated:'!
isEqual: other ^self == other!
*/
}

public static Heaper make(PrintWriter oo, String tag) {
throw new UnsupportedOperationException();/*
udanax-top.st:19667:WorksTestFillRangeDetector class methodsFor: 'pseudo constructors'!
{FeFillRangeDetector} make: oo {ostream reference} with: tag {Character star}
	^self create: oo with: tag.!
*/
}
}
