/*
 * Abora-Gold
 * Part of the Abora hypertext project: http://www.abora.org
 * Copyright 2003 David G Jones
 * 
 * Translated from Udanax-Gold source code: http://www.udanax.com
 * Copyright 1979-1999 Udanax.com. All rights reserved
 */
package org.abora.gold.nkernel;

import org.abora.gold.be.basic.BeRangeElement;
import org.abora.gold.be.basic.ID;
import org.abora.gold.detect.FeFillDetector;
import org.abora.gold.nkernel.FePlaceHolder;
import org.abora.gold.nkernel.FeRangeElement;


/**
 * Actually has a persistent individual PlaceHolder on the Server, or used to, and now has a
 * pointer to the rangeElement it became.
 */
public class FeActualPlaceHolder extends FePlaceHolder {
	protected BeRangeElement myRangeElement;
/*
udanax-top.st:21857:
FePlaceHolder subclass: #FeActualPlaceHolder
	instanceVariableNames: 'myRangeElement {BeRangeElement}'
	classVariableNames: ''
	poolDictionaries: ''
	category: 'Xanadu-nkernel'!
*/
/*
udanax-top.st:21861:
FeActualPlaceHolder comment:
'Actually has a persistent individual PlaceHolder on the Server, or used to, and now has a pointer to the rangeElement it became.'!
*/
/*
udanax-top.st:21863:
(FeActualPlaceHolder getOrMakeCxxClassDescription)
	attributes: ((Set new) add: #CONCRETE; add: #NOT.A.TYPE; yourself)!
*/

public FeRangeElement again() {
throw new UnsupportedOperationException();/*
udanax-top.st:21868:FeActualPlaceHolder methodsFor: 'client accessing'!
{FeRangeElement} again
Dean shouldImplement.  "This must hold onto an FeRangeElement so that the label is properly maintained."
	myRangeElement cast: BePlaceHolder into: [:pl | ^self  "No change."]
		others: [^myRangeElement makeFe: NULL].
	^NULL "fodder"!
*/
}

public boolean canMakeIdentical(FeRangeElement newIdentity) {
throw new UnsupportedOperationException();/*
udanax-top.st:21875:FeActualPlaceHolder methodsFor: 'client accessing'!
{BooleanVar} canMakeIdentical: newIdentity {FeRangeElement}
	(self isIdentical: newIdentity) ifFalse:
		[self unimplemented].
	^true!
*/
}

/**
 * Consolidate this PlaceHolder to the newIdentity.  Return true if successful.
 */
public void makeIdentical(FeRangeElement newIdentity) {
throw new UnsupportedOperationException();/*
udanax-top.st:21881:FeActualPlaceHolder methodsFor: 'client accessing'!
{void} makeIdentical: newIdentity {FeRangeElement}
	"Consolidate this PlaceHolder to the newIdentity.  Return true if successful."
	
	"Check permissions
		and forward the operation after coercing the newIdentity
		 to a persistent RangeElement."
		
	"myRangeElement will tell me to forward to another RangeElement."
	
	(CurrentKeyMaster fluidGet hasAuthority: self owner) ifFalse:
		[Heaper BLAST: #MustBeOwner].
	myRangeElement makeIdentical: newIdentity getOrMakeBe!
*/
}

/**
 * MyBeRangeElement will know it.
 */
public ID owner() {
throw new UnsupportedOperationException();/*
udanax-top.st:21894:FeActualPlaceHolder methodsFor: 'client accessing'!
{ID} owner
	"MyBeRangeElement will know it."
	
	^myRangeElement owner!
*/
}

public void removeFillDetector(FeFillDetector detector) {
throw new UnsupportedOperationException();/*
udanax-top.st:21899:FeActualPlaceHolder methodsFor: 'client accessing'!
{void} removeFillDetector: detector {FeFillDetector}
	(Heaper isDestructed: myRangeElement) ifFalse:
		[myRangeElement cast: BePlaceHolder into: [ :p |
			p removeDetector: detector]
		others: []]!
*/
}

public BeRangeElement fetchBe() {
throw new UnsupportedOperationException();/*
udanax-top.st:21908:FeActualPlaceHolder methodsFor: 'server accessing'!
{BeRangeElement | NULL} fetchBe
	^myRangeElement!
*/
}

/**
 * myRangeElement has become something else.  Forward to the new thing.
 */
public void forwardTo(BeRangeElement element) {
throw new UnsupportedOperationException();/*
udanax-top.st:21912:FeActualPlaceHolder methodsFor: 'server accessing'!
{void} forwardTo: element {BeRangeElement}
	"myRangeElement has become something else.  Forward to the new thing."
	
	myRangeElement removeFeRangeElement: self.
	myRangeElement _ element.
	myRangeElement addFeRangeElement: self.!
*/
}

public BeRangeElement getOrMakeBe() {
throw new UnsupportedOperationException();/*
udanax-top.st:21919:FeActualPlaceHolder methodsFor: 'server accessing'!
{BeRangeElement} getOrMakeBe
	^myRangeElement!
*/
}

public  FeActualPlaceHolder(BeRangeElement be) {
throw new UnsupportedOperationException();/*
udanax-top.st:21925:FeActualPlaceHolder methodsFor: 'private: create'!
create: be {BeRangeElement}
	super create.
	myRangeElement := be.!
*/
}

public void destruct() {
throw new UnsupportedOperationException();/*
udanax-top.st:21932:FeActualPlaceHolder methodsFor: 'destruct'!
{void} destruct
	myRangeElement removeFeRangeElement: self.
	super destruct.!
*/
}
}
