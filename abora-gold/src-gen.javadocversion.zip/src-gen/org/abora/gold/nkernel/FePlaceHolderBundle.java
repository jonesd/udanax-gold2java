/*
 * Abora-Gold
 * Part of the Abora hypertext project: http://www.abora.org
 * Copyright 2003 David G Jones
 * 
 * Translated from Udanax-Gold source code: http://www.udanax.com
 * Copyright 1979-1999 Udanax.com. All rights reserved
 */
package org.abora.gold.nkernel;

import org.abora.gold.nkernel.FeBundle;
import org.abora.gold.spaces.basic.XnRegion;
import org.abora.gold.xpp.basic.Heaper;


/**
 * Describes a region of an Edition in which all indices in my region have a distinct
 * PlaceHolder.
 */
public class FePlaceHolderBundle extends FeBundle {
/*
udanax-top.st:19394:
FeBundle subclass: #FePlaceHolderBundle
	instanceVariableNames: ''
	classVariableNames: ''
	poolDictionaries: ''
	category: 'Xanadu-nkernel'!
*/
/*
udanax-top.st:19398:
FePlaceHolderBundle comment:
'Describes a region of an Edition in which all indices in my region have a distinct PlaceHolder.'!
*/
/*
udanax-top.st:19400:
(FePlaceHolderBundle getOrMakeCxxClassDescription)
	attributes: ((Set new) add: #ON.CLIENT; add: #CONCRETE; yourself)!
*/
/*
udanax-top.st:19410:
FePlaceHolderBundle class
	instanceVariableNames: ''!
*/
/*
udanax-top.st:19413:
(FePlaceHolderBundle getOrMakeCxxClassDescription)
	attributes: ((Set new) add: #ON.CLIENT; add: #CONCRETE; yourself)!
*/

public  FePlaceHolderBundle(XnRegion region) {
	super(region);
throw new UnsupportedOperationException();/*
udanax-top.st:19405:FePlaceHolderBundle methodsFor: 'private: create'!
create: region {XnRegion}
	super create: region.!
*/
}

public static Heaper make(XnRegion region) {
throw new UnsupportedOperationException();/*
udanax-top.st:19418:FePlaceHolderBundle class methodsFor: 'create'!
make: region {XnRegion}
	^self create: region!
*/
}
}
