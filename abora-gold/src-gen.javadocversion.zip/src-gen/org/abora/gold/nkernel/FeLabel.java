/*
 * Abora-Gold
 * Part of the Abora hypertext project: http://www.abora.org
 * Copyright 2003 David G Jones
 * 
 * Translated from Udanax-Gold source code: http://www.udanax.com
 * Copyright 1979-1999 Udanax.com. All rights reserved
 */
package org.abora.gold.nkernel;

import java.io.PrintWriter;
import org.abora.gold.be.basic.BeLabel;
import org.abora.gold.be.basic.BeRangeElement;
import org.abora.gold.nkernel.FeLabel;
import org.abora.gold.nkernel.FeRangeElement;
import org.abora.gold.xpp.basic.Heaper;


/**
 * An identity attached to a RangeElement within an Edition.
 */
public class FeLabel extends FeRangeElement {
	protected BeLabel myBeLabel;
/*
udanax-top.st:21705:
FeRangeElement subclass: #FeLabel
	instanceVariableNames: 'myBeLabel {BeLabel | NULL}'
	classVariableNames: ''
	poolDictionaries: ''
	category: 'Xanadu-nkernel'!
*/
/*
udanax-top.st:21709:
FeLabel comment:
'An identity attached to a RangeElement within an Edition.'!
*/
/*
udanax-top.st:21711:
(FeLabel getOrMakeCxxClassDescription)
	attributes: ((Set new) add: #ON.CLIENT; add: #CONCRETE; yourself)!
*/
/*
udanax-top.st:21764:
FeLabel class
	instanceVariableNames: ''!
*/
/*
udanax-top.st:21767:
(FeLabel getOrMakeCxxClassDescription)
	attributes: ((Set new) add: #ON.CLIENT; add: #CONCRETE; yourself)!
*/

public BeRangeElement fetchBe() {
throw new UnsupportedOperationException();/*
udanax-top.st:21716:FeLabel methodsFor: 'server accessing'!
{BeRangeElement | NULL} fetchBe
	^myBeLabel!
*/
}

public BeRangeElement getOrMakeBe() {
throw new UnsupportedOperationException();/*
udanax-top.st:21720:FeLabel methodsFor: 'server accessing'!
{BeRangeElement} getOrMakeBe
	myBeLabel == NULL ifTrue:
		[myBeLabel _ CurrentGrandMap fluidGet newLabel.
		myBeLabel addFeRangeElement: self].
	^myBeLabel!
*/
}

public FeRangeElement again() {
throw new UnsupportedOperationException();/*
udanax-top.st:21729:FeLabel methodsFor: 'client accessing'!
{FeRangeElement} again
	self unimplemented.
	^NULL "fodder"!
*/
}

public boolean canMakeIdentical(FeRangeElement newIdentity) {
throw new UnsupportedOperationException();/*
udanax-top.st:21734:FeLabel methodsFor: 'client accessing'!
{BooleanVar} canMakeIdentical: newIdentity {FeRangeElement}
	(self isIdentical: newIdentity) ifFalse:
		[self unimplemented].
	^true!
*/
}

public void makeIdentical(FeRangeElement newIdentity) {
throw new UnsupportedOperationException();/*
udanax-top.st:21740:FeLabel methodsFor: 'client accessing'!
{void} makeIdentical: newIdentity {FeRangeElement}
	self unimplemented!
*/
}

public void destruct() {
throw new UnsupportedOperationException();/*
udanax-top.st:21746:FeLabel methodsFor: 'destruct'!
{void} destruct
	myBeLabel == NULL ifFalse:
		[myBeLabel removeFeRangeElement: self].
	super destruct.!
*/
}

public  FeLabel(BeLabel label) {
throw new UnsupportedOperationException();/*
udanax-top.st:21754:FeLabel methodsFor: 'creation'!
create: label {BeLabel | NULL}
	super create.
	myBeLabel _ label.!
*/
}

public void printOn(PrintWriter oo) {
throw new UnsupportedOperationException();/*
udanax-top.st:21760:FeLabel methodsFor: 'printing'!
{void} printOn: oo {ostream reference}
	oo << self getCategory name << '(' << self getOrMakeBe hashForEqual << ')'!
*/
}

/**
 * The label will be made on demand.
 */
public static FeLabel fake() {
throw new UnsupportedOperationException();/*
udanax-top.st:21772:FeLabel class methodsFor: 'creation'!
{FeLabel} fake
	"The label will be made on demand."
	^self on: NULL!
*/
}

/**
 * Essential. Create a new unique Label
 */
public static Heaper make() {
throw new UnsupportedOperationException();/*
udanax-top.st:21777:FeLabel class methodsFor: 'creation'!
{FeLabel CLIENT} make
	"Essential. Create a new unique Label"
	
	^FeLabel fake!
*/
}

public static FeLabel on(BeLabel label) {
throw new UnsupportedOperationException();/*
udanax-top.st:21782:FeLabel class methodsFor: 'creation'!
{FeLabel} on: label {BeLabel | NULL}
	
	| result {FeLabel} |
	result := self create: label.
	label ~~ NULL ifTrue:
		[label addFeRangeElement: result].
	^result!
*/
}
}
