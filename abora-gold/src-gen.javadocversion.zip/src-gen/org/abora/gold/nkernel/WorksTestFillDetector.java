/*
 * Abora-Gold
 * Part of the Abora hypertext project: http://www.abora.org
 * Copyright 2003 David G Jones
 * 
 * Translated from Udanax-Gold source code: http://www.udanax.com
 * Copyright 1979-1999 Udanax.com. All rights reserved
 */
package org.abora.gold.nkernel;

import java.io.PrintWriter;
import org.abora.gold.detect.FeFillDetector;
import org.abora.gold.nkernel.FeRangeElement;
import org.abora.gold.xpp.basic.Heaper;


public class WorksTestFillDetector extends FeFillDetector {
	protected Character myTag;
	protected PrintWriter myOutput;
/*
udanax-top.st:19506:
FeFillDetector subclass: #WorksTestFillDetector
	instanceVariableNames: '
		myTag {Character star}
		myOutput {ostream star}'
	classVariableNames: ''
	poolDictionaries: ''
	category: 'Xanadu-nkernel'!
*/
/*
udanax-top.st:19512:
(WorksTestFillDetector getOrMakeCxxClassDescription)
	attributes: ((Set new) add: #CONCRETE; add: #EQ; add: #NOT.A.TYPE; yourself)!
*/
/*
udanax-top.st:19539:
WorksTestFillDetector class
	instanceVariableNames: ''!
*/
/*
udanax-top.st:19542:
(WorksTestFillDetector getOrMakeCxxClassDescription)
	attributes: ((Set new) add: #CONCRETE; add: #EQ; add: #NOT.A.TYPE; yourself)!
*/

public void filled(FeRangeElement transclusion) {
throw new UnsupportedOperationException();/*
udanax-top.st:19517:WorksTestFillDetector methodsFor: 'triggering'!
{void} filled: transclusion {FeRangeElement}
	[myOutput << myTag << transclusion << '
'] smalltalkOnly.
	'(*myOutput) << myTag << transclusion << "\n";' translateOnly.!
*/
}

public  WorksTestFillDetector(PrintWriter oo, String tag) {
throw new UnsupportedOperationException();/*
udanax-top.st:19525:WorksTestFillDetector methodsFor: 'private: create'!
create: oo {ostream reference} with: tag {Character star}
	super create.
	[myOutput := oo] smalltalkOnly.
	'myOutput = &oo;' translateOnly.
	myTag := tag.!
*/
}

public int actualHashForEqual() {
throw new UnsupportedOperationException();/*
udanax-top.st:19534:WorksTestFillDetector methodsFor: 'generated:'!
actualHashForEqual ^self asOop!
*/
}

public boolean isEqual(Object other) {
throw new UnsupportedOperationException();/*
udanax-top.st:19536:WorksTestFillDetector methodsFor: 'generated:'!
isEqual: other ^self == other!
*/
}

public static Heaper make(PrintWriter oo, String tag) {
throw new UnsupportedOperationException();/*
udanax-top.st:19547:WorksTestFillDetector class methodsFor: 'pseudo constructors'!
{FeFillDetector} make: oo {ostream reference} with: tag {Character star}
	^self create: oo with: tag.!
*/
}
}
