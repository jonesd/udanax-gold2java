/*
 * Abora-Gold
 * Part of the Abora hypertext project: http://www.abora.org
 * Copyright 2003 David G Jones
 * 
 * Translated from Udanax-Gold source code: http://www.udanax.com
 * Copyright 1979-1999 Udanax.com. All rights reserved
 */
package org.abora.gold.nkernel;

import java.io.PrintWriter;
import org.abora.gold.detect.FeWaitDetector;
import org.abora.gold.xpp.basic.Heaper;


/**
 * This class keeps a pointer to an ostream rather than a reference since class
 * ios::operator=() is private.
 */
public class WorksWaitDetector extends FeWaitDetector {
	protected Character myTag;
	protected PrintWriter myOutput;
/*
udanax-top.st:19990:
FeWaitDetector subclass: #WorksWaitDetector
	instanceVariableNames: '
		myTag {Character star}
		myOutput {ostream star}'
	classVariableNames: ''
	poolDictionaries: ''
	category: 'Xanadu-nkernel'!
*/
/*
udanax-top.st:19996:
WorksWaitDetector comment:
'This class keeps a pointer to an ostream rather than a reference since class ios::operator=() is private.'!
*/
/*
udanax-top.st:19998:
(WorksWaitDetector getOrMakeCxxClassDescription)
	attributes: ((Set new) add: #CONCRETE; add: #EQ; add: #NOT.A.TYPE; yourself)!
*/
/*
udanax-top.st:20025:
WorksWaitDetector class
	instanceVariableNames: ''!
*/
/*
udanax-top.st:20028:
(WorksWaitDetector getOrMakeCxxClassDescription)
	attributes: ((Set new) add: #CONCRETE; add: #EQ; add: #NOT.A.TYPE; yourself)!
*/

public  WorksWaitDetector(PrintWriter oo, String tag) {
throw new UnsupportedOperationException();/*
udanax-top.st:20003:WorksWaitDetector methodsFor: 'creation'!
create: oo {ostream reference} with: tag {Character star}
	super create.
	[myOutput := oo] smalltalkOnly.
	'myOutput = &oo;' translateOnly.
	myTag := tag.!
*/
}

public void done() {
throw new UnsupportedOperationException();/*
udanax-top.st:20012:WorksWaitDetector methodsFor: 'triggering'!
{NOACK CLIENT} done
	[myOutput << myTag << '
'] smalltalkOnly.
	'*myOutput << myTag << "\n";' translateOnly.!
*/
}

public int actualHashForEqual() {
throw new UnsupportedOperationException();/*
udanax-top.st:20020:WorksWaitDetector methodsFor: 'generated:'!
actualHashForEqual ^self asOop!
*/
}

public boolean isEqual(Object other) {
throw new UnsupportedOperationException();/*
udanax-top.st:20022:WorksWaitDetector methodsFor: 'generated:'!
isEqual: other ^self == other!
*/
}

public static Heaper make(PrintWriter oo, String tag) {
throw new UnsupportedOperationException();/*
udanax-top.st:20033:WorksWaitDetector class methodsFor: 'creation'!
{FeWaitDetector} make: oo {ostream reference} with: tag {Character star}
	^self create: oo with: tag!
*/
}
}
