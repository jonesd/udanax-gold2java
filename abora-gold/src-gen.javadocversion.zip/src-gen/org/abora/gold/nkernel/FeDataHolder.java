/*
 * Abora-Gold
 * Part of the Abora hypertext project: http://www.abora.org
 * Copyright 2003 David G Jones
 * 
 * Translated from Udanax-Gold source code: http://www.udanax.com
 * Copyright 1979-1999 Udanax.com. All rights reserved
 */
package org.abora.gold.nkernel;

import java.io.PrintWriter;
import org.abora.gold.be.basic.BeDataHolder;
import org.abora.gold.be.basic.BeEdition;
import org.abora.gold.be.basic.BeRangeElement;
import org.abora.gold.nkernel.FeDataHolder;
import org.abora.gold.nkernel.FeRangeElement;
import org.abora.gold.spaces.basic.Position;
import org.abora.gold.x.PrimValue;
import org.abora.gold.xpp.basic.Heaper;


/**
 * The kind of FeRangeElement that represents a piece of data in the Server, along with its
 * identity.
 */
public class FeDataHolder extends FeRangeElement {
/*
udanax-top.st:20516:
FeRangeElement subclass: #FeDataHolder
	instanceVariableNames: ''
	classVariableNames: ''
	poolDictionaries: ''
	category: 'Xanadu-nkernel'!
*/
/*
udanax-top.st:20520:
FeDataHolder comment:
'The kind of FeRangeElement that represents a piece of data in the Server, along with its identity.'!
*/
/*
udanax-top.st:20522:
(FeDataHolder getOrMakeCxxClassDescription)
	attributes: ((Set new) add: #ON.CLIENT; add: #DEFERRED; yourself)!
*/
/*
udanax-top.st:20577:
FeDataHolder class
	instanceVariableNames: ''!
*/
/*
udanax-top.st:20580:
(FeDataHolder getOrMakeCxxClassDescription)
	attributes: ((Set new) add: #ON.CLIENT; add: #DEFERRED; yourself)!
*/

public FeRangeElement again() {
throw new UnsupportedOperationException();/*
udanax-top.st:20527:FeDataHolder methodsFor: 'client accessing'!
{FeRangeElement} again
	self subclassResponsibility!
*/
}

/**
 * Check that it is data with the same value,
 * and check permissions,
 * and forward the operation after coercing the newIdentity to a persistent RangeElement.
 */
public boolean canMakeIdentical(FeRangeElement newIdentity) {
throw new UnsupportedOperationException();/*
udanax-top.st:20531:FeDataHolder methodsFor: 'client accessing'!
{BooleanVar} canMakeIdentical: newIdentity {FeRangeElement}
	
	"Check that it is data with the same value,
		and check permissions,
		and forward the operation after coercing the newIdentity to a persistent RangeElement."
	
	^((newIdentity isKindOf: FeDataHolder)
			and: [((newIdentity cast: FeDataHolder) value isEqual: self value)])!
*/
}

/**
 * Allow consolidation of data in 1st product.
 */
public void makeIdentical(FeRangeElement newIdentity) {
throw new UnsupportedOperationException();/*
udanax-top.st:20540:FeDataHolder methodsFor: 'client accessing'!
{void} makeIdentical: newIdentity {FeRangeElement}
	"Allow consolidation of data in 1st product."
	| ckm {FeKeyMaster} |
	"Check that it is data with the same value,
		and check permissions,
		and forward the operation after coercing the newIdentity to a persistent RangeElement."
	
	self thingToDo. "better blast"
	ckm := CurrentKeyMaster fluidGet.
	((newIdentity isKindOf: FeDataHolder)
			and: [((newIdentity cast: FeDataHolder) value isEqual: self value)
			and: [ckm hasAuthority: self owner]])
		ifTrue: [Heaper BLAST: #CantMakeIdentical].
	self getOrMakeBe makeIdentical: newIdentity getOrMakeBe!
*/
}

/**
 * Essential.  The actual data value
 */
public PrimValue value() {
throw new UnsupportedOperationException();/*
udanax-top.st:20555:FeDataHolder methodsFor: 'client accessing'!
{PrimValue CLIENT} value
	"Essential.  The actual data value"
	
	self subclassResponsibility!
*/
}

public BeRangeElement fetchBe() {
throw new UnsupportedOperationException();/*
udanax-top.st:20562:FeDataHolder methodsFor: 'server accessing'!
{BeRangeElement | NULL} fetchBe
	self subclassResponsibility!
*/
}

public BeRangeElement getOrMakeBe() {
throw new UnsupportedOperationException();/*
udanax-top.st:20566:FeDataHolder methodsFor: 'server accessing'!
{BeRangeElement} getOrMakeBe
	self subclassResponsibility!
*/
}

public void printOn(PrintWriter oo) {
throw new UnsupportedOperationException();/*
udanax-top.st:20572:FeDataHolder methodsFor: 'printing'!
{void} printOn: oo {ostream reference}
	oo << 'DataHolder(' << self value << ')'!
*/
}

public static FeDataHolder fake(PrimValue value, Position key, BeEdition edition) {
throw new UnsupportedOperationException();/*
udanax-top.st:20585:FeDataHolder class methodsFor: 'creation'!
{FeDataHolder} fake: value {PrimValue}
	with: key {Position}
	with: edition {BeEdition}
	
	^FeVirtualDataHolder create: value with: key with: edition.!
*/
}

/**
 * Make a single DataHolder with the given value
 */
public static Heaper make(PrimValue value) {
throw new UnsupportedOperationException();/*
udanax-top.st:20591:FeDataHolder class methodsFor: 'creation'!
{FeDataHolder CLIENT} make: value {PrimValue}
	"Make a single DataHolder with the given value"
	
	^FeDataHolder on: (CurrentGrandMap fluidGet newDataHolder: value)!
*/
}

public static FeDataHolder on(BeDataHolder be) {
throw new UnsupportedOperationException();/*
udanax-top.st:20596:FeDataHolder class methodsFor: 'creation'!
{FeDataHolder} on: be {BeDataHolder}
	| result {FeDataHolder} |
	result := FeActualDataHolder create: be.
	be addFeRangeElement: result.
	^result!
*/
}

/**
 * {PrimValue CLIENT} value
 */
public static void info() {
throw new UnsupportedOperationException();/*
udanax-top.st:20605:FeDataHolder class methodsFor: 'smalltalk: system'!
info.stProtocol
"{PrimValue CLIENT} value
"!
*/
}
}
