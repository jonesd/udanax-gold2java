/*
 * Abora-Gold
 * Part of the Abora hypertext project: http://www.abora.org
 * Copyright 2003 David G Jones
 * 
 * Translated from Udanax-Gold source code: http://www.udanax.com
 * Copyright 1979-1999 Udanax.com. All rights reserved
 */
package org.abora.gold.nkernel;

import org.abora.gold.be.basic.BeCarrier;
import org.abora.gold.be.basic.BeRangeElement;
import org.abora.gold.be.basic.ID;
import org.abora.gold.detect.FeFillDetector;
import org.abora.gold.filter.Filter;
import org.abora.gold.id.IDRegion;
import org.abora.gold.nkernel.FeEdition;
import org.abora.gold.nkernel.FeKeyMaster;
import org.abora.gold.nkernel.FeLabel;
import org.abora.gold.nkernel.FeRangeElement;
import org.abora.gold.spaces.cross.CrossRegion;
import org.abora.gold.xpp.basic.Heaper;


/**
 * The kinds of objects which can be in the range of Editions.
 */
public class FeRangeElement extends Heaper {
/*
udanax-top.st:20253:
Heaper subclass: #FeRangeElement
	instanceVariableNames: ''
	classVariableNames: ''
	poolDictionaries: ''
	category: 'Xanadu-nkernel'!
*/
/*
udanax-top.st:20257:
FeRangeElement comment:
'The kinds of objects which can be in the range of Editions.'!
*/
/*
udanax-top.st:20259:
(FeRangeElement getOrMakeCxxClassDescription)
	attributes: ((Set new) add: #ON.CLIENT; add: #DEFERRED; add: #EQ; yourself)!
*/
/*
udanax-top.st:20463:
FeRangeElement class
	instanceVariableNames: ''!
*/
/*
udanax-top.st:20466:
(FeRangeElement getOrMakeCxxClassDescription)
	attributes: ((Set new) add: #ON.CLIENT; add: #DEFERRED; add: #EQ; yourself)!
*/

public FeEdition works() {
throw new UnsupportedOperationException();/*
udanax-top.st:20264:FeRangeElement methodsFor: 'smalltalk: defaults'!
{FeEdition CLIENT} works
	
	^self works: NULL with: 0 with: NULL!
*/
}

public FeEdition works(Filter filter) {
throw new UnsupportedOperationException();/*
udanax-top.st:20268:FeRangeElement methodsFor: 'smalltalk: defaults'!
{FeEdition CLIENT} works: filter {Filter default: NULL}
	
	^self works: filter with: 0 with: NULL!
*/
}

public FeEdition works(Filter filter, int flags) {
throw new UnsupportedOperationException();/*
udanax-top.st:20272:FeRangeElement methodsFor: 'smalltalk: defaults'!
{FeEdition CLIENT} works: filter {Filter default: NULL}
	with: flags {Int32 default: Int32Zero}
	
	^self works: filter with: flags with: NULL!
*/
}

/**
 * Essential.  When this PlaceHolder becomes any other kind of RangeElement, then the
 * Detector will be triggered with the new RangeElement. If this is already not a
 * PlaceHolder, then the Detector is triggered immediately with this RangeElement.
 * See FillRangeDetector::filled (RangeElement * newIdentity).
 */
public void addFillDetector(FeFillDetector detector) {
throw new UnsupportedOperationException();/*
udanax-top.st:20279:FeRangeElement methodsFor: 'accessing'!
{void} addFillDetector: detector {FeFillDetector}
	"Essential.  When this PlaceHolder becomes any other kind of RangeElement, then the Detector will be triggered with the new RangeElement. If this is already not a PlaceHolder, then the Detector is triggered immediately with this RangeElement.
	See FillRangeDetector::filled (RangeElement * newIdentity)."
	
	detector filled: self. "default will be overridden in FePlaceHolder"!
*/
}

/**
 * Essential.  An object reflecting the current identity of this object, in case it is a
 * PlaceHolder that has become something else since it was received from the Server.
 */
public FeRangeElement again() {
throw new UnsupportedOperationException();/*
udanax-top.st:20285:FeRangeElement methodsFor: 'accessing'!
{FeRangeElement CLIENT} again
	"Essential.  An object reflecting the current identity of this object, in case it is a PlaceHolder that has become something else since it was received from the Server."
	
	self subclassResponsibility!
*/
}

/**
 * Essential.  Whether the identity of this object could be changed to the other.
 * Does not check whether the CurrentKeyMaster has authority to do it.
 * The restrictions on this operation depend on which subclass this is, but in general
 * (except for PlaceHolders) an object can only become another of the same type with the same
 * content.
 */
public boolean canMakeIdentical(FeRangeElement newIdentity) {
throw new UnsupportedOperationException();/*
udanax-top.st:20290:FeRangeElement methodsFor: 'accessing'!
{BooleanVar CLIENT} canMakeIdentical: newIdentity {FeRangeElement}
	"Essential.  Whether the identity of this object could be changed to the other.
	Does not check whether the CurrentKeyMaster has authority to do it.
	The restrictions on this operation depend on which subclass this is, but in general (except for PlaceHolders) an object can only become another of the same type with the same content."
	
	RaviNow shouldImplement.
	^false "fodder"!
*/
}

/**
 * Essential.  Return a FillDetector that will be triggered when this RangeElement becomes
 * something other than a PlaceHolder, or immeditely if this RangeElement is not currently a
 * PlaceHolder.
 * See FillRangeDetector::filled (RangeElement * newIdentity).
 */
public FeFillDetector fillDetector() {
throw new UnsupportedOperationException();/*
udanax-top.st:20298:FeRangeElement methodsFor: 'accessing'!
{FeFillDetector CLIENT} fillDetector
	"Essential.  Return a FillDetector that will be triggered when this RangeElement becomes something other than a PlaceHolder, or immeditely if this RangeElement is not currently a PlaceHolder.
	See FillRangeDetector::filled (RangeElement * newIdentity)."
	
	Dean shouldImplement.
	self addFillDetector: NULL.
	^NULL "fodder"!
*/
}

/**
 * Essential.  Return whether two objects have the same identity on the Server.  Note that
 * this can change over time, if makeIdentical is used.  However, for a given pair of
 * FeRangeElements, it can only change from not being the same to being the same while you
 * are holding onto them.
 */
public boolean isIdentical(FeRangeElement other) {
throw new UnsupportedOperationException();/*
udanax-top.st:20306:FeRangeElement methodsFor: 'accessing'!
{BooleanVar CLIENT} isIdentical: other {FeRangeElement}
	"Essential.  Return whether two objects have the same identity on the Server.  Note that this can change over time, if makeIdentical is used.  However, for a given pair of FeRangeElements, it can only change from not being the same to being the same while you are holding onto them."
	
	other cast: FeVirtualDataHolder into: [ :vd |
		^vd isIdentical: self]
	cast: FeVirtualPlaceHolder into: [ :vp |
		^vp isIdentical: self]
	others:
		["This should be OK, since virtual subclasses override this anyway"
		^self getOrMakeBe isEqual: other getOrMakeBe].
	^false "fodder"!
*/
}

/**
 * Essential.  Change the identity of this object to the other. BLAST if unsuccessful.
 * Requires authority of the current owner; if the operation is successful, the owner will
 * appear to change to that of the other object.
 * Also requires enough permission on newIdentity to determine, by comparing content, whether
 * the operation would succeed.
 * The restrictions on this operation depend on which subclass this is, but in general
 * (except for PlaceHolders) an object can only become another of the same type with the same
 * content.
 */
public void makeIdentical(FeRangeElement newIdentity) {
throw new UnsupportedOperationException();/*
udanax-top.st:20318:FeRangeElement methodsFor: 'accessing'!
{void CLIENT} makeIdentical: newIdentity {FeRangeElement}
	"Essential.  Change the identity of this object to the other. BLAST if unsuccessful.
	Requires authority of the current owner; if the operation is successful, the owner will appear to change to that of the other object.
	Also requires enough permission on newIdentity to determine, by comparing content, whether the operation would succeed.
	The restrictions on this operation depend on which subclass this is, but in general (except for PlaceHolders) an object can only become another of the same type with the same content."
	
	self subclassResponsibility!
*/
}

/**
 * Essential.  The Club which owns this RangeElement, and has the authority to make it become
 * something else, and to transfer ownership to someone else.
 */
public ID owner() {
throw new UnsupportedOperationException();/*
udanax-top.st:20326:FeRangeElement methodsFor: 'accessing'!
{ID CLIENT} owner
	"Essential.  The Club which owns this RangeElement, and has the authority to make it become something else, and to transfer ownership to someone else."
	
	^self getOrMakeBe owner "virtuals should override"!
*/
}

/**
 * Essential.  Remove a Detector which had been added to this RangeElement. You should remove
 * every Detector you add, although they will go away automatically when a client session
 * terminates.
 */
public void removeFillDetector(FeFillDetector detector) {
throw new UnsupportedOperationException();/*
udanax-top.st:20331:FeRangeElement methodsFor: 'accessing'!
{void} removeFillDetector: detector {FeFillDetector}
	"Essential.  Remove a Detector which had been added to this RangeElement. You should remove every Detector you add, although they will go away automatically when a client session terminates."
	
	||
	"Do nothing. PlaceHolder overrides"!
*/
}

/**
 * Essential.  Change the owner; must have the authority of the current owner.
 */
public void setOwner(ID clubID) {
throw new UnsupportedOperationException();/*
udanax-top.st:20337:FeRangeElement methodsFor: 'accessing'!
{void CLIENT} setOwner: clubID {ID}
	"Essential.  Change the owner; must have the authority of the current owner."
	
	(CurrentKeyMaster fluidGet hasAuthority: self owner) ifFalse:
		[Heaper BLAST: #MustBeOwner].
	"Need to make it into a reified range element in order to have distinct ownership"
	
	CurrentGrandMap fluidGet getClub: clubID.  "Checks that it is a club."
	self getOrMakeBe setOwner: clubID!
*/
}

/**
 * All Editions which the CurrentKeyMaster can see, which transclude this RangeElement.
 * If a directFilter is given, then the visibleEndorsements on a Edition must match the
 * filter.
 * If an indirectFilter is given, then a resulting Edition must be contained in some readable
 * Edition whose visibleEndorsements match the filter.
 * If the directContainersOnly flag is set, then a resulting Edition must contain this
 * directly as a RangeElement; otherwise, indirect containment through Editions is allowed.
 * If the localPresentOnly flag is set, then only Editions currently known to this Server are
 * guaranteed to end up in the result; otherwise, Editions which come to satisfy the
 * conditions in the future, and those on other Servers, may also be found.
 * Equivalent to
 * FeServer::current ()->newEditionWith (<any position>, this)
 * ->rangeTranscluders (NULL, directFilter, indirectFilter, flags, otherTranscluders).
 */
public FeEdition transcluders(Filter directFilter, Filter indirectFilter, int flags, FeEdition otherTranscluders) {
throw new UnsupportedOperationException();/*
udanax-top.st:20347:FeRangeElement methodsFor: 'accessing'!
{FeEdition CLIENT} transcluders: directFilter {Filter default: NULL}
	with: indirectFilter {Filter default: NULL}
	with: flags {Int32 default: Int32Zero}
	with: otherTranscluders {FeEdition default: NULL}
	"All Editions which the CurrentKeyMaster can see, which transclude this RangeElement.
	If a directFilter is given, then the visibleEndorsements on a Edition must match the filter.
	If an indirectFilter is given, then a resulting Edition must be contained in some readable Edition whose visibleEndorsements match the filter.
	If the directContainersOnly flag is set, then a resulting Edition must contain this directly as a RangeElement; otherwise, indirect containment through Editions is allowed.
	If the localPresentOnly flag is set, then only Editions currently known to this Server are guaranteed to end up in the result; otherwise, Editions which come to satisfy the conditions in the future, and those on other Servers, may also be found.
	Equivalent to
		FeServer::current ()->newEditionWith (<any position>, this)
			->rangeTranscluders (NULL, directFilter, indirectFilter, flags, otherTranscluders)."
	
	^(FeEdition fromOne: IntegerVarZero integer with: self)
		rangeTranscluders: NULL with: directFilter with: indirectFilter with: flags with: otherTranscluders!
*/
}

/**
 * Essential.  Works which contain this RangeElement and can be read by the CurrentKeyMaster.
 * Returns an IDSpace Edition full of PlaceHolders, which will be filled with Works as
 * results come in.
 * If a filter is given, then only Works whose endorsements pass the Filter are returned.
 * If localPresentOnly flag is set, then only Works currently known to this Server are
 * returned; otherwise, as new Works come to be known to the Server, they are filled into the
 * resulting Edition.
 * If directContainersOnly is set, and this is an Edition, then only Works which are directly
 * on this Edition are returned (and not Works which are on Editions which have this one as
 * sub-Editions).
 * { <k,l,w> | w's contains self, w passes filter}
 */
public FeEdition works(Filter filter, int flags, FeEdition otherTranscluders) {
throw new UnsupportedOperationException();/*
udanax-top.st:20363:FeRangeElement methodsFor: 'accessing'!
{FeEdition CLIENT} works: filter {Filter default: NULL}
	with: flags {Int32 default: Int32Zero}
	with: otherTranscluders {FeEdition default: NULL}
	"Essential.  Works which contain this RangeElement and can be read by the CurrentKeyMaster. Returns an IDSpace Edition full of PlaceHolders, which will be filled with Works as results come in.
	If a filter is given, then only Works whose endorsements pass the Filter are returned.
	If localPresentOnly flag is set, then only Works currently known to this Server are returned; otherwise, as new Works come to be known to the Server, they are filled into the resulting Edition.
	If directContainersOnly is set, and this is an Edition, then only Works which are directly on this Edition are returned (and not Works which are on Editions which have this one as sub-Editions).
	{ <k,l,w> | w's contains self, w passes filter}"
	
	| theFilter {Filter} |
	filter == NULL
		ifTrue: [theFilter := CurrentGrandMap fluidGet endorsementFilterSpace fullRegion cast: Filter]
		ifFalse: [theFilter := filter].
	Dean thingToDo. "avoid reifying"
	^FeEdition on: (self getOrMakeBe
		works: CurrentKeyMaster fluidGet actualAuthority
		with: theFilter
		with: flags)!
*/
}

/**
 * Return an object that wraps up any run-time state that might be needed inside the Be
 * system.  Right now that means labels.
 */
public BeCarrier carrier() {
throw new UnsupportedOperationException();/*
udanax-top.st:20384:FeRangeElement methodsFor: 'server accessing'!
{BeCarrier} carrier
	"Return an object that wraps up any run-time state that might be needed inside the Be system.  Right now that means labels."
	
	^BeCarrier make: self getOrMakeBe!
*/
}

/**
 * If this has a reified Be object, then return it, else NULL
 */
public BeRangeElement fetchBe() {
throw new UnsupportedOperationException();/*
udanax-top.st:20389:FeRangeElement methodsFor: 'server accessing'!
{BeRangeElement | NULL} fetchBe
	"If this has a reified Be object, then return it, else NULL"
	
	self subclassResponsibility!
*/
}

/**
 * An individual BeRangeElement for this identity. If the object is virtualized, then
 * de-virtualizes it.
 */
public BeRangeElement getOrMakeBe() {
throw new UnsupportedOperationException();/*
udanax-top.st:20394:FeRangeElement methodsFor: 'server accessing'!
{BeRangeElement} getOrMakeBe
	"An individual BeRangeElement for this identity. If the object is virtualized, then de-virtualizes it."
	
	self subclassResponsibility!
*/
}

/**
 * Sensor leftShiftDown
 */
public void inspect() {
throw new UnsupportedOperationException();/*
udanax-top.st:20401:FeRangeElement methodsFor: 'smalltalk:'!
inspect
	"Sensor leftShiftDown" true
		ifTrue: [self basicInspect]
		ifFalse: [EntView openOn: (TreeBarnacle new
					buildOn: self
					gettingChildren: [:elem | (elem respondsTo: #inspectPieces)
							ifTrue: [elem inspectPieces]
							ifFalse: [#()]]
					gettingImage: [:me | DisplayText text: me displayString asText textStyle: (TextStyle styleNamed: #small)]
					at: 0 @ 0
					vertical: true
					separation: 5 @ 10)]!
*/
}

public FeEdition transcluders() {
throw new UnsupportedOperationException();/*
udanax-top.st:20414:FeRangeElement methodsFor: 'smalltalk:'!
{FeEdition CLIENT} transcluders
	^self transcluders: NULL with: NULL with: Int32Zero with: NULL!
*/
}

public FeEdition transcluders(Filter directFilter) {
throw new UnsupportedOperationException();/*
udanax-top.st:20417:FeRangeElement methodsFor: 'smalltalk:'!
{FeEdition CLIENT} transcluders: directFilter {Filter default: NULL}
	
	^self transcluders: directFilter with: NULL with: Int32Zero with: NULL!
*/
}

public FeEdition transcluders(Filter directFilter, Filter indirectFilter) {
throw new UnsupportedOperationException();/*
udanax-top.st:20421:FeRangeElement methodsFor: 'smalltalk:'!
{FeEdition CLIENT} transcluders: directFilter {Filter default: NULL}
	with: indirectFilter {Filter default: NULL}
	
	^self transcluders: directFilter with: indirectFilter with: Int32Zero with: NULL!
*/
}

public FeEdition transcluders(Filter directFilter, Filter indirectFilter, int flags) {
throw new UnsupportedOperationException();/*
udanax-top.st:20426:FeRangeElement methodsFor: 'smalltalk:'!
{FeEdition CLIENT} transcluders: directFilter {Filter default: NULL}
	with: indirectFilter {Filter default: NULL}
	with: flags {Int32 default: Int32Zero}
	
	^self transcluders: directFilter with: indirectFilter with: flags with: NULL!
*/
}

/**
 * Essential. Return the label attached to this FeRangeElement. (An FeRangeElement holds a
 * BeRangeElement and a label.)  All FeRangeElements have a label attached to them when they
 * are created (in the various Server::newRangeElement operations).  Derived Editions have
 * the same the label as the Edition they were derived from (e.g. the receiver of copy,
 * combine, replace, transformedBy, etc.)  Labels may be available only on Editions in 1.0.
 * (While this is in force, label() will blast if sent to other kinds of FeEditions.)
 */
public FeLabel label() {
throw new UnsupportedOperationException();/*
udanax-top.st:20434:FeRangeElement methodsFor: 'labelling'!
{FeLabel CLIENT} label
	"Essential. Return the label attached to this FeRangeElement. (An FeRangeElement holds a BeRangeElement and a label.)  All FeRangeElements have a label attached to them when they are created (in the various Server::newRangeElement operations).  Derived Editions have the same the label as the Edition they were derived from (e.g. the receiver of copy, combine, replace, transformedBy, etc.)  Labels may be available only on Editions in 1.0.  (While this is in force, label() will blast if sent to other kinds of FeEditions.)"
	
	self unimplemented. "default"
	^NULL!
*/
}

/**
 * Essential. Return a new FeRangeElement with the same identity and contents (i.e. holding
 * the same BeRangeElement), but with a different label.  (Get new labels from
 * FeServer::newLabel())
 */
public FeRangeElement relabelled(FeLabel label) {
throw new UnsupportedOperationException();/*
udanax-top.st:20440:FeRangeElement methodsFor: 'labelling'!
{FeRangeElement CLIENT} relabelled: label {FeLabel}
	"Essential. Return a new FeRangeElement with the same identity and contents (i.e. holding the same BeRangeElement), but with a different label.  (Get new labels from FeServer::newLabel())"
	
	self unimplemented. "default"
	^NULL!
*/
}

public boolean becomeOther(FeRangeElement newIdentity) {
throw new UnsupportedOperationException();/*
udanax-top.st:20448:FeRangeElement methodsFor: 'smalltalk: passe'!
{BooleanVar} becomeOther: newIdentity {FeRangeElement}
	self passe.	"renamed makeIdentical:"!
*/
}

public boolean isSameAs(FeRangeElement other) {
throw new UnsupportedOperationException();/*
udanax-top.st:20452:FeRangeElement methodsFor: 'smalltalk: passe'!
{BooleanVar} isSameAs: other {FeRangeElement}
	self passe "isIdentical"!
*/
}

public int actualHashForEqual() {
throw new UnsupportedOperationException();/*
udanax-top.st:20458:FeRangeElement methodsFor: 'generated:'!
actualHashForEqual ^self asOop!
*/
}

public boolean isEqual(Object other) {
throw new UnsupportedOperationException();/*
udanax-top.st:20460:FeRangeElement methodsFor: 'generated:'!
isEqual: other ^self == other!
*/
}

/**
 * Check whether the endorsements are valid and authorized.
 * Blast appropriately if not.
 */
public static void validateEndorsement(CrossRegion endorsements, FeKeyMaster km) {
throw new UnsupportedOperationException();/*
udanax-top.st:20471:FeRangeElement class methodsFor: 'protected:'!
{void} validateEndorsement: endorsements {CrossRegion} with: km {FeKeyMaster} 
	"Check whether the endorsements are valid and authorized.
	 Blast appropriately if not."
	endorsements isFinite ifFalse: [Heaper BLAST: #EndorsementMustBeFinite].
	self validateSignature: ((endorsements projection: Int32Zero) cast: IDRegion)
		with: km!
*/
}

/**
 * Check whether the signatures are valid and authorized.
 * Blast appropriately if not.
 */
public static void validateSignature(IDRegion clubs, FeKeyMaster km) {
throw new UnsupportedOperationException();/*
udanax-top.st:20479:FeRangeElement class methodsFor: 'protected:'!
{void} validateSignature: clubs {IDRegion} with: km {FeKeyMaster} 
	"Check whether the signatures are valid and authorized.
	 Blast appropriately if not."
	clubs isFinite ifFalse: [Heaper BLAST: #MustHaveSignatureAuthority].
	clubs stepper forEach: [ :clubID {ID} |
		(km hasSignatureAuthority: clubID)
			ifFalse: [Heaper BLAST: #MustHaveSignatureAuthority]]!
*/
}

/**
 * {void CLIENT} addFillDetector: detector {PrFillDetector}
 * {FeRangeElement CLIENT} again
 * {BooleanVar CLIENT} canMakeIdentical: newIdentity {FeRangeElement}
 * {BooleanVar CLIENT} isIdentical: other {FeRangeElement}
 * {FeLabel CLIENT} label
 * {void CLIENT} makeIdentical: newIdentity {FeRangeElement}
 * {ID CLIENT} owner
 * {FeRangeElement CLIENT} relabelled: label {FeLabel}
 * {void CLIENT} removeFillDetector: detector {PrFillDetector}
 * {void CLIENT} setOwner: clubID {ID}
 * {FeEdition CLIENT} transcluders
 * {FeEdition CLIENT} transcluders: directFilter {Filter default: NULL}
 * {FeEdition CLIENT} transcluders: directFilter {Filter default: NULL} with: indirectFilter
 * {Filter default: NULL}
 * {FeEdition CLIENT} transcluders: directFilter {Filter default: NULL} with: indirectFilter
 * {Filter default: NULL} with: flags {Int32 default: Int32Zero}
 * {FeEdition CLIENT} transcluders: directFilter {Filter default: NULL} with: indirectFilter
 * {Filter default: NULL} with: flags {Int32 default: Int32Zero} with: otherTrail {FeEdition
 * default: NULL}
 * {FeEdition CLIENT} works: filter {Filter default: NULL} with: flags {Int32 default:
 * Int32Zero} with: otherTrail {FeEdition default: NULL}
 */
public static void info() {
throw new UnsupportedOperationException();/*
udanax-top.st:20490:FeRangeElement class methodsFor: 'smalltalk: system'!
info.stProtocol
"{void CLIENT} addFillDetector: detector {PrFillDetector}
{FeRangeElement CLIENT} again
{BooleanVar CLIENT} canMakeIdentical: newIdentity {FeRangeElement}
{BooleanVar CLIENT} isIdentical: other {FeRangeElement}
{FeLabel CLIENT} label
{void CLIENT} makeIdentical: newIdentity {FeRangeElement}
{ID CLIENT} owner
{FeRangeElement CLIENT} relabelled: label {FeLabel}
{void CLIENT} removeFillDetector: detector {PrFillDetector}
{void CLIENT} setOwner: clubID {ID}
{FeEdition CLIENT} transcluders
{FeEdition CLIENT} transcluders: directFilter {Filter default: NULL}
{FeEdition CLIENT} transcluders: directFilter {Filter default: NULL} with: indirectFilter {Filter default: NULL}
{FeEdition CLIENT} transcluders: directFilter {Filter default: NULL} with: indirectFilter {Filter default: NULL} with: flags {Int32 default: Int32Zero}
{FeEdition CLIENT} transcluders: directFilter {Filter default: NULL} with: indirectFilter {Filter default: NULL} with: flags {Int32 default: Int32Zero} with: otherTrail {FeEdition default: NULL}
{FeEdition CLIENT} works: filter {Filter default: NULL} with: flags {Int32 default: Int32Zero} with: otherTrail {FeEdition default: NULL}
"!
*/
}

/**
 * Make a single PlaceHolder.
 */
public static FeRangeElement placeHolder() {
throw new UnsupportedOperationException();/*
udanax-top.st:20511:FeRangeElement class methodsFor: 'creation'!
{FeRangeElement CLIENT} placeHolder
	"Make a single PlaceHolder."
	
	^FePlaceHolder on: CurrentGrandMap fluidGet newPlaceHolder!
*/
}
}
