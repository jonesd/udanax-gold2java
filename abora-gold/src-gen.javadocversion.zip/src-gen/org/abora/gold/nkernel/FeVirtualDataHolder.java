/*
 * Abora-Gold
 * Part of the Abora hypertext project: http://www.abora.org
 * Copyright 2003 David G Jones
 * 
 * Translated from Udanax-Gold source code: http://www.udanax.com
 * Copyright 1979-1999 Udanax.com. All rights reserved
 */
package org.abora.gold.nkernel;

import org.abora.gold.be.basic.BeEdition;
import org.abora.gold.be.basic.BeRangeElement;
import org.abora.gold.be.basic.ID;
import org.abora.gold.nkernel.FeDataHolder;
import org.abora.gold.nkernel.FeRangeElement;
import org.abora.gold.spaces.basic.Position;
import org.abora.gold.x.PrimValue;


/**
 * Fakes a DataHolder by having an Edition and a key.
 */
public class FeVirtualDataHolder extends FeDataHolder {
	protected PrimValue myValue;
	protected Position myKey;
	protected BeEdition myEdition;
/*
udanax-top.st:20654:
FeDataHolder subclass: #FeVirtualDataHolder
	instanceVariableNames: '
		myValue {PrimValue}
		myKey {Position}
		myEdition {BeEdition}'
	classVariableNames: ''
	poolDictionaries: ''
	category: 'Xanadu-nkernel'!
*/
/*
udanax-top.st:20661:
FeVirtualDataHolder comment:
'Fakes a DataHolder by having an Edition and a key.'!
*/
/*
udanax-top.st:20663:
(FeVirtualDataHolder getOrMakeCxxClassDescription)
	attributes: ((Set new) add: #CONCRETE; add: #NOT.A.TYPE; yourself)!
*/

/**
 * Fetch from my Edition again, just in case I've been consolidated.
 */
public FeRangeElement again() {
throw new UnsupportedOperationException();/*
udanax-top.st:20668:FeVirtualDataHolder methodsFor: 'accessing'!
{FeRangeElement} again
	"Fetch from my Edition again, just in case I've been consolidated."
	
	^myEdition fetch: myKey!
*/
}

/**
 * This can do a version comparison (which seems a bit extreme).
 */
public boolean isIdentical(FeRangeElement other) {
throw new UnsupportedOperationException();/*
udanax-top.st:20673:FeVirtualDataHolder methodsFor: 'accessing'!
{BooleanVar} isIdentical: other {FeRangeElement}
	"This can do a version comparison (which seems a bit extreme)."
	Dean shouldImplement.
	^false "fodder"!
*/
}

public ID owner() {
throw new UnsupportedOperationException();/*
udanax-top.st:20679:FeVirtualDataHolder methodsFor: 'accessing'!
{ID} owner
	^myEdition ownerAt: myKey!
*/
}

public PrimValue value() {
throw new UnsupportedOperationException();/*
udanax-top.st:20683:FeVirtualDataHolder methodsFor: 'accessing'!
{PrimValue} value
	^myValue!
*/
}

public BeRangeElement fetchBe() {
throw new UnsupportedOperationException();/*
udanax-top.st:20688:FeVirtualDataHolder methodsFor: 'server accessing'!
{BeRangeElement | NULL} fetchBe
	^NULL!
*/
}

/**
 * Force the ent to generate a beRangeElement at myKey.
 */
public BeRangeElement getOrMakeBe() {
throw new UnsupportedOperationException();/*
udanax-top.st:20692:FeVirtualDataHolder methodsFor: 'server accessing'!
{BeRangeElement} getOrMakeBe
	"Force the ent to generate a beRangeElement at myKey."
	
	^myEdition getOrMakeBe: myKey!
*/
}

public  FeVirtualDataHolder(PrimValue value, Position key, BeEdition edition) {
throw new UnsupportedOperationException();/*
udanax-top.st:20699:FeVirtualDataHolder methodsFor: 'private: create'!
create: value {PrimValue}
	with: key {Position}
	with: edition {BeEdition}
	
	super create.
	myValue := value.
	myKey := key.
	myEdition := edition.!
*/
}
}
