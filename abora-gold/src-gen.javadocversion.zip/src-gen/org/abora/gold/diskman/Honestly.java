/*
 * Abora-Gold
 * Part of the Abora hypertext project: http://www.abora.org
 * Copyright 2003 David G Jones
 * 
 * Translated from Udanax-Gold source code: http://www.udanax.com
 * Copyright 1979-1999 Udanax.com. All rights reserved
 */
package org.abora.gold.diskman;

import org.abora.gold.fm.support.Thunk;
import org.abora.gold.java.missing.IntegerVar;
import org.abora.gold.xcvr.Rcvr;
import org.abora.gold.xcvr.Xmtr;
import org.abora.gold.xpp.basic.Category;


public class Honestly extends Thunk {
	protected Category myCategory;
	protected boolean blastOnError;
	protected IntegerVar persistInterval;
/*
udanax-top.st:57382:
Thunk subclass: #Honestly
	instanceVariableNames: '
		myCategory {Category}
		blastOnError {BooleanVar}
		persistInterval {IntegerVar}'
	classVariableNames: ''
	poolDictionaries: ''
	category: 'Xanadu-diskman'!
*/
/*
udanax-top.st:57389:
(Honestly getOrMakeCxxClassDescription)
	attributes: ((Set new) add: #CONCRETE; add: #(COPY boot ); add: #NOT.A.TYPE; yourself)!
*/

public void execute() {
throw new UnsupportedOperationException();/*
udanax-top.st:57394:Honestly methodsFor: 'running'!
{void} execute
	CurrentPacker fluidFetch == NULL ifTrue:
		[TestPacker make: blastOnError with: persistInterval.
		Turtle make: NULL with: myCategory with: ProtocolBroker diskProtocol].
	CurrentGrandMap fluidSet: HonestAbeIniter fetchGrandMap.!
*/
}

public  Honestly(Rcvr receiver) {
throw new UnsupportedOperationException();/*
udanax-top.st:57402:Honestly methodsFor: 'generated:'!
create.Rcvr: receiver {Rcvr}
	super create.Rcvr: receiver.
	myCategory _ receiver receiveHeaper.
	blastOnError _ receiver receiveBooleanVar.
	persistInterval _ receiver receiveIntegerVar.!
*/
}

public void sendSelfTo(Xmtr xmtr) {
throw new UnsupportedOperationException();/*
udanax-top.st:57408:Honestly methodsFor: 'generated:'!
{void} sendSelfTo: xmtr {Xmtr}
	super sendSelfTo: xmtr.
	xmtr sendHeaper: myCategory.
	xmtr sendBooleanVar: blastOnError.
	xmtr sendIntegerVar: persistInterval.!
*/
}
}
