/*
 * Abora-Gold
 * Part of the Abora hypertext project: http://www.abora.org
 * Copyright 2003 David G Jones
 * 
 * Translated from Udanax-Gold source code: http://www.udanax.com
 * Copyright 1979-1999 Udanax.com. All rights reserved
 */
package org.abora.gold.diskman;

import java.io.PrintWriter;
import org.abora.gold.counter.Counter;
import org.abora.gold.testing.Tester;
import org.abora.gold.xcvr.Rcvr;
import org.abora.gold.xcvr.Xmtr;


public class DiskTester extends Tester {
	protected Counter myBootCounter;
/*
udanax-top.st:58208:
Tester subclass: #DiskTester
	instanceVariableNames: 'myBootCounter {Counter NOCOPY}'
	classVariableNames: ''
	poolDictionaries: ''
	category: 'Xanadu-diskman'!
*/
/*
udanax-top.st:58212:
(DiskTester getOrMakeCxxClassDescription)
	attributes: ((Set new) add: #CONCRETE; add: #(COPY boot ); yourself)!
*/

/**
 * self runTest: #destroyTest:
 */
public void destroyTest(PrintWriter oo) {
throw new UnsupportedOperationException();/*
udanax-top.st:58217:DiskTester methodsFor: 'tests'!
{void} destroyTest: oo {ostream reference unused} 
	"self runTest: #destroyTest:"
	| table {MuTable} |
	table _ MuTable make: IntegerSpace make.
	1 to: 100 do: [:i {Int32} |
		| shep {Abraham} |
		table atInt: i introduce: (DoublingFlock make: i with: i).
		shep _ (table intFetch: i // 2) cast: Abraham.
		shep ~~ NULL ifTrue:
			[shep destroy.
			table intWipe: i // 2].
		self unimplemented.
		"CurrentPacker fluidVar makeConsistent."
		i \\ 20 == Int32Zero ifTrue: [(CurrentPacker fluidGet cast: SnarfPacker) makePersistent]].
	CurrentPacker fluidGet purge!
*/
}

/**
 * self runTest: #forward1Test:
 */
public void forward1Test(PrintWriter oo) {
throw new UnsupportedOperationException();/*
udanax-top.st:58234:DiskTester methodsFor: 'tests'!
{void} forward1Test:  oo {ostream reference} 
	"self runTest: #forward1Test:"
	| a {DoublingFlock} b {DoublingFlock} packer {SnarfPacker} |
	a _ DoublingFlock make: 1.
	b _ DoublingFlock make: 2.
	packer _ CurrentPacker fluidGet cast: SnarfPacker.
	oo << 'Flock a is ' << a << ' at ' << a getInfo <<'
Flock b is ' << b << ' at ' << b getInfo <<'
'.	packer makePersistent.
	[a getInfo snarfID == b getInfo snarfID] whileTrue:
		[a doDouble.
		b doDouble.
		oo << 'doubled to ' << a count << '
'.		"a count >= 512 ifTrue: [self halt]."
		packer makePersistent].!
*/
}

/**
 * self runTest: #forward2Test:
 */
public void forward2Test(PrintWriter oo) {
throw new UnsupportedOperationException();/*
udanax-top.st:58251:DiskTester methodsFor: 'tests'!
{void} forward2Test:  oo {ostream reference} 
	"self runTest: #forward2Test:"
	| pair {PairFlock} packer {SnarfPacker} |
	pair _ PairFlock create: (DoublingFlock make: 1) with: (DoublingFlock make: 2).
	packer _ CurrentPacker fluidGet cast: SnarfPacker.
	oo << 'Flock a is ' << pair left << ' at ' << pair left getInfo <<'
Flock b is ' << pair right << ' at ' << pair right getInfo <<'
'.	packer makePersistent.
	[pair left getInfo snarfID == pair right getInfo snarfID] whileTrue:
		[(pair left cast: DoublingFlock) doDouble.
		(pair right cast: DoublingFlock) doDouble.
		oo << 'doubled to ' << (pair left cast: DoublingFlock) count << '
'.		"pair left count >= 512 ifTrue: [self halt]."
		packer purge].!
*/
}

/**
 * self runTest: #toDiskAndBackTestOn:
 */
public void toDiskAndBackTestOn(PrintWriter aStream) {
throw new UnsupportedOperationException();/*
udanax-top.st:58267:DiskTester methodsFor: 'tests'!
{void} toDiskAndBackTestOn:  aStream {ostream reference} 
	"self runTest: #toDiskAndBackTestOn:"
	"test writing to disk and reading back"
	| firstCounter {MultiCounter} secondCounter {MultiCounter} |
	aStream << '
Test ability to write an object to disk and read it back
'.
	firstCounter _ MultiCounter make: 5.
	firstCounter incrementBoth.
	secondCounter _ MultiCounter make.
	secondCounter incrementFirst; incrementFirst; incrementBoth.
	aStream << '
First MultiCounter = ' << firstCounter.
	aStream << '
Second MultiCounter = ' << secondCounter.
	aStream << '
Purging.'.
	CurrentPacker fluidGet purge.
	aStream << '
Bringing First MultiCounter back; value = ' << firstCounter.
	firstCounter decrementBoth; decrementSecond.
	aStream << '
First MultiCounter = ' << firstCounter.
	
	aStream << '
Bringing Second MultiCounter back and incrementing.'.
	secondCounter incrementSecond; incrementSecond; incrementBoth.
	aStream << '
Second MultiCounter = ' << secondCounter.
	aStream << '
Purging again.'.
	CurrentPacker fluidGet purge.
	aStream << '
Bringing First MultiCounter back; value = ' << firstCounter.
	firstCounter decrementBoth; decrementSecond.
	aStream << '
First MultiCounter = ' << firstCounter.
	
	aStream << '
Bringing Second MultiCounter back and incrementing.'.
	secondCounter incrementSecond; incrementSecond; incrementBoth.
	aStream << '
Second MultiCounter = ' << secondCounter.!
*/
}

/**
 * DiskTester runTest
 */
public void allTestsOn(PrintWriter oo) {
throw new UnsupportedOperationException();/*
udanax-top.st:58324:DiskTester methodsFor: 'running tests'!
{void} allTestsOn: oo {ostream reference}
	"DiskTester runTest"
	
	| conn {Connection} |
	conn _ Connection make: Counter.
	myBootCounter _ conn bootHeaper cast: Counter.
	self destroyTest: oo.
	self toDiskAndBackTestOn: oo.
	self forward1Test: oo.
	self forward2Test: oo.
	conn destroy!
*/
}

public void restartDiskTester(Rcvr rcvr) {
throw new UnsupportedOperationException();/*
udanax-top.st:58338:DiskTester methodsFor: 'hooks:'!
{void RECEIVE.HOOK} restartDiskTester: rcvr {Rcvr unused default: NULL}
	myBootCounter _ NULL!
*/
}

public  DiskTester(Rcvr receiver) {
throw new UnsupportedOperationException();/*
udanax-top.st:58343:DiskTester methodsFor: 'generated:'!
create.Rcvr: receiver {Rcvr}
	super create.Rcvr: receiver.
	self restartDiskTester: receiver.!
*/
}

public void sendSelfTo(Xmtr xmtr) {
throw new UnsupportedOperationException();/*
udanax-top.st:58347:DiskTester methodsFor: 'generated:'!
{void} sendSelfTo: xmtr {Xmtr}
	super sendSelfTo: xmtr.!
*/
}
}
