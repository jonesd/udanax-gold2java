/*
 * Abora-Gold
 * Part of the Abora hypertext project: http://www.abora.org
 * Copyright 2003 David G Jones
 * 
 * Translated from Udanax-Gold source code: http://www.udanax.com
 * Copyright 1979-1999 Udanax.com. All rights reserved
 */
package org.abora.gold.diskman;

import org.abora.gold.be.basic.BeGrandMap;
import org.abora.gold.cobbler.Connection;
import org.abora.gold.fm.support.Thunk;
import org.abora.gold.java.missing.IntegerVar;
import org.abora.gold.xcvr.Rcvr;
import org.abora.gold.xcvr.Xmtr;
import org.abora.gold.xpp.basic.Category;


public class HonestAbeIniter extends Thunk {
	protected Category myCategory;
	protected boolean blastOnError;
	protected IntegerVar persistInterval;
	protected static Connection TheHonestConnection;
	protected static BeGrandMap TheHonestGrandMap;
/*
udanax-top.st:57316:
Thunk subclass: #HonestAbeIniter
	instanceVariableNames: '
		myCategory {Category}
		blastOnError {BooleanVar}
		persistInterval {IntegerVar}'
	classVariableNames: '
		TheHonestConnection {Connection} 
		TheHonestGrandMap {BeGrandMap} '
	poolDictionaries: ''
	category: 'Xanadu-diskman'!
*/
/*
udanax-top.st:57325:
(HonestAbeIniter getOrMakeCxxClassDescription)
	attributes: ((Set new) add: #CONCRETE; add: #(COPY boot ); add: #NOT.A.TYPE; yourself)!
*/
/*
udanax-top.st:57362:
HonestAbeIniter class
	instanceVariableNames: ''!
*/
/*
udanax-top.st:57365:
(HonestAbeIniter getOrMakeCxxClassDescription)
	attributes: ((Set new) add: #CONCRETE; add: #(COPY boot ); add: #NOT.A.TYPE; yourself)!
*/

public void execute() {
throw new UnsupportedOperationException();/*
udanax-top.st:57330:HonestAbeIniter methodsFor: 'running'!
{void} execute
	| cookbook {Cookbook} turtle {Turtle} conn {Connection} |
	TestPacker make: blastOnError with: persistInterval.
	cookbook := Cookbook make.Category: myCategory.
	turtle := Turtle make: cookbook with: myCategory with: ProtocolBroker diskProtocol.
	conn := Connection make: myCategory.
	TheHonestConnection _ conn.
	turtle saveBootHeaper: conn bootHeaper.
	"The following is here so that later thunks can get the GrandMap &c"
	"[WorksBootMaker] USES.
	GrandConnection fluidSet: TheHonestConnection.�"
	TheHonestGrandMap _ conn bootHeaper cast: BeGrandMap.
	CurrentPacker fluidGet purge.
	"CurrentPacker fluidSet: NULL.
"!
*/
}

public  HonestAbeIniter(Rcvr receiver) {
throw new UnsupportedOperationException();/*
udanax-top.st:57349:HonestAbeIniter methodsFor: 'generated:'!
create.Rcvr: receiver {Rcvr}
	super create.Rcvr: receiver.
	myCategory _ receiver receiveHeaper.
	blastOnError _ receiver receiveBooleanVar.
	persistInterval _ receiver receiveIntegerVar.!
*/
}

public void sendSelfTo(Xmtr xmtr) {
throw new UnsupportedOperationException();/*
udanax-top.st:57355:HonestAbeIniter methodsFor: 'generated:'!
{void} sendSelfTo: xmtr {Xmtr}
	super sendSelfTo: xmtr.
	xmtr sendHeaper: myCategory.
	xmtr sendBooleanVar: blastOnError.
	xmtr sendIntegerVar: persistInterval.!
*/
}

public static BeGrandMap fetchGrandMap() {
throw new UnsupportedOperationException();/*
udanax-top.st:57370:HonestAbeIniter class methodsFor: 'accessing'!
{BeGrandMap} fetchGrandMap
	^ TheHonestGrandMap!
*/
}

public static void exitTimeNonInherited() {
throw new UnsupportedOperationException();/*
udanax-top.st:57375:HonestAbeIniter class methodsFor: 'smalltalk: init'!
exitTimeNonInherited
	TheHonestConnection _ NULL!
*/
}

public static void linkTimeNonInherited() {
throw new UnsupportedOperationException();/*
udanax-top.st:57378:HonestAbeIniter class methodsFor: 'smalltalk: init'!
linkTimeNonInherited
	TheHonestConnection _ NULL.
	TheHonestGrandMap _ NULL.!
*/
}
}
