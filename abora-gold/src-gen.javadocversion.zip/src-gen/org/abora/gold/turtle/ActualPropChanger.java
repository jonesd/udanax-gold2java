/*
 * Abora-Gold
 * Part of the Abora hypertext project: http://www.abora.org
 * Copyright 2003 David G Jones
 * 
 * Translated from Udanax-Gold source code: http://www.udanax.com
 * Copyright 1979-1999 Udanax.com. All rights reserved
 */
package org.abora.gold.turtle;

import org.abora.gold.be.canopy.CanopyCrum;
import org.abora.gold.snarf.FlockInfo;
import org.abora.gold.turtle.PropChanger;
import org.abora.gold.xcvr.Rcvr;
import org.abora.gold.xcvr.Xmtr;


/**
 * Used to propagate some prop(erty) change rootwards in some canopy.  Each step propagates
 * it one step parentwards, until it gets to a local root or no further propagation in
 * necessary.
 */
public class ActualPropChanger extends PropChanger {
/*
udanax-top.st:867:
PropChanger subclass: #ActualPropChanger
	instanceVariableNames: ''
	classVariableNames: ''
	poolDictionaries: ''
	category: 'Xanadu-turtle'!
*/
/*
udanax-top.st:871:
ActualPropChanger comment:
'Used to propagate some prop(erty) change rootwards in some canopy.  Each step propagates it one step parentwards, until it gets to a local root or no further propagation in necessary.'!
*/
/*
udanax-top.st:873:
(ActualPropChanger getOrMakeCxxClassDescription)
	attributes: ((Set new) add: #CONCRETE; add: #LOCKED; add: #COPY; yourself)!
*/

public  ActualPropChanger(CanopyCrum crum) {
	super(crum);
throw new UnsupportedOperationException();/*
udanax-top.st:878:ActualPropChanger methodsFor: 'creation'!
create: crum {CanopyCrum}
	super create: crum.
	self newShepherd.!
*/
}

/**
 * Special constructor for becoming this class
 */
public  ActualPropChanger(CanopyCrum crum, int hash, FlockInfo info) {
	super(crum, hash);
throw new UnsupportedOperationException();/*
udanax-top.st:883:ActualPropChanger methodsFor: 'creation'!
create: crum {CanopyCrum | NULL} with: hash {UInt32} with: info {FlockInfo}
	"Special constructor for becoming this class"
	super create: crum with: hash.
	self flockInfo: info.
	self diskUpdate.!
*/
}

public boolean step() {
throw new UnsupportedOperationException();/*
udanax-top.st:892:ActualPropChanger methodsFor: 'accessing'!
{BooleanVar} step
	| |
	"If I'm done
		Stop me before I step again!!.
	atomically
		Do one step of property changing.
			If more needs to be done, step rootward.  (myCrum is set to NULL if I am the root.)
			else I'm done.  Remember it by setting myCrum to NULL
	return a flag saying whether I'm done"
	self fetchCrum == NULL
		ifTrue: [^false].
	DiskManager consistent: 3 with:
		[(self fetchCrum changeCanopy)
			ifTrue: [self setCrum: self fetchCrum fetchParent]
			ifFalse: [self setCrum: NULL]].
	^self fetchCrum ~~ NULL!
*/
}

public  ActualPropChanger(Rcvr receiver) {
	super(receiver);
throw new UnsupportedOperationException();/*
udanax-top.st:912:ActualPropChanger methodsFor: 'generated:'!
create.Rcvr: receiver {Rcvr}
	super create.Rcvr: receiver.!
*/
}

public void sendSelfTo(Xmtr xmtr) {
throw new UnsupportedOperationException();/*
udanax-top.st:915:ActualPropChanger methodsFor: 'generated:'!
{void} sendSelfTo: xmtr {Xmtr}
	super sendSelfTo: xmtr.!
*/
}
}
