/*
 * Abora-Gold
 * Part of the Abora hypertext project: http://www.abora.org
 * Copyright 2003 David G Jones
 * 
 * Translated from Udanax-Gold source code: http://www.udanax.com
 * Copyright 1979-1999 Udanax.com. All rights reserved
 */
package org.abora.gold.turtle;

import org.abora.gold.be.canopy.CanopyCrum;
import org.abora.gold.props.PropChange;
import org.abora.gold.snarf.FlockInfo;
import org.abora.gold.turtle.PropChanger;
import org.abora.gold.xcvr.Rcvr;
import org.abora.gold.xcvr.Xmtr;
import org.abora.gold.xpp.basic.Heaper;


/**
 * Used to propagate some prop(erty) change rootwards in some canopy.  Each step propagates
 * it one step parentwards, until it gets to a local root or no further propagation in
 * necessary.
 */
public class HeightChanger extends PropChanger {
	protected PropChange myChange;
/*
udanax-top.st:918:
PropChanger subclass: #HeightChanger
	instanceVariableNames: 'myChange {PropChange}'
	classVariableNames: ''
	poolDictionaries: ''
	category: 'Xanadu-turtle'!
*/
/*
udanax-top.st:922:
HeightChanger comment:
'Used to propagate some prop(erty) change rootwards in some canopy.  Each step propagates it one step parentwards, until it gets to a local root or no further propagation in necessary.'!
*/
/*
udanax-top.st:924:
(HeightChanger getOrMakeCxxClassDescription)
	attributes: ((Set new) add: #CONCRETE; add: #LOCKED; add: #COPY; yourself)!
*/
/*
udanax-top.st:972:
HeightChanger class
	instanceVariableNames: ''!
*/
/*
udanax-top.st:975:
(HeightChanger getOrMakeCxxClassDescription)
	attributes: ((Set new) add: #CONCRETE; add: #LOCKED; add: #COPY; yourself)!
*/

public  HeightChanger(CanopyCrum crum) {
	super(crum);
throw new UnsupportedOperationException();/*
udanax-top.st:929:HeightChanger methodsFor: 'creation'!
create: crum {CanopyCrum}
	super create: crum.
	self newShepherd.!
*/
}

/**
 * Special constructor for becoming this class
 */
public  HeightChanger(CanopyCrum crum, int hash, FlockInfo info) {
	super(crum, hash);
throw new UnsupportedOperationException();/*
udanax-top.st:934:HeightChanger methodsFor: 'creation'!
create: crum {CanopyCrum | NULL} with: hash {UInt32} with: info {FlockInfo}
	"Special constructor for becoming this class"
	super create: crum with: hash.
	self flockInfo: info.
	self diskUpdate.!
*/
}

public boolean step() {
throw new UnsupportedOperationException();/*
udanax-top.st:943:HeightChanger methodsFor: 'accessing'!
{BooleanVar} step
	| |
	"If I'm done
		Stop me before I step again!!.
	atomically
		Do one step of height recalculation.
			If more needs to be done, step rootward.  (myCrum is set to NULL if I am the root.)
			else I'm done.  Remember it by setting myCrum to NULL
	return a flag saying whether I'm done"
	
	self fetchCrum == NULL
		ifTrue: [^false].
	DiskManager consistent: 3 with:
		[self fetchCrum changeHeight
			ifTrue: [self setCrum: self fetchCrum fetchParent]
			ifFalse: [self setCrum: NULL]].
	^self fetchCrum ~~ NULL!
*/
}

public  HeightChanger(Rcvr receiver) {
	super(receiver);
throw new UnsupportedOperationException();/*
udanax-top.st:963:HeightChanger methodsFor: 'generated:'!
create.Rcvr: receiver {Rcvr}
	super create.Rcvr: receiver.
	myChange _ receiver receiveHeaper.!
*/
}

public void sendSelfTo(Xmtr xmtr) {
throw new UnsupportedOperationException();/*
udanax-top.st:967:HeightChanger methodsFor: 'generated:'!
{void} sendSelfTo: xmtr {Xmtr}
	super sendSelfTo: xmtr.
	xmtr sendHeaper: myChange.!
*/
}

public static Heaper make(CanopyCrum crum, PropChange change) {
throw new UnsupportedOperationException();/*
udanax-top.st:980:HeightChanger class methodsFor: 'creation'!
make: crum {CanopyCrum} with: change {PropChange unused}
	
	self knownBug.	"BOGUS"
	DiskManager consistent: 3 with:
		[^self create: crum]!
*/
}
}
