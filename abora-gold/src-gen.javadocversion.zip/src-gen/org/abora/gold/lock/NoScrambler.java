/*
 * Abora-Gold
 * Part of the Abora hypertext project: http://www.abora.org
 * Copyright 2003 David G Jones
 * 
 * Translated from Udanax-Gold source code: http://www.udanax.com
 * Copyright 1979-1999 Udanax.com. All rights reserved
 */
package org.abora.gold.lock;

import org.abora.gold.collection.basic.UInt8Array;
import org.abora.gold.lock.Scrambler;
import org.abora.gold.xpp.basic.Heaper;


/**
 * Does not actually scramble anything.
 */
public class NoScrambler extends Scrambler {
/*
udanax-top.st:45104:
Scrambler subclass: #NoScrambler
	instanceVariableNames: ''
	classVariableNames: ''
	poolDictionaries: ''
	category: 'Xanadu-lock'!
*/
/*
udanax-top.st:45108:
NoScrambler comment:
'Does not actually scramble anything.'!
*/
/*
udanax-top.st:45110:
(NoScrambler getOrMakeCxxClassDescription)
	attributes: ((Set new) add: #CONCRETE; add: #NOT.A.TYPE; yourself)!
*/
/*
udanax-top.st:45129:
NoScrambler class
	instanceVariableNames: ''!
*/
/*
udanax-top.st:45132:
(NoScrambler getOrMakeCxxClassDescription)
	attributes: ((Set new) add: #CONCRETE; add: #NOT.A.TYPE; yourself)!
*/

public UInt8Array scramble(UInt8Array clear) {
throw new UnsupportedOperationException();/*
udanax-top.st:45115:NoScrambler methodsFor: 'scrambling'!
{UInt8Array} scramble: clear {UInt8Array}
	^clear!
*/
}

public int actualHashForEqual() {
throw new UnsupportedOperationException();/*
udanax-top.st:45121:NoScrambler methodsFor: 'testing'!
{UInt32} actualHashForEqual
	^#cat.U.NoScrambler hashForEqual + 1!
*/
}

public boolean isEqual(Heaper other) {
throw new UnsupportedOperationException();/*
udanax-top.st:45124:NoScrambler methodsFor: 'testing'!
{BooleanVar} isEqual: other {Heaper}
	^other isKindOf: NoScrambler!
*/
}

public static void initTimeNonInherited() {
throw new UnsupportedOperationException();/*
udanax-top.st:45137:NoScrambler class methodsFor: 'smalltalk: init'!
initTimeNonInherited
	Scrambler DEFINE.U.SCRAMBLER: 'NoScrambler' with: NoScrambler make!
*/
}

public static Heaper make() {
throw new UnsupportedOperationException();/*
udanax-top.st:45143:NoScrambler class methodsFor: 'pseudo constructors'!
{Scrambler} make
	^self create!
*/
}
}
