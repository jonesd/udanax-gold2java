/*
 * Abora-Gold
 * Part of the Abora hypertext project: http://www.abora.org
 * Copyright 2003 David G Jones
 * 
 * Translated from Udanax-Gold source code: http://www.udanax.com
 * Copyright 1979-1999 Udanax.com. All rights reserved
 */
package org.abora.gold.lock;

import org.abora.gold.collection.basic.UInt8Array;
import org.abora.gold.java.missing.EncrypterConstructor;
import org.abora.gold.lock.Encrypter;
import org.abora.gold.xpp.basic.Heaper;


/**
 * Contains a pointer to a function used to create an instance of a particular kind of
 * Encrypter.
 * Each concrete Encrypter subclass should create a corresponding EncrypterMaker object and
 * register it in a table, with the name of the encryption algorithm. This should be done
 * using the DECLARE_ENCRYPTER and DEFINE_ENCRYPTER macros.
 */
public class EncrypterMaker extends Heaper {
	protected EncrypterConstructor myConstructor;
/*
udanax-top.st:18834:
Heaper subclass: #EncrypterMaker
	instanceVariableNames: 'myConstructor {EncrypterConstructor var}'
	classVariableNames: ''
	poolDictionaries: ''
	category: 'Xanadu-lock'!
*/
/*
udanax-top.st:18838:
EncrypterMaker comment:
'Contains a pointer to a function used to create an instance of a particular kind of Encrypter. 
Each concrete Encrypter subclass should create a corresponding EncrypterMaker object and register it in a table, with the name of the encryption algorithm. This should be done using the DECLARE_ENCRYPTER and DEFINE_ENCRYPTER macros.'!
*/
/*
udanax-top.st:18842:
(EncrypterMaker getOrMakeCxxClassDescription)
	attributes: ((Set new) add: #CONCRETE; add: #EQ; yourself)!
*/

public  EncrypterMaker(EncrypterConstructor constructor) {
throw new UnsupportedOperationException();/*
udanax-top.st:18847:EncrypterMaker methodsFor: 'create'!
create: constructor {EncrypterConstructor var}
	super create.
	myConstructor := constructor.!
*/
}

/**
 * Make an instance of this kind of encrypter, with the given public and private keys.
 */
public Encrypter makeEncrypter(UInt8Array publicKey, UInt8Array privateKey) {
throw new UnsupportedOperationException();/*
udanax-top.st:18854:EncrypterMaker methodsFor: 'accessing'!
{Encrypter} makeEncrypter: publicKey {UInt8Array | NULL} with: privateKey {UInt8Array | NULL}
	"Make an instance of this kind of encrypter, with the given public and private keys."
	
	^myConstructor invokeFunction: publicKey with: privateKey!
*/
}

public int actualHashForEqual() {
throw new UnsupportedOperationException();/*
udanax-top.st:18861:EncrypterMaker methodsFor: 'generated:'!
actualHashForEqual ^self asOop!
*/
}

public boolean isEqual(Object other) {
throw new UnsupportedOperationException();/*
udanax-top.st:18863:EncrypterMaker methodsFor: 'generated:'!
isEqual: other ^self == other!
*/
}
}
