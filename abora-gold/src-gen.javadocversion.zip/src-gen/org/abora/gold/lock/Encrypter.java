/*
 * Abora-Gold
 * Part of the Abora hypertext project: http://www.abora.org
 * Copyright 2003 David G Jones
 * 
 * Translated from Udanax-Gold source code: http://www.udanax.com
 * Copyright 1979-1999 Udanax.com. All rights reserved
 */
package org.abora.gold.lock;

import org.abora.gold.collection.basic.UInt8Array;
import org.abora.gold.collection.tables.MuTable;
import org.abora.gold.java.missing.EncrypterConstructor;
import org.abora.gold.java.missing.smalltalk.Symbol;
import org.abora.gold.lock.Encrypter;
import org.abora.gold.tumbler.Sequence;
import org.abora.gold.xpp.basic.Heaper;


/**
 * An Encrypter is an instantiation of some public-key encryption algorithm, along with
 * optional public and private keys. Each subclass implements a particular algorithm, such as
 * Rivest-Shamir-Adelman, in response to the encryption, decryption, and key generation
 * protocol.
 * ** obsolete documentation **
 * The algorithm is identified by a Sequence naming it. Each concrete subclass must register
 * itself during initialization time. This is handled by two macros, DECLARE_ENCRYPTER and
 * DEFINE_ENCRYPTER. DECLARE_ENCRYPTER(AClassName) defines a function that can be used to
 * create an instance. DEFINE_ENCRYPTER("identifier",AClassName) creates an EncrypterMaker
 * parametrized with that "constructor" function pointer, and stores it in the system-wide
 * table of EncrypterMakers. DECLARE_ENCRYPTER should be invoked in function scope (i.e.
 * inside a linkTimeNonInherited class method) and DEFINE_ENCRYPTER should be invoked inside
 * an Initializer (i.e. inside an initTimeNonInherited class method).
 * The pseudo-constructor to make an Encrypter takes the PackOBits identifying the algorithm,
 * and looks for a corresponding EncrypterMaker in the table. It then asks that
 * EncrypterMaker to create an instance, with the given public and private keys.
 * Encrypters are mutable objects. This allows you to create an Encrypter, generate new
 * random keys for it, make a copy, remove its private key, and pass that out for public use.
 */
public class Encrypter extends Heaper {
	protected UInt8Array myPublicKey;
	protected UInt8Array myPrivateKey;
	protected static MuTable AllEncrypterMakers;
/*
udanax-top.st:18637:
Heaper subclass: #Encrypter
	instanceVariableNames: '
		myPublicKey {UInt8Array | NULL}
		myPrivateKey {UInt8Array | NULL}'
	classVariableNames: 'AllEncrypterMakers {MuTable of: Sequence and: EncrypterMaker} '
	poolDictionaries: ''
	category: 'Xanadu-lock'!
*/
/*
udanax-top.st:18643:
Encrypter comment:
'An Encrypter is an instantiation of some public-key encryption algorithm, along with optional public and private keys. Each subclass implements a particular algorithm, such as Rivest-Shamir-Adelman, in response to the encryption, decryption, and key generation protocol. 
** obsolete documentation **
The algorithm is identified by a Sequence naming it. Each concrete subclass must register itself during initialization time. This is handled by two macros, DECLARE_ENCRYPTER and DEFINE_ENCRYPTER. DECLARE_ENCRYPTER(AClassName) defines a function that can be used to create an instance. DEFINE_ENCRYPTER("identifier",AClassName) creates an EncrypterMaker parametrized with that "constructor" function pointer, and stores it in the system-wide table of EncrypterMakers. DECLARE_ENCRYPTER should be invoked in function scope (i.e. inside a linkTimeNonInherited class method) and DEFINE_ENCRYPTER should be invoked inside an Initializer (i.e. inside an initTimeNonInherited class method).
The pseudo-constructor to make an Encrypter takes the PackOBits identifying the algorithm, and looks for a corresponding EncrypterMaker in the table. It then asks that EncrypterMaker to create an instance, with the given public and private keys.
Encrypters are mutable objects. This allows you to create an Encrypter, generate new random keys for it, make a copy, remove its private key, and pass that out for public use.'!
*/
/*
udanax-top.st:18653:
(Encrypter getOrMakeCxxClassDescription)
	attributes: ((Set new) add: #DEFERRED; add: #EQ; yourself)!
*/
/*
udanax-top.st:18712:
Encrypter class
	instanceVariableNames: ''!
*/
/*
udanax-top.st:18715:
(Encrypter getOrMakeCxxClassDescription)
	attributes: ((Set new) add: #DEFERRED; add: #EQ; yourself)!
*/

public  Encrypter(UInt8Array publicKey, UInt8Array privateKey) {
throw new UnsupportedOperationException();/*
udanax-top.st:18658:Encrypter methodsFor: 'create'!
create: publicKey {UInt8Array | NULL} with: privateKey {UInt8Array | NULL}
	super create.
	myPublicKey := publicKey.
	myPrivateKey := privateKey.!
*/
}

/**
 * Decrypt data with the current private key.
 */
public UInt8Array decrypt(UInt8Array encrypted) {
throw new UnsupportedOperationException();/*
udanax-top.st:18666:Encrypter methodsFor: 'encrypting/decrypting'!
{UInt8Array} decrypt: encrypted {UInt8Array}
	"Decrypt data with the current private key."
	
	self subclassResponsibility!
*/
}

/**
 * Encrypt the given data with the current public key.
 */
public UInt8Array encrypt(UInt8Array clear) {
throw new UnsupportedOperationException();/*
udanax-top.st:18671:Encrypter methodsFor: 'encrypting/decrypting'!
{UInt8Array} encrypt: clear {UInt8Array}
	"Encrypt the given data with the current public key."
	
	self subclassResponsibility!
*/
}

public UInt8Array privateKey() {
throw new UnsupportedOperationException();/*
udanax-top.st:18678:Encrypter methodsFor: 'keys'!
{UInt8Array} privateKey
	myPrivateKey == NULL
		ifTrue: [Heaper BLAST: #NoPrivateKey].
	^myPrivateKey!
*/
}

public UInt8Array publicKey() {
throw new UnsupportedOperationException();/*
udanax-top.st:18684:Encrypter methodsFor: 'keys'!
{UInt8Array} publicKey
	myPublicKey == NULL
		ifTrue: [Heaper BLAST: #NoPublicKey].
	^myPublicKey!
*/
}

/**
 * Generate a new pair of public and private keys using the given data as a random seed.
 */
public void randomizeKeys(UInt8Array seed) {
throw new UnsupportedOperationException();/*
udanax-top.st:18690:Encrypter methodsFor: 'keys'!
{void} randomizeKeys: seed {UInt8Array}
	"Generate a new pair of public and private keys using the given data as a random seed."
	
	self subclassResponsibility!
*/
}

/**
 * Change the private key.
 */
public void setPrivateKey(UInt8Array newKey) {
throw new UnsupportedOperationException();/*
udanax-top.st:18695:Encrypter methodsFor: 'keys'!
{void} setPrivateKey: newKey {UInt8Array | NULL}
	"Change the private key."
	
	myPrivateKey := newKey.!
*/
}

/**
 * Change the public key.
 */
public void setPublicKey(UInt8Array newKey) {
throw new UnsupportedOperationException();/*
udanax-top.st:18700:Encrypter methodsFor: 'keys'!
{void} setPublicKey: newKey {UInt8Array | NULL}
	"Change the public key."
	
	myPublicKey := newKey.!
*/
}

public int actualHashForEqual() {
throw new UnsupportedOperationException();/*
udanax-top.st:18707:Encrypter methodsFor: 'generated:'!
actualHashForEqual ^self asOop!
*/
}

public boolean isEqual(Object other) {
throw new UnsupportedOperationException();/*
udanax-top.st:18709:Encrypter methodsFor: 'generated:'!
isEqual: other ^self == other!
*/
}

/**
 * Make an encrypter of the given type with the given public and private keys. Gets the
 * requested EncrypterMaker out of the table and then asks it to make an encrypter with the
 * given key. Fails with
 * BLAST(NoSuchEncrypter) if it is not found.
 */
public static Heaper make(Sequence identifier, UInt8Array publicKey, UInt8Array privateKey) {
throw new UnsupportedOperationException();/*
udanax-top.st:18720:Encrypter class methodsFor: 'pseudo constructors'!
make: identifier {Sequence}
	with: publicKey {UInt8Array default: NULL}
	with: privateKey {UInt8Array default: NULL}
	"Make an encrypter of the given type with the given public and private keys. Gets the requested EncrypterMaker out of the table and then asks it to make an encrypter with the given key. Fails with
		BLAST(NoSuchEncrypter) if it is not found."
	ScruTable problems.NotInTable
		handle: [ :boom | Heaper BLAST: #NoSuchEncrypter]
		do: [^((AllEncrypterMakers get: identifier) cast: EncrypterMaker)
			makeEncrypter: publicKey with: privateKey]!
*/
}

/**
 * Only applies in C++
 */
public static void DECLARE(Symbol className) {
throw new UnsupportedOperationException();/*
udanax-top.st:18733:Encrypter class methodsFor: 'smalltalk: macros'!
DECLARE.U.ENCRYPTER: className {Symbol}
	"Only applies in C++"!
*/
}

public static void DEFINE(String identifier, Symbol className) {
throw new UnsupportedOperationException();/*
udanax-top.st:18737:Encrypter class methodsFor: 'smalltalk: macros'!
DEFINE.U.ENCRYPTER: identifier {String} with: className {Symbol}
	self REQUIRES: Encrypter.
	self remember: (Sequence string: identifier)
		with: (Smalltalk at: className)!
*/
}

/**
 * In Smalltalk, the Encrypter class is used in place of the function pointer.
 */
public static Encrypter invokeFunction(Sequence publicKey, Sequence privateKey) {
throw new UnsupportedOperationException();/*
udanax-top.st:18743:Encrypter class methodsFor: 'smalltalk: macros'!
{Encrypter} invokeFunction: publicKey {Sequence| NULL} with: privateKey {Sequence | NULL}
	"In Smalltalk, the Encrypter class is used in place of the function pointer."
	
	^self create: publicKey with: privateKey!
*/
}

public static void remember(Sequence identifier, EncrypterConstructor constructor) {
throw new UnsupportedOperationException();/*
udanax-top.st:18750:Encrypter class methodsFor: 'was protected'!
{void} remember: identifier {Sequence}
	with: constructor {EncrypterConstructor var}
	| maker {EncrypterMaker} |
	maker := EncrypterMaker create: constructor.
	AllEncrypterMakers at: identifier introduce: maker.!
*/
}

public static Heaper make(Sequence identifier) {
throw new UnsupportedOperationException();/*
udanax-top.st:18759:Encrypter class methodsFor: 'smalltalk: defaults'!
make: identifier {Sequence}
	^self make: identifier with: NULL with: NULL!
*/
}

public static Heaper make(Sequence identifier, Sequence publicKey) {
throw new UnsupportedOperationException();/*
udanax-top.st:18763:Encrypter class methodsFor: 'smalltalk: defaults'!
make: identifier {Sequence} with: publicKey {Sequence}
	^self make: identifier with: publicKey with: NULL!
*/
}

public static void initTimeNonInherited() {
throw new UnsupportedOperationException();/*
udanax-top.st:18769:Encrypter class methodsFor: 'smalltalk: init'!
initTimeNonInherited
	self REQUIRES: SequenceSpace.
	self REQUIRES: MuTable.
	AllEncrypterMakers := MuTable make: SequenceSpace make.!
*/
}

public static void linkTimeNonInherited() {
throw new UnsupportedOperationException();/*
udanax-top.st:18775:Encrypter class methodsFor: 'smalltalk: init'!
linkTimeNonInherited
	AllEncrypterMakers := NULL.!
*/
}
}
