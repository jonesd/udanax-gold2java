/*
 * Abora-Gold
 * Part of the Abora hypertext project: http://www.abora.org
 * Copyright 2003 David G Jones
 * 
 * Translated from Udanax-Gold source code: http://www.udanax.com
 * Copyright 1979-1999 Udanax.com. All rights reserved
 */
package org.abora.gold.snfinfo;

import org.abora.gold.cobbler.Cookbook;
import org.abora.gold.fm.support.Thunk;
import org.abora.gold.java.missing.UrdiView;
import org.abora.gold.urdi.SnarfInfoHandler;
import org.abora.gold.xcvr.Rcvr;
import org.abora.gold.xcvr.SpecialistRcvr;
import org.abora.gold.xcvr.XcvrMaker;
import org.abora.gold.xcvr.Xmtr;
import org.abora.gold.xcvr.XnReadStream;


/**
 * Print out some summary of the data currently on disk.
 */
public class SnarfStatistics extends Thunk {
	protected char myFilename;
	protected Cookbook myCookbook;
	protected XcvrMaker myProtocol;
/*
udanax-top.st:57810:
Thunk subclass: #SnarfStatistics
	instanceVariableNames: '
		myFilename {char star}
		myCookbook {Cookbook NOCOPY}
		myProtocol {XcvrMaker NOCOPY}'
	classVariableNames: ''
	poolDictionaries: ''
	category: 'Xanadu-snfinfo'!
*/
/*
udanax-top.st:57817:
SnarfStatistics comment:
'Print out some summary of the data currently on disk.'!
*/
/*
udanax-top.st:57819:
(SnarfStatistics getOrMakeCxxClassDescription)
	attributes: ((Set new) add: #CONCRETE; add: #(COPY boot ); add: #NOT.A.TYPE; yourself)!
*/

public void execute() {
throw new UnsupportedOperationException();/*
udanax-top.st:57824:SnarfStatistics methodsFor: 'running'!
{void} execute
	self snarfAllocInfo.
	self tallyFlockTypes.!
*/
}

public void snarfAllocInfo() {
throw new UnsupportedOperationException();/*
udanax-top.st:57828:SnarfStatistics methodsFor: 'running'!
{void} snarfAllocInfo
	| anUrdi {Urdi} view {UrdiView} info {SnarfInfoHandler} 
	totalReal {IntegerVar} totalForget {IntegerVar}
	totalRealSpace {IntegerVar} totalForgetSpace {IntegerVar} |
	totalReal _ IntegerVarZero.
	totalForget _ IntegerVarZero.
	totalRealSpace _ IntegerVarZero.
	totalForgetSpace _ IntegerVarZero.
	anUrdi _ (Urdi urdi: myFilename with: 2).
	view _ anUrdi makeReadView.
	info _ SnarfInfoHandler make: anUrdi with: view.
cerr << 'There are ' << info snarfInfoCount << ' snarFInfo snarfs out of ' << info snarfCount << ' total snarfs.
There are ' << (view getDataSizeOfSnarf: 1) << ' bytes in each snarf.
'.
	info snarfInfoCount almostTo: info snarfCount do: [:snarfID {Int32} |
		(info getSpaceLeft: snarfID) < (view getDataSizeOfSnarf: snarfID)
			ifTrue:
				[| handler {SnarfHandler} count {Int32} forwards {Int32} forgets {Int32} forgetSpace {Int32} flocks {Int32} liveSpace {Int32} |
				handler _ SnarfHandler make: (view makeReadHandle: snarfID).
				count _ handler mapCount.
				forwards _ forgets _ forgetSpace _ flocks _ liveSpace _ Int32Zero.
				Int32Zero almostTo: count do: [:i {Int32} |
					(handler isOccupied: i) ifTrue:
						[(handler fetchForward: i) ~~ NULL ifTrue: [forwards _ forwards + 1]
						ifFalse: [(handler isForgotten: i) ifTrue: [forgets _ forgets + 1.  
												forgetSpace _ forgetSpace + (handler flockSize: i)]
							ifFalse: [flocks _ flocks + 1.  liveSpace _ liveSpace + (handler flockSize: i)]]]].
				cerr << snarfID << ':	' << flocks << ' real in ' << liveSpace << ' bytes.	'.
				cerr << forgets << ' forgets in ' << forgetSpace << ' bytes.	'.
				cerr << forwards << ' forward.	'.
				cerr "<< count << ' cells '" << handler spaceLeft << ' spaceLeft.'.
				cerr << '	forgotten: ' << (info getForgottenFlag: snarfID) << '.
'.
				handler destroy.
				totalReal _ totalReal + flocks.
				totalRealSpace _ totalRealSpace + liveSpace.
				totalForget _ totalForget + forgets.
				totalForgetSpace _ totalForgetSpace + forgetSpace]].
	cerr << 'All others empty.
'.
	cerr << 'Totals:  ' << totalReal << ' real in ' << totalRealSpace << ' bytes, '
		 << totalForget << ' forgets in ' << totalForgetSpace << ' bytes.
'.
	info destroy.
	view destroy.
	anUrdi destroy!
*/
}

public void tallyFlockTypes() {
throw new UnsupportedOperationException();/*
udanax-top.st:57875:SnarfStatistics methodsFor: 'running'!
{void} tallyFlockTypes
	| anUrdi {Urdi} view {UrdiView} info {SnarfInfoHandler}
		liveFlockCounts {PrimIndexTable} liveFlockTypes {PrimPtr2PtrTable}
		forgottenFlockCounts {PrimIndexTable} forgottenFlockTypes {PrimPtr2PtrTable} |
	liveFlockCounts _ PrimIndexTable make: 255.
	liveFlockTypes _ PrimPtr2PtrTable make: 255.
	forgottenFlockCounts _ PrimIndexTable make: 255.
	forgottenFlockTypes _ PrimPtr2PtrTable make: 255.
	anUrdi _ Urdi urdi: myFilename with: 2.
	view _ anUrdi makeReadView.
	info _ SnarfInfoHandler make: anUrdi with: view.
	self diskCookbook: view with: info.
	cerr << 'Tallying types over all snarfs, this may take a while.
'.
	info snarfInfoCount almostTo: info snarfCount do: [:snarfID {Int32} |
		(info getSpaceLeft: snarfID) < (view getDataSizeOfSnarf: snarfID)
			ifTrue: 
				[| handler {SnarfHandler} count {Int32} |
				handler _ SnarfHandler make: (view makeReadHandle: snarfID).
				count _ handler mapCount.
				Int32Zero almostTo: count do: [:i {Int32} |
					((handler isOccupied: i) and: [(handler fetchForward: i) == NULL]) ifTrue:
						[| rcvr {Rcvr} stream {XnReadStream} cat {Category} |
						rcvr _ self makeRcvr: (stream _ handler readStream: i).
						cat _ SpecialistRcvrJig receiveCategory: rcvr.
						rcvr destroy.
						stream destroy.
						(cat isEqualOrSubclassOf: Abraham) ifFalse:
							[cerr << 'WARNING: non-Abraham flock at ' << snarfID << ':' << i << ' : '.
							cerr << cat name << '
'.
							cerr << '	flock size = ' << (handler flockSize: i) << '
'].
						(handler isForgotten: i) ifFalse:
							[(liveFlockTypes fetch: cat) == NULL
								ifTrue: [liveFlockTypes at: cat store: cat.
										liveFlockCounts at: cat store: 1]
								ifFalse: [liveFlockCounts at: cat store: (liveFlockCounts fetch: cat) + 1]]
							ifTrue: [(forgottenFlockTypes fetch: cat) == NULL
								ifTrue: [forgottenFlockTypes at: cat store: cat.
										forgottenFlockCounts at: cat store: 1]
								ifFalse: [forgottenFlockCounts at: cat store: (forgottenFlockCounts fetch: cat) + 1]]]].
				handler destroy]].
	cerr << '
tally of live flocks.
'.
	liveFlockTypes stepper forEach: [:cat {Category} |
		cerr << (liveFlockCounts fetch: cat) << '	' << cat name << '
'].
	cerr << '
tally of forgotten flocks.
'.
	forgottenFlockTypes stepper forEach: [:cat {Category} |
		cerr << (forgottenFlockCounts fetch: cat) << '	' << cat name << '
'].
	info destroy.
	view destroy.
	anUrdi destroy!
*/
}

/**
 * Get the cookbook and protocol-stream maker for the disk.
 */
public void diskCookbook(UrdiView view, SnarfInfoHandler info) {
throw new UnsupportedOperationException();/*
udanax-top.st:57936:SnarfStatistics methodsFor: 'private'!
{void} diskCookbook: view {UrdiView} with: info {SnarfInfoHandler}
	"Get the cookbook and protocol-stream maker for the disk."
	| handler {SnarfHandler} stream {XnReadStream} rcvr {Rcvr} protocol {char star} cookbook {char star}|
	handler _ SnarfHandler make: (view makeReadHandle: info snarfInfoCount).
	rcvr _ TextyXcvrMaker makeReader: (stream _ handler readStream: Int32Zero).
	protocol _ rcvr receiveString.
	cookbook _ rcvr receiveString.
	rcvr destroy.
	stream destroy.
	handler destroy.
	myProtocol _ ProtocolBroker diskProtocol: protocol.	
	myCookbook _ Cookbook make.String: cookbook.
	protocol delete.
	cookbook delete.!
*/
}

public SpecialistRcvr makeRcvr(XnReadStream readStream) {
throw new UnsupportedOperationException();/*
udanax-top.st:57952:SnarfStatistics methodsFor: 'private'!
{SpecialistRcvr} makeRcvr: readStream {XnReadStream}
	^myProtocol makeRcvr: (DiskSpecialist make: myCookbook with: NULL) with: readStream!
*/
}

public  SnarfStatistics(Rcvr receiver) {
throw new UnsupportedOperationException();/*
udanax-top.st:57957:SnarfStatistics methodsFor: 'generated:'!
create.Rcvr: receiver {Rcvr}
	super create.Rcvr: receiver.
	myFilename _ receiver receiveString.!
*/
}

public void sendSelfTo(Xmtr xmtr) {
throw new UnsupportedOperationException();/*
udanax-top.st:57961:SnarfStatistics methodsFor: 'generated:'!
{void} sendSelfTo: xmtr {Xmtr}
	super sendSelfTo: xmtr.
	xmtr sendString: myFilename.!
*/
}
}
