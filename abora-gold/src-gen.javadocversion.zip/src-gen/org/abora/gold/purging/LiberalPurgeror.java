/*
 * Abora-Gold
 * Part of the Abora hypertext project: http://www.abora.org
 * Copyright 2003 David G Jones
 * 
 * Translated from Udanax-Gold source code: http://www.udanax.com
 * Copyright 1979-1999 Udanax.com. All rights reserved
 */
package org.abora.gold.purging;

import org.abora.gold.gchooks.RepairEngineer;
import org.abora.gold.snarf.SnarfPacker;
import org.abora.gold.xpp.basic.Heaper;


public class LiberalPurgeror extends RepairEngineer {
	protected boolean myMustPurge;
	protected SnarfPacker myPacker;
/*
udanax-top.st:42177:
RepairEngineer subclass: #LiberalPurgeror
	instanceVariableNames: '
		myMustPurge {BooleanVar}
		myPacker {SnarfPacker}'
	classVariableNames: ''
	poolDictionaries: ''
	category: 'Xanadu-purging'!
*/
/*
udanax-top.st:42183:
(LiberalPurgeror getOrMakeCxxClassDescription)
	attributes: ((Set new) add: #CONCRETE; yourself)!
*/
/*
udanax-top.st:42206:
LiberalPurgeror class
	instanceVariableNames: ''!
*/
/*
udanax-top.st:42209:
(LiberalPurgeror getOrMakeCxxClassDescription)
	attributes: ((Set new) add: #CONCRETE; yourself)!
*/

public  LiberalPurgeror(SnarfPacker packer) {
throw new UnsupportedOperationException();/*
udanax-top.st:42188:LiberalPurgeror methodsFor: 'protected: create'!
create: packer {SnarfPacker}
	super create.
	myPacker := packer.
	myMustPurge := false!
*/
}

public void setMustPurge() {
throw new UnsupportedOperationException();/*
udanax-top.st:42195:LiberalPurgeror methodsFor: 'accessing'!
{void} setMustPurge
	myMustPurge := true!
*/
}

public void repair() {
throw new UnsupportedOperationException();/*
udanax-top.st:42200:LiberalPurgeror methodsFor: 'invoking'!
{void} repair
	myMustPurge ifTrue:
		[myPacker purgeClean: true.
		myMustPurge := false]!
*/
}

public static Heaper make(SnarfPacker packer) {
throw new UnsupportedOperationException();/*
udanax-top.st:42214:LiberalPurgeror class methodsFor: 'create'!
make: packer {SnarfPacker}
	^ self create: packer!
*/
}
}
