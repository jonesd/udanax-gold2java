/*
 * Abora-Gold
 * Part of the Abora hypertext project: http://www.abora.org
 * Copyright 2003 David G Jones
 * 
 * Translated from Udanax-Gold source code: http://www.udanax.com
 * Copyright 1979-1999 Udanax.com. All rights reserved
 */
package org.abora.gold.fbtest;

import org.abora.gold.cobbler.BootMaker;
import org.abora.gold.cobbler.BootPlan;
import org.abora.gold.xcvr.Rcvr;
import org.abora.gold.xcvr.Xmtr;
import org.abora.gold.xpp.basic.Category;
import org.abora.gold.xpp.basic.Heaper;


public class ShepherdBootMaker extends BootMaker {
/*
udanax-top.st:56940:
BootMaker subclass: #ShepherdBootMaker
	instanceVariableNames: ''
	classVariableNames: ''
	poolDictionaries: ''
	category: 'Xanadu-fbtest'!
*/
/*
udanax-top.st:56944:
(ShepherdBootMaker getOrMakeCxxClassDescription)
	attributes: ((Set new) add: #CONCRETE; add: #(COPY boot ); add: #NOT.A.TYPE; yourself)!
*/
/*
udanax-top.st:56966:
ShepherdBootMaker class
	instanceVariableNames: ''!
*/
/*
udanax-top.st:56969:
(ShepherdBootMaker getOrMakeCxxClassDescription)
	attributes: ((Set new) add: #CONCRETE; add: #(COPY boot ); add: #NOT.A.TYPE; yourself)!
*/

public Category bootCategory() {
throw new UnsupportedOperationException();/*
udanax-top.st:56949:ShepherdBootMaker methodsFor: 'accessing'!
{Category} bootCategory
	^Counter!
*/
}

public Heaper bootHeaper() {
throw new UnsupportedOperationException();/*
udanax-top.st:56954:ShepherdBootMaker methodsFor: 'protected:'!
{Heaper} bootHeaper
	^Counter make.!
*/
}

public  ShepherdBootMaker(Rcvr receiver) {
throw new UnsupportedOperationException();/*
udanax-top.st:56959:ShepherdBootMaker methodsFor: 'generated:'!
create.Rcvr: receiver {Rcvr}
	super create.Rcvr: receiver.!
*/
}

public void sendSelfTo(Xmtr xmtr) {
throw new UnsupportedOperationException();/*
udanax-top.st:56962:ShepherdBootMaker methodsFor: 'generated:'!
{void} sendSelfTo: xmtr {Xmtr}
	super sendSelfTo: xmtr.!
*/
}

public static Heaper make() {
throw new UnsupportedOperationException();/*
udanax-top.st:56974:ShepherdBootMaker class methodsFor: 'creation'!
{BootPlan} make
	^self create!
*/
}
}
