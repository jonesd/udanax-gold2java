/*
 * Abora-Gold
 * Part of the Abora hypertext project: http://www.abora.org
 * Copyright 2003 David G Jones
 * 
 * Translated from Udanax-Gold source code: http://www.udanax.com
 * Copyright 1979-1999 Udanax.com. All rights reserved
 */
package org.abora.gold.fbtest;

import org.abora.gold.cobbler.BootPlan;
import org.abora.gold.cobbler.Connection;
import org.abora.gold.xcvr.Rcvr;
import org.abora.gold.xcvr.Xmtr;
import org.abora.gold.xpp.basic.Category;


public class FeWorksBootMaker extends BootPlan {
/*
udanax-top.st:57065:
BootPlan subclass: #FeWorksBootMaker
	instanceVariableNames: ''
	classVariableNames: ''
	poolDictionaries: ''
	category: 'Xanadu-fbtest'!
*/
/*
udanax-top.st:57069:
(FeWorksBootMaker getOrMakeCxxClassDescription)
	attributes: ((Set new) add: #CONCRETE; add: #(COPY boot ); add: #NOT.A.TYPE; yourself)!
*/

public Category bootCategory() {
throw new UnsupportedOperationException();/*
udanax-top.st:57074:FeWorksBootMaker methodsFor: 'accessing'!
{Category} bootCategory
	^ FeServer!
*/
}

public Connection connection() {
throw new UnsupportedOperationException();/*
udanax-top.st:57077:FeWorksBootMaker methodsFor: 'accessing'!
{Connection} connection
	| conn {Connection} |
	conn _ Connection make: FeServer.
	^ conn
	"^NestedConnection make: self bootCategory with: (PrGateKeeper make: (conn bootHeaper cast: FeGateKeeper)) with: conn"!
*/
}

public  FeWorksBootMaker(Rcvr receiver) {
throw new UnsupportedOperationException();/*
udanax-top.st:57085:FeWorksBootMaker methodsFor: 'generated:'!
create.Rcvr: receiver {Rcvr}
	super create.Rcvr: receiver.!
*/
}

public void sendSelfTo(Xmtr xmtr) {
throw new UnsupportedOperationException();/*
udanax-top.st:57088:FeWorksBootMaker methodsFor: 'generated:'!
{void} sendSelfTo: xmtr {Xmtr}
	super sendSelfTo: xmtr.!
*/
}
}
