/*
 * Abora-Gold
 * Part of the Abora hypertext project: http://www.abora.org
 * Copyright 2003 David G Jones
 * 
 * Translated from Udanax-Gold source code: http://www.udanax.com
 * Copyright 1979-1999 Udanax.com. All rights reserved
 */
package org.abora.gold.fbtest;

import org.abora.gold.cobbler.BootMaker;
import org.abora.gold.xcvr.Rcvr;
import org.abora.gold.xcvr.Xmtr;
import org.abora.gold.xpp.basic.Category;
import org.abora.gold.xpp.basic.Heaper;


public class WorksBootMaker extends BootMaker {
/*
udanax-top.st:56977:
BootMaker subclass: #WorksBootMaker
	instanceVariableNames: ''
	classVariableNames: ''
	poolDictionaries: ''
	category: 'Xanadu-fbtest'!
*/
/*
udanax-top.st:56981:
(WorksBootMaker getOrMakeCxxClassDescription)
	attributes: ((Set new) add: #CONCRETE; add: #(COPY boot ); add: #NOT.A.TYPE; yourself)!
*/
/*
udanax-top.st:57010:
WorksBootMaker class
	instanceVariableNames: ''!
*/
/*
udanax-top.st:57013:
(WorksBootMaker getOrMakeCxxClassDescription)
	attributes: ((Set new) add: #CONCRETE; add: #(COPY boot ); add: #NOT.A.TYPE; yourself)!
*/

public Category bootCategory() {
throw new UnsupportedOperationException();/*
udanax-top.st:56986:WorksBootMaker methodsFor: 'accessing'!
{Category} bootCategory
	^FeServer!
*/
}

public Heaper bootHeaper() {
throw new UnsupportedOperationException();/*
udanax-top.st:56991:WorksBootMaker methodsFor: 'protected:'!
{Heaper} bootHeaper
	GrandConnection fluidFetch == NULL ifTrue:
		["CurrentGrandMap fluidFetch == NULL ifFalse: [Heaper BLAST: #GrandMapWithoutConnection]."
		GrandConnection fluidSet: (Connection make: BeGrandMap).
		CurrentGrandMap fluidSet: (GrandConnection fluidGet bootHeaper cast: BeGrandMap).
		"force agenda items to be invoked - they were commented out in getInitialFlock /ravi/10/22/92/"
		DiskManager consistent: []].
	^FeServer make!
*/
}

public  WorksBootMaker(Rcvr receiver) {
throw new UnsupportedOperationException();/*
udanax-top.st:57003:WorksBootMaker methodsFor: 'generated:'!
create.Rcvr: receiver {Rcvr}
	super create.Rcvr: receiver.!
*/
}

public void sendSelfTo(Xmtr xmtr) {
throw new UnsupportedOperationException();/*
udanax-top.st:57006:WorksBootMaker methodsFor: 'generated:'!
{void} sendSelfTo: xmtr {Xmtr}
	super sendSelfTo: xmtr.!
*/
}

public static void staticTimeNonInherited() {
throw new UnsupportedOperationException();/*
udanax-top.st:57018:WorksBootMaker class methodsFor: 'smalltalk: init'!
staticTimeNonInherited
	Connection defineFluid: #GrandConnection with: Emulsion globalEmulsion with: [NULL].!
*/
}
}
