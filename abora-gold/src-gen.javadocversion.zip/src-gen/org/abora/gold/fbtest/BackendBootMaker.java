/*
 * Abora-Gold
 * Part of the Abora hypertext project: http://www.abora.org
 * Copyright 2003 David G Jones
 * 
 * Translated from Udanax-Gold source code: http://www.udanax.com
 * Copyright 1979-1999 Udanax.com. All rights reserved
 */
package org.abora.gold.fbtest;

import org.abora.gold.cobbler.BootMaker;
import org.abora.gold.cobbler.BootPlan;
import org.abora.gold.xcvr.Rcvr;
import org.abora.gold.xcvr.Xmtr;
import org.abora.gold.xpp.basic.Category;
import org.abora.gold.xpp.basic.Heaper;


public class BackendBootMaker extends BootMaker {
/*
udanax-top.st:56870:
BootMaker subclass: #BackendBootMaker
	instanceVariableNames: ''
	classVariableNames: ''
	poolDictionaries: ''
	category: 'Xanadu-fbtest'!
*/
/*
udanax-top.st:56874:
(BackendBootMaker getOrMakeCxxClassDescription)
	attributes: ((Set new) add: #CONCRETE; add: #(COPY boot ); add: #NOT.A.TYPE; yourself)!
*/
/*
udanax-top.st:56897:
BackendBootMaker class
	instanceVariableNames: ''!
*/
/*
udanax-top.st:56900:
(BackendBootMaker getOrMakeCxxClassDescription)
	attributes: ((Set new) add: #CONCRETE; add: #(COPY boot ); add: #NOT.A.TYPE; yourself)!
*/

public Category bootCategory() {
throw new UnsupportedOperationException();/*
udanax-top.st:56879:BackendBootMaker methodsFor: 'accessing'!
{Category} bootCategory
	^BeGrandMap!
*/
}

public Heaper bootHeaper() {
throw new UnsupportedOperationException();/*
udanax-top.st:56884:BackendBootMaker methodsFor: 'protected:'!
{Heaper} bootHeaper
	^BeGrandMap make!
*/
}

public  BackendBootMaker(Rcvr receiver) {
throw new UnsupportedOperationException();/*
udanax-top.st:56890:BackendBootMaker methodsFor: 'generated:'!
create.Rcvr: receiver {Rcvr}
	super create.Rcvr: receiver.!
*/
}

public void sendSelfTo(Xmtr xmtr) {
throw new UnsupportedOperationException();/*
udanax-top.st:56893:BackendBootMaker methodsFor: 'generated:'!
{void} sendSelfTo: xmtr {Xmtr}
	super sendSelfTo: xmtr.!
*/
}

public static Heaper make() {
throw new UnsupportedOperationException();/*
udanax-top.st:56905:BackendBootMaker class methodsFor: 'creation'!
{BootPlan} make
	^self create!
*/
}

public static void initTimeNonInherited() {
throw new UnsupportedOperationException();/*
udanax-top.st:56910:BackendBootMaker class methodsFor: 'smalltalk: init'!
initTimeNonInherited
	[FeServer, Recipe] USES.
	Cookbook declareCookbook: 'disk' with: BeGrandMap with: DiskCuisine with: XppCuisine with: FebeCuisine!
*/
}
}
