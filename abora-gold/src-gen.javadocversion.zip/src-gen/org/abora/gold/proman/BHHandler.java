/*
 * Abora-Gold
 * Part of the Abora hypertext project: http://www.abora.org
 * Copyright 2003 David G Jones
 * 
 * Translated from Udanax-Gold source code: http://www.udanax.com
 * Copyright 1979-1999 Udanax.com. All rights reserved
 */
package org.abora.gold.proman;

import org.abora.gold.java.missing.handle.BHFn;
import org.abora.gold.proman.PromiseManager;
import org.abora.gold.proman.RequestHandler;
import org.abora.gold.xpp.basic.Category;
import org.abora.gold.xpp.basic.Heaper;


public class BHHandler extends RequestHandler {
	protected BHFn myFn;
	protected Category myType1;
/*
udanax-top.st:43576:
RequestHandler subclass: #BHHandler
	instanceVariableNames: '
		myFn {BHFn var}
		myType1 {Category}'
	classVariableNames: ''
	poolDictionaries: ''
	category: 'Xanadu-proman'!
*/
/*
udanax-top.st:43582:
(BHHandler getOrMakeCxxClassDescription)
	attributes: ((Set new) add: #CONCRETE; add: #NOT.A.TYPE; yourself)!
*/
/*
udanax-top.st:43602:
BHHandler class
	instanceVariableNames: ''!
*/
/*
udanax-top.st:43605:
(BHHandler getOrMakeCxxClassDescription)
	attributes: ((Set new) add: #CONCRETE; add: #NOT.A.TYPE; yourself)!
*/

public void handleRequest(PromiseManager pm) {
throw new UnsupportedOperationException();/*
udanax-top.st:43587:BHHandler methodsFor: 'request handling'!
{void} handleRequest: pm {PromiseManager}
	
	| arg1 {Heaper} |
	arg1 _ pm fetchNonNullHeaper: myType1.
	pm noErrors ifTrue:
		[pm respondBooleanVar: (myFn invokeFunction: arg1)]!
*/
}

public  BHHandler(BHFn fn, Category type1) {
throw new UnsupportedOperationException();/*
udanax-top.st:43596:BHHandler methodsFor: 'creation'!
create: fn {BHFn var} with: type1 {Category}
	super create.
	myFn _ fn.
	myType1 _ type1.!
*/
}

public static Heaper make(BHFn fn, Category type1) {
throw new UnsupportedOperationException();/*
udanax-top.st:43610:BHHandler class methodsFor: 'creation'!
{RequestHandler} make: fn {BHFn var} with: type1 {Category}
	^self create: fn with: type1!
*/
}

public static void isGenerated() {
throw new UnsupportedOperationException();/*
udanax-top.st:43615:BHHandler class methodsFor: 'generated:'!
isGenerated ^true!
*/
}
}
