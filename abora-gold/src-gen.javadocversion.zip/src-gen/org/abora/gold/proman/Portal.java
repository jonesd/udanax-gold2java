/*
 * Abora-Gold
 * Part of the Abora hypertext project: http://www.abora.org
 * Copyright 2003 David G Jones
 * 
 * Translated from Udanax-Gold source code: http://www.udanax.com
 * Copyright 1979-1999 Udanax.com. All rights reserved
 */
package org.abora.gold.proman;

import org.abora.gold.xcvr.XnReadStream;
import org.abora.gold.xcvr.XnWriteStream;
import org.abora.gold.xpp.basic.Heaper;


public class Portal extends Heaper {
/*
udanax-top.st:31333:
Heaper subclass: #Portal
	instanceVariableNames: ''
	classVariableNames: ''
	poolDictionaries: ''
	category: 'Xanadu-proman'!
*/
/*
udanax-top.st:31337:
(Portal getOrMakeCxxClassDescription)
	attributes: ((Set new) add: #DEFERRED; add: #EQ; yourself)!
*/
/*
udanax-top.st:31357:
Portal class
	instanceVariableNames: ''!
*/
/*
udanax-top.st:31360:
(Portal getOrMakeCxxClassDescription)
	attributes: ((Set new) add: #DEFERRED; add: #EQ; yourself)!
*/

public XnReadStream readStream() {
throw new UnsupportedOperationException();/*
udanax-top.st:31342:Portal methodsFor: 'accessing'!
{XnReadStream} readStream
	
	self subclassResponsibility!
*/
}

public XnWriteStream writeStream() {
throw new UnsupportedOperationException();/*
udanax-top.st:31346:Portal methodsFor: 'accessing'!
{XnWriteStream} writeStream
	
	self subclassResponsibility!
*/
}

public int actualHashForEqual() {
throw new UnsupportedOperationException();/*
udanax-top.st:31352:Portal methodsFor: 'generated:'!
actualHashForEqual ^self asOop!
*/
}

public boolean isEqual(Object other) {
throw new UnsupportedOperationException();/*
udanax-top.st:31354:Portal methodsFor: 'generated:'!
isEqual: other ^self == other!
*/
}

public static Heaper make(String host, int port) {
throw new UnsupportedOperationException();/*
udanax-top.st:31365:Portal class methodsFor: 'pseudo constructors'!
make: host {char star} with: port {UInt32}
	^SocketPortal make: host with: port!
*/
}
}
