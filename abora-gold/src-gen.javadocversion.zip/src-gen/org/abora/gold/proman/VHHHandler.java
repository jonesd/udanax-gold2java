/*
 * Abora-Gold
 * Part of the Abora hypertext project: http://www.abora.org
 * Copyright 2003 David G Jones
 * 
 * Translated from Udanax-Gold source code: http://www.udanax.com
 * Copyright 1979-1999 Udanax.com. All rights reserved
 */
package org.abora.gold.proman;

import org.abora.gold.java.missing.handle.VHHFn;
import org.abora.gold.proman.PromiseManager;
import org.abora.gold.proman.RequestHandler;
import org.abora.gold.xpp.basic.Category;
import org.abora.gold.xpp.basic.Heaper;


public class VHHHandler extends RequestHandler {
	protected VHHFn myFn;
	protected Category myType1;
	protected Category myType2;
/*
udanax-top.st:44264:
RequestHandler subclass: #VHHHandler
	instanceVariableNames: '
		myFn {VHHFn var}
		myType1 {Category}
		myType2 {Category}'
	classVariableNames: ''
	poolDictionaries: ''
	category: 'Xanadu-proman'!
*/
/*
udanax-top.st:44271:
(VHHHandler getOrMakeCxxClassDescription)
	attributes: ((Set new) add: #CONCRETE; add: #NOT.A.TYPE; yourself)!
*/
/*
udanax-top.st:44294:
VHHHandler class
	instanceVariableNames: ''!
*/
/*
udanax-top.st:44297:
(VHHHandler getOrMakeCxxClassDescription)
	attributes: ((Set new) add: #CONCRETE; add: #NOT.A.TYPE; yourself)!
*/

public void handleRequest(PromiseManager pm) {
throw new UnsupportedOperationException();/*
udanax-top.st:44276:VHHHandler methodsFor: 'request handling'!
{void} handleRequest: pm {PromiseManager}
	
	| arg1 {Heaper} arg2 {Heaper} |
	arg1 _ pm fetchNonNullHeaper: myType1.
	arg2 _ pm fetchNonNullHeaper: myType2.
	pm noErrors ifTrue:
		[(myFn invokeFunction: arg1 with: arg2).
		pm respondVoid]!
*/
}

public  VHHHandler(VHHFn fn, Category type1, Category type2) {
throw new UnsupportedOperationException();/*
udanax-top.st:44287:VHHHandler methodsFor: 'creation'!
create: fn {VHHFn var} with: type1 {Category} with: type2 {Category}
	super create.
	myFn _ fn.
	myType1 _ type1.
	myType2 _ type2.!
*/
}

public static Heaper make(VHHFn fn, Category type1, Category type2) {
throw new UnsupportedOperationException();/*
udanax-top.st:44302:VHHHandler class methodsFor: 'creation'!
{RequestHandler} make: fn {VHHFn var} with: type1 {Category} with: type2 {Category}
	^self create: fn with: type1 with: type2!
*/
}

public static void isGenerated() {
throw new UnsupportedOperationException();/*
udanax-top.st:44307:VHHHandler class methodsFor: 'generated:'!
isGenerated ^true!
*/
}
}
