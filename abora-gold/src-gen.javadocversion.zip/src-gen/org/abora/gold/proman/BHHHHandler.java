/*
 * Abora-Gold
 * Part of the Abora hypertext project: http://www.abora.org
 * Copyright 2003 David G Jones
 * 
 * Translated from Udanax-Gold source code: http://www.udanax.com
 * Copyright 1979-1999 Udanax.com. All rights reserved
 */
package org.abora.gold.proman;

import org.abora.gold.java.missing.handle.BHHHFn;
import org.abora.gold.proman.PromiseManager;
import org.abora.gold.proman.RequestHandler;
import org.abora.gold.xpp.basic.Category;
import org.abora.gold.xpp.basic.Heaper;


public class BHHHHandler extends RequestHandler {
	protected BHHHFn myFn;
	protected Category myType1;
	protected Category myType2;
	protected Category myType3;
/*
udanax-top.st:43661:
RequestHandler subclass: #BHHHHandler
	instanceVariableNames: '
		myFn {BHHHFn var}
		myType1 {Category}
		myType2 {Category}
		myType3 {Category}'
	classVariableNames: ''
	poolDictionaries: ''
	category: 'Xanadu-proman'!
*/
/*
udanax-top.st:43669:
(BHHHHandler getOrMakeCxxClassDescription)
	attributes: ((Set new) add: #CONCRETE; add: #NOT.A.TYPE; yourself)!
*/
/*
udanax-top.st:43693:
BHHHHandler class
	instanceVariableNames: ''!
*/
/*
udanax-top.st:43696:
(BHHHHandler getOrMakeCxxClassDescription)
	attributes: ((Set new) add: #CONCRETE; add: #NOT.A.TYPE; yourself)!
*/

public void handleRequest(PromiseManager pm) {
throw new UnsupportedOperationException();/*
udanax-top.st:43674:BHHHHandler methodsFor: 'request handling'!
{void} handleRequest: pm {PromiseManager}
	
	| arg1 {Heaper} arg2 {Heaper} arg3 {Heaper} |
	arg1 _ pm fetchNonNullHeaper: myType1.
	arg2 _ pm fetchNonNullHeaper: myType2.
	arg3 _ pm fetchNonNullHeaper: myType3.
	pm noErrors ifTrue:
		[pm respondBooleanVar: (myFn invokeFunction: arg1 with: arg2 with: arg3)]!
*/
}

public  BHHHHandler(BHHHFn fn, Category type1, Category type2, Category type3) {
throw new UnsupportedOperationException();/*
udanax-top.st:43685:BHHHHandler methodsFor: 'creation'!
create: fn {BHHHFn var} with: type1 {Category} with: type2 {Category} with: type3 {Category}
	super create.
	myFn _ fn.
	myType1 _ type1.
	myType2 _ type2.
	myType3 _ type3.!
*/
}

public static Heaper make(BHHHFn fn, Category type1, Category type2, Category type3) {
throw new UnsupportedOperationException();/*
udanax-top.st:43701:BHHHHandler class methodsFor: 'creation'!
{RequestHandler} make: fn {BHHHFn var} with: type1 {Category} with: type2 {Category} with: type3 {Category}
	^self create: fn with: type1 with: type2 with: type3!
*/
}

public static void isGenerated() {
throw new UnsupportedOperationException();/*
udanax-top.st:43706:BHHHHandler class methodsFor: 'generated:'!
isGenerated ^true!
*/
}
}
