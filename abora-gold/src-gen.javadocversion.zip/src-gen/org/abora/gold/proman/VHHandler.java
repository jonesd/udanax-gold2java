/*
 * Abora-Gold
 * Part of the Abora hypertext project: http://www.abora.org
 * Copyright 2003 David G Jones
 * 
 * Translated from Udanax-Gold source code: http://www.udanax.com
 * Copyright 1979-1999 Udanax.com. All rights reserved
 */
package org.abora.gold.proman;

import org.abora.gold.java.missing.handle.VHFn;
import org.abora.gold.proman.PromiseManager;
import org.abora.gold.proman.RequestHandler;
import org.abora.gold.xpp.basic.Category;
import org.abora.gold.xpp.basic.Heaper;


public class VHHandler extends RequestHandler {
	protected VHFn myFn;
	protected Category myType1;
/*
udanax-top.st:44222:
RequestHandler subclass: #VHHandler
	instanceVariableNames: '
		myFn {VHFn var}
		myType1 {Category}'
	classVariableNames: ''
	poolDictionaries: ''
	category: 'Xanadu-proman'!
*/
/*
udanax-top.st:44228:
(VHHandler getOrMakeCxxClassDescription)
	attributes: ((Set new) add: #CONCRETE; add: #NOT.A.TYPE; yourself)!
*/
/*
udanax-top.st:44249:
VHHandler class
	instanceVariableNames: ''!
*/
/*
udanax-top.st:44252:
(VHHandler getOrMakeCxxClassDescription)
	attributes: ((Set new) add: #CONCRETE; add: #NOT.A.TYPE; yourself)!
*/

public void handleRequest(PromiseManager pm) {
throw new UnsupportedOperationException();/*
udanax-top.st:44233:VHHandler methodsFor: 'request handling'!
{void} handleRequest: pm {PromiseManager}
	
	| arg1 {Heaper} |
	arg1 _ pm fetchNonNullHeaper: myType1.
	pm noErrors ifTrue:
		[(myFn invokeFunction: arg1).
		pm respondVoid]!
*/
}

public  VHHandler(VHFn fn, Category type1) {
throw new UnsupportedOperationException();/*
udanax-top.st:44243:VHHandler methodsFor: 'creation'!
create: fn {VHFn var} with: type1 {Category}
	super create.
	myFn _ fn.
	myType1 _ type1.!
*/
}

public static Heaper make(VHFn fn, Category type1) {
throw new UnsupportedOperationException();/*
udanax-top.st:44257:VHHandler class methodsFor: 'creation'!
{RequestHandler} make: fn {VHFn var} with: type1 {Category}
	^self create: fn with: type1!
*/
}

public static void isGenerated() {
throw new UnsupportedOperationException();/*
udanax-top.st:44262:VHHandler class methodsFor: 'generated:'!
isGenerated ^true!
*/
}
}
