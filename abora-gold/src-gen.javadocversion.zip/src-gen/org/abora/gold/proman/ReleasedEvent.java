/*
 * Abora-Gold
 * Part of the Abora hypertext project: http://www.abora.org
 * Copyright 2003 David G Jones
 * 
 * Translated from Udanax-Gold source code: http://www.udanax.com
 * Copyright 1979-1999 Udanax.com. All rights reserved
 */
package org.abora.gold.proman;

import org.abora.gold.java.missing.IntegerVar;
import org.abora.gold.proman.DetectorEvent;
import org.abora.gold.proman.PromiseManager;
import org.abora.gold.xpp.basic.Heaper;


public class ReleasedEvent extends DetectorEvent {
	protected Heaper myWork;
	protected IntegerVar myReason;
/*
udanax-top.st:16108:
DetectorEvent subclass: #ReleasedEvent
	instanceVariableNames: '
		myWork {Heaper}
		myReason {IntegerVar}'
	classVariableNames: ''
	poolDictionaries: ''
	category: 'Xanadu-proman'!
*/
/*
udanax-top.st:16114:
(ReleasedEvent getOrMakeCxxClassDescription)
	attributes: ((Set new) add: #CONCRETE; add: #NOT.A.TYPE; yourself)!
*/
/*
udanax-top.st:16136:
ReleasedEvent class
	instanceVariableNames: ''!
*/
/*
udanax-top.st:16139:
(ReleasedEvent getOrMakeCxxClassDescription)
	attributes: ((Set new) add: #CONCRETE; add: #NOT.A.TYPE; yourself)!
*/

public  ReleasedEvent(IntegerVar detector, Heaper work, IntegerVar reason) {
	super(detector);
throw new UnsupportedOperationException();/*
udanax-top.st:16119:ReleasedEvent methodsFor: 'creation'!
create: detector {IntegerVar} with: work {Heaper} with: reason {IntegerVar}
	super create: detector.
	myWork _ work.
	myReason _ reason!
*/
}

/**
 * Send the message across the wire.
 */
public void trigger(PromiseManager pm) {
throw new UnsupportedOperationException();/*
udanax-top.st:16126:ReleasedEvent methodsFor: 'triggering'!
{void} trigger: pm {PromiseManager}
	"Send the message across the wire."
	
	pm sendResponse: PromiseManager releasedResponse.
	pm sendIntegerVar: self detector.
	pm sendPromise: myWork.
	pm sendIntegerVar: myReason.
	pm sendPromise: (PrimIntValue make: myReason)!
*/
}

public static Heaper make(IntegerVar detector, Heaper work, IntegerVar reason) {
throw new UnsupportedOperationException();/*
udanax-top.st:16144:ReleasedEvent class methodsFor: 'creation'!
{DetectorEvent} make: detector {IntegerVar} with: work {Heaper} with: reason {IntegerVar}
	^self create: detector with: work with: reason!
*/
}
}
