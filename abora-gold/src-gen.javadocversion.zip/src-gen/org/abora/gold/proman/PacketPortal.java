/*
 * Abora-Gold
 * Part of the Abora hypertext project: http://www.abora.org
 * Copyright 2003 David G Jones
 * 
 * Translated from Udanax-Gold source code: http://www.udanax.com
 * Copyright 1979-1999 Udanax.com. All rights reserved
 */
package org.abora.gold.proman;

import org.abora.gold.collection.basic.UInt8Array;
import org.abora.gold.proman.Portal;
import org.abora.gold.xcvr.XnReadStream;
import org.abora.gold.xcvr.XnWriteStream;


public class PacketPortal extends Portal {
	protected XnReadStream myReadStream;
	protected XnWriteStream myWriteStream;
/*
udanax-top.st:31369:
Portal subclass: #PacketPortal
	instanceVariableNames: '
		myReadStream {XnReadStream}
		myWriteStream {XnWriteStream}'
	classVariableNames: ''
	poolDictionaries: ''
	category: 'Xanadu-proman'!
*/
/*
udanax-top.st:31375:
(PacketPortal getOrMakeCxxClassDescription)
	attributes: ((Set new) add: #DEFERRED; yourself)!
*/

public  PacketPortal() {
throw new UnsupportedOperationException();/*
udanax-top.st:31380:PacketPortal methodsFor: 'protected: creation'!
create
	super create.
	myReadStream _ XnBufferedReadStream create: self.
	myWriteStream _ XnBufferedWriteStream create: self.!
*/
}

public  PacketPortal(XnReadStream readStr, XnWriteStream writeStr) {
throw new UnsupportedOperationException();/*
udanax-top.st:31385:PacketPortal methodsFor: 'protected: creation'!
create: readStr {XnReadStream} with: writeStr {XnWriteStream}
	super create.
	myReadStream _ readStr.
	myWriteStream _ writeStr!
*/
}

public XnReadStream readStream() {
throw new UnsupportedOperationException();/*
udanax-top.st:31392:PacketPortal methodsFor: 'accessing'!
{XnReadStream} readStream
	
	^myReadStream!
*/
}

public XnWriteStream writeStream() {
throw new UnsupportedOperationException();/*
udanax-top.st:31396:PacketPortal methodsFor: 'accessing'!
{XnWriteStream} writeStream
	
	^myWriteStream!
*/
}

/**
 * Make sure the bits go out.
 */
public void flush() {
throw new UnsupportedOperationException();/*
udanax-top.st:31402:PacketPortal methodsFor: 'internal'!
{void} flush
	"Make sure the bits go out."
	
	self subclassResponsibility!
*/
}

/**
 * Return a buffer of a size that the unerlying transport layer likes.
 */
public UInt8Array readBuffer() {
throw new UnsupportedOperationException();/*
udanax-top.st:31407:PacketPortal methodsFor: 'internal'!
{UInt8Array} readBuffer
	"Return a buffer of a size that the unerlying transport layer likes."
	
	self subclassResponsibility!
*/
}

public int readPacket(UInt8Array buffer, int count) {
throw new UnsupportedOperationException();/*
udanax-top.st:31412:PacketPortal methodsFor: 'internal'!
{Int32} readPacket: buffer {UInt8Array} with: count {Int32}
	
	self subclassResponsibility!
*/
}

/**
 * Return a buffer of a size that the unerlying transport layer likes.
 */
public UInt8Array writeBuffer() {
throw new UnsupportedOperationException();/*
udanax-top.st:31416:PacketPortal methodsFor: 'internal'!
{UInt8Array} writeBuffer
	"Return a buffer of a size that the unerlying transport layer likes."
	
	self subclassResponsibility!
*/
}

public void writePacket(UInt8Array packet, int count) {
throw new UnsupportedOperationException();/*
udanax-top.st:31421:PacketPortal methodsFor: 'internal'!
{void} writePacket: packet {UInt8Array} with: count {Int32}
	
	self subclassResponsibility!
*/
}
}
