/*
 * Abora-Gold
 * Part of the Abora hypertext project: http://www.abora.org
 * Copyright 2003 David G Jones
 * 
 * Translated from Udanax-Gold source code: http://www.udanax.com
 * Copyright 1979-1999 Udanax.com. All rights reserved
 */
package org.abora.gold.proman;

import org.abora.gold.detect.FeFillRangeDetector;
import org.abora.gold.java.missing.IntegerVar;
import org.abora.gold.nkernel.FeEdition;
import org.abora.gold.proman.PromiseManager;
import org.abora.gold.xpp.basic.Heaper;


/**
 * Send the detector events over comm.
 */
public class CommFillRangeDetector extends FeFillRangeDetector {
	protected PromiseManager myManager;
	protected IntegerVar myNumber;
	protected FeEdition myTarget;
/*
udanax-top.st:19586:
FeFillRangeDetector subclass: #CommFillRangeDetector
	instanceVariableNames: '
		myManager {PromiseManager}
		myNumber {IntegerVar}
		myTarget {FeEdition}'
	classVariableNames: ''
	poolDictionaries: ''
	category: 'Xanadu-proman'!
*/
/*
udanax-top.st:19593:
CommFillRangeDetector comment:
'Send the detector events over comm.'!
*/
/*
udanax-top.st:19595:
(CommFillRangeDetector getOrMakeCxxClassDescription)
	attributes: ((Set new) add: #CONCRETE; yourself)!
*/
/*
udanax-top.st:19614:
CommFillRangeDetector class
	instanceVariableNames: ''!
*/
/*
udanax-top.st:19617:
(CommFillRangeDetector getOrMakeCxxClassDescription)
	attributes: ((Set new) add: #CONCRETE; yourself)!
*/

public  CommFillRangeDetector(PromiseManager pm, IntegerVar number, FeEdition target) {
throw new UnsupportedOperationException();/*
udanax-top.st:19600:CommFillRangeDetector methodsFor: 'creation'!
create: pm {PromiseManager} with: number {IntegerVar} with: target {FeEdition}
	super create.
	myManager _ pm.
	myNumber _ number.
	myTarget _ target!
*/
}

/**
 * Essential.  Some of the PlaceHolders in the Edition on which I was placed have become
 * something else. The Edition has their new identies as its RangeElements, though the keys
 * may bear no relationship to those in the original Edition.
 */
public void rangeFilled(FeEdition newIdentities) {
throw new UnsupportedOperationException();/*
udanax-top.st:19608:CommFillRangeDetector methodsFor: 'triggering'!
{void} rangeFilled: newIdentities {FeEdition}
	"Essential.  Some of the PlaceHolders in the Edition on which I was placed have become something else. The Edition has their new identies as its RangeElements, though the keys may bear no relationship to those in the original Edition."
	
	myManager queueDetectorEvent: (RangeFilledEvent make: myNumber with: newIdentities)!
*/
}

public static Heaper make(PromiseManager pm, IntegerVar number, FeEdition target) {
throw new UnsupportedOperationException();/*
udanax-top.st:19622:CommFillRangeDetector class methodsFor: 'creation'!
make: pm {PromiseManager} with: number {IntegerVar} with: target {FeEdition}
	^self create: pm with: number with: target!
*/
}
}
