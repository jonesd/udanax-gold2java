/*
 * Abora-Gold
 * Part of the Abora hypertext project: http://www.abora.org
 * Copyright 2003 David G Jones
 * 
 * Translated from Udanax-Gold source code: http://www.udanax.com
 * Copyright 1979-1999 Udanax.com. All rights reserved
 */
package org.abora.gold.proman;

import org.abora.gold.be.basic.ID;
import org.abora.gold.detect.FeRevisionDetector;
import org.abora.gold.java.missing.IntegerVar;
import org.abora.gold.nkernel.FeEdition;
import org.abora.gold.nkernel.FeWork;
import org.abora.gold.proman.PromiseManager;
import org.abora.gold.xpp.basic.Heaper;


/**
 * Send the detector events over comm.
 */
public class CommRevisionDetector extends FeRevisionDetector {
	protected PromiseManager myManager;
	protected IntegerVar myNumber;
	protected FeWork myTarget;
/*
udanax-top.st:19704:
FeRevisionDetector subclass: #CommRevisionDetector
	instanceVariableNames: '
		myManager {PromiseManager}
		myNumber {IntegerVar}
		myTarget {FeWork}'
	classVariableNames: ''
	poolDictionaries: ''
	category: 'Xanadu-proman'!
*/
/*
udanax-top.st:19711:
CommRevisionDetector comment:
'Send the detector events over comm.'!
*/
/*
udanax-top.st:19713:
(CommRevisionDetector getOrMakeCxxClassDescription)
	attributes: ((Set new) add: #CONCRETE; yourself)!
*/
/*
udanax-top.st:19747:
CommRevisionDetector class
	instanceVariableNames: ''!
*/
/*
udanax-top.st:19750:
(CommRevisionDetector getOrMakeCxxClassDescription)
	attributes: ((Set new) add: #CONCRETE; yourself)!
*/

public  CommRevisionDetector(PromiseManager pm, IntegerVar number, FeWork target) {
throw new UnsupportedOperationException();/*
udanax-top.st:19718:CommRevisionDetector methodsFor: 'creation'!
create: pm {PromiseManager} with: number {IntegerVar} with: target {FeWork}
	super create.
	myManager _ pm.
	myNumber _ number.
	myTarget _ target!
*/
}

/**
 * Essential. The Work has been revised. Gives the Work, the current Edition, the
 * author ID who had it grabbed, the sequence number of the revision to the
 * Work, and the clock time on the Server (note that the clock time is only as
 * reliable as the Server's operating system, which is usually not very).
 */
public void revised(FeWork work, FeEdition contents, ID author, IntegerVar time, IntegerVar sequence) {
throw new UnsupportedOperationException();/*
udanax-top.st:19726:CommRevisionDetector methodsFor: 'triggering'!
{void} revised: work {FeWork}
	with: contents {FeEdition}
	with: author {ID}
	with: time {IntegerVar}
	with: sequence {IntegerVar}
	
	"Essential. The Work has been revised. Gives the Work, the current Edition, the 
	author ID who had it grabbed, the sequence number of the revision to the 
	Work, and the clock time on the Server (note that the clock time is only as 
	reliable as the Server's operating system, which is usually not very)."
	myManager queueDetectorEvent: 
		(RevisedEvent
			make: myNumber
			with: work
			with: contents
			with: author
			with: time
			with: sequence)!
*/
}

public static Heaper make(PromiseManager pm, IntegerVar number, FeWork target) {
throw new UnsupportedOperationException();/*
udanax-top.st:19755:CommRevisionDetector class methodsFor: 'creation'!
make: pm {PromiseManager} with: number {IntegerVar} with: target {FeWork}
	^self create: pm with: number with: target!
*/
}
}
