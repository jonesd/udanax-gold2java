/*
 * Abora-Gold
 * Part of the Abora hypertext project: http://www.abora.org
 * Copyright 2003 David G Jones
 * 
 * Translated from Udanax-Gold source code: http://www.udanax.com
 * Copyright 1979-1999 Udanax.com. All rights reserved
 */
package org.abora.gold.proman;

import org.abora.gold.java.missing.IntegerVar;
import org.abora.gold.proman.DetectorEvent;
import org.abora.gold.proman.PromiseManager;
import org.abora.gold.xpp.basic.Heaper;


public class RevisedEvent extends DetectorEvent {
	protected Heaper myWork;
	protected Heaper myContents;
	protected Heaper myAuthor;
	protected IntegerVar myTime;
	protected IntegerVar mySequence;
/*
udanax-top.st:16147:
DetectorEvent subclass: #RevisedEvent
	instanceVariableNames: '
		myWork {Heaper}
		myContents {Heaper}
		myAuthor {Heaper}
		myTime {IntegerVar}
		mySequence {IntegerVar}'
	classVariableNames: ''
	poolDictionaries: ''
	category: 'Xanadu-proman'!
*/
/*
udanax-top.st:16156:
(RevisedEvent getOrMakeCxxClassDescription)
	attributes: ((Set new) add: #CONCRETE; add: #NOT.A.TYPE; yourself)!
*/
/*
udanax-top.st:16191:
RevisedEvent class
	instanceVariableNames: ''!
*/
/*
udanax-top.st:16194:
(RevisedEvent getOrMakeCxxClassDescription)
	attributes: ((Set new) add: #CONCRETE; add: #NOT.A.TYPE; yourself)!
*/

public  RevisedEvent(IntegerVar detector, Heaper work, Heaper contents, Heaper author, IntegerVar time, IntegerVar sequence) {
	super(detector);
throw new UnsupportedOperationException();/*
udanax-top.st:16161:RevisedEvent methodsFor: 'creation'!
create: detector {IntegerVar} 
	with: work {Heaper}
	with: contents {Heaper}
	with: author {Heaper}
	with: time {IntegerVar}
	with: sequence {IntegerVar}
	
	super create: detector.
	myWork _ work.
	myContents _ contents.
	myAuthor _ author.
	myTime _ time.
	mySequence _ sequence!
*/
}

/**
 * Send the message across the wire.
 */
public void trigger(PromiseManager pm) {
throw new UnsupportedOperationException();/*
udanax-top.st:16177:RevisedEvent methodsFor: 'triggering'!
{void} trigger: pm {PromiseManager}
	"Send the message across the wire."
	
	pm sendResponse: PromiseManager revisedResponse.
	pm sendIntegerVar: self detector.
	pm sendPromise: myWork.
	pm sendPromise: myContents.
	pm sendPromise: myAuthor.
	pm sendIntegerVar: myTime.
	pm sendPromise: (PrimIntValue make: myTime).
	pm sendIntegerVar: mySequence.
	pm sendPromise: (PrimIntValue make: mySequence)!
*/
}

public static Heaper make(IntegerVar detector, Heaper work, Heaper contents, Heaper author, IntegerVar time, IntegerVar sequence) {
throw new UnsupportedOperationException();/*
udanax-top.st:16199:RevisedEvent class methodsFor: 'creation'!
{DetectorEvent} make: detector {IntegerVar} 
	with: work {Heaper}
	with: contents {Heaper}
	with: author {Heaper}
	with: time {IntegerVar}
	with: sequence {IntegerVar}
	
	^ self create: detector 
		with: work
		with: contents
		with: author
		with: time
		with: sequence!
*/
}
}
