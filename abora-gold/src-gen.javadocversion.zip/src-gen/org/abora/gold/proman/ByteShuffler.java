/*
 * Abora-Gold
 * Part of the Abora hypertext project: http://www.abora.org
 * Copyright 2003 David G Jones
 * 
 * Translated from Udanax-Gold source code: http://www.udanax.com
 * Copyright 1979-1999 Udanax.com. All rights reserved
 */
package org.abora.gold.proman;

import org.abora.gold.java.missing.VoidStar;
import org.abora.gold.proman.ByteShuffler;
import org.abora.gold.xpp.basic.Heaper;


/**
 * Instances shuffle bytes to convert between byte sexes.  Subclasses are defined for each of
 * the various transformations.
 */
public class ByteShuffler extends Heaper {
/*
udanax-top.st:12941:
Heaper subclass: #ByteShuffler
	instanceVariableNames: ''
	classVariableNames: ''
	poolDictionaries: ''
	category: 'Xanadu-proman'!
*/
/*
udanax-top.st:12945:
ByteShuffler comment:
'Instances shuffle bytes to convert between byte sexes.  Subclasses are defined for each of the various transformations.'!
*/
/*
udanax-top.st:12947:
(ByteShuffler getOrMakeCxxClassDescription)
	attributes: ((Set new) add: #DEFERRED; yourself)!
*/

/**
 * Return a shuffler that inverts the receiver's shuffler.  This will typically be the same
 * transformation.
 */
public ByteShuffler inverse() {
throw new UnsupportedOperationException();/*
udanax-top.st:12952:ByteShuffler methodsFor: 'shuffle'!
{ByteShuffler} inverse
	"Return a shuffler that inverts the receiver's shuffler.  This will typically be the same transformation."
	
	^self!
*/
}

/**
 * Go from one byte sex to another for representing numbers of the specified precision.
 */
public void shuffle(int precision, VoidStar buffer, int size) {
throw new UnsupportedOperationException();/*
udanax-top.st:12957:ByteShuffler methodsFor: 'shuffle'!
{void} shuffle: precision {Int32} with: buffer {void star} with: size {Int32}
	"Go from one byte sex to another for representing numbers of the specified precision."
	
	precision == 8 ifTrue: [^VOID].
	precision == 16 ifTrue: [self shuffle16: buffer with: size. ^VOID].
	precision == 32 ifTrue: [self shuffle32: buffer with: size. ^VOID].
	precision == 64 ifTrue: [self shuffle64: buffer with: size. ^VOID].
	Heaper BLAST: #BadPrecision!
*/
}

/**
 * Go from one byte sex to another for representing 16 bit numbers.
 */
public void shuffle16(VoidStar buffer, int count) {
throw new UnsupportedOperationException();/*
udanax-top.st:12968:ByteShuffler methodsFor: 'private: shuffle'!
{void} shuffle16: buffer {void star} with: count {Int32}
	"Go from one byte sex to another for representing 16 bit numbers."
	
	self subclassResponsibility!
*/
}

/**
 * Go from one byte sex to another for representing 32 bit numbers.
 */
public void shuffle32(VoidStar buffer, int count) {
throw new UnsupportedOperationException();/*
udanax-top.st:12973:ByteShuffler methodsFor: 'private: shuffle'!
{void} shuffle32: buffer {void star} with: count {Int32}
	"Go from one byte sex to another for representing 32 bit numbers."
	
	self subclassResponsibility!
*/
}

/**
 * Go from one byte sex to another for representing 64 bit numbers.
 */
public void shuffle64(VoidStar buffer, int count) {
throw new UnsupportedOperationException();/*
udanax-top.st:12978:ByteShuffler methodsFor: 'private: shuffle'!
{void} shuffle64: buffer {void star} with: count {Int32}
	"Go from one byte sex to another for representing 64 bit numbers."
	
	self subclassResponsibility!
*/
}

public int actualHashForEqual() {
throw new UnsupportedOperationException();/*
udanax-top.st:12985:ByteShuffler methodsFor: 'testing'!
{UInt32} actualHashForEqual
	^Heaper takeOop!
*/
}
}
