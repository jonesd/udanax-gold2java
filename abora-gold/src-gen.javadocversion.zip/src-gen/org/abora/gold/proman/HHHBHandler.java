/*
 * Abora-Gold
 * Part of the Abora hypertext project: http://www.abora.org
 * Copyright 2003 David G Jones
 * 
 * Translated from Udanax-Gold source code: http://www.udanax.com
 * Copyright 1979-1999 Udanax.com. All rights reserved
 */
package org.abora.gold.proman;

import org.abora.gold.java.missing.handle.HHHBFn;
import org.abora.gold.proman.PromiseManager;
import org.abora.gold.proman.RequestHandler;
import org.abora.gold.xpp.basic.Category;
import org.abora.gold.xpp.basic.Heaper;


public class HHHBHandler extends RequestHandler {
	protected HHHBFn myFn;
	protected Category myType1;
	protected Category myType2;
/*
udanax-top.st:43853:
RequestHandler subclass: #HHHBHandler
	instanceVariableNames: '
		myFn {HHHBFn var}
		myType1 {Category}
		myType2 {Category}'
	classVariableNames: ''
	poolDictionaries: ''
	category: 'Xanadu-proman'!
*/
/*
udanax-top.st:43860:
(HHHBHandler getOrMakeCxxClassDescription)
	attributes: ((Set new) add: #CONCRETE; add: #NOT.A.TYPE; yourself)!
*/
/*
udanax-top.st:43883:
HHHBHandler class
	instanceVariableNames: ''!
*/
/*
udanax-top.st:43886:
(HHHBHandler getOrMakeCxxClassDescription)
	attributes: ((Set new) add: #CONCRETE; add: #NOT.A.TYPE; yourself)!
*/

public void handleRequest(PromiseManager pm) {
throw new UnsupportedOperationException();/*
udanax-top.st:43865:HHHBHandler methodsFor: 'request handling'!
{void} handleRequest: pm {PromiseManager}
	
	| arg1 {Heaper} arg2 {Heaper} arg3 {BooleanVar} |
	arg1 _ pm fetchNonNullHeaper: myType1.
	arg2 _ pm fetchNonNullHeaper: myType2.
	arg3 _ pm fetchBooleanVar.
	pm noErrors ifTrue:
		[pm respondHeaper: (myFn invokeFunction: arg1 with: arg2 with: arg3)]!
*/
}

public  HHHBHandler(HHHBFn fn, Category type1, Category type2) {
throw new UnsupportedOperationException();/*
udanax-top.st:43876:HHHBHandler methodsFor: 'creation'!
create: fn {HHHBFn var} with: type1 {Category} with: type2 {Category}
	super create.
	myFn _ fn.
	myType1 _ type1.
	myType2 _ type2.!
*/
}

public static Heaper make(HHHBFn fn, Category type1, Category type2) {
throw new UnsupportedOperationException();/*
udanax-top.st:43891:HHHBHandler class methodsFor: 'creation'!
{RequestHandler} make: fn {HHHBFn var} with: type1 {Category} with: type2 {Category}
	^self create: fn with: type1 with: type2!
*/
}

public static void isGenerated() {
throw new UnsupportedOperationException();/*
udanax-top.st:43896:HHHBHandler class methodsFor: 'generated:'!
isGenerated ^true!
*/
}
}
