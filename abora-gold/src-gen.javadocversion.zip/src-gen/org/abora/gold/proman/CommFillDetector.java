/*
 * Abora-Gold
 * Part of the Abora hypertext project: http://www.abora.org
 * Copyright 2003 David G Jones
 * 
 * Translated from Udanax-Gold source code: http://www.udanax.com
 * Copyright 1979-1999 Udanax.com. All rights reserved
 */
package org.abora.gold.proman;

import org.abora.gold.detect.FeFillDetector;
import org.abora.gold.java.missing.IntegerVar;
import org.abora.gold.nkernel.FeRangeElement;
import org.abora.gold.proman.PromiseManager;
import org.abora.gold.xpp.basic.Heaper;


/**
 * Send the detector events over comm.
 */
public class CommFillDetector extends FeFillDetector {
	protected PromiseManager myManager;
	protected IntegerVar myNumber;
	protected FeRangeElement myTarget;
/*
udanax-top.st:19466:
FeFillDetector subclass: #CommFillDetector
	instanceVariableNames: '
		myManager {PromiseManager}
		myNumber {IntegerVar}
		myTarget {FeRangeElement}'
	classVariableNames: ''
	poolDictionaries: ''
	category: 'Xanadu-proman'!
*/
/*
udanax-top.st:19473:
CommFillDetector comment:
'Send the detector events over comm.'!
*/
/*
udanax-top.st:19475:
(CommFillDetector getOrMakeCxxClassDescription)
	attributes: ((Set new) add: #CONCRETE; yourself)!
*/
/*
udanax-top.st:19494:
CommFillDetector class
	instanceVariableNames: ''!
*/
/*
udanax-top.st:19497:
(CommFillDetector getOrMakeCxxClassDescription)
	attributes: ((Set new) add: #CONCRETE; yourself)!
*/

public  CommFillDetector(PromiseManager pm, IntegerVar number, FeRangeElement target) {
throw new UnsupportedOperationException();/*
udanax-top.st:19480:CommFillDetector methodsFor: 'creation'!
create: pm {PromiseManager} with: number {IntegerVar} with: target {FeRangeElement}
	super create.
	myManager _ pm.
	myNumber _ number.
	myTarget _ target!
*/
}

/**
 * A single PlaceHolder has been filled to become another kind of RangeElement
 */
public void filled(FeRangeElement newIdentity) {
throw new UnsupportedOperationException();/*
udanax-top.st:19488:CommFillDetector methodsFor: 'triggering'!
{void} filled: newIdentity {FeRangeElement}
	"A single PlaceHolder has been filled to become another kind of RangeElement"
	
	myManager queueDetectorEvent: (FilledEvent make: myNumber with: newIdentity)!
*/
}

public static Heaper make(PromiseManager pm, IntegerVar number, FeRangeElement target) {
throw new UnsupportedOperationException();/*
udanax-top.st:19502:CommFillDetector class methodsFor: 'creation'!
make: pm {PromiseManager} with: number {IntegerVar} with: target {FeRangeElement}
	^self create: pm with: number with: target!
*/
}
}
