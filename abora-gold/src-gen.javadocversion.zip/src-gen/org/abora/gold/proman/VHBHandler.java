/*
 * Abora-Gold
 * Part of the Abora hypertext project: http://www.abora.org
 * Copyright 2003 David G Jones
 * 
 * Translated from Udanax-Gold source code: http://www.udanax.com
 * Copyright 1979-1999 Udanax.com. All rights reserved
 */
package org.abora.gold.proman;

import org.abora.gold.java.missing.handle.VHBFn;
import org.abora.gold.proman.PromiseManager;
import org.abora.gold.proman.RequestHandler;
import org.abora.gold.xpp.basic.Category;
import org.abora.gold.xpp.basic.Heaper;


public class VHBHandler extends RequestHandler {
	protected VHBFn myFn;
	protected Category myType1;
/*
udanax-top.st:44179:
RequestHandler subclass: #VHBHandler
	instanceVariableNames: '
		myFn {VHBFn var}
		myType1 {Category}'
	classVariableNames: ''
	poolDictionaries: ''
	category: 'Xanadu-proman'!
*/
/*
udanax-top.st:44185:
(VHBHandler getOrMakeCxxClassDescription)
	attributes: ((Set new) add: #CONCRETE; add: #NOT.A.TYPE; yourself)!
*/
/*
udanax-top.st:44207:
VHBHandler class
	instanceVariableNames: ''!
*/
/*
udanax-top.st:44210:
(VHBHandler getOrMakeCxxClassDescription)
	attributes: ((Set new) add: #CONCRETE; add: #NOT.A.TYPE; yourself)!
*/

public void handleRequest(PromiseManager pm) {
throw new UnsupportedOperationException();/*
udanax-top.st:44190:VHBHandler methodsFor: 'request handling'!
{void} handleRequest: pm {PromiseManager}
	
	| arg1 {Heaper} arg2 {BooleanVar} |
	arg1 _ pm fetchNonNullHeaper: myType1.
	arg2 _ pm fetchBooleanVar.
	pm noErrors ifTrue:
		[(myFn invokeFunction: arg1 with: arg2).
		pm respondVoid]!
*/
}

public  VHBHandler(VHBFn fn, Category type1) {
throw new UnsupportedOperationException();/*
udanax-top.st:44201:VHBHandler methodsFor: 'creation'!
create: fn {VHBFn var} with: type1 {Category}
	super create.
	myFn _ fn.
	myType1 _ type1.!
*/
}

public static Heaper make(VHBFn fn, Category type1) {
throw new UnsupportedOperationException();/*
udanax-top.st:44215:VHBHandler class methodsFor: 'creation'!
{RequestHandler} make: fn {VHBFn var} with: type1 {Category}
	^self create: fn with: type1!
*/
}

public static void isGenerated() {
throw new UnsupportedOperationException();/*
udanax-top.st:44220:VHBHandler class methodsFor: 'generated:'!
isGenerated ^true!
*/
}
}
