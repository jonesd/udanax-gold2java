/*
 * Abora-Gold
 * Part of the Abora hypertext project: http://www.abora.org
 * Copyright 2003 David G Jones
 * 
 * Translated from Udanax-Gold source code: http://www.udanax.com
 * Copyright 1979-1999 Udanax.com. All rights reserved
 */
package org.abora.gold.proman;

import org.abora.gold.java.missing.VoidStar;
import org.abora.gold.proman.ByteShuffler;


/**
 * No transformation.
 */
public class NoShuffler extends ByteShuffler {
/*
udanax-top.st:12988:
ByteShuffler subclass: #NoShuffler
	instanceVariableNames: ''
	classVariableNames: ''
	poolDictionaries: ''
	category: 'Xanadu-proman'!
*/
/*
udanax-top.st:12992:
NoShuffler comment:
'No transformation.'!
*/
/*
udanax-top.st:12994:
(NoShuffler getOrMakeCxxClassDescription)
	attributes: ((Set new) add: #CONCRETE; yourself)!
*/

/**
 * Do nothing.
 */
public void shuffle16(VoidStar buffer, int count) {
throw new UnsupportedOperationException();/*
udanax-top.st:12999:NoShuffler methodsFor: 'shuffle'!
{void} shuffle16: buffer {void star} with: count {Int32}
	"Do nothing."!
*/
}

/**
 * Do nothing.
 */
public void shuffle32(VoidStar buffer, int count) {
throw new UnsupportedOperationException();/*
udanax-top.st:13002:NoShuffler methodsFor: 'shuffle'!
{void} shuffle32: buffer {void star} with: count {Int32}
	"Do nothing."!
*/
}

/**
 * Do nothing.
 */
public void shuffle64(VoidStar buffer, int count) {
throw new UnsupportedOperationException();/*
udanax-top.st:13005:NoShuffler methodsFor: 'shuffle'!
{void} shuffle64: buffer {void star} with: count {Int32}
	"Do nothing."!
*/
}
}
