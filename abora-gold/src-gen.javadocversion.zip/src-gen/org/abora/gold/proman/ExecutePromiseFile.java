/*
 * Abora-Gold
 * Part of the Abora hypertext project: http://www.abora.org
 * Copyright 2003 David G Jones
 * 
 * Translated from Udanax-Gold source code: http://www.udanax.com
 * Copyright 1979-1999 Udanax.com. All rights reserved
 */
package org.abora.gold.proman;

import org.abora.gold.cobbler.Connection;
import org.abora.gold.proman.PromiseManager;
import org.abora.gold.rcmain.ServerChunk;
import org.abora.gold.xcvr.Rcvr;
import org.abora.gold.xcvr.Xmtr;


/**
 * Read client requests from one files and write the results to another file.
 */
public class ExecutePromiseFile extends ServerChunk {
	protected char myReadName;
	protected char myWriteName;
	protected PromiseManager myManager;
	protected Connection myConnection;
/*
udanax-top.st:50782:
ServerChunk subclass: #ExecutePromiseFile
	instanceVariableNames: '
		myReadName {char star}
		myWriteName {char star}
		myManager {PromiseManager NOCOPY}
		myConnection {Connection NOCOPY}'
	classVariableNames: ''
	poolDictionaries: ''
	category: 'Xanadu-proman'!
*/
/*
udanax-top.st:50790:
ExecutePromiseFile comment:
'Read client requests from one files and write the results to another file.'!
*/
/*
udanax-top.st:50792:
(ExecutePromiseFile getOrMakeCxxClassDescription)
	attributes: ((Set new) add: #CONCRETE; add: #(COPY boot ); yourself)!
*/

/**
 * Execute the action defined by this thunk.
 */
public boolean execute() {
throw new UnsupportedOperationException();/*
udanax-top.st:50797:ExecutePromiseFile methodsFor: 'operate'!
{BooleanVar} execute
	"Execute the action defined by this thunk."
	myManager handleRequest.
	self thingToDo.  "Check whether the read file is Empty."
	^true!
*/
}

public void restartPromises(Rcvr rcvr) {
throw new UnsupportedOperationException();/*
udanax-top.st:50806:ExecutePromiseFile methodsFor: 'hooks:'!
{void RECEIVE.HOOK} restartPromises: rcvr {Rcvr unused}
	| readStream {XnReadStream} writeStream {XnWriteStream} |
	readStream _ XnReadFile make: myReadName.
	writeStream _ XnWriteFile make: myWriteName.
	myManager _ PromiseManager make: (PairPortal make: readStream with: writeStream).
	myConnection _ Connection make: FeServer.  self thingToDo.  "This should be unnecessary."!
*/
}

public  ExecutePromiseFile(Rcvr receiver) {
throw new UnsupportedOperationException();/*
udanax-top.st:50815:ExecutePromiseFile methodsFor: 'generated:'!
create.Rcvr: receiver {Rcvr}
	super create.Rcvr: receiver.
	myReadName _ receiver receiveString.
	myWriteName _ receiver receiveString.
	self restartPromises: receiver.!
*/
}

public void sendSelfTo(Xmtr xmtr) {
throw new UnsupportedOperationException();/*
udanax-top.st:50821:ExecutePromiseFile methodsFor: 'generated:'!
{void} sendSelfTo: xmtr {Xmtr}
	super sendSelfTo: xmtr.
	xmtr sendString: myReadName.
	xmtr sendString: myWriteName.!
*/
}
}
