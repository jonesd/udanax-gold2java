/*
 * Abora-Gold
 * Part of the Abora hypertext project: http://www.abora.org
 * Copyright 2003 David G Jones
 * 
 * Translated from Udanax-Gold source code: http://www.udanax.com
 * Copyright 1979-1999 Udanax.com. All rights reserved
 */
package org.abora.gold.proman;

import org.abora.gold.java.missing.handle.VHFn;
import org.abora.gold.proman.PromiseManager;
import org.abora.gold.proman.RequestHandler;
import org.abora.gold.xpp.basic.Heaper;


public class SpecialHandler extends RequestHandler {
	protected VHFn myFn;
/*
udanax-top.st:44148:
RequestHandler subclass: #SpecialHandler
	instanceVariableNames: 'myFn {VHFn var}'
	classVariableNames: ''
	poolDictionaries: ''
	category: 'Xanadu-proman'!
*/
/*
udanax-top.st:44152:
(SpecialHandler getOrMakeCxxClassDescription)
	attributes: ((Set new) add: #CONCRETE; add: #NOT.A.TYPE; yourself)!
*/
/*
udanax-top.st:44168:
SpecialHandler class
	instanceVariableNames: ''!
*/
/*
udanax-top.st:44171:
(SpecialHandler getOrMakeCxxClassDescription)
	attributes: ((Set new) add: #CONCRETE; add: #NOT.A.TYPE; yourself)!
*/

public void handleRequest(PromiseManager pm) {
throw new UnsupportedOperationException();/*
udanax-top.st:44157:SpecialHandler methodsFor: 'request handling'!
{void} handleRequest: pm {PromiseManager}
	myFn invokeFunction: pm!
*/
}

public  SpecialHandler(VHFn fn) {
throw new UnsupportedOperationException();/*
udanax-top.st:44163:SpecialHandler methodsFor: 'creation'!
create: fn {VHFn var}
	super create.
	myFn _ fn.!
*/
}

public static Heaper make(VHFn fn) {
throw new UnsupportedOperationException();/*
udanax-top.st:44176:SpecialHandler class methodsFor: 'creation'!
{RequestHandler} make: fn {VHFn var}
	^ self create: fn!
*/
}
}
