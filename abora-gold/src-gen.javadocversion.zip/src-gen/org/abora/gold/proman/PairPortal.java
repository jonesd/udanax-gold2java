/*
 * Abora-Gold
 * Part of the Abora hypertext project: http://www.abora.org
 * Copyright 2003 David G Jones
 * 
 * Translated from Udanax-Gold source code: http://www.udanax.com
 * Copyright 1979-1999 Udanax.com. All rights reserved
 */
package org.abora.gold.proman;

import org.abora.gold.proman.Portal;
import org.abora.gold.xcvr.XnReadStream;
import org.abora.gold.xcvr.XnWriteStream;
import org.abora.gold.xpp.basic.Heaper;


public class PairPortal extends Portal {
	protected XnReadStream myReadStream;
	protected XnWriteStream myWriteStream;
/*
udanax-top.st:31425:
Portal subclass: #PairPortal
	instanceVariableNames: '
		myReadStream {XnReadStream}
		myWriteStream {XnWriteStream}'
	classVariableNames: ''
	poolDictionaries: ''
	category: 'Xanadu-proman'!
*/
/*
udanax-top.st:31431:
(PairPortal getOrMakeCxxClassDescription)
	attributes: ((Set new) add: #CONCRETE; yourself)!
*/
/*
udanax-top.st:31457:
PairPortal class
	instanceVariableNames: ''!
*/
/*
udanax-top.st:31460:
(PairPortal getOrMakeCxxClassDescription)
	attributes: ((Set new) add: #CONCRETE; yourself)!
*/

public XnReadStream readStream() {
throw new UnsupportedOperationException();/*
udanax-top.st:31436:PairPortal methodsFor: 'accessing'!
{XnReadStream} readStream
	
	^myReadStream!
*/
}

public XnWriteStream writeStream() {
throw new UnsupportedOperationException();/*
udanax-top.st:31440:PairPortal methodsFor: 'accessing'!
{XnWriteStream} writeStream
	
	^myWriteStream!
*/
}

public  PairPortal(XnReadStream readStr, XnWriteStream writeStr) {
throw new UnsupportedOperationException();/*
udanax-top.st:31446:PairPortal methodsFor: 'protected: creation'!
create: readStr {XnReadStream} with: writeStr {XnWriteStream}
	super create.
	myReadStream _ readStr.
	myWriteStream _ writeStr!
*/
}

public void destruct() {
throw new UnsupportedOperationException();/*
udanax-top.st:31451:PairPortal methodsFor: 'protected: creation'!
{void} destruct
	myReadStream destroy.
	myWriteStream destroy.
	super destruct!
*/
}

public static Heaper make(XnReadStream read, XnWriteStream write) {
throw new UnsupportedOperationException();/*
udanax-top.st:31465:PairPortal class methodsFor: 'creation'!
make: read {XnReadStream} with: write {XnWriteStream}
	^self create: read with: write!
*/
}
}
