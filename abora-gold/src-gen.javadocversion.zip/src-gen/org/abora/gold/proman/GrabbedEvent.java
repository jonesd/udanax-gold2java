/*
 * Abora-Gold
 * Part of the Abora hypertext project: http://www.abora.org
 * Copyright 2003 David G Jones
 * 
 * Translated from Udanax-Gold source code: http://www.udanax.com
 * Copyright 1979-1999 Udanax.com. All rights reserved
 */
package org.abora.gold.proman;

import org.abora.gold.java.missing.IntegerVar;
import org.abora.gold.proman.DetectorEvent;
import org.abora.gold.proman.PromiseManager;
import org.abora.gold.xpp.basic.Heaper;


public class GrabbedEvent extends DetectorEvent {
	protected Heaper myWork;
	protected Heaper myAuthor;
	protected IntegerVar myReason;
/*
udanax-top.st:16032:
DetectorEvent subclass: #GrabbedEvent
	instanceVariableNames: '
		myWork {Heaper}
		myAuthor {Heaper}
		myReason {IntegerVar}'
	classVariableNames: ''
	poolDictionaries: ''
	category: 'Xanadu-proman'!
*/
/*
udanax-top.st:16039:
(GrabbedEvent getOrMakeCxxClassDescription)
	attributes: ((Set new) add: #CONCRETE; add: #NOT.A.TYPE; yourself)!
*/
/*
udanax-top.st:16063:
GrabbedEvent class
	instanceVariableNames: ''!
*/
/*
udanax-top.st:16066:
(GrabbedEvent getOrMakeCxxClassDescription)
	attributes: ((Set new) add: #CONCRETE; add: #NOT.A.TYPE; yourself)!
*/

/**
 * Send the message across the wire.
 */
public void trigger(PromiseManager pm) {
throw new UnsupportedOperationException();/*
udanax-top.st:16044:GrabbedEvent methodsFor: 'triggering'!
{void} trigger: pm {PromiseManager}
	"Send the message across the wire."
	
	pm sendResponse: PromiseManager grabbedResponse.
	pm sendIntegerVar: self detector.
	pm sendPromise: myWork.
	pm sendPromise: myAuthor.
	pm sendIntegerVar: myReason.
	pm sendPromise: (PrimIntValue make: myReason)!
*/
}

public  GrabbedEvent(IntegerVar detector, Heaper work, Heaper author, IntegerVar reason) {
	super(detector);
throw new UnsupportedOperationException();/*
udanax-top.st:16056:GrabbedEvent methodsFor: 'creation'!
create: detector {IntegerVar} with: work {Heaper} with: author {Heaper} with: reason {IntegerVar}
	super create: detector.
	myWork _ work.
	myAuthor _ author.
	myReason _ reason!
*/
}

public static Heaper make(IntegerVar detector, Heaper work, Heaper author, IntegerVar reason) {
throw new UnsupportedOperationException();/*
udanax-top.st:16071:GrabbedEvent class methodsFor: 'creation'!
{DetectorEvent} make: detector {IntegerVar} with: work {Heaper} with: author {Heaper} with: reason {IntegerVar}
	^self create: detector with: work with: author  with: reason!
*/
}
}
