/*
 * Abora-Gold
 * Part of the Abora hypertext project: http://www.abora.org
 * Copyright 2003 David G Jones
 * 
 * Translated from Udanax-Gold source code: http://www.udanax.com
 * Copyright 1979-1999 Udanax.com. All rights reserved
 */
package org.abora.gold.proman;

import org.abora.gold.java.missing.IntegerVar;
import org.abora.gold.proman.DetectorEvent;
import org.abora.gold.proman.PromiseManager;
import org.abora.gold.xpp.basic.Heaper;


public class FilledEvent extends DetectorEvent {
	protected Heaper myFilling;
/*
udanax-top.st:15998:
DetectorEvent subclass: #FilledEvent
	instanceVariableNames: 'myFilling {Heaper}'
	classVariableNames: ''
	poolDictionaries: ''
	category: 'Xanadu-proman'!
*/
/*
udanax-top.st:16002:
(FilledEvent getOrMakeCxxClassDescription)
	attributes: ((Set new) add: #CONCRETE; add: #NOT.A.TYPE; yourself)!
*/
/*
udanax-top.st:16021:
FilledEvent class
	instanceVariableNames: ''!
*/
/*
udanax-top.st:16024:
(FilledEvent getOrMakeCxxClassDescription)
	attributes: ((Set new) add: #CONCRETE; add: #NOT.A.TYPE; yourself)!
*/

/**
 * Send the message across the wire.
 */
public void trigger(PromiseManager pm) {
throw new UnsupportedOperationException();/*
udanax-top.st:16007:FilledEvent methodsFor: 'triggering'!
{void} trigger: pm {PromiseManager}
	"Send the message across the wire."
	
	pm sendResponse: PromiseManager filledResponse.
	pm sendIntegerVar: self detector.
	pm sendPromise: myFilling!
*/
}

public  FilledEvent(IntegerVar detector, Heaper filling) {
	super(detector);
throw new UnsupportedOperationException();/*
udanax-top.st:16016:FilledEvent methodsFor: 'creation'!
create: detector {IntegerVar} with: filling {Heaper}
	super create: detector.
	myFilling _ filling!
*/
}

public static Heaper make(IntegerVar detector, Heaper filling) {
throw new UnsupportedOperationException();/*
udanax-top.st:16029:FilledEvent class methodsFor: 'creation'!
{DetectorEvent} make: detector {IntegerVar} with: filling {Heaper}
	^ self create: detector with: filling!
*/
}
}
