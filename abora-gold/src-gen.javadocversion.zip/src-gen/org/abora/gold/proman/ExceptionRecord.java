/*
 * Abora-Gold
 * Part of the Abora hypertext project: http://www.abora.org
 * Copyright 2003 David G Jones
 * 
 * Translated from Udanax-Gold source code: http://www.udanax.com
 * Copyright 1979-1999 Udanax.com. All rights reserved
 */
package org.abora.gold.proman;

import java.io.PrintWriter;
import org.abora.gold.java.missing.IntegerVar;
import org.abora.gold.proman.ExceptionRecord;
import org.abora.gold.xpp.basic.Heaper;


/**
 * myPromise is the number of the promise that caused this error.  It will be the excuse for
 * an Excused promise.
 */
public class ExceptionRecord extends Heaper {
	protected IntegerVar myPromise;
	protected int myError;
/*
udanax-top.st:18865:
Heaper subclass: #ExceptionRecord
	instanceVariableNames: '
		myPromise {IntegerVar}
		myError {Int32}'
	classVariableNames: ''
	poolDictionaries: ''
	category: 'Xanadu-proman'!
*/
/*
udanax-top.st:18871:
ExceptionRecord comment:
'myPromise is the number of the promise that caused this error.  It will be the excuse for an Excused promise.'!
*/
/*
udanax-top.st:18873:
(ExceptionRecord getOrMakeCxxClassDescription)
	attributes: ((Set new) add: #CONCRETE; yourself)!
*/
/*
udanax-top.st:18916:
ExceptionRecord class
	instanceVariableNames: ''!
*/
/*
udanax-top.st:18919:
(ExceptionRecord getOrMakeCxxClassDescription)
	attributes: ((Set new) add: #CONCRETE; yourself)!
*/

/**
 * Return the error most useful to the client for figuring out what happened.  This returns
 * the earliest cause of an error (typically a broken promise.
 */
public ExceptionRecord best(ExceptionRecord rec) {
throw new UnsupportedOperationException();/*
udanax-top.st:18878:ExceptionRecord methodsFor: 'accessing'!
{ExceptionRecord} best: rec {ExceptionRecord | NULL}
	"Return the error most useful to the client for figuring out what happened.  This returns the earliest cause of an error (typically a broken promise."
	
	rec == NULL ifTrue: [^self].
	rec promise <= myPromise ifTrue: [^rec].
	^self!
*/
}

public int error() {
throw new UnsupportedOperationException();/*
udanax-top.st:18885:ExceptionRecord methodsFor: 'accessing'!
{Int32} error
	^myError!
*/
}

public boolean isExcused() {
throw new UnsupportedOperationException();/*
udanax-top.st:18888:ExceptionRecord methodsFor: 'accessing'!
{BooleanVar} isExcused
	^myError == ExceptionRecord excused!
*/
}

public IntegerVar promise() {
throw new UnsupportedOperationException();/*
udanax-top.st:18891:ExceptionRecord methodsFor: 'accessing'!
{IntegerVar} promise
	^myPromise!
*/
}

public  ExceptionRecord(IntegerVar promise, int error) {
throw new UnsupportedOperationException();/*
udanax-top.st:18896:ExceptionRecord methodsFor: 'creation'!
create: promise {IntegerVar} with: error {Int32}
	super create.
	myPromise _ promise.
	myError _ error!
*/
}

public void printOn(PrintWriter oo) {
throw new UnsupportedOperationException();/*
udanax-top.st:18904:ExceptionRecord methodsFor: 'printing'!
{void} printOn: oo {ostream reference}
	oo << self getCategory name << '(' << myPromise.
	myError == ExceptionRecord excused ifTrue: [oo << ', excused)']
	ifFalse: [myError == ExceptionRecord typeMismatch ifTrue: [oo << ', typeMismatch)']
	ifFalse: [myError == ExceptionRecord badCategory ifTrue: [oo << ', badCategory)']]]!
*/
}

public int actualHashForEqual() {
throw new UnsupportedOperationException();/*
udanax-top.st:18912:ExceptionRecord methodsFor: 'testing'!
{UInt32} actualHashForEqual
	^Heaper takeOop!
*/
}

public static int badCategory() {
throw new UnsupportedOperationException();/*
udanax-top.st:18924:ExceptionRecord class methodsFor: 'constant'!
{Int32} badCategory
	^PromiseManager problemNumber: 'BAD_CATEGORY' "BLAST(BAD_CATEGORY)"!
*/
}

public static int excused() {
throw new UnsupportedOperationException();/*
udanax-top.st:18927:ExceptionRecord class methodsFor: 'constant'!
{Int32} excused
	^PromiseManager problemNumber: 'BROKEN_PROMISE' "BLAST(BROKEN_PROMISE)"!
*/
}

public static int typeMismatch() {
throw new UnsupportedOperationException();/*
udanax-top.st:18930:ExceptionRecord class methodsFor: 'constant'!
{Int32} typeMismatch
	^PromiseManager problemNumber: 'TYPE_MISMATCH' "BLAST(TYPE_MISMATCH)"!
*/
}

public static int wasNull() {
throw new UnsupportedOperationException();/*
udanax-top.st:18933:ExceptionRecord class methodsFor: 'constant'!
{Int32} wasNull
	^PromiseManager problemNumber: 'WAS_NULL' "BLAST(WAS_NULL)"!
*/
}

public static ExceptionRecord badCategory(IntegerVar promise) {
throw new UnsupportedOperationException();/*
udanax-top.st:18938:ExceptionRecord class methodsFor: 'creation'!
{ExceptionRecord} badCategory: promise {IntegerVar}
	^self create: promise with: self badCategory!
*/
}

public static ExceptionRecord excuse(IntegerVar promise) {
throw new UnsupportedOperationException();/*
udanax-top.st:18941:ExceptionRecord class methodsFor: 'creation'!
{ExceptionRecord} excuse: promise {IntegerVar}
	^self create: promise with: self excused!
*/
}

public static ExceptionRecord mismatch(IntegerVar promise) {
throw new UnsupportedOperationException();/*
udanax-top.st:18944:ExceptionRecord class methodsFor: 'creation'!
{ExceptionRecord} mismatch: promise {IntegerVar}
	^self create: promise with: self typeMismatch!
*/
}

public static ExceptionRecord wasNull(IntegerVar promise) {
throw new UnsupportedOperationException();/*
udanax-top.st:18947:ExceptionRecord class methodsFor: 'creation'!
{ExceptionRecord} wasNull: promise {IntegerVar}
	^self create: promise with: self wasNull!
*/
}
}
