/*
 * Abora-Gold
 * Part of the Abora hypertext project: http://www.abora.org
 * Copyright 2003 David G Jones
 * 
 * Translated from Udanax-Gold source code: http://www.udanax.com
 * Copyright 1979-1999 Udanax.com. All rights reserved
 */
package org.abora.gold.proman;

import org.abora.gold.java.missing.handle.HHFn;
import org.abora.gold.proman.PromiseManager;
import org.abora.gold.proman.RequestHandler;
import org.abora.gold.xpp.basic.Category;
import org.abora.gold.xpp.basic.Heaper;


public class HHHandler extends RequestHandler {
	protected HHFn myFn;
	protected Category myType1;
/*
udanax-top.st:43812:
RequestHandler subclass: #HHHandler
	instanceVariableNames: '
		myFn {HHFn var}
		myType1 {Category}'
	classVariableNames: ''
	poolDictionaries: ''
	category: 'Xanadu-proman'!
*/
/*
udanax-top.st:43818:
(HHHandler getOrMakeCxxClassDescription)
	attributes: ((Set new) add: #CONCRETE; add: #NOT.A.TYPE; yourself)!
*/
/*
udanax-top.st:43838:
HHHandler class
	instanceVariableNames: ''!
*/
/*
udanax-top.st:43841:
(HHHandler getOrMakeCxxClassDescription)
	attributes: ((Set new) add: #CONCRETE; add: #NOT.A.TYPE; yourself)!
*/

public void handleRequest(PromiseManager pm) {
throw new UnsupportedOperationException();/*
udanax-top.st:43823:HHHandler methodsFor: 'request handling'!
{void} handleRequest: pm {PromiseManager}
	
	| arg1 {Heaper} |
	arg1 _ pm fetchNonNullHeaper: myType1.
	pm noErrors ifTrue:
		[pm respondHeaper: (myFn invokeFunction: arg1)]!
*/
}

public  HHHandler(HHFn fn, Category type1) {
throw new UnsupportedOperationException();/*
udanax-top.st:43832:HHHandler methodsFor: 'creation'!
create: fn {HHFn var} with: type1 {Category}
	super create.
	myFn _ fn.
	myType1 _ type1.!
*/
}

public static Heaper make(HHFn fn, Category type1) {
throw new UnsupportedOperationException();/*
udanax-top.st:43846:HHHandler class methodsFor: 'creation'!
{RequestHandler} make: fn {HHFn var} with: type1 {Category}
	^self create: fn with: type1!
*/
}

public static void isGenerated() {
throw new UnsupportedOperationException();/*
udanax-top.st:43851:HHHandler class methodsFor: 'generated:'!
isGenerated ^true!
*/
}
}
