/*
 * Abora-Gold
 * Part of the Abora hypertext project: http://www.abora.org
 * Copyright 2003 David G Jones
 * 
 * Translated from Udanax-Gold source code: http://www.udanax.com
 * Copyright 1979-1999 Udanax.com. All rights reserved
 */
package org.abora.gold.proman;

import org.abora.gold.be.basic.ID;
import org.abora.gold.detect.FeStatusDetector;
import org.abora.gold.java.missing.IntegerVar;
import org.abora.gold.nkernel.FeWork;
import org.abora.gold.proman.PromiseManager;
import org.abora.gold.xpp.basic.Heaper;


/**
 * Send the detector events over comm.
 */
public class CommStatusDetector extends FeStatusDetector {
	protected PromiseManager myManager;
	protected IntegerVar myNumber;
	protected FeWork myTarget;
/*
udanax-top.st:19814:
FeStatusDetector subclass: #CommStatusDetector
	instanceVariableNames: '
		myManager {PromiseManager}
		myNumber {IntegerVar}
		myTarget {FeWork}'
	classVariableNames: ''
	poolDictionaries: ''
	category: 'Xanadu-proman'!
*/
/*
udanax-top.st:19821:
CommStatusDetector comment:
'Send the detector events over comm.'!
*/
/*
udanax-top.st:19823:
(CommStatusDetector getOrMakeCxxClassDescription)
	attributes: ((Set new) add: #CONCRETE; yourself)!
*/
/*
udanax-top.st:19856:
CommStatusDetector class
	instanceVariableNames: ''!
*/
/*
udanax-top.st:19859:
(CommStatusDetector getOrMakeCxxClassDescription)
	attributes: ((Set new) add: #CONCRETE; yourself)!
*/

public  CommStatusDetector(PromiseManager pm, IntegerVar number, FeWork target) {
throw new UnsupportedOperationException();/*
udanax-top.st:19828:CommStatusDetector methodsFor: 'creation'!
create: pm {PromiseManager} with: number {IntegerVar} with: target {FeWork}
	super create.
	myManager _ pm.
	myNumber _ number.
	myTarget _ target!
*/
}

/**
 * Essential. The Work has been grabbed, or regrabbed.
 */
public void grabbed(FeWork work, ID author, IntegerVar reason) {
throw new UnsupportedOperationException();/*
udanax-top.st:19836:CommStatusDetector methodsFor: 'triggering'!
{void} grabbed: work {FeWork} with: author {ID} with: reason {IntegerVar}
	"Essential. The Work has been grabbed, or regrabbed."
	
	myManager queueDetectorEvent: 
		(GrabbedEvent
			make: myNumber
			with: work
			with: author
			with: reason)!
*/
}

/**
 * Essential. The revise capability of the Work has been lost.
 */
public void released(FeWork work, IntegerVar reason) {
throw new UnsupportedOperationException();/*
udanax-top.st:19846:CommStatusDetector methodsFor: 'triggering'!
{void} released: work {FeWork} with: reason {IntegerVar}
	"Essential. The revise capability of the Work has been lost."
	
	myManager queueDetectorEvent: 
		(ReleasedEvent
			make: myNumber
			with: work
			with: reason)!
*/
}

public static Heaper make(PromiseManager pm, IntegerVar number, FeWork target) {
throw new UnsupportedOperationException();/*
udanax-top.st:19864:CommStatusDetector class methodsFor: 'creation'!
make: pm {PromiseManager} with: number {IntegerVar} with: target {FeWork}
	^self create: pm with: number with: target!
*/
}
}
