/*
 * Abora-Gold
 * Part of the Abora hypertext project: http://www.abora.org
 * Copyright 2003 David G Jones
 * 
 * Translated from Udanax-Gold source code: http://www.udanax.com
 * Copyright 1979-1999 Udanax.com. All rights reserved
 */
package org.abora.gold.proman;

import org.abora.gold.java.missing.IntegerVar;
import org.abora.gold.proman.DetectorEvent;
import org.abora.gold.proman.PromiseManager;
import org.abora.gold.xpp.basic.Heaper;


public class DoneEvent extends DetectorEvent {
/*
udanax-top.st:15966:
DetectorEvent subclass: #DoneEvent
	instanceVariableNames: ''
	classVariableNames: ''
	poolDictionaries: ''
	category: 'Xanadu-proman'!
*/
/*
udanax-top.st:15970:
(DoneEvent getOrMakeCxxClassDescription)
	attributes: ((Set new) add: #CONCRETE; add: #NOT.A.TYPE; yourself)!
*/
/*
udanax-top.st:15987:
DoneEvent class
	instanceVariableNames: ''!
*/
/*
udanax-top.st:15990:
(DoneEvent getOrMakeCxxClassDescription)
	attributes: ((Set new) add: #CONCRETE; add: #NOT.A.TYPE; yourself)!
*/

/**
 * Send the message across the wire.
 */
public void trigger(PromiseManager pm) {
throw new UnsupportedOperationException();/*
udanax-top.st:15975:DoneEvent methodsFor: 'triggering'!
{void} trigger: pm {PromiseManager}
	"Send the message across the wire."
	
	pm sendResponse: PromiseManager doneResponse.
	pm sendIntegerVar: self detector.!
*/
}

public  DoneEvent(IntegerVar detector) {
	super(detector);
throw new UnsupportedOperationException();/*
udanax-top.st:15983:DoneEvent methodsFor: 'creation'!
create: detector {IntegerVar}
	super create: detector!
*/
}

public static Heaper make(IntegerVar detector) {
throw new UnsupportedOperationException();/*
udanax-top.st:15995:DoneEvent class methodsFor: 'creation'!
{DetectorEvent} make: detector {IntegerVar}
	^ self create: detector!
*/
}
}
