/*
 * Abora-Gold
 * Part of the Abora hypertext project: http://www.abora.org
 * Copyright 2003 David G Jones
 * 
 * Translated from Udanax-Gold source code: http://www.udanax.com
 * Copyright 1979-1999 Udanax.com. All rights reserved
 */
package org.abora.gold.proman;

import org.abora.gold.java.missing.IntegerVar;
import org.abora.gold.proman.DetectorEvent;
import org.abora.gold.proman.PromiseManager;
import org.abora.gold.xpp.basic.Heaper;


/**
 * The detectors for comm create these and queue them up because they can only go out between
 * requests.
 */
public class DetectorEvent extends Heaper {
	protected DetectorEvent myNext;
	protected IntegerVar myDetector;
/*
udanax-top.st:15925:
Heaper subclass: #DetectorEvent
	instanceVariableNames: '
		myNext {DetectorEvent}
		myDetector {IntegerVar}'
	classVariableNames: ''
	poolDictionaries: ''
	category: 'Xanadu-proman'!
*/
/*
udanax-top.st:15931:
DetectorEvent comment:
'The detectors for comm create these and queue them up because they can only go out between requests.'!
*/
/*
udanax-top.st:15933:
(DetectorEvent getOrMakeCxxClassDescription)
	attributes: ((Set new) add: #DEFERRED; yourself)!
*/

public IntegerVar detector() {
throw new UnsupportedOperationException();/*
udanax-top.st:15938:DetectorEvent methodsFor: 'accessing'!
{IntegerVar} detector
	^myDetector!
*/
}

public DetectorEvent next() {
throw new UnsupportedOperationException();/*
udanax-top.st:15941:DetectorEvent methodsFor: 'accessing'!
{DetectorEvent} next
	^myNext!
*/
}

public void setNext(DetectorEvent event) {
throw new UnsupportedOperationException();/*
udanax-top.st:15944:DetectorEvent methodsFor: 'accessing'!
{void} setNext: event {DetectorEvent}
	myNext _ event!
*/
}

/**
 * Send the message across the wire.
 */
public void trigger(PromiseManager pm) {
throw new UnsupportedOperationException();/*
udanax-top.st:15949:DetectorEvent methodsFor: 'triggering'!
{void} trigger: pm {PromiseManager}
	"Send the message across the wire."
	
	self subclassResponsibility!
*/
}

public  DetectorEvent(IntegerVar detector) {
throw new UnsupportedOperationException();/*
udanax-top.st:15956:DetectorEvent methodsFor: 'creation'!
create: detector {IntegerVar}
	super create.
	myDetector _ detector.
	myNext _ NULL!
*/
}

public int actualHashForEqual() {
throw new UnsupportedOperationException();/*
udanax-top.st:15963:DetectorEvent methodsFor: 'testing'!
{UInt32} actualHashForEqual
	^Heaper takeOop!
*/
}
}
