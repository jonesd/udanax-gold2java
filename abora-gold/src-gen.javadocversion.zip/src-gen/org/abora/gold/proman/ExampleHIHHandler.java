/*
 * Abora-Gold
 * Part of the Abora hypertext project: http://www.abora.org
 * Copyright 2003 David G Jones
 * 
 * Translated from Udanax-Gold source code: http://www.udanax.com
 * Copyright 1979-1999 Udanax.com. All rights reserved
 */
package org.abora.gold.proman;

import org.abora.gold.java.missing.handle.HIHFn;
import org.abora.gold.proman.PromiseManager;
import org.abora.gold.proman.RequestHandler;
import org.abora.gold.xpp.basic.Category;


public class ExampleHIHHandler extends RequestHandler {
	protected HIHFn myFn;
	protected Category myType2;
/*
udanax-top.st:43708:
RequestHandler subclass: #ExampleHIHHandler
	instanceVariableNames: '
		myFn {HIHFn}
		myType2 {Category}'
	classVariableNames: ''
	poolDictionaries: ''
	category: 'Xanadu-proman'!
*/
/*
udanax-top.st:43714:
(ExampleHIHHandler getOrMakeCxxClassDescription)
	attributes: ((Set new) add: #CONCRETE; add: #SMALLTALK.ONLY; yourself)!
*/

public void handleRequest(PromiseManager pm) {
throw new UnsupportedOperationException();/*
udanax-top.st:43719:ExampleHIHHandler methodsFor: 'request handling'!
{void} handleRequest: pm {PromiseManager}
	| arg1 {IntegerVar} arg2 {Heaper} |
	arg1 _ self fetchIntegerVar.
	arg2 _ self fetchHeaper: myType2.
	pm noErrors ifTrue:
		[self respondHeaper: (myFn invokeFunction: arg1 with: arg2)]!
*/
}

public  ExampleHIHHandler(HIHFn fn, Category type2) {
throw new UnsupportedOperationException();/*
udanax-top.st:43729:ExampleHIHHandler methodsFor: 'creation'!
create: fn {HIHFn} with: type2 {Category}
	super create.
	myFn _ fn.
	myType2 _ type2!
*/
}
}
