/*
 * Abora-Gold
 * Part of the Abora hypertext project: http://www.abora.org
 * Copyright 2003 David G Jones
 * 
 * Translated from Udanax-Gold source code: http://www.udanax.com
 * Copyright 1979-1999 Udanax.com. All rights reserved
 */
package org.abora.gold.proman;

import org.abora.gold.java.missing.handle.BHHFn;
import org.abora.gold.proman.PromiseManager;
import org.abora.gold.proman.RequestHandler;
import org.abora.gold.xpp.basic.Category;
import org.abora.gold.xpp.basic.Heaper;


public class BHHHandler extends RequestHandler {
	protected BHHFn myFn;
	protected Category myType1;
	protected Category myType2;
/*
udanax-top.st:43617:
RequestHandler subclass: #BHHHandler
	instanceVariableNames: '
		myFn {BHHFn var}
		myType1 {Category}
		myType2 {Category}'
	classVariableNames: ''
	poolDictionaries: ''
	category: 'Xanadu-proman'!
*/
/*
udanax-top.st:43624:
(BHHHandler getOrMakeCxxClassDescription)
	attributes: ((Set new) add: #CONCRETE; add: #NOT.A.TYPE; yourself)!
*/
/*
udanax-top.st:43646:
BHHHandler class
	instanceVariableNames: ''!
*/
/*
udanax-top.st:43649:
(BHHHandler getOrMakeCxxClassDescription)
	attributes: ((Set new) add: #CONCRETE; add: #NOT.A.TYPE; yourself)!
*/

public void handleRequest(PromiseManager pm) {
throw new UnsupportedOperationException();/*
udanax-top.st:43629:BHHHandler methodsFor: 'request handling'!
{void} handleRequest: pm {PromiseManager}
	
	| arg1 {Heaper} arg2 {Heaper} |
	arg1 _ pm fetchNonNullHeaper: myType1.
	arg2 _ pm fetchNonNullHeaper: myType2.
	pm noErrors ifTrue:
		[pm respondBooleanVar: (myFn invokeFunction: arg1 with: arg2)]!
*/
}

public  BHHHandler(BHHFn fn, Category type1, Category type2) {
throw new UnsupportedOperationException();/*
udanax-top.st:43639:BHHHandler methodsFor: 'creation'!
create: fn {BHHFn var} with: type1 {Category} with: type2 {Category}
	super create.
	myFn _ fn.
	myType1 _ type1.
	myType2 _ type2.!
*/
}

public static Heaper make(BHHFn fn, Category type1, Category type2) {
throw new UnsupportedOperationException();/*
udanax-top.st:43654:BHHHandler class methodsFor: 'creation'!
{RequestHandler} make: fn {BHHFn var} with: type1 {Category} with: type2 {Category}
	^self create: fn with: type1 with: type2!
*/
}

public static void isGenerated() {
throw new UnsupportedOperationException();/*
udanax-top.st:43659:BHHHandler class methodsFor: 'generated:'!
isGenerated ^true!
*/
}
}
