/*
 * Abora-Gold
 * Part of the Abora hypertext project: http://www.abora.org
 * Copyright 2003 David G Jones
 * 
 * Translated from Udanax-Gold source code: http://www.udanax.com
 * Copyright 1979-1999 Udanax.com. All rights reserved
 */
package org.abora.gold.proman;

import org.abora.gold.java.missing.handle.HFn;
import org.abora.gold.proman.PromiseManager;
import org.abora.gold.proman.RequestHandler;
import org.abora.gold.xpp.basic.Heaper;


public class HHandler extends RequestHandler {
	protected HFn myFn;
/*
udanax-top.st:43734:
RequestHandler subclass: #HHandler
	instanceVariableNames: 'myFn {HFn var}'
	classVariableNames: ''
	poolDictionaries: ''
	category: 'Xanadu-proman'!
*/
/*
udanax-top.st:43738:
(HHandler getOrMakeCxxClassDescription)
	attributes: ((Set new) add: #CONCRETE; add: #NOT.A.TYPE; yourself)!
*/
/*
udanax-top.st:43755:
HHandler class
	instanceVariableNames: ''!
*/
/*
udanax-top.st:43758:
(HHandler getOrMakeCxxClassDescription)
	attributes: ((Set new) add: #CONCRETE; add: #NOT.A.TYPE; yourself)!
*/

public void handleRequest(PromiseManager pm) {
throw new UnsupportedOperationException();/*
udanax-top.st:43743:HHandler methodsFor: 'request handling'!
{void} handleRequest: pm {PromiseManager}
	
	pm noErrors ifTrue:
		[pm respondHeaper: (myFn invokeFunction)]!
*/
}

public  HHandler(HFn fn) {
throw new UnsupportedOperationException();/*
udanax-top.st:43750:HHandler methodsFor: 'creation'!
create: fn {HFn var}
	super create.
	myFn _ fn.!
*/
}

public static Heaper make(HFn fn) {
throw new UnsupportedOperationException();/*
udanax-top.st:43763:HHandler class methodsFor: 'creation'!
{RequestHandler} make: fn {HFn var}
	^self create: fn!
*/
}

public static void isGenerated() {
throw new UnsupportedOperationException();/*
udanax-top.st:43768:HHandler class methodsFor: 'generated:'!
isGenerated ^true!
*/
}
}
