/*
 * Abora-Gold
 * Part of the Abora hypertext project: http://www.abora.org
 * Copyright 2003 David G Jones
 * 
 * Translated from Udanax-Gold source code: http://www.udanax.com
 * Copyright 1979-1999 Udanax.com. All rights reserved
 */
package org.abora.gold.gchooks;

import org.abora.gold.collection.basic.WeakPtrArray;
import org.abora.gold.java.missing.VoidStar;
import org.abora.gold.wparray.XnExecutor;
import org.abora.gold.xpp.basic.Heaper;


/**
 * This executor manages objects that need to release non-Heaper storage on finalization.
 */
public class DeleteExecutor extends XnExecutor {
	protected static VoidStar StorageArray;
	protected static WeakPtrArray StorageHolders;
/*
udanax-top.st:15847:
XnExecutor subclass: #DeleteExecutor
	instanceVariableNames: ''
	classVariableNames: '
		StorageArray {void vector star} 
		StorageHolders {WeakPtrArray} '
	poolDictionaries: ''
	category: 'Xanadu-gchooks'!
*/
/*
udanax-top.st:15853:
DeleteExecutor comment:
'This executor manages objects that need to release non-Heaper storage on finalization.'!
*/
/*
udanax-top.st:15855:
(DeleteExecutor getOrMakeCxxClassDescription)
	attributes: ((Set new) add: #CONCRETE; add: #EQ; add: #NOT.A.TYPE; yourself)!
*/
/*
udanax-top.st:15879:
DeleteExecutor class
	instanceVariableNames: ''!
*/
/*
udanax-top.st:15882:
(DeleteExecutor getOrMakeCxxClassDescription)
	attributes: ((Set new) add: #CONCRETE; add: #EQ; add: #NOT.A.TYPE; yourself)!
*/

public void execute(int estateIndex) {
throw new UnsupportedOperationException();/*
udanax-top.st:15860:DeleteExecutor methodsFor: 'invoking'!
{void} execute: estateIndex {Int32}
	| storage {void star} |
	storage := StorageArray at: estateIndex.
	storage ~~ NULL ifTrue: [
		storage delete].
	StorageArray at: estateIndex put: NULL.!
*/
}

public  DeleteExecutor() {
throw new UnsupportedOperationException();/*
udanax-top.st:15869:DeleteExecutor methodsFor: 'protected: create'!
create
	super create!
*/
}

public int actualHashForEqual() {
throw new UnsupportedOperationException();/*
udanax-top.st:15874:DeleteExecutor methodsFor: 'generated:'!
actualHashForEqual ^self asOop!
*/
}

public boolean isEqual(Object other) {
throw new UnsupportedOperationException();/*
udanax-top.st:15876:DeleteExecutor methodsFor: 'generated:'!
isEqual: other ^self == other!
*/
}

public static void registerHolder(Heaper holder, VoidStar storage) {
throw new UnsupportedOperationException();/*
udanax-top.st:15887:DeleteExecutor class methodsFor: 'accessing'!
{void} registerHolder: holder {Heaper} with: storage {void star}
	| slot {Int32} |
	StorageArray == NULL ifTrue: [
		| exec {XnExecutor} |
		'DeleteExecutor::StorageArray = new void* [32];
		memset (DeleteExecutor::StorageArray, 0, 32 * sizeof(void*));' translateOnly.
		[StorageArray := PtrArray nulls: 32] smalltalkOnly.
		exec := DeleteExecutor create.
		StorageHolders := WeakPtrArray make: exec with: 32].
	slot := StorageHolders indexOf: NULL.
	slot == -1 ifTrue: [
		slot := StorageHolders count.
		'void ** newArray = new void* [slot + 16];
		memset(&newArray[slot], 0, 16 * sizeof(void*));
		MEMMOVE(newArray, DeleteExecutor::StorageArray, (int)slot);
		delete DeleteExecutor::StorageArray;
		DeleteExecutor::StorageArray = newArray;' translateOnly.
		[StorageArray := StorageArray copyGrow: 16] smalltalkOnly.
		StorageHolders := (StorageHolders copyGrow: 16) cast: WeakPtrArray].
	StorageArray at: slot put: storage.
	StorageHolders at: slot store: holder.!
*/
}

public static void unregisterHolder(Heaper holder, VoidStar storage) {
throw new UnsupportedOperationException();/*
udanax-top.st:15909:DeleteExecutor class methodsFor: 'accessing'!
{void} unregisterHolder: holder {Heaper} with: storage {void star}
	| slot {Int32} |
	slot := StorageHolders indexOfEQ: holder.
	[slot ~= -1 and: [slot < StorageHolders count and: [(StorageArray at: slot) ~~ storage]]] whileTrue: [
		slot := StorageHolders indexOfEQ: holder with: slot + 1].
	(slot == -1 or: [(StorageArray at: slot) ~~ storage]) ifTrue: [
		Heaper BLAST: #SanityViolation].
	StorageArray at: slot put: NULL.
	StorageHolders at: slot store: NULL.!
*/
}

public static void linkTimeNonInherited() {
throw new UnsupportedOperationException();/*
udanax-top.st:15921:DeleteExecutor class methodsFor: 'smalltalk: init'!
linkTimeNonInherited
	StorageArray := NULL.
	StorageHolders := NULL.!
*/
}
}
