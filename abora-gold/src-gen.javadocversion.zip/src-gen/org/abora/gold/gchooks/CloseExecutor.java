/*
 * Abora-Gold
 * Part of the Abora hypertext project: http://www.abora.org
 * Copyright 2003 David G Jones
 * 
 * Translated from Udanax-Gold source code: http://www.udanax.com
 * Copyright 1979-1999 Udanax.com. All rights reserved
 */
package org.abora.gold.gchooks;

import org.abora.gold.collection.basic.Int32Array;
import org.abora.gold.collection.basic.WeakPtrArray;
import org.abora.gold.wparray.XnExecutor;
import org.abora.gold.xpp.basic.Heaper;


/**
 * This executor manages objects that need to close file descriptors on finalization.
 */
public class CloseExecutor extends XnExecutor {
	protected static Int32Array FDArray;
	protected static WeakPtrArray FileDescriptorHolders;
/*
udanax-top.st:13732:
XnExecutor subclass: #CloseExecutor
	instanceVariableNames: ''
	classVariableNames: '
		FDArray {Int32Array} 
		FileDescriptorHolders {WeakPtrArray} '
	poolDictionaries: ''
	category: 'Xanadu-gchooks'!
*/
/*
udanax-top.st:13738:
CloseExecutor comment:
'This executor manages objects that need to close file descriptors on finalization.'!
*/
/*
udanax-top.st:13740:
(CloseExecutor getOrMakeCxxClassDescription)
	attributes: ((Set new) add: #CONCRETE; add: #EQ; add: #NOT.A.TYPE; yourself)!
*/
/*
udanax-top.st:13765:
CloseExecutor class
	instanceVariableNames: ''!
*/
/*
udanax-top.st:13768:
(CloseExecutor getOrMakeCxxClassDescription)
	attributes: ((Set new) add: #CONCRETE; add: #EQ; add: #NOT.A.TYPE; yourself)!
*/

public  CloseExecutor() {
throw new UnsupportedOperationException();/*
udanax-top.st:13745:CloseExecutor methodsFor: 'protected: create'!
create
	super create!
*/
}

public void execute(int estateIndex) {
throw new UnsupportedOperationException();/*
udanax-top.st:13750:CloseExecutor methodsFor: 'invoking'!
{void} execute: estateIndex {Int32}
	| fd {Int32} |
	fd := FDArray intAt: estateIndex.
	fd ~= -1 ifTrue: [
		[fd close] smalltalkOnly.
		'close((int)fd);' translateOnly.
		FDArray at: estateIndex storeInt: -1]!
*/
}

public int actualHashForEqual() {
throw new UnsupportedOperationException();/*
udanax-top.st:13760:CloseExecutor methodsFor: 'generated:'!
actualHashForEqual ^self asOop!
*/
}

public boolean isEqual(Object other) {
throw new UnsupportedOperationException();/*
udanax-top.st:13762:CloseExecutor methodsFor: 'generated:'!
isEqual: other ^self == other!
*/
}

public static void registerHolder(Heaper holder, int fd) {
throw new UnsupportedOperationException();/*
udanax-top.st:13773:CloseExecutor class methodsFor: 'accessing'!
{void} registerHolder: holder {Heaper} with: fd {Int32}
	| slot {Int32} |
	slot _Int32Zero.
	FDArray == NULL ifTrue: [
		| exec {XnExecutor} |
		FDArray := Int32Array make: 32.
		exec := CloseExecutor create.
		FileDescriptorHolders := WeakPtrArray make: exec with: 32].
	slot := FileDescriptorHolders indexOf: NULL.
	[self halt.] smalltalkOnly.
	slot == -1 ifTrue: [
	[self halt]smalltalkOnly.
		slot := FDArray count.
		FDArray := (FDArray copyGrow: 16) cast: Int32Array.
		FileDescriptorHolders := (FileDescriptorHolders copyGrow: 16) cast: WeakPtrArray].
	FDArray at: slot storeInt: fd.
	FileDescriptorHolders at: slot store: holder.!
*/
}

public static void unregisterHolder(Heaper holder, int fd) {
throw new UnsupportedOperationException();/*
udanax-top.st:13791:CloseExecutor class methodsFor: 'accessing'!
{void} unregisterHolder: holder {Heaper} with: fd {Int32}
	| slot {Int32} |
	slot := FileDescriptorHolders indexOfEQ: holder.
	[slot ~= -1 and: [slot < FDArray count and: [(FDArray intAt: slot) ~= fd]]] whileTrue: [
		slot := FileDescriptorHolders indexOfEQ: holder with: slot + 1].
	(slot == -1 or: [(FDArray intAt: slot) ~= fd]) ifTrue: [
		Heaper BLAST: #SanityViolation].
	FileDescriptorHolders at: slot store: NULL.
	FDArray at: slot storeInt: -1.!
*/
}

public static void linkTimeNonInherited() {
throw new UnsupportedOperationException();/*
udanax-top.st:13803:CloseExecutor class methodsFor: 'smalltalk: init'!
linkTimeNonInherited
	FDArray := NULL.
	FileDescriptorHolders := NULL!
*/
}
}
