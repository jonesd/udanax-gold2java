/*
 * Abora-Gold
 * Part of the Abora hypertext project: http://www.abora.org
 * Copyright 2003 David G Jones
 * 
 * Translated from Udanax-Gold source code: http://www.udanax.com
 * Copyright 1979-1999 Udanax.com. All rights reserved
 */
package org.abora.gold.set;

import java.io.PrintWriter;
import org.abora.gold.tumbler.Sequence;
import org.abora.gold.xpp.basic.Heaper;


/**
 * SHTO (SpecialHashTestObject) is used for testing hash sets.  It stores an identifying
 * string, along with the hash that it is to return.  This allows a) system independent
 * testing - as the hash will be the same in all test output files, and b) provides for
 * testing complex hash value interactions with spending years looking for the right objects
 * to generate critical hash values.
 */
public class SHTO extends Heaper {
	protected byte myHashValue;
	protected Sequence myStringValue;
/*
udanax-top.st:51460:
Heaper subclass: #SHTO
	instanceVariableNames: '
		myHashValue {UInt4}
		myStringValue {Sequence}'
	classVariableNames: ''
	poolDictionaries: ''
	category: 'Xanadu-set'!
*/
/*
udanax-top.st:51466:
SHTO comment:
'SHTO (SpecialHashTestObject) is used for testing hash sets.  It stores an identifying string, along with the hash that it is to return.  This allows a) system independent testing - as the hash will be the same in all test output files, and b) provides for testing complex hash value interactions with spending years looking for the right objects to generate critical hash values.'!
*/
/*
udanax-top.st:51468:
(SHTO getOrMakeCxxClassDescription)
	attributes: ((Set new) add: #CONCRETE; yourself)!
*/
/*
udanax-top.st:51512:
SHTO class
	instanceVariableNames: ''!
*/
/*
udanax-top.st:51515:
(SHTO getOrMakeCxxClassDescription)
	attributes: ((Set new) add: #CONCRETE; yourself)!
*/

public int actualHashForEqual() {
throw new UnsupportedOperationException();/*
udanax-top.st:51473:SHTO methodsFor: 'tests'!
{UInt32} actualHashForEqual
	^ myHashValue!
*/
}

public boolean isEqual(Heaper other) {
throw new UnsupportedOperationException();/*
udanax-top.st:51477:SHTO methodsFor: 'tests'!
{BooleanVar} isEqual: other {Heaper} 
	other cast: SHTO
		into: [:foo {SHTO} |
			^myHashValue = foo hashForEqual and: [myStringValue isEqual: foo stringValue]]
		others: [
			^false].
	^false "fodder"!
*/
}

public  SHTO(Sequence onString, int onHash) {
throw new UnsupportedOperationException();/*
udanax-top.st:51487:SHTO methodsFor: 'creation'!
create: onString {Sequence} with: onHash {UInt32}
	super create.
	myStringValue _ onString.
	myHashValue _ onHash!
*/
}

public void printOn(PrintWriter oo) {
throw new UnsupportedOperationException();/*
udanax-top.st:51495:SHTO methodsFor: 'printing'!
{void} printOn: oo {ostream reference}
	oo << self getCategory name << '('.
	[myHashValue printOn: oo base: 16] smalltalkOnly.
	'{
		char	buffer[9];
		sprintf(buffer, "%X", myHashValue);
		oo << buffer;
	}' translateOnly.
	oo << ', ' << myStringValue << ')'!
*/
}

public Sequence stringValue() {
throw new UnsupportedOperationException();/*
udanax-top.st:51508:SHTO methodsFor: 'private: accessing'!
{Sequence} stringValue
	^ myStringValue!
*/
}

public static Heaper make(String aString, int aHashVal) {
throw new UnsupportedOperationException();/*
udanax-top.st:51520:SHTO class methodsFor: 'make'!
make: aString {char vector} with: aHashVal {UInt32}
	| pack {Sequence} |
	pack _ Sequence string: aString.
	^ self create: pack with: aHashVal!
*/
}
}
