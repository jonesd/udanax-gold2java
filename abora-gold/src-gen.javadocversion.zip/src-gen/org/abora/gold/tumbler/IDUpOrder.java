/*
 * Abora-Gold
 * Part of the Abora hypertext project: http://www.abora.org
 * Copyright 2003 David G Jones
 * 
 * Translated from Udanax-Gold source code: http://www.udanax.com
 * Copyright 1979-1999 Udanax.com. All rights reserved
 */
package org.abora.gold.tumbler;

import org.abora.gold.arrange.Arrangement;
import org.abora.gold.spaces.basic.CoordinateSpace;
import org.abora.gold.spaces.basic.OrderSpec;
import org.abora.gold.spaces.basic.Position;
import org.abora.gold.spaces.basic.XnRegion;
import org.abora.gold.spaces.unordered.IDSpace;
import org.abora.gold.xcvr.Rcvr;
import org.abora.gold.xcvr.Xmtr;
import org.abora.gold.xpp.basic.Heaper;


public class IDUpOrder extends OrderSpec {
	protected IDSpace myIDSpace;
/*
udanax-top.st:30792:
OrderSpec subclass: #IDUpOrder
	instanceVariableNames: 'myIDSpace {IDSpace}'
	classVariableNames: ''
	poolDictionaries: ''
	category: 'Xanadu-tumbler'!
*/
/*
udanax-top.st:30796:
(IDUpOrder getOrMakeCxxClassDescription)
	attributes: ((Set new) add: #CONCRETE; add: #COPY; add: #NOT.A.TYPE; yourself)!
*/
/*
udanax-top.st:30875:
IDUpOrder class
	instanceVariableNames: ''!
*/
/*
udanax-top.st:30878:
(IDUpOrder getOrMakeCxxClassDescription)
	attributes: ((Set new) add: #CONCRETE; add: #COPY; add: #NOT.A.TYPE; yourself)!
*/

public int actualHashForEqual() {
throw new UnsupportedOperationException();/*
udanax-top.st:30801:IDUpOrder methodsFor: 'testing'!
{UInt32} actualHashForEqual
	^self getCategory hashForEqual!
*/
}

public boolean follows(Position x, Position y) {
throw new UnsupportedOperationException();/*
udanax-top.st:30805:IDUpOrder methodsFor: 'testing'!
{BooleanVar} follows: x {Position} with: y {Position}
	x cast: ID into: [ :a | y cast: ID into: [ :b |
		Ravi thingToDo. "more efficient comparison"
		^(b backend isGE: a backend) not
			or: [(a backend isEqual: b backend)
				and: [a number >= b number]]]].
	^false "fodder"!
*/
}

public boolean isEqual(Heaper other) {
throw new UnsupportedOperationException();/*
udanax-top.st:30814:IDUpOrder methodsFor: 'testing'!
{BooleanVar} isEqual: other {Heaper}
	^other isKindOf: IDUpOrder!
*/
}

public boolean isFullOrder(XnRegion keys) {
throw new UnsupportedOperationException();/*
udanax-top.st:30818:IDUpOrder methodsFor: 'testing'!
{BooleanVar} isFullOrder: keys {XnRegion default: NULL}
	^true!
*/
}

/**
 * Return true if some position in before is less than or equal to all positions in after.
 */
public boolean preceeds(XnRegion before, XnRegion after) {
throw new UnsupportedOperationException();/*
udanax-top.st:30822:IDUpOrder methodsFor: 'testing'!
{BooleanVar} preceeds: before {XnRegion} with: after {XnRegion}
	"Return true if some position in before is less than or equal to all positions in after."
	
	| beforeB {SequenceRegion} afterB {SequenceRegion} bound {Sequence} |
	before cast: IDRegion into: [ :beforeIDs |
	after cast: IDRegion into: [ :afterIDs |
		beforeB := beforeIDs backends.
		afterB := afterIDs backends.
		(SequenceSpace make ascending preceeds: beforeB with: afterB) ifFalse:
			[^false].
		beforeB isBoundedBelow ifFalse:
			[^true].
		bound := beforeB lowerBound.
		(bound isEqual: afterB lowerBound) ifFalse:
			[^true].
		^IntegerSpace make ascending
			preceeds: (beforeIDs iDNumbersFrom: bound)
			with: (afterIDs iDNumbersFrom: bound)]].
	^false "fodder"!
*/
}

public Arrangement arrange(XnRegion region) {
throw new UnsupportedOperationException();/*
udanax-top.st:30844:IDUpOrder methodsFor: 'accessing'!
{Arrangement} arrange: region {XnRegion}
	| stepper {Stepper} array {PtrArray} |
	region isFinite ifFalse: [Heaper BLAST: #MustBeFinite].
	stepper := (region cast: IDRegion) stepper.
	array := stepper stepMany cast: PtrArray.
	stepper atEnd ifFalse: [self unimplemented].
	^ExplicitArrangement make: array!
*/
}

public CoordinateSpace coordinateSpace() {
throw new UnsupportedOperationException();/*
udanax-top.st:30853:IDUpOrder methodsFor: 'accessing'!
{CoordinateSpace} coordinateSpace
	^myIDSpace!
*/
}

public  IDUpOrder(IDSpace space) {
	super(null);
throw new UnsupportedOperationException();/*
udanax-top.st:30859:IDUpOrder methodsFor: 'create'!
create: space {IDSpace}
	super create.
	myIDSpace := space.!
*/
}

public  IDUpOrder(Rcvr receiver) {
	super(receiver);
throw new UnsupportedOperationException();/*
udanax-top.st:30866:IDUpOrder methodsFor: 'generated:'!
create.Rcvr: receiver {Rcvr}
	super create.Rcvr: receiver.
	myIDSpace _ receiver receiveHeaper.!
*/
}

public void sendSelfTo(Xmtr xmtr) {
throw new UnsupportedOperationException();/*
udanax-top.st:30870:IDUpOrder methodsFor: 'generated:'!
{void} sendSelfTo: xmtr {Xmtr}
	super sendSelfTo: xmtr.
	xmtr sendHeaper: myIDSpace.!
*/
}

public static Heaper make(IDSpace space) {
throw new UnsupportedOperationException();/*
udanax-top.st:30883:IDUpOrder class methodsFor: 'pseudo constructors'!
{OrderSpec} make: space {IDSpace}
	^self create: space.!
*/
}
}
