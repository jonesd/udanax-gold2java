/*
 * Abora-Gold
 * Part of the Abora hypertext project: http://www.abora.org
 * Copyright 2003 David G Jones
 * 
 * Translated from Udanax-Gold source code: http://www.udanax.com
 * Copyright 1979-1999 Udanax.com. All rights reserved
 */
package org.abora.gold.tumbler;

import java.io.PrintWriter;
import org.abora.gold.edgeregion.TransitionEdge;
import org.abora.gold.spaces.basic.Position;
import org.abora.gold.tumbler.Sequence;
import org.abora.gold.tumbler.SequenceEdge;
import org.abora.gold.tumbler.SequenceMapping;
import org.abora.gold.xcvr.Rcvr;
import org.abora.gold.xcvr.Xmtr;
import org.abora.gold.xpp.basic.Heaper;


public class BeforeSequence extends SequenceEdge {
/*
udanax-top.st:63796:
SequenceEdge subclass: #BeforeSequence
	instanceVariableNames: ''
	classVariableNames: ''
	poolDictionaries: ''
	category: 'Xanadu-tumbler'!
*/
/*
udanax-top.st:63800:
(BeforeSequence getOrMakeCxxClassDescription)
	attributes: ((Set new) add: #CONCRETE; add: #COPY; add: #NOT.A.TYPE; yourself)!
*/
/*
udanax-top.st:63880:
BeforeSequence class
	instanceVariableNames: ''!
*/
/*
udanax-top.st:63883:
(BeforeSequence getOrMakeCxxClassDescription)
	attributes: ((Set new) add: #CONCRETE; add: #COPY; add: #NOT.A.TYPE; yourself)!
*/

public boolean follows(Position pos) {
throw new UnsupportedOperationException();/*
udanax-top.st:63805:BeforeSequence methodsFor: 'comparing'!
{BooleanVar} follows: pos {Position}
	^((pos cast: Sequence) isGE: self sequence) not!
*/
}

public boolean isEqual(Heaper other) {
throw new UnsupportedOperationException();/*
udanax-top.st:63809:BeforeSequence methodsFor: 'comparing'!
{BooleanVar} isEqual: other {Heaper}
	other cast: BeforeSequence into: [ :before |
		^before sequence isEqual: self sequence]
	others:
		[^false].
	^ false "compiler fodder"!
*/
}

public boolean isFollowedBy(TransitionEdge next) {
throw new UnsupportedOperationException();/*
udanax-top.st:63817:BeforeSequence methodsFor: 'comparing'!
{BooleanVar} isFollowedBy: next {TransitionEdge}
	next cast: AfterSequence into: [ :after |
		^self sequence isEqual: after sequence]
	others:
		[^false].
	^ false "compiler fodder"!
*/
}

public boolean isGE(TransitionEdge other) {
throw new UnsupportedOperationException();/*
udanax-top.st:63825:BeforeSequence methodsFor: 'comparing'!
{BooleanVar} isGE: other {TransitionEdge}
	other cast: BeforeSequencePrefix into: [ :prefix |
		^(self sequence comparePrefix: prefix sequence with: prefix limit) >= Int32Zero]
	cast: BeforeSequence into: [ :before |
		^self sequence isGE: before sequence]
	cast: AfterSequence into: [ :after |
		^(after sequence isGE: self sequence) not].
	^ false "compiler fodder"!
*/
}

public boolean touches(TransitionEdge other) {
throw new UnsupportedOperationException();/*
udanax-top.st:63835:BeforeSequence methodsFor: 'comparing'!
{BooleanVar} touches: other {TransitionEdge}
	other cast: BeforeSequencePrefix into: [ :prefix |
		^false]
	cast: SequenceEdge into: [ :edge |
		^self sequence isEqual: edge sequence].
	^ false "compiler fodder"!
*/
}

public Position position() {
throw new UnsupportedOperationException();/*
udanax-top.st:63845:BeforeSequence methodsFor: 'accessing'!
{Position} position
	^self sequence!
*/
}

public SequenceEdge transformedBy(SequenceMapping dsp) {
throw new UnsupportedOperationException();/*
udanax-top.st:63849:BeforeSequence methodsFor: 'accessing'!
{SequenceEdge} transformedBy: dsp {SequenceMapping}
	^BeforeSequence make: ((dsp of: self sequence) cast: Sequence)!
*/
}

public  BeforeSequence(Sequence sequence) {
	super(sequence);
throw new UnsupportedOperationException();/*
udanax-top.st:63855:BeforeSequence methodsFor: 'create'!
create: sequence {Sequence}
	super create: sequence.!
*/
}

public void printTransitionOn(PrintWriter oo, boolean entering, boolean touchesPrevious) {
throw new UnsupportedOperationException();/*
udanax-top.st:63861:BeforeSequence methodsFor: 'printing'!
{void} printTransitionOn: oo {ostream reference}
	with: entering {BooleanVar}
	with: touchesPrevious {BooleanVar}
	oo << ' '.
	entering ifTrue: [oo << '['].
	(touchesPrevious and: [entering not]) ifFalse:
		[oo << self sequence].
	entering ifFalse: [oo << ')']!
*/
}

public  BeforeSequence(Rcvr receiver) {
	super(receiver);
throw new UnsupportedOperationException();/*
udanax-top.st:63873:BeforeSequence methodsFor: 'generated:'!
create.Rcvr: receiver {Rcvr}
	super create.Rcvr: receiver.!
*/
}

public void sendSelfTo(Xmtr xmtr) {
throw new UnsupportedOperationException();/*
udanax-top.st:63876:BeforeSequence methodsFor: 'generated:'!
{void} sendSelfTo: xmtr {Xmtr}
	super sendSelfTo: xmtr.!
*/
}

public static Heaper make(Sequence sequence) {
throw new UnsupportedOperationException();/*
udanax-top.st:63888:BeforeSequence class methodsFor: 'pseudo constructors'!
{SequenceEdge} make: sequence {Sequence}
	^self create: sequence!
*/
}
}
