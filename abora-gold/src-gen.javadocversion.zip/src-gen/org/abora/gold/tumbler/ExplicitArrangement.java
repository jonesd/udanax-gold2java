/*
 * Abora-Gold
 * Part of the Abora hypertext project: http://www.abora.org
 * Copyright 2003 David G Jones
 * 
 * Translated from Udanax-Gold source code: http://www.udanax.com
 * Copyright 1979-1999 Udanax.com. All rights reserved
 */
package org.abora.gold.tumbler;

import org.abora.gold.arrange.Arrangement;
import org.abora.gold.collection.basic.PtrArray;
import org.abora.gold.java.missing.IntegerVar;
import org.abora.gold.spaces.basic.Position;
import org.abora.gold.spaces.basic.XnRegion;
import org.abora.gold.spaces.integers.IntegerRegion;
import org.abora.gold.xcvr.Rcvr;
import org.abora.gold.xcvr.Xmtr;
import org.abora.gold.xpp.basic.Heaper;


public class ExplicitArrangement extends Arrangement {
	protected PtrArray myPositions;
/*
udanax-top.st:12585:
Arrangement subclass: #ExplicitArrangement
	instanceVariableNames: 'myPositions {PtrArray of: Position}'
	classVariableNames: ''
	poolDictionaries: ''
	category: 'Xanadu-tumbler'!
*/
/*
udanax-top.st:12589:
(ExplicitArrangement getOrMakeCxxClassDescription)
	attributes: ((Set new) add: #CONCRETE; add: #COPY; add: #NOT.A.TYPE; yourself)!
*/
/*
udanax-top.st:12670:
ExplicitArrangement class
	instanceVariableNames: ''!
*/
/*
udanax-top.st:12673:
(ExplicitArrangement getOrMakeCxxClassDescription)
	attributes: ((Set new) add: #CONCRETE; add: #COPY; add: #NOT.A.TYPE; yourself)!
*/

public  ExplicitArrangement(PtrArray positions) {
	super(null);
throw new UnsupportedOperationException();/*
udanax-top.st:12594:ExplicitArrangement methodsFor: 'create'!
create: positions {PtrArray of: Position}
	super create.
	myPositions := positions.!
*/
}

public IntegerVar indexOf(Position position) {
throw new UnsupportedOperationException();/*
udanax-top.st:12601:ExplicitArrangement methodsFor: 'accessing'!
{IntegerVar} indexOf: position {Position}
	Int32Zero almostTo: myPositions count do: [ :i {Int32} |
		(position isEqual: (myPositions fetch: i)) ifTrue:
			[^i]].
	Heaper BLAST: #NotFound.
	^ -1 "compiler fodder"!
*/
}

public IntegerRegion indicesOf(XnRegion region) {
throw new UnsupportedOperationException();/*
udanax-top.st:12609:ExplicitArrangement methodsFor: 'accessing'!
{IntegerRegion} indicesOf: region {XnRegion}
	| result {IntegerRegion} |
	result := IntegerRegion make.
	Int32Zero almostTo: myPositions count do: [ :i {Int32} |
		(region hasMember: ((myPositions fetch: i) cast: Position)) ifTrue:
			[result := (result with: i integer) cast: IntegerRegion]].
	^result!
*/
}

public XnRegion keysOf(int start, int stop) {
throw new UnsupportedOperationException();/*
udanax-top.st:12618:ExplicitArrangement methodsFor: 'accessing'!
{XnRegion} keysOf: start {Int32} with: stop {Int32}
	| result {XnRegion} |
	result := NULL.
	start almostTo: stop do: [ :i {Int32} |
		result == NULL ifTrue:
			[result := ((myPositions fetch: i) cast: Position) asRegion]
		ifFalse:
			[result := result with: ((myPositions fetch: i) cast: Position)]].
	result == NULL ifTrue:
		[Heaper BLAST: #IndexOutOfBounds].
	^result!
*/
}

public XnRegion region() {
throw new UnsupportedOperationException();/*
udanax-top.st:12631:ExplicitArrangement methodsFor: 'accessing'!
{XnRegion} region
	| result {XnRegion} |
	result := (myPositions get: Int32Zero) cast: XnRegion.
	1 almostTo: myPositions count do: [ :i {Int32} |
		result := result with: ((myPositions get: i) cast: Position)].
	^result!
*/
}

public int actualHashForEqual() {
throw new UnsupportedOperationException();/*
udanax-top.st:12641:ExplicitArrangement methodsFor: 'testing'!
{UInt32} actualHashForEqual
	^ myPositions contentsHash!
*/
}

public int hashForEqual() {
throw new UnsupportedOperationException();/*
udanax-top.st:12644:ExplicitArrangement methodsFor: 'testing'!
{UInt32} hashForEqual
	^ myPositions contentsHash!
*/
}

public boolean isEqual(Heaper other) {
throw new UnsupportedOperationException();/*
udanax-top.st:12647:ExplicitArrangement methodsFor: 'testing'!
{BooleanVar} isEqual: other {Heaper}
	other cast: ExplicitArrangement
		  into: [:o {ExplicitArrangement} |
		  	^ myPositions contentsEqual: o positions]
		  others: [^ false ].
	^ false "fodder"!
*/
}

public PtrArray positions() {
throw new UnsupportedOperationException();/*
udanax-top.st:12656:ExplicitArrangement methodsFor: 'private: accessing'!
{PtrArray} positions
	^ myPositions!
*/
}

public  ExplicitArrangement(Rcvr receiver) {
	super(receiver);
throw new UnsupportedOperationException();/*
udanax-top.st:12661:ExplicitArrangement methodsFor: 'generated:'!
create.Rcvr: receiver {Rcvr}
	super create.Rcvr: receiver.
	myPositions _ receiver receiveHeaper.!
*/
}

public void sendSelfTo(Xmtr xmtr) {
throw new UnsupportedOperationException();/*
udanax-top.st:12665:ExplicitArrangement methodsFor: 'generated:'!
{void} sendSelfTo: xmtr {Xmtr}
	super sendSelfTo: xmtr.
	xmtr sendHeaper: myPositions.!
*/
}

public static Heaper make(PtrArray positions) {
throw new UnsupportedOperationException();/*
udanax-top.st:12678:ExplicitArrangement class methodsFor: 'create'!
{Arrangement} make: positions {PtrArray of: Position} 
	^self create: positions!
*/
}
}
