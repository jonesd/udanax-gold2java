/*
 * Abora-Gold
 * Part of the Abora hypertext project: http://www.abora.org
 * Copyright 2003 David G Jones
 * 
 * Translated from Udanax-Gold source code: http://www.udanax.com
 * Copyright 1979-1999 Udanax.com. All rights reserved
 */
package org.abora.gold.tumbler;

import java.io.PrintWriter;
import org.abora.gold.edgeregion.TransitionEdge;
import org.abora.gold.spaces.basic.Position;
import org.abora.gold.tumbler.RealPos;
import org.abora.gold.xcvr.Rcvr;
import org.abora.gold.xcvr.Xmtr;
import org.abora.gold.xpp.basic.Heaper;


public class RealEdge extends TransitionEdge {
	protected RealPos myPos;
/*
udanax-top.st:63418:
TransitionEdge subclass: #RealEdge
	instanceVariableNames: 'myPos {RealPos}'
	classVariableNames: ''
	poolDictionaries: ''
	category: 'Xanadu-tumbler'!
*/
/*
udanax-top.st:63422:
(RealEdge getOrMakeCxxClassDescription)
	attributes: ((Set new) add: #DEFERRED; add: #COPY; yourself)!
*/

public RealPos position() {
throw new UnsupportedOperationException();/*
udanax-top.st:63427:RealEdge methodsFor: 'accessing'!
{RealPos} position
	^myPos!
*/
}

public int actualHashForEqual() {
throw new UnsupportedOperationException();/*
udanax-top.st:63433:RealEdge methodsFor: 'testing'!
{UInt32} actualHashForEqual
	^myPos hashForEqual bitXor: self getCategory hashForEqual!
*/
}

public boolean follows(Position pos) {
throw new UnsupportedOperationException();/*
udanax-top.st:63437:RealEdge methodsFor: 'testing'!
{BooleanVar} follows: pos {Position}
	
	self subclassResponsibility!
*/
}

public boolean isEqual(Heaper other) {
throw new UnsupportedOperationException();/*
udanax-top.st:63441:RealEdge methodsFor: 'testing'!
{BooleanVar} isEqual: other {Heaper}
	self subclassResponsibility!
*/
}

public boolean isFollowedBy(TransitionEdge next) {
throw new UnsupportedOperationException();/*
udanax-top.st:63445:RealEdge methodsFor: 'testing'!
{BooleanVar} isFollowedBy: next {TransitionEdge}
	
	self subclassResponsibility!
*/
}

public boolean isGE(TransitionEdge other) {
throw new UnsupportedOperationException();/*
udanax-top.st:63449:RealEdge methodsFor: 'testing'!
{BooleanVar} isGE: other {TransitionEdge}
	
	self subclassResponsibility!
*/
}

public boolean touches(TransitionEdge other) {
throw new UnsupportedOperationException();/*
udanax-top.st:63453:RealEdge methodsFor: 'testing'!
{BooleanVar} touches: other {TransitionEdge}
	
	^myPos isEqual: (other cast: RealEdge) position!
*/
}

public void printTransitionOn(PrintWriter oo, boolean entering, boolean touchesPrevious) {
throw new UnsupportedOperationException();/*
udanax-top.st:63459:RealEdge methodsFor: 'printing'!
{void} printTransitionOn: oo {ostream reference}
	with: entering {BooleanVar}
	with: touchesPrevious {BooleanVar}
	
	self subclassResponsibility!
*/
}

public  RealEdge(RealPos pos) {
	super(null);
throw new UnsupportedOperationException();/*
udanax-top.st:63467:RealEdge methodsFor: 'creation'!
create: pos {RealPos}
	super create.
	myPos := pos.!
*/
}

public  RealEdge(Rcvr receiver) {
	super(receiver);
throw new UnsupportedOperationException();/*
udanax-top.st:63474:RealEdge methodsFor: 'generated:'!
create.Rcvr: receiver {Rcvr}
	super create.Rcvr: receiver.
	myPos _ receiver receiveHeaper.!
*/
}

public void sendSelfTo(Xmtr xmtr) {
throw new UnsupportedOperationException();/*
udanax-top.st:63478:RealEdge methodsFor: 'generated:'!
{void} sendSelfTo: xmtr {Xmtr}
	super sendSelfTo: xmtr.
	xmtr sendHeaper: myPos.!
*/
}
}
