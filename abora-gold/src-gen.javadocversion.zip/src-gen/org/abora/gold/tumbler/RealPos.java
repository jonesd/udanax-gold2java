/*
 * Abora-Gold
 * Part of the Abora hypertext project: http://www.abora.org
 * Copyright 2003 David G Jones
 * 
 * Translated from Udanax-Gold source code: http://www.udanax.com
 * Copyright 1979-1999 Udanax.com. All rights reserved
 */
package org.abora.gold.tumbler;

import org.abora.gold.java.missing.IEEE8;
import org.abora.gold.java.missing.IntegerVar;
import org.abora.gold.spaces.basic.CoordinateSpace;
import org.abora.gold.spaces.basic.Position;
import org.abora.gold.spaces.basic.XnRegion;
import org.abora.gold.tumbler.RealPos;
import org.abora.gold.x.PrimFloatValue;
import org.abora.gold.xcvr.Rcvr;
import org.abora.gold.xcvr.Xmtr;
import org.abora.gold.xpp.basic.Heaper;


/**
 * Represents some real number exactly.  Not all real numbers can be exactly represented.
 * See class comment in RealSpace.
 */
public class RealPos extends Position {
/*
udanax-top.st:32016:
Position subclass: #RealPos
	instanceVariableNames: ''
	classVariableNames: ''
	poolDictionaries: ''
	category: 'Xanadu-tumbler'!
*/
/*
udanax-top.st:32020:
RealPos comment:
'Represents some real number exactly.  Not all real numbers can be exactly represented.  See class comment in RealSpace.'!
*/
/*
udanax-top.st:32022:
(RealPos getOrMakeCxxClassDescription)
	attributes: ((Set new) add: #ON.CLIENT; add: #DEFERRED; add: #COPY; yourself)!
*/
/*
udanax-top.st:32113:
RealPos class
	instanceVariableNames: ''!
*/
/*
udanax-top.st:32116:
(RealPos getOrMakeCxxClassDescription)
	attributes: ((Set new) add: #ON.CLIENT; add: #DEFERRED; add: #COPY; yourself)!
*/

public XnRegion asRegion() {
throw new UnsupportedOperationException();/*
udanax-top.st:32027:RealPos methodsFor: 'accessing'!
{XnRegion} asRegion
	^RealRegion make: false
		with: (PrimSpec pointer
			arrayWithTwo: (BeforeReal make: self)
			with: (AfterReal make: self))!
*/
}

public CoordinateSpace coordinateSpace() {
throw new UnsupportedOperationException();/*
udanax-top.st:32034:RealPos methodsFor: 'accessing'!
{CoordinateSpace INLINE} coordinateSpace
	^RealSpace make!
*/
}

/**
 * Essential. Return the number as a PrimFloat object from which you can get it in a variety
 * of representations.
 */
public PrimFloatValue value() {
throw new UnsupportedOperationException();/*
udanax-top.st:32038:RealPos methodsFor: 'accessing'!
{PrimFloatValue CLIENT} value
	"Essential. Return the number as a PrimFloat object from which you can get it in a variety of representations."
	
	self subclassResponsibility!
*/
}

public int actualHashForEqual() {
throw new UnsupportedOperationException();/*
udanax-top.st:32045:RealPos methodsFor: 'testing'!
{UInt32} actualHashForEqual
	
	[^self asIEEE64 basicCast: UInt32] translateOnly.
	
	[^self asIEEE64 truncated] smalltalkOnly!
*/
}

public boolean isEqual(Heaper other) {
throw new UnsupportedOperationException();/*
udanax-top.st:32051:RealPos methodsFor: 'testing'!
{BooleanVar} isEqual: other {Heaper} 
	
	MarkM thingToDo. "128 bit values"
	other
		cast: RealPos into: [:r |
			^self asIEEE64 = r asIEEE64]
		others: [^false].
	^false "fodder"!
*/
}

public boolean isGE(Position other) {
throw new UnsupportedOperationException();/*
udanax-top.st:32061:RealPos methodsFor: 'testing'!
{BooleanVar} isGE: other {Position}
	^self asIEEE64 >= (other cast: RealPos) asIEEE64!
*/
}

public IntegerVar exponent() {
throw new UnsupportedOperationException();/*
udanax-top.st:32067:RealPos methodsFor: 'smalltalk: passe'!
{IntegerVar} exponent
	self passe!
*/
}

/**
 * Whether the real number that this object represents is exactly representable in an
 * available IEEE precision.  Currently the answer is always TRUE, and the available
 * precisions are 8 (stupid precision), 32 (single precision), and 64 (double precision).  If
 * the answer is FALSE, the meaning of the messages 'precision' and 'asIEEE' remain to be
 * defined.
 */
public boolean isIEEE() {
throw new UnsupportedOperationException();/*
udanax-top.st:32071:RealPos methodsFor: 'smalltalk: passe'!
{BooleanVar} isIEEE
	"Whether the real number that this object represents is exactly representable in an available IEEE precision.  Currently the answer is always TRUE, and the available precisions are 8 (stupid precision), 32 (single precision), and 64 (double precision).  If the answer is FALSE, the meaning of the messages 'precision' and 'asIEEE' remain to be defined."
	self passe.
	^true!
*/
}

/**
 * This number represents exactly this->mantissa() * 2 ^ this->exponent().  Should we
 * eventually support real numbers which cannot be expressed exactly with integral mantissa
 * and exponent, then this message (and 'exponent') will BLAST for such numbers.
 */
public IntegerVar mantissa() {
throw new UnsupportedOperationException();/*
udanax-top.st:32076:RealPos methodsFor: 'smalltalk: passe'!
{IntegerVar} mantissa
	"This number represents exactly this->mantissa() * 2 ^ this->exponent().  Should we eventually support real numbers which cannot be expressed exactly with integral mantissa and exponent, then this message (and 'exponent') will BLAST for such numbers."
	self passe!
*/
}

/**
 * Returns the value as IEEE basic data type is big enough to hold any value which can be put
 * into an XuReal.  Currently this is an IEEE64 (double precision).  In future releases of
 * this API, the return type of this method may be changed to IEEE128 (quad precision).  Once
 * we support other ways of representing real numbers, there may not be an all-inclusive IEEE
 * type, in which case this message will BLAST.
 * The only IEEE values which this will return are those that represent real numbers.  I.e.,
 * no NANs, no inifinities, no negative zero.
 */
public double asIEEE() {
throw new UnsupportedOperationException();/*
udanax-top.st:32083:RealPos methodsFor: 'obsolete:'!
{IEEE64} asIEEE
	"Returns the value as IEEE basic data type is big enough to hold any value which can be put into an XuReal.  Currently this is an IEEE64 (double precision).  In future releases of this API, the return type of this method may be changed to IEEE128 (quad precision).  Once we support other ways of representing real numbers, there may not be an all-inclusive IEEE type, in which case this message will BLAST.
	
	The only IEEE values which this will return are those that represent real numbers.  I.e., no NANs, no inifinities, no negative zero."
	
	self subclassResponsibility!
*/
}

/**
 * Returns the value as IEEE64 (double precision).
 * The only IEEE values which this will return are those that represent real numbers.  I.e.,
 * no NANs, no inifinities, no negative zero.
 */
public double asIEEE64() {
throw new UnsupportedOperationException();/*
udanax-top.st:32090:RealPos methodsFor: 'obsolete:'!
{IEEE64} asIEEE64
	"Returns the value as IEEE64 (double precision).
	The only IEEE values which this will return are those that represent real numbers.  I.e., no NANs, no inifinities, no negative zero."
	
	self subclassResponsibility!
*/
}

/**
 * What precision is it, in terms of the number of bits used to represent it.  In the
 * interests of efficiency, this may return a number larger than that *needed* to represent
 * it.  However, the precision reported must be at least that needed to represent this
 * number.  It is assumed that the format of the number satisfies the IEEE radix independent
 * floating point spec.  Should we represent real numbers other that those representable in
 * IEEE, the meaning of this message will be more fully specified.
 * The fact that this message is allowed to overestimate precision doesn't interfere with
 * equality: a->isEqual(b) exactly when they represent that same real number, even if one of
 * them happens to overestimate precision more that the other.
 */
public int precision() {
throw new UnsupportedOperationException();/*
udanax-top.st:32096:RealPos methodsFor: 'obsolete:'!
{Int32} precision
	"What precision is it, in terms of the number of bits used to represent it.  In the interests of efficiency, this may return a number larger than that *needed* to represent it.  However, the precision reported must be at least that needed to represent this number.  It is assumed that the format of the number satisfies the IEEE radix independent floating point spec.  Should we represent real numbers other that those representable in IEEE, the meaning of this message will be more fully specified.
	
	The fact that this message is allowed to overestimate precision doesn't interfere with equality: a->isEqual(b) exactly when they represent that same real number, even if one of them happens to overestimate precision more that the other."
	
	MarkM thingToDo. "retire this"
	self subclassResponsibility!
*/
}

public  RealPos(Rcvr receiver) {
throw new UnsupportedOperationException();/*
udanax-top.st:32106:RealPos methodsFor: 'generated:'!
create.Rcvr: receiver {Rcvr}
	super create.Rcvr: receiver.!
*/
}

public void sendSelfTo(Xmtr xmtr) {
throw new UnsupportedOperationException();/*
udanax-top.st:32109:RealPos methodsFor: 'generated:'!
{void} sendSelfTo: xmtr {Xmtr}
	super sendSelfTo: xmtr.!
*/
}

/**
 * make an XuReal given an IEEE floating point number of whatever precision on this platform
 * is able to hold all the real numbers currently representable by an XuReal.  Currently this
 * is IEEE64 (double precision), but may be redeclared as a larger IEEE precision in the
 * future.  See comment in XuReal::makeIEEE64
 */
public static Heaper make(double value) {
throw new UnsupportedOperationException();/*
udanax-top.st:32121:RealPos class methodsFor: 'creation'!
{RealPos INLINE} make: value {IEEE64}
	"make an XuReal given an IEEE floating point number of whatever precision on this platform is able to hold all the real numbers currently representable by an XuReal.  Currently this is IEEE64 (double precision), but may be redeclared as a larger IEEE precision in the future.  See comment in XuReal::makeIEEE64"
	^self makeIEEE64: value!
*/
}

/**
 * See comment in XuReal::makeIEEE64
 */
public static RealPos makeIEEE32(float value) {
throw new UnsupportedOperationException();/*
udanax-top.st:32126:RealPos class methodsFor: 'creation'!
{RealPos} makeIEEE32: value {IEEE32}
	"See comment in XuReal::makeIEEE64"
	self knownBug. "must ensure that it is a number, and convert -0 to +0"
	self thingToDo. "perhaps we should check to see if a lower precision can hold it exactly, and delegate to XuIEEE8.  Nahh."
	
	^IEEE32Pos create: value!
*/
}

/**
 * Returns an XuReal which exactly represents the same real number that is represented by
 * 'value'.  BLASTs if value doesn't represent a real (i.e., no NANs or inifinities).
 * Negative 0 will be silently converted to positive zero
 */
public static RealPos makeIEEE64(double value) {
throw new UnsupportedOperationException();/*
udanax-top.st:32134:RealPos class methodsFor: 'creation'!
{RealPos} makeIEEE64: value {IEEE64}
	"Returns an XuReal which exactly represents the same real number that is represented by 'value'.  BLASTs if value doesn't represent a real (i.e., no NANs or inifinities).  Negative 0 will be silently converted to positive zero"
	self knownBug. "must ensure that it is a number, and convert -0 to +0"
	self thingToDo. "perhaps we should check to see if a lower precision can hold it exactly, and delegate to XuIEEE32 or XuIEEE8.  Nahh."
	
	^IEEE64Pos create: value!
*/
}

/**
 * See comment in XuReal::makeIEEE64
 */
public static RealPos makeIEEE8(IEEE8 value) {
throw new UnsupportedOperationException();/*
udanax-top.st:32142:RealPos class methodsFor: 'creation'!
{RealPos} makeIEEE8: value {IEEE8}
	"See comment in XuReal::makeIEEE64"
	self knownBug. "must ensure that it is a number, and convert -0 to +0"
	
	^IEEE8Pos create: value!
*/
}

/**
 * {PrimFloat CLIENT} value
 */
public static void info() {
throw new UnsupportedOperationException();/*
udanax-top.st:32151:RealPos class methodsFor: 'smalltalk: system'!
info.stProtocol
"{PrimFloat CLIENT} value
"!
*/
}

public static String exportName() {
throw new UnsupportedOperationException();/*
udanax-top.st:32157:RealPos class methodsFor: 'smalltalk: promise'!
exportName
	^'Real'!
*/
}
}
