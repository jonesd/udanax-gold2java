/*
 * Abora-Gold
 * Part of the Abora hypertext project: http://www.abora.org
 * Copyright 2003 David G Jones
 * 
 * Translated from Udanax-Gold source code: http://www.udanax.com
 * Copyright 1979-1999 Udanax.com. All rights reserved
 */
package org.abora.gold.tumbler;

import java.io.PrintWriter;
import org.abora.gold.edgeregion.TransitionEdge;
import org.abora.gold.spaces.basic.Position;
import org.abora.gold.tumbler.Sequence;
import org.abora.gold.tumbler.SequenceEdge;
import org.abora.gold.tumbler.SequenceMapping;
import org.abora.gold.xcvr.Rcvr;
import org.abora.gold.xcvr.Xmtr;
import org.abora.gold.xpp.basic.Heaper;


public class SequenceEdge extends TransitionEdge {
	protected Sequence mySequence;
/*
udanax-top.st:63627:
TransitionEdge subclass: #SequenceEdge
	instanceVariableNames: 'mySequence {Sequence}'
	classVariableNames: ''
	poolDictionaries: ''
	category: 'Xanadu-tumbler'!
*/
/*
udanax-top.st:63631:
(SequenceEdge getOrMakeCxxClassDescription)
	attributes: ((Set new) add: #DEFERRED; add: #COPY; yourself)!
*/

public int actualHashForEqual() {
throw new UnsupportedOperationException();/*
udanax-top.st:63636:SequenceEdge methodsFor: 'testing'!
{UInt32} actualHashForEqual
	^self sequence hashForEqual bitXor: self getCategory hashForEqual!
*/
}

/**
 * Whether the position is strictly less than this edge
 */
public boolean follows(Position pos) {
throw new UnsupportedOperationException();/*
udanax-top.st:63640:SequenceEdge methodsFor: 'testing'!
{BooleanVar} follows: pos {Position}
	"Whether the position is strictly less than this edge"
	
	self subclassResponsibility!
*/
}

public boolean isEqual(Heaper other) {
throw new UnsupportedOperationException();/*
udanax-top.st:63645:SequenceEdge methodsFor: 'testing'!
{BooleanVar} isEqual: other {Heaper}
	self subclassResponsibility!
*/
}

/**
 * Whether there is precisely one position between this edge and the next one
 */
public boolean isFollowedBy(TransitionEdge next) {
throw new UnsupportedOperationException();/*
udanax-top.st:63649:SequenceEdge methodsFor: 'testing'!
{BooleanVar} isFollowedBy: next {TransitionEdge}
	"Whether there is precisely one position between this edge and the next one"
	
	self subclassResponsibility!
*/
}

/**
 * Defines a full ordering among all edges in a given CoordinateSpace
 */
public boolean isGE(TransitionEdge other) {
throw new UnsupportedOperationException();/*
udanax-top.st:63654:SequenceEdge methodsFor: 'testing'!
{BooleanVar} isGE: other {TransitionEdge}
	"Defines a full ordering among all edges in a given CoordinateSpace"
	
	self subclassResponsibility!
*/
}

/**
 * Whether this edge touches the same position the other does
 */
public boolean touches(TransitionEdge other) {
throw new UnsupportedOperationException();/*
udanax-top.st:63659:SequenceEdge methodsFor: 'testing'!
{BooleanVar} touches: other {TransitionEdge}
	"Whether this edge touches the same position the other does"
	
	self subclassResponsibility!
*/
}

public Sequence sequence() {
throw new UnsupportedOperationException();/*
udanax-top.st:63666:SequenceEdge methodsFor: 'accessing'!
{Sequence} sequence
	^mySequence!
*/
}

/**
 * Transform the edge by the given mapping
 */
public SequenceEdge transformedBy(SequenceMapping dsp) {
throw new UnsupportedOperationException();/*
udanax-top.st:63670:SequenceEdge methodsFor: 'accessing'!
{SequenceEdge} transformedBy: dsp {SequenceMapping}
	"Transform the edge by the given mapping"
	
	self subclassResponsibility!
*/
}

public void printOn(PrintWriter oo) {
throw new UnsupportedOperationException();/*
udanax-top.st:63677:SequenceEdge methodsFor: 'printing'!
{void} printOn: oo {ostream reference}
	oo << self getCategory name << '(' << mySequence << ')'!
*/
}

/**
 * Print a description of this transition
 */
public void printTransitionOn(PrintWriter oo, boolean entering, boolean touchesPrevious) {
throw new UnsupportedOperationException();/*
udanax-top.st:63681:SequenceEdge methodsFor: 'printing'!
{void} printTransitionOn: oo {ostream reference}
	with: entering {BooleanVar}
	with: touchesPrevious {BooleanVar}
	"Print a description of this transition"
	
	self subclassResponsibility!
*/
}

public  SequenceEdge(Sequence sequence) {
	super(null);
throw new UnsupportedOperationException();/*
udanax-top.st:63690:SequenceEdge methodsFor: 'create'!
create: sequence {Sequence}
	super create.
	mySequence := sequence.!
*/
}

public  SequenceEdge(Rcvr receiver) {
	super(receiver);
throw new UnsupportedOperationException();/*
udanax-top.st:63697:SequenceEdge methodsFor: 'generated:'!
create.Rcvr: receiver {Rcvr}
	super create.Rcvr: receiver.
	mySequence _ receiver receiveHeaper.!
*/
}

public void sendSelfTo(Xmtr xmtr) {
throw new UnsupportedOperationException();/*
udanax-top.st:63701:SequenceEdge methodsFor: 'generated:'!
{void} sendSelfTo: xmtr {Xmtr}
	super sendSelfTo: xmtr.
	xmtr sendHeaper: mySequence.!
*/
}
}
