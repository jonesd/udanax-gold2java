/*
 * Abora-Gold
 * Part of the Abora hypertext project: http://www.abora.org
 * Copyright 2003 David G Jones
 * 
 * Translated from Udanax-Gold source code: http://www.udanax.com
 * Copyright 1979-1999 Udanax.com. All rights reserved
 */
package org.abora.gold.primtab;

import java.io.PrintWriter;
import org.abora.gold.testing.Tester;
import org.abora.gold.xcvr.Rcvr;
import org.abora.gold.xcvr.Xmtr;


public class PrimPtrTableTester extends Tester {
/*
udanax-top.st:59626:
Tester subclass: #PrimPtrTableTester
	instanceVariableNames: ''
	classVariableNames: ''
	poolDictionaries: ''
	category: 'Xanadu-primtab'!
*/
/*
udanax-top.st:59630:
(PrimPtrTableTester getOrMakeCxxClassDescription)
	attributes: ((Set new) add: #CONCRETE; add: #(COPY boot ); yourself)!
*/

public void accessTestOn(PrintWriter oo) {
throw new UnsupportedOperationException();/*
udanax-top.st:59635:PrimPtrTableTester methodsFor: 'tests'!
{void} accessTestOn: oo {ostream reference}
	| tab {PrimPtrTable} |
	"For this tests, I use as keys category pointers from the minimal xpp set"
	tab := PrimPtrTable make: 7.
	"first test a few introduces"
	tab at: 1 introduce: Heaper.
	tab at: 2 introduce: Category.
	tab at: 3 introduce: PrimIndexTable.
	(tab get: 1) ~~ Heaper ifTrue: [ Heaper BLAST: #IntroduceFailed ].
	(tab get: 2) ~~ Category ifTrue: [ Heaper BLAST: #IntroduceFailed ].
	(tab get: 3) ~~ PrimIndexTable ifTrue: [ Heaper BLAST: #IntroduceFailed ].
	"now do some more to cause a grow."
	tab at: 4 introduce: Tester.
	tab at: 5 introduce: PrimIndexTableTester.
	tab at: 7 introduce: Recipe.
	tab at: 8 introduce: BootMaker.
	(tab get: 1) ~~ Heaper ifTrue: [ Heaper BLAST: #IntroduceFailed ].
	(tab get: 2) ~~ Category ifTrue: [ Heaper BLAST: #IntroduceFailed ].
	(tab get: 3) ~~ PrimIndexTable ifTrue: [ Heaper BLAST: #IntroduceFailed ].
	(tab get: 4) ~~ Tester ifTrue: [ Heaper BLAST: #IntroduceFailed ].
	(tab get: 5) ~~ PrimIndexTableTester ifTrue: [ Heaper BLAST: #IntroduceFailed ].
	(tab get: 7) ~~ Recipe ifTrue: [ Heaper BLAST: #IntroduceFailed ].
	(tab get: 8) ~~ BootMaker ifTrue: [ Heaper BLAST: #IntroduceFailed ].
	"Now remove some stuff."
	tab remove: 7.
	(tab get: 1) ~~ Heaper ifTrue: [ Heaper BLAST: #RemoveFouled ].
	(tab get: 2) ~~ Category ifTrue: [ Heaper BLAST: #RemoveFouled ].
	(tab get: 3) ~~ PrimIndexTable ifTrue: [ Heaper BLAST: #RemoveFouled ].
	(tab get: 4) ~~ Tester ifTrue: [ Heaper BLAST: #RemoveFouled ].
	(tab get: 5) ~~ PrimIndexTableTester ifTrue: [ Heaper BLAST: #RemoveFouled ].
	(tab get: 8) ~~ BootMaker ifTrue: [ Heaper BLAST: #RemoveFouled ].!
*/
}

public void allTestsOn(PrintWriter oo) {
throw new UnsupportedOperationException();/*
udanax-top.st:59669:PrimPtrTableTester methodsFor: 'testing'!
{void} allTestsOn: oo {ostream reference} 
	self accessTestOn: oo!
*/
}

public  PrimPtrTableTester(Rcvr receiver) {
throw new UnsupportedOperationException();/*
udanax-top.st:59675:PrimPtrTableTester methodsFor: 'generated:'!
create.Rcvr: receiver {Rcvr}
	super create.Rcvr: receiver.!
*/
}

public void sendSelfTo(Xmtr xmtr) {
throw new UnsupportedOperationException();/*
udanax-top.st:59678:PrimPtrTableTester methodsFor: 'generated:'!
{void} sendSelfTo: xmtr {Xmtr}
	super sendSelfTo: xmtr.!
*/
}
}
