/*
 * Abora-Gold
 * Part of the Abora hypertext project: http://www.abora.org
 * Copyright 2003 David G Jones
 * 
 * Translated from Udanax-Gold source code: http://www.udanax.com
 * Copyright 1979-1999 Udanax.com. All rights reserved
 */
package org.abora.gold.primtab;

import java.io.PrintWriter;
import org.abora.gold.cache.InstanceCache;
import org.abora.gold.collection.basic.PtrArray;
import org.abora.gold.collection.steppers.Stepper;
import org.abora.gold.xpp.basic.Heaper;


public class PrimSetStepper extends Stepper {
	protected PtrArray myPtrs;
	protected byte myIndex;
	protected static InstanceCache SomeSteppers;
/*
udanax-top.st:54976:
Stepper subclass: #PrimSetStepper
	instanceVariableNames: '
		myPtrs {PtrArray}
		myIndex {Int4}'
	classVariableNames: 'SomeSteppers {InstanceCache} '
	poolDictionaries: ''
	category: 'Xanadu-primtab'!
*/
/*
udanax-top.st:54982:
(PrimSetStepper getOrMakeCxxClassDescription)
	attributes: ((Set new) add: #CONCRETE; yourself)!
*/
/*
udanax-top.st:55036:
PrimSetStepper class
	instanceVariableNames: ''!
*/
/*
udanax-top.st:55039:
(PrimSetStepper getOrMakeCxxClassDescription)
	attributes: ((Set new) add: #CONCRETE; yourself)!
*/

public Stepper copy() {
throw new UnsupportedOperationException();/*
udanax-top.st:54987:PrimSetStepper methodsFor: 'create'!
{Stepper} copy
	| result {Heaper} |
	result := SomeSteppers fetch.
	result == NULL
		ifTrue: [^ PrimSetStepper create: myPtrs with: Int32Zero]
		ifFalse: [^ (PrimSetStepper new.Become: result) create: myPtrs with: Int32Zero]!
*/
}

public  PrimSetStepper(PtrArray array, int index) {
throw new UnsupportedOperationException();/*
udanax-top.st:54994:PrimSetStepper methodsFor: 'create'!
create: array {PtrArray} with: index {Int32}
	| tmp {Heaper wimpy} |
	super create.
	myPtrs := array.
	myIndex := index.
	[myIndex < myPtrs count and: [(tmp _ myPtrs fetch: myIndex) == NULL or: [tmp == PrimRemovedObject make]]]
		whileTrue: [ myIndex := myIndex + 1 ].!
*/
}

public void destroy() {
throw new UnsupportedOperationException();/*
udanax-top.st:55002:PrimSetStepper methodsFor: 'create'!
{void} destroy
	(SomeSteppers store: self) ifFalse:
		[super destroy]!
*/
}

public Heaper fetch() {
throw new UnsupportedOperationException();/*
udanax-top.st:55008:PrimSetStepper methodsFor: 'accessing'!
{Heaper wimpy} fetch
	myIndex < myPtrs count
		ifTrue: [ ^ myPtrs fetch: myIndex ]
		ifFalse: [ ^ NULL ]!
*/
}

public boolean hasValue() {
throw new UnsupportedOperationException();/*
udanax-top.st:55013:PrimSetStepper methodsFor: 'accessing'!
{BooleanVar} hasValue
	^ myIndex < myPtrs count!
*/
}

public void step() {
throw new UnsupportedOperationException();/*
udanax-top.st:55016:PrimSetStepper methodsFor: 'accessing'!
{void} step
	|tmp {Heaper wimpy} |
	myIndex := myIndex + 1.
	[myIndex < myPtrs count and: [(tmp _ myPtrs fetch: myIndex) == NULL or: [tmp == PrimRemovedObject make]]]
		whileTrue: [ myIndex := myIndex + 1 ].!
*/
}

public void printOn(PrintWriter oo) {
throw new UnsupportedOperationException();/*
udanax-top.st:55024:PrimSetStepper methodsFor: 'printint'!
{void} printOn: oo {ostream reference}
	| printedElem {BooleanVar} |
	oo << 'PrimSetStepper on {'.
	printedElem := false.
	Int32Zero almostTo: myPtrs count do: [:i {Int32} |
		(myPtrs fetch: i) ~~ NULL ifTrue: [
			printedElem ifTrue: [oo << ', '].
			oo << (myPtrs fetch: i).
			printedElem := true]].
	oo << '}'!
*/
}

public static Heaper make(PtrArray ptrs) {
throw new UnsupportedOperationException();/*
udanax-top.st:55044:PrimSetStepper class methodsFor: 'create'!
{Stepper} make: ptrs {PtrArray}
	| result {Heaper} |
	result := SomeSteppers fetch.
	result == NULL
		ifTrue: [^ PrimSetStepper create: ptrs with: Int32Zero]
		ifFalse: [^ (PrimSetStepper new.Become: result) create: ptrs with: Int32Zero]!
*/
}

public static void initTimeNonInherited() {
throw new UnsupportedOperationException();/*
udanax-top.st:55053:PrimSetStepper class methodsFor: 'smalltalk: init'!
initTimeNonInherited
	SomeSteppers := InstanceCache make: 8!
*/
}

public static void linkTimeNonInherited() {
throw new UnsupportedOperationException();/*
udanax-top.st:55056:PrimSetStepper class methodsFor: 'smalltalk: init'!
linkTimeNonInherited
	SomeSteppers := NULL!
*/
}
}
