/*
 * Abora-Gold
 * Part of the Abora hypertext project: http://www.abora.org
 * Copyright 2003 David G Jones
 * 
 * Translated from Udanax-Gold source code: http://www.udanax.com
 * Copyright 1979-1999 Udanax.com. All rights reserved
 */
package org.abora.gold.primtab;

import org.abora.gold.collection.basic.PtrArray;
import org.abora.gold.collection.steppers.Stepper;
import org.abora.gold.primtab.PrimSet;
import org.abora.gold.wparray.XnExecutor;
import org.abora.gold.xpp.basic.Heaper;


/**
 * A set of pointers.  May be strong or weak.  If we have a separate executor, it is called
 * with the remaining size after removal.
 */
public class PrimSet extends Heaper {
	protected PtrArray myPtrs;
	protected byte myTally;
	protected boolean myWeakness;
	protected XnExecutor myExecutor;
/*
udanax-top.st:33854:
Heaper subclass: #PrimSet
	instanceVariableNames: '
		myPtrs {PtrArray}
		myTally {Int4}
		myWeakness {BooleanVar}
		myExecutor {XnExecutor | NULL}'
	classVariableNames: ''
	poolDictionaries: ''
	category: 'Xanadu-primtab'!
*/
/*
udanax-top.st:33862:
PrimSet comment:
'A set of pointers.  May be strong or weak.  If we have a separate executor, it is called with the remaining size after removal.'!
*/
/*
udanax-top.st:33864:
(PrimSet getOrMakeCxxClassDescription)
	friends:
'/- friends for class PrimSet -/
friend class PrimSetExecutor;';
	attributes: ((Set new) add: #CONCRETE; yourself)!
*/
/*
udanax-top.st:34003:
PrimSet class
	instanceVariableNames: ''!
*/
/*
udanax-top.st:34006:
(PrimSet getOrMakeCxxClassDescription)
	friends:
'/- friends for class PrimSet -/
friend class PrimSetExecutor;';
	attributes: ((Set new) add: #CONCRETE; yourself)!
*/

public Stepper stepper() {
throw new UnsupportedOperationException();/*
udanax-top.st:33872:PrimSet methodsFor: 'enumerating'!
{Stepper} stepper
	^ PrimSetStepper make: myPtrs!
*/
}

public void introduce(Heaper value) {
throw new UnsupportedOperationException();/*
udanax-top.st:33877:PrimSet methodsFor: 'adding-removing'!
{void} introduce: value {Heaper}
	| loc {Int32} |
	loc := self hashFind: value.
	loc == -1 ifTrue: [
		self hack.
		self grow.
		loc := self hashFind: value].
	(myPtrs fetch: loc) == value
		ifTrue: [ Heaper BLAST: #AlreadyInSet ]
		ifFalse: [
			myPtrs at: loc store: value.
			myTally := myTally + 1.
			myTally > (2 * myPtrs count / 3) ifTrue: [ self grow ]]!
*/
}

public void remove(Heaper value) {
throw new UnsupportedOperationException();/*
udanax-top.st:33891:PrimSet methodsFor: 'adding-removing'!
{void} remove: value {Heaper}
	| loc {Int32} |
	loc := self hashFind: value.
	(myPtrs fetch: loc) ~~ value ifTrue: [ Heaper BLAST: #NotInSet ].
	myPtrs at: loc store: PrimRemovedObject make.
	myTally := myTally - 1.!
*/
}

public void store(Heaper value) {
throw new UnsupportedOperationException();/*
udanax-top.st:33898:PrimSet methodsFor: 'adding-removing'!
{void} store: value {Heaper}
	| loc {Int32} |
	loc := self hashFind: value.
	loc == -1 ifTrue: [
		self hack.
		self grow.
		loc := self hashFind: value].
	(myPtrs fetch: loc) ~= value ifTrue: [
		myPtrs at: loc store: value.
		myTally := myTally + 1.
		myTally > (2 * myPtrs count / 3) ifTrue: [ self grow ]]!
*/
}

public void wipe(Heaper value) {
throw new UnsupportedOperationException();/*
udanax-top.st:33910:PrimSet methodsFor: 'adding-removing'!
{void} wipe: value {Heaper}
	| loc {Int32} |
	loc := self hashFind: value.
	(myPtrs fetch: loc) == value ifTrue: [
		myPtrs at: loc store: PrimRemovedObject make.
		myTally := myTally - 1].!
*/
}

public void wipeAll() {
throw new UnsupportedOperationException();/*
udanax-top.st:33917:PrimSet methodsFor: 'adding-removing'!
{void} wipeAll
	myPtrs storeAll.
	myTally := Int32Zero.!
*/
}

public int count() {
throw new UnsupportedOperationException();/*
udanax-top.st:33923:PrimSet methodsFor: 'accessing'!
{Int32 INLINE} count
	^myTally!
*/
}

public boolean hasMember(Heaper element) {
throw new UnsupportedOperationException();/*
udanax-top.st:33926:PrimSet methodsFor: 'accessing'!
{BooleanVar} hasMember: element {Heaper}
	| tmp {Heaper wimpy} |
	tmp _ myPtrs fetch: (self hashFind: element).
	^ tmp == element!
*/
}

public boolean isEmpty() {
throw new UnsupportedOperationException();/*
udanax-top.st:33931:PrimSet methodsFor: 'accessing'!
{BooleanVar} isEmpty
	^myTally == Int32Zero!
*/
}

public void grow() {
throw new UnsupportedOperationException();/*
udanax-top.st:33936:PrimSet methodsFor: 'private:'!
{void} grow
	| oldPtrs {PtrArray} removed {Heaper wimpy} |
	oldPtrs := myPtrs.
	myWeakness
		ifTrue: [myPtrs := WeakPtrArray make: (PrimSetExecutor make: self) with: 5 * oldPtrs count // 3]
		ifFalse: [myPtrs := PtrArray nulls: 5 * oldPtrs count // 3].
	removed := PrimRemovedObject make.
	Int32Zero almostTo: oldPtrs count do: [:i {Int32} |
		| tmp {Heaper wimpy} |
		tmp := oldPtrs fetch: i.
		(tmp ~~ NULL and: [tmp ~~ removed]) ifTrue:
			[|loc {Int32} |
			loc := self hashFind: tmp.
			myPtrs at: loc store: tmp]].
	oldPtrs destroy!
*/
}

public int hashFind(Heaper value) {
throw new UnsupportedOperationException();/*
udanax-top.st:33952:PrimSet methodsFor: 'private:'!
{Int32} hashFind: value {Heaper}
	| loc {Int32} firstRemoved {Int32} tmp {Heaper wimpy} removed {Heaper wimpy} looped {BooleanVar} |
	firstRemoved _ -1.
	loc := value hashForEqual.
	loc :=  (FHash fastHash.UInt32: loc) \\ myPtrs count.
	removed _ PrimRemovedObject make.
	looped _ false.
	[(tmp _ myPtrs fetch: loc) ~~ NULL] whileTrue:
		[tmp == value ifTrue: [ ^ loc ].
		tmp == removed ifTrue:
			[firstRemoved == -1 ifTrue: [firstRemoved _ loc]].
		loc := loc + 1.
		loc >= myPtrs count ifTrue: 
			[looped ifTrue: [^firstRemoved] ifFalse: [looped _ true].
			loc := Int32Zero]].
	firstRemoved ~~ -1
		ifTrue: [ ^ firstRemoved ]
		ifFalse: [ ^ loc ]!
*/
}

public  PrimSet(int size, XnExecutor exec) {
throw new UnsupportedOperationException();/*
udanax-top.st:33973:PrimSet methodsFor: 'protected: create'!
create: size {Int32} with.Executor: exec {XnExecutor}
	super create.
	myWeakness := true.
	myExecutor := exec.
	myPtrs := WeakPtrArray make: (PrimSetExecutor make: self) with: size.
	myTally := Int32Zero.!
*/
}

public  PrimSet(int size, boolean weakness) {
throw new UnsupportedOperationException();/*
udanax-top.st:33980:PrimSet methodsFor: 'protected: create'!
create: size {Int32} with: weakness {BooleanVar}
	super create.
	myWeakness := weakness.
	myExecutor := NULL.
	weakness
		ifTrue: [myPtrs := WeakPtrArray make: (PrimSetExecutor make: self) with: size]
		ifFalse: [myPtrs := PtrArray nulls: size].
	myTally := Int32Zero.!
*/
}

public void weakRemove(int index) {
throw new UnsupportedOperationException();/*
udanax-top.st:33991:PrimSet methodsFor: 'private: weakness'!
{void} weakRemove: index {Int32}
	myPtrs at: index store: PrimRemovedObject make. "NULL will mess up hashFind"
	myTally := myTally - 1.
	myExecutor ~~ NULL ifTrue: [
		myExecutor execute: myTally].!
*/
}

public int actualHashForEqual() {
throw new UnsupportedOperationException();/*
udanax-top.st:33999:PrimSet methodsFor: 'testing'!
{UInt32} actualHashForEqual
	^Heaper takeOop!
*/
}

public static Heaper make() {
throw new UnsupportedOperationException();/*
udanax-top.st:34014:PrimSet class methodsFor: 'create'!
make
	^ self create: 7 with: false!
*/
}

public static Heaper make(int size) {
throw new UnsupportedOperationException();/*
udanax-top.st:34017:PrimSet class methodsFor: 'create'!
make: size {Int32}
	^ self create: size with: false!
*/
}

public static PrimSet weak() {
throw new UnsupportedOperationException();/*
udanax-top.st:34020:PrimSet class methodsFor: 'create'!
{PrimSet} weak
	^ self create: 7 with: true!
*/
}

public static PrimSet weak(int size) {
throw new UnsupportedOperationException();/*
udanax-top.st:34023:PrimSet class methodsFor: 'create'!
{PrimSet} weak: size {Int32}
	^ self create: size with: true!
*/
}

public static PrimSet weak(int size, XnExecutor exec) {
throw new UnsupportedOperationException();/*
udanax-top.st:34026:PrimSet class methodsFor: 'create'!
{PrimSet} weak: size {Int32} with: exec {XnExecutor}
	^ self  create: size with.Executor: exec!
*/
}

public static void create(int size, XnExecutor exec) {
throw new UnsupportedOperationException();/*
udanax-top.st:34031:PrimSet class methodsFor: 'smalltalk: create'!
create: size {Int32} with.Executor: exec {XnExecutor}
	^self new create: size with.Executor: exec!
*/
}
}
