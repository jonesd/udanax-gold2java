/*
 * Abora-Gold
 * Part of the Abora hypertext project: http://www.abora.org
 * Copyright 2003 David G Jones
 * 
 * Translated from Udanax-Gold source code: http://www.udanax.com
 * Copyright 1979-1999 Udanax.com. All rights reserved
 */
package org.abora.gold.primtab;

import org.abora.gold.collection.basic.IntegerVarArray;
import org.abora.gold.collection.basic.PtrArray;
import org.abora.gold.collection.steppers.Stepper;
import org.abora.gold.java.missing.IntegerVar;
import org.abora.gold.xpp.basic.Heaper;


/**
 * Stepper over map from integers to strong or wimpy pointers
 */
public class PrimPtrTableStepper extends Stepper {
	protected PtrArray myPtrs;
	protected IntegerVarArray myIndices;
	protected byte myIndex;
/*
udanax-top.st:54925:
Stepper subclass: #PrimPtrTableStepper
	instanceVariableNames: '
		myPtrs {PtrArray}
		myIndices {IntegerVarArray}
		myIndex {Int4}'
	classVariableNames: ''
	poolDictionaries: ''
	category: 'Xanadu-primtab'!
*/
/*
udanax-top.st:54932:
PrimPtrTableStepper comment:
'Stepper over map from integers to strong or wimpy pointers'!
*/
/*
udanax-top.st:54934:
(PrimPtrTableStepper getOrMakeCxxClassDescription)
	friends:
'/- friends for class PrimPtrTableStepper -/
friend class PrimPtrTable;';
	attributes: ((Set new) add: #CONCRETE; yourself)!
*/

public  PrimPtrTableStepper(IntegerVarArray from, PtrArray to, int index) {
throw new UnsupportedOperationException();/*
udanax-top.st:54942:PrimPtrTableStepper methodsFor: 'protected: create'!
create: from {IntegerVarArray} with: to {PtrArray} with: index {Int32}
	| tmp {Heaper wimpy} |
	super create.
	myIndices := from.
	myPtrs := to.
	myIndex := index.
	[myIndex < myPtrs count and: [(tmp _ myPtrs fetch: myIndex) == NULL or: [tmp == PrimRemovedObject make]]]
		whileTrue: [ myIndex := myIndex + 1 ].!
*/
}

public Heaper fetch() {
throw new UnsupportedOperationException();/*
udanax-top.st:54953:PrimPtrTableStepper methodsFor: 'accessing'!
{Heaper wimpy} fetch
	myIndex < myPtrs count ifTrue: [ ^ myPtrs fetch: myIndex ]
	ifFalse: [ ^ NULL ]!
*/
}

public boolean hasValue() {
throw new UnsupportedOperationException();/*
udanax-top.st:54957:PrimPtrTableStepper methodsFor: 'accessing'!
{BooleanVar} hasValue
	^ myIndex < myPtrs count!
*/
}

public IntegerVar index() {
throw new UnsupportedOperationException();/*
udanax-top.st:54960:PrimPtrTableStepper methodsFor: 'accessing'!
{IntegerVar} index
	myIndex < myIndices count ifTrue: [^ myIndices integerVarAt: myIndex].
	Heaper BLAST: #EmptyStepper.
	^ NULL "Hush up the compiler"!
*/
}

public void step() {
throw new UnsupportedOperationException();/*
udanax-top.st:54965:PrimPtrTableStepper methodsFor: 'accessing'!
{void} step
	|tmp {Heaper wimpy} |
	myIndex := myIndex + 1.
	[myIndex < myPtrs count and: [(tmp _ myPtrs fetch: myIndex) == NULL or: [tmp == PrimRemovedObject make]]]
		whileTrue: [ myIndex := myIndex + 1 ].!
*/
}

public Stepper copy() {
throw new UnsupportedOperationException();/*
udanax-top.st:54973:PrimPtrTableStepper methodsFor: 'create'!
{Stepper} copy
	^ PrimPtrTableStepper create: myIndices with: myPtrs with: myIndex!
*/
}
}
