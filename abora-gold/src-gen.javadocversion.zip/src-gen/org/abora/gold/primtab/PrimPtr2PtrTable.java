/*
 * Abora-Gold
 * Part of the Abora hypertext project: http://www.abora.org
 * Copyright 2003 David G Jones
 * 
 * Translated from Udanax-Gold source code: http://www.udanax.com
 * Copyright 1979-1999 Udanax.com. All rights reserved
 */
package org.abora.gold.primtab;

import org.abora.gold.collection.basic.PtrArray;
import org.abora.gold.primtab.PrimPtr2PtrTableStepper;
import org.abora.gold.xpp.basic.Heaper;


/**
 * Map wimpy pointers to strong ptrs
 */
public class PrimPtr2PtrTable extends Heaper {
	protected PtrArray myFromPtrs;
	protected PtrArray myToPtrs;
	protected byte myTally;
/*
udanax-top.st:33459:
Heaper subclass: #PrimPtr2PtrTable
	instanceVariableNames: '
		myFromPtrs {PtrArray}
		myToPtrs {PtrArray}
		myTally {Int4}'
	classVariableNames: ''
	poolDictionaries: ''
	category: 'Xanadu-primtab'!
*/
/*
udanax-top.st:33466:
PrimPtr2PtrTable comment:
'Map wimpy pointers to strong ptrs'!
*/
/*
udanax-top.st:33468:
(PrimPtr2PtrTable getOrMakeCxxClassDescription)
	friends:
'/- friends for class PrimPtr2PtrTable -/
friend SPTR(PrimPtr2PtrTable)  primPtr2PtrTable (Int4 size);';
	attributes: ((Set new) add: #CONCRETE; yourself)!
*/
/*
udanax-top.st:33581:
PrimPtr2PtrTable class
	instanceVariableNames: ''!
*/
/*
udanax-top.st:33584:
(PrimPtr2PtrTable getOrMakeCxxClassDescription)
	friends:
'/- friends for class PrimPtr2PtrTable -/
friend SPTR(PrimPtr2PtrTable)  primPtr2PtrTable (Int4 size);';
	attributes: ((Set new) add: #CONCRETE; yourself)!
*/

public PrimPtr2PtrTableStepper stepper() {
throw new UnsupportedOperationException();/*
udanax-top.st:33476:PrimPtr2PtrTable methodsFor: 'enumerating'!
{PrimPtr2PtrTableStepper} stepper
	^ PrimPtr2PtrTableStepper create: myFromPtrs with: myToPtrs with: Int32Zero!
*/
}

public void atIntroduce(Heaper key, Heaper value) {
throw new UnsupportedOperationException();/*
udanax-top.st:33481:PrimPtr2PtrTable methodsFor: 'accessing'!
{void} at: key {Heaper} introduce: value {Heaper}
	| loc {Int32} tmp {Heaper wimpy} |
	loc := self hashFind: key.
	((tmp _ myToPtrs fetch: loc) ~~ NULL and: [tmp ~~ PrimRemovedObject make]) ifTrue:
		[ Heaper BLAST: #AlreadyInTable ].
	myToPtrs at: loc store: value.
	myFromPtrs at: loc store: key.
	myTally := myTally + 1.
	myTally > (2 * myFromPtrs count / 3) ifTrue: [ self grow ]!
*/
}

public void atStore(Heaper key, Heaper value) {
throw new UnsupportedOperationException();/*
udanax-top.st:33491:PrimPtr2PtrTable methodsFor: 'accessing'!
{void} at: key {Heaper} store: value {Heaper}
	| loc {Int32} |
	loc := self hashFind: key.
	(myToPtrs fetch: loc) == NULL ifTrue: [ myTally := myTally + 1].
	myToPtrs at: loc store: value.
	myFromPtrs at: loc store: key.
	myTally > (2 * myFromPtrs count / 3) ifTrue: [ self grow ]!
*/
}

public int count() {
throw new UnsupportedOperationException();/*
udanax-top.st:33499:PrimPtr2PtrTable methodsFor: 'accessing'!
{Int32 INLINE} count
	^myTally!
*/
}

public Heaper fetch(Heaper key) {
throw new UnsupportedOperationException();/*
udanax-top.st:33502:PrimPtr2PtrTable methodsFor: 'accessing'!
{Heaper} fetch: key {Heaper}
	| tmp {Heaper wimpy} |
	tmp _ myToPtrs fetch: (self hashFind: key).
	tmp == PrimRemovedObject make
		ifTrue: [  ^ NULL ]
		ifFalse: [ ^ tmp ]!
*/
}

public Heaper get(Heaper ptr) {
throw new UnsupportedOperationException();/*
udanax-top.st:33509:PrimPtr2PtrTable methodsFor: 'accessing'!
{Heaper} get: ptr {Heaper}
	| result {Heaper} |
	((result _ myToPtrs fetch: (self hashFind: ptr)) == NULL
		or: [(result basicCast: Heaper star) == (PrimRemovedObject make basicCast: Heaper star)])
		ifTrue: [ Heaper BLAST: #NotInTable ].
	^ result!
*/
}

public void remove(Heaper key) {
throw new UnsupportedOperationException();/*
udanax-top.st:33516:PrimPtr2PtrTable methodsFor: 'accessing'!
{void} remove: key {Heaper}
	| loc {Int32} |
	loc := self hashFind: key.
	(myToPtrs fetch: loc) == NULL ifTrue: [ Heaper BLAST: #NotInTable ].
	myToPtrs at: loc store: PrimRemovedObject make.
	myTally := myTally - 1.!
*/
}

public void destruct() {
throw new UnsupportedOperationException();/*
udanax-top.st:33525:PrimPtr2PtrTable methodsFor: 'protected: destruct'!
{void} destruct
	myFromPtrs destroy.
	myToPtrs destroy.
	super destruct!
*/
}

public  PrimPtr2PtrTable(int size) {
throw new UnsupportedOperationException();/*
udanax-top.st:33532:PrimPtr2PtrTable methodsFor: 'protected: create'!
create: size {Int32}
	super create.
	myFromPtrs := WeakPtrArray make: XnExecutor noopExecutor with: size.
	myToPtrs := PtrArray nulls: size.
	myTally := Int32Zero.!
*/
}

public void grow() {
throw new UnsupportedOperationException();/*
udanax-top.st:33540:PrimPtr2PtrTable methodsFor: 'private:'!
{void} grow
	| oldFromPtrs {PtrArray} oldToPtrs {PtrArray} tmp {Heaper wimpy} removed {Heaper wimpy} |
	oldFromPtrs := myFromPtrs.
	oldToPtrs := myToPtrs.
	myFromPtrs := WeakPtrArray make: XnExecutor noopExecutor with: 5 * myFromPtrs count // 3.
	myToPtrs := PtrArray nulls: myFromPtrs count.
	removed _ PrimRemovedObject make.
	Int32Zero almostTo: oldFromPtrs count do: [:i {Int32} |
		| loc {Int32} |
		((tmp _ oldToPtrs fetch: i) ~~ NULL and: [tmp ~~ removed]) ifTrue:
			[loc := self hashFind: (oldFromPtrs fetch: i).
			myFromPtrs at: loc store: (oldFromPtrs fetch: i).
			myToPtrs at: loc store: (oldToPtrs fetch: i)]].
	oldFromPtrs destroy.
	oldToPtrs destroy!
*/
}

public int hashFind(Heaper key) {
throw new UnsupportedOperationException();/*
udanax-top.st:33556:PrimPtr2PtrTable methodsFor: 'private:'!
{Int32} hashFind: key {Heaper}
	| loc {Int32} firstRemoved {Int32} tmp {Heaper wimpy} removed {Heaper wimpy} looped {BooleanVar} |
	firstRemoved _ -1.
	loc := key hashForEqual.
	loc :=  (FHash fastHash.UInt32: loc) \\ myFromPtrs count.
	removed _ PrimRemovedObject make.
	looped _ false.
	[(tmp _ myToPtrs fetch: loc) ~~ NULL] whileTrue:
		[((myFromPtrs fetch: loc) basicCast: Heaper star) == key ifTrue: [ ^ loc ].
		tmp == removed ifTrue:
			[firstRemoved == -1 ifTrue: [firstRemoved _ loc]].
		loc := loc + 1.
		loc >= myFromPtrs count ifTrue: 
			[looped ifTrue: [^firstRemoved] ifFalse: [looped _ true].
			loc := Int32Zero]].
	firstRemoved ~~ -1
		ifTrue: [ ^ firstRemoved ]
		ifFalse: [ ^ loc ]!
*/
}

public int actualHashForEqual() {
throw new UnsupportedOperationException();/*
udanax-top.st:33577:PrimPtr2PtrTable methodsFor: 'testing'!
{UInt32} actualHashForEqual
	^Heaper takeOop!
*/
}

public static Heaper make(int size) {
throw new UnsupportedOperationException();/*
udanax-top.st:33592:PrimPtr2PtrTable class methodsFor: 'create'!
make: size {Int32}
	^ self create: size!
*/
}
}
