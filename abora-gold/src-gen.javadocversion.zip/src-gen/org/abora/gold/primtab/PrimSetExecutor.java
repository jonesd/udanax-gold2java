/*
 * Abora-Gold
 * Part of the Abora hypertext project: http://www.abora.org
 * Copyright 2003 David G Jones
 * 
 * Translated from Udanax-Gold source code: http://www.udanax.com
 * Copyright 1979-1999 Udanax.com. All rights reserved
 */
package org.abora.gold.primtab;

import org.abora.gold.primtab.PrimSet;
import org.abora.gold.wparray.XnExecutor;
import org.abora.gold.xpp.basic.Heaper;


public class PrimSetExecutor extends XnExecutor {
	protected PrimSet mySet;
/*
udanax-top.st:34034:
XnExecutor subclass: #PrimSetExecutor
	instanceVariableNames: 'mySet {PrimSet}'
	classVariableNames: ''
	poolDictionaries: ''
	category: 'Xanadu-primtab'!
*/
/*
udanax-top.st:34038:
(PrimSetExecutor getOrMakeCxxClassDescription)
	attributes: ((Set new) add: #CONCRETE; yourself)!
*/
/*
udanax-top.st:34053:
PrimSetExecutor class
	instanceVariableNames: ''!
*/
/*
udanax-top.st:34056:
(PrimSetExecutor getOrMakeCxxClassDescription)
	attributes: ((Set new) add: #CONCRETE; yourself)!
*/

public  PrimSetExecutor(PrimSet set) {
throw new UnsupportedOperationException();/*
udanax-top.st:34043:PrimSetExecutor methodsFor: 'protected: create'!
create: set {PrimSet}
	super create.
	mySet := set!
*/
}

public void execute(int estateIndex) {
throw new UnsupportedOperationException();/*
udanax-top.st:34049:PrimSetExecutor methodsFor: 'execution'!
{void} execute: estateIndex {Int32}
	mySet weakRemove: estateIndex!
*/
}

public static Heaper make(PrimSet set) {
throw new UnsupportedOperationException();/*
udanax-top.st:34061:PrimSetExecutor class methodsFor: 'pseudoconstructor'!
make: set {PrimSet}
	^ self create: set!
*/
}
}
