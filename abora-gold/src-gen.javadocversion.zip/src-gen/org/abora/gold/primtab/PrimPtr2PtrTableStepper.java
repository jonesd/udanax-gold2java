/*
 * Abora-Gold
 * Part of the Abora hypertext project: http://www.abora.org
 * Copyright 2003 David G Jones
 * 
 * Translated from Udanax-Gold source code: http://www.udanax.com
 * Copyright 1979-1999 Udanax.com. All rights reserved
 */
package org.abora.gold.primtab;

import org.abora.gold.collection.basic.PtrArray;
import org.abora.gold.collection.steppers.Stepper;
import org.abora.gold.xpp.basic.Heaper;


public class PrimPtr2PtrTableStepper extends Stepper {
	protected PtrArray myFromPtrs;
	protected PtrArray myToPtrs;
	protected byte myIndex;
/*
udanax-top.st:54877:
Stepper subclass: #PrimPtr2PtrTableStepper
	instanceVariableNames: '
		myFromPtrs {PtrArray}
		myToPtrs {PtrArray}
		myIndex {Int4}'
	classVariableNames: ''
	poolDictionaries: ''
	category: 'Xanadu-primtab'!
*/
/*
udanax-top.st:54884:
(PrimPtr2PtrTableStepper getOrMakeCxxClassDescription)
	friends:
'/- friends for class PrimPtr2PtrTableStepper -/
friend class PrimPtr2PtrTable;';
	attributes: ((Set new) add: #CONCRETE; yourself)!
*/

public Stepper copy() {
throw new UnsupportedOperationException();/*
udanax-top.st:54892:PrimPtr2PtrTableStepper methodsFor: 'create'!
{Stepper} copy
	^ PrimPtr2PtrTableStepper create: myFromPtrs with: myToPtrs with: myIndex!
*/
}

public Heaper fetch() {
throw new UnsupportedOperationException();/*
udanax-top.st:54897:PrimPtr2PtrTableStepper methodsFor: 'accessing'!
{Heaper wimpy} fetch
	myIndex < myToPtrs count ifTrue: [ ^ myToPtrs fetch: myIndex ]
	ifFalse: [ ^ NULL ]!
*/
}

public boolean hasValue() {
throw new UnsupportedOperationException();/*
udanax-top.st:54901:PrimPtr2PtrTableStepper methodsFor: 'accessing'!
{BooleanVar} hasValue
	^ myIndex < myToPtrs count!
*/
}

public Heaper heaperKey() {
throw new UnsupportedOperationException();/*
udanax-top.st:54904:PrimPtr2PtrTableStepper methodsFor: 'accessing'!
{Heaper} heaperKey
	myIndex < myFromPtrs count ifTrue: [^ myFromPtrs fetch: myIndex]
	ifFalse: [ ^ NULL ]!
*/
}

public void step() {
throw new UnsupportedOperationException();/*
udanax-top.st:54908:PrimPtr2PtrTableStepper methodsFor: 'accessing'!
{void} step
	|tmp {Heaper wimpy} |
	myIndex := myIndex + 1.
	[myIndex < myToPtrs count and: [(tmp _ myToPtrs fetch: myIndex) == NULL or: [tmp == PrimRemovedObject make]]]
		whileTrue: [ myIndex := myIndex + 1 ].!
*/
}

public  PrimPtr2PtrTableStepper(PtrArray from, PtrArray to, int index) {
throw new UnsupportedOperationException();/*
udanax-top.st:54916:PrimPtr2PtrTableStepper methodsFor: 'protected: create'!
create: from {PtrArray} with: to {PtrArray} with: index {Int32}
	| tmp {Heaper wimpy} |
	super create.
	myFromPtrs := from.
	myToPtrs := to.
	myIndex := index.
	[myIndex < myToPtrs count and: [(tmp _ myToPtrs fetch: myIndex) == NULL or: [tmp == PrimRemovedObject make]]]
		whileTrue: [ myIndex := myIndex + 1 ].!
*/
}
}
