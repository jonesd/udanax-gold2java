/*
 * Abora-Gold
 * Part of the Abora hypertext project: http://www.abora.org
 * Copyright 2003 David G Jones
 * 
 * Translated from Udanax-Gold source code: http://www.udanax.com
 * Copyright 1979-1999 Udanax.com. All rights reserved
 */
package org.abora.gold.primtab;

import org.abora.gold.primtab.PrimPtrTable;
import org.abora.gold.wparray.XnExecutor;
import org.abora.gold.xpp.basic.Heaper;


public class PrimPtrTableExecutor extends XnExecutor {
	protected PrimPtrTable myTable;
	protected XnExecutor myFollower;
/*
udanax-top.st:33784:
XnExecutor subclass: #PrimPtrTableExecutor
	instanceVariableNames: '
		myTable {PrimPtrTable}
		myFollower {XnExecutor | NULL}'
	classVariableNames: ''
	poolDictionaries: ''
	category: 'Xanadu-primtab'!
*/
/*
udanax-top.st:33790:
(PrimPtrTableExecutor getOrMakeCxxClassDescription)
	attributes: ((Set new) add: #CONCRETE; yourself)!
*/
/*
udanax-top.st:33806:
PrimPtrTableExecutor class
	instanceVariableNames: ''!
*/
/*
udanax-top.st:33809:
(PrimPtrTableExecutor getOrMakeCxxClassDescription)
	attributes: ((Set new) add: #CONCRETE; yourself)!
*/

public void execute(int estateIndex) {
throw new UnsupportedOperationException();/*
udanax-top.st:33795:PrimPtrTableExecutor methodsFor: 'invoking'!
{void} execute: estateIndex {Int32}
	myTable weakRemove: estateIndex with: myFollower!
*/
}

public  PrimPtrTableExecutor(PrimPtrTable table, XnExecutor follower) {
throw new UnsupportedOperationException();/*
udanax-top.st:33800:PrimPtrTableExecutor methodsFor: 'protected: create'!
create: table {PrimPtrTable} with: follower {XnExecutor | NULL}
	super create.
	myTable := table.
	myFollower := follower.!
*/
}

public static Heaper make(PrimPtrTable table, XnExecutor follower) {
throw new UnsupportedOperationException();/*
udanax-top.st:33814:PrimPtrTableExecutor class methodsFor: 'create'!
make: table {PrimPtrTable} with: follower {XnExecutor | NULL}
	^ self create: table with: follower!
*/
}
}
