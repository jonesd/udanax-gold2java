/*
 * Abora-Gold
 * Part of the Abora hypertext project: http://www.abora.org
 * Copyright 2003 David G Jones
 * 
 * Translated from Udanax-Gold source code: http://www.udanax.com
 * Copyright 1979-1999 Udanax.com. All rights reserved
 */
package org.abora.gold.primtab;

import java.io.PrintWriter;
import org.abora.gold.testing.Tester;
import org.abora.gold.xcvr.Rcvr;
import org.abora.gold.xcvr.Xmtr;


public class PrimIndexTableTester extends Tester {
/*
udanax-top.st:59571:
Tester subclass: #PrimIndexTableTester
	instanceVariableNames: ''
	classVariableNames: ''
	poolDictionaries: ''
	category: 'Xanadu-primtab'!
*/
/*
udanax-top.st:59575:
(PrimIndexTableTester getOrMakeCxxClassDescription)
	attributes: ((Set new) add: #CONCRETE; add: #(COPY boot ); yourself)!
*/

public void accessTestOn(PrintWriter oo) {
throw new UnsupportedOperationException();/*
udanax-top.st:59580:PrimIndexTableTester methodsFor: 'tests'!
{void} accessTestOn: oo {ostream reference}
	| tab {PrimIndexTable} |
	"For this tests, I use as keys category pointers from the minimal xpp set"
	tab := PrimIndexTable make: 7.
	"first test a few introduces"
	tab at: Heaper introduce: 1.
	tab at: Category introduce: 2.
	tab at: PrimIndexTable introduce: 3.
	(tab get: Heaper) ~~ 1 ifTrue: [ Heaper BLAST: #IntroduceFailed ].
	(tab get: Category) ~~ 2 ifTrue: [ Heaper BLAST: #IntroduceFailed ].
	(tab get: PrimIndexTable) ~~ 3 ifTrue: [ Heaper BLAST: #IntroduceFailed ].
	"now do some more to cause a grow."
	tab at: Tester introduce: 4.
	tab at: PrimIndexTableTester introduce: 5.
	tab at: Recipe introduce: 7.
	tab at: BootMaker introduce: 8.
	(tab get: Heaper) ~~ 1 ifTrue: [ Heaper BLAST: #IntroduceFailed ].
	(tab get: Category) ~~ 2 ifTrue: [ Heaper BLAST: #IntroduceFailed ].
	(tab get: PrimIndexTable) ~~ 3 ifTrue: [ Heaper BLAST: #IntroduceFailed ].
	(tab get: Tester) ~~ 4 ifTrue: [ Heaper BLAST: #IntroduceFailed ].
	(tab get: PrimIndexTableTester) ~~ 5 ifTrue: [ Heaper BLAST: #IntroduceFailed ].
	(tab get: Recipe) ~~ 7 ifTrue: [ Heaper BLAST: #IntroduceFailed ].
	(tab get: BootMaker) ~~ 8 ifTrue: [ Heaper BLAST: #IntroduceFailed ].
	"Now remove some stuff."
	tab remove: Recipe.
	(tab get: Heaper) ~~ 1 ifTrue: [ Heaper BLAST: #RemoveFouled ].
	(tab get: Category) ~~ 2 ifTrue: [ Heaper BLAST: #RemoveFouled ].
	(tab get: PrimIndexTable) ~~ 3 ifTrue: [ Heaper BLAST: #RemoveFouled ].
	(tab get: Tester) ~~ 4 ifTrue: [ Heaper BLAST: #IntroduceFailed ].
	(tab get: PrimIndexTableTester) ~~ 5 ifTrue: [ Heaper BLAST: #IntroduceFailed ].
	(tab get: BootMaker) ~~ 8 ifTrue: [ Heaper BLAST: #IntroduceFailed ].!
*/
}

public void allTestsOn(PrintWriter oo) {
throw new UnsupportedOperationException();/*
udanax-top.st:59614:PrimIndexTableTester methodsFor: 'testing'!
{void} allTestsOn: oo {ostream reference} 
	self accessTestOn: oo!
*/
}

public  PrimIndexTableTester(Rcvr receiver) {
throw new UnsupportedOperationException();/*
udanax-top.st:59620:PrimIndexTableTester methodsFor: 'generated:'!
create.Rcvr: receiver {Rcvr}
	super create.Rcvr: receiver.!
*/
}

public void sendSelfTo(Xmtr xmtr) {
throw new UnsupportedOperationException();/*
udanax-top.st:59623:PrimIndexTableTester methodsFor: 'generated:'!
{void} sendSelfTo: xmtr {Xmtr}
	super sendSelfTo: xmtr.!
*/
}
}
