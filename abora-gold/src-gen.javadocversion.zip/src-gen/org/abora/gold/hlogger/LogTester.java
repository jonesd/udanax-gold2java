/*
 * Abora-Gold
 * Part of the Abora hypertext project: http://www.abora.org
 * Copyright 2003 David G Jones
 * 
 * Translated from Udanax-Gold source code: http://www.udanax.com
 * Copyright 1979-1999 Udanax.com. All rights reserved
 */
package org.abora.gold.hlogger;

import java.io.PrintWriter;
import org.abora.gold.testing.Tester;
import org.abora.gold.xcvr.Rcvr;
import org.abora.gold.xcvr.Xmtr;


public class LogTester extends Tester {
/*
udanax-top.st:59523:
Tester subclass: #LogTester
	instanceVariableNames: ''
	classVariableNames: ''
	poolDictionaries: ''
	category: 'Xanadu-hlogger'!
*/
/*
udanax-top.st:59527:
(LogTester getOrMakeCxxClassDescription)
	attributes: ((Set new) add: #CONCRETE; add: #(COPY boot ); yourself)!
*/
/*
udanax-top.st:59560:
LogTester class
	instanceVariableNames: ''!
*/
/*
udanax-top.st:59563:
(LogTester getOrMakeCxxClassDescription)
	attributes: ((Set new) add: #CONCRETE; add: #(COPY boot ); yourself)!
*/

public void allTestsOn(PrintWriter oo) {
throw new UnsupportedOperationException();/*
udanax-top.st:59532:LogTester methodsFor: 'testing'!
{void} allTestsOn: oo {ostream reference} 
 
	FooLog << 'foo ' << self << '
'.
	VanillaLog << 'bar ' << self << '
'.
	ErrorLog << 'err ' << self << '
'.
	FooLog LOG: [:ooo |
		ooo << 'zip ' << self << '
'].
	VanillaLog LOG: [:ooo |
		ooo << 'zap ' << self << '
'].
	ErrorLog LOG: [:ooo |
		ooo << 'human ' << self << '
'].!
*/
}

public  LogTester(Rcvr receiver) {
throw new UnsupportedOperationException();/*
udanax-top.st:59553:LogTester methodsFor: 'generated:'!
create.Rcvr: receiver {Rcvr}
	super create.Rcvr: receiver.!
*/
}

public void sendSelfTo(Xmtr xmtr) {
throw new UnsupportedOperationException();/*
udanax-top.st:59556:LogTester methodsFor: 'generated:'!
{void} sendSelfTo: xmtr {Xmtr}
	super sendSelfTo: xmtr.!
*/
}

public static void linkTimeNonInherited() {
throw new UnsupportedOperationException();/*
udanax-top.st:59568:LogTester class methodsFor: 'smalltalk: init'!
linkTimeNonInherited
	Logger defineLogger: #FooLog!
*/
}
}
