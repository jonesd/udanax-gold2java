/*
 * Abora-Gold
 * Part of the Abora hypertext project: http://www.abora.org
 * Copyright 2003 David G Jones
 * 
 * Translated from Udanax-Gold source code: http://www.udanax.com
 * Copyright 1979-1999 Udanax.com. All rights reserved
 */
package org.abora.gold.hlogger;

import org.abora.gold.fm.support.Thunk;
import org.abora.gold.xcvr.Rcvr;
import org.abora.gold.xcvr.Xmtr;


public class SwitchLogger extends Thunk {
	protected char myLoggerName;
	protected char myDirective;
/*
udanax-top.st:58015:
Thunk subclass: #SwitchLogger
	instanceVariableNames: '
		myLoggerName {char star}
		myDirective {char star}'
	classVariableNames: ''
	poolDictionaries: ''
	category: 'Xanadu-hlogger'!
*/
/*
udanax-top.st:58021:
(SwitchLogger getOrMakeCxxClassDescription)
	attributes: ((Set new) add: #CONCRETE; add: #COPY; add: #NOT.A.TYPE; yourself)!
*/

public void execute() {
throw new UnsupportedOperationException();/*
udanax-top.st:58026:SwitchLogger methodsFor: 'operate'!
{void} execute
	
	(Logger get: myLoggerName) init: myDirective!
*/
}

public void restartSwitchLogger(Rcvr rcvr) {
throw new UnsupportedOperationException();/*
udanax-top.st:58032:SwitchLogger methodsFor: 'hooks:'!
{void} restartSwitchLogger: rcvr {Rcvr unused default: NULL}
	DeleteExecutor registerHolder: self with: myLoggerName.
	DeleteExecutor registerHolder: self with: myDirective.!
*/
}

public  SwitchLogger(Rcvr receiver) {
throw new UnsupportedOperationException();/*
udanax-top.st:58038:SwitchLogger methodsFor: 'generated:'!
create.Rcvr: receiver {Rcvr}
	super create.Rcvr: receiver.
	myLoggerName _ receiver receiveString.
	myDirective _ receiver receiveString.!
*/
}

public void sendSelfTo(Xmtr xmtr) {
throw new UnsupportedOperationException();/*
udanax-top.st:58043:SwitchLogger methodsFor: 'generated:'!
{void} sendSelfTo: xmtr {Xmtr}
	super sendSelfTo: xmtr.
	xmtr sendString: myLoggerName.
	xmtr sendString: myDirective.!
*/
}
}
