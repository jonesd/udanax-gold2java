/*
 * Abora-Gold
 * Part of the Abora hypertext project: http://www.abora.org
 * Copyright 2003 David G Jones
 * 
 * Translated from Udanax-Gold source code: http://www.udanax.com
 * Copyright 1979-1999 Udanax.com. All rights reserved
 */
package org.abora.gold.testing;

import java.io.PrintWriter;
import org.abora.gold.java.missing.IntegerVar;
import org.abora.gold.testing.Tester;
import org.abora.gold.xcvr.Rcvr;
import org.abora.gold.xcvr.Xmtr;


public class HelloTester extends Tester {
/*
udanax-top.st:59109:
Tester subclass: #HelloTester
	instanceVariableNames: ''
	classVariableNames: ''
	poolDictionaries: ''
	category: 'Xanadu-Testing'!
*/
/*
udanax-top.st:59113:
(HelloTester getOrMakeCxxClassDescription)
	attributes: ((Set new) add: #CONCRETE; add: #(COPY boot ); yourself)!
*/

public IntegerVar ifdefTest() {
throw new UnsupportedOperationException();/*
udanax-top.st:59118:HelloTester methodsFor: 'testing'!
{IntegerVar ifdefFOO ifndefBAR} ifdefTest
 
	^IntegerVar0!
*/
}

/**
 * self tryTest: #test1On:
 */
public void test1On(PrintWriter aStream) {
throw new UnsupportedOperationException();/*
udanax-top.st:59122:HelloTester methodsFor: 'testing'!
{void} test1On: aStream {ostream reference} 
	"self tryTest: #test1On:"
	
	aStream << 'Hello, translated world!!
'!
*/
}

/**
 * HelloTester runTest
 */
public void allTestsOn(PrintWriter aStream) {
throw new UnsupportedOperationException();/*
udanax-top.st:59130:HelloTester methodsFor: 'running tests'!
{void} allTestsOn: aStream {ostream reference} 
	"HelloTester runTest"
	
	aStream << ' 
Running Hello, world!! test.
'.
	self test1On: aStream.!
*/
}

public  HelloTester(Rcvr receiver) {
throw new UnsupportedOperationException();/*
udanax-top.st:59140:HelloTester methodsFor: 'generated:'!
create.Rcvr: receiver {Rcvr}
	super create.Rcvr: receiver.!
*/
}

public void sendSelfTo(Xmtr xmtr) {
throw new UnsupportedOperationException();/*
udanax-top.st:59143:HelloTester methodsFor: 'generated:'!
{void} sendSelfTo: xmtr {Xmtr}
	super sendSelfTo: xmtr.!
*/
}
}
