/*
 * Abora-Gold
 * Part of the Abora hypertext project: http://www.abora.org
 * Copyright 2003 David G Jones
 * 
 * Translated from Udanax-Gold source code: http://www.udanax.com
 * Copyright 1979-1999 Udanax.com. All rights reserved
 */
package org.abora.gold.testing;

import java.io.PrintWriter;
import org.abora.gold.collection.sets.ScruSet;
import org.abora.gold.collection.steppers.Stepper;
import org.abora.gold.testing.ScruSetTester;
import org.abora.gold.xcvr.Rcvr;
import org.abora.gold.xcvr.Xmtr;


public class ImmuSetTester extends ScruSetTester {
/*
udanax-top.st:60502:
ScruSetTester subclass: #ImmuSetTester
	instanceVariableNames: ''
	classVariableNames: ''
	poolDictionaries: ''
	category: 'Xanadu-Testing'!
*/
/*
udanax-top.st:60506:
(ImmuSetTester getOrMakeCxxClassDescription)
	attributes: ((Set new) add: #CONCRETE; add: #(COPY boot ); yourself)!
*/

public void allTestsOn(PrintWriter oo) {
throw new UnsupportedOperationException();/*
udanax-top.st:60511:ImmuSetTester methodsFor: 'testing'!
{void} allTestsOn: oo {ostream reference} 
	oo << 'ImmuSet testing
'.
	super allTestsOn: oo.
	oo << 'End of ImmuSet testing
'!
*/
}

public ScruSet generateSet() {
throw new UnsupportedOperationException();/*
udanax-top.st:60520:ImmuSetTester methodsFor: 'accessing'!
{ScruSet} generateSet
	^ ImmuSet make!
*/
}

public ScruSet generateSetContaining(Stepper stuff) {
throw new UnsupportedOperationException();/*
udanax-top.st:60524:ImmuSetTester methodsFor: 'accessing'!
{ScruSet} generateSetContaining: stuff {Stepper}
	| t {MuSet} |
	t _ MuSet make.
	stuff forEach: [:e {Heaper} |
		t store: e].
	^ t asImmuSet!
*/
}

public  ImmuSetTester(Rcvr receiver) {
throw new UnsupportedOperationException();/*
udanax-top.st:60534:ImmuSetTester methodsFor: 'generated:'!
create.Rcvr: receiver {Rcvr}
	super create.Rcvr: receiver.!
*/
}

public void sendSelfTo(Xmtr xmtr) {
throw new UnsupportedOperationException();/*
udanax-top.st:60537:ImmuSetTester methodsFor: 'generated:'!
{void} sendSelfTo: xmtr {Xmtr}
	super sendSelfTo: xmtr.!
*/
}
}
