/*
 * Abora-Gold
 * Part of the Abora hypertext project: http://www.abora.org
 * Copyright 2003 David G Jones
 * 
 * Translated from Udanax-Gold source code: http://www.udanax.com
 * Copyright 1979-1999 Udanax.com. All rights reserved
 */
package org.abora.gold.testing;

import java.io.PrintWriter;
import org.abora.gold.collection.sets.MuSet;
import org.abora.gold.collection.sets.ScruSet;
import org.abora.gold.collection.steppers.Stepper;
import org.abora.gold.collection.tables.ScruTable;
import org.abora.gold.testing.ScruSetTester;
import org.abora.gold.xcvr.Rcvr;
import org.abora.gold.xcvr.Xmtr;


public class MuSetTester extends ScruSetTester {
/*
udanax-top.st:60540:
ScruSetTester subclass: #MuSetTester
	instanceVariableNames: ''
	classVariableNames: ''
	poolDictionaries: ''
	category: 'Xanadu-Testing'!
*/
/*
udanax-top.st:60544:
(MuSetTester getOrMakeCxxClassDescription)
	attributes: ((Set new) add: #(COPY boot ); add: #DEFERRED; yourself)!
*/
/*
udanax-top.st:60631:
MuSetTester class
	instanceVariableNames: ''!
*/
/*
udanax-top.st:60634:
(MuSetTester getOrMakeCxxClassDescription)
	attributes: ((Set new) add: #(COPY boot ); add: #DEFERRED; yourself)!
*/

public ScruSet generateSet() {
throw new UnsupportedOperationException();/*
udanax-top.st:60549:MuSetTester methodsFor: 'deferred: initialization'!
{ScruSet} generateSet
	self subclassResponsibility!
*/
}

public ScruSet generateSetContaining(Stepper stuff) {
throw new UnsupportedOperationException();/*
udanax-top.st:60553:MuSetTester methodsFor: 'deferred: initialization'!
{ScruSet} generateSetContaining: stuff {Stepper}
	self subclassResponsibility!
*/
}

public void binaryCheck(MuSet a, MuSet b) {
throw new UnsupportedOperationException();/*
udanax-top.st:60559:MuSetTester methodsFor: 'tests'!
{void} binaryCheck: a {MuSet} with: b {MuSet}
	| anb {MuSet} bna {MuSet} amb {MuSet} aub {MuSet} bua {MuSet} |
	anb _ a copy cast: MuSet.
	anb restrictTo: b.
	bna _ b copy cast: MuSet.
	bna restrictTo: a.
	(anb contentsEqual: bna) assert: 'intersect test failed.'.
	(anb isSubsetOf: a) assert: 'intersect/subset test failed.'.
	(anb isSubsetOf: b) assert: 'intersect/subset test failed.'.
	(bna isSubsetOf: a) assert: 'intersect/subset test failed.'.
	(bna isSubsetOf: b) assert: 'intersect/subset test failed.'.
	(a intersects: b) == (anb isEmpty not) assert: 'intersects test failed.'.
	amb _ a copy cast: MuSet.
	amb wipeAll: b.
	(amb intersects: b) not assert: 'minus/intersect test failed.'.
	(amb isSubsetOf: a) assert: 'minus/subset test failed.'.
	aub _ a copy cast: MuSet.
	aub storeAll: b.
	bua _ b copy cast: MuSet.
	bua storeAll: a.
	(aub contentsEqual: bua) assert: 'unionWith test failed.'.
	(a isSubsetOf: aub) assert: 'union/subset test failed.'.
	(b isSubsetOf: aub) assert: 'union/subset test failed.'.
	
	(((a isSubsetOf: b) and: [b isSubsetOf: a]) == (a contentsEqual: b)) assert: 'subset/equals test failed.'.!
*/
}

public void binarySetTestsOn(PrintWriter oo) {
throw new UnsupportedOperationException();/*
udanax-top.st:60586:MuSetTester methodsFor: 'tests'!
{void} binarySetTestsOn: oo {ostream reference} 
	oo << 'start binary tests
'. 
	self testMuSets stepper forEach: [:setone {MuSet} | 
		self testMuSets stepper forEach: [:settwo {MuSet} | 
			self binaryCheck: setone with: settwo]].
	oo << 'end binary tests
'!
*/
}

public void unaryCheck(ScruSet a) {
throw new UnsupportedOperationException();/*
udanax-top.st:60595:MuSetTester methodsFor: 'tests'!
{void} unaryCheck: a {ScruSet} 
	| ta {MuSet} |
	
	super unaryCheck: a.
	ta _ a copy cast: MuSet.
	ta wipeAll: a.
	ta isEmpty assert: 'self minus/isEmpty failed.'.
	ta _ a copy cast: MuSet.
	ta restrictTo: a.
	(ta contentsEqual: a) assert: 'intersect/isEqual test failed.'!
*/
}

public void allTestsOn(PrintWriter oo) {
throw new UnsupportedOperationException();/*
udanax-top.st:60608:MuSetTester methodsFor: 'testing'!
{void} allTestsOn: oo {ostream reference} 
	oo << 'MuSet testing
'.
	super allTestsOn: oo.
	self binarySetTestsOn: oo.
	oo << 'End of MuSet testing
'!
*/
}

public ScruTable testMuSets() {
throw new UnsupportedOperationException();/*
udanax-top.st:60618:MuSetTester methodsFor: 'protected: accessing'!
{ScruTable of: MuSet} testMuSets
	^ self testScruSets!
*/
}

public  MuSetTester(Rcvr receiver) {
throw new UnsupportedOperationException();/*
udanax-top.st:60624:MuSetTester methodsFor: 'generated:'!
create.Rcvr: receiver {Rcvr}
	super create.Rcvr: receiver.!
*/
}

public void sendSelfTo(Xmtr xmtr) {
throw new UnsupportedOperationException();/*
udanax-top.st:60627:MuSetTester methodsFor: 'generated:'!
{void} sendSelfTo: xmtr {Xmtr}
	super sendSelfTo: xmtr.!
*/
}

public static void suppressInitTimeInherited() {
throw new UnsupportedOperationException();/*
udanax-top.st:60639:MuSetTester class methodsFor: 'smalltalk: smalltalk initialization'!
suppressInitTimeInherited!
*/
}

public static void suppressLinkTimeInherited() {
throw new UnsupportedOperationException();/*
udanax-top.st:60641:MuSetTester class methodsFor: 'smalltalk: smalltalk initialization'!
suppressLinkTimeInherited!
*/
}
}
