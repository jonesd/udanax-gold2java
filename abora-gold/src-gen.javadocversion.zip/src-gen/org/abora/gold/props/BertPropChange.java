/*
 * Abora-Gold
 * Part of the Abora hypertext project: http://www.abora.org
 * Copyright 2003 David G Jones
 * 
 * Translated from Udanax-Gold source code: http://www.udanax.com
 * Copyright 1979-1999 Udanax.com. All rights reserved
 */
package org.abora.gold.props;

import org.abora.gold.be.basic.BeRangeElement;
import org.abora.gold.be.canopy.PropFinder;
import org.abora.gold.be.canopy.prop.Prop;
import org.abora.gold.java.missing.PropJoint;
import org.abora.gold.props.FullPropChange;
import org.abora.gold.xcvr.Rcvr;
import org.abora.gold.xcvr.Xmtr;


/**
 * Use when it is fine to consider that all aspects of the BertProp may have changed
 */
public class BertPropChange extends FullPropChange {
/*
udanax-top.st:39096:
FullPropChange subclass: #BertPropChange
	instanceVariableNames: ''
	classVariableNames: ''
	poolDictionaries: ''
	category: 'Xanadu-props'!
*/
/*
udanax-top.st:39100:
BertPropChange comment:
'Use when it is fine to consider that all aspects of the BertProp may have changed'!
*/
/*
udanax-top.st:39102:
(BertPropChange getOrMakeCxxClassDescription)
	attributes: ((Set new) add: #CONCRETE; add: #COPY; add: #NOT.A.TYPE; yourself)!
*/

public PropFinder fetchFinder(Prop before, Prop after, BeRangeElement element, PropFinder oldFinder) {
throw new UnsupportedOperationException();/*
udanax-top.st:39107:BertPropChange methodsFor: 'accessing'!
{PropFinder | NULL} fetchFinder: before {Prop}
	with: after {Prop}
	with: element {BeRangeElement}
	with: oldFinder {PropFinder | NULL}
	
	| p {PropFinder} e {PropFinder} |
	p := PropChange permissionsChange
			fetchFinder: before with: after with: element with: oldFinder.
	e := PropChange endorsementsChange
			fetchFinder: before with: after with: element with: oldFinder.
	p == NULL ifTrue: [^e].
	e == NULL ifTrue: [^p].
	p cast: CumulativeRecorderFinder into: [ :pcrf |
	e cast: CumulativeRecorderFinder into: [ :ecrf |
		^CumulativeRecorderFinder
			make: (pcrf generators unionWith: ecrf generators)
			with: (pcrf current unionWith: ecrf current)
			with: (pcrf others unionWith: ecrf others)]].
	^NULL "fodder"!
*/
}

/**
 * compare the changed parts of a PropJoint and a Prop
 */
public boolean isEqualToJointOf(PropJoint a, Prop b) {
throw new UnsupportedOperationException();/*
udanax-top.st:39129:BertPropChange methodsFor: 'smalltalk: suspended'!
{BooleanVar} isEqualToJointOf: a {PropJoint} with: b {Prop}
	"compare the changed parts of a PropJoint and a Prop"
	| bpj {BertPropJoint wimpy} bp {BertProp wimpy} |
	bpj _ a cast: BertPropJoint.
	bp _ b cast: BertProp.
	^(bpj endorsementsJoint unioned isEqual: bp endorsements)
		and: [(bpj permissionsJoint unioned isEqual: bp permissions)
		and: [bpj isSensorWaiting == bp isSensorWaiting
		and: [bpj isNotPartializable == bp isNotPartializable]]]!
*/
}

public  BertPropChange(Rcvr receiver) {
throw new UnsupportedOperationException();/*
udanax-top.st:39141:BertPropChange methodsFor: 'generated:'!
create.Rcvr: receiver {Rcvr}
	super create.Rcvr: receiver.!
*/
}

public void sendSelfTo(Xmtr xmtr) {
throw new UnsupportedOperationException();/*
udanax-top.st:39144:BertPropChange methodsFor: 'generated:'!
{void} sendSelfTo: xmtr {Xmtr}
	super sendSelfTo: xmtr.!
*/
}
}
