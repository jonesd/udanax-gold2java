/*
 * Abora-Gold
 * Part of the Abora hypertext project: http://www.abora.org
 * Copyright 2003 David G Jones
 * 
 * Translated from Udanax-Gold source code: http://www.udanax.com
 * Copyright 1979-1999 Udanax.com. All rights reserved
 */
package org.abora.gold.props;

import org.abora.gold.be.basic.BeRangeElement;
import org.abora.gold.be.canopy.PropFinder;
import org.abora.gold.be.canopy.prop.Prop;
import org.abora.gold.java.missing.PropJoint;
import org.abora.gold.props.FullPropChange;
import org.abora.gold.xcvr.Rcvr;
import org.abora.gold.xcvr.Xmtr;


/**
 * Use when it is fine to consider that all aspects of the SensorProp may have changed
 */
public class SensorPropChange extends FullPropChange {
/*
udanax-top.st:39147:
FullPropChange subclass: #SensorPropChange
	instanceVariableNames: ''
	classVariableNames: ''
	poolDictionaries: ''
	category: 'Xanadu-props'!
*/
/*
udanax-top.st:39151:
SensorPropChange comment:
'Use when it is fine to consider that all aspects of the SensorProp may have changed'!
*/
/*
udanax-top.st:39153:
(SensorPropChange getOrMakeCxxClassDescription)
	attributes: ((Set new) add: #CONCRETE; add: #COPY; add: #NOT.A.TYPE; yourself)!
*/

public PropFinder fetchFinder(Prop before, Prop after, BeRangeElement element, PropFinder oldFinder) {
throw new UnsupportedOperationException();/*
udanax-top.st:39158:SensorPropChange methodsFor: 'accessing'!
{PropFinder | NULL} fetchFinder: before {Prop unused}
	with: after {Prop unused}
	with: element {BeRangeElement unused}
	with: oldFinder {PropFinder unused | NULL}
	^NULL!
*/
}

public boolean isEqualToJointOf(PropJoint a, Prop b) {
throw new UnsupportedOperationException();/*
udanax-top.st:39167:SensorPropChange methodsFor: 'smalltalk: suspended'!
{BooleanVar} isEqualToJointOf: a {PropJoint} with: b {Prop}
	
	a cast: SensorPropJoint into: [ :spj |
	b cast: SensorProp into: [ :sp |
		^(spj relevantEndorsements isEqual: sp relevantEndorsements)
			and: [(spj relevantPermissions isEqual: sp relevantPermissions)
			and: [spj isPartial == sp isPartial]]]].
	^false "fodder"!
*/
}

public  SensorPropChange(Rcvr receiver) {
throw new UnsupportedOperationException();/*
udanax-top.st:39178:SensorPropChange methodsFor: 'generated:'!
create.Rcvr: receiver {Rcvr}
	super create.Rcvr: receiver.!
*/
}

public void sendSelfTo(Xmtr xmtr) {
throw new UnsupportedOperationException();/*
udanax-top.st:39181:SensorPropChange methodsFor: 'generated:'!
{void} sendSelfTo: xmtr {Xmtr}
	super sendSelfTo: xmtr.!
*/
}
}
