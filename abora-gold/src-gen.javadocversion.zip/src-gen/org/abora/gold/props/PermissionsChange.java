/*
 * Abora-Gold
 * Part of the Abora hypertext project: http://www.abora.org
 * Copyright 2003 David G Jones
 * 
 * Translated from Udanax-Gold source code: http://www.udanax.com
 * Copyright 1979-1999 Udanax.com. All rights reserved
 */
package org.abora.gold.props;

import org.abora.gold.be.basic.BeRangeElement;
import org.abora.gold.be.canopy.PropFinder;
import org.abora.gold.be.canopy.prop.Prop;
import org.abora.gold.java.missing.PropJoint;
import org.abora.gold.props.PropChange;
import org.abora.gold.xcvr.Rcvr;
import org.abora.gold.xcvr.Xmtr;


/**
 * Used when the Permissions part of a BertProp changed
 */
public class PermissionsChange extends PropChange {
/*
udanax-top.st:39184:
PropChange subclass: #PermissionsChange
	instanceVariableNames: ''
	classVariableNames: ''
	poolDictionaries: ''
	category: 'Xanadu-props'!
*/
/*
udanax-top.st:39188:
PermissionsChange comment:
'Used when the Permissions part of a BertProp changed'!
*/
/*
udanax-top.st:39190:
(PermissionsChange getOrMakeCxxClassDescription)
	attributes: ((Set new) add: #CONCRETE; add: #COPY; add: #NOT.A.TYPE; yourself)!
*/

/**
 * compare the changed parts of two Props
 */
public boolean areEqualProps(Prop a, Prop b) {
throw new UnsupportedOperationException();/*
udanax-top.st:39195:PermissionsChange methodsFor: 'accessing'!
{BooleanVar} areEqualProps: a {Prop} with: b {Prop}
	"compare the changed parts of two Props"
	^(a cast: BertProp) permissions isEqual: (b cast: BertProp) permissions!
*/
}

public Prop changed(Prop old, Prop a) {
throw new UnsupportedOperationException();/*
udanax-top.st:39199:PermissionsChange methodsFor: 'accessing'!
{Prop} changed: old {Prop} with: a {Prop}
	| bp {BertProp wimpy} |
	bp _ old cast: BertProp.
	^BertProp make: (a cast: BertProp) permissions
		with: bp endorsements
		with: bp isSensorWaiting
		with: bp isNotPartializable!
*/
}

public PropFinder fetchFinder(Prop before, Prop after, BeRangeElement element, PropFinder oldFinder) {
throw new UnsupportedOperationException();/*
udanax-top.st:39208:PermissionsChange methodsFor: 'accessing'!
{PropFinder | NULL} fetchFinder: before {Prop}
	with: after {Prop}
	with: element {BeRangeElement}
	with: oldFinder {PropFinder | NULL}
	
	before cast: BertProp into: [ :b |
	after cast: BertProp into: [ :a |
		| result {PropFinder} delta {RegionDelta}
		  any {PropFinder} anys {ImmuSet}
		  simple {PropFinder} simples {ImmuSet} |
		delta := RegionDelta make: b permissions with: a permissions.
		delta isSame ifTrue:
			[^NULL].
		any := AnyRecorderPFinder make: delta.
		any isEmpty
			ifTrue: [anys := ImmuSet make]
			ifFalse: [anys := ImmuSet newWith: any].
		simple :=ResultRecorderPFinder make: element
			with: delta
			with: a endorsements.
		simple isEmpty
			ifTrue: [simples := ImmuSet make]
			ifFalse: [simples := ImmuSet newWith: simple].
		oldFinder == NULL ifTrue:
			[result := CumulativeRecorderFinder
				make: anys
				with: simples
				with: ImmuSet make]
		ifFalse:
			[oldFinder cast: CumulativeRecorderFinder into: [ :crf |
				result := CumulativeRecorderFinder
					make: anys
					with: simples
					with: (crf current unionWith: crf others)]].
		result isEmpty
			ifTrue: [^NULL]
			ifFalse: [^result]]].
	^NULL "fodder"!
*/
}

/**
 * whether this is a complete change of props
 */
public boolean isFull() {
throw new UnsupportedOperationException();/*
udanax-top.st:39247:PermissionsChange methodsFor: 'accessing'!
{BooleanVar} isFull
	"whether this is a complete change of props"
	^false!
*/
}

public Prop with(Prop old, Prop a) {
throw new UnsupportedOperationException();/*
udanax-top.st:39251:PermissionsChange methodsFor: 'accessing'!
{Prop} with: old {Prop} with: a {Prop}
	| bp {BertProp wimpy} |
	bp _ old cast: BertProp.
	^BertProp make: ((a cast: BertProp) permissions unionWith: bp permissions)
		with: bp endorsements
		with: bp isSensorWaiting
		with: bp isNotPartializable!
*/
}

/**
 * compare the changed parts of two PropJoints
 */
public boolean areEqualPropJoints(PropJoint a, PropJoint b) {
throw new UnsupportedOperationException();/*
udanax-top.st:39262:PermissionsChange methodsFor: 'smalltalk: suspended'!
{BooleanVar} areEqualPropJoints: a {PropJoint} with: b {PropJoint}
	"compare the changed parts of two PropJoints"
	^(a cast: BertPropJoint) permissionsJoint isEqual: (b cast: BertPropJoint) permissionsJoint!
*/
}

public PropJoint changedJoint(PropJoint old, PropJoint a) {
throw new UnsupportedOperationException();/*
udanax-top.st:39266:PermissionsChange methodsFor: 'smalltalk: suspended'!
{PropJoint} changedJoint: old {PropJoint} with: a {PropJoint}
	
	| bp {BertPropJoint wimpy} |
	bp _ old cast: BertPropJoint.
	^BertPropJoint make: (a cast: BertPropJoint) permissionsJoint
		with: bp endorsementsJoint
		with: bp isSensorWaiting
		with: bp isNotPartializable!
*/
}

/**
 * compare the changed parts of a PropJoint and a Prop
 */
public boolean isEqualToJointOf(PropJoint a, Prop b) {
throw new UnsupportedOperationException();/*
udanax-top.st:39275:PermissionsChange methodsFor: 'smalltalk: suspended'!
{BooleanVar} isEqualToJointOf: a {PropJoint} with: b {Prop}
	"compare the changed parts of a PropJoint and a Prop"
	^(a cast: BertPropJoint) permissionsJoint unioned isEqual: (b cast: BertProp) permissions!
*/
}

/**
 * combine two PropJoints with minimum effort, given the previous result
 */
public PropJoint join(PropJoint old, PropJoint a, PropJoint b) {
throw new UnsupportedOperationException();/*
udanax-top.st:39279:PermissionsChange methodsFor: 'smalltalk: suspended'!
{PropJoint} join: old {PropJoint} with: a {PropJoint} with: b {PropJoint}
	"combine two PropJoints with minimum effort, given the previous result"
	| bp {BertPropJoint wimpy} |
	bp _ old cast: BertPropJoint.
	^BertPropJoint make: ((a cast: BertPropJoint) permissionsJoint join: (b cast: BertPropJoint) permissionsJoint)
		with: bp endorsementsJoint
		with: bp isSensorWaiting
		with: bp isNotPartializable!
*/
}

/**
 * combine two PropJoints and a prop with minimum effort, given the previous result
 */
public PropJoint joinProp(PropJoint old, PropJoint a, PropJoint b, Prop prop) {
throw new UnsupportedOperationException();/*
udanax-top.st:39288:PermissionsChange methodsFor: 'smalltalk: suspended'!
{PropJoint} joinProp: old {PropJoint} with: a {PropJoint} with: b {PropJoint} with: prop {Prop}
	"combine two PropJoints and a prop with minimum effort, given the previous result"
	| bpj {BertPropJoint wimpy} |
	bpj _ old cast: BertPropJoint.
	^BertPropJoint make: (((a cast: BertPropJoint) permissionsJoint
			join: (b cast: BertPropJoint) permissionsJoint)
			with: (prop cast: BertProp) permissions)
		with: bpj endorsementsJoint
		with: bpj isSensorWaiting
		with: bpj isNotPartializable!
*/
}

public  PermissionsChange(Rcvr receiver) {
throw new UnsupportedOperationException();/*
udanax-top.st:39301:PermissionsChange methodsFor: 'generated:'!
create.Rcvr: receiver {Rcvr}
	super create.Rcvr: receiver.!
*/
}

public void sendSelfTo(Xmtr xmtr) {
throw new UnsupportedOperationException();/*
udanax-top.st:39304:PermissionsChange methodsFor: 'generated:'!
{void} sendSelfTo: xmtr {Xmtr}
	super sendSelfTo: xmtr.!
*/
}
}
