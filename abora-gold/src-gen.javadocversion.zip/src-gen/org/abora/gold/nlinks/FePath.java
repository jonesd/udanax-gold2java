/*
 * Abora-Gold
 * Part of the Abora hypertext project: http://www.abora.org
 * Copyright 2003 David G Jones
 * 
 * Translated from Udanax-Gold source code: http://www.udanax.com
 * Copyright 1979-1999 Udanax.com. All rights reserved
 */
package org.abora.gold.nlinks;

import org.abora.gold.collection.basic.PtrArray;
import org.abora.gold.java.missing.IntegerVar;
import org.abora.gold.nkernel.FeEdition;
import org.abora.gold.nkernel.FeLabel;
import org.abora.gold.nkernel.FeRangeElement;
import org.abora.gold.nlinks.FePath;
import org.abora.gold.wrapper.FeWrapper;
import org.abora.gold.wrapper.FeWrapperSpec;
import org.abora.gold.xpp.basic.Heaper;


/**
 * A sequence of Labels, used for context information in a LinkEnd.
 */
public class FePath extends FeWrapper {
	protected static FeWrapperSpec ThePathSpec;
/*
udanax-top.st:25046:
FeWrapper subclass: #FePath
	instanceVariableNames: ''
	classVariableNames: 'ThePathSpec {FeWrapperSpec} '
	poolDictionaries: ''
	category: 'Xanadu-nlinks'!
*/
/*
udanax-top.st:25050:
FePath comment:
'A sequence of Labels, used for context information in a LinkEnd.'!
*/
/*
udanax-top.st:25052:
(FePath getOrMakeCxxClassDescription)
	attributes: ((Set new) add: #ON.CLIENT; add: #CONCRETE; yourself)!
*/
/*
udanax-top.st:25123:
FePath class
	instanceVariableNames: ''!
*/
/*
udanax-top.st:25126:
(FePath getOrMakeCxxClassDescription)
	attributes: ((Set new) add: #ON.CLIENT; add: #CONCRETE; yourself)!
*/

/**
 * The first label in the sequence
 */
public FeLabel first() {
throw new UnsupportedOperationException();/*
udanax-top.st:25057:FePath methodsFor: 'smalltalk: passe'!
{FeLabel} first
	"The first label in the sequence"
	self passe.
	^(self edition get: IntegerZero) cast: FeLabel!
*/
}

/**
 * Replace what is in the container at my path after index with contained.
 */
public FeEdition replace(FeEdition container, FeRangeElement contained, IntegerVar index, IntegerVar count) {
throw new UnsupportedOperationException();/*
udanax-top.st:25062:FePath methodsFor: 'smalltalk: passe'!
{FeEdition} replace: container {FeEdition}
	with: contained {FeRangeElement}
	with: index {IntegerVar}
	with: count {IntegerVar}
	"Replace what is in the container at my path after index with contained."
	
	| labels {XnRegion} |
	index = count ifTrue: [^contained cast: FeEdition].
	labels := container positionsLabelled: ((self edition get: index integer) cast: FeLabel).
	^container with: labels theOne
		with: (self replace: ((container get: labels theOne) cast: FeEdition)
			with: contained
			with: index + 1
			with: count)!
*/
}

/**
 * Replace whatever is at this path in the container with the newValue. Fail if at any point
 * there is not precisely one choice.
 */
public FeEdition replaceIn(FeEdition container, FeRangeElement value) {
throw new UnsupportedOperationException();/*
udanax-top.st:25077:FePath methodsFor: 'smalltalk: passe'!
{FeEdition} replaceIn: container {FeEdition} with: value {FeRangeElement}
	"Replace whatever is at this path in the container with the newValue. Fail if at any point there is not precisely one choice."
	
	self passe.
	^self replace: container with: value with: IntegerVarZero with: self edition count!
*/
}

/**
 * The remaining path after the first label in the sequence
 */
public FePath rest() {
throw new UnsupportedOperationException();/*
udanax-top.st:25083:FePath methodsFor: 'smalltalk: passe'!
{FePath} rest
	"The remaining path after the first label in the sequence"
	self passe.
	^(FePath construct: (self edition
		transformedBy: ((IntegerMapping make: -1)
			restrict: (IntegerRegion after: 1)))) cast: FePath!
*/
}

/**
 * Append it to the beginning of the path
 */
public FePath withFirst(FeLabel label) {
throw new UnsupportedOperationException();/*
udanax-top.st:25090:FePath methodsFor: 'smalltalk: passe'!
{FePath} withFirst: label {FeLabel}
	"Append it to the beginning of the path"
	self passe.
	^(FePath construct: ((self edition
			transformedBy: ((IntegerMapping make: 1)
				restrict: (IntegerRegion after: 1)))
		with: IntegerZero with: label)) cast: FePath!
*/
}

/**
 * Append it to the end of the path
 */
public FePath withLast(FeLabel label) {
throw new UnsupportedOperationException();/*
udanax-top.st:25098:FePath methodsFor: 'smalltalk: passe'!
{FePath} withLast: label {FeLabel}
	"Append it to the end of the path"
	self passe.
	^(FePath construct: (self edition
		with: self edition count with: label)) cast: FePath!
*/
}

/**
 * Follow a path down into an Edition and return what is at the end of the path. Fail if at
 * any point there is not precisely one choice.
 */
public FeRangeElement follow(FeEdition edition) {
throw new UnsupportedOperationException();/*
udanax-top.st:25106:FePath methodsFor: 'operations'!
{FeRangeElement CLIENT} follow: edition {FeEdition}
	"Follow a path down into an Edition and return what is at the end of the path. Fail if at any point there is not precisely one choice."
	
	| result {FeRangeElement} label {FeLabel} |
	result := edition.
	IntegerVarZero almostTo: self edition count do: [ :index {IntegerVar} |
		label := (self edition get: index integer) cast: FeLabel.
		result := (result cast: FeEdition) get: ((result cast: FeEdition) positionsLabelled: label) theOne].
	^result!
*/
}

public  FePath(FeEdition edition, FeWrapperSpec spec) {
	super(edition, spec);
throw new UnsupportedOperationException();/*
udanax-top.st:25118:FePath methodsFor: 'private: create'!
create: edition {FeEdition} with: spec {FeWrapperSpec}
	super create: edition with: spec!
*/
}

public static Heaper make(PtrArray labels) {
throw new UnsupportedOperationException();/*
udanax-top.st:25131:FePath class methodsFor: 'pseudo constructors'!
{FePath CLIENT} make: labels {PtrArray of: FeLabel}
	^(self spec wrap: (FeEdition fromArray: labels)) cast: FePath!
*/
}

public static FeWrapperSpec spec() {
throw new UnsupportedOperationException();/*
udanax-top.st:25135:FePath class methodsFor: 'pseudo constructors'!
{FeWrapperSpec} spec
	^ThePathSpec!
*/
}

public static boolean check(FeEdition edition) {
throw new UnsupportedOperationException();/*
udanax-top.st:25141:FePath class methodsFor: 'private: wrapping'!
{BooleanVar} check: edition {FeEdition}
	
	Ravi thingToDo. "check that there are only labels here"
	^(edition domain isKindOf: IntegerRegion)
		and: [(edition domain cast: IntegerRegion) isCompacted
		"and: [((edition zoneOf: FeLabel spec) domain
			isEqual: edition domain)]"]!
*/
}

public static FePath construct(FeEdition edition) {
throw new UnsupportedOperationException();/*
udanax-top.st:25149:FePath class methodsFor: 'private: wrapping'!
{FePath} construct: edition {FeEdition}
	
	self spec endorse: edition.
	^(self makeWrapper: edition) cast: FePath!
*/
}

public static FeWrapper makeWrapper(FeEdition edition) {
throw new UnsupportedOperationException();/*
udanax-top.st:25154:FePath class methodsFor: 'private: wrapping'!
{FeWrapper} makeWrapper: edition {FeEdition}
	
	^self create: edition with: self spec!
*/
}

public static void setSpec(FeWrapperSpec wrap) {
throw new UnsupportedOperationException();/*
udanax-top.st:25158:FePath class methodsFor: 'private: wrapping'!
{void} setSpec: wrap {FeWrapperSpec}
	ThePathSpec := wrap.!
*/
}

public static void initTimeNonInherited() {
throw new UnsupportedOperationException();/*
udanax-top.st:25164:FePath class methodsFor: 'smalltalk: init'!
initTimeNonInherited
	FeWrapperSpec DIRECTWRAPPER: 'Path'
		with: 'Wrapper'
		with: #FePath.!
*/
}

public static void linkTimeNonInherited() {
throw new UnsupportedOperationException();/*
udanax-top.st:25170:FePath class methodsFor: 'smalltalk: init'!
linkTimeNonInherited
	ThePathSpec := NULL.!
*/
}

/**
 * {FeRangeElement CLIENT} follow: edition {FeEdition}
 */
public static void info() {
throw new UnsupportedOperationException();/*
udanax-top.st:25176:FePath class methodsFor: 'smalltalk: system'!
info.stProtocol
"{FeRangeElement CLIENT} follow: edition {FeEdition}
"!
*/
}
}
