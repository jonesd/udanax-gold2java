/*
 * Abora-Gold
 * Part of the Abora hypertext project: http://www.abora.org
 * Copyright 2003 David G Jones
 * 
 * Translated from Udanax-Gold source code: http://www.udanax.com
 * Copyright 1979-1999 Udanax.com. All rights reserved
 */
package org.abora.gold.nlinks;

import org.abora.gold.nkernel.FeEdition;
import org.abora.gold.nkernel.FeWork;
import org.abora.gold.nlinks.FeHyperRef;
import org.abora.gold.nlinks.FePath;
import org.abora.gold.nlinks.FeSingleRef;
import org.abora.gold.wrapper.FeWrapper;
import org.abora.gold.wrapper.FeWrapperSpec;
import org.abora.gold.xpp.basic.Heaper;


/**
 * Represents a single attachment to some material in the context of a Work, and maybe a Path
 * beneath it.
 */
public class FeSingleRef extends FeHyperRef {
	protected static FeWrapperSpec TheSingleRefSpec;
/*
udanax-top.st:24383:
FeHyperRef subclass: #FeSingleRef
	instanceVariableNames: ''
	classVariableNames: 'TheSingleRefSpec {FeWrapperSpec} '
	poolDictionaries: ''
	category: 'Xanadu-nlinks'!
*/
/*
udanax-top.st:24387:
FeSingleRef comment:
'Represents a single attachment to some material in the context of a Work, and maybe a Path beneath it.'!
*/
/*
udanax-top.st:24389:
(FeSingleRef getOrMakeCxxClassDescription)
	attributes: ((Set new) add: #ON.CLIENT; add: #CONCRETE; yourself)!
*/
/*
udanax-top.st:24418:
FeSingleRef class
	instanceVariableNames: ''!
*/
/*
udanax-top.st:24421:
(FeSingleRef getOrMakeCxxClassDescription)
	attributes: ((Set new) add: #ON.CLIENT; add: #CONCRETE; yourself)!
*/

/**
 * The material to which this HyperRef is attached.
 */
public FeEdition excerpt() {
throw new UnsupportedOperationException();/*
udanax-top.st:24394:FeSingleRef methodsFor: 'accessing'!
{FeEdition CLIENT} excerpt
	"The material to which this HyperRef is attached."
	^(self edition get: (Sequence string: 'HyperRef:Excerpt')) cast: FeEdition!
*/
}

/**
 * Make this Ref point at different material.
 */
public FeSingleRef withExcerpt(FeEdition excerpt) {
throw new UnsupportedOperationException();/*
udanax-top.st:24399:FeSingleRef methodsFor: 'accessing'!
{FeSingleRef CLIENT} withExcerpt: excerpt {FeEdition}
	"Make this Ref point at different material."
	^FeSingleRef construct: (self edition with: (Sequence string: 'HyperRef:Excerpt') with: excerpt)!
*/
}

/**
 * Make a new HyperRef of the same type with different contents
 */
public FeHyperRef makeNew(FeEdition edition) {
throw new UnsupportedOperationException();/*
udanax-top.st:24406:FeSingleRef methodsFor: 'protected:'!
{FeHyperRef} makeNew: edition {FeEdition}
	"Make a new HyperRef of the same type with different contents"
	
	^FeSingleRef construct: edition!
*/
}

public  FeSingleRef(FeEdition edition, FeWrapperSpec spec) {
	super(edition, spec);
throw new UnsupportedOperationException();/*
udanax-top.st:24413:FeSingleRef methodsFor: 'private: create'!
create: edition {FeEdition} with: spec {FeWrapperSpec}
	super create: edition with: spec!
*/
}

/**
 * Check that it has the right fields in the right places. Ignore other contents.
 */
public static boolean check(FeEdition edition) {
throw new UnsupportedOperationException();/*
udanax-top.st:24426:FeSingleRef class methodsFor: 'private: wrapping'!
{BooleanVar} check: edition {FeEdition}
	"Check that it has the right fields in the right places. Ignore other contents."
	
	^(FeHyperRef check: edition)
		and: [FeWrapper checkSubEdition: edition
			with: (Sequence string: 'HyperRef:AttachedMaterial')
			with: NULL
			with: false]!
*/
}

/**
 * Create a new wrapper and endorse it
 */
public static FeSingleRef construct(FeEdition edition) {
throw new UnsupportedOperationException();/*
udanax-top.st:24435:FeSingleRef class methodsFor: 'private: wrapping'!
{FeSingleRef} construct: edition {FeEdition}
	"Create a new wrapper and endorse it"
	
	self spec endorse: edition.
	^(self makeWrapper: edition) cast: FeSingleRef!
*/
}

/**
 * Just create a new wrapper
 */
public static FeWrapper makeWrapper(FeEdition edition) {
throw new UnsupportedOperationException();/*
udanax-top.st:24441:FeSingleRef class methodsFor: 'private: wrapping'!
{FeWrapper} makeWrapper: edition {FeEdition}
	"Just create a new wrapper"
	
	^self create: edition with: self spec!
*/
}

public static void setSpec(FeWrapperSpec wrap) {
throw new UnsupportedOperationException();/*
udanax-top.st:24446:FeSingleRef class methodsFor: 'private: wrapping'!
{void} setSpec: wrap {FeWrapperSpec}
	TheSingleRefSpec := wrap.!
*/
}

/**
 * Make a new SingleRef. At least one of the parameters must be non-NULL. The
 * originalContext, if supplied,  must be a frozen Work.
 */
public static Heaper make(FeEdition material, FeWork workContext, FeWork originalContext, FePath pathContext) {
throw new UnsupportedOperationException();/*
udanax-top.st:24452:FeSingleRef class methodsFor: 'creation'!
{FeSingleRef CLIENT} make: material {FeEdition | NULL}
	with: workContext {FeWork default: NULL}
	with: originalContext {FeWork default: NULL}
	with: pathContext {FePath default: NULL}
	"Make a new SingleRef. At least one of the parameters must be non-NULL. The originalContext, if supplied,  must be a frozen Work."
	
	| result {FeEdition} |
	(material == NULL and: [workContext == NULL
			and: [originalContext == NULL and: [pathContext == NULL]]])
		ifTrue: [Heaper BLAST: #MustSupplySomeHyperRefInformation].
	(originalContext ~~ NULL
			and: [(originalContext fetchBe cast: BeWork) fetchEditClub ~~ NULL])
		ifTrue: [Heaper BLAST: #OriginalContextMustBeFrozen].
	result := FeEdition empty: SequenceSpace make.
	workContext ~~ NULL ifTrue:
		[result := result with: (Sequence string: 'HyperRef:WorkContext')
			with: workContext].
	originalContext ~~ NULL ifTrue:
		[result := result with: (Sequence string: 'HyperRef:OriginalContext')
			with: originalContext].
	material ~~ NULL ifTrue:
		[result := result with: (Sequence string: 'HyperRef:Excerpt')
			with: material].
	pathContext ~~ NULL ifTrue:
		[result := result with: (Sequence string: 'HyperRef:PathContext')
			with: pathContext edition].
	^self construct: result!
*/
}

public static FeWrapperSpec spec() {
throw new UnsupportedOperationException();/*
udanax-top.st:24481:FeSingleRef class methodsFor: 'creation'!
{FeWrapperSpec} spec
	^TheSingleRefSpec!
*/
}

public static void initTimeNonInherited() {
throw new UnsupportedOperationException();/*
udanax-top.st:24487:FeSingleRef class methodsFor: 'smalltalk: init'!
initTimeNonInherited
	FeWrapperSpec DIRECTWRAPPER: 'SingleRef'
		with: 'HyperRef'
		with: #FeSingleRef.!
*/
}

public static void linkTimeNonInherited() {
throw new UnsupportedOperationException();/*
udanax-top.st:24493:FeSingleRef class methodsFor: 'smalltalk: init'!
linkTimeNonInherited
	TheSingleRefSpec := NULL.!
*/
}

/**
 * {FeEdition CLIENT} excerpt
 */
public static void info() {
throw new UnsupportedOperationException();/*
udanax-top.st:24499:FeSingleRef class methodsFor: 'smalltalk: system'!
info.stProtocol
"{FeEdition CLIENT} excerpt
"!
*/
}

/**
 * Make a new SingleRef. At least one of the parameters must be non-NULL. The
 * originalContext, if supplied,  must be a frozen Work.
 */
public static Heaper make(FeEdition material) {
throw new UnsupportedOperationException();/*
udanax-top.st:24505:FeSingleRef class methodsFor: 'smalltalk: defaults'!
{FeSingleRef CLIENT} make: material {FeEdition | NULL}
	"Make a new SingleRef. At least one of the parameters must be non-NULL. The originalContext, if supplied,  must be a frozen Work."
	^self make: material with: NULL with: NULL with: NULL!
*/
}

/**
 * Make a new SingleRef. At least one of the parameters must be non-NULL. The
 * originalContext, if supplied,  must be a frozen Work.
 */
public static Heaper make(FeEdition material, FeWork workContext) {
throw new UnsupportedOperationException();/*
udanax-top.st:24510:FeSingleRef class methodsFor: 'smalltalk: defaults'!
{FeSingleRef CLIENT} make: material {FeEdition | NULL}
	with: workContext {FeWork default: NULL}
	"Make a new SingleRef. At least one of the parameters must be non-NULL. The originalContext, if supplied,  must be a frozen Work."
	^self make: material with: workContext with: NULL with: NULL!
*/
}

/**
 * Make a new SingleRef. At least one of the parameters must be non-NULL. The
 * originalContext, if supplied,  must be a frozen Work.
 */
public static Heaper make(FeEdition material, FeWork workContext, FeWork originalContext) {
throw new UnsupportedOperationException();/*
udanax-top.st:24516:FeSingleRef class methodsFor: 'smalltalk: defaults'!
{FeSingleRef CLIENT} make: material {FeEdition | NULL}
	with: workContext {FeWork default: NULL}
	with: originalContext {FeWork default: NULL}
	"Make a new SingleRef. At least one of the parameters must be non-NULL. The originalContext, if supplied,  must be a frozen Work."
	^self make: material with: workContext with: originalContext with: NULL!
*/
}
}
