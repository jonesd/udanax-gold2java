/*
 * Abora-Gold
 * Part of the Abora hypertext project: http://www.abora.org
 * Copyright 2003 David G Jones
 * 
 * Translated from Udanax-Gold source code: http://www.udanax.com
 * Copyright 1979-1999 Udanax.com. All rights reserved
 */
package org.abora.gold.cache;

import org.abora.gold.collection.basic.PtrArray;
import org.abora.gold.xpp.basic.Heaper;


/**
 * InstanceCache is intended to store a small number of frequently used objects with the
 * intent of reducing memory allocation traffic.
 */
public class InstanceCache extends Heaper {
	protected PtrArray myArray;
	protected int myTop;
/*
udanax-top.st:27691:
Heaper subclass: #InstanceCache
	instanceVariableNames: '
		myArray {PtrArray}
		myTop {Int32}'
	classVariableNames: ''
	poolDictionaries: ''
	category: 'Xanadu-cache'!
*/
/*
udanax-top.st:27697:
InstanceCache comment:
'InstanceCache is intended to store a small number of frequently used objects with the intent of reducing memory allocation traffic.'!
*/
/*
udanax-top.st:27699:
(InstanceCache getOrMakeCxxClassDescription)
	attributes: ((Set new) add: #CONCRETE; add: #EQ; yourself)!
*/
/*
udanax-top.st:27740:
InstanceCache class
	instanceVariableNames: ''!
*/
/*
udanax-top.st:27743:
(InstanceCache getOrMakeCxxClassDescription)
	attributes: ((Set new) add: #CONCRETE; add: #EQ; yourself)!
*/

public Heaper fetch() {
throw new UnsupportedOperationException();/*
udanax-top.st:27704:InstanceCache methodsFor: 'accessing'!
{Heaper} fetch
	myTop >= Int32Zero
		ifTrue: [
			| result {Heaper} |
			result := myArray fetch: myTop.
			myArray at: myTop store: NULL.
			myTop := myTop - 1.
			^ result]
		ifFalse: [
			^ NULL]!
*/
}

public boolean store(Heaper object) {
throw new UnsupportedOperationException();/*
udanax-top.st:27715:InstanceCache methodsFor: 'accessing'!
{BooleanVar} store: object {Heaper}
	myTop < (myArray count - 1)
		ifTrue: [
			myTop := myTop + 1.
			object destruct.
			(SuspendedHeaper new.Become: object) create.
			myArray at: myTop store: object.
			^ true]
		ifFalse: [
			^ false]!
*/
}

public  InstanceCache(int size) {
throw new UnsupportedOperationException();/*
udanax-top.st:27728:InstanceCache methodsFor: 'protected: create'!
create: size {Int32}
	super create.
	myArray := PtrArray nulls: size.
	myTop := -1!
*/
}

public int actualHashForEqual() {
throw new UnsupportedOperationException();/*
udanax-top.st:27735:InstanceCache methodsFor: 'generated:'!
actualHashForEqual ^self asOop!
*/
}

public boolean isEqual(Object other) {
throw new UnsupportedOperationException();/*
udanax-top.st:27737:InstanceCache methodsFor: 'generated:'!
isEqual: other ^self == other!
*/
}

public static Heaper make(int size) {
throw new UnsupportedOperationException();/*
udanax-top.st:27748:InstanceCache class methodsFor: 'create'!
make: size {Int32}
	^ self create: size!
*/
}
}
