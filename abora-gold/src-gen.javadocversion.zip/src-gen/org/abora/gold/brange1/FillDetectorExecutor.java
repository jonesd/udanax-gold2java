/*
 * Abora-Gold
 * Part of the Abora hypertext project: http://www.abora.org
 * Copyright 2003 David G Jones
 * 
 * Translated from Udanax-Gold source code: http://www.udanax.com
 * Copyright 1979-1999 Udanax.com. All rights reserved
 */
package org.abora.gold.brange1;

import org.abora.gold.be.basic.BePlaceHolder;
import org.abora.gold.wparray.XnExecutor;
import org.abora.gold.xpp.basic.Heaper;


/**
 * This class notifies its place holder when its last fill detector has gone away.
 */
public class FillDetectorExecutor extends XnExecutor {
	protected BePlaceHolder myPlaceHolder;
/*
udanax-top.st:26447:
XnExecutor subclass: #FillDetectorExecutor
	instanceVariableNames: 'myPlaceHolder {BePlaceHolder}'
	classVariableNames: ''
	poolDictionaries: ''
	category: 'Xanadu-brange1'!
*/
/*
udanax-top.st:26451:
FillDetectorExecutor comment:
'This class notifies its place holder when its last fill detector has gone away.'!
*/
/*
udanax-top.st:26453:
(FillDetectorExecutor getOrMakeCxxClassDescription)
	attributes: ((Set new) add: #CONCRETE; add: #NOT.A.TYPE; yourself)!
*/
/*
udanax-top.st:26469:
FillDetectorExecutor class
	instanceVariableNames: ''!
*/
/*
udanax-top.st:26472:
(FillDetectorExecutor getOrMakeCxxClassDescription)
	attributes: ((Set new) add: #CONCRETE; add: #NOT.A.TYPE; yourself)!
*/

public  FillDetectorExecutor(BePlaceHolder placeHolder) {
throw new UnsupportedOperationException();/*
udanax-top.st:26458:FillDetectorExecutor methodsFor: 'protected: create'!
create: placeHolder {BePlaceHolder}
	super create.
	myPlaceHolder := placeHolder.!
*/
}

public void execute(int arg) {
throw new UnsupportedOperationException();/*
udanax-top.st:26464:FillDetectorExecutor methodsFor: 'execute'!
{void} execute: arg {Int32}
	arg == Int32Zero ifTrue: [
		myPlaceHolder removeLastDetector]!
*/
}

public static Heaper make(BePlaceHolder placeHolder) {
throw new UnsupportedOperationException();/*
udanax-top.st:26477:FillDetectorExecutor class methodsFor: 'create'!
{XnExecutor} make: placeHolder {BePlaceHolder}
	^ self create: placeHolder!
*/
}
}
