/*
 * Abora-Gold
 * Part of the Abora hypertext project: http://www.abora.org
 * Copyright 2003 David G Jones
 * 
 * Translated from Udanax-Gold source code: http://www.udanax.com
 * Copyright 1979-1999 Udanax.com. All rights reserved
 */
package org.abora.gold.tokens;

import org.abora.gold.collection.basic.Int32Array;
import org.abora.gold.xpp.basic.Heaper;


/**
 * Manage a set of integerVars as tokens.  The Available array is tokens that have been
 * returned to the pool.  They get used in preference to allocating new ones so that we keep
 * the numbers dense.
 */
public class TokenSource extends Heaper {
	protected Int32Array myAvailable;
	protected int myAvailableCount;
	protected int myCeiling;
/*
udanax-top.st:62807:
Heaper subclass: #TokenSource
	instanceVariableNames: '
		myAvailable {Int32Array}
		myAvailableCount {Int32}
		myCeiling {Int32}'
	classVariableNames: ''
	poolDictionaries: ''
	category: 'Xanadu-tokens'!
*/
/*
udanax-top.st:62814:
TokenSource comment:
'Manage a set of integerVars as tokens.  The Available array is tokens that have been returned to the pool.  They get used in preference to allocating new ones so that we keep the numbers dense.'!
*/
/*
udanax-top.st:62816:
(TokenSource getOrMakeCxxClassDescription)
	attributes: ((Set new) add: #CONCRETE; add: #EQ; yourself)!
*/
/*
udanax-top.st:62861:
TokenSource class
	instanceVariableNames: ''!
*/
/*
udanax-top.st:62864:
(TokenSource getOrMakeCxxClassDescription)
	attributes: ((Set new) add: #CONCRETE; add: #EQ; yourself)!
*/

public void returnToken(int token) {
throw new UnsupportedOperationException();/*
udanax-top.st:62821:TokenSource methodsFor: 'accessing'!
{void} returnToken: token {Int32}
	token == myCeiling ifTrue: [
		myCeiling _ myCeiling - 1.
		^VOID
	].
	myAvailableCount >= myAvailable count ifTrue: [
	 	myAvailable _ (myAvailable copyGrow: myAvailableCount+1) cast: Int32Array.
	].
	myAvailable at: myAvailableCount storeInt: token.
	myAvailableCount _ myAvailableCount + 1.!
*/
}

public int takeToken() {
throw new UnsupportedOperationException();/*
udanax-top.st:62832:TokenSource methodsFor: 'accessing'!
{Int32} takeToken
|tmp {Int32}|
	myAvailableCount > Int32Zero ifTrue: [
		myAvailableCount _ myAvailableCount - 1.
		tmp _myAvailable intAt: myAvailableCount.
		
	] ifFalse: [
		myCeiling _ myCeiling + 1.
		tmp _myCeiling
	].
	[tmp == NULL ifTrue:[self halt]] smalltalkOnly.
	
	^tmp!
*/
}

public  TokenSource() {
throw new UnsupportedOperationException();/*
udanax-top.st:62848:TokenSource methodsFor: 'creation'!
create
	super create.
	myAvailable _ Int32Array make: 10.
	myAvailableCount _ Int32Zero.
	myCeiling _ Int32Zero!
*/
}

public int actualHashForEqual() {
throw new UnsupportedOperationException();/*
udanax-top.st:62856:TokenSource methodsFor: 'generated:'!
actualHashForEqual ^self asOop!
*/
}

public boolean isEqual(Object other) {
throw new UnsupportedOperationException();/*
udanax-top.st:62858:TokenSource methodsFor: 'generated:'!
isEqual: other ^self == other!
*/
}

public static Heaper make() {
throw new UnsupportedOperationException();/*
udanax-top.st:62869:TokenSource class methodsFor: 'creation'!
make
	^TokenSource create!
*/
}
}
