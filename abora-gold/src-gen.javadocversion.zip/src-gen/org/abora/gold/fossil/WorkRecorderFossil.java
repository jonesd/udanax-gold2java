/*
 * Abora-Gold
 * Part of the Abora hypertext project: http://www.abora.org
 * Copyright 2003 David G Jones
 * 
 * Translated from Udanax-Gold source code: http://www.udanax.com
 * Copyright 1979-1999 Udanax.com. All rights reserved
 */
package org.abora.gold.fossil;

import org.abora.gold.backrec.ResultRecorder;
import org.abora.gold.filter.Filter;
import org.abora.gold.fossil.RecorderFossil;
import org.abora.gold.id.IDRegion;
import org.abora.gold.tclude.TrailBlazer;
import org.abora.gold.xcvr.Rcvr;
import org.abora.gold.xcvr.Xmtr;


/**
 * A Fossil for a WorkRecorder.
 */
public class WorkRecorderFossil extends RecorderFossil {
	protected Filter myEndorsementsFilter;
/*
udanax-top.st:10930:
RecorderFossil subclass: #WorkRecorderFossil
	instanceVariableNames: 'myEndorsementsFilter {Filter}'
	classVariableNames: ''
	poolDictionaries: ''
	category: 'Xanadu-fossil'!
*/
/*
udanax-top.st:10934:
WorkRecorderFossil comment:
'A Fossil for a WorkRecorder.'!
*/
/*
udanax-top.st:10936:
(WorkRecorderFossil getOrMakeCxxClassDescription)
	attributes: ((Set new) add: #SHEPHERD.PATRIARCH; add: #COPY; add: #DEFERRED; add: #DEFERRED.LOCKED; add: #NOT.A.TYPE; yourself)!
*/

public ResultRecorder actualRecorder() {
throw new UnsupportedOperationException();/*
udanax-top.st:10941:WorkRecorderFossil methodsFor: 'protected: accessing'!
{ResultRecorder} actualRecorder
	self subclassResponsibility!
*/
}

public Filter endorsementsFilter() {
throw new UnsupportedOperationException();/*
udanax-top.st:10945:WorkRecorderFossil methodsFor: 'protected: accessing'!
{Filter} endorsementsFilter
	^myEndorsementsFilter!
*/
}

public  WorkRecorderFossil(IDRegion loginAuthority, Filter endorsementsFilter, TrailBlazer trailBlazer) {
	super(null, null);
throw new UnsupportedOperationException();/*
udanax-top.st:10951:WorkRecorderFossil methodsFor: 'create'!
create: loginAuthority {IDRegion}
	with: endorsementsFilter {Filter}
	with: trailBlazer {TrailBlazer}
	
	super create: loginAuthority with: trailBlazer.
	myEndorsementsFilter := endorsementsFilter.!
*/
}

public  WorkRecorderFossil(Rcvr receiver) {
	super(receiver);
throw new UnsupportedOperationException();/*
udanax-top.st:10960:WorkRecorderFossil methodsFor: 'generated:'!
create.Rcvr: receiver {Rcvr}
	super create.Rcvr: receiver.
	myEndorsementsFilter _ receiver receiveHeaper.!
*/
}

public void sendSelfTo(Xmtr xmtr) {
throw new UnsupportedOperationException();/*
udanax-top.st:10964:WorkRecorderFossil methodsFor: 'generated:'!
{void} sendSelfTo: xmtr {Xmtr}
	super sendSelfTo: xmtr.
	xmtr sendHeaper: myEndorsementsFilter.!
*/
}
}
