/*
 * Abora-Gold
 * Part of the Abora hypertext project: http://www.abora.org
 * Copyright 2003 David G Jones
 * 
 * Translated from Udanax-Gold source code: http://www.udanax.com
 * Copyright 1979-1999 Udanax.com. All rights reserved
 */
package org.abora.gold.fossil;

import org.abora.gold.backrec.ResultRecorder;
import org.abora.gold.be.basic.BeRangeElement;
import org.abora.gold.be.canopy.SensorCrum;
import org.abora.gold.filter.Filter;
import org.abora.gold.fossil.WorkRecorderFossil;
import org.abora.gold.id.IDRegion;
import org.abora.gold.tclude.TrailBlazer;
import org.abora.gold.turtle.Agenda;
import org.abora.gold.xcvr.Rcvr;
import org.abora.gold.xcvr.Xmtr;


/**
 * A Fossil for a DirectWorkRecorder.
 */
public class DirectWorkRecorderFossil extends WorkRecorderFossil {
/*
udanax-top.st:10968:
WorkRecorderFossil subclass: #DirectWorkRecorderFossil
	instanceVariableNames: ''
	classVariableNames: ''
	poolDictionaries: ''
	category: 'Xanadu-fossil'!
*/
/*
udanax-top.st:10972:
DirectWorkRecorderFossil comment:
'A Fossil for a DirectWorkRecorder.'!
*/
/*
udanax-top.st:10974:
(DirectWorkRecorderFossil getOrMakeCxxClassDescription)
	attributes: ((Set new) add: #SHEPHERD.PATRIARCH; add: #COPY; add: #LOCKED; add: #NOT.A.TYPE; add: #CONCRETE; yourself)!
*/

public ResultRecorder actualRecorder() {
throw new UnsupportedOperationException();/*
udanax-top.st:10979:DirectWorkRecorderFossil methodsFor: 'protected: accessing'!
{ResultRecorder} actualRecorder
	^DirectWorkRecorder
		create: self endorsementsFilter
		with: self trailBlazer!
*/
}

public  DirectWorkRecorderFossil(IDRegion loginAuthority, Filter endorsementsFilter, TrailBlazer trailBlazer) {
	super(null, null, null);
throw new UnsupportedOperationException();/*
udanax-top.st:10987:DirectWorkRecorderFossil methodsFor: 'create'!
create: loginAuthority {IDRegion}
	with: endorsementsFilter {Filter}
	with: trailBlazer {TrailBlazer}
	
	super create: loginAuthority
		with: endorsementsFilter
		with: trailBlazer.
	self newShepherd.
	self remember.!
*/
}

/**
 * do nothing
 */
public void storeDataRecordingAgents(SensorCrum sensorCrum, Agenda agenda) {
throw new UnsupportedOperationException();/*
udanax-top.st:10999:DirectWorkRecorderFossil methodsFor: 'backfollow'!
{void} storeDataRecordingAgents: sensorCrum {SensorCrum}
	with: agenda {Agenda}
	"do nothing"!
*/
}

public void storeRangeElementRecordingAgents(BeRangeElement rangeElement, SensorCrum sensorCrum, Agenda agenda) {
throw new UnsupportedOperationException();/*
udanax-top.st:11004:DirectWorkRecorderFossil methodsFor: 'backfollow'!
{void} storeRangeElementRecordingAgents: rangeElement {BeRangeElement}
	with: sensorCrum {SensorCrum}
	with: agenda {Agenda}
	((rangeElement isKindOf: BeEdition) or: [rangeElement isKindOf: BePlaceHolder])
		ifTrue:
			[super storeRangeElementRecordingAgents: rangeElement
				with: sensorCrum
				with: agenda]!
*/
}

public  DirectWorkRecorderFossil(Rcvr receiver) {
	super(receiver);
throw new UnsupportedOperationException();/*
udanax-top.st:11016:DirectWorkRecorderFossil methodsFor: 'generated:'!
create.Rcvr: receiver {Rcvr}
	super create.Rcvr: receiver.!
*/
}

public void sendSelfTo(Xmtr xmtr) {
throw new UnsupportedOperationException();/*
udanax-top.st:11019:DirectWorkRecorderFossil methodsFor: 'generated:'!
{void} sendSelfTo: xmtr {Xmtr}
	super sendSelfTo: xmtr.!
*/
}
}
