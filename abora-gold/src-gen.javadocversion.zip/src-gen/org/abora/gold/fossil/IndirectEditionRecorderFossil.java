/*
 * Abora-Gold
 * Part of the Abora hypertext project: http://www.abora.org
 * Copyright 2003 David G Jones
 * 
 * Translated from Udanax-Gold source code: http://www.udanax.com
 * Copyright 1979-1999 Udanax.com. All rights reserved
 */
package org.abora.gold.fossil;

import org.abora.gold.backrec.ResultRecorder;
import org.abora.gold.filter.Filter;
import org.abora.gold.fossil.EditionRecorderFossil;
import org.abora.gold.id.IDRegion;
import org.abora.gold.tclude.TrailBlazer;
import org.abora.gold.xcvr.Rcvr;
import org.abora.gold.xcvr.Xmtr;


/**
 * A Fossil for an EditionRecorder with the directOnly flag off.
 */
public class IndirectEditionRecorderFossil extends EditionRecorderFossil {
/*
udanax-top.st:10890:
EditionRecorderFossil subclass: #IndirectEditionRecorderFossil
	instanceVariableNames: ''
	classVariableNames: ''
	poolDictionaries: ''
	category: 'Xanadu-fossil'!
*/
/*
udanax-top.st:10894:
IndirectEditionRecorderFossil comment:
'A Fossil for an EditionRecorder with the directOnly flag off.'!
*/
/*
udanax-top.st:10896:
(IndirectEditionRecorderFossil getOrMakeCxxClassDescription)
	attributes: ((Set new) add: #SHEPHERD.PATRIARCH; add: #COPY; add: #LOCKED; add: #NOT.A.TYPE; add: #CONCRETE; yourself)!
*/

public ResultRecorder actualRecorder() {
throw new UnsupportedOperationException();/*
udanax-top.st:10901:IndirectEditionRecorderFossil methodsFor: 'protected: accessing'!
{ResultRecorder} actualRecorder
	^IndirectEditionRecorder
		create: self directFilter
		with: self indirectFilter
		with: self trailBlazer!
*/
}

public  IndirectEditionRecorderFossil(IDRegion loginAuthority, Filter directFilter, Filter indirectFilter, TrailBlazer trailBlazer) {
	super(null, null, null, null);
throw new UnsupportedOperationException();/*
udanax-top.st:10910:IndirectEditionRecorderFossil methodsFor: 'create'!
create: loginAuthority {IDRegion}
	with: directFilter {Filter}
	with: indirectFilter {Filter}
	with: trailBlazer {TrailBlazer}
	
	super create: loginAuthority
		with: directFilter
		with: indirectFilter
		with: trailBlazer.
	self newShepherd.
	self remember.!
*/
}

public  IndirectEditionRecorderFossil(Rcvr receiver) {
	super(receiver);
throw new UnsupportedOperationException();/*
udanax-top.st:10924:IndirectEditionRecorderFossil methodsFor: 'generated:'!
create.Rcvr: receiver {Rcvr}
	super create.Rcvr: receiver.!
*/
}

public void sendSelfTo(Xmtr xmtr) {
throw new UnsupportedOperationException();/*
udanax-top.st:10927:IndirectEditionRecorderFossil methodsFor: 'generated:'!
{void} sendSelfTo: xmtr {Xmtr}
	super sendSelfTo: xmtr.!
*/
}
}
