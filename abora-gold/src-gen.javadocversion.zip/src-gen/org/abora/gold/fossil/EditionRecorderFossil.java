/*
 * Abora-Gold
 * Part of the Abora hypertext project: http://www.abora.org
 * Copyright 2003 David G Jones
 * 
 * Translated from Udanax-Gold source code: http://www.udanax.com
 * Copyright 1979-1999 Udanax.com. All rights reserved
 */
package org.abora.gold.fossil;

import org.abora.gold.backrec.ResultRecorder;
import org.abora.gold.filter.Filter;
import org.abora.gold.fossil.RecorderFossil;
import org.abora.gold.id.IDRegion;
import org.abora.gold.tclude.TrailBlazer;
import org.abora.gold.xcvr.Rcvr;
import org.abora.gold.xcvr.Xmtr;


/**
 * A Fossil for an EditionRecorder.
 */
public class EditionRecorderFossil extends RecorderFossil {
	protected Filter myDirectFilter;
	protected Filter myIndirectFilter;
/*
udanax-top.st:10802:
RecorderFossil subclass: #EditionRecorderFossil
	instanceVariableNames: '
		myDirectFilter {Filter}
		myIndirectFilter {Filter}'
	classVariableNames: ''
	poolDictionaries: ''
	category: 'Xanadu-fossil'!
*/
/*
udanax-top.st:10808:
EditionRecorderFossil comment:
'A Fossil for an EditionRecorder.'!
*/
/*
udanax-top.st:10810:
(EditionRecorderFossil getOrMakeCxxClassDescription)
	attributes: ((Set new) add: #SHEPHERD.PATRIARCH; add: #COPY; add: #DEFERRED; add: #DEFERRED.LOCKED; add: #NOT.A.TYPE; yourself)!
*/

public ResultRecorder actualRecorder() {
throw new UnsupportedOperationException();/*
udanax-top.st:10815:EditionRecorderFossil methodsFor: 'protected: accessing'!
{ResultRecorder} actualRecorder
	self subclassResponsibility!
*/
}

public Filter directFilter() {
throw new UnsupportedOperationException();/*
udanax-top.st:10819:EditionRecorderFossil methodsFor: 'protected: accessing'!
{Filter} directFilter
	
	^myDirectFilter!
*/
}

public Filter indirectFilter() {
throw new UnsupportedOperationException();/*
udanax-top.st:10823:EditionRecorderFossil methodsFor: 'protected: accessing'!
{Filter} indirectFilter
	
	^myIndirectFilter!
*/
}

public  EditionRecorderFossil(IDRegion loginAuthority, Filter directFilter, Filter indirectFilter, TrailBlazer trailBlazer) {
	super(null, null);
throw new UnsupportedOperationException();/*
udanax-top.st:10829:EditionRecorderFossil methodsFor: 'create'!
create: loginAuthority {IDRegion}
	with: directFilter {Filter}
	with: indirectFilter {Filter}
	with: trailBlazer {TrailBlazer}
	
	super create: loginAuthority with: trailBlazer.
	myDirectFilter := directFilter.
	myIndirectFilter := indirectFilter.!
*/
}

public  EditionRecorderFossil(Rcvr receiver) {
	super(receiver);
throw new UnsupportedOperationException();/*
udanax-top.st:10840:EditionRecorderFossil methodsFor: 'generated:'!
create.Rcvr: receiver {Rcvr}
	super create.Rcvr: receiver.
	myDirectFilter _ receiver receiveHeaper.
	myIndirectFilter _ receiver receiveHeaper.!
*/
}

public void sendSelfTo(Xmtr xmtr) {
throw new UnsupportedOperationException();/*
udanax-top.st:10845:EditionRecorderFossil methodsFor: 'generated:'!
{void} sendSelfTo: xmtr {Xmtr}
	super sendSelfTo: xmtr.
	xmtr sendHeaper: myDirectFilter.
	xmtr sendHeaper: myIndirectFilter.!
*/
}
}
