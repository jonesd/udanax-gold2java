/*
 * Abora-Gold
 * Part of the Abora hypertext project: http://www.abora.org
 * Copyright 2003 David G Jones
 * 
 * Translated from Udanax-Gold source code: http://www.udanax.com
 * Copyright 1979-1999 Udanax.com. All rights reserved
 */
package org.abora.gold.packer;

import org.abora.gold.fm.support.Thunk;
import org.abora.gold.xcvr.Rcvr;
import org.abora.gold.xcvr.Xmtr;


public class SpareStageSpace extends Thunk {
	protected int myCruftedSnarfCount;
	protected int myFlocksPerSnarf;
	protected static int CruftedSnarfCount;
	protected static int FlocksPerSnarf;
/*
udanax-top.st:57965:
Thunk subclass: #SpareStageSpace
	instanceVariableNames: '
		myCruftedSnarfCount {Int32}
		myFlocksPerSnarf {Int32}'
	classVariableNames: '
		CruftedSnarfCount {Int32} 
		FlocksPerSnarf {Int32} '
	poolDictionaries: ''
	category: 'Xanadu-packer'!
*/
/*
udanax-top.st:57973:
(SpareStageSpace getOrMakeCxxClassDescription)
	attributes: ((Set new) add: #CONCRETE; add: #(COPY boot ); yourself)!
*/
/*
udanax-top.st:57995:
SpareStageSpace class
	instanceVariableNames: ''!
*/
/*
udanax-top.st:57998:
(SpareStageSpace getOrMakeCxxClassDescription)
	attributes: ((Set new) add: #CONCRETE; add: #(COPY boot ); yourself)!
*/

public void execute() {
throw new UnsupportedOperationException();/*
udanax-top.st:57978:SpareStageSpace methodsFor: 'execute'!
{void} execute
	CruftedSnarfCount := myCruftedSnarfCount.
	FlocksPerSnarf := myFlocksPerSnarf.!
*/
}

public  SpareStageSpace(Rcvr receiver) {
throw new UnsupportedOperationException();/*
udanax-top.st:57984:SpareStageSpace methodsFor: 'generated:'!
create.Rcvr: receiver {Rcvr}
	super create.Rcvr: receiver.
	myCruftedSnarfCount _ receiver receiveInt32.
	myFlocksPerSnarf _ receiver receiveInt32.!
*/
}

public void sendSelfTo(Xmtr xmtr) {
throw new UnsupportedOperationException();/*
udanax-top.st:57989:SpareStageSpace methodsFor: 'generated:'!
{void} sendSelfTo: xmtr {Xmtr}
	super sendSelfTo: xmtr.
	xmtr sendInt32: myCruftedSnarfCount.
	xmtr sendInt32: myFlocksPerSnarf.!
*/
}

public static void linkTimeNonInherited() {
throw new UnsupportedOperationException();/*
udanax-top.st:58003:SpareStageSpace class methodsFor: 'smalltalk: init'!
linkTimeNonInherited
	CruftedSnarfCount := 7.
	FlocksPerSnarf := 100.!
*/
}

public static int cruftedSnarfsGuess() {
throw new UnsupportedOperationException();/*
udanax-top.st:58009:SpareStageSpace class methodsFor: 'accessing'!
{Int32} cruftedSnarfsGuess
	^ CruftedSnarfCount!
*/
}

public static int flocksPerSnarfGuess() {
throw new UnsupportedOperationException();/*
udanax-top.st:58012:SpareStageSpace class methodsFor: 'accessing'!
{Int32} flocksPerSnarfGuess
	^ FlocksPerSnarf!
*/
}
}
