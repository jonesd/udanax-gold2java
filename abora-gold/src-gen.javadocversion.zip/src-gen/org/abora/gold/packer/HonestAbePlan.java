/*
 * Abora-Gold
 * Part of the Abora hypertext project: http://www.abora.org
 * Copyright 2003 David G Jones
 * 
 * Translated from Udanax-Gold source code: http://www.udanax.com
 * Copyright 1979-1999 Udanax.com. All rights reserved
 */
package org.abora.gold.packer;

import org.abora.gold.cobbler.BootMaker;
import org.abora.gold.xcvr.Rcvr;
import org.abora.gold.xcvr.Xmtr;
import org.abora.gold.xpp.basic.Category;
import org.abora.gold.xpp.basic.Heaper;


public class HonestAbePlan extends BootMaker {
	protected Category myCategory;
/*
udanax-top.st:56914:
BootMaker subclass: #HonestAbePlan
	instanceVariableNames: 'myCategory {Category}'
	classVariableNames: ''
	poolDictionaries: ''
	category: 'Xanadu-packer'!
*/
/*
udanax-top.st:56918:
(HonestAbePlan getOrMakeCxxClassDescription)
	attributes: ((Set new) add: #CONCRETE; add: #(COPY boot ); add: #NOT.A.TYPE; yourself)!
*/

public Category bootCategory() {
throw new UnsupportedOperationException();/*
udanax-top.st:56923:HonestAbePlan methodsFor: 'accessing'!
{Category} bootCategory
	^myCategory!
*/
}

public Heaper bootHeaper() {
throw new UnsupportedOperationException();/*
udanax-top.st:56926:HonestAbePlan methodsFor: 'accessing'!
{Heaper} bootHeaper
	^CurrentPacker fluidGet getInitialFlock bootHeaper!
*/
}

public  HonestAbePlan(Rcvr receiver) {
throw new UnsupportedOperationException();/*
udanax-top.st:56932:HonestAbePlan methodsFor: 'generated:'!
create.Rcvr: receiver {Rcvr}
	super create.Rcvr: receiver.
	myCategory _ receiver receiveHeaper.!
*/
}

public void sendSelfTo(Xmtr xmtr) {
throw new UnsupportedOperationException();/*
udanax-top.st:56936:HonestAbePlan methodsFor: 'generated:'!
{void} sendSelfTo: xmtr {Xmtr}
	super sendSelfTo: xmtr.
	xmtr sendHeaper: myCategory.!
*/
}
}
