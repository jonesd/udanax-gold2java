/*
 * Abora-Gold
 * Part of the Abora hypertext project: http://www.abora.org
 * Copyright 2003 David G Jones
 * 
 * Translated from Udanax-Gold source code: http://www.udanax.com
 * Copyright 1979-1999 Udanax.com. All rights reserved
 */
package org.abora.gold.packer;

import org.abora.gold.packer.PersistentCleaner;
import org.abora.gold.schunk.ChunkCleaner;
import org.abora.gold.xpp.basic.Heaper;


/**
 * This does a makePersistent when ServerChunks go away
 */
public class PersistentCleaner extends ChunkCleaner {
	protected static PersistentCleaner ThePersistentCleaner;
/*
udanax-top.st:13695:
ChunkCleaner subclass: #PersistentCleaner
	instanceVariableNames: ''
	classVariableNames: 'ThePersistentCleaner {PersistentCleaner} '
	poolDictionaries: ''
	category: 'Xanadu-packer'!
*/
/*
udanax-top.st:13699:
PersistentCleaner comment:
'This does a makePersistent when ServerChunks go away'!
*/
/*
udanax-top.st:13701:
(PersistentCleaner getOrMakeCxxClassDescription)
	attributes: ((Set new) add: #CONCRETE; yourself)!
*/
/*
udanax-top.st:13715:
PersistentCleaner class
	instanceVariableNames: ''!
*/
/*
udanax-top.st:13718:
(PersistentCleaner getOrMakeCxxClassDescription)
	attributes: ((Set new) add: #CONCRETE; yourself)!
*/

public void cleanup() {
throw new UnsupportedOperationException();/*
udanax-top.st:13706:PersistentCleaner methodsFor: 'invoking'!
{void} cleanup
	CurrentPacker fluidGet purge!
*/
}

public  PersistentCleaner() {
throw new UnsupportedOperationException();/*
udanax-top.st:13711:PersistentCleaner methodsFor: 'protected: create'!
create
	super create!
*/
}

public static void linkTimeNonInherited() {
throw new UnsupportedOperationException();/*
udanax-top.st:13723:PersistentCleaner class methodsFor: 'smalltalk: init'!
linkTimeNonInherited
	ThePersistentCleaner := NULL!
*/
}

public static Heaper make() {
throw new UnsupportedOperationException();/*
udanax-top.st:13728:PersistentCleaner class methodsFor: 'create'!
make
	ThePersistentCleaner == NULL ifTrue: [ThePersistentCleaner := self create].
	^ ThePersistentCleaner!
*/
}
}
