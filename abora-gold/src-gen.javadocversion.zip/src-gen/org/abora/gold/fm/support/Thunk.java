/*
 * Abora-Gold
 * Part of the Abora hypertext project: http://www.abora.org
 * Copyright 2003 David G Jones
 * 
 * Translated from Udanax-Gold source code: http://www.udanax.com
 * Copyright 1979-1999 Udanax.com. All rights reserved
 */
package org.abora.gold.fm.support;

import org.abora.gold.xpp.basic.Heaper;


/**
 * Thunk is the abstraction for reified void/0-argument operations.  Therse include Testers,
 * frontend operations, etc.
 */
public class Thunk extends Heaper {
/*
udanax-top.st:56776:
Heaper subclass: #Thunk
	instanceVariableNames: ''
	classVariableNames: ''
	poolDictionaries: ''
	category: 'FM-Support'!
*/
/*
udanax-top.st:56780:
Thunk comment:
'Thunk is the abstraction for reified void/0-argument operations.  Therse include Testers, frontend operations, etc.'!
*/
/*
udanax-top.st:56782:
(Thunk getOrMakeCxxClassDescription)
	attributes: ((Set new) add: #DEFERRED; add: #EQ; yourself)!
*/

/**
 * Execute the action defined by this thunk.
 */
public void execute() {
throw new UnsupportedOperationException();/*
udanax-top.st:56787:Thunk methodsFor: 'operate'!
{void} execute
	"Execute the action defined by this thunk."
	self subclassResponsibility!
*/
}

public int actualHashForEqual() {
throw new UnsupportedOperationException();/*
udanax-top.st:56794:Thunk methodsFor: 'generated:'!
actualHashForEqual ^self asOop!
*/
}

public boolean isEqual(Object other) {
throw new UnsupportedOperationException();/*
udanax-top.st:56796:Thunk methodsFor: 'generated:'!
isEqual: other ^self == other!
*/
}
}
