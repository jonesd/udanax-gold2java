/*
 * Abora-Gold
 * Part of the Abora hypertext project: http://www.abora.org
 * Copyright 2003 David G Jones
 * 
 * Translated from Udanax-Gold source code: http://www.udanax.com
 * Copyright 1979-1999 Udanax.com. All rights reserved
 */
package org.abora.gold.backrec;

import org.abora.gold.backrec.WorkRecorder;
import org.abora.gold.be.basic.BeEdition;
import org.abora.gold.be.basic.BeRangeElement;
import org.abora.gold.be.canopy.PropFinder;
import org.abora.gold.collection.cache.HashSetCache;
import org.abora.gold.filter.Filter;
import org.abora.gold.fossil.RecorderFossil;
import org.abora.gold.tclude.TrailBlazer;


/**
 * Represents the a persistent works or rangeWorks query with the directContainersOnly flag
 * on
 */
public class DirectWorkRecorder extends WorkRecorder {
/*
udanax-top.st:44746:
WorkRecorder subclass: #DirectWorkRecorder
	instanceVariableNames: ''
	classVariableNames: ''
	poolDictionaries: ''
	category: 'Xanadu-backrec'!
*/
/*
udanax-top.st:44750:
DirectWorkRecorder comment:
'Represents the a persistent works or rangeWorks query with the directContainersOnly flag on'!
*/
/*
udanax-top.st:44752:
(DirectWorkRecorder getOrMakeCxxClassDescription)
	attributes: ((Set new) add: #CONCRETE; add: #NOT.A.TYPE; yourself)!
*/

public  DirectWorkRecorder(Filter endorsementsFilter, TrailBlazer trailBlazer) {
	super(endorsementsFilter, trailBlazer);
throw new UnsupportedOperationException();/*
udanax-top.st:44757:DirectWorkRecorder methodsFor: 'create'!
create: endorsementsFilter {Filter}
	with: trailBlazer {TrailBlazer}
	
	super create: endorsementsFilter
		with: trailBlazer!
*/
}

public boolean isDirectOnly() {
throw new UnsupportedOperationException();/*
udanax-top.st:44765:DirectWorkRecorder methodsFor: 'accessing'!
{BooleanVar} isDirectOnly
	
	^true!
*/
}

public void delayedStoreBackfollow(BeEdition edition, PropFinder finder, RecorderFossil fossil, HashSetCache hCrumCache) {
throw new UnsupportedOperationException();/*
udanax-top.st:44771:DirectWorkRecorder methodsFor: 'backfollow'!
{void} delayedStoreBackfollow: edition {BeEdition unused}
	with: finder {PropFinder unused} 
	with: fossil {RecorderFossil unused}
	with: hCrumCache {HashSetCache unused of: HistoryCrum }
	
	Heaper BLAST: #FatalError. "This algorithm should never reach here"!
*/
}

public void delayedStoreMatching(BeRangeElement element, PropFinder finder, RecorderFossil fossil, HashSetCache hCrumCache) {
throw new UnsupportedOperationException();/*
udanax-top.st:44778:DirectWorkRecorder methodsFor: 'backfollow'!
{void} delayedStoreMatching: element {BeRangeElement}
	with: finder {PropFinder unused} 
	with: fossil {RecorderFossil}
	with: hCrumCache {HashSetCache unused of: HistoryCrum }
	
	 self recordImmediateWorks: element with: fossil "and nothing else"!
*/
}
}
