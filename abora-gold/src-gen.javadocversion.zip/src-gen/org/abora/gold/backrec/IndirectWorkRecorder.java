/*
 * Abora-Gold
 * Part of the Abora hypertext project: http://www.abora.org
 * Copyright 2003 David G Jones
 * 
 * Translated from Udanax-Gold source code: http://www.udanax.com
 * Copyright 1979-1999 Udanax.com. All rights reserved
 */
package org.abora.gold.backrec;

import org.abora.gold.backrec.WorkRecorder;
import org.abora.gold.be.basic.BeEdition;
import org.abora.gold.be.basic.BeRangeElement;
import org.abora.gold.be.canopy.PropFinder;
import org.abora.gold.collection.cache.HashSetCache;
import org.abora.gold.filter.Filter;
import org.abora.gold.fossil.RecorderFossil;
import org.abora.gold.tclude.TrailBlazer;


/**
 * Represents the a persistent works or rangeWorks query with the directContainersOnly flag
 * off
 */
public class IndirectWorkRecorder extends WorkRecorder {
/*
udanax-top.st:44785:
WorkRecorder subclass: #IndirectWorkRecorder
	instanceVariableNames: ''
	classVariableNames: ''
	poolDictionaries: ''
	category: 'Xanadu-backrec'!
*/
/*
udanax-top.st:44789:
IndirectWorkRecorder comment:
'Represents the a persistent works or rangeWorks query with the directContainersOnly flag off'!
*/
/*
udanax-top.st:44791:
(IndirectWorkRecorder getOrMakeCxxClassDescription)
	attributes: ((Set new) add: #CONCRETE; add: #NOT.A.TYPE; yourself)!
*/

public  IndirectWorkRecorder(Filter endorsementsFilter, TrailBlazer trailBlazer) {
	super(endorsementsFilter, trailBlazer);
throw new UnsupportedOperationException();/*
udanax-top.st:44796:IndirectWorkRecorder methodsFor: 'create'!
create: endorsementsFilter {Filter}
	with: trailBlazer {TrailBlazer}
	
	super create: endorsementsFilter
		with: trailBlazer!
*/
}

public boolean isDirectOnly() {
throw new UnsupportedOperationException();/*
udanax-top.st:44804:IndirectWorkRecorder methodsFor: 'accessing'!
{BooleanVar} isDirectOnly
	
	^false!
*/
}

public void delayedStoreBackfollow(BeEdition edition, PropFinder finder, RecorderFossil fossil, HashSetCache hCrumCache) {
throw new UnsupportedOperationException();/*
udanax-top.st:44810:IndirectWorkRecorder methodsFor: 'backfollow'!
{void} delayedStoreBackfollow: edition {BeEdition}
	with: finder {PropFinder} 
	with: fossil {RecorderFossil}
	with: hCrumCache {HashSetCache of: HistoryCrum}
	
	self recordImmediateWorks: edition with: fossil.
	edition delayedStoreBackfollow: finder with: fossil with: self with: hCrumCache!
*/
}

public void delayedStoreMatching(BeRangeElement element, PropFinder finder, RecorderFossil fossil, HashSetCache hCrumCache) {
throw new UnsupportedOperationException();/*
udanax-top.st:44818:IndirectWorkRecorder methodsFor: 'backfollow'!
{void} delayedStoreMatching: element {BeRangeElement}
	with: finder {PropFinder} 
	with: fossil {RecorderFossil}
	with: hCrumCache {HashSetCache of: HistoryCrum}
	
	 self recordImmediateWorks: element with: fossil.
	 super delayedStoreMatching: element with: finder with: fossil with: hCrumCache!
*/
}
}
