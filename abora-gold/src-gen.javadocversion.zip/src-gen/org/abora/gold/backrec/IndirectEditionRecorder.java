/*
 * Abora-Gold
 * Part of the Abora hypertext project: http://www.abora.org
 * Copyright 2003 David G Jones
 * 
 * Translated from Udanax-Gold source code: http://www.udanax.com
 * Copyright 1979-1999 Udanax.com. All rights reserved
 */
package org.abora.gold.backrec;

import org.abora.gold.backrec.EditionRecorder;
import org.abora.gold.be.basic.BeEdition;
import org.abora.gold.be.canopy.PropFinder;
import org.abora.gold.collection.cache.HashSetCache;
import org.abora.gold.filter.Filter;
import org.abora.gold.fossil.RecorderFossil;
import org.abora.gold.tclude.TrailBlazer;


/**
 * Represents the a persistent transcluders or rangeTranscluders query with
 * directContainersOnly flag off
 */
public class IndirectEditionRecorder extends EditionRecorder {
/*
udanax-top.st:44662:
EditionRecorder subclass: #IndirectEditionRecorder
	instanceVariableNames: ''
	classVariableNames: ''
	poolDictionaries: ''
	category: 'Xanadu-backrec'!
*/
/*
udanax-top.st:44666:
IndirectEditionRecorder comment:
'Represents the a persistent transcluders or rangeTranscluders query with directContainersOnly flag off'!
*/
/*
udanax-top.st:44668:
(IndirectEditionRecorder getOrMakeCxxClassDescription)
	attributes: ((Set new) add: #CONCRETE; add: #NOT.A.TYPE; yourself)!
*/

public boolean isDirectOnly() {
throw new UnsupportedOperationException();/*
udanax-top.st:44673:IndirectEditionRecorder methodsFor: 'accessing'!
{BooleanVar} isDirectOnly
	
	^false!
*/
}

public  IndirectEditionRecorder(Filter directFilter, Filter indirectFilter, TrailBlazer trailBlazer) {
	super(directFilter, indirectFilter, trailBlazer);
throw new UnsupportedOperationException();/*
udanax-top.st:44679:IndirectEditionRecorder methodsFor: 'create'!
create: directFilter {Filter}
	with: indirectFilter {Filter}
	with: trailBlazer {TrailBlazer}
	
	super create: directFilter
		with: indirectFilter
		with: trailBlazer!
*/
}

public void delayedStoreBackfollow(BeEdition edition, PropFinder finder, RecorderFossil fossil, HashSetCache hCrumCache) {
throw new UnsupportedOperationException();/*
udanax-top.st:44689:IndirectEditionRecorder methodsFor: 'backfollow'!
{void} delayedStoreBackfollow: edition {BeEdition}
	with: finder {PropFinder} 
	with: fossil {RecorderFossil}
	with: hCrumCache {HashSetCache of: HistoryCrum}
	super delayedStoreBackfollow: edition with: finder with: fossil with: hCrumCache.
	edition delayedStoreBackfollow: finder with: fossil with: self with: hCrumCache.!
*/
}
}
