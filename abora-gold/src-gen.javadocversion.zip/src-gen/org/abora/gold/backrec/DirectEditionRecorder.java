/*
 * Abora-Gold
 * Part of the Abora hypertext project: http://www.abora.org
 * Copyright 2003 David G Jones
 * 
 * Translated from Udanax-Gold source code: http://www.udanax.com
 * Copyright 1979-1999 Udanax.com. All rights reserved
 */
package org.abora.gold.backrec;

import org.abora.gold.backrec.EditionRecorder;
import org.abora.gold.filter.Filter;
import org.abora.gold.tclude.TrailBlazer;


/**
 * Represents the a persistent transcluders or rangeTranscluders query with
 * directContainersOnly flag on
 */
public class DirectEditionRecorder extends EditionRecorder {
/*
udanax-top.st:44637:
EditionRecorder subclass: #DirectEditionRecorder
	instanceVariableNames: ''
	classVariableNames: ''
	poolDictionaries: ''
	category: 'Xanadu-backrec'!
*/
/*
udanax-top.st:44641:
DirectEditionRecorder comment:
'Represents the a persistent transcluders or rangeTranscluders query with directContainersOnly flag on'!
*/
/*
udanax-top.st:44643:
(DirectEditionRecorder getOrMakeCxxClassDescription)
	attributes: ((Set new) add: #CONCRETE; add: #NOT.A.TYPE; yourself)!
*/

public boolean isDirectOnly() {
throw new UnsupportedOperationException();/*
udanax-top.st:44648:DirectEditionRecorder methodsFor: 'accessing'!
{BooleanVar} isDirectOnly
	
	^true!
*/
}

public  DirectEditionRecorder(Filter directFilter, Filter indirectFilter, TrailBlazer trailBlazer) {
	super(directFilter, indirectFilter, trailBlazer);
throw new UnsupportedOperationException();/*
udanax-top.st:44654:DirectEditionRecorder methodsFor: 'create'!
create: directFilter {Filter}
	with: indirectFilter {Filter}
	with: trailBlazer {TrailBlazer}
	
	super create: directFilter
		with: indirectFilter
		with: trailBlazer!
*/
}
}
