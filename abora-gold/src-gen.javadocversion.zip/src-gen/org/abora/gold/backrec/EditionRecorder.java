/*
 * Abora-Gold
 * Part of the Abora hypertext project: http://www.abora.org
 * Copyright 2003 David G Jones
 * 
 * Translated from Udanax-Gold source code: http://www.udanax.com
 * Copyright 1979-1999 Udanax.com. All rights reserved
 */
package org.abora.gold.backrec;

import org.abora.gold.backrec.ResultRecorder;
import org.abora.gold.be.basic.BeEdition;
import org.abora.gold.be.basic.BeRangeElement;
import org.abora.gold.be.canopy.PropFinder;
import org.abora.gold.collection.cache.HashSetCache;
import org.abora.gold.filter.Filter;
import org.abora.gold.fossil.RecorderFossil;
import org.abora.gold.tclude.TrailBlazer;


/**
 * Represents the a persistent transcluders or rangeTranscluders query
 */
public class EditionRecorder extends ResultRecorder {
	protected Filter myDirectFilter;
	protected Filter myIndirectFilter;
/*
udanax-top.st:44581:
ResultRecorder subclass: #EditionRecorder
	instanceVariableNames: '
		myDirectFilter {Filter}
		myIndirectFilter {Filter}'
	classVariableNames: ''
	poolDictionaries: ''
	category: 'Xanadu-backrec'!
*/
/*
udanax-top.st:44587:
EditionRecorder comment:
'Represents the a persistent transcluders or rangeTranscluders query'!
*/
/*
udanax-top.st:44589:
(EditionRecorder getOrMakeCxxClassDescription)
	attributes: ((Set new) add: #DEFERRED; yourself)!
*/

public boolean accepts(BeRangeElement element) {
throw new UnsupportedOperationException();/*
udanax-top.st:44594:EditionRecorder methodsFor: 'accessing'!
{BooleanVar} accepts: element {BeRangeElement}
	^element isKindOf: BeEdition!
*/
}

public Filter directFilter() {
throw new UnsupportedOperationException();/*
udanax-top.st:44598:EditionRecorder methodsFor: 'accessing'!
{Filter} directFilter
	^myDirectFilter!
*/
}

public Filter indirectFilter() {
throw new UnsupportedOperationException();/*
udanax-top.st:44602:EditionRecorder methodsFor: 'accessing'!
{Filter} indirectFilter
	^myIndirectFilter!
*/
}

public boolean isDirectOnly() {
throw new UnsupportedOperationException();/*
udanax-top.st:44606:EditionRecorder methodsFor: 'accessing'!
{BooleanVar} isDirectOnly
	
	self subclassResponsibility!
*/
}

public  EditionRecorder(Filter directFilter, Filter indirectFilter, TrailBlazer trailBlazer) {
	super(null, null, null);
throw new UnsupportedOperationException();/*
udanax-top.st:44612:EditionRecorder methodsFor: 'create'!
create: directFilter {Filter}
	with: indirectFilter {Filter}
	with: trailBlazer {TrailBlazer}
	
	super create: ((directFilter unionWith: indirectFilter) cast: Filter)
		with: ((directFilter relevantRegion unionWith: indirectFilter relevantRegion ) cast: CrossRegion)
		with: trailBlazer.
	
	myDirectFilter := directFilter.
	myIndirectFilter := indirectFilter.!
*/
}

public void delayedStoreBackfollow(BeEdition edition, PropFinder finder, RecorderFossil fossil, HashSetCache hCrumCache) {
throw new UnsupportedOperationException();/*
udanax-top.st:44625:EditionRecorder methodsFor: 'backfollow'!
{void} delayedStoreBackfollow: edition {BeEdition}
	with: finder {PropFinder unused} 
	with: fossil {RecorderFossil}
	with: hCrumCache {HashSetCache of: HistoryCrum unused}
	CurrentKeyMaster fluidBind: self keyMaster during:
		[((myDirectFilter match: edition visibleEndorsements)
				and: [edition anyPasses: (PropFinder
					backfollowFinder: self permissionsFilter with: myIndirectFilter)])
			ifTrue:
				[(RecorderTrigger make: fossil with: edition) schedule]]!
*/
}
}
