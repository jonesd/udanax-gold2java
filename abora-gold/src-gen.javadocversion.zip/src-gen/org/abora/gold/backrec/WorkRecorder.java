/*
 * Abora-Gold
 * Part of the Abora hypertext project: http://www.abora.org
 * Copyright 2003 David G Jones
 * 
 * Translated from Udanax-Gold source code: http://www.udanax.com
 * Copyright 1979-1999 Udanax.com. All rights reserved
 */
package org.abora.gold.backrec;

import org.abora.gold.backrec.ResultRecorder;
import org.abora.gold.be.basic.BeEdition;
import org.abora.gold.be.basic.BeRangeElement;
import org.abora.gold.be.canopy.PropFinder;
import org.abora.gold.collection.cache.HashSetCache;
import org.abora.gold.filter.Filter;
import org.abora.gold.fossil.RecorderFossil;
import org.abora.gold.tclude.TrailBlazer;


/**
 * Represents the a persistent works or rangeWorks query
 */
public class WorkRecorder extends ResultRecorder {
/*
udanax-top.st:44697:
ResultRecorder subclass: #WorkRecorder
	instanceVariableNames: ''
	classVariableNames: ''
	poolDictionaries: ''
	category: 'Xanadu-backrec'!
*/
/*
udanax-top.st:44701:
WorkRecorder comment:
'Represents the a persistent works or rangeWorks query'!
*/
/*
udanax-top.st:44703:
(WorkRecorder getOrMakeCxxClassDescription)
	attributes: ((Set new) add: #DEFERRED; yourself)!
*/

public  WorkRecorder(Filter endorsementsFilter, TrailBlazer trailBlazer) {
	super(null, null, null);
throw new UnsupportedOperationException();/*
udanax-top.st:44708:WorkRecorder methodsFor: 'create'!
create: endorsementsFilter {Filter}
	with: trailBlazer {TrailBlazer}
	
	super create: endorsementsFilter
		with: (endorsementsFilter relevantRegion cast: CrossRegion)
		with: trailBlazer!
*/
}

public boolean accepts(BeRangeElement element) {
throw new UnsupportedOperationException();/*
udanax-top.st:44717:WorkRecorder methodsFor: 'accessing'!
{BooleanVar} accepts: element {BeRangeElement}
	^element isKindOf: BeWork!
*/
}

public boolean isDirectOnly() {
throw new UnsupportedOperationException();/*
udanax-top.st:44721:WorkRecorder methodsFor: 'accessing'!
{BooleanVar} isDirectOnly
	
	self subclassResponsibility!
*/
}

public void delayedStoreBackfollow(BeEdition edition, PropFinder finder, RecorderFossil fossil, HashSetCache hCrumCache) {
throw new UnsupportedOperationException();/*
udanax-top.st:44727:WorkRecorder methodsFor: 'backfollow'!
{void} delayedStoreBackfollow: edition {BeEdition}
	with: finder {PropFinder} 
	with: fossil {RecorderFossil}
	with: hCrumCache {HashSetCache of: HistoryCrum}
	
	self subclassResponsibility!
*/
}

/**
 * If there are any Works directly on the RangeElement which pass the filters, record them
 */
public void recordImmediateWorks(BeRangeElement element, RecorderFossil fossil) {
throw new UnsupportedOperationException();/*
udanax-top.st:44734:WorkRecorder methodsFor: 'backfollow'!
{void} recordImmediateWorks: element {BeRangeElement} with: fossil {RecorderFossil}
	"If there are any Works directly on the RangeElement which pass the filters, record them"
	
	element cast: BeEdition into: [ :edition |
		edition currentWorks stepper forEach: [ :work {BeWork} |
			((work canBeReadBy: self keyMaster)
					and: [self endorsementsFilter match: work endorsements])
				ifTrue:
					[(RecorderTrigger make: fossil with: work) schedule]]]
	others:
		[]!
*/
}
}
