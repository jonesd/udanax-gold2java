/*
 * Abora-Gold
 * Part of the Abora hypertext project: http://www.abora.org
 * Copyright 2003 David G Jones
 * 
 * Translated from Udanax-Gold source code: http://www.udanax.com
 * Copyright 1979-1999 Udanax.com. All rights reserved
 */
package org.abora.gold.filter;

import java.io.PrintWriter;
import org.abora.gold.collection.sets.ScruSet;
import org.abora.gold.filter.Joint;
import org.abora.gold.spaces.basic.CoordinateSpace;
import org.abora.gold.spaces.basic.XnRegion;
import org.abora.gold.xcvr.Rcvr;
import org.abora.gold.xcvr.Xmtr;
import org.abora.gold.xpp.basic.Heaper;


/**
 * Joints are used to prune searches through trees of Regions. Each Joint summarizes the
 * Joints and Regions at its node and its children using their intersection and union. If you
 * maintain this information at each each node in the tree, then you can search for Regions
 * in the tree efficiently using Filter::pass() to adapt the search criteria to the contents
 * of the subtree. See also Filter::pass(Joint *).
 */
public class Joint extends Heaper {
	protected XnRegion myUnioned;
	protected XnRegion myIntersected;
/*
udanax-top.st:27751:
Heaper subclass: #Joint
	instanceVariableNames: '
		myUnioned {XnRegion}
		myIntersected {XnRegion}'
	classVariableNames: ''
	poolDictionaries: ''
	category: 'Xanadu-filter'!
*/
/*
udanax-top.st:27757:
Joint comment:
'Joints are used to prune searches through trees of Regions. Each Joint summarizes the Joints and Regions at its node and its children using their intersection and union. If you maintain this information at each each node in the tree, then you can search for Regions in the tree efficiently using Filter::pass() to adapt the search criteria to the contents of the subtree. See also Filter::pass(Joint *).'!
*/
/*
udanax-top.st:27759:
(Joint getOrMakeCxxClassDescription)
	attributes: ((Set new) add: #CONCRETE; add: #COPY; yourself)!
*/
/*
udanax-top.st:27823:
Joint class
	instanceVariableNames: ''!
*/
/*
udanax-top.st:27826:
(Joint getOrMakeCxxClassDescription)
	attributes: ((Set new) add: #CONCRETE; add: #COPY; yourself)!
*/

public  Joint(XnRegion unioned, XnRegion intersected) {
throw new UnsupportedOperationException();/*
udanax-top.st:27764:Joint methodsFor: 'creation'!
create: unioned {XnRegion} with:  intersected{XnRegion}
	super create.
	myUnioned _ unioned.
	myIntersected _ intersected.!
*/
}

public void printOn(PrintWriter oo) {
throw new UnsupportedOperationException();/*
udanax-top.st:27771:Joint methodsFor: 'printing'!
{void} printOn: oo {ostream reference}
	oo << self getCategory name << '(union: ' << myUnioned << '; intersected: ' << myIntersected << ')'!
*/
}

/**
 * The intersection of the regions at all child nodes in the tree.
 */
public XnRegion intersected() {
throw new UnsupportedOperationException();/*
udanax-top.st:27776:Joint methodsFor: 'accessing'!
{XnRegion INLINE} intersected
	"The intersection of the regions at all child nodes in the tree."
	^myIntersected!
*/
}

/**
 * A Joint that is a parent of this Joint and the given one.
 */
public Joint join(Joint other) {
throw new UnsupportedOperationException();/*
udanax-top.st:27781:Joint methodsFor: 'accessing'!
{Joint INLINE} join: other {Joint}
	"A Joint that is a parent of this Joint and the given one."
	
	^Joint make.Joint: self with: other!
*/
}

/**
 * The union of the regions at all child nodes in the tree.
 */
public XnRegion unioned() {
throw new UnsupportedOperationException();/*
udanax-top.st:27786:Joint methodsFor: 'accessing'!
{XnRegion INLINE} unioned
	"The union of the regions at all child nodes in the tree."
	^myUnioned!
*/
}

/**
 * A Joint that is a parent of this one and the given region.
 */
public Joint with(XnRegion region) {
throw new UnsupportedOperationException();/*
udanax-top.st:27791:Joint methodsFor: 'accessing'!
{Joint} with: region {XnRegion}
	"A Joint that is a parent of this one and the given region."
	
	^Joint make.XnRegion: (myUnioned unionWith: region)
		with: (myIntersected intersect: region)!
*/
}

public int actualHashForEqual() {
throw new UnsupportedOperationException();/*
udanax-top.st:27799:Joint methodsFor: 'testing'!
{UInt32} actualHashForEqual
	^myUnioned hashForEqual + myIntersected hashForEqual!
*/
}

public boolean isEqual(Heaper other) {
throw new UnsupportedOperationException();/*
udanax-top.st:27802:Joint methodsFor: 'testing'!
{BooleanVar} isEqual: other {Heaper}
	
	other cast: Joint into: [:o {Joint} |
			^(myUnioned isEqual: o unioned) and:
				[myIntersected isEqual: o intersected]]
		others: [^false].
	^false "fodder"!
*/
}

public  Joint(Rcvr receiver) {
throw new UnsupportedOperationException();/*
udanax-top.st:27812:Joint methodsFor: 'generated:'!
create.Rcvr: receiver {Rcvr}
	super create.Rcvr: receiver.
	myUnioned _ receiver receiveHeaper.
	myIntersected _ receiver receiveHeaper.!
*/
}

public void sendSelfTo(Xmtr xmtr) {
throw new UnsupportedOperationException();/*
udanax-top.st:27817:Joint methodsFor: 'generated:'!
{void} sendSelfTo: xmtr {Xmtr}
	super sendSelfTo: xmtr.
	xmtr sendHeaper: myUnioned.
	xmtr sendHeaper: myIntersected.!
*/
}

/**
 * An empty Joint in the given coordinate space.
 */
public static Heaper make(CoordinateSpace space) {
throw new UnsupportedOperationException();/*
udanax-top.st:27831:Joint class methodsFor: 'pseudo constructors'!
make.CoordinateSpace: space {CoordinateSpace}
	"An empty Joint in the given coordinate space."
	
	^Joint create: space emptyRegion with: space fullRegion!
*/
}

/**
 * A joint that is a parent of the two given Joints.
 */
public static Heaper make(Joint left, Joint right) {
throw new UnsupportedOperationException();/*
udanax-top.st:27836:Joint class methodsFor: 'pseudo constructors'!
make.Joint: left {Joint} with: right {Joint}
	"A joint that is a parent of the two given Joints."
	
	^Joint create: (left unioned unionWith: right unioned)
		with: (left intersected intersect: right intersected)!
*/
}

/**
 * A Joint that is a parent of all of the Joints in the set.
 */
public static Heaper make(ScruSet subs) {
throw new UnsupportedOperationException();/*
udanax-top.st:27842:Joint class methodsFor: 'pseudo constructors'!
make.ScruSet: subs {ScruSet of: Joint}
	"A Joint that is a parent of all of the Joints in the set."
	
	| unioned {XnRegion} intersected {XnRegion} subStepper {Stepper} |
	subStepper _ subs stepper.
	unioned _ (subStepper get cast: Joint) unioned.
	intersected _ (subStepper fetch cast: Joint) intersected.
	subStepper step.
	subStepper forEach: [ :sub {Joint} |
		unioned _ unioned unionWith: sub unioned.
		intersected _ intersected intersect: sub intersected].
	^Joint create: unioned with: intersected!
*/
}

/**
 * A Joint containing only the given region.
 */
public static Heaper make(XnRegion both) {
throw new UnsupportedOperationException();/*
udanax-top.st:27855:Joint class methodsFor: 'pseudo constructors'!
make.XnRegion: both {XnRegion}
	"A Joint containing only the given region."
	
	^Joint create: both with: both!
*/
}

/**
 * A Joint with the given union and intersection regions.
 */
public static Heaper make(XnRegion unioned, XnRegion intersected) {
throw new UnsupportedOperationException();/*
udanax-top.st:27860:Joint class methodsFor: 'pseudo constructors'!
make.XnRegion: unioned {XnRegion} with: intersected {XnRegion}
	"A Joint with the given union and intersection regions."
	
	^Joint create: unioned with: intersected!
*/
}

public static Heaper make(Object something) {
throw new UnsupportedOperationException();/*
udanax-top.st:27867:Joint class methodsFor: 'smalltalk: smalltalk defaults'!
make: something
	(something isKindOf: XnRegion) ifTrue:
		[^self make.XnRegion: something].
	(something isKindOf: CoordinateSpace) ifTrue:
		[^self make.CoordinateSpace: something].
	^self make.ScruSet: (something cast: ScruSet)!
*/
}

public static Heaper make(Object something, Object other) {
throw new UnsupportedOperationException();/*
udanax-top.st:27874:Joint class methodsFor: 'smalltalk: smalltalk defaults'!
make: something with: other
	(something isKindOf: Joint) ifTrue:
		[^self make.Joint: something with: other].
	^self make.XnRegion: (something cast: XnRegion) with: other!
*/
}
}
