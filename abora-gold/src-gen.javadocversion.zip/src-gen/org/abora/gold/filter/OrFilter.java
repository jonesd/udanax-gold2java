/*
 * Abora-Gold
 * Part of the Abora hypertext project: http://www.abora.org
 * Copyright 2003 David G Jones
 * 
 * Translated from Udanax-Gold source code: http://www.udanax.com
 * Copyright 1979-1999 Udanax.com. All rights reserved
 */
package org.abora.gold.filter;

import java.io.PrintWriter;
import org.abora.gold.collection.sets.ImmuSet;
import org.abora.gold.collection.steppers.Stepper;
import org.abora.gold.filter.Filter;
import org.abora.gold.filter.FilterSpace;
import org.abora.gold.filter.Joint;
import org.abora.gold.spaces.basic.XnRegion;
import org.abora.gold.xcvr.Rcvr;
import org.abora.gold.xcvr.Xmtr;
import org.abora.gold.xpp.basic.Heaper;


public class OrFilter extends Filter {
	protected ImmuSet mySubFilters;
/*
udanax-top.st:67342:
Filter subclass: #OrFilter
	instanceVariableNames: 'mySubFilters {ImmuSet of: Filter}'
	classVariableNames: ''
	poolDictionaries: ''
	category: 'Xanadu-Filter'!
*/
/*
udanax-top.st:67346:
(OrFilter getOrMakeCxxClassDescription)
	attributes: ((Set new) add: #CONCRETE; add: #NOT.A.TYPE; add: #COPY; yourself)!
*/

public  OrFilter(FilterSpace cs, ImmuSet subs) {
	super(cs);

throw new UnsupportedOperationException();/*
udanax-top.st:67351:OrFilter methodsFor: 'creation'!
create: cs {FilterSpace} with: subs {ImmuSet of: Filter}
	super create: cs.
	mySubFilters _ subs!
*/
}

public int actualHashForEqual() {
throw new UnsupportedOperationException();/*
udanax-top.st:67357:OrFilter methodsFor: 'testing'!
{UInt32} actualHashForEqual
	^(self coordinateSpace hashForEqual bitXor: mySubFilters hashForEqual)
		bitXor: #cat.U.OrFilter hashForEqual!
*/
}

public boolean isAllFilter() {
throw new UnsupportedOperationException();/*
udanax-top.st:67361:OrFilter methodsFor: 'testing'!
{BooleanVar} isAllFilter
	^false!
*/
}

public boolean isAnyFilter() {
throw new UnsupportedOperationException();/*
udanax-top.st:67365:OrFilter methodsFor: 'testing'!
{BooleanVar} isAnyFilter
	
	^false!
*/
}

public boolean isEmpty() {
throw new UnsupportedOperationException();/*
udanax-top.st:67369:OrFilter methodsFor: 'testing'!
{BooleanVar} isEmpty
	^false!
*/
}

public boolean isEqual(Heaper other) {
throw new UnsupportedOperationException();/*
udanax-top.st:67372:OrFilter methodsFor: 'testing'!
{BooleanVar} isEqual: other {Heaper}
	other
		cast: OrFilter into: [:of |
			^of subFilters isEqual: self subFilters]
		others: [^false].
	^false "fodder"!
*/
}

public boolean isFull() {
throw new UnsupportedOperationException();/*
udanax-top.st:67380:OrFilter methodsFor: 'testing'!
{BooleanVar} isFull	
	^false!
*/
}

public void printOn(PrintWriter oo) {
throw new UnsupportedOperationException();/*
udanax-top.st:67386:OrFilter methodsFor: 'printing'!
{void} printOn: oo {ostream reference}
	oo << self getCategory name.
	self subFilters printOnWithSimpleSyntax: oo with: '(' with: ' || ' with: ')'!
*/
}

public XnRegion complement() {
throw new UnsupportedOperationException();/*
udanax-top.st:67392:OrFilter methodsFor: 'operations'!
{XnRegion} complement
	| result {XnRegion} |
	result _ Filter openFilter: self coordinateSpace.
	self subFilters stepper forEach: [ :sub {XnRegion} |
		result _ result intersect: sub complement].
	^result!
*/
}

/**
 * tell whether a region passes this filter
 */
public boolean match(XnRegion region) {
throw new UnsupportedOperationException();/*
udanax-top.st:67402:OrFilter methodsFor: 'filtering'!
{BooleanVar} match: region {XnRegion}
	"tell whether a region passes this filter"
	self subFilters stepper forEach: [ :sub {Filter} |
		(sub match: region)
			ifTrue: [^true]].
	^false!
*/
}

/**
 * return the simplest filter for looking at the children
 */
public Filter pass(Joint parent) {
throw new UnsupportedOperationException();/*
udanax-top.st:67409:OrFilter methodsFor: 'filtering'!
{Filter} pass: parent {Joint}
	"return the simplest filter for looking at the children"
	| result {XnRegion} |
	result _ Filter closedFilter: self coordinateSpace.
	self subFilters stepper forEach: [ :sub {Filter} |
		result _ result unionWith: (sub pass: parent)].
	^result cast: Filter!
*/
}

public ImmuSet subFilters() {
throw new UnsupportedOperationException();/*
udanax-top.st:67417:OrFilter methodsFor: 'filtering'!
{ImmuSet of: Filter} subFilters
	^mySubFilters!
*/
}

/**
 * return self or other if one is clearly a subset of the other, else NULL
 */
public XnRegion fetchSpecialSubset(XnRegion other) {
throw new UnsupportedOperationException();/*
udanax-top.st:67422:OrFilter methodsFor: 'protected: protected operations'!
{XnRegion} fetchSpecialSubset: other {XnRegion}
	"return self or other if one is clearly a subset of the other, else NULL"
	| filter {Filter} defaultRegion {XnRegion} |
	filter _ other cast: Filter.
	defaultRegion _ self.
	self subFilters stepper forEach: [ :subfilter {Filter} | 
		| a {XnRegion} b {XnRegion} |
		((a _ subfilter fetchSpecialSubset: filter) basicCast: Heaper star) == other ifTrue: [^other].
		((b _ filter fetchSpecialSubset: subfilter) basicCast: Heaper star) == other ifTrue: [^other].
		((a basicCast: Heaper star) == other or: [(b basicCast: Heaper star) == other]) ifFalse: [defaultRegion _ NULL]].
	^defaultRegion!
*/
}

public Stepper intersectedFilters() {
throw new UnsupportedOperationException();/*
udanax-top.st:67436:OrFilter methodsFor: 'enumerating'!
{Stepper of: Filter} intersectedFilters
	^Stepper itemStepper: self!
*/
}

public Stepper unionedFilters() {
throw new UnsupportedOperationException();/*
udanax-top.st:67440:OrFilter methodsFor: 'enumerating'!
{Stepper of: Filter} unionedFilters
	^mySubFilters stepper!
*/
}

public XnRegion baseRegion() {
throw new UnsupportedOperationException();/*
udanax-top.st:67446:OrFilter methodsFor: 'accessing'!
{XnRegion} baseRegion
	Heaper BLAST: #NotSimpleEnough.
	^NULL!
*/
}

public XnRegion relevantRegion() {
throw new UnsupportedOperationException();/*
udanax-top.st:67451:OrFilter methodsFor: 'accessing'!
{XnRegion} relevantRegion
	| result {XnRegion} |
	result := self filterSpace baseSpace emptyRegion.
	mySubFilters stepper forEach: [ :sub {Filter} |
		result := result unionWith: sub relevantRegion].
	^result!
*/
}

public  OrFilter(Rcvr receiver) {
	super(receiver);

throw new UnsupportedOperationException();/*
udanax-top.st:67461:OrFilter methodsFor: 'generated:'!
create.Rcvr: receiver {Rcvr}
	super create.Rcvr: receiver.
	mySubFilters _ receiver receiveHeaper.!
*/
}

public void sendSelfTo(Xmtr xmtr) {
throw new UnsupportedOperationException();/*
udanax-top.st:67465:OrFilter methodsFor: 'generated:'!
{void} sendSelfTo: xmtr {Xmtr}
	super sendSelfTo: xmtr.
	xmtr sendHeaper: mySubFilters.!
*/
}
}
