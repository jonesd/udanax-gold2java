/*
 * Abora-Gold
 * Part of the Abora hypertext project: http://www.abora.org
 * Copyright 2003 David G Jones
 * 
 * Translated from Udanax-Gold source code: http://www.udanax.com
 * Copyright 1979-1999 Udanax.com. All rights reserved
 */
package org.abora.gold.filter;

import java.io.PrintWriter;
import org.abora.gold.collection.steppers.Stepper;
import org.abora.gold.collection.tables.Pair;
import org.abora.gold.filter.Filter;
import org.abora.gold.filter.FilterSpace;
import org.abora.gold.filter.Joint;
import org.abora.gold.spaces.basic.XnRegion;
import org.abora.gold.xcvr.Rcvr;
import org.abora.gold.xcvr.Xmtr;
import org.abora.gold.xpp.basic.Heaper;


public class SupersetFilter extends Filter {
	protected XnRegion myRegion;
/*
udanax-top.st:67597:
Filter subclass: #SupersetFilter
	instanceVariableNames: 'myRegion {XnRegion}'
	classVariableNames: ''
	poolDictionaries: ''
	category: 'Xanadu-Filter'!
*/
/*
udanax-top.st:67601:
(SupersetFilter getOrMakeCxxClassDescription)
	attributes: ((Set new) add: #CONCRETE; add: #NOT.A.TYPE; add: #COPY; yourself)!
*/

/**
 * tell whether a region passes this filter
 */
public boolean match(XnRegion region) {
throw new UnsupportedOperationException();/*
udanax-top.st:67606:SupersetFilter methodsFor: 'filtering'!
{BooleanVar} match: region {XnRegion}
	"tell whether a region passes this filter"
	^myRegion isSubsetOf: region!
*/
}

/**
 * return the simplest filter for looking at the children
 */
public Filter pass(Joint parent) {
throw new UnsupportedOperationException();/*
udanax-top.st:67610:SupersetFilter methodsFor: 'filtering'!
{Filter} pass: parent {Joint}
	"return the simplest filter for looking at the children"
	(myRegion isSubsetOf: parent intersected) ifTrue:
		[^Filter openFilter: self coordinateSpace].
	(myRegion isSubsetOf: parent unioned) ifFalse:
		[^Filter closedFilter: self coordinateSpace].
	^self!
*/
}

public XnRegion region() {
throw new UnsupportedOperationException();/*
udanax-top.st:67618:SupersetFilter methodsFor: 'filtering'!
{XnRegion} region
	^myRegion!
*/
}

public XnRegion complement() {
throw new UnsupportedOperationException();/*
udanax-top.st:67623:SupersetFilter methodsFor: 'operations'!
{XnRegion} complement
	^Filter notSupersetFilter: self coordinateSpace with: myRegion!
*/
}

public int actualHashForEqual() {
throw new UnsupportedOperationException();/*
udanax-top.st:67629:SupersetFilter methodsFor: 'testing'!
{UInt32} actualHashForEqual
	^(self coordinateSpace hashForEqual bitXor: myRegion hashForEqual)
		bitXor: #cat.U.SupersetFilter hashForEqual!
*/
}

public boolean isAllFilter() {
throw new UnsupportedOperationException();/*
udanax-top.st:67633:SupersetFilter methodsFor: 'testing'!
{BooleanVar} isAllFilter
	^true!
*/
}

public boolean isAnyFilter() {
throw new UnsupportedOperationException();/*
udanax-top.st:67637:SupersetFilter methodsFor: 'testing'!
{BooleanVar} isAnyFilter
	
	^false!
*/
}

public boolean isEmpty() {
throw new UnsupportedOperationException();/*
udanax-top.st:67641:SupersetFilter methodsFor: 'testing'!
{BooleanVar} isEmpty
	^false!
*/
}

public boolean isEqual(Heaper other) {
throw new UnsupportedOperationException();/*
udanax-top.st:67644:SupersetFilter methodsFor: 'testing'!
{BooleanVar} isEqual: other {Heaper}
	other
		cast: SupersetFilter into: [:ssf |
			^ssf region isEqual: myRegion]
		others: [^false].
	^false "fodder"!
*/
}

public boolean isFull() {
throw new UnsupportedOperationException();/*
udanax-top.st:67652:SupersetFilter methodsFor: 'testing'!
{BooleanVar} isFull	
	^false!
*/
}

public XnRegion fetchSpecialUnion(XnRegion other) {
throw new UnsupportedOperationException();/*
udanax-top.st:67658:SupersetFilter methodsFor: 'protected: protected operations'!
{XnRegion} fetchSpecialUnion: other {XnRegion unused}
	^NULL!
*/
}

public  SupersetFilter(FilterSpace cs, XnRegion region) {
	super(cs);

throw new UnsupportedOperationException();/*
udanax-top.st:67663:SupersetFilter methodsFor: 'creation'!
create: cs {FilterSpace} with: region {XnRegion}
	super create: cs.
	myRegion _ region!
*/
}

public void printOn(PrintWriter oo) {
throw new UnsupportedOperationException();/*
udanax-top.st:67669:SupersetFilter methodsFor: 'printing'!
{void} printOn: oo {ostream reference}
	oo << self getCategory name << '(' << myRegion << ')'!
*/
}

/**
 * return NULL, or the pair of canonical filters (left == new1 | self, right == new2 | other)
 */
public Pair fetchCanonicalUnion(Filter other) {
throw new UnsupportedOperationException();/*
udanax-top.st:67674:SupersetFilter methodsFor: 'protected operations'!
{Pair of: Filter} fetchCanonicalUnion: other {Filter}
	"return NULL, or the pair of canonical filters (left == new1 | self, right == new2 | other)"
	
	other
		cast: NotSubsetFilter into: [:nsf |
			| others {XnRegion} |
			others _ nsf region.
			(myRegion isSubsetOf: others)
				ifFalse: [^Pair make: (Filter supersetFilter: self coordinateSpace
						with: (myRegion intersect: nsf region))
					with: other]]
		others: [].
	^NULL!
*/
}

public XnRegion fetchSpecialIntersect(XnRegion other) {
throw new UnsupportedOperationException();/*
udanax-top.st:67688:SupersetFilter methodsFor: 'protected operations'!
{XnRegion} fetchSpecialIntersect: other {XnRegion}
	other
		cast: SubsetFilter into: [:subF |
			(myRegion isSubsetOf: subF region)
				ifFalse: [^Filter closedFilter: self coordinateSpace]]
		cast: SupersetFilter into: [:superF |
			^Filter supersetFilter: self coordinateSpace
				with: (myRegion unionWith: superF region)]
		others: [].
	^NULL!
*/
}

public XnRegion fetchSpecialSubset(XnRegion other) {
throw new UnsupportedOperationException();/*
udanax-top.st:67700:SupersetFilter methodsFor: 'protected operations'!
{XnRegion} fetchSpecialSubset: other {XnRegion}
	other
		cast: NotSubsetFilter  into: [:nSubF |
			(myRegion isSubsetOf: nSubF region)
				ifFalse: [^self]]
		cast: SupersetFilter into: [:superF |
			| others {XnRegion} |
			others _ superF region.
			(myRegion isSubsetOf: others) ifTrue: [^other].
			(others isSubsetOf: myRegion) ifTrue: [^self]]
		others: [].
	^NULL!
*/
}

public Stepper intersectedFilters() {
throw new UnsupportedOperationException();/*
udanax-top.st:67716:SupersetFilter methodsFor: 'enumerating'!
{Stepper of: Filter} intersectedFilters
	^Stepper itemStepper: self!
*/
}

public Stepper unionedFilters() {
throw new UnsupportedOperationException();/*
udanax-top.st:67720:SupersetFilter methodsFor: 'enumerating'!
{Stepper of: Filter} unionedFilters
	^Stepper itemStepper: self!
*/
}

public XnRegion baseRegion() {
throw new UnsupportedOperationException();/*
udanax-top.st:67726:SupersetFilter methodsFor: 'accessing'!
{XnRegion} baseRegion
	^myRegion!
*/
}

public XnRegion relevantRegion() {
throw new UnsupportedOperationException();/*
udanax-top.st:67730:SupersetFilter methodsFor: 'accessing'!
{XnRegion} relevantRegion
	^myRegion!
*/
}

public  SupersetFilter(Rcvr receiver) {
	super(receiver);

throw new UnsupportedOperationException();/*
udanax-top.st:67736:SupersetFilter methodsFor: 'generated:'!
create.Rcvr: receiver {Rcvr}
	super create.Rcvr: receiver.
	myRegion _ receiver receiveHeaper.!
*/
}

public void sendSelfTo(Xmtr xmtr) {
throw new UnsupportedOperationException();/*
udanax-top.st:67740:SupersetFilter methodsFor: 'generated:'!
{void} sendSelfTo: xmtr {Xmtr}
	super sendSelfTo: xmtr.
	xmtr sendHeaper: myRegion.!
*/
}
}
