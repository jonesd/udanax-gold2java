/*
 * Abora-Gold
 * Part of the Abora hypertext project: http://www.abora.org
 * Copyright 2003 David G Jones
 * 
 * Translated from Udanax-Gold source code: http://www.udanax.com
 * Copyright 1979-1999 Udanax.com. All rights reserved
 */
package org.abora.gold.filter;

import java.io.PrintWriter;
import org.abora.gold.collection.steppers.Stepper;
import org.abora.gold.filter.Filter;
import org.abora.gold.filter.FilterSpace;
import org.abora.gold.filter.Joint;
import org.abora.gold.spaces.basic.CoordinateSpace;
import org.abora.gold.spaces.basic.XnRegion;
import org.abora.gold.xcvr.Rcvr;
import org.abora.gold.xcvr.Xmtr;
import org.abora.gold.xpp.basic.Heaper;


public class OpenFilter extends Filter {
/*
udanax-top.st:67226:
Filter subclass: #OpenFilter
	instanceVariableNames: ''
	classVariableNames: ''
	poolDictionaries: ''
	category: 'Xanadu-Filter'!
*/
/*
udanax-top.st:67230:
(OpenFilter getOrMakeCxxClassDescription)
	attributes: ((Set new) add: #CONCRETE; add: #NOT.A.TYPE; add: #COPY; yourself)!
*/
/*
udanax-top.st:67330:
OpenFilter class
	instanceVariableNames: ''!
*/
/*
udanax-top.st:67333:
(OpenFilter getOrMakeCxxClassDescription)
	attributes: ((Set new) add: #CONCRETE; add: #NOT.A.TYPE; add: #COPY; yourself)!
*/

public XnRegion complement() {
throw new UnsupportedOperationException();/*
udanax-top.st:67235:OpenFilter methodsFor: 'operations'!
{XnRegion} complement
	^Filter closedFilter: self coordinateSpace!
*/
}

public XnRegion intersect(XnRegion other) {
throw new UnsupportedOperationException();/*
udanax-top.st:67239:OpenFilter methodsFor: 'operations'!
{XnRegion} intersect: other {XnRegion}
	^other!
*/
}

public XnRegion minus(XnRegion other) {
throw new UnsupportedOperationException();/*
udanax-top.st:67242:OpenFilter methodsFor: 'operations'!
{XnRegion} minus: other {XnRegion}
	^other complement!
*/
}

public XnRegion unionWith(XnRegion other) {
throw new UnsupportedOperationException();/*
udanax-top.st:67245:OpenFilter methodsFor: 'operations'!
{XnRegion} unionWith: other {XnRegion unused}
	^self!
*/
}

/**
 * tell whether a region passes this filter
 */
public boolean match(XnRegion region) {
throw new UnsupportedOperationException();/*
udanax-top.st:67250:OpenFilter methodsFor: 'filtering'!
{BooleanVar} match: region {XnRegion unused}
	"tell whether a region passes this filter"
	^true!
*/
}

/**
 * return the simplest filter for looking at the children
 */
public Filter pass(Joint parent) {
throw new UnsupportedOperationException();/*
udanax-top.st:67254:OpenFilter methodsFor: 'filtering'!
{Filter} pass: parent {Joint unused}
	"return the simplest filter for looking at the children"
	^self!
*/
}

public int actualHashForEqual() {
throw new UnsupportedOperationException();/*
udanax-top.st:67260:OpenFilter methodsFor: 'testing'!
{UInt32} actualHashForEqual
	^self coordinateSpace hashForEqual bitXor: #cat.U.OpenFilter hashForEqual!
*/
}

public boolean isAllFilter() {
throw new UnsupportedOperationException();/*
udanax-top.st:67263:OpenFilter methodsFor: 'testing'!
{BooleanVar} isAllFilter
	^true!
*/
}

public boolean isAnyFilter() {
throw new UnsupportedOperationException();/*
udanax-top.st:67267:OpenFilter methodsFor: 'testing'!
{BooleanVar} isAnyFilter
	
	^false!
*/
}

public boolean isEmpty() {
throw new UnsupportedOperationException();/*
udanax-top.st:67271:OpenFilter methodsFor: 'testing'!
{BooleanVar} isEmpty
	^false!
*/
}

public boolean isEqual(Heaper other) {
throw new UnsupportedOperationException();/*
udanax-top.st:67274:OpenFilter methodsFor: 'testing'!
{BooleanVar} isEqual: other {Heaper}
	other
		cast: OpenFilter into: [:of |
			^of coordinateSpace isEqual: self coordinateSpace]
		others: [^false].
	^false "fodder"!
*/
}

public boolean isFull() {
throw new UnsupportedOperationException();/*
udanax-top.st:67282:OpenFilter methodsFor: 'testing'!
{BooleanVar} isFull	
	^true!
*/
}

public  OpenFilter(FilterSpace cs) {
	super(cs);
throw new UnsupportedOperationException();/*
udanax-top.st:67288:OpenFilter methodsFor: 'creation'!
create: cs {FilterSpace}
	super create: cs!
*/
}

public void printOn(PrintWriter oo) {
throw new UnsupportedOperationException();/*
udanax-top.st:67293:OpenFilter methodsFor: 'printing'!
{void} printOn: oo {ostream reference}
	oo << self getCategory name << '(' << self coordinateSpace << ')'!
*/
}

public XnRegion fetchSpecialSubset(XnRegion other) {
throw new UnsupportedOperationException();/*
udanax-top.st:67298:OpenFilter methodsFor: 'protected: protected operations'!
{XnRegion} fetchSpecialSubset: other {XnRegion}
	^other!
*/
}

public Stepper intersectedFilters() {
throw new UnsupportedOperationException();/*
udanax-top.st:67303:OpenFilter methodsFor: 'enumerating'!
{Stepper of: Filter} intersectedFilters
	^Stepper emptyStepper!
*/
}

public Stepper unionedFilters() {
throw new UnsupportedOperationException();/*
udanax-top.st:67307:OpenFilter methodsFor: 'enumerating'!
{Stepper of: Filter} unionedFilters
	^Stepper itemStepper: self!
*/
}

public XnRegion baseRegion() {
throw new UnsupportedOperationException();/*
udanax-top.st:67313:OpenFilter methodsFor: 'accessing'!
{XnRegion} baseRegion
	^(self coordinateSpace cast: FilterSpace) emptyRegion!
*/
}

public XnRegion relevantRegion() {
throw new UnsupportedOperationException();/*
udanax-top.st:67317:OpenFilter methodsFor: 'accessing'!
{XnRegion} relevantRegion
	^self filterSpace baseSpace emptyRegion!
*/
}

public  OpenFilter(Rcvr receiver) {
	super(receiver);

throw new UnsupportedOperationException();/*
udanax-top.st:67323:OpenFilter methodsFor: 'generated:'!
create.Rcvr: receiver {Rcvr}
	super create.Rcvr: receiver.!
*/
}

public void sendSelfTo(Xmtr xmtr) {
throw new UnsupportedOperationException();/*
udanax-top.st:67326:OpenFilter methodsFor: 'generated:'!
{void} sendSelfTo: xmtr {Xmtr}
	super sendSelfTo: xmtr.!
*/
}

public static Heaper make(CoordinateSpace space) {
throw new UnsupportedOperationException();/*
udanax-top.st:67338:OpenFilter class methodsFor: 'pseudo constructors'!
{Filter} make: space {CoordinateSpace}
	^self create: (space cast: FilterSpace)!
*/
}
}
