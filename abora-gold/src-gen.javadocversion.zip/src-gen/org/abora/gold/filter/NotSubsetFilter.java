/*
 * Abora-Gold
 * Part of the Abora hypertext project: http://www.abora.org
 * Copyright 2003 David G Jones
 * 
 * Translated from Udanax-Gold source code: http://www.udanax.com
 * Copyright 1979-1999 Udanax.com. All rights reserved
 */
package org.abora.gold.filter;

import java.io.PrintWriter;
import org.abora.gold.collection.steppers.Stepper;
import org.abora.gold.filter.Filter;
import org.abora.gold.filter.FilterSpace;
import org.abora.gold.filter.Joint;
import org.abora.gold.spaces.basic.XnRegion;
import org.abora.gold.xcvr.Rcvr;
import org.abora.gold.xcvr.Xmtr;
import org.abora.gold.xpp.basic.Heaper;


public class NotSubsetFilter extends Filter {
	protected XnRegion myRegion;
/*
udanax-top.st:66910:
Filter subclass: #NotSubsetFilter
	instanceVariableNames: 'myRegion {XnRegion}'
	classVariableNames: ''
	poolDictionaries: ''
	category: 'Xanadu-Filter'!
*/
/*
udanax-top.st:66914:
(NotSubsetFilter getOrMakeCxxClassDescription)
	attributes: ((Set new) add: #CONCRETE; add: #NOT.A.TYPE; add: #COPY; yourself)!
*/

/**
 * tell whether a region passes this filter
 */
public boolean match(XnRegion region) {
throw new UnsupportedOperationException();/*
udanax-top.st:66919:NotSubsetFilter methodsFor: 'filtering'!
{BooleanVar} match: region {XnRegion}
	"tell whether a region passes this filter"
	^(region isSubsetOf: myRegion) not!
*/
}

/**
 * return the simplest filter for looking at the children
 */
public Filter pass(Joint parent) {
throw new UnsupportedOperationException();/*
udanax-top.st:66923:NotSubsetFilter methodsFor: 'filtering'!
{Filter} pass: parent {Joint}
	"return the simplest filter for looking at the children"
	(parent intersected isSubsetOf: myRegion)
		ifFalse: [^Filter openFilter: self coordinateSpace].
	(parent unioned isSubsetOf: myRegion)
		ifTrue: [^Filter closedFilter: self coordinateSpace].
	^self!
*/
}

public XnRegion region() {
throw new UnsupportedOperationException();/*
udanax-top.st:66931:NotSubsetFilter methodsFor: 'filtering'!
{XnRegion} region
	^myRegion!
*/
}

public int actualHashForEqual() {
throw new UnsupportedOperationException();/*
udanax-top.st:66936:NotSubsetFilter methodsFor: 'testing'!
{UInt32} actualHashForEqual
	^(self coordinateSpace hashForEqual bitXor: myRegion hashForEqual)
		bitXor: #cat.U.NotSubsetFilter hashForEqual!
*/
}

public boolean isAllFilter() {
throw new UnsupportedOperationException();/*
udanax-top.st:66940:NotSubsetFilter methodsFor: 'testing'!
{BooleanVar} isAllFilter
	^false!
*/
}

public boolean isAnyFilter() {
throw new UnsupportedOperationException();/*
udanax-top.st:66944:NotSubsetFilter methodsFor: 'testing'!
{BooleanVar} isAnyFilter
	
	^true!
*/
}

public boolean isEmpty() {
throw new UnsupportedOperationException();/*
udanax-top.st:66948:NotSubsetFilter methodsFor: 'testing'!
{BooleanVar} isEmpty
	^false!
*/
}

public boolean isEqual(Heaper other) {
throw new UnsupportedOperationException();/*
udanax-top.st:66951:NotSubsetFilter methodsFor: 'testing'!
{BooleanVar} isEqual: other {Heaper}
	other
		cast: NotSubsetFilter into: [:nsf |
			^nsf region isEqual: myRegion]
		others: [^false].
	^false "fodder"!
*/
}

public boolean isFull() {
throw new UnsupportedOperationException();/*
udanax-top.st:66959:NotSubsetFilter methodsFor: 'testing'!
{BooleanVar} isFull	
	^false!
*/
}

public XnRegion complement() {
throw new UnsupportedOperationException();/*
udanax-top.st:66965:NotSubsetFilter methodsFor: 'operations'!
{XnRegion} complement
	^Filter subsetFilter: self coordinateSpace with: myRegion!
*/
}

public  NotSubsetFilter(FilterSpace cs, XnRegion region) {
	super(cs);
throw new UnsupportedOperationException();/*
udanax-top.st:66971:NotSubsetFilter methodsFor: 'creation'!
create: cs {FilterSpace} with: region {XnRegion}
	super create: cs.
	myRegion _ region!
*/
}

public void printOn(PrintWriter oo) {
throw new UnsupportedOperationException();/*
udanax-top.st:66977:NotSubsetFilter methodsFor: 'printing'!
{void} printOn: oo {ostream reference}
	oo << 'IntersectionFilter(' << myRegion complement << ')'!
*/
}

public XnRegion fetchSpecialIntersect(XnRegion other) {
throw new UnsupportedOperationException();/*
udanax-top.st:66982:NotSubsetFilter methodsFor: 'protected operations'!
{XnRegion} fetchSpecialIntersect: other {XnRegion}
	other
		cast: SubsetFilter into: [:sf |
			(sf region isSubsetOf: myRegion)
				ifTrue: [^Filter closedFilter: self coordinateSpace]
				ifFalse: [^NULL]]
		others: [^NULL].
	^NULL "fodder"!
*/
}

public XnRegion fetchSpecialSubset(XnRegion other) {
throw new UnsupportedOperationException();/*
udanax-top.st:66992:NotSubsetFilter methodsFor: 'protected operations'!
{XnRegion} fetchSpecialSubset: other {XnRegion}
	other
		cast: NotSubsetFilter into: [:nsf |
			| others {XnRegion} |
			others _ nsf region.
			(others isSubsetOf: myRegion) ifTrue: [^self].
			(myRegion isSubsetOf: others) ifTrue: [^other]]
		others: [].
	^NULL!
*/
}

public XnRegion fetchSpecialUnion(XnRegion other) {
throw new UnsupportedOperationException();/*
udanax-top.st:67003:NotSubsetFilter methodsFor: 'protected operations'!
{XnRegion} fetchSpecialUnion: other {XnRegion}
	other
		cast: SubsetFilter into: [:sf |
			(myRegion isSubsetOf: sf region)
				ifTrue: [^Filter openFilter: self coordinateSpace]
				ifFalse: [^NULL]]
		cast: NotSubsetFilter into: [:nsf |
			^Filter notSubsetFilter: self coordinateSpace
				with: (myRegion intersect: nsf region)]
		others: [^NULL].
	^NULL "fodder"!
*/
}

public Stepper intersectedFilters() {
throw new UnsupportedOperationException();/*
udanax-top.st:67018:NotSubsetFilter methodsFor: 'enumerating'!
{Stepper of: Filter} intersectedFilters
	^Stepper itemStepper: self!
*/
}

public Stepper unionedFilters() {
throw new UnsupportedOperationException();/*
udanax-top.st:67022:NotSubsetFilter methodsFor: 'enumerating'!
{Stepper of: Filter} unionedFilters
	^Stepper itemStepper: self!
*/
}

public XnRegion baseRegion() {
throw new UnsupportedOperationException();/*
udanax-top.st:67028:NotSubsetFilter methodsFor: 'accessing'!
{XnRegion} baseRegion
	^myRegion complement!
*/
}

public XnRegion relevantRegion() {
throw new UnsupportedOperationException();/*
udanax-top.st:67032:NotSubsetFilter methodsFor: 'accessing'!
{XnRegion} relevantRegion
	^myRegion complement!
*/
}

public  NotSubsetFilter(Rcvr receiver) {
	super(receiver);
throw new UnsupportedOperationException();/*
udanax-top.st:67038:NotSubsetFilter methodsFor: 'generated:'!
create.Rcvr: receiver {Rcvr}
	super create.Rcvr: receiver.
	myRegion _ receiver receiveHeaper.!
*/
}

public void sendSelfTo(Xmtr xmtr) {
throw new UnsupportedOperationException();/*
udanax-top.st:67042:NotSubsetFilter methodsFor: 'generated:'!
{void} sendSelfTo: xmtr {Xmtr}
	super sendSelfTo: xmtr.
	xmtr sendHeaper: myRegion.!
*/
}
}
