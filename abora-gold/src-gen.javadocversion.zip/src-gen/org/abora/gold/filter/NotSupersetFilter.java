/*
 * Abora-Gold
 * Part of the Abora hypertext project: http://www.abora.org
 * Copyright 2003 David G Jones
 * 
 * Translated from Udanax-Gold source code: http://www.udanax.com
 * Copyright 1979-1999 Udanax.com. All rights reserved
 */
package org.abora.gold.filter;

import java.io.PrintWriter;
import org.abora.gold.collection.steppers.Stepper;
import org.abora.gold.collection.tables.Pair;
import org.abora.gold.filter.Filter;
import org.abora.gold.filter.FilterSpace;
import org.abora.gold.filter.Joint;
import org.abora.gold.spaces.basic.XnRegion;
import org.abora.gold.xcvr.Rcvr;
import org.abora.gold.xcvr.Xmtr;
import org.abora.gold.xpp.basic.Heaper;


public class NotSupersetFilter extends Filter {
	protected XnRegion myRegion;
/*
udanax-top.st:67046:
Filter subclass: #NotSupersetFilter
	instanceVariableNames: 'myRegion {XnRegion}'
	classVariableNames: ''
	poolDictionaries: ''
	category: 'Xanadu-Filter'!
*/
/*
udanax-top.st:67050:
(NotSupersetFilter getOrMakeCxxClassDescription)
	attributes: ((Set new) add: #CONCRETE; add: #NOT.A.TYPE; add: #COPY; yourself)!
*/

/**
 * tell whether a region passes this filter
 */
public boolean match(XnRegion region) {
throw new UnsupportedOperationException();/*
udanax-top.st:67055:NotSupersetFilter methodsFor: 'filtering'!
{BooleanVar} match: region {XnRegion}
	"tell whether a region passes this filter"
	^(myRegion isSubsetOf: region) not!
*/
}

/**
 * return the simplest filter for looking at the children
 */
public Filter pass(Joint parent) {
throw new UnsupportedOperationException();/*
udanax-top.st:67059:NotSupersetFilter methodsFor: 'filtering'!
{Filter} pass: parent {Joint}
	"return the simplest filter for looking at the children"
	(myRegion isSubsetOf: parent unioned) ifFalse:
		[^Filter openFilter: self coordinateSpace].
	(myRegion isSubsetOf: parent intersected) ifTrue:
		[^Filter closedFilter: self coordinateSpace].
	^self!
*/
}

public XnRegion region() {
throw new UnsupportedOperationException();/*
udanax-top.st:67067:NotSupersetFilter methodsFor: 'filtering'!
{XnRegion} region
	^myRegion!
*/
}

public XnRegion complement() {
throw new UnsupportedOperationException();/*
udanax-top.st:67072:NotSupersetFilter methodsFor: 'operations'!
{XnRegion} complement
	^Filter supersetFilter: self coordinateSpace with: myRegion!
*/
}

public int actualHashForEqual() {
throw new UnsupportedOperationException();/*
udanax-top.st:67078:NotSupersetFilter methodsFor: 'testing'!
{UInt32} actualHashForEqual
	^(self coordinateSpace hashForEqual bitXor: myRegion hashForEqual)
		bitXor: #cat.U.NotSupersetFilter hashForEqual!
*/
}

public boolean isAllFilter() {
throw new UnsupportedOperationException();/*
udanax-top.st:67082:NotSupersetFilter methodsFor: 'testing'!
{BooleanVar} isAllFilter
	^false!
*/
}

public boolean isAnyFilter() {
throw new UnsupportedOperationException();/*
udanax-top.st:67086:NotSupersetFilter methodsFor: 'testing'!
{BooleanVar} isAnyFilter
	
	^false!
*/
}

public boolean isEmpty() {
throw new UnsupportedOperationException();/*
udanax-top.st:67090:NotSupersetFilter methodsFor: 'testing'!
{BooleanVar} isEmpty
	^false!
*/
}

public boolean isEqual(Heaper other) {
throw new UnsupportedOperationException();/*
udanax-top.st:67093:NotSupersetFilter methodsFor: 'testing'!
{BooleanVar} isEqual: other {Heaper}
	other
		cast: NotSupersetFilter into: [:nsf |
			^nsf region isEqual: myRegion]
		others: [^false].
	^false "fodder"!
*/
}

public boolean isFull() {
throw new UnsupportedOperationException();/*
udanax-top.st:67101:NotSupersetFilter methodsFor: 'testing'!
{BooleanVar} isFull	
	^false!
*/
}

public  NotSupersetFilter(FilterSpace cs, XnRegion region) {
	super(cs);
throw new UnsupportedOperationException();/*
udanax-top.st:67107:NotSupersetFilter methodsFor: 'creation'!
create: cs {FilterSpace} with: region {XnRegion}
	super create: cs.
	myRegion _ region!
*/
}

public void printOn(PrintWriter oo) {
throw new UnsupportedOperationException();/*
udanax-top.st:67113:NotSupersetFilter methodsFor: 'printing'!
{void} printOn: oo {ostream reference}
	oo << self getCategory name << '(' << myRegion << ')'!
*/
}

/**
 * return NULL, or the pair of canonical filters (left == new1 | self, right == new2 | other)
 */
public Pair fetchCanonicalIntersect(Filter other) {
throw new UnsupportedOperationException();/*
udanax-top.st:67118:NotSupersetFilter methodsFor: 'protected operations'!
{Pair of: Filter} fetchCanonicalIntersect: other {Filter}
	"return NULL, or the pair of canonical filters (left == new1 | self, right == new2 | other)"
	
	other
		cast: SubsetFilter into: [:subF |
			| others {XnRegion} |
			others _ subF region.
			(myRegion isSubsetOf: others)
				ifTrue: [^NULL]
				ifFalse: [^Pair make: (Filter notSupersetFilter: self coordinateSpace
						with: (myRegion intersect: others))
					with: other]]
		cast: SupersetFilter into: [:superF |
			| others {XnRegion} |
			others _ superF region.
			(myRegion intersects: others)
				ifTrue: [^Pair make: (Filter notSupersetFilter: self coordinateSpace
						with: (myRegion minus: superF region))
					with: other]
				ifFalse: [^NULL]]
		others: [^NULL].
	^NULL "fodder"!
*/
}

/**
 * return NULL, or the pair of canonical filters (left == new1 | self, right == new2 | other)
 */
public Pair fetchCanonicalUnion(Filter other) {
throw new UnsupportedOperationException();/*
udanax-top.st:67141:NotSupersetFilter methodsFor: 'protected operations'!
{Pair of: Filter} fetchCanonicalUnion: other {Filter}
	"return NULL, or the pair of canonical filters (left == new1 | self, right == new2 | other)"
	
	other
		cast: SupersetFilter into: [:sf |
			| others {XnRegion} |
			others _ sf region.
			(myRegion intersects: others)
				ifTrue: [^Pair make: self
					with: (Filter supersetFilter: self coordinateSpace
						with: (sf region minus: myRegion))]
				ifFalse: [^NULL]]
		others: [^NULL].
	^NULL "fodder"!
*/
}

public XnRegion fetchSpecialIntersect(XnRegion other) {
throw new UnsupportedOperationException();/*
udanax-top.st:67156:NotSupersetFilter methodsFor: 'protected operations'!
{XnRegion} fetchSpecialIntersect: other {XnRegion}
	other
		cast: SupersetFilter into: [:sf |
			(myRegion isSubsetOf: sf region)
				ifTrue: [^Filter closedFilter: self coordinateSpace]
				ifFalse: [^NULL]]
		others: [^NULL].
	^NULL "fodder"!
*/
}

public XnRegion fetchSpecialSubset(XnRegion other) {
throw new UnsupportedOperationException();/*
udanax-top.st:67166:NotSupersetFilter methodsFor: 'protected operations'!
{XnRegion} fetchSpecialSubset: other {XnRegion}
	other
		cast: SubsetFilter into: [:subF |
			(myRegion isSubsetOf: subF region)
				ifFalse: [^other]]
		cast: NotSupersetFilter into: [:nSuperF |
			| others {XnRegion} |
			others _ nSuperF region.
			(myRegion isSubsetOf: others) ifTrue: [^self].
			(others isSubsetOf: myRegion) ifTrue: [^other]]
		others: [].
	^NULL!
*/
}

public XnRegion fetchSpecialUnion(XnRegion other) {
throw new UnsupportedOperationException();/*
udanax-top.st:67180:NotSupersetFilter methodsFor: 'protected operations'!
{XnRegion} fetchSpecialUnion: other {XnRegion}
	other
		cast: NotSubsetFilter into: [:nSubF |
			(myRegion isSubsetOf: nSubF region)
				ifFalse: [^Filter openFilter: self coordinateSpace]]
		cast: SupersetFilter into: [:superF |
			(superF region isSubsetOf: myRegion)
				ifTrue: [^Filter openFilter: self coordinateSpace]]
		cast: NotSupersetFilter into: [:nSuperF |
			^Filter notSupersetFilter: self coordinateSpace
				with: (myRegion unionWith: nSuperF region)]
		others: [].
	^NULL!
*/
}

public Stepper intersectedFilters() {
throw new UnsupportedOperationException();/*
udanax-top.st:67197:NotSupersetFilter methodsFor: 'enumerating'!
{Stepper of: Filter} intersectedFilters
	^Stepper itemStepper: self!
*/
}

public Stepper unionedFilters() {
throw new UnsupportedOperationException();/*
udanax-top.st:67201:NotSupersetFilter methodsFor: 'enumerating'!
{Stepper of: Filter} unionedFilters
	^Stepper itemStepper: self!
*/
}

public XnRegion baseRegion() {
throw new UnsupportedOperationException();/*
udanax-top.st:67207:NotSupersetFilter methodsFor: 'accessing'!
{XnRegion} baseRegion
	Heaper BLAST: #NotSimpleEnough.
	^NULL!
*/
}

public XnRegion relevantRegion() {
throw new UnsupportedOperationException();/*
udanax-top.st:67212:NotSupersetFilter methodsFor: 'accessing'!
{XnRegion} relevantRegion
	^myRegion!
*/
}

public  NotSupersetFilter(Rcvr receiver) {
	super(receiver);

throw new UnsupportedOperationException();/*
udanax-top.st:67218:NotSupersetFilter methodsFor: 'generated:'!
create.Rcvr: receiver {Rcvr}
	super create.Rcvr: receiver.
	myRegion _ receiver receiveHeaper.!
*/
}

public void sendSelfTo(Xmtr xmtr) {
throw new UnsupportedOperationException();/*
udanax-top.st:67222:NotSupersetFilter methodsFor: 'generated:'!
{void} sendSelfTo: xmtr {Xmtr}
	super sendSelfTo: xmtr.
	xmtr sendHeaper: myRegion.!
*/
}
}
