/*
 * Abora-Gold
 * Part of the Abora hypertext project: http://www.abora.org
 * Copyright 2003 David G Jones
 * 
 * Translated from Udanax-Gold source code: http://www.udanax.com
 * Copyright 1979-1999 Udanax.com. All rights reserved
 */
package org.abora.gold.filter;

import org.abora.gold.spaces.basic.CoordinateSpace;
import org.abora.gold.spaces.basic.Position;
import org.abora.gold.spaces.basic.XnRegion;
import org.abora.gold.xcvr.Rcvr;
import org.abora.gold.xcvr.Xmtr;
import org.abora.gold.xpp.basic.Heaper;


/**
 * Encapsulates a Region in the baseSpace into a Position so that it can be treated as one
 * for polymorphism. See Filter.
 */
public class FilterPosition extends Position {
	protected XnRegion myRegion;
/*
udanax-top.st:31529:
Position subclass: #FilterPosition
	instanceVariableNames: 'myRegion {XnRegion}'
	classVariableNames: ''
	poolDictionaries: ''
	category: 'Xanadu-filter'!
*/
/*
udanax-top.st:31533:
FilterPosition comment:
'Encapsulates a Region in the baseSpace into a Position so that it can be treated as one for polymorphism. See Filter.'!
*/
/*
udanax-top.st:31535:
(FilterPosition getOrMakeCxxClassDescription)
	attributes: ((Set new) add: #CONCRETE; add: #ON.CLIENT; add: #COPY; yourself)!
*/
/*
udanax-top.st:31592:
FilterPosition class
	instanceVariableNames: ''!
*/
/*
udanax-top.st:31595:
(FilterPosition getOrMakeCxxClassDescription)
	attributes: ((Set new) add: #CONCRETE; add: #ON.CLIENT; add: #COPY; yourself)!
*/

public int actualHashForEqual() {
throw new UnsupportedOperationException();/*
udanax-top.st:31540:FilterPosition methodsFor: 'testing'!
{UInt32} actualHashForEqual
	^myRegion hashForEqual + 1!
*/
}

public boolean isEqual(Heaper other) {
throw new UnsupportedOperationException();/*
udanax-top.st:31544:FilterPosition methodsFor: 'testing'!
{BooleanVar} isEqual: other {Heaper} 
	other 
		cast: FilterPosition into: [:rap |
			^rap baseRegion isEqual: myRegion]
		others: [^false].
	^false "fodder"!
*/
}

public XnRegion asRegion() {
throw new UnsupportedOperationException();/*
udanax-top.st:31554:FilterPosition methodsFor: 'accessing'!
{XnRegion} asRegion
	^(Filter subsetFilter: self coordinateSpace
			with: myRegion)
		intersect: (Filter supersetFilter: self coordinateSpace
			with: myRegion)!
*/
}

/**
 * Essential. The region in the base space which I represent.
 */
public XnRegion baseRegion() {
throw new UnsupportedOperationException();/*
udanax-top.st:31561:FilterPosition methodsFor: 'accessing'!
{XnRegion CLIENT INLINE} baseRegion
	"Essential. The region in the base space which I represent."
	
	^myRegion!
*/
}

public CoordinateSpace coordinateSpace() {
throw new UnsupportedOperationException();/*
udanax-top.st:31566:FilterPosition methodsFor: 'accessing'!
{CoordinateSpace} coordinateSpace
	^FilterSpace make: myRegion coordinateSpace!
*/
}

public  FilterPosition(XnRegion region) {
throw new UnsupportedOperationException();/*
udanax-top.st:31571:FilterPosition methodsFor: 'instance creation'!
create: region {XnRegion}
	super create.
	myRegion _ region.!
*/
}

public XnRegion region() {
throw new UnsupportedOperationException();/*
udanax-top.st:31577:FilterPosition methodsFor: 'smalltalk: passe'!
{XnRegion} region
	self passe!
*/
}

public  FilterPosition(Rcvr receiver) {
throw new UnsupportedOperationException();/*
udanax-top.st:31583:FilterPosition methodsFor: 'generated:'!
create.Rcvr: receiver {Rcvr}
	super create.Rcvr: receiver.
	myRegion _ receiver receiveHeaper.!
*/
}

public void sendSelfTo(Xmtr xmtr) {
throw new UnsupportedOperationException();/*
udanax-top.st:31587:FilterPosition methodsFor: 'generated:'!
{void} sendSelfTo: xmtr {Xmtr}
	super sendSelfTo: xmtr.
	xmtr sendHeaper: myRegion.!
*/
}

/**
 * A position containing the given region.
 */
public static Heaper make(XnRegion region) {
throw new UnsupportedOperationException();/*
udanax-top.st:31600:FilterPosition class methodsFor: 'pseudo constructors'!
make: region {XnRegion}
	"A position containing the given region."
	
	^FilterPosition create: region!
*/
}

/**
 * {XnRegion CLIENT} baseRegion
 */
public static void info() {
throw new UnsupportedOperationException();/*
udanax-top.st:31607:FilterPosition class methodsFor: 'smalltalk: system'!
info.stProtocol
"{XnRegion CLIENT} baseRegion
"!
*/
}
}
