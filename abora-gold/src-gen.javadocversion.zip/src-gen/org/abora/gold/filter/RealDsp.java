/*
 * Abora-Gold
 * Part of the Abora hypertext project: http://www.abora.org
 * Copyright 2003 David G Jones
 * 
 * Translated from Udanax-Gold source code: http://www.udanax.com
 * Copyright 1979-1999 Udanax.com. All rights reserved
 */
package org.abora.gold.filter;

import org.abora.gold.spaces.basic.CoordinateSpace;
import org.abora.gold.spaces.basic.Dsp;
import org.abora.gold.spaces.unordered.IdentityDsp;
import org.abora.gold.xcvr.Rcvr;
import org.abora.gold.xcvr.Xmtr;
import org.abora.gold.xpp.basic.Heaper;


public class RealDsp extends IdentityDsp {
/*
udanax-top.st:29730:
IdentityDsp subclass: #RealDsp
	instanceVariableNames: ''
	classVariableNames: ''
	poolDictionaries: ''
	category: 'Xanadu-Filter'!
*/
/*
udanax-top.st:29734:
(RealDsp getOrMakeCxxClassDescription)
	attributes: ((Set new) add: #CONCRETE; add: #COPY; add: #NOT.A.TYPE; yourself)!
*/
/*
udanax-top.st:29752:
RealDsp class
	instanceVariableNames: ''!
*/
/*
udanax-top.st:29755:
(RealDsp getOrMakeCxxClassDescription)
	attributes: ((Set new) add: #CONCRETE; add: #COPY; add: #NOT.A.TYPE; yourself)!
*/

public CoordinateSpace coordinateSpace() {
throw new UnsupportedOperationException();/*
udanax-top.st:29739:RealDsp methodsFor: 'deferred accessing'!
{CoordinateSpace} coordinateSpace
	^RealSpace make!
*/
}

public  RealDsp(Rcvr receiver) {
throw new UnsupportedOperationException();/*
udanax-top.st:29745:RealDsp methodsFor: 'generated:'!
create.Rcvr: receiver {Rcvr}
	super create.Rcvr: receiver.!
*/
}

public void sendSelfTo(Xmtr xmtr) {
throw new UnsupportedOperationException();/*
udanax-top.st:29748:RealDsp methodsFor: 'generated:'!
{void} sendSelfTo: xmtr {Xmtr}
	super sendSelfTo: xmtr.!
*/
}

public static Heaper make() {
throw new UnsupportedOperationException();/*
udanax-top.st:29760:RealDsp class methodsFor: 'creation'!
{Dsp} make
	
	^self create!
*/
}
}
