/*
 * Abora-Gold
 * Part of the Abora hypertext project: http://www.abora.org
 * Copyright 2003 David G Jones
 * 
 * Translated from Udanax-Gold source code: http://www.udanax.com
 * Copyright 1979-1999 Udanax.com. All rights reserved
 */
package org.abora.gold.filter;

import java.io.PrintWriter;
import org.abora.gold.collection.sets.ImmuSet;
import org.abora.gold.collection.steppers.Stepper;
import org.abora.gold.filter.Filter;
import org.abora.gold.filter.FilterSpace;
import org.abora.gold.filter.Joint;
import org.abora.gold.spaces.basic.XnRegion;
import org.abora.gold.xcvr.Rcvr;
import org.abora.gold.xcvr.Xmtr;
import org.abora.gold.xpp.basic.Heaper;


public class AndFilter extends Filter {
	protected ImmuSet mySubFilters;
/*
udanax-top.st:66642:
Filter subclass: #AndFilter
	instanceVariableNames: 'mySubFilters {ImmuSet of: Filter}'
	classVariableNames: ''
	poolDictionaries: ''
	category: 'Xanadu-Filter'!
*/
/*
udanax-top.st:66646:
(AndFilter getOrMakeCxxClassDescription)
	attributes: ((Set new) add: #CONCRETE; add: #NOT.A.TYPE; add: #COPY; yourself)!
*/
/*
udanax-top.st:66769:
AndFilter class
	instanceVariableNames: ''!
*/
/*
udanax-top.st:66772:
(AndFilter getOrMakeCxxClassDescription)
	attributes: ((Set new) add: #CONCRETE; add: #NOT.A.TYPE; add: #COPY; yourself)!
*/

public  AndFilter(FilterSpace cs, ImmuSet subs) {
	super(cs);
throw new UnsupportedOperationException();/*
udanax-top.st:66651:AndFilter methodsFor: 'creation'!
create: cs {FilterSpace} with: subs {ImmuSet of: Filter}
	super create: cs.
	mySubFilters _ subs!
*/
}

/**
 * tell whether a region passes this filter
 */
public boolean match(XnRegion region) {
throw new UnsupportedOperationException();/*
udanax-top.st:66657:AndFilter methodsFor: 'filtering'!
{BooleanVar} match: region {XnRegion}
	"tell whether a region passes this filter"
	self subFilters stepper forEach: [ :sub {Filter} |
		(sub match: region)
			ifFalse: [^false]].
	^true!
*/
}

/**
 * return the simplest filter for looking at the children
 */
public Filter pass(Joint parent) {
throw new UnsupportedOperationException();/*
udanax-top.st:66664:AndFilter methodsFor: 'filtering'!
{Filter} pass: parent {Joint}
	"return the simplest filter for looking at the children"
	| result {XnRegion} |
	result _ Filter openFilter: self coordinateSpace.
	self subFilters stepper forEach: [ :sub {Filter} |
		result _ result intersect: (sub pass: parent)].
	^result cast: Filter!
*/
}

public ImmuSet subFilters() {
throw new UnsupportedOperationException();/*
udanax-top.st:66672:AndFilter methodsFor: 'filtering'!
{ImmuSet of: Filter} subFilters
	^mySubFilters!
*/
}

public void printOn(PrintWriter oo) {
throw new UnsupportedOperationException();/*
udanax-top.st:66677:AndFilter methodsFor: 'printing'!
{void} printOn: oo {ostream reference}
	oo << self getCategory name.
	self subFilters printOnWithSimpleSyntax: oo with: '(' with: ' && ' with: ')'!
*/
}

public int actualHashForEqual() {
throw new UnsupportedOperationException();/*
udanax-top.st:66683:AndFilter methodsFor: 'testing'!
{UInt32} actualHashForEqual
	^(self coordinateSpace hashForEqual bitXor: mySubFilters hashForEqual)
		bitXor: #cat.U.AndFilter hashForEqual!
*/
}

public boolean isAllFilter() {
throw new UnsupportedOperationException();/*
udanax-top.st:66687:AndFilter methodsFor: 'testing'!
{BooleanVar} isAllFilter
	^false!
*/
}

public boolean isAnyFilter() {
throw new UnsupportedOperationException();/*
udanax-top.st:66691:AndFilter methodsFor: 'testing'!
{BooleanVar} isAnyFilter
	
	^false!
*/
}

public boolean isEmpty() {
throw new UnsupportedOperationException();/*
udanax-top.st:66695:AndFilter methodsFor: 'testing'!
{BooleanVar} isEmpty
	^false!
*/
}

public boolean isEqual(Heaper other) {
throw new UnsupportedOperationException();/*
udanax-top.st:66698:AndFilter methodsFor: 'testing'!
{BooleanVar} isEqual: other {Heaper}
	other
		cast: AndFilter into: [:af |
			^af subFilters isEqual: self subFilters]
		others: [^false].
	^false "fodder"!
*/
}

public boolean isFull() {
throw new UnsupportedOperationException();/*
udanax-top.st:66706:AndFilter methodsFor: 'testing'!
{BooleanVar} isFull	
	^false!
*/
}

public XnRegion complement() {
throw new UnsupportedOperationException();/*
udanax-top.st:66712:AndFilter methodsFor: 'operations'!
{XnRegion} complement
	| result {XnRegion} |
	result _ Filter closedFilter: self coordinateSpace.
	self subFilters stepper forEach: [ :sub {XnRegion} |
		result _ result unionWith: sub complement].
	^result!
*/
}

/**
 * return self or other if one is clearly a subset of the other, else NULL
 */
public XnRegion fetchSpecialSubset(XnRegion other) {
throw new UnsupportedOperationException();/*
udanax-top.st:66722:AndFilter methodsFor: 'protected operations'!
{XnRegion} fetchSpecialSubset: other {XnRegion}
	"return self or other if one is clearly a subset of the other, else NULL"
	| filter {Filter} defaultRegion {XnRegion} |
	filter _ other cast: Filter.
	defaultRegion _ other.
	self subFilters stepper forEach: [ :subfilter {Filter} | | a {XnRegion} b {XnRegion} |
		(a _ subfilter fetchSpecialSubset: filter) == subfilter ifTrue: [^self].
		(b _ filter fetchSpecialSubset: subfilter) == subfilter ifTrue: [^self].
		((a basicCast: Heaper star) == other or: [(b basicCast: Heaper star) == other]) ifFalse: [defaultRegion _ NULL]].
	^defaultRegion!
*/
}

public Stepper intersectedFilters() {
throw new UnsupportedOperationException();/*
udanax-top.st:66735:AndFilter methodsFor: 'enumerating'!
{Stepper of: Filter} intersectedFilters
	^mySubFilters stepper!
*/
}

public Stepper unionedFilters() {
throw new UnsupportedOperationException();/*
udanax-top.st:66739:AndFilter methodsFor: 'enumerating'!
{Stepper of: Filter} unionedFilters
	^Stepper itemStepper: self!
*/
}

public XnRegion baseRegion() {
throw new UnsupportedOperationException();/*
udanax-top.st:66745:AndFilter methodsFor: 'accessing'!
{XnRegion} baseRegion
	Heaper BLAST: #NotSimpleEnough.
	^NULL!
*/
}

public XnRegion relevantRegion() {
throw new UnsupportedOperationException();/*
udanax-top.st:66750:AndFilter methodsFor: 'accessing'!
{XnRegion} relevantRegion
	| result {XnRegion} |
	result := self filterSpace baseSpace emptyRegion.
	mySubFilters stepper forEach: [ :sub {Filter} |
		result := result unionWith: sub relevantRegion].
	^result!
*/
}

public  AndFilter(Rcvr receiver) {
	super(receiver);
throw new UnsupportedOperationException();/*
udanax-top.st:66760:AndFilter methodsFor: 'generated:'!
create.Rcvr: receiver {Rcvr}
	super create.Rcvr: receiver.
	mySubFilters _ receiver receiveHeaper.!
*/
}

public void sendSelfTo(Xmtr xmtr) {
throw new UnsupportedOperationException();/*
udanax-top.st:66764:AndFilter methodsFor: 'generated:'!
{void} sendSelfTo: xmtr {Xmtr}
	super sendSelfTo: xmtr.
	xmtr sendHeaper: mySubFilters.!
*/
}

/**
 * assumes that the interactions between elements have already been removed
 */
public static Heaper make(FilterSpace cs, ImmuSet subs) {
throw new UnsupportedOperationException();/*
udanax-top.st:66777:AndFilter class methodsFor: 'pseudo constructors'!
{Filter} make: cs {FilterSpace} with: subs {ImmuSet of: Filter}
	"assumes that the interactions between elements have already been removed"
	
	subs isEmpty ifTrue: [^cs fullRegion cast: Filter].
	subs count = 1 ifTrue: [^subs theOne cast: Filter].
	^self create: cs with: subs!
*/
}
}
