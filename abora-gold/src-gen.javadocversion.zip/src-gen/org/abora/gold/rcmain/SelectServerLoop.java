/*
 * Abora-Gold
 * Part of the Abora hypertext project: http://www.abora.org
 * Copyright 2003 David G Jones
 * 
 * Translated from Udanax-Gold source code: http://www.udanax.com
 * Copyright 1979-1999 Udanax.com. All rights reserved
 */
package org.abora.gold.rcmain;

import org.abora.gold.fm.support.Thunk;
import org.abora.gold.rcmain.ServerChunk;
import org.abora.gold.rcmain.ServerLoop;
import org.abora.gold.xcvr.Rcvr;
import org.abora.gold.xcvr.Xmtr;
import org.abora.gold.xpp.basic.Heaper;


/**
 * This is a ServerLoop designed specifically for Berkeley Sockets.  It allows socket
 * listeners to be registered and it dispatches among them based on a select() call
 */
public class SelectServerLoop extends ServerLoop {
	protected int myFDSet;
/*
udanax-top.st:57631:
ServerLoop subclass: #SelectServerLoop
	instanceVariableNames: 'myFDSet {fd.U.set var NOCOPY}'
	classVariableNames: ''
	poolDictionaries: ''
	category: 'Xanadu-rcmain'!
*/
/*
udanax-top.st:57635:
SelectServerLoop comment:
'This is a ServerLoop designed specifically for Berkeley Sockets.  It allows socket listeners to be registered and it dispatches among them based on a select() call'!
*/
/*
udanax-top.st:57637:
(SelectServerLoop getOrMakeCxxClassDescription)
	attributes: ((Set new) add: #CONCRETE; add: #(COPY boot ); add: #NOT.A.TYPE; yourself)!
*/
/*
udanax-top.st:57737:
SelectServerLoop class
	instanceVariableNames: ''!
*/
/*
udanax-top.st:57740:
(SelectServerLoop getOrMakeCxxClassDescription)
	attributes: ((Set new) add: #CONCRETE; add: #(COPY boot ); add: #NOT.A.TYPE; yourself)!
*/

public  SelectServerLoop() {
throw new UnsupportedOperationException();/*
udanax-top.st:57642:SelectServerLoop methodsFor: 'creation'!
create
	super create.
	'
#ifndef HIGHC
	FD_ZERO(&myFDSet);
#endif' translateOnly!
*/
}

/**
 * Schedule any chunks that have become active.
 */
public void scheduleChunks() {
throw new UnsupportedOperationException();/*
udanax-top.st:57651:SelectServerLoop methodsFor: 'execution'!
{void} scheduleChunks
	"Schedule any chunks that have become active."
	
	[Stepper] USES.
	[MuSet] USES.
	[Delay forMilliseconds: 100.] smalltalkOnly.
	'
#ifdef unix
	signal (SIGPIPE, SIG_IGN);
#endif
	
	static fd_set readfds = myFDSet;
	static fd_set exceptfds = myFDSet;
#if defined(unix) && !! defined(__sgi)
	int maxFDs = getdtablesize();
#else
	int maxFDs = FD_SETSIZE;
#endif /- unix -/
	int numReady;
	
	if (this->activeChunks ()->isEmpty ()) {
		numReady = select (maxFDs-1, &readfds, NULL, &exceptfds, NULL);
	} else {
		/- timeout immediately so active Chunks can execute -/
		timeval zero;
		zero.tv_sec = 0;
		zero.tv_usec = 0;
		numReady = select (maxFDs-1, &readfds, NULL, &exceptfds, &zero);
	}
	if (numReady <= 0 ) {
#ifdef WIN32
		if (numReady == 0 || errno == WSAEINTR) {
#else
		if (numReady == 0 || errno == EINTR) {
#endif /- WIN32 -/
			return;
		}
		BLAST(SELECT_FAILED);
	}
	BEGIN_FOR_EACH(FDListener, aListener, (ServerLoop::chunks()->stepper())) {
		if (FD_ISSET(aListener->descriptor(), &exceptfds)) {
			ServerLoop::chunks()->remove(aListener);
			aListener->destroy ();
			if (--numReady <= 0)
				break;
		} else if (FD_ISSET(aListener->descriptor(), &readfds)) {
			if (aListener->shouldBeReady ()) {
				this->activeChunks()->store(aListener);
			} else {
				ServerLoop::chunks()->remove(aListener);
				aListener->destroy ();
			}
			if (--numReady <= 0)
				break;
		}
	} END_FOR_EACH;
' translateOnly.
	[self activeChunks storeAll: ServerLoop chunks.
	Processor yield] smalltalkOnly!
*/
}

public void deregisterChunk(ServerChunk aChunk) {
throw new UnsupportedOperationException();/*
udanax-top.st:57714:SelectServerLoop methodsFor: 'protected: accessing'!
{void} deregisterChunk: aChunk {ServerChunk}
	super deregisterChunk: aChunk.
	'
	FD_CLR(CAST(FDListener,aChunk)->descriptor(), &myFDSet);
' translateOnly!
*/
}

public void registerChunk(ServerChunk aChunk) {
throw new UnsupportedOperationException();/*
udanax-top.st:57721:SelectServerLoop methodsFor: 'protected: accessing'!
{void} registerChunk: aChunk {ServerChunk}
	super registerChunk: aChunk.
	'
	FD_SET(CAST(FDListener,aChunk)->descriptor(), &myFDSet);
' translateOnly!
*/
}

public  SelectServerLoop(Rcvr receiver) {
throw new UnsupportedOperationException();/*
udanax-top.st:57730:SelectServerLoop methodsFor: 'generated:'!
create.Rcvr: receiver {Rcvr}
	super create.Rcvr: receiver.!
*/
}

public void sendSelfTo(Xmtr xmtr) {
throw new UnsupportedOperationException();/*
udanax-top.st:57733:SelectServerLoop methodsFor: 'generated:'!
{void} sendSelfTo: xmtr {Xmtr}
	super sendSelfTo: xmtr.!
*/
}

public static Heaper make() {
throw new UnsupportedOperationException();/*
udanax-top.st:57745:SelectServerLoop class methodsFor: 'creation'!
{Thunk} make
	^ self create!
*/
}
}
