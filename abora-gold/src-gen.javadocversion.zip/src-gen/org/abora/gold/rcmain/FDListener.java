/*
 * Abora-Gold
 * Part of the Abora hypertext project: http://www.abora.org
 * Copyright 2003 David G Jones
 * 
 * Translated from Udanax-Gold source code: http://www.udanax.com
 * Copyright 1979-1999 Udanax.com. All rights reserved
 */
package org.abora.gold.rcmain;

import org.abora.gold.rcmain.ServerChunk;


/**
 * This is the superclass for Listeners that use Berkeley UNIX sockets.
 */
public class FDListener extends ServerChunk {
	protected int myFD;
/*
udanax-top.st:50826:
ServerChunk subclass: #FDListener
	instanceVariableNames: 'myFD {int NOCOPY}'
	classVariableNames: ''
	poolDictionaries: ''
	category: 'Xanadu-rcmain'!
*/
/*
udanax-top.st:50830:
FDListener comment:
'This is the superclass for Listeners that use Berkeley UNIX sockets.'!
*/
/*
udanax-top.st:50832:
(FDListener getOrMakeCxxClassDescription)
	attributes: ((Set new) add: #DEFERRED; add: #EQ; yourself)!
*/
/*
udanax-top.st:50878:
FDListener class
	instanceVariableNames: ''!
*/
/*
udanax-top.st:50881:
(FDListener getOrMakeCxxClassDescription)
	attributes: ((Set new) add: #DEFERRED; add: #EQ; yourself)!
*/

public int descriptor() {
throw new UnsupportedOperationException();/*
udanax-top.st:50837:FDListener methodsFor: 'accessing'!
{int} descriptor
	^myFD.!
*/
}

/**
 * Attempt to execute another chunk.  Return whether there is more to be done.
 */
public boolean execute() {
throw new UnsupportedOperationException();/*
udanax-top.st:50841:FDListener methodsFor: 'accessing'!
{BooleanVar} execute
	"Attempt to execute another chunk.  Return whether there is more to be done."
	self subclassResponsibility.!
*/
}

/**
 * There should be data waiting on this FD. Return TRUE if I am still in a reasonable state
 * to continue, FALSE if not (in which case the Listener will be destroyed by the caller)
 */
public boolean shouldBeReady() {
throw new UnsupportedOperationException();/*
udanax-top.st:50846:FDListener methodsFor: 'accessing'!
{BooleanVar} shouldBeReady
	"There should be data waiting on this FD. Return TRUE if I am still in a reasonable state to continue, FALSE if not (in which case the Listener will be destroyed by the caller)"
	self subclassResponsibility.!
*/
}

public  FDListener() {
throw new UnsupportedOperationException();/*
udanax-top.st:50853:FDListener methodsFor: 'creation'!
create
	super create.
	[myFD _ Int32Zero] smalltalkOnly.
	'myFD = (int) Int32Zero;' translateOnly.!
*/
}

public void destruct() {
throw new UnsupportedOperationException();/*
udanax-top.st:50859:FDListener methodsFor: 'creation'!
{void} destruct
	[myFD close] smalltalkOnly.
	'close (myFD);' translateOnly.
	super destruct.!
*/
}

public void registerFor(int anFD) {
throw new UnsupportedOperationException();/*
udanax-top.st:50865:FDListener methodsFor: 'creation'!
{void} registerFor: anFD {int}
	myFD _ anFD.
	CloseExecutor registerHolder: self with: anFD.
	ServerLoop introduceChunk: self!
*/
}

public int actualHashForEqual() {
throw new UnsupportedOperationException();/*
udanax-top.st:50873:FDListener methodsFor: 'generated:'!
actualHashForEqual ^self asOop!
*/
}

public boolean isEqual(Object other) {
throw new UnsupportedOperationException();/*
udanax-top.st:50875:FDListener methodsFor: 'generated:'!
isEqual: other ^self == other!
*/
}

public static void initTimeNonInherited() {
throw new UnsupportedOperationException();/*
udanax-top.st:50886:FDListener class methodsFor: 'smalltalk: init'!
initTimeNonInherited
'
#ifdef unix
	signal(SIGPIPE, SIG_IGN);
#endif
' translateOnly!
*/
}

public static void problems() {
throw new UnsupportedOperationException();/*
udanax-top.st:50896:FDListener class methodsFor: 'exceptions: exceptions'!
problems.SOCKET.U.ERRS
	^self signals: #(SOCKET.U.RECV.U.ERROR SOCKET.U.SEND.U.ERROR)!
*/
}
}
