/*
 * Abora-Gold
 * Part of the Abora hypertext project: http://www.abora.org
 * Copyright 2003 David G Jones
 * 
 * Translated from Udanax-Gold source code: http://www.udanax.com
 * Copyright 1979-1999 Udanax.com. All rights reserved
 */
package org.abora.gold.rcmain;

import org.abora.gold.java.missing.smalltalk.Filename;
import org.abora.gold.xpp.basic.Heaper;


/**
 * A dummy class on which to hang the main that reads in an rc file.
 */
public class MainDummy extends Heaper {
/*
udanax-top.st:28218:
Heaper subclass: #MainDummy
	instanceVariableNames: ''
	classVariableNames: ''
	poolDictionaries: ''
	category: 'Xanadu-rcmain'!
*/
/*
udanax-top.st:28222:
MainDummy comment:
'A dummy class on which to hang the main that reads in an rc file.'!
*/
/*
udanax-top.st:28224:
(MainDummy getOrMakeCxxClassDescription)
	friends:
'/- friends for class MainDummy -/
friend int  main (int argc, char* * argv);';
	attributes: ((Set new) add: #DEFERRED; yourself)!
*/
/*
udanax-top.st:28237:
MainDummy class
	instanceVariableNames: ''!
*/
/*
udanax-top.st:28240:
(MainDummy getOrMakeCxxClassDescription)
	friends:
'/- friends for class MainDummy -/
friend int  main (int argc, char* * argv);';
	attributes: ((Set new) add: #DEFERRED; yourself)!
*/

public int actualHashForEqual() {
throw new UnsupportedOperationException();/*
udanax-top.st:28233:MainDummy methodsFor: 'testing'!
{UInt32} actualHashForEqual
	^Heaper takeOop!
*/
}

public static void run(Object filename) {
throw new UnsupportedOperationException();/*
udanax-top.st:28249:MainDummy class methodsFor: 'smalltalk: booting'!
{void} run: filename
	self XU.U.MAIN: 2 with: (Array with: filename)!
*/
}

public static void runString(Object string) {
throw new UnsupportedOperationException();/*
udanax-top.st:28252:MainDummy class methodsFor: 'smalltalk: booting'!
{void} runString: string 
	Initializer doMain:
	[| rc {Rcvr} next {Heaper | NULL} |
	rc _ TextyXcvrMaker make 
				makeRcvr: (TransferSpecialist make: (Cookbook make.String: 'boot'))
				with: (XnReadFile create: string readStream).
	next _ rc receiveHeaper.
	[next ~~ NULL] whileTrue: 
		[next cast: Thunk into: [:thunk | thunk execute] others: [].
		next _ rc receiveHeaper].
	rc destroy].
	^Int32Zero!
*/
}

public static void toFileRunString(Filename fileName, String string) {
throw new UnsupportedOperationException();/*
udanax-top.st:28265:MainDummy class methodsFor: 'smalltalk: booting'!
{void} toFile: fileName {Filename} runString: string {String}
	| aStream saveCerr |
	aStream _ fileName writeStream.
	saveCerr _ cerr.
	[| rc {Rcvr} next {Heaper | NULL} |
	cerr _ aStream.
	self knownBug. "only accepts UInt8Arrays"
	rc _ TextyXcvrMaker make 
				makeRcvr: (TransferSpecialist make: (Cookbook make.String: 'boot'))
				with: (XnReadFile create: string readStream).
	next _ rc receiveHeaper.
	[next ~~ NULL] whileTrue: 
		[next cast: Thunk into: [:thunk | thunk execute] others: [].
		next _ rc receiveHeaper].
	rc destroy] valueNowOrOnUnwindDo: 
		[cerr _ saveCerr.
		aStream close]!
*/
}

public static void staticTimeNonInherited() {
throw new UnsupportedOperationException();/*
udanax-top.st:28286:MainDummy class methodsFor: 'smalltalk: init'!
staticTimeNonInherited
	Rcvr defineFluid: #CurrentMainReceiver with: Emulsion globalEmulsion with: [NULL].
	Heaper defineFluid: #MainActiveThunk with: Emulsion globalEmulsion with: [NULL].!
*/
}

public static int XU(int argc, String argv) {
throw new UnsupportedOperationException();/*
udanax-top.st:28292:MainDummy class methodsFor: 'global: booting'!
{int} XU.U.MAIN: argc {int} with: argv {char star vector}
	| stackObject {Int32} |
	[StackExaminer] USES.
	'StackExaminer::stackEnd(&stackObject);' translateOnly.
	Initializer with: argc with: argv doMain:
	[| rc {Rcvr} next {Heaper | NULL} |
	argc < 2 ifTrue: [cerr << 'usage: ' << (argv at: Int32Zero) << ' rcFileName
'.	^1].
	rc _ TextyXcvrMaker make 
			makeRcvr: (TransferSpecialist make: (Cookbook make.String: 'boot')) 
			with: (XnReadFile make: (argv at: 1)).
	CurrentMainReceiver fluidBind: rc during:
		[next _ CurrentMainReceiver fluidGet receiveHeaper.
		[next ~~ NULL] whileTrue:
			[MainActiveThunk fluidBind: next during:
				[next cast: Thunk into: [:thunk | thunk execute] others: []].
			next _ CurrentMainReceiver fluidGet  receiveHeaper].
			CurrentMainReceiver fluidGet destroy].
	^Int32Zero]!
*/
}

public static int main(int argc, String argv) {
throw new UnsupportedOperationException();/*
udanax-top.st:28314:MainDummy class methodsFor: 'smalltalk: passe'!
{int} main: argc {int} with: argv {char star vector}
	
	self passe!
*/
}
}
