/*
 * Abora-Gold
 * Part of the Abora hypertext project: http://www.abora.org
 * Copyright 2003 David G Jones
 * 
 * Translated from Udanax-Gold source code: http://www.udanax.com
 * Copyright 1979-1999 Udanax.com. All rights reserved
 */
package org.abora.gold.rcmain;

import org.abora.gold.nadmin.FeSession;
import org.abora.gold.proman.PacketPortal;
import org.abora.gold.proman.PromiseManager;
import org.abora.gold.rcmain.FDListener;
import org.abora.gold.xpp.basic.Heaper;


/**
 * A IPConnectionListener is associated with the FD of a socket connection to a frontend.
 * Its handleInput method is used to invoke a waitForAndProcessMessage method to handle
 * messages
 * from the frontend.
 */
public class IPPromiseListener extends FDListener {
	protected PromiseManager myManager;
	protected FeSession mySession;
	protected PacketPortal myPortal;
/*
udanax-top.st:50900:
FDListener subclass: #IPPromiseListener
	instanceVariableNames: '
		myManager {PromiseManager}
		mySession {FeSession}
		myPortal {PacketPortal}'
	classVariableNames: ''
	poolDictionaries: ''
	category: 'Xanadu-rcmain'!
*/
/*
udanax-top.st:50907:
IPPromiseListener comment:
'A IPConnectionListener is associated with the FD of a socket connection to a frontend.
Its handleInput method is used to invoke a waitForAndProcessMessage method to handle messages
from the frontend.'!
*/
/*
udanax-top.st:50911:
(IPPromiseListener getOrMakeCxxClassDescription)
	attributes: ((Set new) add: #CONCRETE; yourself)!
*/
/*
udanax-top.st:50982:
IPPromiseListener class
	instanceVariableNames: ''!
*/
/*
udanax-top.st:50985:
(IPPromiseListener getOrMakeCxxClassDescription)
	attributes: ((Set new) add: #CONCRETE; yourself)!
*/

public void destruct() {
throw new UnsupportedOperationException();/*
udanax-top.st:50916:IPPromiseListener methodsFor: 'protected: destruct'!
{void} destruct
	mySession _ NULL.
	myPortal _ NULL.
	myManager destroy.
	myManager _ NULL.
	super destruct!
*/
}

public  IPPromiseListener(int aSocket) {
throw new UnsupportedOperationException();/*
udanax-top.st:50925:IPPromiseListener methodsFor: 'creation'!
create: aSocket {int}
	super create.
	CurrentChunk _ self.
	myPortal _ SocketPortal make: aSocket.
	myManager _ PromiseManager make: myPortal.
	self registerFor: aSocket.
	FePromiseSession make: (UInt8Array string: 'socket') with: self with: myManager.
	CurrentChunk _ NULL.!
*/
}

public boolean shouldBeReady() {
throw new UnsupportedOperationException();/*
udanax-top.st:50937:IPPromiseListener methodsFor: 'testing'!
{BooleanVar} shouldBeReady
	| result {BooleanVar} |
	result := self destroyPending not.
	result ifFalse: [self destroyOKIfRequested].
	[^result] smalltalkOnly.
	'
#if defined(WIN32) | defined(HIGHC)
	return result;
#else
	if (!!result) {
		return FALSE;
	}
	size_t	nready;
	ioctl (this->descriptor (), FIONREAD, &nready);
	return nready > 0;
#endif /- WIN32 -/
' translateOnly!
*/
}

/**
 * Attempt to execute another chunk.  Return whether there is more to be done.
 */
public boolean execute() {
throw new UnsupportedOperationException();/*
udanax-top.st:50957:IPPromiseListener methodsFor: 'accessing'!
{BooleanVar} execute
	"Attempt to execute another chunk.  Return whether there is more to be done."
	(myPortal readStream cast: XnBufferedReadStream) isReady ifFalse: [^false].
	CurrentChunk _ self.
	FDListener problems.SOCKET.U.ERRS 
		handle: [:ex | 
				'/-cerr << &PROBLEM(ex);-/' translateOnly.
				'operator<<(cerr ,(Problem*)&PROBLEM(ex));' translateOnly.
				cerr << ' Connection closed.
'.
				CurrentChunk _ NULL.
				self destroy.
				self destroyOKIfRequested.
				^false]
		do: 	[
			self inRequest.
			myManager handleRequest.
			self notInRequest].
	CurrentChunk _ NULL.
	self destroyOKIfRequested
		ifTrue: [^ false]
		ifFalse: [^(myPortal readStream cast: XnBufferedReadStream) isReady]!
*/
}

public static Heaper make(int aSocket) {
throw new UnsupportedOperationException();/*
udanax-top.st:50990:IPPromiseListener class methodsFor: 'creation'!
{FDListener} make: aSocket {int}
	^self create: aSocket.!
*/
}
}
