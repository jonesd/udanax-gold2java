/*
 * Abora-Gold
 * Part of the Abora hypertext project: http://www.abora.org
 * Copyright 2003 David G Jones
 * 
 * Translated from Udanax-Gold source code: http://www.udanax.com
 * Copyright 1979-1999 Udanax.com. All rights reserved
 */
package org.abora.gold.rcmain;

import org.abora.gold.xpp.basic.Heaper;
import org.abora.gold.xpp.fluid.Emulsion;


/**
 * This is the superclass for all the Chunks.  Chunks represent pieces of the server that run
 * for a while, then return control.  Subclasses include Listeners that wait for input.
 * When manually destroyed, this class flags itself for cleanup after any current
 * request is finished--myEnding state is alive, alive in request, destruction requested, and
 * ready for destruction.
 */
public class ServerChunk extends Heaper {
	protected char myFluidSpace;
	protected int myEndingState;
	protected static Emulsion SecretEmulsion;
/*
udanax-top.st:50657:
Heaper subclass: #ServerChunk
	instanceVariableNames: '
		myFluidSpace {char star}
		myEndingState {Int32}'
	classVariableNames: 'SecretEmulsion {Emulsion} '
	poolDictionaries: ''
	category: 'Xanadu-rcmain'!
*/
/*
udanax-top.st:50663:
ServerChunk comment:
'This is the superclass for all the Chunks.  Chunks represent pieces of the server that run for a while, then return control.  Subclasses include Listeners that wait for input.    When manually destroyed, this class flags itself for cleanup after any current
request is finished--myEnding state is alive, alive in request, destruction requested, and ready for destruction.'!
*/
/*
udanax-top.st:50666:
(ServerChunk getOrMakeCxxClassDescription)
	attributes: ((Set new) add: #DEFERRED; add: #EQ; yourself)!
*/
/*
udanax-top.st:50745:
ServerChunk class
	instanceVariableNames: ''!
*/
/*
udanax-top.st:50748:
(ServerChunk getOrMakeCxxClassDescription)
	attributes: ((Set new) add: #DEFERRED; add: #EQ; yourself)!
*/

public boolean destroyOKIfRequested() {
throw new UnsupportedOperationException();/*
udanax-top.st:50671:ServerChunk methodsFor: 'protected: accessing'!
{BooleanVar} destroyOKIfRequested
	(myEndingState == ServerChunk inRequestFlag or: [myEndingState == ServerChunk destroyRequestedFlag]) ifTrue: [
		myEndingState := ServerChunk destroyReadyFlag.
		^ true]
	ifFalse: [^false]!
*/
}

public boolean destroyPending() {
throw new UnsupportedOperationException();/*
udanax-top.st:50677:ServerChunk methodsFor: 'protected: accessing'!
{BooleanVar} destroyPending
	^ myEndingState == ServerChunk destroyRequestedFlag.!
*/
}

public void inRequest() {
throw new UnsupportedOperationException();/*
udanax-top.st:50680:ServerChunk methodsFor: 'protected: accessing'!
{void} inRequest
	myEndingState := ServerChunk inRequestFlag.!
*/
}

public void notInRequest() {
throw new UnsupportedOperationException();/*
udanax-top.st:50683:ServerChunk methodsFor: 'protected: accessing'!
{void} notInRequest
	myEndingState == ServerChunk destroyRequestedFlag
		ifTrue: [myEndingState := ServerChunk destroyReadyFlag]
		ifFalse: [myEndingState == ServerChunk inRequestFlag ifTrue: [myEndingState := ServerChunk aliveFlag]]!
*/
}

/**
 * Returns TRUE if this chunk wants to be deleted after deregistration.
 */
public boolean shouldDestroy() {
throw new UnsupportedOperationException();/*
udanax-top.st:50690:ServerChunk methodsFor: 'testing'!
{BooleanVar} shouldDestroy
	"Returns TRUE if this chunk wants to be deleted after deregistration."
	^ myEndingState == ServerChunk destroyReadyFlag!
*/
}

/**
 * Attempt to execute another chunk.  Return whether there is more to be done.
 */
public boolean execute() {
throw new UnsupportedOperationException();/*
udanax-top.st:50696:ServerChunk methodsFor: 'accessing'!
{BooleanVar} execute
	"Attempt to execute another chunk.  Return whether there is more to be done."
	self subclassResponsibility.!
*/
}

public String fluidSpace() {
throw new UnsupportedOperationException();/*
udanax-top.st:50701:ServerChunk methodsFor: 'accessing'!
{char star} fluidSpace
	^myFluidSpace.!
*/
}

public String fluidSpace(String aFluidSpace) {
throw new UnsupportedOperationException();/*
udanax-top.st:50705:ServerChunk methodsFor: 'accessing'!
{char star} fluidSpace: aFluidSpace {char star}
	^myFluidSpace _ aFluidSpace.!
*/
}

/**
 * ServerChunks are destroyed explicitly in the server loop.
 */
public void destruct() {
throw new UnsupportedOperationException();/*
udanax-top.st:50711:ServerChunk methodsFor: 'protected: destruct'!
{void} destruct
	"ServerChunks are destroyed explicitly in the server loop."
	| saveChunk {ServerChunk} |
	(myFluidSpace ~~ NULL) ifTrue: [
		saveChunk _ CurrentChunk.
		CurrentChunk _ self.
		ServerChunk emulsion destructAll.
		CurrentChunk _ saveChunk.].
	ServerLoop removeChunk: self.
	ChunkCleaner beClean.
	super destruct.!
*/
}

public  ServerChunk() {
throw new UnsupportedOperationException();/*
udanax-top.st:50725:ServerChunk methodsFor: 'creation'!
create
	super create.
	myFluidSpace _ NULL.
	myEndingState := Int32Zero.!
*/
}

public void destroy() {
throw new UnsupportedOperationException();/*
udanax-top.st:50731:ServerChunk methodsFor: 'creation'!
{void} destroy
	(myEndingState == ServerChunk aliveFlag or: [myEndingState == ServerChunk destroyReadyFlag])
		ifTrue: [super destroy]
		ifFalse: [
			myEndingState == ServerChunk destroyRequestedFlag ifTrue: [Heaper BLAST: #AlreadyDestroyed].
			myEndingState := ServerChunk destroyRequestedFlag]!
*/
}

public int actualHashForEqual() {
throw new UnsupportedOperationException();/*
udanax-top.st:50740:ServerChunk methodsFor: 'generated:'!
actualHashForEqual ^self asOop!
*/
}

public boolean isEqual(Object other) {
throw new UnsupportedOperationException();/*
udanax-top.st:50742:ServerChunk methodsFor: 'generated:'!
isEqual: other ^self == other!
*/
}

public static Emulsion emulsion() {
throw new UnsupportedOperationException();/*
udanax-top.st:50753:ServerChunk class methodsFor: 'accessing'!
{Emulsion} emulsion
	[SecretEmulsion == nil ifTrue: [SecretEmulsion _ NULL]] smalltalkOnly.
	(SecretEmulsion == NULL) ifTrue: [
		SecretEmulsion _ ListenerEmulsion new create].
	^SecretEmulsion.!
*/
}

public static void cleanupGarbage() {
throw new UnsupportedOperationException();/*
udanax-top.st:50761:ServerChunk class methodsFor: 'smalltalk: init'!
cleanupGarbage
	SecretEmulsion _ NULL!
*/
}

public static void linkTimeNonInherited() {
throw new UnsupportedOperationException();/*
udanax-top.st:50764:ServerChunk class methodsFor: 'smalltalk: init'!
linkTimeNonInherited
	ServerChunk defineGlobal: #CurrentChunk with: NULL.
	SecretEmulsion _ NULL.!
*/
}

public static int aliveFlag() {
throw new UnsupportedOperationException();/*
udanax-top.st:50770:ServerChunk class methodsFor: 'protected: accessing'!
{Int32 INLINE} aliveFlag
	^ Int32Zero!
*/
}

public static int destroyReadyFlag() {
throw new UnsupportedOperationException();/*
udanax-top.st:50773:ServerChunk class methodsFor: 'protected: accessing'!
{Int32 INLINE} destroyReadyFlag
	^ 3!
*/
}

public static int destroyRequestedFlag() {
throw new UnsupportedOperationException();/*
udanax-top.st:50776:ServerChunk class methodsFor: 'protected: accessing'!
{Int32 INLINE} destroyRequestedFlag
	^ 2!
*/
}

public static int inRequestFlag() {
throw new UnsupportedOperationException();/*
udanax-top.st:50779:ServerChunk class methodsFor: 'protected: accessing'!
{Int32 INLINE} inRequestFlag
	^ 1!
*/
}
}
