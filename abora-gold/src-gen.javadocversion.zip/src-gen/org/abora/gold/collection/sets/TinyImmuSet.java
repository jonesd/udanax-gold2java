/*
 * Abora-Gold
 * Part of the Abora hypertext project: http://www.abora.org
 * Copyright 2003 David G Jones
 * 
 * Translated from Udanax-Gold source code: http://www.udanax.com
 * Copyright 1979-1999 Udanax.com. All rights reserved
 */
package org.abora.gold.collection.sets;

import org.abora.gold.collection.sets.ImmuSet;
import org.abora.gold.collection.sets.MuSet;
import org.abora.gold.collection.sets.ScruSet;
import org.abora.gold.collection.steppers.Stepper;
import org.abora.gold.java.missing.IntegerVar;
import org.abora.gold.xcvr.Rcvr;
import org.abora.gold.xcvr.Xmtr;
import org.abora.gold.xpp.basic.Heaper;


/**
 * This is an efficient implementation of ImmuSets for zero and one element sets.
 */
public class TinyImmuSet extends ImmuSet {
	protected Heaper elementInternal;
/*
udanax-top.st:45721:
ImmuSet subclass: #TinyImmuSet
	instanceVariableNames: 'elementInternal {Heaper}'
	classVariableNames: ''
	poolDictionaries: ''
	category: 'Xanadu-Collection-Sets'!
*/
/*
udanax-top.st:45725:
TinyImmuSet comment:
'This is an efficient implementation of ImmuSets for zero and one element sets.'!
*/
/*
udanax-top.st:45727:
(TinyImmuSet getOrMakeCxxClassDescription)
	attributes: ((Set new) add: #CONCRETE; add: #NOT.A.TYPE; add: #COPY; yourself)!
*/
/*
udanax-top.st:45812:
TinyImmuSet class
	instanceVariableNames: ''!
*/
/*
udanax-top.st:45815:
(TinyImmuSet getOrMakeCxxClassDescription)
	attributes: ((Set new) add: #CONCRETE; add: #NOT.A.TYPE; add: #COPY; yourself)!
*/

/**
 * Initialize a singleton immuset
 */
public  TinyImmuSet(Heaper only) {
throw new UnsupportedOperationException();/*
udanax-top.st:45732:TinyImmuSet methodsFor: 'protected: creation'!
create: only {Heaper}
	"Initialize a singleton immuset"
	super create.
	elementInternal _ only!
*/
}

public IntegerVar count() {
throw new UnsupportedOperationException();/*
udanax-top.st:45739:TinyImmuSet methodsFor: 'enumerating'!
{IntegerVar} count
	^ 1!
*/
}

public Stepper stepper() {
throw new UnsupportedOperationException();/*
udanax-top.st:45742:TinyImmuSet methodsFor: 'enumerating'!
{Stepper} stepper
	^Stepper itemStepper: elementInternal!
*/
}

public Heaper theOne() {
throw new UnsupportedOperationException();/*
udanax-top.st:45745:TinyImmuSet methodsFor: 'enumerating'!
{Heaper} theOne
	^ elementInternal!
*/
}

public ImmuSet with(Heaper anElement) {
throw new UnsupportedOperationException();/*
udanax-top.st:45750:TinyImmuSet methodsFor: 'adding-removing'!
{ImmuSet} with: anElement {Heaper} 
	(elementInternal isEqual: anElement)
		ifTrue: [^self]
		ifFalse: [| nuSet {MuSet} |
					nuSet _ MuSet make.Heaper: anElement.
					nuSet introduce: elementInternal.
					^ImmuSet make: nuSet]!
*/
}

public ImmuSet without(Heaper anElement) {
throw new UnsupportedOperationException();/*
udanax-top.st:45758:TinyImmuSet methodsFor: 'adding-removing'!
{ImmuSet} without: anElement {Heaper}
	(elementInternal isEqual: anElement) ifTrue: [^ ImmuSet make].
	^ self!
*/
}

public boolean hasMember(Heaper someone) {
throw new UnsupportedOperationException();/*
udanax-top.st:45764:TinyImmuSet methodsFor: 'accessing'!
{BooleanVar} hasMember: someone {Heaper}
	^ elementInternal isEqual: someone!
*/
}

public boolean isEmpty() {
throw new UnsupportedOperationException();/*
udanax-top.st:45767:TinyImmuSet methodsFor: 'accessing'!
{BooleanVar} isEmpty
	^ false!
*/
}

public boolean isSubsetOf(ScruSet another) {
throw new UnsupportedOperationException();/*
udanax-top.st:45770:TinyImmuSet methodsFor: 'accessing'!
{BooleanVar} isSubsetOf: another {ScruSet}
	^ another hasMember: elementInternal!
*/
}

public ImmuSet intersect(ScruSet another) {
throw new UnsupportedOperationException();/*
udanax-top.st:45775:TinyImmuSet methodsFor: 'operations'!
{ImmuSet} intersect: another {ScruSet} 
	(another hasMember: elementInternal)
		ifTrue: [^ self]
		ifFalse: [^ ImmuSet make]!
*/
}

public ImmuSet minus(ScruSet another) {
throw new UnsupportedOperationException();/*
udanax-top.st:45780:TinyImmuSet methodsFor: 'operations'!
{ImmuSet} minus: another {ScruSet}
	(another hasMember: elementInternal) 
		ifTrue: [^ ImmuSet make]
		ifFalse: [^ self]!
*/
}

public ImmuSet unionWith(ScruSet another) {
throw new UnsupportedOperationException();/*
udanax-top.st:45785:TinyImmuSet methodsFor: 'operations'!
{ImmuSet} unionWith: another {ScruSet}
	another isEmpty 
		ifTrue: [^ self]
		ifFalse:
			[| nuSet {MuSet} |
			(another hasMember: elementInternal) ifTrue: [ ^ another asImmuSet ].
			another count > 5 ifTrue: [^another asImmuSet unionWith: self].
			nuSet _ MuSet make.Heaper: elementInternal.
			nuSet storeAll: another.
			^ ImmuSet make: nuSet]!
*/
}

public MuSet asMuSet() {
throw new UnsupportedOperationException();/*
udanax-top.st:45798:TinyImmuSet methodsFor: 'conversion'!
{MuSet} asMuSet
	^ MuSet make.Heaper: elementInternal!
*/
}

public  TinyImmuSet(Rcvr receiver) {
throw new UnsupportedOperationException();/*
udanax-top.st:45803:TinyImmuSet methodsFor: 'generated:'!
create.Rcvr: receiver {Rcvr}
	super create.Rcvr: receiver.
	elementInternal _ receiver receiveHeaper.!
*/
}

public void sendSelfTo(Xmtr xmtr) {
throw new UnsupportedOperationException();/*
udanax-top.st:45807:TinyImmuSet methodsFor: 'generated:'!
{void} sendSelfTo: xmtr {Xmtr}
	super sendSelfTo: xmtr.
	xmtr sendHeaper: elementInternal.!
*/
}

public static Heaper make(Heaper aHeaper) {
throw new UnsupportedOperationException();/*
udanax-top.st:45820:TinyImmuSet class methodsFor: 'create'!
{ImmuSet} make: aHeaper {Heaper}
	^ self create: aHeaper!
*/
}
}
