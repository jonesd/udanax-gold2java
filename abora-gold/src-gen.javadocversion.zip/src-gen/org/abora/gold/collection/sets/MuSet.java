/*
 * Abora-Gold
 * Part of the Abora hypertext project: http://www.abora.org
 * Copyright 2003 David G Jones
 * 
 * Translated from Udanax-Gold source code: http://www.udanax.com
 * Copyright 1979-1999 Udanax.com. All rights reserved
 */
package org.abora.gold.collection.sets;

import org.abora.gold.collection.sets.ImmuSet;
import org.abora.gold.collection.sets.MuSet;
import org.abora.gold.collection.sets.ScruSet;
import org.abora.gold.collection.steppers.Stepper;
import org.abora.gold.java.missing.IntegerVar;
import org.abora.gold.spaces.basic.XnRegion;
import org.abora.gold.xpp.basic.Heaper;


/**
 * MuSets are a changable collection of elements.  Added to the ScruSet protocol are messages
 * for performing these changes.  The "introduce/store/wipe/remove" suite is defined by
 * analogy with similar methods in MuTable.  See both ScruSet and MuTable.
 */
public class MuSet extends ScruSet {
/*
udanax-top.st:45823:
ScruSet subclass: #MuSet
	instanceVariableNames: ''
	classVariableNames: ''
	poolDictionaries: ''
	category: 'Xanadu-Collection-Sets'!
*/
/*
udanax-top.st:45827:
MuSet comment:
'MuSets are a changable collection of elements.  Added to the ScruSet protocol are messages for performing these changes.  The "introduce/store/wipe/remove" suite is defined by analogy with similar methods in MuTable.  See both ScruSet and MuTable.'!
*/
/*
udanax-top.st:45829:
(MuSet getOrMakeCxxClassDescription)
	friends:
'/- friends for class MuSet -/
friend class ImmuSetOnMu;
friend class COWMuSet;';
	attributes: ((Set new) add: #DEFERRED; add: #EQ; yourself)!
*/
/*
udanax-top.st:45926:
MuSet class
	instanceVariableNames: ''!
*/
/*
udanax-top.st:45929:
(MuSet getOrMakeCxxClassDescription)
	friends:
'/- friends for class MuSet -/
friend class ImmuSetOnMu;
friend class COWMuSet;';
	attributes: ((Set new) add: #DEFERRED; add: #EQ; yourself)!
*/

public boolean hasMember(Heaper someone) {
throw new UnsupportedOperationException();/*
udanax-top.st:45838:MuSet methodsFor: 'accessing'!
{BooleanVar} hasMember: someone {Heaper}
	self subclassResponsibility!
*/
}

public boolean isEmpty() {
throw new UnsupportedOperationException();/*
udanax-top.st:45841:MuSet methodsFor: 'accessing'!
{BooleanVar} isEmpty
	self subclassResponsibility!
*/
}

/**
 * Sort of intersect.  Wipe from myself all elements that I don't have in common with other.
 * Turn myself into the intersection of my current self and other.
 */
public void restrictTo(ScruSet other) {
throw new UnsupportedOperationException();/*
udanax-top.st:45846:MuSet methodsFor: 'operations'!
{void} restrictTo: other {ScruSet} 
	"Sort of intersect.  Wipe from myself all elements that I don't have in common with other.
	Turn myself into the intersection of my current self and other."
	| tmp {MuSet} |
	tmp _ self copy cast: MuSet.
	tmp wipeAll: other.
	self wipeAll: tmp.
	tmp destroy.!
*/
}

/**
 * Sort of union.  Store into myself all elements from other.
 * Turn myself into the union of my current self and other.
 */
public void storeAll(ScruSet other) {
throw new UnsupportedOperationException();/*
udanax-top.st:45856:MuSet methodsFor: 'operations'!
{void} storeAll: other {ScruSet} 
	"Sort of union.  Store into myself all elements from other.
	Turn myself into the union of my current self and other."
	other stepper forEach: [:elem {Heaper wimpy} | self store: elem]!
*/
}

/**
 * Sort of minus.  Wipe from myself all elements from other.
 * Turn myself into my current self minus other.
 */
public void wipeAll(ScruSet other) {
throw new UnsupportedOperationException();/*
udanax-top.st:45862:MuSet methodsFor: 'operations'!
{void} wipeAll: other {ScruSet} 
	"Sort of minus.  Wipe from myself all elements from other.
	Turn myself into my current self minus other."
	other stepper forEach: [:elem {Heaper wimpy} | self wipe: elem]!
*/
}

/**
 * Add anElement to my members, but only if it isn't already a member.
 * If it is already a member, BLAST
 */
public void introduce(Heaper anElement) {
throw new UnsupportedOperationException();/*
udanax-top.st:45870:MuSet methodsFor: 'adding-removing'!
{void} introduce: anElement {Heaper}
	"Add anElement to my members, but only if it isn't already a member.
	If it is already a member, BLAST"
	
	self subclassResponsibility!
*/
}

/**
 * Remove anElement from my members.  If it isn't currently a member, then BLAST
 */
public void remove(Heaper anElement) {
throw new UnsupportedOperationException();/*
udanax-top.st:45876:MuSet methodsFor: 'adding-removing'!
{void} remove: anElement {Heaper}
	"Remove anElement from my members.  If it isn't currently a member, then BLAST"
	
	self subclassResponsibility!
*/
}

/**
 * Add anElement to my set of members.  No semantic effect if anElement is already a member.
 */
public void store(Heaper anElement) {
throw new UnsupportedOperationException();/*
udanax-top.st:45881:MuSet methodsFor: 'adding-removing'!
{void} store: anElement {Heaper}
	"Add anElement to my set of members.  No semantic effect if anElement is already a member."
	
	self subclassResponsibility!
*/
}

/**
 * make anElement no longer be one of my members.  No semantic effect if it already isn't a
 * member.
 */
public void wipe(Heaper anElement) {
throw new UnsupportedOperationException();/*
udanax-top.st:45886:MuSet methodsFor: 'adding-removing'!
{void} wipe: anElement {Heaper}
	"make anElement no longer be one of my members.  No semantic effect if it already isn't a member."
	
	self subclassResponsibility!
*/
}

public ScruSet copy() {
throw new UnsupportedOperationException();/*
udanax-top.st:45893:MuSet methodsFor: 'creation'!
{ScruSet} copy
	self subclassResponsibility!
*/
}

public ImmuSet asImmuSet() {
throw new UnsupportedOperationException();/*
udanax-top.st:45898:MuSet methodsFor: 'conversion'!
{ImmuSet} asImmuSet
	self isEmpty ifTrue: [^ ImmuSet make].
	self count == 1 ifTrue: [^ ImmuSet make with: (self theOne)].
	^ ImmuSet make: self!
*/
}

public MuSet asMuSet() {
throw new UnsupportedOperationException();/*
udanax-top.st:45903:MuSet methodsFor: 'conversion'!
{MuSet} asMuSet
	^ self copy quickCast: MuSet!
*/
}

public IntegerVar count() {
throw new UnsupportedOperationException();/*
udanax-top.st:45908:MuSet methodsFor: 'enumerating'!
{IntegerVar} count
	self subclassResponsibility!
*/
}

public Stepper stepper() {
throw new UnsupportedOperationException();/*
udanax-top.st:45911:MuSet methodsFor: 'enumerating'!
{Stepper} stepper
	self subclassResponsibility!
*/
}

public Stepper immuStepper() {
throw new UnsupportedOperationException();/*
udanax-top.st:45916:MuSet methodsFor: 'private: enumerating'!
{Stepper} immuStepper
	self subclassResponsibility!
*/
}

public int actualHashForEqual() {
throw new UnsupportedOperationException();/*
udanax-top.st:45921:MuSet methodsFor: 'generated:'!
actualHashForEqual ^self asOop!
*/
}

public boolean isEqual(Object other) {
throw new UnsupportedOperationException();/*
udanax-top.st:45923:MuSet methodsFor: 'generated:'!
isEqual: other ^self == other!
*/
}

/**
 * someSize is a non-semantic hint about how big the set might get.
 */
public static Heaper make(XnRegion region) {
throw new UnsupportedOperationException();/*
udanax-top.st:45938:MuSet class methodsFor: 'smalltalk: passe'!
make.Region: region {XnRegion} 
	"someSize is a non-semantic hint about how big the set might get."
	| result {MuSet} |
	self passe.
	result _ ActualHashSet make.IntegerVar: region count.
	region stepper forEach: [:position {Position} | result store: position].
	^result!
*/
}

public static MuSet fromStepper(Stepper stepper) {
throw new UnsupportedOperationException();/*
udanax-top.st:45949:MuSet class methodsFor: 'pseudo constructors'!
{MuSet} fromStepper: stepper {Stepper}
	| result {MuSet} |
	result _ MuSet make.
	stepper forEach: [ :element {Heaper} |
		result store: element].
	^result!
*/
}

public static Heaper make() {
throw new UnsupportedOperationException();/*
udanax-top.st:45956:MuSet class methodsFor: 'pseudo constructors'!
{MuSet} make 
	^ActualHashSet make!
*/
}

public static Heaper make(Heaper item) {
throw new UnsupportedOperationException();/*
udanax-top.st:45959:MuSet class methodsFor: 'pseudo constructors'!
{MuSet} make.Heaper: item {Heaper}
	^ActualHashSet make.Heaper: item!
*/
}

/**
 * someSize is a non-semantic hint about how big the set might get.
 */
public static Heaper make(IntegerVar someSize) {
throw new UnsupportedOperationException();/*
udanax-top.st:45963:MuSet class methodsFor: 'pseudo constructors'!
{MuSet} make.IntegerVar: someSize {IntegerVar}
	"someSize is a non-semantic hint about how big the set might get."
	^ActualHashSet make.IntegerVar: someSize!
*/
}

public static Heaper make(Object something) {
throw new UnsupportedOperationException();/*
udanax-top.st:45969:MuSet class methodsFor: 'smalltalk: defaults'!
make: something
	(something isKindOf: Integer) ifTrue:
		[^self make.IntegerVar: something].
	^self make.Region: (something cast: XnRegion)!
*/
}

public static void initTimeNonInherited() {
throw new UnsupportedOperationException();/*
udanax-top.st:45976:MuSet class methodsFor: 'smalltalk: initialization'!
initTimeNonInherited
	self REQUIRES: ActualHashSet!
*/
}

public static void problems() {
throw new UnsupportedOperationException();/*
udanax-top.st:45982:MuSet class methodsFor: 'exceptions: exceptions'!
problems.AlreadyInSet
	^self signals: #(AlreadyInSet)!
*/
}
}
