/*
 * Abora-Gold
 * Part of the Abora hypertext project: http://www.abora.org
 * Copyright 2003 David G Jones
 * 
 * Translated from Udanax-Gold source code: http://www.udanax.com
 * Copyright 1979-1999 Udanax.com. All rights reserved
 */
package org.abora.gold.collection.grand;

import org.abora.gold.collection.grand.GrandEntry;
import org.abora.gold.snarf.Abraham;
import org.abora.gold.xcvr.Rcvr;
import org.abora.gold.xcvr.Xmtr;
import org.abora.gold.xpp.basic.Heaper;


/**
 * GrandEntries probably want to not be remembered right when they are created,
 * and remembered when they are finally put into their place in the GrandDataPages
 * or GrandOverflows
 */
public class GrandEntry extends Abraham {
	protected Heaper objectInternal;
/*
udanax-top.st:6517:
Abraham subclass: #GrandEntry
	instanceVariableNames: 'objectInternal {Heaper}'
	classVariableNames: ''
	poolDictionaries: ''
	category: 'Xanadu-Collection-Grand'!
*/
/*
udanax-top.st:6521:
GrandEntry comment:
'GrandEntries probably want to not be remembered right when they are created,
and remembered when they are finally put into their place in the GrandDataPages
or GrandOverflows'!
*/
/*
udanax-top.st:6525:
(GrandEntry getOrMakeCxxClassDescription)
	attributes: ((Set new) add: #DEFERRED; add: #COPY; add: #SHEPHERD.PATRIARCH; add: #DEFERRED.LOCKED; yourself)!
*/

public Heaper value() {
throw new UnsupportedOperationException();/*
udanax-top.st:6530:GrandEntry methodsFor: 'accessing'!
{Heaper} value
	objectInternal == NULL ifTrue: [Heaper BLAST: #NotInTable].
	^ objectInternal!
*/
}

public  GrandEntry(Heaper value, int hash) {
throw new UnsupportedOperationException();/*
udanax-top.st:6536:GrandEntry methodsFor: 'protected: creation'!
create: value {Heaper} with: hash {UInt32}
	super create: hash.
	value == NULL ifTrue: [Heaper BLAST: #NullInsertion].
	[value == nil ifTrue: [Heaper BLAST: #NullInsertion]] smalltalkOnly.
	objectInternal _ value.!
*/
}

public boolean compare(Heaper anObj) {
throw new UnsupportedOperationException();/*
udanax-top.st:6544:GrandEntry methodsFor: 'deferred: testing'!
{BooleanVar} compare: anObj {Heaper | Position}
	self subclassResponsibility!
*/
}

public boolean matches(GrandEntry anEntry) {
throw new UnsupportedOperationException();/*
udanax-top.st:6547:GrandEntry methodsFor: 'deferred: testing'!
{BooleanVar} matches: anEntry {GrandEntry}
	self subclassResponsibility!
*/
}

public int contentsHash() {
throw new UnsupportedOperationException();/*
udanax-top.st:6552:GrandEntry methodsFor: 'testing'!
{UInt32} contentsHash
	^(super contentsHash
		bitXor: (IntegerPos integerHash: self hashForEqual))
		bitXor: objectInternal hashForEqual!
*/
}

public  GrandEntry(Rcvr receiver) {
throw new UnsupportedOperationException();/*
udanax-top.st:6560:GrandEntry methodsFor: 'generated:'!
create.Rcvr: receiver {Rcvr}
	super create.Rcvr: receiver.
	objectInternal _ receiver receiveHeaper.!
*/
}

public void sendSelfTo(Xmtr xmtr) {
throw new UnsupportedOperationException();/*
udanax-top.st:6564:GrandEntry methodsFor: 'generated:'!
{void} sendSelfTo: xmtr {Xmtr}
	super sendSelfTo: xmtr.
	xmtr sendHeaper: objectInternal.!
*/
}
}
