/*
 * Abora-Gold
 * Part of the Abora hypertext project: http://www.abora.org
 * Copyright 2003 David G Jones
 * 
 * Translated from Udanax-Gold source code: http://www.udanax.com
 * Copyright 1979-1999 Udanax.com. All rights reserved
 */
package org.abora.gold.collection.grand;

import java.io.PrintWriter;
import org.abora.gold.collection.basic.PtrArray;
import org.abora.gold.collection.grand.GrandDataPage;
import org.abora.gold.collection.grand.GrandEntry;
import org.abora.gold.collection.grand.GrandOverflow;
import org.abora.gold.java.missing.IntegerVar;
import org.abora.gold.snarf.Abraham;
import org.abora.gold.xcvr.Rcvr;
import org.abora.gold.xcvr.Xmtr;
import org.abora.gold.xpp.basic.Heaper;


/**
 * oldOverflowRoot holds onto the overflow tree that was in place when a node doubling
 * starts.
 * It allows an object stored to be found at any time during the doubling.
 */
public class GrandNode extends Abraham {
	protected PtrArray primaryPages;
	protected int numPrimaries;
	protected GrandOverflow overflowRoot;
	protected GrandOverflow oldOverflowRoot;
	protected int numReinserters;
	protected static int OverflowPageSize;
/*
udanax-top.st:6678:
Abraham subclass: #GrandNode
	instanceVariableNames: '
		primaryPages {PtrArray of: GrandDataPage}
		numPrimaries {Int32}
		overflowRoot {GrandOverflow}
		oldOverflowRoot {GrandOverflow}
		numReinserters {Int32}'
	classVariableNames: 'OverflowPageSize {Int32} '
	poolDictionaries: ''
	category: 'Xanadu-Collection-Grand'!
*/
/*
udanax-top.st:6687:
GrandNode comment:
'oldOverflowRoot holds onto the overflow tree that was in place when a node doubling starts.
It allows an object stored to be found at any time during the doubling.'!
*/
/*
udanax-top.st:6690:
(GrandNode getOrMakeCxxClassDescription)
	friends:
'/- friends for class GrandNode -/
friend class GrandNodeStepper;
friend class GrandNodeDoubler;
friend class GrandNodeReinserter;
';
	attributes: ((Set new) add: #LOCKED; add: #COPY; add: #SHEPHERD.PATRIARCH; add: #CONCRETE; yourself)!
*/
/*
udanax-top.st:6892:
GrandNode class
	instanceVariableNames: ''!
*/
/*
udanax-top.st:6895:
(GrandNode getOrMakeCxxClassDescription)
	friends:
'/- friends for class GrandNode -/
friend class GrandNodeStepper;
friend class GrandNodeDoubler;
friend class GrandNodeReinserter;
';
	attributes: ((Set new) add: #LOCKED; add: #COPY; add: #SHEPHERD.PATRIARCH; add: #CONCRETE; yourself)!
*/

public Heaper fetch(Heaper toMatch, int aHash) {
throw new UnsupportedOperationException();/*
udanax-top.st:6701:GrandNode methodsFor: 'accessing'!
{Heaper} fetch: toMatch {Heaper | Position} with: aHash {UInt32}
	| result {Heaper} |
	result _ ((primaryPages fetch: aHash \\ numPrimaries) cast: GrandDataPage)
		fetch: toMatch with: aHash with: numPrimaries.
	result ~~ NULL ifTrue:
		[ ^ result ].
	oldOverflowRoot ~~ NULL ifTrue:
		[^oldOverflowRoot fetch: toMatch with: aHash].
	^ NULL!
*/
}

public void store(GrandEntry newEntry) {
throw new UnsupportedOperationException();/*
udanax-top.st:6711:GrandNode methodsFor: 'accessing'!
{void} store.Entry: newEntry {GrandEntry}
	((primaryPages fetch: newEntry hashForEqual \\ numPrimaries) cast: GrandDataPage)
		store.Entry: newEntry with: numPrimaries!
*/
}

public void wipe(Heaper toMatch, int aHash) {
throw new UnsupportedOperationException();/*
udanax-top.st:6715:GrandNode methodsFor: 'accessing'!
{void} wipe: toMatch {Heaper | Position} with: aHash {UInt32} 
	((primaryPages fetch: aHash \\ numPrimaries) cast: GrandDataPage)
		wipe: toMatch with: aHash with: numPrimaries.
	oldOverflowRoot ~~ NULL ifTrue:
		[oldOverflowRoot wipe: toMatch with: aHash]!
*/
}

public void printOn(PrintWriter aStream) {
throw new UnsupportedOperationException();/*
udanax-top.st:6723:GrandNode methodsFor: 'printing'!
{void} printOn: aStream {ostream reference}
	aStream << 'GrandNode(numPages=' << numPrimaries << ')'!
*/
}

public  GrandNode() {
throw new UnsupportedOperationException();/*
udanax-top.st:6728:GrandNode methodsFor: 'protected: creation'!
create
	| aPage {GrandDataPage} |
	super create.
	overflowRoot _ NULL.
	oldOverflowRoot _ NULL.
	numReinserters _ Int32Zero.
	numPrimaries _ 1.
	primaryPages _ PtrArray nulls: 1.
	aPage _ GrandDataPage make: GrandNode primaryPageSize with: self with: UInt32Zero.
	primaryPages at: Int32Zero store: aPage.
	self newShepherd.
	self remember!
*/
}

public void dismantle() {
throw new UnsupportedOperationException();/*
udanax-top.st:6741:GrandNode methodsFor: 'protected: creation'!
{void} dismantle
	DiskManager consistent: 2 + numPrimaries with:
		[| page {Heaper} |
		primaryPages ~~ NULL ifTrue:
			[Int32Zero almostTo: numPrimaries do: [:i {Int32} |
				page _ (primaryPages fetch: i).
				page ~~ NULL ifTrue:
				[page destroy]].
			primaryPages destroy].
		overflowRoot ~~ NULL 
			ifTrue: [overflowRoot destroy].
		oldOverflowRoot ~~ NULL
			ifTrue: [oldOverflowRoot destroy].
		super dismantle]!
*/
}

public void addReinserter() {
throw new UnsupportedOperationException();/*
udanax-top.st:6758:GrandNode methodsFor: 'node doubling'!
{void} addReinserter
	DiskManager consistent: 1 with:
		[numReinserters _ numReinserters + 1.
		self diskUpdate]!
*/
}

public void doubleNode() {
throw new UnsupportedOperationException();/*
udanax-top.st:6763:GrandNode methodsFor: 'node doubling'!
{void} doubleNode
	| newPage {GrandDataPage} newNumPrimaries {Int32} newPrimaries {PtrArray of: GrandDataPage} |
	
	DiskManager consistent: self doubleNodeConsistency with: 
		[newNumPrimaries _ numPrimaries * 2.
		newPrimaries _ PtrArray nulls: newNumPrimaries.
		Int32Zero almostTo: numPrimaries do:
			[:i {Int32} | 
			newPage _ ((primaryPages fetch: i) cast: GrandDataPage) makeDouble: newNumPrimaries.
			newPrimaries at: i store: (primaryPages fetch: i).
			newPrimaries at: newPage lowHashBits store: newPage].
		primaryPages destroy.
		primaryPages _ newPrimaries.
		numPrimaries _ newNumPrimaries.
		"At this point, the structure is consistent, but still doesn't have the full benefit of the node
		doubling.  Inserts will be faster now, but reinsertion of the overflow data is required for fetch
		to improve."
		overflowRoot ~~ NULL ifTrue:
			[oldOverflowRoot ~~ NULL ifTrue:
				[Heaper BLAST: #FallenBehindInNodeDoubling].
			oldOverflowRoot _ overflowRoot.
			overflowRoot _ NULL.
			(GrandNodeReinserter make: self with: oldOverflowRoot) schedule].
		self diskUpdate].!
*/
}

public IntegerVar doubleNodeConsistency() {
throw new UnsupportedOperationException();/*
udanax-top.st:6790:GrandNode methodsFor: 'node doubling'!
{IntegerVar} doubleNodeConsistency
	Eric knownBug. "Sometimes this is off by one in either direction"
	^ 2 * numPrimaries + 2!
*/
}

public void removeReinserter() {
throw new UnsupportedOperationException();/*
udanax-top.st:6794:GrandNode methodsFor: 'node doubling'!
{void} removeReinserter
	DiskManager consistent: 1 with:
		[numReinserters _ numReinserters - 1.
		numReinserters == Int32Zero ifTrue:
			[oldOverflowRoot destroy.
			oldOverflowRoot _ NULL].
		self diskUpdate]!
*/
}

public GrandDataPage pageAt(IntegerVar idx) {
throw new UnsupportedOperationException();/*
udanax-top.st:6804:GrandNode methodsFor: 'private: friendly access'!
{GrandDataPage} pageAt: idx {IntegerVar}
	^ (primaryPages fetch: idx DOTasLong) cast: GrandDataPage!
*/
}

public IntegerVar pageCount() {
throw new UnsupportedOperationException();/*
udanax-top.st:6807:GrandNode methodsFor: 'private: friendly access'!
{IntegerVar} pageCount
	^ numPrimaries!
*/
}

public int contentsHash() {
throw new UnsupportedOperationException();/*
udanax-top.st:6812:GrandNode methodsFor: 'testing'!
{UInt32} contentsHash
	| result {UInt32} |
	
	result _ ((super contentsHash
		bitXor: primaryPages contentsHash)
		bitXor: (IntegerPos integerHash: numPrimaries)).
	
	overflowRoot ~~ NULL ifTrue:
		[result _ result bitXor: overflowRoot hashForEqual].
		
	oldOverflowRoot ~~ NULL ifTrue:
		[result _ result bitXor: oldOverflowRoot hashForEqual].
		
	^ result!
*/
}

public boolean isEmpty() {
throw new UnsupportedOperationException();/*
udanax-top.st:6827:GrandNode methodsFor: 'testing'!
{BooleanVar} isEmpty
	UInt32Zero almostTo: numPrimaries do: [ :i {UInt32} |
		((primaryPages fetch: i) cast: GrandDataPage) isEmpty ifFalse: [ ^ false ]].
	^ overflowRoot == NULL and: [oldOverflowRoot == NULL]!
*/
}

public void inspect() {
throw new UnsupportedOperationException();/*
udanax-top.st:6834:GrandNode methodsFor: 'smalltalk: inspection'!
inspect
	EntView make: self!
*/
}

public static void inspectPieces() {
throw new UnsupportedOperationException();/*
udanax-top.st:6837:GrandNode methodsFor: 'smalltalk: inspection'!
inspectPieces
	| result |
	result _ primaryPages asOrderedCollection.
	overflowRoot ~~ NULL ifTrue:
		[result add: overflowRoot].
	oldOverflowRoot ~~ NULL ifTrue:
		[result add: oldOverflowRoot].
	^result!
*/
}

public GrandOverflow fetchOldOverflow() {
throw new UnsupportedOperationException();/*
udanax-top.st:6848:GrandNode methodsFor: 'overflow'!
{GrandOverflow} fetchOldOverflow
	^ oldOverflowRoot!
*/
}

public GrandOverflow fetchOverflow() {
throw new UnsupportedOperationException();/*
udanax-top.st:6851:GrandNode methodsFor: 'overflow'!
{GrandOverflow} fetchOverflow
	
	^overflowRoot!
*/
}

public GrandOverflow getOverflow() {
throw new UnsupportedOperationException();/*
udanax-top.st:6855:GrandNode methodsFor: 'overflow'!
{GrandOverflow} getOverflow
	
	overflowRoot == NULL
		ifTrue: 
			[DiskManager consistent: 2 with:
				[overflowRoot _ GrandOverflow create: OverflowPageSize with: 1.
				self diskUpdate]].
	^overflowRoot!
*/
}

public double loadFactor() {
throw new UnsupportedOperationException();/*
udanax-top.st:6866:GrandNode methodsFor: 'special'!
{IEEEDoubleVar} loadFactor
	| loadSum {IEEEDoubleVar} |
	loadSum _ 0.0.
	Int32Zero almostTo: numPrimaries do: [ :i {Int32} |
		loadSum _ loadSum + (((primaryPages fetch: i) cast: GrandDataPage) loadFactor)].
	^ loadSum / numPrimaries!
*/
}

public  GrandNode(Rcvr receiver) {
throw new UnsupportedOperationException();/*
udanax-top.st:6875:GrandNode methodsFor: 'generated:'!
create.Rcvr: receiver {Rcvr}
	super create.Rcvr: receiver.
	primaryPages _ receiver receiveHeaper.
	numPrimaries _ receiver receiveInt32.
	overflowRoot _ receiver receiveHeaper.
	oldOverflowRoot _ receiver receiveHeaper.
	numReinserters _ receiver receiveInt32.!
*/
}

public void sendSelfTo(Xmtr xmtr) {
throw new UnsupportedOperationException();/*
udanax-top.st:6883:GrandNode methodsFor: 'generated:'!
{void} sendSelfTo: xmtr {Xmtr}
	super sendSelfTo: xmtr.
	xmtr sendHeaper: primaryPages.
	xmtr sendInt32: numPrimaries.
	xmtr sendHeaper: overflowRoot.
	xmtr sendHeaper: oldOverflowRoot.
	xmtr sendInt32: numReinserters.!
*/
}

public static void linkTimeNonInherited() {
throw new UnsupportedOperationException();/*
udanax-top.st:6906:GrandNode class methodsFor: 'smalltalk: smalltalk initialization'!
linkTimeNonInherited
	OverflowPageSize _ 8!
*/
}

public static Heaper make() {
throw new UnsupportedOperationException();/*
udanax-top.st:6911:GrandNode class methodsFor: 'create'!
make
	^ self create!
*/
}

public static int primaryPageSize() {
throw new UnsupportedOperationException();/*
udanax-top.st:6916:GrandNode class methodsFor: 'static functions'!
{Int32 INLINE} primaryPageSize
	^ 128!
*/
}
}
