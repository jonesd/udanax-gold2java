/*
 * Abora-Gold
 * Part of the Abora hypertext project: http://www.abora.org
 * Copyright 2003 David G Jones
 * 
 * Translated from Udanax-Gold source code: http://www.udanax.com
 * Copyright 1979-1999 Udanax.com. All rights reserved
 */
package org.abora.gold.collection.grand;

import org.abora.gold.collection.basic.PtrArray;
import org.abora.gold.collection.basic.UInt32Array;
import org.abora.gold.collection.grand.ExponentialHashMap;
import org.abora.gold.xpp.basic.Heaper;


public class ExponentialHashMap extends Heaper {
	protected int domain;
	protected UInt32Array rBottoms;
	protected UInt32Array rSizes;
	protected UInt32Array dBottoms;
	protected int dSize;
	protected static PtrArray FastHashMap;
	protected static int HashBits;
	protected static ExponentialHashMap TheExponentialMap;
/*
udanax-top.st:18950:
Heaper subclass: #ExponentialHashMap
	instanceVariableNames: '
		domain {Int32}
		rBottoms {UInt32Array}
		rSizes {UInt32Array}
		dBottoms {UInt32Array}
		dSize {Int32}'
	classVariableNames: '
		FastHashMap {PtrArray} 
		HashBits {UInt32} 
		TheExponentialMap {ExponentialHashMap} '
	poolDictionaries: ''
	category: 'Xanadu-Collection-Grand'!
*/
/*
udanax-top.st:18962:
(ExponentialHashMap getOrMakeCxxClassDescription)
	attributes: ((Set new) add: #CONCRETE; yourself)!
*/
/*
udanax-top.st:19004:
ExponentialHashMap class
	instanceVariableNames: ''!
*/
/*
udanax-top.st:19007:
(ExponentialHashMap getOrMakeCxxClassDescription)
	attributes: ((Set new) add: #CONCRETE; yourself)!
*/

public int of(int aHash) {
throw new UnsupportedOperationException();/*
udanax-top.st:18967:ExponentialHashMap methodsFor: 'mapping'!
{UInt32} of: aHash {UInt32}
	| pieceIndex {Int32} |
	(aHash > domain)
		ifTrue: [ Heaper BLAST: #outOfDomain ].
	pieceIndex _ aHash // dSize.
	^ (rBottoms uIntAt: pieceIndex) + ((aHash - (dBottoms uIntAt: pieceIndex))
		* (rSizes uIntAt: pieceIndex) // dSize)!
*/
}

public  ExponentialHashMap(int numPieces, int range) {
throw new UnsupportedOperationException();/*
udanax-top.st:18977:ExponentialHashMap methodsFor: 'creation'!
create: numPieces {Int32} with: range {UInt32} 
	| rBottom {UInt32} |
	super create.
	domain _ range.
	dSize _ range // numPieces.
	"Depends on image having UInt32 _ Integer."
	rBottoms _ UInt32Array make: numPieces.
	rSizes _ UInt32Array make: numPieces.
	dBottoms _ UInt32Array make: numPieces.
	rBottom _ UInt32Zero.
	UInt32Zero almostTo: numPieces do: [ :d {UInt32} |
		dBottoms at: d storeUInt: d * dSize.
		rBottoms at: d storeUInt: rBottom.
		rBottom _ self expFunc: d + 1 * dSize within: range.
		rSizes at: d storeUInt: rBottom - (rBottoms uIntAt: d)].!
*/
}

public int expFuncWithin(int domElem, int range) {
throw new UnsupportedOperationException();/*
udanax-top.st:18995:ExponentialHashMap methodsFor: 'private: calculation'!
{UInt32} expFunc: domElem {UInt32} within: range {UInt32} 
	^(range * ((2.0 raisedTo: domElem asFloat / range asFloat) - 1)) asInteger!
*/
}

public int actualHashForEqual() {
throw new UnsupportedOperationException();/*
udanax-top.st:19000:ExponentialHashMap methodsFor: 'testing'!
{UInt32} actualHashForEqual
	^Heaper takeOop!
*/
}

public static int exponentialMap(int aHash) {
throw new UnsupportedOperationException();/*
udanax-top.st:19012:ExponentialHashMap class methodsFor: 'accessing'!
{UInt32 INLINE} exponentialMap: aHash {UInt32}
	^ (TheExponentialMap of:  ((FHash fastHash.UInt32: aHash) bitAnd: HashBits)) bitAnd: HashBits!
*/
}

public static int hashBits() {
throw new UnsupportedOperationException();/*
udanax-top.st:19015:ExponentialHashMap class methodsFor: 'accessing'!
{UInt32 INLINE} hashBits
	^ HashBits!
*/
}

/**
 * ExponentialHashMap initTimeNonInherited
 */
public static void initTimeNonInherited() {
throw new UnsupportedOperationException();/*
udanax-top.st:19020:ExponentialHashMap class methodsFor: 'smalltalk: init'!
initTimeNonInherited
	"ExponentialHashMap initTimeNonInherited"
	
	TheExponentialMap _  ExponentialHashMap create: 256 with: HashBits + 1.
	[| rand {RandomStepper} |
	rand _ RandomStepper make: 43 with: 11 with: 5.
	FastHashMap _ PtrArray nulls: 8.
	UInt32Zero to: 7 do:
		[:i {UInt32} |
		| array {UInt32Array} |
		array _ UInt32Array make: 256.
		UInt32Zero to: 255 do: 
			[: j {UInt32} |
			array at: j storeUInt: rand value.
			rand step].
		FastHashMap at: i store: array]] smalltalkOnly!
*/
}

/**
 * ExponentialHashMap linkTimeNonInherited
 */
public static void linkTimeNonInherited() {
throw new UnsupportedOperationException();/*
udanax-top.st:19037:ExponentialHashMap class methodsFor: 'smalltalk: init'!
linkTimeNonInherited
	"ExponentialHashMap linkTimeNonInherited"
	
	HashBits _ (1 bitShift: 30) - 1.
	TheExponentialMap _ NULL.
	[HashBits _ SmallInteger maxVal // 2 - 1] smalltalkOnly.
	[FastHashMap _ NULL] smalltalkOnly!
*/
}
}
