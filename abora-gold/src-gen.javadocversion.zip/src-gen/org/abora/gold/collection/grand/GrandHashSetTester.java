/*
 * Abora-Gold
 * Part of the Abora hypertext project: http://www.abora.org
 * Copyright 2003 David G Jones
 * 
 * Translated from Udanax-Gold source code: http://www.udanax.com
 * Copyright 1979-1999 Udanax.com. All rights reserved
 */
package org.abora.gold.collection.grand;

import java.io.PrintWriter;
import org.abora.gold.collection.sets.ScruSet;
import org.abora.gold.collection.steppers.Stepper;
import org.abora.gold.testing.MuSetTester;
import org.abora.gold.xcvr.Rcvr;
import org.abora.gold.xcvr.Xmtr;


public class GrandHashSetTester extends MuSetTester {
/*
udanax-top.st:60643:
MuSetTester subclass: #GrandHashSetTester
	instanceVariableNames: ''
	classVariableNames: ''
	poolDictionaries: ''
	category: 'Xanadu-Collection-Grand'!
*/
/*
udanax-top.st:60647:
(GrandHashSetTester getOrMakeCxxClassDescription)
	attributes: ((Set new) add: #CONCRETE; add: #(COPY boot ); yourself)!
*/

public void allTestsOn(PrintWriter oo) {
throw new UnsupportedOperationException();/*
udanax-top.st:60652:GrandHashSetTester methodsFor: 'testing'!
{void} allTestsOn: oo {ostream reference} 
	
	oo << 'GrandHashSet testing
'.
	super allTestsOn: oo.
	oo << 'End of GrandHashSet testing
'!
*/
}

public ScruSet generateSet() {
throw new UnsupportedOperationException();/*
udanax-top.st:60662:GrandHashSetTester methodsFor: 'accessing'!
{ScruSet} generateSet
	^ GrandHashSet make: 2!
*/
}

public ScruSet generateSetContaining(Stepper stuff) {
throw new UnsupportedOperationException();/*
udanax-top.st:60666:GrandHashSetTester methodsFor: 'accessing'!
{ScruSet} generateSetContaining: stuff {Stepper}
	| t {MuSet} |
	t _ GrandHashSet make: 2.
	stuff forEach: [:e {Heaper} |
		t store: e].
	^ t!
*/
}

public  GrandHashSetTester(Rcvr receiver) {
	super(receiver);
throw new UnsupportedOperationException();/*
udanax-top.st:60675:GrandHashSetTester methodsFor: 'generated:'!
create.Rcvr: receiver {Rcvr}
	super create.Rcvr: receiver.!
*/
}

public void sendSelfTo(Xmtr xmtr) {
throw new UnsupportedOperationException();/*
udanax-top.st:60678:GrandHashSetTester methodsFor: 'generated:'!
{void} sendSelfTo: xmtr {Xmtr}
	super sendSelfTo: xmtr.!
*/
}
}
