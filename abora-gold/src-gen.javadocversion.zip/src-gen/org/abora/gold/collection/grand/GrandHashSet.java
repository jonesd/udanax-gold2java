/*
 * Abora-Gold
 * Part of the Abora hypertext project: http://www.abora.org
 * Copyright 2003 David G Jones
 * 
 * Translated from Udanax-Gold source code: http://www.udanax.com
 * Copyright 1979-1999 Udanax.com. All rights reserved
 */
package org.abora.gold.collection.grand;

import java.io.PrintWriter;
import org.abora.gold.collection.basic.PtrArray;
import org.abora.gold.collection.grand.GrandNode;
import org.abora.gold.collection.sets.ImmuSet;
import org.abora.gold.collection.sets.MuSet;
import org.abora.gold.collection.sets.ScruSet;
import org.abora.gold.collection.steppers.Stepper;
import org.abora.gold.counter.Counter;
import org.abora.gold.java.missing.IntegerVar;
import org.abora.gold.xcvr.Rcvr;
import org.abora.gold.xcvr.Xmtr;
import org.abora.gold.xpp.basic.Heaper;


public class GrandHashSet extends MuSet {
	protected PtrArray grandNodes;
	protected int numNodes;
	protected int nodeIndexShift;
	protected Counter myTally;
	protected Counter myDoublingFrontIndex;
	protected Counter myDoublingPasses;
	protected int cacheHash;
	protected Heaper cacheValue;
	protected IntegerVar myOutstandingSteppers;
/*
udanax-top.st:45985:
MuSet subclass: #GrandHashSet
	instanceVariableNames: '
		grandNodes {PtrArray copy of: GrandNode}
		numNodes {Int32 copy}
		nodeIndexShift {Int32 copy}
		myTally {Counter copy}
		myDoublingFrontIndex {Counter copy}
		myDoublingPasses {Counter copy}
		cacheHash {UInt32 NOCOPY}
		cacheValue {Heaper wimpy NOCOPY}
		myOutstandingSteppers {IntegerVar NOCOPY}'
	classVariableNames: ''
	poolDictionaries: ''
	category: 'Xanadu-Collection-Grand'!
*/
/*
udanax-top.st:45998:
(GrandHashSet getOrMakeCxxClassDescription)
	friends:
'/- friends for class GrandHashSet -/
friend SPTR(GrandHashSet)  grandHashSet ();
friend SPTR(GrandHashSet)  grandHashSet (Int4 nNodes);
friend class GrandHashSetStepper;
';
	attributes: ((Set new) add: #CONCRETE; add: #COPY; yourself)!
*/
/*
udanax-top.st:46234:
GrandHashSet class
	instanceVariableNames: ''!
*/
/*
udanax-top.st:46237:
(GrandHashSet getOrMakeCxxClassDescription)
	friends:
'/- friends for class GrandHashSet -/
friend SPTR(GrandHashSet)  grandHashSet ();
friend SPTR(GrandHashSet)  grandHashSet (Int4 nNodes);
friend class GrandHashSetStepper;
';
	attributes: ((Set new) add: #CONCRETE; add: #COPY; yourself)!
*/

public void introduce(Heaper aHeaper) {
throw new UnsupportedOperationException();/*
udanax-top.st:46009:GrandHashSet methodsFor: 'adding-removing'!
{void} introduce: aHeaper {Heaper}
	| hash {UInt32} node {GrandNode} |
	self checkSteppers.
	aHeaper == NULL ifTrue: [Heaper BLAST: #NullInsertion].
	hash _ ExponentialHashMap exponentialMap: aHeaper hashForEqual.
	node _ (grandNodes fetch: hash // nodeIndexShift) cast: GrandNode.
	(node fetch: aHeaper with: hash) ~~ NULL
		ifTrue: [Heaper BLAST: #AlreadyInSet]
		ifFalse: [| newEntry {GrandEntry} |
				DiskManager consistent: 6 with:
					[newEntry _ GrandSetEntry make: aHeaper with: hash.
					node store.Entry: newEntry]].
	myTally increment.
	self considerNeedForDoubling.
	self invalidateCache.!
*/
}

public void remove(Heaper aHeaper) {
throw new UnsupportedOperationException();/*
udanax-top.st:46026:GrandHashSet methodsFor: 'adding-removing'!
{void} remove: aHeaper {Heaper} 
	((self hasMember: aHeaper) == NULL) 
		ifTrue: [Heaper BLAST: #NotInSet]
		ifFalse: [self wipe: aHeaper]!
*/
}

public void store(Heaper aHeaper) {
throw new UnsupportedOperationException();/*
udanax-top.st:46032:GrandHashSet methodsFor: 'adding-removing'!
{void} store: aHeaper {Heaper} 
	| hash {UInt32} node {GrandNode} newEntry {GrandEntry} test {BooleanVar} |
	self checkSteppers.
	aHeaper == NULL ifTrue: [Heaper BLAST: #NullInsertion].
	hash _ ExponentialHashMap exponentialMap: aHeaper hashForEqual.
	node _ (grandNodes fetch: hash // nodeIndexShift) cast: GrandNode.
	test _ (node fetch: aHeaper with: hash) == NULL.
	DiskManager consistent: 6 with:
		[newEntry _ GrandSetEntry make: aHeaper with: hash.
		node store.Entry: newEntry].
	test ifTrue: 
		[myTally increment.
		self considerNeedForDoubling].
	self invalidateCache.!
*/
}

public void wipe(Heaper aHeaper) {
throw new UnsupportedOperationException();/*
udanax-top.st:46047:GrandHashSet methodsFor: 'adding-removing'!
{void} wipe: aHeaper {Heaper} 
	| hash {UInt32} node {GrandNode} |
	self checkSteppers.
	hash _ ExponentialHashMap exponentialMap: aHeaper hashForEqual.
	node _ (grandNodes fetch: hash // nodeIndexShift) cast: GrandNode.
	(node fetch: aHeaper with: hash) ~~ NULL
		ifTrue: 
			[node wipe: aHeaper with: hash.
			myTally decrement]!
*/
}

public IntegerVar count() {
throw new UnsupportedOperationException();/*
udanax-top.st:46059:GrandHashSet methodsFor: 'accessing'!
{IntegerVar} count
	^myTally count!
*/
}

public boolean hasMember(Heaper aHeaper) {
throw new UnsupportedOperationException();/*
udanax-top.st:46063:GrandHashSet methodsFor: 'accessing'!
{BooleanVar} hasMember: aHeaper {Heaper} 
	| hash {UInt32} result {Heaper} |
	hash _ ExponentialHashMap exponentialMap: aHeaper hashForEqual.
	"(cacheKey ~~ NULL and: [cacheHash == hash and: [cacheKey isEqual: key]]) ifTrue: [ ^ cacheValue ]."
	result _ ((grandNodes fetch: hash // nodeIndexShift) cast: GrandNode) fetch: aHeaper with: hash.
	"result ~~ NULL ifTrue:
		[cacheHash _ hash.
		 cacheKey _ key.
		 cacheValue _ result]."
	^ result ~~ NULL!
*/
}

public boolean isEmpty() {
throw new UnsupportedOperationException();/*
udanax-top.st:46076:GrandHashSet methodsFor: 'testing'!
{BooleanVar} isEmpty
	^myTally count == IntegerVar0!
*/
}

public ImmuSet asImmuSet() {
throw new UnsupportedOperationException();/*
udanax-top.st:46082:GrandHashSet methodsFor: 'conversion'!
{ImmuSet} asImmuSet
	self willNotImplement.
	^ NULL!
*/
}

public MuSet asMuSet() {
throw new UnsupportedOperationException();/*
udanax-top.st:46086:GrandHashSet methodsFor: 'conversion'!
{MuSet} asMuSet
	self willNotImplement.
	^ NULL!
*/
}

public ScruSet copy() {
throw new UnsupportedOperationException();/*
udanax-top.st:46092:GrandHashSet methodsFor: 'creation'!
{ScruSet} copy
	| newSet {MuSet} |
	newSet _ GrandHashSet make: numNodes.
	self stepper forEach:
		[:e {Heaper} |
		newSet store: e].
	^ newSet!
*/
}

public void printOn(PrintWriter aStream) {
throw new UnsupportedOperationException();/*
udanax-top.st:46102:GrandHashSet methodsFor: 'printing'!
{void} printOn: aStream {ostream reference}
	aStream << 'GrandHashSet(' << self count << ' entries over ' << numNodes << ' nodes)'!
*/
}

public void printOnWithSimpleSyntax(PrintWriter oo, String open, String sep, String close) {
throw new UnsupportedOperationException();/*
udanax-top.st:46105:GrandHashSet methodsFor: 'printing'!
{void} printOnWithSimpleSyntax: oo {ostream reference} with: open {char star} with: sep {char star} with: close {char star} 
	| stomp {Stepper} |
	oo << open.
	self isEmpty
		ifTrue: [oo << 'empty']
		ifFalse: 
			[stomp _ self stepper.
			[stomp hasValue]
				whileTrue: 
					[oo << stomp fetch.
					stomp step.
					stomp hasValue ifTrue: [oo << sep]].
			stomp destroy].
	oo << close!
*/
}

public Stepper stepper() {
throw new UnsupportedOperationException();/*
udanax-top.st:46122:GrandHashSet methodsFor: 'enumerating'!
{Stepper} stepper
	^ GrandHashSetStepper create: self!
*/
}

public  GrandHashSet(int nNodes) {
throw new UnsupportedOperationException();/*
udanax-top.st:46127:GrandHashSet methodsFor: 'protected: creation'!
create: nNodes {Int32}
	| aNode {GrandNode} |
	super create. 
	numNodes _ nNodes.
	nodeIndexShift _ ExponentialHashMap hashBits // numNodes.
	grandNodes _ PtrArray nulls: numNodes.
	DiskManager consistent: 2 * numNodes + 3 with:
		[Int32Zero almostTo: numNodes do: [:i {Int32} | 
			aNode _ GrandNode make.
			grandNodes at: i store: aNode].
		myTally _ Counter make.
		myDoublingFrontIndex _ Counter make.
		myDoublingPasses _ Counter make].
	myOutstandingSteppers _ IntegerVarZero.
	self invalidateCache!
*/
}

public void destruct() {
throw new UnsupportedOperationException();/*
udanax-top.st:46143:GrandHashSet methodsFor: 'protected: creation'!
{void} destruct
 	| temp {Heaper} |
 	self checkSteppers.
 	DiskManager consistent: numNodes with:
		[UInt32Zero almostTo: numNodes do:
			[:i {UInt32} |
			(temp _ grandNodes fetch: i) ~~ NULL ifTrue: [temp destroy]]].
	super destruct!
*/
}

/**
 * Compute location of doubling front from tally.  If front crosses a node boundary
 */
public void considerNeedForDoubling() {
throw new UnsupportedOperationException();/*
udanax-top.st:46154:GrandHashSet methodsFor: 'private: housekeeping'!
{void} considerNeedForDoubling
	"Compute location of doubling front from tally.  If front crosses a node boundary"
	" and that node has index higher than doublingFrontIndex then double that node."
	" Then increase doublingFrontIndex.  If the front has hit the end of the table index"
	" reset it to zero.  This allows elements to be wiped from the table without causing"
	" extra node doubling to occur on later insertions.  This aims for 80% max table"
	"loading using an approximation of the formula given in the Fagin paper."
	| desiredDoublingIndex {Int32} x {IEEEDoubleVar} dfi {Int32} |
	x _ 0.05"Magic number" * numNodes * (1 bitShift: myDoublingPasses count DOTasLong) * GrandNode primaryPageSize.
	desiredDoublingIndex _ (myTally count DOTasLong asFloat / x) asInteger "- 1".
	dfi _ myDoublingFrontIndex count DOTasLong.
	desiredDoublingIndex >= (dfi + 1) ifTrue:
		[(grandNodes fetch: dfi) ~~ NULL ifTrue: [(GrandNodeDoubler make: ((grandNodes fetch: dfi) cast: GrandNode)) schedule].
		dfi _ myDoublingFrontIndex increment DOTasLong].
	dfi >= numNodes ifTrue:
		[myDoublingFrontIndex setCount: IntegerVar0.
		myDoublingPasses increment]!
*/
}

public void invalidateCache() {
throw new UnsupportedOperationException();/*
udanax-top.st:46172:GrandHashSet methodsFor: 'private: housekeeping'!
{void} invalidateCache
	cacheValue _ NULL.!
*/
}

/**
 * re-initialize the non-persistent part
 */
public void restartGrandHashSet(Rcvr trans) {
throw new UnsupportedOperationException();/*
udanax-top.st:46177:GrandHashSet methodsFor: 'receiver'!
{void RECEIVE.HOOK} restartGrandHashSet: trans {Rcvr unused default: NULL}
	"re-initialize the non-persistent part"
	cacheValue _ NULL.
	myOutstandingSteppers _ IntegerVar0!
*/
}

public GrandNode nodeAt(IntegerVar idx) {
throw new UnsupportedOperationException();/*
udanax-top.st:46184:GrandHashSet methodsFor: 'private: friendly'!
{GrandNode} nodeAt: idx {IntegerVar}
	^ (grandNodes fetch: idx DOTasLong) cast: GrandNode!
*/
}

public IntegerVar nodeCount() {
throw new UnsupportedOperationException();/*
udanax-top.st:46187:GrandHashSet methodsFor: 'private: friendly'!
{IntegerVar} nodeCount
	^ numNodes!
*/
}

public static void inspectPieces() {
throw new UnsupportedOperationException();/*
udanax-top.st:46192:GrandHashSet methodsFor: 'private: smalltalk: private'!
inspectPieces
	^grandNodes asOrderedCollection!
*/
}

public void checkSteppers() {
throw new UnsupportedOperationException();/*
udanax-top.st:46197:GrandHashSet methodsFor: 'private: enumerating'!
{void INLINE} checkSteppers
	myOutstandingSteppers > IntegerVar0 ifTrue:
		[ Heaper BLAST: #ModifyBlockedByOutstandingStepper ]!
*/
}

public void fewerSteppers() {
throw new UnsupportedOperationException();/*
udanax-top.st:46201:GrandHashSet methodsFor: 'private: enumerating'!
{void} fewerSteppers
	myOutstandingSteppers _ myOutstandingSteppers - 1.
	myOutstandingSteppers < IntegerVar0 ifTrue:
		[ Heaper BLAST: #TooManySteppersReleased ]!
*/
}

public Stepper immuStepper() {
throw new UnsupportedOperationException();/*
udanax-top.st:46206:GrandHashSet methodsFor: 'private: enumerating'!
{Stepper} immuStepper
	self hack. "This will have to be fixed if GrandHashSet::stepper ever makes a copy"
	 ^ self stepper!
*/
}

public void moreSteppers() {
throw new UnsupportedOperationException();/*
udanax-top.st:46210:GrandHashSet methodsFor: 'private: enumerating'!
{void} moreSteppers
	myOutstandingSteppers _ myOutstandingSteppers + 1!
*/
}

public  GrandHashSet(Rcvr receiver) {
throw new UnsupportedOperationException();/*
udanax-top.st:46215:GrandHashSet methodsFor: 'generated:'!
create.Rcvr: receiver {Rcvr}
	super create.Rcvr: receiver.
	grandNodes _ receiver receiveHeaper.
	numNodes _ receiver receiveInt32.
	nodeIndexShift _ receiver receiveInt32.
	myTally _ receiver receiveHeaper.
	myDoublingFrontIndex _ receiver receiveHeaper.
	myDoublingPasses _ receiver receiveHeaper.!
*/
}

public void sendSelfTo(Xmtr xmtr) {
throw new UnsupportedOperationException();/*
udanax-top.st:46224:GrandHashSet methodsFor: 'generated:'!
{void} sendSelfTo: xmtr {Xmtr}
	super sendSelfTo: xmtr.
	xmtr sendHeaper: grandNodes.
	xmtr sendInt32: numNodes.
	xmtr sendInt32: nodeIndexShift.
	xmtr sendHeaper: myTally.
	xmtr sendHeaper: myDoublingFrontIndex.
	xmtr sendHeaper: myDoublingPasses.!
*/
}

public static Heaper make() {
throw new UnsupportedOperationException();/*
udanax-top.st:46248:GrandHashSet class methodsFor: 'pseudoConstructors'!
make 
	^ self create: 32 "A Very big table"!
*/
}

public static Heaper make(int nNodes) {
throw new UnsupportedOperationException();/*
udanax-top.st:46251:GrandHashSet class methodsFor: 'pseudoConstructors'!
make: nNodes {Int32} 
	^ self create: nNodes!
*/
}

/**
 * GrandHashTable initTimeNonInherited
 */
public static void initTimeNonInherited() {
throw new UnsupportedOperationException();/*
udanax-top.st:46256:GrandHashSet class methodsFor: 'smalltalk: initialization'!
initTimeNonInherited
	"GrandHashTable initTimeNonInherited"
	
	self REQUIRES: ExponentialHashMap!
*/
}
}
