/*
 * Abora-Gold
 * Part of the Abora hypertext project: http://www.abora.org
 * Copyright 2003 David G Jones
 * 
 * Translated from Udanax-Gold source code: http://www.udanax.com
 * Copyright 1979-1999 Udanax.com. All rights reserved
 */
package org.abora.gold.collection.settable;

import org.abora.gold.cache.InstanceCache;
import org.abora.gold.collection.basic.SharedPtrArray;
import org.abora.gold.collection.settable.TableEntry;
import org.abora.gold.collection.steppers.Stepper;
import org.abora.gold.collection.steppers.TableStepper;
import org.abora.gold.java.missing.IntegerVar;
import org.abora.gold.spaces.basic.Position;
import org.abora.gold.xpp.basic.Heaper;


public class BucketArrayStepper extends TableStepper {
	protected TableEntry myEntry;
	protected SharedPtrArray myEntries;
	protected byte myNextBucket;
	protected static InstanceCache SomeSteppers;
/*
udanax-top.st:55515:
TableStepper subclass: #BucketArrayStepper
	instanceVariableNames: '
		myEntry {TableEntry | NULL}
		myEntries {SharedPtrArray of: TableEntry}
		myNextBucket {Int4}'
	classVariableNames: 'SomeSteppers {InstanceCache} '
	poolDictionaries: ''
	category: 'Xanadu-Collection-SetTable'!
*/
/*
udanax-top.st:55522:
(BucketArrayStepper getOrMakeCxxClassDescription)
	attributes: ((Set new) add: #CONCRETE; add: #NOT.A.TYPE; yourself)!
*/
/*
udanax-top.st:55594:
BucketArrayStepper class
	instanceVariableNames: ''!
*/
/*
udanax-top.st:55597:
(BucketArrayStepper getOrMakeCxxClassDescription)
	attributes: ((Set new) add: #CONCRETE; add: #NOT.A.TYPE; yourself)!
*/

public Heaper fetch() {
throw new UnsupportedOperationException();/*
udanax-top.st:55527:BucketArrayStepper methodsFor: 'operations'!
{Heaper wimpy} fetch
	myEntry == NULL ifTrue: [^NULL] ifFalse: [^myEntry value]!
*/
}

public boolean hasValue() {
throw new UnsupportedOperationException();/*
udanax-top.st:55530:BucketArrayStepper methodsFor: 'operations'!
{BooleanVar} hasValue
	^myEntry ~~ NULL!
*/
}

public void step() {
throw new UnsupportedOperationException();/*
udanax-top.st:55533:BucketArrayStepper methodsFor: 'operations'!
{void} step
	myEntry ~~ NULL ifTrue: [
		myEntry _ myEntry fetchNext.
		self verifyEntry]!
*/
}

/**
 * Step through the bucket till we find something with a matching key.
 */
public void verifyEntry() {
throw new UnsupportedOperationException();/*
udanax-top.st:55540:BucketArrayStepper methodsFor: 'private:'!
{void} verifyEntry
	"Step through the bucket till we find something with a matching key."
	| bucket {Int32} |
	"use a local index to avoid pointer refs in loop"
	myEntry ~~ NULL ifTrue: [^VOID].
	bucket _ myNextBucket.
	[bucket < myEntries count] whileTrue:
		[|nextEntry {Heaper wimpy}|
		nextEntry _ myEntries fetch: bucket.
		bucket _ bucket + 1.
		nextEntry ~~ NULL ifTrue:
			[myEntry _ nextEntry cast: TableEntry.
			myNextBucket _ bucket.
			^VOID]].
	myEntries := NULL.!
*/
}

public IntegerVar index() {
throw new UnsupportedOperationException();/*
udanax-top.st:55558:BucketArrayStepper methodsFor: 'special'!
{IntegerVar} index
	myEntry ~~ NULL assert: 'Illegal access'.
	^myEntry index!
*/
}

public Position position() {
throw new UnsupportedOperationException();/*
udanax-top.st:55562:BucketArrayStepper methodsFor: 'special'!
{Position} position
	myEntry ~~ NULL assert: 'Illegal access'.
	^myEntry position!
*/
}

public  BucketArrayStepper(SharedPtrArray entries, TableEntry entry, int nextBucket) {
throw new UnsupportedOperationException();/*
udanax-top.st:55568:BucketArrayStepper methodsFor: 'protected: create'!
create: entries {SharedPtrArray} with: entry {TableEntry | NULL} with: nextBucket {Int32}
	super create.
	myEntry _ entry.
	myEntries _ entries.
	myNextBucket _ nextBucket.
	myEntries shareMore.
	self verifyEntry!
*/
}

public void destruct() {
throw new UnsupportedOperationException();/*
udanax-top.st:55576:BucketArrayStepper methodsFor: 'protected: create'!
{void} destruct
	myEntries ~~ NULL ifTrue: [
		myEntries shareLess].
	super destruct!
*/
}

public Stepper copy() {
throw new UnsupportedOperationException();/*
udanax-top.st:55583:BucketArrayStepper methodsFor: 'create'!
{Stepper} copy
	| result {Heaper} |
	result := SomeSteppers fetch.
	result ==  NULL
		ifTrue: [^BucketArrayStepper create: myEntries with: myEntry with: myNextBucket]
		ifFalse: [^(BucketArrayStepper new.Become: result) create: myEntries with: myEntry with: myNextBucket]!
*/
}

public void destroy() {
throw new UnsupportedOperationException();/*
udanax-top.st:55590:BucketArrayStepper methodsFor: 'create'!
{void} destroy
	(SomeSteppers store: self) ifFalse: [super destroy]!
*/
}

public static void initTimeNonInherited() {
throw new UnsupportedOperationException();/*
udanax-top.st:55602:BucketArrayStepper class methodsFor: 'smalltalk: init'!
initTimeNonInherited
	SomeSteppers := InstanceCache make: 8!
*/
}

public static void linkTimeNonInherited() {
throw new UnsupportedOperationException();/*
udanax-top.st:55605:BucketArrayStepper class methodsFor: 'smalltalk: init'!
linkTimeNonInherited
	SomeSteppers := NULL!
*/
}

public static Heaper make(SharedPtrArray entries) {
throw new UnsupportedOperationException();/*
udanax-top.st:55610:BucketArrayStepper class methodsFor: 'creation'!
{TableStepper} make: entries {SharedPtrArray}
	| result {Heaper} |
	result := SomeSteppers fetch.
	result == NULL
		ifTrue: [^self create: entries with: NULL with: Int32Zero]
		ifFalse: [^(self new.Become: result) create: entries with: NULL with: Int32Zero]!
*/
}
}
