/*
 * Abora-Gold
 * Part of the Abora hypertext project: http://www.abora.org
 * Copyright 2003 David G Jones
 * 
 * Translated from Udanax-Gold source code: http://www.udanax.com
 * Copyright 1979-1999 Udanax.com. All rights reserved
 */
package org.abora.gold.collection.settable;

import java.io.PrintWriter;
import org.abora.gold.collection.basic.SharedPtrArray;
import org.abora.gold.collection.settable.TableEntry;
import org.abora.gold.collection.steppers.TableStepper;
import org.abora.gold.java.missing.IntegerVar;
import org.abora.gold.spaces.basic.Position;
import org.abora.gold.xcvr.Rcvr;
import org.abora.gold.xcvr.Xmtr;
import org.abora.gold.xpp.basic.Heaper;


public class TableEntry extends Heaper {
	protected TableEntry myNext;
	protected Heaper myValue;
/*
udanax-top.st:56469:
Heaper subclass: #TableEntry
	instanceVariableNames: '
		myNext {TableEntry}
		myValue {Heaper}'
	classVariableNames: ''
	poolDictionaries: ''
	category: 'Xanadu-Collection-SetTable'!
*/
/*
udanax-top.st:56475:
(TableEntry getOrMakeCxxClassDescription)
	attributes: ((Set new) add: #EQ; add: #DEFERRED; add: #COPY; yourself)!
*/
/*
udanax-top.st:56563:
TableEntry class
	instanceVariableNames: ''!
*/
/*
udanax-top.st:56566:
(TableEntry getOrMakeCxxClassDescription)
	attributes: ((Set new) add: #EQ; add: #DEFERRED; add: #COPY; yourself)!
*/

public TableEntry copy() {
throw new UnsupportedOperationException();/*
udanax-top.st:56480:TableEntry methodsFor: 'accessing'!
{TableEntry} copy
	self subclassResponsibility!
*/
}

public TableEntry fetchNext() {
throw new UnsupportedOperationException();/*
udanax-top.st:56484:TableEntry methodsFor: 'accessing'!
{TableEntry INLINE | NULL} fetchNext
	^myNext!
*/
}

public IntegerVar index() {
throw new UnsupportedOperationException();/*
udanax-top.st:56487:TableEntry methodsFor: 'accessing'!
{IntegerVar} index
	^ (self position cast: IntegerPos) asIntegerVar!
*/
}

/**
 * Return true if my key matches key.
 */
public boolean match(Position key) {
throw new UnsupportedOperationException();/*
udanax-top.st:56490:TableEntry methodsFor: 'accessing'!
{BooleanVar} match: key {Position}
	"Return true if my key matches key."
	
	self subclassResponsibility!
*/
}

/**
 * Return true if my key matches the position associated with index.
 */
public boolean matchInt(IntegerVar index) {
throw new UnsupportedOperationException();/*
udanax-top.st:56495:TableEntry methodsFor: 'accessing'!
{BooleanVar} matchInt: index {IntegerVar}
	"Return true if my key matches the position associated with index."
	
	^self match: index integer!
*/
}

/**
 * Return true if my value matches value.  Note that this *must* test EQ first in
 * case the value is no longer a heaper.  Otherwise we could never remove a
 * destructed object.
 */
public boolean matchValue(Heaper value) {
throw new UnsupportedOperationException();/*
udanax-top.st:56500:TableEntry methodsFor: 'accessing'!
{BooleanVar} matchValue: value {Heaper}
	"Return true if my value matches value.  Note that this *must* test EQ first in
	 case the value is no longer a heaper.  Otherwise we could never remove a 
	 destructed object."
	
	^value == (myValue basicCast: Heaper star) or: [value isEqual: myValue]!
*/
}

public Position position() {
throw new UnsupportedOperationException();/*
udanax-top.st:56507:TableEntry methodsFor: 'accessing'!
{Position} position
	self subclassResponsibility!
*/
}

/**
 * Return true if my value can be replaced in place, and false if the entire entry must be
 * replaced.
 */
public boolean replaceValue(Heaper newValue) {
throw new UnsupportedOperationException();/*
udanax-top.st:56510:TableEntry methodsFor: 'accessing'!
{BooleanVar} replaceValue: newValue {Heaper}
	"Return true if my value can be replaced in place, and false if the entire entry must be replaced."
	
	"The default implementation."
	myValue _ newValue.
	^true!
*/
}

/**
 * Change my pointer to the rest of the chain in this bucket.
 */
public void setNext(TableEntry next) {
throw new UnsupportedOperationException();/*
udanax-top.st:56517:TableEntry methodsFor: 'accessing'!
{void INLINE} setNext: next {TableEntry | NULL}
	"Change my pointer to the rest of the chain in this bucket."
	myNext _ next!
*/
}

public Heaper value() {
throw new UnsupportedOperationException();/*
udanax-top.st:56521:TableEntry methodsFor: 'accessing'!
{Heaper INLINE} value
	^myValue!
*/
}

public  TableEntry(Heaper value) {
throw new UnsupportedOperationException();/*
udanax-top.st:56526:TableEntry methodsFor: 'protected: creation'!
create: value {Heaper}
	super create.
	myNext _ NULL.
	myValue _ value!
*/
}

public  TableEntry(TableEntry next, Heaper value) {
throw new UnsupportedOperationException();/*
udanax-top.st:56531:TableEntry methodsFor: 'protected: creation'!
create: next {TableEntry} with: value {Heaper}
	super create.
	myNext _ next.
	myValue _ value!
*/
}

public void printOn(PrintWriter oo) {
throw new UnsupportedOperationException();/*
udanax-top.st:56538:TableEntry methodsFor: 'printing'!
{void} printOn: oo {ostream reference}
	oo << self getCategory name << '(' << self position << ' -> ' << self value << ')'!
*/
}

/**
 * temporarily don't destroy.
 */
public void destroy() {
throw new UnsupportedOperationException();/*
udanax-top.st:56543:TableEntry methodsFor: 'destroy'!
{void} destroy
	"temporarily don't destroy."!
*/
}

public int actualHashForEqual() {
throw new UnsupportedOperationException();/*
udanax-top.st:56548:TableEntry methodsFor: 'generated:'!
actualHashForEqual ^self asOop!
*/
}

public  TableEntry(Rcvr receiver) {
throw new UnsupportedOperationException();/*
udanax-top.st:56550:TableEntry methodsFor: 'generated:'!
create.Rcvr: receiver {Rcvr}
	super create.Rcvr: receiver.
	myNext _ receiver receiveHeaper.
	myValue _ receiver receiveHeaper.!
*/
}

public boolean isEqual(Object other) {
throw new UnsupportedOperationException();/*
udanax-top.st:56555:TableEntry methodsFor: 'generated:'!
isEqual: other ^self == other!
*/
}

public void sendSelfTo(Xmtr xmtr) {
throw new UnsupportedOperationException();/*
udanax-top.st:56557:TableEntry methodsFor: 'generated:'!
{void} sendSelfTo: xmtr {Xmtr}
	super sendSelfTo: xmtr.
	xmtr sendHeaper: myNext.
	xmtr sendHeaper: myValue.!
*/
}

public static TableStepper bucketStepper(SharedPtrArray array) {
throw new UnsupportedOperationException();/*
udanax-top.st:56571:TableEntry class methodsFor: 'creation'!
{TableStepper INLINE} bucketStepper: array {SharedPtrArray}
	^BucketArrayStepper make: array!
*/
}

public static Heaper make(IntegerVar index, Heaper value) {
throw new UnsupportedOperationException();/*
udanax-top.st:56574:TableEntry class methodsFor: 'creation'!
make.IntegerVar: index {IntegerVar} with: value {Heaper}
	index == value hashForEqual
		ifTrue: [^HashIndexEntry create: value]
		ifFalse: [^IndexEntry create: index with: value]!
*/
}

public static Heaper make(Position key, Heaper value) {
throw new UnsupportedOperationException();/*
udanax-top.st:56579:TableEntry class methodsFor: 'creation'!
make: key {Position} with: value {Heaper}
	key cast: IntegerPos into: [:xuint | 
			^self make.IntegerVar: xuint asIntegerVar with: value]
		cast: HeaperAsPosition into: [:hap |
				(key isEqual: (HeaperAsPosition make: value))
					ifTrue: [ ^HeaperAsEntry create: value]
					ifFalse: [^PositionEntry create: key with: value]]
		others: [^PositionEntry create: key with: value].
	^ NULL "compiler fodder"!
*/
}
}
