/*
 * Abora-Gold
 * Part of the Abora hypertext project: http://www.abora.org
 * Copyright 2003 David G Jones
 * 
 * Translated from Udanax-Gold source code: http://www.udanax.com
 * Copyright 1979-1999 Udanax.com. All rights reserved
 */
package org.abora.gold.collection.settable;

import java.io.PrintWriter;
import org.abora.gold.collection.settable.TableEntry;
import org.abora.gold.java.missing.IntegerVar;
import org.abora.gold.spaces.basic.Position;
import org.abora.gold.xcvr.Rcvr;
import org.abora.gold.xcvr.Xmtr;
import org.abora.gold.xpp.basic.Heaper;


public class IndexEntry extends TableEntry {
	protected IntegerVar myIndex;
/*
udanax-top.st:56680:
TableEntry subclass: #IndexEntry
	instanceVariableNames: 'myIndex {IntegerVar}'
	classVariableNames: ''
	poolDictionaries: ''
	category: 'Xanadu-Collection-SetTable'!
*/
/*
udanax-top.st:56684:
(IndexEntry getOrMakeCxxClassDescription)
	attributes: ((Set new) add: #CONCRETE; add: #COPY; add: #NOT.A.TYPE; yourself)!
*/

public IntegerVar index() {
throw new UnsupportedOperationException();/*
udanax-top.st:56689:IndexEntry methodsFor: 'accessing'!
{IntegerVar} index
	^ myIndex!
*/
}

/**
 * Return true if my key matches key.
 */
public boolean match(Position key) {
throw new UnsupportedOperationException();/*
udanax-top.st:56692:IndexEntry methodsFor: 'accessing'!
{BooleanVar} match: key {Position}
	"Return true if my key matches key."
	
	key cast: IntegerPos into: [:pos | 
			^pos asIntegerVar == myIndex]
		others: [^false].
	^ false "compiler fodder"!
*/
}

/**
 * Return true if my key matches the position associated with index.
 */
public boolean matchInt(IntegerVar index) {
throw new UnsupportedOperationException();/*
udanax-top.st:56700:IndexEntry methodsFor: 'accessing'!
{BooleanVar} matchInt: index {IntegerVar}
	"Return true if my key matches the position associated with index."
	
	^index == myIndex!
*/
}

public Position position() {
throw new UnsupportedOperationException();/*
udanax-top.st:56705:IndexEntry methodsFor: 'accessing'!
{Position} position
	^myIndex integer!
*/
}

public TableEntry copy() {
throw new UnsupportedOperationException();/*
udanax-top.st:56710:IndexEntry methodsFor: 'creation'!
{TableEntry} copy
	^ IndexEntry create: myIndex with:self value!
*/
}

public  IndexEntry(IntegerVar index, Heaper value) {
	super(value);
throw new UnsupportedOperationException();/*
udanax-top.st:56713:IndexEntry methodsFor: 'creation'!
create: index {IntegerVar} with: value {Heaper}
	super create: value.
	myIndex _ index!
*/
}

public  IndexEntry(TableEntry next, Heaper value, IntegerVar index) {
	super(next, value);
throw new UnsupportedOperationException();/*
udanax-top.st:56717:IndexEntry methodsFor: 'creation'!
create: next {TableEntry} with: value {Heaper} with: index {IntegerVar}
	super create: next with: value.
	myIndex _ index!
*/
}

public void printOn(PrintWriter oo) {
throw new UnsupportedOperationException();/*
udanax-top.st:56723:IndexEntry methodsFor: 'printing'!
{void} printOn: oo {ostream reference}
	oo << self getCategory name << '(' << myIndex integer << ' -> ' << self value << ')'!
*/
}

public  IndexEntry(Rcvr receiver) {
	super(receiver);
throw new UnsupportedOperationException();/*
udanax-top.st:56728:IndexEntry methodsFor: 'generated:'!
create.Rcvr: receiver {Rcvr}
	super create.Rcvr: receiver.
	myIndex _ receiver receiveIntegerVar.!
*/
}

public void sendSelfTo(Xmtr xmtr) {
throw new UnsupportedOperationException();/*
udanax-top.st:56732:IndexEntry methodsFor: 'generated:'!
{void} sendSelfTo: xmtr {Xmtr}
	super sendSelfTo: xmtr.
	xmtr sendIntegerVar: myIndex.!
*/
}
}
