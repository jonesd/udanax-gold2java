/*
 * Abora-Gold
 * Part of the Abora hypertext project: http://www.abora.org
 * Copyright 2003 David G Jones
 * 
 * Translated from Udanax-Gold source code: http://www.udanax.com
 * Copyright 1979-1999 Udanax.com. All rights reserved
 */
package org.abora.gold.collection.tables;

import org.abora.gold.collection.steppers.TableStepper;
import org.abora.gold.collection.tables.IntegerTable;
import org.abora.gold.collection.tables.MuTable;
import org.abora.gold.collection.tables.ScruTable;
import org.abora.gold.java.missing.IntegerVar;
import org.abora.gold.java.missing.MuWordArray;
import org.abora.gold.spaces.basic.CoordinateSpace;
import org.abora.gold.spaces.basic.OrderSpec;
import org.abora.gold.spaces.basic.Position;
import org.abora.gold.spaces.basic.XnRegion;
import org.abora.gold.spaces.integers.IntegerRegion;
import org.abora.gold.xpp.basic.Heaper;


/**
 * The IntegerTable class is used for tables that have arbitrary XuInteger keys in their
 * domain.  Since ScruTable & MuTable already provide all the unboxed versions of the table
 * protocol, there is little need for this class to be a type.  However, this class does
 * provide a bit of extra protocol convenience: highestIndex & lowestIndex. Unless these are
 * retired, we cannot retire this class from type status.
 * Note that there may be tables with XuInteger keys (i.e., IntegerSpace domains) which are
 * not kinds of IntegerTables.  In particular it is perfectly sensible to create a HashTable
 * with XuInteger keys when the domain region is likely to be sparse.
 */
public class IntegerTable extends MuTable {
/*
udanax-top.st:48897:
MuTable subclass: #IntegerTable
	instanceVariableNames: ''
	classVariableNames: ''
	poolDictionaries: ''
	category: 'Xanadu-Collection-Tables'!
*/
/*
udanax-top.st:48901:
IntegerTable comment:
'The IntegerTable class is used for tables that have arbitrary XuInteger keys in their domain.  Since ScruTable & MuTable already provide all the unboxed versions of the table protocol, there is little need for this class to be a type.  However, this class does provide a bit of extra protocol convenience: highestIndex & lowestIndex. Unless these are retired, we cannot retire this class from type status.
	
	Note that there may be tables with XuInteger keys (i.e., IntegerSpace domains) which are not kinds of IntegerTables.  In particular it is perfectly sensible to create a HashTable with XuInteger keys when the domain region is likely to be sparse.'!
*/
/*
udanax-top.st:48905:
(IntegerTable getOrMakeCxxClassDescription)
	attributes: ((Set new) add: #DEFERRED; yourself)!
*/
/*
udanax-top.st:49045:
IntegerTable class
	instanceVariableNames: ''!
*/
/*
udanax-top.st:49048:
(IntegerTable getOrMakeCxxClassDescription)
	attributes: ((Set new) add: #DEFERRED; yourself)!
*/

public void atIntIntroduce(IntegerVar key, Heaper value) {
throw new UnsupportedOperationException();/*
udanax-top.st:48910:IntegerTable methodsFor: 'accessing'!
{void} atInt: key {IntegerVar} introduce: value {Heaper}
	| old {Heaper} |
	(old _ self atInt: key store: value) ~~ NULL
		ifTrue: [self atInt: key store: old. "restore prior condition"
			Heaper BLAST: #AlreadyInTable]!
*/
}

public void atIntReplace(IntegerVar key, Heaper value) {
throw new UnsupportedOperationException();/*
udanax-top.st:48916:IntegerTable methodsFor: 'accessing'!
{void} atInt: key {IntegerVar} replace: value {Heaper} 
	(self atInt: key store: value) == NULL
		ifTrue: [self intWipe: key. "restore prior condition"
			Heaper BLAST: #NotInTable]!
*/
}

public Heaper atIntStore(IntegerVar key, Heaper value) {
throw new UnsupportedOperationException();/*
udanax-top.st:48921:IntegerTable methodsFor: 'accessing'!
{Heaper} atInt: key {IntegerVar} store: value {Heaper} 
	self subclassResponsibility!
*/
}

public CoordinateSpace coordinateSpace() {
throw new UnsupportedOperationException();/*
udanax-top.st:48925:IntegerTable methodsFor: 'accessing'!
{CoordinateSpace} coordinateSpace
	^IntegerSpace make!
*/
}

public IntegerVar count() {
throw new UnsupportedOperationException();/*
udanax-top.st:48929:IntegerTable methodsFor: 'accessing'!
{IntegerVar} count
	self subclassResponsibility!
*/
}

public XnRegion domain() {
throw new UnsupportedOperationException();/*
udanax-top.st:48933:IntegerTable methodsFor: 'accessing'!
{XnRegion} domain
	self subclassResponsibility.!
*/
}

/**
 * Given that the table is non-empty, 'intTab->highestIndex()' is equivalent to
 * 'CAST(IntegerRegion,intTab->domain())->upperBound() -1'. The reason for the
 * '-1' is that the 'upperBound' is an exclusive upper bound (see
 * IntegerRegion::upperBound), whereas 'highestIndex' is the highest index which is
 * in my domain. I need to here specify what 'highestIndex' does if I am empty.
 */
public IntegerVar highestIndex() {
throw new UnsupportedOperationException();/*
udanax-top.st:48937:IntegerTable methodsFor: 'accessing'!
{IntegerVar} highestIndex
	"Given that the table is non-empty, 'intTab->highestIndex()' is equivalent to 
	'CAST(IntegerRegion,intTab->domain())->upperBound() -1'. The reason for the 
	'-1' is that the 'upperBound' is an exclusive upper bound (see 
	IntegerRegion::upperBound), whereas 'highestIndex' is the highest index which is 
	in my domain. I need to here specify what 'highestIndex' does if I am empty."
	self subclassResponsibility!
*/
}

public Heaper intFetch(IntegerVar key) {
throw new UnsupportedOperationException();/*
udanax-top.st:48946:IntegerTable methodsFor: 'accessing'!
{Heaper} intFetch: key {IntegerVar} 
	self subclassResponsibility!
*/
}

public void intRemove(IntegerVar anIdx) {
throw new UnsupportedOperationException();/*
udanax-top.st:48950:IntegerTable methodsFor: 'accessing'!
{void} intRemove: anIdx {IntegerVar}
	
	(self intWipe: anIdx) ifFalse: [Heaper BLAST: #NotInTable]!
*/
}

public boolean intWipe(IntegerVar anIdx) {
throw new UnsupportedOperationException();/*
udanax-top.st:48954:IntegerTable methodsFor: 'accessing'!
{BooleanVar} intWipe: anIdx {IntegerVar}
	self subclassResponsibility!
*/
}

/**
 * Given that the table is non-empty, 'intTab->lowestIndex()' is equivalent to
 * 'CAST(IntegerRegion,intTab->domain())->lowerBound()'. 'lowestIndex' is the
 * lowest index which is in my domain. I need to here specify what 'lowestIndex'
 * does if I am empty.
 */
public IntegerVar lowestIndex() {
throw new UnsupportedOperationException();/*
udanax-top.st:48957:IntegerTable methodsFor: 'accessing'!
{IntegerVar} lowestIndex
	"Given that the table is non-empty, 'intTab->lowestIndex()' is equivalent to 
	'CAST(IntegerRegion,intTab->domain())->lowerBound()'. 'lowestIndex' is the 
	lowest index which is in my domain. I need to here specify what 'lowestIndex' 
	does if I am empty."
	self subclassResponsibility!
*/
}

public ScruTable subTable(XnRegion reg) {
throw new UnsupportedOperationException();/*
udanax-top.st:48965:IntegerTable methodsFor: 'accessing'!
{ScruTable} subTable: reg {XnRegion} 
	self subclassResponsibility!
*/
}

public void atIntroduce(Position key, Heaper value) {
throw new UnsupportedOperationException();/*
udanax-top.st:48971:IntegerTable methodsFor: 'accessing overloads'!
{void} at: key {Position} introduce: value {Heaper} 
	self atInt: (key cast: IntegerPos) asIntegerVar introduce: value!
*/
}

public void atReplace(Position key, Heaper value) {
throw new UnsupportedOperationException();/*
udanax-top.st:48975:IntegerTable methodsFor: 'accessing overloads'!
{void} at: key {Position} replace: value {Heaper} 
	self atInt: (key cast: IntegerPos) asIntegerVar replace: value!
*/
}

public Heaper atStore(Position key, Heaper value) {
throw new UnsupportedOperationException();/*
udanax-top.st:48979:IntegerTable methodsFor: 'accessing overloads'!
{Heaper} at: key {Position} store: value {Heaper} 
	^ self atInt: (key cast: IntegerPos) asIntegerVar store: value!
*/
}

public Heaper fetch(Position key) {
throw new UnsupportedOperationException();/*
udanax-top.st:48983:IntegerTable methodsFor: 'accessing overloads'!
{Heaper} fetch: key {Position} 
	^ self intFetch: (key cast: IntegerPos) asIntegerVar!
*/
}

public boolean includesKey(Position aKey) {
throw new UnsupportedOperationException();/*
udanax-top.st:48987:IntegerTable methodsFor: 'accessing overloads'!
{BooleanVar} includesKey: aKey {Position}
	^ self includesIntKey: (aKey cast: IntegerPos) asIntegerVar!
*/
}

public void remove(Position aPos) {
throw new UnsupportedOperationException();/*
udanax-top.st:48990:IntegerTable methodsFor: 'accessing overloads'!
{void} remove: aPos {Position}
	
	self intRemove: (aPos cast: IntegerPos) asIntegerVar!
*/
}

public XnRegion runAt(Position key) {
throw new UnsupportedOperationException();/*
udanax-top.st:48994:IntegerTable methodsFor: 'accessing overloads'!
{XnRegion} runAt: key {Position} 
	^ self runAtInt: (key cast: IntegerPos) asIntegerVar!
*/
}

public boolean wipe(Position anIdx) {
throw new UnsupportedOperationException();/*
udanax-top.st:48997:IntegerTable methodsFor: 'accessing overloads'!
{BooleanVar} wipe: anIdx {Position}
	^ self intWipe: ((anIdx cast: IntegerPos) asIntegerVar)!
*/
}

public boolean includesIntKey(IntegerVar aKey) {
throw new UnsupportedOperationException();/*
udanax-top.st:49003:IntegerTable methodsFor: 'testing'!
{BooleanVar} includesIntKey: aKey {IntegerVar}
	self subclassResponsibility!
*/
}

public boolean isEmpty() {
throw new UnsupportedOperationException();/*
udanax-top.st:49006:IntegerTable methodsFor: 'testing'!
{BooleanVar} isEmpty
	self subclassResponsibility.!
*/
}

public TableStepper stepper(OrderSpec order) {
throw new UnsupportedOperationException();/*
udanax-top.st:49011:IntegerTable methodsFor: 'enumerating'!
{TableStepper} stepper: order {OrderSpec default: NULL}
	self subclassResponsibility!
*/
}

public XnRegion runAtInt(IntegerVar key) {
throw new UnsupportedOperationException();/*
udanax-top.st:49016:IntegerTable methodsFor: 'runs'!
{XnRegion} runAtInt: key {IntegerVar}
	self subclassResponsibility!
*/
}

public ScruTable copy() {
throw new UnsupportedOperationException();/*
udanax-top.st:49021:IntegerTable methodsFor: 'creation'!
{ScruTable} copy
	self subclassResponsibility!
*/
}

/**
 * Create a new table with an unspecified number of initial domain positions.
 */
public  IntegerTable() {
throw new UnsupportedOperationException();/*
udanax-top.st:49024:IntegerTable methodsFor: 'creation'!
create
	"Create a new table with an unspecified number of initial domain positions."
	super create!
*/
}

public ScruTable emptySize(IntegerVar size) {
throw new UnsupportedOperationException();/*
udanax-top.st:49028:IntegerTable methodsFor: 'creation'!
{ScruTable} emptySize: size {IntegerVar}
	self subclassResponsibility!
*/
}

/**
 * Return a table which contains the elements from start to stop, starting at
 * firstIndex. Zero-based subclasses will blast if firstIndex is non-zero
 */
public ScruTable offsetSubTableBetween(IntegerVar startIndex, IntegerVar stopIndex, IntegerVar firstIndex) {
throw new UnsupportedOperationException();/*
udanax-top.st:49032:IntegerTable methodsFor: 'creation'!
{ScruTable} offsetSubTableBetween: startIndex {IntegerVar} 
	with: stopIndex {IntegerVar} 
	with: firstIndex {IntegerVar} 
	"Return a table which contains the elements from start to stop, starting at 
	firstIndex. Zero-based subclasses will blast if firstIndex is non-zero"
	self subclassResponsibility!
*/
}

/**
 * Hack for C++ overloading problem
 */
public ScruTable subTableBetween(IntegerVar startIndex, IntegerVar stopIndex) {
throw new UnsupportedOperationException();/*
udanax-top.st:49040:IntegerTable methodsFor: 'creation'!
{ScruTable} subTableBetween: startIndex {IntegerVar} with: stopIndex {IntegerVar}
	"Hack for C++ overloading problem"
	self subclassResponsibility!
*/
}

public static Heaper make(Heaper something) {
throw new UnsupportedOperationException();/*
udanax-top.st:49053:IntegerTable class methodsFor: 'smalltalk: pseudoConstructors'!
{IntegerTable} make: something {Heaper}
	(something isKindOf: String) 
		ifTrue: [^ self make.charVector: something].
	^ self make.IntegerVar: (something cast: Integer)!
*/
}

//public static Heaper make(IntegerVar from, IntegerVar to) {
//throw new UnsupportedOperationException();/*
//udanax-top.st:49058:IntegerTable class methodsFor: 'smalltalk: pseudoConstructors'!
//{MuTable} make: from {IntegerVar} with: to {IntegerVar}
//	^self make.IntegerVar: from with: to!
//*/
//}

/**
 * A new empty IntegerTable
 */
public static Heaper make() {
throw new UnsupportedOperationException();/*
udanax-top.st:49064:IntegerTable class methodsFor: 'pseudoConstructors'!
{IntegerTable} make
	"A new empty IntegerTable"
	
	^ ActualIntegerTable create.!
*/
}

/**
 * A new empty IntegerTable. 'someSize' is a hint about how big the table is likely
 * to need to be ('highestIndex - lowestIndex + 1', not 'count').
 */
public static Heaper make(IntegerVar someSize) {
throw new UnsupportedOperationException();/*
udanax-top.st:49069:IntegerTable class methodsFor: 'pseudoConstructors'!
{IntegerTable} make.IntegerVar: someSize {IntegerVar} 
	"A new empty IntegerTable. 'someSize' is a hint about how big the table is likely 
	to need to be ('highestIndex - lowestIndex + 1', not 'count')."
	^ActualIntegerTable create.IntegerVar: someSize!
*/
}

/**
 * Hint that the domain's lowerBound (inclusive) will eventually be 'fromIdx', and
 * the domain's upperBound (exclusive) will eventually be 'toIdx'.
 */
public static Heaper make(IntegerVar fromIdx, IntegerVar toIdx) {
throw new UnsupportedOperationException();/*
udanax-top.st:49075:IntegerTable class methodsFor: 'pseudoConstructors'!
{IntegerTable} make.IntegerVar: fromIdx {IntegerVar} with: toIdx {IntegerVar} 
	"Hint that the domain's lowerBound (inclusive) will eventually be 'fromIdx', and 
	the domain's upperBound (exclusive) will eventually be 'toIdx'."
	^ActualIntegerTable create: fromIdx with: toIdx!
*/
}

/**
 * Hint that the domain of the new table will eventually be (or at least resemble)
 * 'reg'.
 */
public static Heaper make(IntegerRegion reg) {
throw new UnsupportedOperationException();/*
udanax-top.st:49081:IntegerTable class methodsFor: 'pseudoConstructors'!
{IntegerTable} make.Region: reg {IntegerRegion} 
	"Hint that the domain of the new table will eventually be (or at least resemble) 
	'reg'."
	^ActualIntegerTable create: reg start with: reg stop!
*/
}

/**
 * A new IntegerTable initialized from 'table' in a wierd and screwy way
 */
public static Heaper make(ScruTable table) {
throw new UnsupportedOperationException();/*
udanax-top.st:49089:IntegerTable class methodsFor: 'smalltalk: passe'!
{IntegerTable} make.ScruTable: table {ScruTable} 
	"A new IntegerTable initialized from 'table' in a wierd and screwy way"
	
	"| newTable {IntegerTable} stomp {TableStepper} |
	newTable _ IntegerTable make.IntegerVar: (table count).
	stomp _ table stepper.
	[stomp hasValue] whileTrue:
		[newTable at.IntegerVar: stomp index introduce: (table get.IntegerVar: stomp index).
		stomp step].
	^newTable"
	
	self passe!
*/
}

/**
 * Make a copy of 'wv' as an IntegerTable. The IntegerTable starts out with the
 * same state as 'wv', but unlike 'wv' is not obligated to maintain MuArray
 * constraints.
 */
public static Heaper make(MuWordArray wv) {
throw new UnsupportedOperationException();/*
udanax-top.st:49102:IntegerTable class methodsFor: 'smalltalk: passe'!
{IntegerTable} make.WordArray: wv {MuWordArray}
	"Make a copy of 'wv' as an IntegerTable. The IntegerTable starts out with the 
	same state as 'wv', but unlike 'wv' is not obligated to maintain MuArray 
	constraints."
	self passe.!
*/
}
}
