/*
 * Abora-Gold
 * Part of the Abora hypertext project: http://www.abora.org
 * Copyright 2003 David G Jones
 * 
 * Translated from Udanax-Gold source code: http://www.udanax.com
 * Copyright 1979-1999 Udanax.com. All rights reserved
 */
package org.abora.gold.collection.tables;

import org.abora.gold.collection.steppers.TableStepper;
import org.abora.gold.collection.tables.HashTable;
import org.abora.gold.collection.tables.MuTable;
import org.abora.gold.collection.tables.ScruTable;
import org.abora.gold.java.missing.IntegerVar;
import org.abora.gold.spaces.basic.CoordinateSpace;
import org.abora.gold.spaces.basic.OrderSpec;
import org.abora.gold.spaces.basic.Position;
import org.abora.gold.spaces.basic.XnRegion;
import org.abora.gold.xpp.basic.Heaper;


public class HashTable extends MuTable {
/*
udanax-top.st:48454:
MuTable subclass: #HashTable
	instanceVariableNames: ''
	classVariableNames: ''
	poolDictionaries: ''
	category: 'Xanadu-Collection-Tables'!
*/
/*
udanax-top.st:48458:
(HashTable getOrMakeCxxClassDescription)
	attributes: ((Set new) add: #DEFERRED; yourself)!
*/
/*
udanax-top.st:48532:
HashTable class
	instanceVariableNames: ''!
*/
/*
udanax-top.st:48535:
(HashTable getOrMakeCxxClassDescription)
	attributes: ((Set new) add: #DEFERRED; yourself)!
*/

/**
 * Associate value with key, whether or not
 * there is a previous association.
 */
public Heaper atStore(Position key, Heaper value) {
throw new UnsupportedOperationException();/*
udanax-top.st:48463:HashTable methodsFor: 'accessing'!
{Heaper} at: key {Position} store: value {Heaper} 
	"Associate value with key, whether or not
	 there is a previous association."
	self subclassResponsibility!
*/
}

public CoordinateSpace coordinateSpace() {
throw new UnsupportedOperationException();/*
udanax-top.st:48469:HashTable methodsFor: 'accessing'!
{CoordinateSpace} coordinateSpace
	
	self subclassResponsibility!
*/
}

public IntegerVar count() {
throw new UnsupportedOperationException();/*
udanax-top.st:48473:HashTable methodsFor: 'accessing'!
{IntegerVar} count
	self subclassResponsibility!
*/
}

public XnRegion domain() {
throw new UnsupportedOperationException();/*
udanax-top.st:48477:HashTable methodsFor: 'accessing'!
{XnRegion} domain
	self subclassResponsibility.!
*/
}

public Heaper fetch(Position key) {
throw new UnsupportedOperationException();/*
udanax-top.st:48481:HashTable methodsFor: 'accessing'!
{Heaper} fetch: key {Position} 
	self subclassResponsibility!
*/
}

public ScruTable subTable(XnRegion reg) {
throw new UnsupportedOperationException();/*
udanax-top.st:48485:HashTable methodsFor: 'accessing'!
{ScruTable} subTable: reg {XnRegion} 
	self subclassResponsibility!
*/
}

/**
 * Remove a key->value association from the table.
 * Do not blast (or do anything else) if the key is not in my current domain.
 */
public boolean wipe(Position anIdx) {
throw new UnsupportedOperationException();/*
udanax-top.st:48489:HashTable methodsFor: 'accessing'!
{BooleanVar} wipe: anIdx {Position}
	"Remove a key->value association from the table.
	 Do not blast (or do anything else) if the key is not in my current domain."
	self subclassResponsibility!
*/
}

public boolean includesKey(Position aKey) {
throw new UnsupportedOperationException();/*
udanax-top.st:48497:HashTable methodsFor: 'testing'!
{BooleanVar} includesKey: aKey {Position}
	self subclassResponsibility!
*/
}

public boolean isEmpty() {
throw new UnsupportedOperationException();/*
udanax-top.st:48500:HashTable methodsFor: 'testing'!
{BooleanVar} isEmpty
	self subclassResponsibility.!
*/
}

public TableStepper stepper(OrderSpec order) {
throw new UnsupportedOperationException();/*
udanax-top.st:48505:HashTable methodsFor: 'enumerating'!
{TableStepper} stepper: order {OrderSpec default: NULL}
	self subclassResponsibility!
*/
}

public Heaper theOne() {
throw new UnsupportedOperationException();/*
udanax-top.st:48508:HashTable methodsFor: 'enumerating'!
{Heaper} theOne
	self subclassResponsibility!
*/
}

public XnRegion runAt(Position key) {
throw new UnsupportedOperationException();/*
udanax-top.st:48513:HashTable methodsFor: 'runs'!
{XnRegion} runAt: key {Position} 
	self subclassResponsibility!
*/
}

public ScruTable copy() {
throw new UnsupportedOperationException();/*
udanax-top.st:48519:HashTable methodsFor: 'creation'!
{ScruTable} copy
	self subclassResponsibility!
*/
}

public ScruTable emptySize(IntegerVar size) {
throw new UnsupportedOperationException();/*
udanax-top.st:48522:HashTable methodsFor: 'creation'!
{ScruTable} emptySize: size {IntegerVar}
	self subclassResponsibility!
*/
}

public  HashTable() {
throw new UnsupportedOperationException();/*
udanax-top.st:48528:HashTable methodsFor: 'protected: create'!
create
	super create!
*/
}

public static Heaper make(CoordinateSpace cs) {
throw new UnsupportedOperationException();/*
udanax-top.st:48540:HashTable class methodsFor: 'pseudo constructors'!
{HashTable INLINE} make.CoordinateSpace: cs {CoordinateSpace}
	^ActualHashTable make: cs!
*/
}

public static Heaper make(CoordinateSpace cs, IntegerVar size) {
throw new UnsupportedOperationException();/*
udanax-top.st:48543:HashTable class methodsFor: 'pseudo constructors'!
make.CoordinateSpace: cs {CoordinateSpace} with: size {IntegerVar}
	^ActualHashTable make: cs with: (size DOTasLong bitOr: 1)!
*/
}

public static void initTimeNonInherited() {
throw new UnsupportedOperationException();/*
udanax-top.st:48548:HashTable class methodsFor: 'smalltalk: initialization'!
initTimeNonInherited
	self REQUIRES: ImmuSet. "for the empty set domain"
	self REQUIRES: LPPrimeSizeProvider!
*/
}
}
