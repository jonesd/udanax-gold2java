/*
 * Abora-Gold
 * Part of the Abora hypertext project: http://www.abora.org
 * Copyright 2003 David G Jones
 * 
 * Translated from Udanax-Gold source code: http://www.udanax.com
 * Copyright 1979-1999 Udanax.com. All rights reserved
 */
package org.abora.gold.collection.tables;

import java.io.PrintWriter;
import org.abora.gold.collection.steppers.TableStepper;
import org.abora.gold.collection.tables.ImmuTable;
import org.abora.gold.collection.tables.MuTable;
import org.abora.gold.collection.tables.ScruTable;
import org.abora.gold.java.missing.IntegerVar;
import org.abora.gold.spaces.basic.CoordinateSpace;
import org.abora.gold.spaces.basic.OrderSpec;
import org.abora.gold.spaces.basic.Position;
import org.abora.gold.spaces.basic.XnRegion;
import org.abora.gold.xcvr.Rcvr;
import org.abora.gold.xcvr.Xmtr;
import org.abora.gold.xpp.basic.Heaper;


public class ImmuTableOnMu extends ImmuTable {
	protected MuTable myMuTable;
/*
udanax-top.st:47406:
ImmuTable subclass: #ImmuTableOnMu
	instanceVariableNames: 'myMuTable {MuTable}'
	classVariableNames: ''
	poolDictionaries: ''
	category: 'Xanadu-Collection-Tables'!
*/
/*
udanax-top.st:47410:
(ImmuTableOnMu getOrMakeCxxClassDescription)
	friends:
'friend SPTR(ImmuTable) immuTable (MuTable*);
friend SPTR(ImmuTable) immuTable (CoordinateSpace * cs);
friend SPTR(ImmuTable) MuTable::asImmuTable ();';
	attributes: ((Set new) add: #CONCRETE; add: #NOT.A.TYPE; add: #COPY; yourself)!
*/

/**
 * use the given Mu to store current value
 */
public  ImmuTableOnMu(MuTable aMuTable) {
throw new UnsupportedOperationException();/*
udanax-top.st:47419:ImmuTableOnMu methodsFor: 'private: instance creation'!
create: aMuTable {MuTable}
	"use the given Mu to store current value"
	"it should be a copy for my exclusive use"
	"this should only be called from the pseudo constructor or from class methods"
	super create.
	myMuTable _ aMuTable!
*/
}

public CoordinateSpace coordinateSpace() {
throw new UnsupportedOperationException();/*
udanax-top.st:47429:ImmuTableOnMu methodsFor: 'accessing'!
{CoordinateSpace} coordinateSpace
	
	^myMuTable coordinateSpace!
*/
}

public IntegerVar count() {
throw new UnsupportedOperationException();/*
udanax-top.st:47433:ImmuTableOnMu methodsFor: 'accessing'!
{IntegerVar} count
	^myMuTable count!
*/
}

public XnRegion domain() {
throw new UnsupportedOperationException();/*
udanax-top.st:47437:ImmuTableOnMu methodsFor: 'accessing'!
{XnRegion} domain
	^myMuTable domain!
*/
}

public Heaper fetch(Position key) {
throw new UnsupportedOperationException();/*
udanax-top.st:47441:ImmuTableOnMu methodsFor: 'accessing'!
{Heaper} fetch: key {Position} 
	^myMuTable fetch: key!
*/
}

public Heaper intFetch(IntegerVar key) {
throw new UnsupportedOperationException();/*
udanax-top.st:47445:ImmuTableOnMu methodsFor: 'accessing'!
{Heaper} intFetch: key {IntegerVar}
	^myMuTable intFetch: key!
*/
}

public ScruTable subTable(XnRegion region) {
throw new UnsupportedOperationException();/*
udanax-top.st:47448:ImmuTableOnMu methodsFor: 'accessing'!
{ScruTable} subTable: region {XnRegion} 
	^ImmuTableOnMu create: ((myMuTable subTable: region) cast: MuTable)!
*/
}

public ImmuTable combineWith(ImmuTable other) {
throw new UnsupportedOperationException();/*
udanax-top.st:47454:ImmuTableOnMu methodsFor: 'SEF manipulation'!
{ImmuTable} combineWith: other {ImmuTable}
	| newMuTable {MuTable} others {TableStepper} |
	newMuTable _ myMuTable copy cast: MuTable.
	others _ other stepper.
	[others hasValue] whileTrue:
		[newMuTable at: others position store: others fetch.
		others step].
	others destroy.
	^ImmuTableOnMu create: newMuTable!
*/
}

public ImmuTable without(Position index) {
throw new UnsupportedOperationException();/*
udanax-top.st:47465:ImmuTableOnMu methodsFor: 'SEF manipulation'!
{ImmuTable} without: index {Position}
	| newMuTable {MuTable} |
	newMuTable _ myMuTable copy cast: MuTable.
	newMuTable wipe: index.
	^ ImmuTableOnMu create: newMuTable!
*/
}

public MuTable asMuTable() {
throw new UnsupportedOperationException();/*
udanax-top.st:47474:ImmuTableOnMu methodsFor: 'conversion'!
{MuTable} asMuTable
	^myMuTable copy cast: MuTable!
*/
}

public boolean includesIntKey(IntegerVar aKey) {
throw new UnsupportedOperationException();/*
udanax-top.st:47480:ImmuTableOnMu methodsFor: 'testing'!
{BooleanVar} includesIntKey: aKey {IntegerVar}
	^ myMuTable includesIntKey: aKey!
*/
}

public boolean includesKey(Position aKey) {
throw new UnsupportedOperationException();/*
udanax-top.st:47483:ImmuTableOnMu methodsFor: 'testing'!
{BooleanVar} includesKey: aKey {Position}
	^ myMuTable includesKey: aKey!
*/
}

public boolean isEmpty() {
throw new UnsupportedOperationException();/*
udanax-top.st:47486:ImmuTableOnMu methodsFor: 'testing'!
{BooleanVar} isEmpty
	^myMuTable isEmpty!
*/
}

public TableStepper stepper(OrderSpec order) {
throw new UnsupportedOperationException();/*
udanax-top.st:47491:ImmuTableOnMu methodsFor: 'enumerating'!
{TableStepper} stepper: order {OrderSpec default: NULL}
	^myMuTable copy stepper: order	"making the copy prevents anyone from getting access to the array through TableStepper array"!
*/
}

public Heaper theOne() {
throw new UnsupportedOperationException();/*
udanax-top.st:47494:ImmuTableOnMu methodsFor: 'enumerating'!
{Heaper} theOne
	^ myMuTable theOne!
*/
}

public MuTable getMuTable() {
throw new UnsupportedOperationException();/*
udanax-top.st:47499:ImmuTableOnMu methodsFor: 'private: accessing'!
{MuTable} getMuTable
	^myMuTable!
*/
}

public ScruTable emptySize(IntegerVar size) {
throw new UnsupportedOperationException();/*
udanax-top.st:47504:ImmuTableOnMu methodsFor: 'creation'!
{ScruTable} emptySize: size {IntegerVar}
	^ImmuTableOnMu create: ((myMuTable emptySize: size) cast: MuTable)!
*/
}

public XnRegion runAt(Position key) {
throw new UnsupportedOperationException();/*
udanax-top.st:47510:ImmuTableOnMu methodsFor: 'runs'!
{XnRegion} runAt: key {Position} 
	^myMuTable runAt: key!
*/
}

public XnRegion runAtInt(IntegerVar key) {
throw new UnsupportedOperationException();/*
udanax-top.st:47514:ImmuTableOnMu methodsFor: 'runs'!
{XnRegion} runAtInt: key {IntegerVar}
	^myMuTable runAtInt: key!
*/
}

public void printOn(PrintWriter oo) {
throw new UnsupportedOperationException();/*
udanax-top.st:47519:ImmuTableOnMu methodsFor: 'printing'!
{void} printOn: oo {ostream reference}
	oo << self getCategory name << '(' << myMuTable << ')'!
*/
}

public  ImmuTableOnMu(Rcvr receiver) {
throw new UnsupportedOperationException();/*
udanax-top.st:47525:ImmuTableOnMu methodsFor: 'generated:'!
create.Rcvr: receiver {Rcvr}
	super create.Rcvr: receiver.
	myMuTable _ receiver receiveHeaper.!
*/
}

public void sendSelfTo(Xmtr xmtr) {
throw new UnsupportedOperationException();/*
udanax-top.st:47529:ImmuTableOnMu methodsFor: 'generated:'!
{void} sendSelfTo: xmtr {Xmtr}
	super sendSelfTo: xmtr.
	xmtr sendHeaper: myMuTable.!
*/
}
}
