/*
 * Abora-Gold
 * Part of the Abora hypertext project: http://www.abora.org
 * Copyright 2003 David G Jones
 * 
 * Translated from Udanax-Gold source code: http://www.udanax.com
 * Copyright 1979-1999 Udanax.com. All rights reserved
 */
package org.abora.gold.collection.tables;

import java.io.PrintWriter;
import org.abora.gold.collection.basic.PtrArray;
import org.abora.gold.collection.steppers.TableStepper;
import org.abora.gold.collection.tables.OberIntegerTable;
import org.abora.gold.collection.tables.ScruTable;
import org.abora.gold.java.missing.IntegerVar;
import org.abora.gold.spaces.basic.CoordinateSpace;
import org.abora.gold.spaces.basic.OrderSpec;
import org.abora.gold.spaces.basic.Position;
import org.abora.gold.spaces.basic.XnRegion;
import org.abora.gold.spaces.integers.IntegerRegion;
import org.abora.gold.xcvr.Rcvr;
import org.abora.gold.xcvr.Xmtr;
import org.abora.gold.xpp.basic.Heaper;


/**
 * The IntegerTable class is intended to provide an integer indexed
 * table which is not constrained to be zero based.
 */
public class ActualIntegerTable extends OberIntegerTable {
	protected PtrArray elements;
	protected IntegerVar start;
	protected int elemCount;
	protected int firstElem;
	protected int lastElem;
	protected int tally;
	protected boolean domainIsSimple;
/*
udanax-top.st:49748:
OberIntegerTable subclass: #ActualIntegerTable
	instanceVariableNames: '
		elements {PtrArray}
		start {IntegerVar}
		elemCount {UInt32}
		firstElem {UInt32}
		lastElem {UInt32}
		tally {UInt32}
		domainIsSimple {BooleanVar}'
	classVariableNames: ''
	poolDictionaries: ''
	category: 'Xanadu-Collection-Tables'!
*/
/*
udanax-top.st:49759:
ActualIntegerTable comment:
'The IntegerTable class is intended to provide an integer indexed
table which is not constrained to be zero based.'!
*/
/*
udanax-top.st:49762:
(ActualIntegerTable getOrMakeCxxClassDescription)
	friends:
'/- friends for class ActualIntegerTable -/
friend class ITAscendingStepper;
friend class ITDescendingStepper;
friend class ITGenericStepper;';
	attributes: ((Set new) add: #CONCRETE; add: #COPY; yourself)!
*/

public int fastHash() {
throw new UnsupportedOperationException();/*
udanax-top.st:49772:ActualIntegerTable methodsFor: 'testing'!
{UInt32} fastHash
	^(((start DOTasLong bitXor: firstElem) bitXor: tally) bitXor: lastElem) + #cat.U.ActualIntegerTable hashForEqual!
*/
}

public boolean includesIntKey(IntegerVar aKey) {
throw new UnsupportedOperationException();/*
udanax-top.st:49775:ActualIntegerTable methodsFor: 'testing'!
{BooleanVar} includesIntKey: aKey {IntegerVar} 
	(aKey < self lowestIndex or: [aKey > self highestIndex])
		ifTrue: [^false]
		ifFalse: [domainIsSimple
				ifTrue: [^true]
				ifFalse: [^(elements fetch: aKey DOTasLong - start DOTasLong) ~~ NULL]]!
*/
}

public boolean isEmpty() {
throw new UnsupportedOperationException();/*
udanax-top.st:49782:ActualIntegerTable methodsFor: 'testing'!
{BooleanVar} isEmpty
	^tally == UInt32Zero!
*/
}

public Heaper atIntStore(IntegerVar index, Heaper value) {
throw new UnsupportedOperationException();/*
udanax-top.st:49787:ActualIntegerTable methodsFor: 'accessing'!
{Heaper} atInt: index {IntegerVar} store: value {Heaper} 
	| reali {Int32} old {Heaper} |
	value == NULL ifTrue: [Heaper BLAST: #NullInsertion].
	tally == UInt32Zero ifTrue: [start _ index].
	index - start >= elemCount
		ifTrue: [self enlargeAfter: index]
		ifFalse: [index < start ifTrue: [self enlargeBefore: index]].
	reali _ (index - start) DOTasLong.
	(old _ elements fetch: reali) == NULL ifTrue: [tally _ tally + 1].
	reali < firstElem ifTrue: [
		(firstElem - reali) > 1 ifTrue: [domainIsSimple _ false].
		firstElem _ reali].
	reali > lastElem ifTrue: [
		(reali - lastElem) > 1 ifTrue: [domainIsSimple _ false].
		lastElem _ reali].
	elements at: reali store: value.
	^ old!
*/
}

public CoordinateSpace coordinateSpace() {
throw new UnsupportedOperationException();/*
udanax-top.st:49805:ActualIntegerTable methodsFor: 'accessing'!
{CoordinateSpace} coordinateSpace
	^IntegerSpace make!
*/
}

public IntegerVar count() {
throw new UnsupportedOperationException();/*
udanax-top.st:49809:ActualIntegerTable methodsFor: 'accessing'!
{IntegerVar} count
	^tally!
*/
}

/**
 */
public XnRegion domain() {
throw new UnsupportedOperationException();/*
udanax-top.st:49813:ActualIntegerTable methodsFor: 'accessing'!
{XnRegion} domain
	""
	"The domainIsSimple flag is used as an optimization in this method.  When it is True, I 
	stop looking after the first simple domain I find.  Therefore, when True, it MUST BE 
	CORRECT.  When it is False, I do a complete search, and set the flag if the domain
	turns out to be simple."
	| newReg {XnRegion} |
	self isEmpty
		ifTrue: [^IntegerRegion make]
		ifFalse: [domainIsSimple
				ifTrue: 
					[^IntegerRegion make: self lowestIndex with: self highestIndex + 1]
				ifFalse: 
					[newReg _ self generateDomain.
					newReg isSimple ifTrue: [domainIsSimple _ true].
					^newReg]]!
*/
}

public IntegerVar highestIndex() {
throw new UnsupportedOperationException();/*
udanax-top.st:49831:ActualIntegerTable methodsFor: 'accessing'!
{IntegerVar} highestIndex
	tally == UInt32Zero ifTrue: [^start].
	^ start + lastElem!
*/
}

public Heaper intFetch(IntegerVar index) {
throw new UnsupportedOperationException();/*
udanax-top.st:49835:ActualIntegerTable methodsFor: 'accessing'!
{Heaper} intFetch: index {IntegerVar} 
	| idx {UInt32}|
	((idx _ (index-start) DOTasLong) >= elemCount or: [index < start])
		ifTrue: [^NULL]
		ifFalse: [^elements fetch: idx]!
*/
}

public boolean intWipe(IntegerVar index) {
throw new UnsupportedOperationException();/*
udanax-top.st:49842:ActualIntegerTable methodsFor: 'accessing'!
{BooleanVar} intWipe: index {IntegerVar} 
	| reali {UInt32} wiped {BooleanVar} |
	wiped _ false.
	reali _ (index - start) DOTasLong.
	(reali > lastElem or: [reali < firstElem])
		ifFalse: 
			[(elements fetch: reali) ~~ NULL ifTrue: [tally _ tally - 1. wiped _ true].
			elements at: reali store: NULL.
			reali == firstElem
				ifTrue: [firstElem _ self firstElemAfter: reali]
				ifFalse: [reali == lastElem
						ifTrue: [lastElem _ self lastElemBefore: reali]
						ifFalse: [domainIsSimple _ false]]].
	^ wiped!
*/
}

public IntegerVar lowestIndex() {
throw new UnsupportedOperationException();/*
udanax-top.st:49857:ActualIntegerTable methodsFor: 'accessing'!
{IntegerVar} lowestIndex
	tally == UInt32Zero ifTrue: [^start].
	^ start + firstElem!
*/
}

public ScruTable copy() {
throw new UnsupportedOperationException();/*
udanax-top.st:49864:ActualIntegerTable methodsFor: 'creation'!
{ScruTable} copy
	^ ActualIntegerTable 
		create: (elements copy cast: PtrArray)
		with: start
		with: elemCount
		with: firstElem
		with: lastElem
		with: tally
		with: domainIsSimple!
*/
}

/**
 * The optional argument just hints at the number of elements
 * to eventually be added.  It makes no difference semantically.
 */
public  ActualIntegerTable() {
throw new UnsupportedOperationException();/*
udanax-top.st:49874:ActualIntegerTable methodsFor: 'creation'!
create
	"The optional argument just hints at the number of elements
	 to eventually be added.  It makes no difference semantically."
	super create.
	elements _ PtrArray nulls: 8.
	start _ IntegerVar0.
	firstElem _ 7.
	lastElem _ UInt32Zero.
	elemCount _ 8.
	tally _ UInt32Zero.
	domainIsSimple _ true.!
*/
}

/**
 * The optional argument just hints at the number of elements
 * to eventually be added.  It makes no difference semantically.
 */
public  ActualIntegerTable(IntegerVar size) {
throw new UnsupportedOperationException();/*
udanax-top.st:49886:ActualIntegerTable methodsFor: 'creation'!
create.IntegerVar: size {IntegerVar} 
	"The optional argument just hints at the number of elements
	 to eventually be added.  It makes no difference semantically."
	super create.
	size > IntegerVar0 ifTrue: [elemCount _ size DOTasLong] ifFalse: [elemCount _ 4].
	elements _ PtrArray nulls: elemCount.
	start _ IntegerVar0.
	tally _ UInt32Zero.
	firstElem _ elemCount - 1.
	lastElem _ UInt32Zero.
	domainIsSimple _ true.!
*/
}

/**
 * Hint at the domain to be accessed (inclusive, exclusive).
 */
public  ActualIntegerTable(IntegerVar begin, IntegerVar end) {
throw new UnsupportedOperationException();/*
udanax-top.st:49899:ActualIntegerTable methodsFor: 'creation'!
create: begin {IntegerVar} with: end {IntegerVar} 
	"Hint at the domain to be accessed (inclusive, exclusive)."
	super create.
	start _ begin.
	elemCount _ (end - start) DOTasLong.
	elemCount < 4 ifTrue: [elemCount _ 4].
	elements _ PtrArray nulls: elemCount.
	firstElem _ elemCount - 1.
	lastElem _ UInt32Zero.
	tally _ UInt32Zero.
	domainIsSimple _ true!
*/
}

public  ActualIntegerTable(PtrArray array, IntegerVar begin, int count, int first, int last, int aTally, boolean simple) {
throw new UnsupportedOperationException();/*
udanax-top.st:49912:ActualIntegerTable methodsFor: 'creation'!
create: array {PtrArray} with: begin {IntegerVar} with: count {UInt32} with: first {UInt32} with: last {UInt32} with: aTally {UInt32} with: simple {BooleanVar}
	super create.
	elements  := array.
	start := begin.
	elemCount := count.
	firstElem := first.
	lastElem := last.
	tally := aTally.
	domainIsSimple := simple!
*/
}

public void destroy() {
throw new UnsupportedOperationException();/*
udanax-top.st:49922:ActualIntegerTable methodsFor: 'creation'!
{void} destroy
	self getNextCOW == NULL ifTrue:
		[super destroy]!
*/
}

public ScruTable emptySize(IntegerVar size) {
throw new UnsupportedOperationException();/*
udanax-top.st:49926:ActualIntegerTable methodsFor: 'creation'!
{ScruTable} emptySize: size {IntegerVar unused}
	^IntegerTable make.IntegerVar: (self lowestIndex) with: (self highestIndex + 1)!
*/
}

/**
 * Copy the given range into a new IntegerTable.
 * The range is startIndex (inclusive) to stopIndex (exclusive)
 * The first element in the sub table will be at firstIndex
 */
public ScruTable offsetSubTableBetween(IntegerVar startIndex, IntegerVar stopIndex, IntegerVar firstIndex) {
throw new UnsupportedOperationException();/*
udanax-top.st:49930:ActualIntegerTable methodsFor: 'creation'!
{ScruTable} offsetSubTableBetween: startIndex {IntegerVar} 
	with: stopIndex {IntegerVar} 
	with: firstIndex {IntegerVar} 
	"Copy the given range into a new IntegerTable. 
	The range is startIndex (inclusive) to stopIndex (exclusive)
	The first element in the sub table will be at firstIndex"
	| table {IntegerTable} theEnd {IntegerVar} |
	theEnd _ firstIndex + stopIndex - startIndex - 1.
	table _ IntegerTable make.IntegerVar: firstIndex with: theEnd.
	firstIndex to: theEnd do: 
		[:i {IntegerVar} | 
		| val {Heaper wimpy} |
		val _ self intFetch: i + startIndex - firstIndex.
		val == NULL ifFalse: [table atInt: i introduce: val]].
	^table!
*/
}

public ScruTable subTable(XnRegion reg) {
throw new UnsupportedOperationException();/*
udanax-top.st:49947:ActualIntegerTable methodsFor: 'creation'!
{ScruTable} subTable: reg {XnRegion} 
	| subRegion {IntegerRegion} |
	subRegion _ (reg intersect: self domain asSimpleRegion)
				cast: IntegerRegion.
	subRegion isEmpty ifTrue: [^ self emptySize: (self count max: 1)].
	^self subTableBetween: subRegion start with: subRegion stop!
*/
}

/**
 * Hack for C++ overloading problem
 */
public ScruTable subTableBetween(IntegerVar startIndex, IntegerVar stopIndex) {
throw new UnsupportedOperationException();/*
udanax-top.st:49955:ActualIntegerTable methodsFor: 'creation'!
{ScruTable} subTableBetween: startIndex {IntegerVar} with: stopIndex {IntegerVar}
	"Hack for C++ overloading problem"
	^self offsetSubTableBetween: startIndex with: stopIndex with: startIndex!
*/
}

public XnRegion runAtInt(IntegerVar anIdx) {
throw new UnsupportedOperationException();/*
udanax-top.st:49961:ActualIntegerTable methodsFor: 'runs'!
{XnRegion} runAtInt: anIdx {IntegerVar} 
	| idx {UInt32} lastObj {Heaper} notDone {BooleanVar} |
	idx _ (anIdx - start) DOTasLong.
	tally == UInt32Zero ifTrue: [^ IntegerRegion make].
	(idx < firstElem or: [idx > lastElem])
		ifTrue: [^IntegerRegion make: anIdx with: anIdx].
	notDone _ true.
	(lastObj _ elements fetch: idx) == NULL
		ifTrue: [[idx <= lastElem and: [notDone]]
				whileTrue: [(elements fetch: idx) == NULL
						ifTrue: [idx _ idx + 1]
						ifFalse: [notDone _ false]]]
		ifFalse: [[idx <= lastElem and: [notDone]]
				whileTrue: [(elements fetch: idx) ~~ NULL
						ifTrue: [((elements fetch: idx) isEqual: lastObj)
								ifTrue: [idx _ idx + 1]
								ifFalse: [notDone _ false]]
						ifFalse: [notDone _ false]]].
	^IntegerRegion make: anIdx with: (start + idx)!
*/
}

public void printOn(PrintWriter aStream) {
throw new UnsupportedOperationException();/*
udanax-top.st:49983:ActualIntegerTable methodsFor: 'printing'!
{void} printOn: aStream {ostream reference} 
	aStream << self getCategory name.
	self printOnWithSimpleSyntax: aStream
		with: '['
		with: ','
		with: ']'!
*/
}

/**
 * ignore order spec for now
 */
public TableStepper stepper(OrderSpec order) {
throw new UnsupportedOperationException();/*
udanax-top.st:49992:ActualIntegerTable methodsFor: 'enumerating'!
{TableStepper} stepper: order {OrderSpec default: NULL} 
	"ignore order spec for now"
	"Note that this method depends on the ITAscendingStepper NOT copying the table."
	order == NULL
		ifTrue: [tally == UInt32Zero
				ifTrue: [^IntegerTableStepper
						make: self
						with: start
						with: start]
				ifFalse: [^ITAscendingStepper
						create: (self copy cast: OberIntegerTable)
						with: start + firstElem "self lowestIndex"
						with: start + lastElem "self highestIndex"]]
		ifFalse: [^IntegerTableStepper make: self with: order]!
*/
}

public Heaper theOne() {
throw new UnsupportedOperationException();/*
udanax-top.st:50007:ActualIntegerTable methodsFor: 'enumerating'!
{Heaper} theOne
	self count ~~ 1 ifTrue:
		[ Heaper BLAST: #NotOneElement ].
	^ self intFetch: self lowestIndex!
*/
}

public IntegerRegion contigDomainStarting(int anIdx) {
throw new UnsupportedOperationException();/*
udanax-top.st:50014:ActualIntegerTable methodsFor: 'private:'!
{IntegerRegion} contigDomainStarting: anIdx {UInt32} 
	| begin {UInt32} tIdx {UInt32} |
	tIdx _ begin _ anIdx.
	[tIdx <= lastElem and: [(elements fetch: tIdx) ~~ NULL]]
		whileTrue: [tIdx _ tIdx + 1].
	tIdx > begin
		ifTrue: [^IntegerRegion make: start + begin with: start + tIdx]
		ifFalse: [^IntegerRegion make: anIdx with: anIdx]!
*/
}

/**
 * return the elements array for rapid processing
 */
public PtrArray elementsArray() {
throw new UnsupportedOperationException();/*
udanax-top.st:50023:ActualIntegerTable methodsFor: 'private:'!
{PtrArray} elementsArray
	"return the elements array for rapid processing"
	^ elements!
*/
}

/**
 * return the size of the elements array for rapid processing
 */
public int endOffset() {
throw new UnsupportedOperationException();/*
udanax-top.st:50027:ActualIntegerTable methodsFor: 'private:'!
{UInt32} endOffset
	"return the size of the elements array for rapid processing"
	^ lastElem!
*/
}

/**
 * Enlarge the receiver to contain more slots filled with nil.
 */
public void enlargeAfter(IntegerVar toMinimum) {
throw new UnsupportedOperationException();/*
udanax-top.st:50031:ActualIntegerTable methodsFor: 'private:'!
{void} enlargeAfter: toMinimum {IntegerVar}
	"Enlarge the receiver to contain more slots filled with nil."
	| newElements{PtrArray} oldElements {PtrArray wimpy} tmp {UInt32} newSize {UInt32} |
	newSize _ elemCount * 2.
	newSize < 4 ifTrue: [newSize _ 4].
	(newSize < (tmp _ (toMinimum - start) DOTasLong + 1)) ifTrue: [newSize _ tmp].
	newElements _ PtrArray nulls: newSize.
	UInt32Zero almostTo: elemCount do: [:i {UInt32} | 
		newElements at: i store: (elements fetch: i)].
	"Just for the hell of it, I make this robust for asynchronous readers..."
	oldElements _ elements.
	elements _ newElements.
	oldElements destroy.
	elemCount _ newSize.
	tally == UInt32Zero ifTrue: [firstElem _ elements count - 1]!
*/
}

/**
 * Enlarge the receiver to contain more slots filled with nil.
 */
public void enlargeBefore(IntegerVar toMinimum) {
throw new UnsupportedOperationException();/*
udanax-top.st:50048:ActualIntegerTable methodsFor: 'private:'!
{void} enlargeBefore: toMinimum {IntegerVar} 
	"Enlarge the receiver to contain more slots filled with nil."
	| newSize {UInt32} newElements {PtrArray} oldElements {PtrArray wimpy} offset {UInt32} tmp {UInt32} stop {IntegerVar} |
	stop _ start + elemCount.
	newSize _ elemCount * 2.
	newSize < 4 ifTrue: [newSize _ 4].
	newSize < (tmp _ (stop - toMinimum) DOTasLong + 1) ifTrue: [newSize _ tmp].
	newElements _ PtrArray nulls: newSize.
	offset _ newSize - elemCount.
	UInt32Zero almostTo: elemCount do: [:i {UInt32} | 
		newElements at: i + offset store: (elements fetch: i)].
	oldElements _ elements.
	elements _ newElements.
	oldElements destroy.
	start _ stop - newSize.
	firstElem _ firstElem + offset.
	lastElem _ lastElem + offset.
	elemCount _ newSize!
*/
}

/**
 * This method returns the first table entry that is not NULL after index.
 */
public int firstElemAfter(int index) {
throw new UnsupportedOperationException();/*
udanax-top.st:50068:ActualIntegerTable methodsFor: 'private:'!
{UInt32} firstElemAfter: index {UInt32}
	"This method returns the first table entry that is not NULL after index."
	 
	| idx {UInt32} |
	(tally == UInt32Zero) ifTrue: [^elemCount].
	idx _ index + 1.
	[(idx < lastElem) and: [(elements fetch: idx) == NULL]] whileTrue: [idx _ idx + 1].
	^ idx!
*/
}

public IntegerRegion generateDomain() {
throw new UnsupportedOperationException();/*
udanax-top.st:50078:ActualIntegerTable methodsFor: 'private:'!
{IntegerRegion} generateDomain
	| begin {UInt32} resReg {IntegerRegion} nextReg {IntegerRegion} |
	resReg _ IntegerRegion make.
	tally == UInt32Zero ifTrue: [^resReg].
	begin _ firstElem.
	[begin <= lastElem]
		whileTrue: 
			[nextReg _ self contigDomainStarting: begin.
			nextReg isEmpty
				ifTrue: [nextReg _ self nullDomainStarting: begin]
				ifFalse: [resReg _ (resReg unionWith: nextReg)
								cast: IntegerRegion].
			begin _ (nextReg stop - start) DOTasLong].
	^resReg!
*/
}

/**
 * This method returns the first table entry that is not NULL after index.
 */
public int lastElemBefore(int index) {
throw new UnsupportedOperationException();/*
udanax-top.st:50093:ActualIntegerTable methodsFor: 'private:'!
{UInt32} lastElemBefore: index {UInt32}
	"This method returns the first table entry that is not NULL after index."
	 
	| idx {UInt32} |
	(tally == UInt32Zero) ifTrue: [^UInt32Zero].
	idx _ index - 1.
	[(idx > firstElem) and: [(elements fetch: idx) == NULL]] whileTrue: [idx _ idx - 1].
	^ idx!
*/
}

/**
 * return the size of the elements array for rapid processing
 */
public int maxElements() {
throw new UnsupportedOperationException();/*
udanax-top.st:50103:ActualIntegerTable methodsFor: 'private:'!
{UInt32} maxElements
	"return the size of the elements array for rapid processing"
	^ elemCount!
*/
}

public IntegerRegion nullDomainStarting(int anIdx) {
throw new UnsupportedOperationException();/*
udanax-top.st:50107:ActualIntegerTable methodsFor: 'private:'!
{IntegerRegion} nullDomainStarting: anIdx {UInt32} 
	| begin {UInt32} tIdx {UInt32} |
	tIdx _ begin _ anIdx.
	[tIdx <= lastElem and: [(elements fetch: tIdx) == NULL]]
		whileTrue: [tIdx _ tIdx + 1].
	tIdx > begin
		ifTrue: [^IntegerRegion make: start + begin with: start + tIdx]
		ifFalse: [^IntegerRegion make: anIdx with: anIdx]!
*/
}

/**
 * return the size of the elements array for rapid processing
 */
public IntegerVar startIndex() {
throw new UnsupportedOperationException();/*
udanax-top.st:50116:ActualIntegerTable methodsFor: 'private:'!
{IntegerVar} startIndex
	"return the size of the elements array for rapid processing"
	^ start!
*/
}

/**
 * return the size of the elements array for rapid processing
 */
public int startOffset() {
throw new UnsupportedOperationException();/*
udanax-top.st:50120:ActualIntegerTable methodsFor: 'private:'!
{UInt32} startOffset
	"return the size of the elements array for rapid processing"
	^ firstElem!
*/
}

public void fixup() {
throw new UnsupportedOperationException();/*
udanax-top.st:50126:ActualIntegerTable methodsFor: 'smalltalk: private:'!
fixup
	super fixup.
	[((elements fetch: lastElem) == NULL) and: [lastElem > 0]] whileTrue: [
		Transcript show: 'd'.
		lastElem _ lastElem - 1]!
*/
}

public void inspect() {
throw new UnsupportedOperationException();/*
udanax-top.st:50132:ActualIntegerTable methodsFor: 'smalltalk: private:'!
{void} inspect
	^InspectorView open: (IntegerTableInspector inspect: self)!
*/
}

public void destruct() {
throw new UnsupportedOperationException();/*
udanax-top.st:50137:ActualIntegerTable methodsFor: 'protected: destruct'!
{void} destruct
	elements destroy.
	elements _ NULL.
	super destruct!
*/
}

public void becomeCloneOnWrite(Heaper where) {
throw new UnsupportedOperationException();/*
udanax-top.st:50144:ActualIntegerTable methodsFor: 'protected: COW stuff'!
{void} becomeCloneOnWrite: where {Heaper}
	| tmp {IntegerTable} source {TableStepper} |
	tmp _ (ActualIntegerTable new.Become: where) create: start with: (start + lastElem).
	tally == UInt32Zero ifTrue: [^ VOID].
	source _ ITAscendingStepper create: self with: start + firstElem with: start + lastElem.
	source forEach: [ :tableElem {Heaper} |
		tmp at: source position store: tableElem].!
*/
}

public Heaper atStore(Position key, Heaper value) {
throw new UnsupportedOperationException();/*
udanax-top.st:50154:ActualIntegerTable methodsFor: 'overload junk'!
{Heaper} at: key {Position} store: value {Heaper} 
	^ self atInt: (key cast: IntegerPos) asIntegerVar store: value!
*/
}

public Heaper fetch(Position key) {
throw new UnsupportedOperationException();/*
udanax-top.st:50158:ActualIntegerTable methodsFor: 'overload junk'!
{Heaper} fetch: key {Position} 
	^ self intFetch: ((key cast: IntegerPos) asIntegerVar)!
*/
}

public boolean includesKey(Position aKey) {
throw new UnsupportedOperationException();/*
udanax-top.st:50162:ActualIntegerTable methodsFor: 'overload junk'!
{BooleanVar} includesKey: aKey {Position}
	^ self includesIntKey: ((aKey cast: IntegerPos) asIntegerVar)!
*/
}

public XnRegion runAt(Position anIdx) {
throw new UnsupportedOperationException();/*
udanax-top.st:50165:ActualIntegerTable methodsFor: 'overload junk'!
{XnRegion} runAt: anIdx {Position} 
	^ self runAtInt: ((anIdx cast: IntegerPos) asIntegerVar)!
*/
}

public boolean wipe(Position key) {
throw new UnsupportedOperationException();/*
udanax-top.st:50168:ActualIntegerTable methodsFor: 'overload junk'!
{BooleanVar} wipe: key {Position}
	^ self intWipe: ((key cast: IntegerPos) asIntegerVar)!
*/
}

public  ActualIntegerTable(Rcvr receiver) {
throw new UnsupportedOperationException();/*
udanax-top.st:50173:ActualIntegerTable methodsFor: 'generated:'!
create.Rcvr: receiver {Rcvr}
	super create.Rcvr: receiver.
	elements _ receiver receiveHeaper.
	start _ receiver receiveIntegerVar.
	elemCount _ receiver receiveUInt32.
	firstElem _ receiver receiveUInt32.
	lastElem _ receiver receiveUInt32.
	tally _ receiver receiveUInt32.
	domainIsSimple _ receiver receiveBooleanVar.!
*/
}

public void sendSelfTo(Xmtr xmtr) {
throw new UnsupportedOperationException();/*
udanax-top.st:50183:ActualIntegerTable methodsFor: 'generated:'!
{void} sendSelfTo: xmtr {Xmtr}
	super sendSelfTo: xmtr.
	xmtr sendHeaper: elements.
	xmtr sendIntegerVar: start.
	xmtr sendUInt32: elemCount.
	xmtr sendUInt32: firstElem.
	xmtr sendUInt32: lastElem.
	xmtr sendUInt32: tally.
	xmtr sendBooleanVar: domainIsSimple.!
*/
}
}
