/*
 * Abora-Gold
 * Part of the Abora hypertext project: http://www.abora.org
 * Copyright 2003 David G Jones
 * 
 * Translated from Udanax-Gold source code: http://www.udanax.com
 * Copyright 1979-1999 Udanax.com. All rights reserved
 */
package org.abora.gold.collection.tables;

import org.abora.gold.collection.steppers.TableStepper;
import org.abora.gold.collection.tables.ImmuTable;
import org.abora.gold.collection.tables.IntegerTable;
import org.abora.gold.collection.tables.MuTable;
import org.abora.gold.collection.tables.ScruTable;
import org.abora.gold.java.missing.IntegerVar;
import org.abora.gold.spaces.basic.CoordinateSpace;
import org.abora.gold.spaces.basic.OrderSpec;
import org.abora.gold.spaces.basic.Position;
import org.abora.gold.spaces.basic.XnRegion;
import org.abora.gold.xcvr.Rcvr;
import org.abora.gold.xcvr.Xmtr;
import org.abora.gold.xpp.basic.Heaper;


public class IntegerScruTable extends ScruTable {
	protected IntegerTable tableToScru;
/*
udanax-top.st:47661:
ScruTable subclass: #IntegerScruTable
	instanceVariableNames: 'tableToScru {IntegerTable}'
	classVariableNames: ''
	poolDictionaries: ''
	category: 'Xanadu-Collection-Tables'!
*/
/*
udanax-top.st:47665:
(IntegerScruTable getOrMakeCxxClassDescription)
	attributes: ((Set new) add: #CONCRETE; add: #NOT.A.TYPE; add: #COPY; yourself)!
*/
/*
udanax-top.st:47774:
IntegerScruTable class
	instanceVariableNames: ''!
*/
/*
udanax-top.st:47777:
(IntegerScruTable getOrMakeCxxClassDescription)
	attributes: ((Set new) add: #CONCRETE; add: #NOT.A.TYPE; add: #COPY; yourself)!
*/

public CoordinateSpace coordinateSpace() {
throw new UnsupportedOperationException();/*
udanax-top.st:47670:IntegerScruTable methodsFor: 'accessing'!
{CoordinateSpace} coordinateSpace
	
	^IntegerSpace make!
*/
}

public IntegerVar count() {
throw new UnsupportedOperationException();/*
udanax-top.st:47674:IntegerScruTable methodsFor: 'accessing'!
{IntegerVar} count
	^tableToScru count!
*/
}

public XnRegion domain() {
throw new UnsupportedOperationException();/*
udanax-top.st:47678:IntegerScruTable methodsFor: 'accessing'!
{XnRegion} domain
	^ tableToScru domain!
*/
}

public Heaper fetch(Position key) {
throw new UnsupportedOperationException();/*
udanax-top.st:47682:IntegerScruTable methodsFor: 'accessing'!
{Heaper} fetch: key {Position} 
	^ tableToScru fetch: key!
*/
}

public Heaper intFetch(IntegerVar key) {
throw new UnsupportedOperationException();/*
udanax-top.st:47686:IntegerScruTable methodsFor: 'accessing'!
{Heaper} intFetch: key {IntegerVar}
	^ tableToScru intFetch: key!
*/
}

public ScruTable subTable(XnRegion reg) {
throw new UnsupportedOperationException();/*
udanax-top.st:47689:IntegerScruTable methodsFor: 'accessing'!
{ScruTable} subTable: reg {XnRegion} 
	^ tableToScru subTable: reg!
*/
}

/**
 * Return a table which contains the intersection of this table's domain and the
 * domain specified by the enclosure.
 */
public ScruTable subTableBetween(IntegerVar start, IntegerVar stop) {
throw new UnsupportedOperationException();/*
udanax-top.st:47693:IntegerScruTable methodsFor: 'accessing'!
{ScruTable} subTableBetween: start {IntegerVar} with: stop {IntegerVar}
	"Return a table which contains the intersection of this table's domain and the 
	domain specified by the enclosure."
	^ tableToScru offsetSubTableBetween: start with: stop with: start!
*/
}

public ScruTable copy() {
throw new UnsupportedOperationException();/*
udanax-top.st:47701:IntegerScruTable methodsFor: 'creation'!
{ScruTable} copy
	^ IntegerScruTable create: ((tableToScru copy) quickCast: IntegerTable)!
*/
}

public  IntegerScruTable(IntegerTable fromTable) {
throw new UnsupportedOperationException();/*
udanax-top.st:47704:IntegerScruTable methodsFor: 'creation'!
create: fromTable {IntegerTable}
	super create.
	tableToScru _ fromTable!
*/
}

public ScruTable emptySize(IntegerVar size) {
throw new UnsupportedOperationException();/*
udanax-top.st:47708:IntegerScruTable methodsFor: 'creation'!
{ScruTable} emptySize: size {IntegerVar}
	^ IntegerScruTable create.IntegerVar: ((tableToScru emptySize: size) quickCast: IntegerTable)!
*/
}

public XnRegion runAt(Position key) {
throw new UnsupportedOperationException();/*
udanax-top.st:47714:IntegerScruTable methodsFor: 'runs'!
{XnRegion} runAt: key {Position} 
	^ tableToScru runAt: key!
*/
}

public XnRegion runAtInt(IntegerVar key) {
throw new UnsupportedOperationException();/*
udanax-top.st:47718:IntegerScruTable methodsFor: 'runs'!
{XnRegion} runAtInt: key {IntegerVar}
	^ tableToScru runAtInt: key!
*/
}

public int actualHashForEqual() {
throw new UnsupportedOperationException();/*
udanax-top.st:47723:IntegerScruTable methodsFor: 'testing'!
{UInt32} actualHashForEqual
	^#cat.U.IntegerScruTable hashForEqual + tableToScru hashForEqual!
*/
}

public boolean includesIntKey(IntegerVar aKey) {
throw new UnsupportedOperationException();/*
udanax-top.st:47726:IntegerScruTable methodsFor: 'testing'!
{BooleanVar} includesIntKey: aKey {IntegerVar}
	^ tableToScru includesIntKey: aKey!
*/
}

public boolean includesKey(Position aKey) {
throw new UnsupportedOperationException();/*
udanax-top.st:47729:IntegerScruTable methodsFor: 'testing'!
{BooleanVar} includesKey: aKey {Position}
	^ tableToScru includesKey: aKey!
*/
}

public boolean isEmpty() {
throw new UnsupportedOperationException();/*
udanax-top.st:47732:IntegerScruTable methodsFor: 'testing'!
{BooleanVar} isEmpty
	^ tableToScru isEmpty!
*/
}

public boolean isEqual(Heaper other) {
throw new UnsupportedOperationException();/*
udanax-top.st:47735:IntegerScruTable methodsFor: 'testing'!
{BooleanVar} isEqual: other {Heaper} 
	other
		cast: IntegerScruTable into: [:ist |
			^ist innerTable isEqual: tableToScru]
		others: [^false].
	^ false "compiler fodder"!
*/
}

public TableStepper stepper(OrderSpec order) {
throw new UnsupportedOperationException();/*
udanax-top.st:47745:IntegerScruTable methodsFor: 'enumerating'!
{TableStepper} stepper: order {OrderSpec default: NULL}
	^ tableToScru stepper: order!
*/
}

public ImmuTable asImmuTable() {
throw new UnsupportedOperationException();/*
udanax-top.st:47750:IntegerScruTable methodsFor: 'conversion'!
{ImmuTable} asImmuTable
	^ tableToScru asImmuTable!
*/
}

public MuTable asMuTable() {
throw new UnsupportedOperationException();/*
udanax-top.st:47754:IntegerScruTable methodsFor: 'conversion'!
{MuTable} asMuTable
	^ tableToScru copy asMuTable!
*/
}

public ScruTable innerTable() {
throw new UnsupportedOperationException();/*
udanax-top.st:47760:IntegerScruTable methodsFor: 'private: private'!
{ScruTable} innerTable
	^tableToScru!
*/
}

public  IntegerScruTable(Rcvr receiver) {
throw new UnsupportedOperationException();/*
udanax-top.st:47765:IntegerScruTable methodsFor: 'generated:'!
create.Rcvr: receiver {Rcvr}
	super create.Rcvr: receiver.
	tableToScru _ receiver receiveHeaper.!
*/
}

public void sendSelfTo(Xmtr xmtr) {
throw new UnsupportedOperationException();/*
udanax-top.st:47769:IntegerScruTable methodsFor: 'generated:'!
{void} sendSelfTo: xmtr {Xmtr}
	super sendSelfTo: xmtr.
	xmtr sendHeaper: tableToScru.!
*/
}

public static Heaper make(IntegerTable fromTable) {
throw new UnsupportedOperationException();/*
udanax-top.st:47782:IntegerScruTable class methodsFor: 'pseudo constructors'!
{ScruTable} make: fromTable {IntegerTable}
	^ IntegerScruTable create: fromTable!
*/
}
}
