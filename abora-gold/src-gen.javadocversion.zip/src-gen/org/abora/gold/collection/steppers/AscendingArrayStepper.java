/*
 * Abora-Gold
 * Part of the Abora hypertext project: http://www.abora.org
 * Copyright 2003 David G Jones
 * 
 * Translated from Udanax-Gold source code: http://www.udanax.com
 * Copyright 1979-1999 Udanax.com. All rights reserved
 */
package org.abora.gold.collection.steppers;

import java.io.PrintWriter;
import org.abora.gold.collection.steppers.ArrayStepper;
import org.abora.gold.collection.steppers.Stepper;
import org.abora.gold.collection.steppers.TableStepper;
import org.abora.gold.collection.tables.ActualArray;
import org.abora.gold.java.missing.IntegerVar;
import org.abora.gold.xpp.basic.Heaper;


public class AscendingArrayStepper extends ArrayStepper {
	protected int lastValueInternal;
/*
udanax-top.st:55449:
ArrayStepper subclass: #AscendingArrayStepper
	instanceVariableNames: 'lastValueInternal {Int32}'
	classVariableNames: ''
	poolDictionaries: ''
	category: 'Xanadu-Collection-Steppers'!
*/
/*
udanax-top.st:55453:
(AscendingArrayStepper getOrMakeCxxClassDescription)
	attributes: ((Set new) add: #CONCRETE; add: #NOT.A.TYPE; yourself)!
*/
/*
udanax-top.st:55498:
AscendingArrayStepper class
	instanceVariableNames: ''!
*/
/*
udanax-top.st:55501:
(AscendingArrayStepper getOrMakeCxxClassDescription)
	attributes: ((Set new) add: #CONCRETE; add: #NOT.A.TYPE; yourself)!
*/

public Stepper copy() {
throw new UnsupportedOperationException();/*
udanax-top.st:55458:AscendingArrayStepper methodsFor: 'create'!
{Stepper} copy
	^AscendingArrayStepper
		make: self array
		with: self index
		with: lastValueInternal!
*/
}

public  AscendingArrayStepper(ActualArray array) {
	super(array);
throw new UnsupportedOperationException();/*
udanax-top.st:55466:AscendingArrayStepper methodsFor: 'protected: create'!
create: array {ActualArray}
	super create: array.
	lastValueInternal _ array endOffset!
*/
}

public  AscendingArrayStepper(ActualArray array, IntegerVar index) {
	super(array, index);
throw new UnsupportedOperationException();/*
udanax-top.st:55470:AscendingArrayStepper methodsFor: 'protected: create'!
create: array {ActualArray} with: index {IntegerVar}
	super create: array with: index.
	lastValueInternal _ array endOffset!
*/
}

public  AscendingArrayStepper(ActualArray array, IntegerVar start, IntegerVar stop) {
	super(array, start);
throw new UnsupportedOperationException();/*
udanax-top.st:55474:AscendingArrayStepper methodsFor: 'protected: create'!
create: array {ActualArray} with: start {IntegerVar} with: stop {IntegerVar}
	super create: array with: start.
	lastValueInternal _ stop DOTasLong!
*/
}

public Heaper fetch() {
throw new UnsupportedOperationException();/*
udanax-top.st:55480:AscendingArrayStepper methodsFor: 'operations'!
{Heaper wimpy} fetch
	self hasValue
		ifTrue: [^self array elementsArray fetch: self index DOTasLong]
		ifFalse: [^NULL]!
*/
}

public boolean hasValue() {
throw new UnsupportedOperationException();/*
udanax-top.st:55485:AscendingArrayStepper methodsFor: 'operations'!
{BooleanVar} hasValue
	^self index <= lastValueInternal!
*/
}

public void step() {
throw new UnsupportedOperationException();/*
udanax-top.st:55488:AscendingArrayStepper methodsFor: 'operations'!
{void} step
	self setIndex: self index DOTasLong + 1!
*/
}

public void printOn(PrintWriter oo) {
throw new UnsupportedOperationException();/*
udanax-top.st:55493:AscendingArrayStepper methodsFor: 'printing'!
{void} printOn: oo {ostream reference}
	oo << self getCategory name << ' on ' << (self array subTableBetween: self index with: lastValueInternal)!
*/
}

public static Heaper make(ActualArray array) {
throw new UnsupportedOperationException();/*
udanax-top.st:55506:AscendingArrayStepper class methodsFor: 'create'!
{TableStepper} make: array {ActualArray}
	^ self create: array!
*/
}

public static Heaper make(ActualArray array, IntegerVar index) {
throw new UnsupportedOperationException();/*
udanax-top.st:55509:AscendingArrayStepper class methodsFor: 'create'!
{TableStepper} make: array {ActualArray} with: index {IntegerVar}
	^ self create: array with: index!
*/
}

public static Heaper make(ActualArray array, IntegerVar start, IntegerVar stop) {
throw new UnsupportedOperationException();/*
udanax-top.st:55512:AscendingArrayStepper class methodsFor: 'create'!
{TableStepper} make: array {ActualArray} with: start {IntegerVar} with: stop {IntegerVar}
	^ self create: array with: start with: stop!
*/
}
}
