/*
 * Abora-Gold
 * Part of the Abora hypertext project: http://www.abora.org
 * Copyright 2003 David G Jones
 * 
 * Translated from Udanax-Gold source code: http://www.udanax.com
 * Copyright 1979-1999 Udanax.com. All rights reserved
 */
package org.abora.gold.collection.steppers;

import org.abora.gold.collection.steppers.Stepper;
import org.abora.gold.collection.steppers.TableStepper;
import org.abora.gold.collection.tables.IntegerTable;
import org.abora.gold.java.missing.IntegerVar;
import org.abora.gold.spaces.basic.OrderSpec;
import org.abora.gold.spaces.basic.Position;
import org.abora.gold.xpp.basic.Heaper;


/**
 * Consider this a protected class.  It is public only for use by the "array" module.
 */
public class IntegerTableStepper extends TableStepper {
/*
udanax-top.st:55790:
TableStepper subclass: #IntegerTableStepper
	instanceVariableNames: ''
	classVariableNames: ''
	poolDictionaries: ''
	category: 'Xanadu-Collection-Steppers'!
*/
/*
udanax-top.st:55794:
IntegerTableStepper comment:
'Consider this a protected class.  It is public only for use by the "array" module.'!
*/
/*
udanax-top.st:55796:
(IntegerTableStepper getOrMakeCxxClassDescription)
	attributes: ((Set new) add: #DEFERRED; yourself)!
*/
/*
udanax-top.st:55827:
IntegerTableStepper class
	instanceVariableNames: ''!
*/
/*
udanax-top.st:55830:
(IntegerTableStepper getOrMakeCxxClassDescription)
	attributes: ((Set new) add: #DEFERRED; yourself)!
*/

public Heaper fetch() {
throw new UnsupportedOperationException();/*
udanax-top.st:55801:IntegerTableStepper methodsFor: 'operations'!
{Heaper wimpy} fetch
	self subclassResponsibility!
*/
}

public Heaper get() {
throw new UnsupportedOperationException();/*
udanax-top.st:55804:IntegerTableStepper methodsFor: 'operations'!
{Heaper wimpy} get
	| res {Heaper wimpy} |
	res _ self fetch.
	res == NULL ifTrue: [Heaper BLAST: #EmptyStepper].
	^res!
*/
}

public boolean hasValue() {
throw new UnsupportedOperationException();/*
udanax-top.st:55810:IntegerTableStepper methodsFor: 'operations'!
{BooleanVar} hasValue
	self subclassResponsibility!
*/
}

public void step() {
throw new UnsupportedOperationException();/*
udanax-top.st:55813:IntegerTableStepper methodsFor: 'operations'!
{void} step
	self subclassResponsibility!
*/
}

public Position position() {
throw new UnsupportedOperationException();/*
udanax-top.st:55818:IntegerTableStepper methodsFor: 'special'!
{Position} position
	self subclassResponsibility!
*/
}

public Stepper copy() {
throw new UnsupportedOperationException();/*
udanax-top.st:55823:IntegerTableStepper methodsFor: 'create'!
{Stepper} copy
	self subclassResponsibility!
*/
}

/**
 * Do not consider public.  Only for use by the modules inttab, array, and awarray.
 */
public static Heaper make(IntegerTable aTable, OrderSpec anOrder) {
throw new UnsupportedOperationException();/*
udanax-top.st:55835:IntegerTableStepper class methodsFor: 'pseudoConstructors'!
make: aTable {IntegerTable} with: anOrder {OrderSpec default: NULL} 
	"Do not consider public.  Only for use by the modules inttab, array, and awarray."
	
	aTable cast: ActualIntegerTable into: [:tab |
			(anOrder followsInt: 1  with: IntegerVar0)
				ifTrue: [^ITAscendingStepper create: tab]
				ifFalse: [^ITDescendingStepper create: tab]]
		others: [anOrder == NULL
				ifTrue: [^ITGenericStepper create: aTable]
				ifFalse: [^ITGenericStepper create: aTable with.OrderSpec: anOrder]].
	^ NULL "compiler fodder"!
*/
}

/**
 * Do not consider public.  Only for use by the modules inttab, array, and awarray.
 */
public static Heaper make(IntegerTable aTable, IntegerVar start, IntegerVar stop) {
throw new UnsupportedOperationException();/*
udanax-top.st:55847:IntegerTableStepper class methodsFor: 'pseudoConstructors'!
make: aTable {IntegerTable} 
	with: start {IntegerVar} 
	with: stop {IntegerVar} 
	"Do not consider public.  Only for use by the modules inttab, array, and awarray."
	
	aTable cast: ActualIntegerTable into: [:tab |
			^ITAscendingStepper
				create: tab
				with: start
				with: stop]
		others: [^ITGenericStepper
				create: aTable
				with: start
				with: stop
				with: 1].
	^ NULL "compiler fodder"!
*/
}

public static void create(IntegerTable onTable, OrderSpec anOrderSpec) {
throw new UnsupportedOperationException();/*
udanax-top.st:55866:IntegerTableStepper class methodsFor: 'smalltalk: smalltalk creation'!
create: onTable {IntegerTable} with.OrderSpec: anOrderSpec {OrderSpec}
	^ self new create: onTable with.OrderSpec: anOrderSpec!
*/
}
}
