/*
 * Abora-Gold
 * Part of the Abora hypertext project: http://www.abora.org
 * Copyright 2003 David G Jones
 * 
 * Translated from Udanax-Gold source code: http://www.udanax.com
 * Copyright 1979-1999 Udanax.com. All rights reserved
 */
package org.abora.gold.collection.steppers;

import org.abora.gold.collection.steppers.IntegerTableStepper;
import org.abora.gold.collection.steppers.Stepper;
import org.abora.gold.collection.tables.IntegerTable;
import org.abora.gold.java.missing.IntegerVar;
import org.abora.gold.spaces.basic.OrderSpec;
import org.abora.gold.spaces.basic.Position;
import org.abora.gold.xpp.basic.Heaper;


public class ITGenericStepper extends IntegerTableStepper {
	protected IntegerTable arrayInternal;
	protected IntegerVar indexInternal;
	protected IntegerVar lastValueInternal;
	protected int incrementInternal;
/*
udanax-top.st:56012:
IntegerTableStepper subclass: #ITGenericStepper
	instanceVariableNames: '
		arrayInternal {IntegerTable}
		indexInternal {IntegerVar}
		lastValueInternal {IntegerVar}
		incrementInternal {Int32}'
	classVariableNames: ''
	poolDictionaries: ''
	category: 'Xanadu-Collection-Steppers'!
*/
/*
udanax-top.st:56020:
(ITGenericStepper getOrMakeCxxClassDescription)
	attributes: ((Set new) add: #CONCRETE; add: #NOT.A.TYPE; yourself)!
*/

public Heaper fetch() {
throw new UnsupportedOperationException();/*
udanax-top.st:56025:ITGenericStepper methodsFor: 'operations'!
{Heaper wimpy} fetch
	self hasValue
		ifTrue: [^ arrayInternal intFetch: indexInternal]
		ifFalse: [^NULL]!
*/
}

public boolean hasValue() {
throw new UnsupportedOperationException();/*
udanax-top.st:56030:ITGenericStepper methodsFor: 'operations'!
{BooleanVar} hasValue
	^(incrementInternal > Int32Zero and: [indexInternal <= lastValueInternal])
		or: [incrementInternal < Int32Zero and: [indexInternal >= lastValueInternal]]!
*/
}

public void step() {
throw new UnsupportedOperationException();/*
udanax-top.st:56034:ITGenericStepper methodsFor: 'operations'!
{void} step
	indexInternal _ indexInternal + incrementInternal.
	self verifyEntry!
*/
}

public IntegerVar index() {
throw new UnsupportedOperationException();/*
udanax-top.st:56040:ITGenericStepper methodsFor: 'special'!
{IntegerVar} index
	^indexInternal!
*/
}

public Position position() {
throw new UnsupportedOperationException();/*
udanax-top.st:56043:ITGenericStepper methodsFor: 'special'!
{Position} position
	^indexInternal integer!
*/
}

public Stepper copy() {
throw new UnsupportedOperationException();/*
udanax-top.st:56048:ITGenericStepper methodsFor: 'create'!
{Stepper} copy
	^ITGenericStepper
		create: arrayInternal
		with: indexInternal
		with: lastValueInternal
		with: incrementInternal!
*/
}

public  ITGenericStepper(IntegerTable array) {
throw new UnsupportedOperationException();/*
udanax-top.st:56055:ITGenericStepper methodsFor: 'create'!
create: array {IntegerTable}
	super create.
	arrayInternal _ (array copy cast: IntegerTable).
	indexInternal _ IntegerVar0.
	lastValueInternal _ arrayInternal highestIndex.
	incrementInternal _ 1!
*/
}

public  ITGenericStepper(IntegerTable onTable, OrderSpec anOrder) {
throw new UnsupportedOperationException();/*
udanax-top.st:56062:ITGenericStepper methodsFor: 'create'!
create: onTable {IntegerTable} with.OrderSpec: anOrder {OrderSpec} 
	
	super create.
	(anOrder followsInt: 1 with: IntegerVar0)
		ifTrue: "order is ascending"
			[arrayInternal _ (onTable copy cast: IntegerTable).
			indexInternal _ onTable lowestIndex.
			lastValueInternal _ onTable highestIndex.
			incrementInternal _ 1]
		ifFalse: "order is descending"
			[arrayInternal _ (onTable copy cast: IntegerTable).
			indexInternal _ onTable highestIndex.
			lastValueInternal _ onTable lowestIndex.
			incrementInternal _ -1]!
*/
}

public  ITGenericStepper(IntegerTable array, IntegerVar index) {
throw new UnsupportedOperationException();/*
udanax-top.st:56077:ITGenericStepper methodsFor: 'create'!
create: array {IntegerTable} with: index {IntegerVar}
	super create.
	arrayInternal _ array copy cast: IntegerTable.
	indexInternal _ index.
	lastValueInternal _ arrayInternal highestIndex.
	incrementInternal _ 1!
*/
}

public  ITGenericStepper(IntegerTable array, IntegerVar start, IntegerVar stop) {
throw new UnsupportedOperationException();/*
udanax-top.st:56084:ITGenericStepper methodsFor: 'create'!
create: array {IntegerTable} with: start {IntegerVar} with: stop {IntegerVar}
	super create.
	arrayInternal _ array copy cast: IntegerTable.
	indexInternal _ start.
	lastValueInternal _ stop.
	incrementInternal _ 1!
*/
}

public  ITGenericStepper(IntegerTable array, IntegerVar start, IntegerVar stop, IntegerVar direction) {
throw new UnsupportedOperationException();/*
udanax-top.st:56091:ITGenericStepper methodsFor: 'create'!
create: array {IntegerTable} with: start {IntegerVar} with: stop {IntegerVar} with: direction {IntegerVar}
	super create.
	arrayInternal _ array copy cast: IntegerTable.
	indexInternal _ start.
	lastValueInternal _ stop.
	incrementInternal _ direction DOTasLong!
*/
}

public void verifyEntry() {
throw new UnsupportedOperationException();/*
udanax-top.st:56100:ITGenericStepper methodsFor: 'private: private'!
{void} verifyEntry
	| notDone {BooleanVar} |
	notDone _ true.
	[notDone]
		whileTrue: [
			((incrementInternal > Int32Zero and: [indexInternal < lastValueInternal])
					or: [incrementInternal < Int32Zero and: [indexInternal >= lastValueInternal]])
				ifTrue: [(arrayInternal intFetch: indexInternal) == NULL
						ifTrue: [indexInternal _ indexInternal + incrementInternal]
						ifFalse: [notDone _ false]]
				ifFalse: [notDone _ false]]!
*/
}
}
