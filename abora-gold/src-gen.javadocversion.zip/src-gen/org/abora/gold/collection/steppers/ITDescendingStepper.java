/*
 * Abora-Gold
 * Part of the Abora hypertext project: http://www.abora.org
 * Copyright 2003 David G Jones
 * 
 * Translated from Udanax-Gold source code: http://www.udanax.com
 * Copyright 1979-1999 Udanax.com. All rights reserved
 */
package org.abora.gold.collection.steppers;

import org.abora.gold.collection.steppers.IntegerTableStepper;
import org.abora.gold.collection.steppers.Stepper;
import org.abora.gold.collection.tables.OberIntegerTable;
import org.abora.gold.java.missing.IntegerVar;
import org.abora.gold.spaces.basic.Position;
import org.abora.gold.xpp.basic.Heaper;


public class ITDescendingStepper extends IntegerTableStepper {
	protected OberIntegerTable arrayInternal;
	protected int indexInternal;
	protected int lastValueInternal;
/*
udanax-top.st:55944:
IntegerTableStepper subclass: #ITDescendingStepper
	instanceVariableNames: '
		arrayInternal {OberIntegerTable}
		indexInternal {UInt32}
		lastValueInternal {UInt32}'
	classVariableNames: ''
	poolDictionaries: ''
	category: 'Xanadu-Collection-Steppers'!
*/
/*
udanax-top.st:55951:
(ITDescendingStepper getOrMakeCxxClassDescription)
	attributes: ((Set new) add: #CONCRETE; add: #NOT.A.TYPE; yourself)!
*/

public Stepper copy() {
throw new UnsupportedOperationException();/*
udanax-top.st:55956:ITDescendingStepper methodsFor: 'create'!
{Stepper} copy
	^ITDescendingStepper
		create: (arrayInternal copy cast: ActualIntegerTable)
		with: self index
		with: arrayInternal startIndex + lastValueInternal!
*/
}

public  ITDescendingStepper(OberIntegerTable array) {
throw new UnsupportedOperationException();/*
udanax-top.st:55962:ITDescendingStepper methodsFor: 'create'!
create: array {OberIntegerTable} 
	super create.
	arrayInternal _ array copy cast: OberIntegerTable.
	indexInternal _ arrayInternal endOffset.
	lastValueInternal _ arrayInternal startOffset.
	self verifyEntry!
*/
}

public  ITDescendingStepper(OberIntegerTable array, IntegerVar index) {
throw new UnsupportedOperationException();/*
udanax-top.st:55969:ITDescendingStepper methodsFor: 'create'!
create: array {OberIntegerTable} with: index {IntegerVar} 
	super create.
	arrayInternal _ array copy cast: OberIntegerTable.
	indexInternal _ (index - arrayInternal startIndex) DOTasLong.
	lastValueInternal _ arrayInternal startOffset.
	self verifyEntry!
*/
}

public  ITDescendingStepper(OberIntegerTable array, IntegerVar start, IntegerVar stop) {
throw new UnsupportedOperationException();/*
udanax-top.st:55976:ITDescendingStepper methodsFor: 'create'!
create: array {OberIntegerTable} with: start {IntegerVar} with: stop {IntegerVar} 
	super create.
	arrayInternal _ array copy cast: OberIntegerTable.
	indexInternal _ (start - arrayInternal startIndex) DOTasLong.
	lastValueInternal _ (stop - arrayInternal startIndex) DOTasLong.
	self verifyEntry!
*/
}

public Heaper fetch() {
throw new UnsupportedOperationException();/*
udanax-top.st:55985:ITDescendingStepper methodsFor: 'operations'!
{Heaper wimpy} fetch
	indexInternal >= lastValueInternal
		ifTrue: [^arrayInternal elementsArray fetch: indexInternal]
		ifFalse: [^NULL]!
*/
}

public boolean hasValue() {
throw new UnsupportedOperationException();/*
udanax-top.st:55990:ITDescendingStepper methodsFor: 'operations'!
{BooleanVar} hasValue
	^indexInternal >= lastValueInternal!
*/
}

public void step() {
throw new UnsupportedOperationException();/*
udanax-top.st:55993:ITDescendingStepper methodsFor: 'operations'!
{void} step
	indexInternal _ indexInternal - 1.
	self verifyEntry!
*/
}

public IntegerVar index() {
throw new UnsupportedOperationException();/*
udanax-top.st:55999:ITDescendingStepper methodsFor: 'special'!
{IntegerVar} index
	^ arrayInternal startIndex + indexInternal!
*/
}

public Position position() {
throw new UnsupportedOperationException();/*
udanax-top.st:56002:ITDescendingStepper methodsFor: 'special'!
{Position} position
	^ self index integer!
*/
}

public void verifyEntry() {
throw new UnsupportedOperationException();/*
udanax-top.st:56007:ITDescendingStepper methodsFor: 'private: private'!
{void} verifyEntry
	[indexInternal >= lastValueInternal and: 
			[(arrayInternal elementsArray fetch: indexInternal) == NULL]]
		whileTrue: [indexInternal _ indexInternal - 1]!
*/
}
}
