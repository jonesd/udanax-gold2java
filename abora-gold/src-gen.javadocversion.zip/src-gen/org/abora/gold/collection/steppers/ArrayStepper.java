/*
 * Abora-Gold
 * Part of the Abora hypertext project: http://www.abora.org
 * Copyright 2003 David G Jones
 * 
 * Translated from Udanax-Gold source code: http://www.udanax.com
 * Copyright 1979-1999 Udanax.com. All rights reserved
 */
package org.abora.gold.collection.steppers;

import org.abora.gold.collection.steppers.Stepper;
import org.abora.gold.collection.steppers.TableStepper;
import org.abora.gold.collection.tables.ActualArray;
import org.abora.gold.collection.tables.MuArray;
import org.abora.gold.java.missing.IntegerVar;
import org.abora.gold.spaces.basic.Position;
import org.abora.gold.xpp.basic.Heaper;


public class ArrayStepper extends TableStepper {
	protected ActualArray arrayInternal;
	protected int indexInternal;
/*
udanax-top.st:55393:
TableStepper subclass: #ArrayStepper
	instanceVariableNames: '
		arrayInternal {ActualArray}
		indexInternal {Int32}'
	classVariableNames: ''
	poolDictionaries: ''
	category: 'Xanadu-Collection-Steppers'!
*/
/*
udanax-top.st:55399:
(ArrayStepper getOrMakeCxxClassDescription)
	attributes: ((Set new) add: #NOT.A.TYPE; add: #DEFERRED; yourself)!
*/

public Heaper fetch() {
throw new UnsupportedOperationException();/*
udanax-top.st:55404:ArrayStepper methodsFor: 'operations'!
{Heaper wimpy} fetch
	self subclassResponsibility!
*/
}

public Heaper get() {
throw new UnsupportedOperationException();/*
udanax-top.st:55407:ArrayStepper methodsFor: 'operations'!
{Heaper wimpy} get
	^arrayInternal intGet: indexInternal!
*/
}

public boolean hasValue() {
throw new UnsupportedOperationException();/*
udanax-top.st:55410:ArrayStepper methodsFor: 'operations'!
{BooleanVar} hasValue
	self subclassResponsibility!
*/
}

public void step() {
throw new UnsupportedOperationException();/*
udanax-top.st:55413:ArrayStepper methodsFor: 'operations'!
{void} step
	self subclassResponsibility!
*/
}

public IntegerVar index() {
throw new UnsupportedOperationException();/*
udanax-top.st:55418:ArrayStepper methodsFor: 'special'!
{IntegerVar} index
	^indexInternal!
*/
}

public Position position() {
throw new UnsupportedOperationException();/*
udanax-top.st:55421:ArrayStepper methodsFor: 'special'!
{Position} position
	^indexInternal integer!
*/
}

public ActualArray array() {
throw new UnsupportedOperationException();/*
udanax-top.st:55426:ArrayStepper methodsFor: 'protected: accessing'!
{ActualArray} array
	^arrayInternal!
*/
}

public void setIndex(int i) {
throw new UnsupportedOperationException();/*
udanax-top.st:55429:ArrayStepper methodsFor: 'protected: accessing'!
{void} setIndex: i {Int32}
	indexInternal _ i!
*/
}

public Stepper copy() {
throw new UnsupportedOperationException();/*
udanax-top.st:55434:ArrayStepper methodsFor: 'create'!
{Stepper} copy
	self subclassResponsibility!
*/
}

public  ArrayStepper(MuArray array) {
throw new UnsupportedOperationException();/*
udanax-top.st:55439:ArrayStepper methodsFor: 'protected: create'!
create: array {MuArray}
	super create.
	arrayInternal _ array copy cast: ActualArray.
	indexInternal _ Int32Zero!
*/
}

public  ArrayStepper(MuArray array, IntegerVar index) {
throw new UnsupportedOperationException();/*
udanax-top.st:55444:ArrayStepper methodsFor: 'protected: create'!
create: array {MuArray} with: index {IntegerVar}
	super create.
	arrayInternal _ array copy cast: ActualArray.
	indexInternal _ index DOTasLong!
*/
}
}
