/*
 * Abora-Gold
 * Part of the Abora hypertext project: http://www.abora.org
 * Copyright 2003 David G Jones
 * 
 * Translated from Udanax-Gold source code: http://www.udanax.com
 * Copyright 1979-1999 Udanax.com. All rights reserved
 */
package org.abora.gold.collection.steppers;

import org.abora.gold.collection.steppers.Accumulator;
import org.abora.gold.collection.steppers.TableAccumulator;
import org.abora.gold.collection.tables.MuArray;
import org.abora.gold.xpp.basic.Heaper;


public class ArrayAccumulator extends TableAccumulator {
	protected MuArray arrayInternal;
/*
udanax-top.st:12425:
TableAccumulator subclass: #ArrayAccumulator
	instanceVariableNames: 'arrayInternal {MuArray}'
	classVariableNames: ''
	poolDictionaries: ''
	category: 'Xanadu-Collection-Steppers'!
*/
/*
udanax-top.st:12429:
(ArrayAccumulator getOrMakeCxxClassDescription)
	friends:
'friend class XuArray;';
	attributes: ((Set new) add: #CONCRETE; add: #NOT.A.TYPE; yourself)!
*/
/*
udanax-top.st:12456:
ArrayAccumulator class
	instanceVariableNames: ''!
*/
/*
udanax-top.st:12459:
(ArrayAccumulator getOrMakeCxxClassDescription)
	friends:
'friend class XuArray;';
	attributes: ((Set new) add: #CONCRETE; add: #NOT.A.TYPE; yourself)!
*/

public  ArrayAccumulator(MuArray onTable) {
throw new UnsupportedOperationException();/*
udanax-top.st:12436:ArrayAccumulator methodsFor: 'protected: create'!
create: onTable {MuArray}
	super create.
	arrayInternal _ onTable!
*/
}

public void step(Heaper obj) {
throw new UnsupportedOperationException();/*
udanax-top.st:12442:ArrayAccumulator methodsFor: 'operations'!
{void} step: obj {Heaper} 
	arrayInternal isEmpty
		ifTrue: [arrayInternal atInt: IntegerVar0 store: obj]
		ifFalse: [arrayInternal atInt: (arrayInternal domain quickCast: IntegerRegion) stop introduce: obj]!
*/
}

public Heaper value() {
throw new UnsupportedOperationException();/*
udanax-top.st:12447:ArrayAccumulator methodsFor: 'operations'!
{Heaper} value
	^ arrayInternal.!
*/
}

public Accumulator copy() {
throw new UnsupportedOperationException();/*
udanax-top.st:12452:ArrayAccumulator methodsFor: 'create'!
{Accumulator} copy
	^ ArrayAccumulator make: (arrayInternal copy cast: MuArray)!
*/
}

public static Heaper make(MuArray onTable) {
throw new UnsupportedOperationException();/*
udanax-top.st:12466:ArrayAccumulator class methodsFor: 'create'!
{TableAccumulator} make: onTable {MuArray}
	^ self create: onTable!
*/
}

public static void create(Object aTable) {
throw new UnsupportedOperationException();/*
udanax-top.st:12471:ArrayAccumulator class methodsFor: 'smalltalk: creation'!
create.IntegerTable: aTable	
	^self new create: aTable!
*/
}
}
