/*
 * Abora-Gold
 * Part of the Abora hypertext project: http://www.abora.org
 * Copyright 2003 David G Jones
 * 
 * Translated from Udanax-Gold source code: http://www.udanax.com
 * Copyright 1979-1999 Udanax.com. All rights reserved
 */
package org.abora.gold.collection.steppers;

import org.abora.gold.collection.steppers.Stepper;
import org.abora.gold.collection.steppers.TableStepper;
import org.abora.gold.java.missing.IntegerVar;
import org.abora.gold.spaces.basic.Dsp;
import org.abora.gold.spaces.basic.Position;
import org.abora.gold.xpp.basic.Heaper;


public class OffsetScruTableStepper extends TableStepper {
	protected TableStepper myTableStepper;
	protected Dsp myDsp;
/*
udanax-top.st:56176:
TableStepper subclass: #OffsetScruTableStepper
	instanceVariableNames: '
		myTableStepper {TableStepper}
		myDsp {Dsp}'
	classVariableNames: ''
	poolDictionaries: ''
	category: 'Xanadu-Collection-Steppers'!
*/
/*
udanax-top.st:56182:
(OffsetScruTableStepper getOrMakeCxxClassDescription)
	attributes: ((Set new) add: #CONCRETE; add: #NOT.A.TYPE; yourself)!
*/
/*
udanax-top.st:56219:
OffsetScruTableStepper class
	instanceVariableNames: ''!
*/
/*
udanax-top.st:56222:
(OffsetScruTableStepper getOrMakeCxxClassDescription)
	attributes: ((Set new) add: #CONCRETE; add: #NOT.A.TYPE; yourself)!
*/

public Heaper fetch() {
throw new UnsupportedOperationException();/*
udanax-top.st:56187:OffsetScruTableStepper methodsFor: 'operations'!
{Heaper wimpy} fetch
	^ myTableStepper fetch!
*/
}

public Heaper get() {
throw new UnsupportedOperationException();/*
udanax-top.st:56190:OffsetScruTableStepper methodsFor: 'operations'!
{Heaper wimpy} get
	^ myTableStepper get!
*/
}

public boolean hasValue() {
throw new UnsupportedOperationException();/*
udanax-top.st:56193:OffsetScruTableStepper methodsFor: 'operations'!
{BooleanVar} hasValue
	^myTableStepper hasValue!
*/
}

public void step() {
throw new UnsupportedOperationException();/*
udanax-top.st:56196:OffsetScruTableStepper methodsFor: 'operations'!
{void} step
	myTableStepper step!
*/
}

public IntegerVar index() {
throw new UnsupportedOperationException();/*
udanax-top.st:56201:OffsetScruTableStepper methodsFor: 'special'!
{IntegerVar} index
	^myDsp ofInt: myTableStepper index!
*/
}

public Position position() {
throw new UnsupportedOperationException();/*
udanax-top.st:56204:OffsetScruTableStepper methodsFor: 'special'!
{Position} position
	^myDsp of: myTableStepper position!
*/
}

public Stepper copy() {
throw new UnsupportedOperationException();/*
udanax-top.st:56209:OffsetScruTableStepper methodsFor: 'create'!
{Stepper} copy
	^ OffsetScruTableStepper create.Stepper: (myTableStepper copy cast: TableStepper) with: myDsp!
*/
}

public  OffsetScruTableStepper(TableStepper onStepper, Dsp aDsp) {
throw new UnsupportedOperationException();/*
udanax-top.st:56212:OffsetScruTableStepper methodsFor: 'create'!
create.Stepper: onStepper {TableStepper} with: aDsp {Dsp} 
	
	super create.
	myTableStepper _ onStepper.
	myDsp _ aDsp!
*/
}

public static void create(Object aStepper, Object aDsp) {
throw new UnsupportedOperationException();/*
udanax-top.st:56227:OffsetScruTableStepper class methodsFor: 'smalltalk: smalltalk creation'!
create.Stepper: aStepper with: aDsp
	^ self new create.Stepper: aStepper with: aDsp!
*/
}
}
