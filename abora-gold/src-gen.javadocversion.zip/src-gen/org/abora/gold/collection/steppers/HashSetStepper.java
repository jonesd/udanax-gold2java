/*
 * Abora-Gold
 * Part of the Abora hypertext project: http://www.abora.org
 * Copyright 2003 David G Jones
 * 
 * Translated from Udanax-Gold source code: http://www.udanax.com
 * Copyright 1979-1999 Udanax.com. All rights reserved
 */
package org.abora.gold.collection.steppers;

import org.abora.gold.cache.InstanceCache;
import org.abora.gold.collection.basic.SharedPtrArray;
import org.abora.gold.collection.steppers.Stepper;
import org.abora.gold.xpp.basic.Heaper;


public class HashSetStepper extends Stepper {
	protected SharedPtrArray myElements;
	protected int myCurrent;
	protected static InstanceCache SomeSteppers;
/*
udanax-top.st:54158:
Stepper subclass: #HashSetStepper
	instanceVariableNames: '
		myElements {SharedPtrArray}
		myCurrent {Int32}'
	classVariableNames: 'SomeSteppers {InstanceCache} '
	poolDictionaries: ''
	category: 'Xanadu-Collection-Steppers'!
*/
/*
udanax-top.st:54164:
(HashSetStepper getOrMakeCxxClassDescription)
	attributes: ((Set new) add: #CONCRETE; add: #NOT.A.TYPE; yourself)!
*/
/*
udanax-top.st:54222:
HashSetStepper class
	instanceVariableNames: ''!
*/
/*
udanax-top.st:54225:
(HashSetStepper getOrMakeCxxClassDescription)
	attributes: ((Set new) add: #CONCRETE; add: #NOT.A.TYPE; yourself)!
*/

public Heaper fetch() {
throw new UnsupportedOperationException();/*
udanax-top.st:54169:HashSetStepper methodsFor: 'accessing'!
{Heaper wimpy} fetch
	(myElements ~~ NULL and: [myCurrent < myElements count])
		ifTrue: [^myElements fetch: myCurrent]
		ifFalse: [^NULL]!
*/
}

public boolean hasValue() {
throw new UnsupportedOperationException();/*
udanax-top.st:54174:HashSetStepper methodsFor: 'accessing'!
{BooleanVar} hasValue
	^myElements ~~ NULL and: [myCurrent < myElements count]!
*/
}

public void step() {
throw new UnsupportedOperationException();/*
udanax-top.st:54177:HashSetStepper methodsFor: 'accessing'!
{void} step
	myCurrent _ myCurrent + 1.
	self verifyEntry!
*/
}

public void destruct() {
throw new UnsupportedOperationException();/*
udanax-top.st:54183:HashSetStepper methodsFor: 'protected: destruct'!
{void} destruct
	myElements ~~ NULL ifTrue: [
		myElements shareLess].
	super destruct!
*/
}

public  HashSetStepper(SharedPtrArray elements, int current) {
throw new UnsupportedOperationException();/*
udanax-top.st:54190:HashSetStepper methodsFor: 'protected: creation'!
create: elements {SharedPtrArray} with: current {Int32}
	super create.
	myElements _ elements.
	myElements shareMore.
	myCurrent _ current.
	self verifyEntry!
*/
}

public Stepper copy() {
throw new UnsupportedOperationException();/*
udanax-top.st:54199:HashSetStepper methodsFor: 'creation'!
{Stepper} copy
	| result {Heaper} |
	result := SomeSteppers fetch.
	result == NULL
		ifTrue: [^ HashSetStepper create: myElements with: myCurrent]
		ifFalse: [^ (HashSetStepper new.Become: result) create: myElements with: myCurrent]!
*/
}

public void destroy() {
throw new UnsupportedOperationException();/*
udanax-top.st:54206:HashSetStepper methodsFor: 'creation'!
{void} destroy
	(SomeSteppers store: self) ifFalse:
		[super destroy]!
*/
}

public void verifyEntry() {
throw new UnsupportedOperationException();/*
udanax-top.st:54212:HashSetStepper methodsFor: 'private:'!
{void} verifyEntry
	myElements ~~ NULL ifTrue: [
		myCurrent < myElements count ifTrue: [
			myCurrent := myElements indexPast: NULL with: myCurrent.
			myCurrent == -1 ifTrue: [myCurrent := myElements count]].
		self hasValue ifFalse: [
			myElements shareLess.
			myElements := NULL]].!
*/
}

public static Heaper make(SharedPtrArray elements) {
throw new UnsupportedOperationException();/*
udanax-top.st:54230:HashSetStepper class methodsFor: 'pseudo constructors'!
{Stepper} make: elements {SharedPtrArray}
	| result {Heaper} |
	result := SomeSteppers fetch.
	result == NULL
		ifTrue: [^ self create: elements with: Int32Zero]
		ifFalse: [^ (self new.Become: result) create: elements with: Int32Zero]!
*/
}

public static void initTimeNonInherited() {
throw new UnsupportedOperationException();/*
udanax-top.st:54239:HashSetStepper class methodsFor: 'smalltalk: init'!
initTimeNonInherited
	SomeSteppers := InstanceCache make: 16.!
*/
}

public static void linkTimeNonInherited() {
throw new UnsupportedOperationException();/*
udanax-top.st:54242:HashSetStepper class methodsFor: 'smalltalk: init'!
linkTimeNonInherited
	SomeSteppers := NULL!
*/
}
}
