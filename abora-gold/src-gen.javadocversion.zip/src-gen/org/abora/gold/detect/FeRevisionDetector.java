/*
 * Abora-Gold
 * Part of the Abora hypertext project: http://www.abora.org
 * Copyright 2003 David G Jones
 * 
 * Translated from Udanax-Gold source code: http://www.udanax.com
 * Copyright 1979-1999 Udanax.com. All rights reserved
 */
package org.abora.gold.detect;

import org.abora.gold.be.basic.ID;
import org.abora.gold.detect.FeDetector;
import org.abora.gold.java.missing.IntegerVar;
import org.abora.gold.nkernel.FeEdition;
import org.abora.gold.nkernel.FeWork;


/**
 * Client defines subclasses and passes in an instance in order to be notified of revisions
 * to a Work
 */
public class FeRevisionDetector extends FeDetector {
/*
udanax-top.st:19671:
FeDetector subclass: #FeRevisionDetector
	instanceVariableNames: ''
	classVariableNames: ''
	poolDictionaries: ''
	category: 'Xanadu-detect'!
*/
/*
udanax-top.st:19675:
FeRevisionDetector comment:
'Client defines subclasses and passes in an instance in order to be notified of revisions to a Work'!
*/
/*
udanax-top.st:19677:
(FeRevisionDetector getOrMakeCxxClassDescription)
	attributes: ((Set new) add: #ON.CLIENT; add: #DEFERRED; yourself)!
*/
/*
udanax-top.st:19692:
FeRevisionDetector class
	instanceVariableNames: ''!
*/
/*
udanax-top.st:19695:
(FeRevisionDetector getOrMakeCxxClassDescription)
	attributes: ((Set new) add: #ON.CLIENT; add: #DEFERRED; yourself)!
*/

/**
 * Essential. The Work has been revised. Gives the Work, the current Edition, the author ID
 * who had it grabbed, the sequence number of the revision to the Work, and the clock time on
 * the Server (note that the clock time is only as reliable as the Server's operating system,
 * which is usually not very).
 */
public void revised(FeWork work, FeEdition contents, ID author, IntegerVar time, IntegerVar sequence) {
throw new UnsupportedOperationException();/*
udanax-top.st:19682:FeRevisionDetector methodsFor: 'triggering'!
{void CLIENT} revised: work {FeWork}
	with: contents {FeEdition}
	with: author {ID}
	with: time {IntegerVar}
	with: sequence {IntegerVar}
	"Essential. The Work has been revised. Gives the Work, the current Edition, the author ID who had it grabbed, the sequence number of the revision to the Work, and the clock time on the Server (note that the clock time is only as reliable as the Server's operating system, which is usually not very)."
	
	self subclassResponsibility!
*/
}

/**
 * {NOWAIT CLIENT} revised: contents {PrEdition} with: author {PrID} with: time {PrInteger}
 * with: sequence {PrInteger}
 */
public static void info() {
throw new UnsupportedOperationException();/*
udanax-top.st:19700:FeRevisionDetector class methodsFor: 'smalltalk: system'!
info.stProtocol
"{NOWAIT CLIENT} revised: contents {PrEdition} with: author {PrID} with: time {PrInteger} with: sequence {PrInteger}
"!
*/
}
}
