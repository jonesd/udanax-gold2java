/*
 * Abora-Gold
 * Part of the Abora hypertext project: http://www.abora.org
 * Copyright 2003 David G Jones
 * 
 * Translated from Udanax-Gold source code: http://www.udanax.com
 * Copyright 1979-1999 Udanax.com. All rights reserved
 */
package org.abora.gold.detect;

import org.abora.gold.xpp.basic.Heaper;


/**
 * This generic superclass for detectors is so the comm system can tell what things are
 * detectors.
 */
public class FeDetector extends Heaper {
/*
udanax-top.st:19422:
Heaper subclass: #FeDetector
	instanceVariableNames: ''
	classVariableNames: ''
	poolDictionaries: ''
	category: 'Xanadu-detect'!
*/
/*
udanax-top.st:19426:
FeDetector comment:
'This generic superclass for detectors is so the comm system can tell what things are detectors.'!
*/
/*
udanax-top.st:19428:
(FeDetector getOrMakeCxxClassDescription)
	attributes: ((Set new) add: #DEFERRED; add: #EQ; yourself)!
*/

public int actualHashForEqual() {
throw new UnsupportedOperationException();/*
udanax-top.st:19433:FeDetector methodsFor: 'generated:'!
actualHashForEqual ^self asOop!
*/
}

public boolean isEqual(Object other) {
throw new UnsupportedOperationException();/*
udanax-top.st:19435:FeDetector methodsFor: 'generated:'!
isEqual: other ^self == other!
*/
}
}
