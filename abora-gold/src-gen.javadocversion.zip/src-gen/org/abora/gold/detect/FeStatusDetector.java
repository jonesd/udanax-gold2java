/*
 * Abora-Gold
 * Part of the Abora hypertext project: http://www.abora.org
 * Copyright 2003 David G Jones
 * 
 * Translated from Udanax-Gold source code: http://www.udanax.com
 * Copyright 1979-1999 Udanax.com. All rights reserved
 */
package org.abora.gold.detect;

import org.abora.gold.be.basic.ID;
import org.abora.gold.detect.FeDetector;
import org.abora.gold.java.missing.IntegerVar;
import org.abora.gold.nkernel.FeWork;


/**
 * Is notified of changes in the capability of a Work object.
 */
public class FeStatusDetector extends FeDetector {
/*
udanax-top.st:19759:
FeDetector subclass: #FeStatusDetector
	instanceVariableNames: ''
	classVariableNames: ''
	poolDictionaries: ''
	category: 'Xanadu-detect'!
*/
/*
udanax-top.st:19763:
FeStatusDetector comment:
'Is notified of changes in the capability of a Work object.'!
*/
/*
udanax-top.st:19765:
(FeStatusDetector getOrMakeCxxClassDescription)
	attributes: ((Set new) add: #ON.CLIENT; add: #DEFERRED; yourself)!
*/
/*
udanax-top.st:19781:
FeStatusDetector class
	instanceVariableNames: ''!
*/
/*
udanax-top.st:19784:
(FeStatusDetector getOrMakeCxxClassDescription)
	attributes: ((Set new) add: #ON.CLIENT; add: #DEFERRED; yourself)!
*/

/**
 * Essential. The Work has been grabbed, or regrabbed.
 */
public void grabbed(FeWork work, ID author, IntegerVar reason) {
throw new UnsupportedOperationException();/*
udanax-top.st:19770:FeStatusDetector methodsFor: 'triggering'!
{void CLIENT} grabbed: work {FeWork} with: author {ID} with: reason {IntegerVar}
	"Essential. The Work has been grabbed, or regrabbed."
	
	self subclassResponsibility!
*/
}

/**
 * Essential. The revise capability of the Work has been lost.
 */
public void released(FeWork work, IntegerVar reason) {
throw new UnsupportedOperationException();/*
udanax-top.st:19775:FeStatusDetector methodsFor: 'triggering'!
{void CLIENT} released: work {FeWork} with: reason {IntegerVar}
	"Essential. The revise capability of the Work has been lost."
	
	self subclassResponsibility!
*/
}

/**
 * {Int32 CLIENT INLINE} EDIT.U.PERMISSION.U.CHANGED
 * {Int32 CLIENT INLINE} KEYMASTER.U.CHANGED
 * {Int32 CLIENT INLINE} SIGNATURE.U.AUTHORITY.CHANGED
 * {void NOWAIT CLIENT} grabbed: work {PrWork} with: author {PrID} with: reason {PrInteger}
 * {void NOWAIT CLIENT} released: work {PrWork} with: reason {PrInteger}
 */
public static void info() {
throw new UnsupportedOperationException();/*
udanax-top.st:19789:FeStatusDetector class methodsFor: 'smalltalk: system'!
info.stProtocol
"{Int32 CLIENT INLINE} EDIT.U.PERMISSION.U.CHANGED
{Int32 CLIENT INLINE} KEYMASTER.U.CHANGED
{Int32 CLIENT INLINE} SIGNATURE.U.AUTHORITY.CHANGED
{void NOWAIT CLIENT} grabbed: work {PrWork} with: author {PrID} with: reason {PrInteger}
{void NOWAIT CLIENT} released: work {PrWork} with: reason {PrInteger}
"!
*/
}

/**
 * The reason for the change was a change in the permissions required to edit the Work
 */
public static int EDIT() {
throw new UnsupportedOperationException();/*
udanax-top.st:19799:FeStatusDetector class methodsFor: 'constants'!
{Int32 CLIENT INLINE} EDIT.U.PERMISSION.U.CHANGED
	"The reason for the change was a change in the permissions required to edit the Work"
	
	^4!
*/
}

/**
 * The reason for the change was a change in authority of the KeyMaster in the Work
 */
public static int KEYMASTER() {
throw new UnsupportedOperationException();/*
udanax-top.st:19804:FeStatusDetector class methodsFor: 'constants'!
{Int32 CLIENT INLINE} KEYMASTER.U.CHANGED
	"The reason for the change was a change in authority of the KeyMaster in the Work"
	
	^2!
*/
}

/**
 * The reason for the change was a change in signature authority of the CurrentAuthor
 */
public static int SIGNATURE() {
throw new UnsupportedOperationException();/*
udanax-top.st:19809:FeStatusDetector class methodsFor: 'constants'!
{Int32 CLIENT INLINE} SIGNATURE.U.AUTHORITY.CHANGED
	"The reason for the change was a change in signature authority of the CurrentAuthor"
	
	^1!
*/
}
}
