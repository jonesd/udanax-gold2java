/*
 * Abora-Gold
 * Part of the Abora hypertext project: http://www.abora.org
 * Copyright 2003 David G Jones
 * 
 * Translated from Udanax-Gold source code: http://www.udanax.com
 * Copyright 1979-1999 Udanax.com. All rights reserved
 */
package org.abora.gold.nadmin;

import org.abora.gold.be.basic.ID;
import org.abora.gold.be.locks.Lock;
import org.abora.gold.collection.basic.PrimIntArray;
import org.abora.gold.collection.basic.UInt8Array;
import org.abora.gold.nadmin.FeChallengeLockSmith;
import org.abora.gold.nadmin.FeLockSmith;
import org.abora.gold.nkernel.FeEdition;
import org.abora.gold.tumbler.Sequence;
import org.abora.gold.wrapper.FeWrapper;
import org.abora.gold.wrapper.FeWrapperSpec;
import org.abora.gold.xpp.basic.Heaper;


/**
 * Makes ChallengeLocks; see the comment there
 */
public class FeChallengeLockSmith extends FeLockSmith {
	protected static FeWrapperSpec TheChallengeLockSmithSpec;
/*
udanax-top.st:24650:
FeLockSmith subclass: #FeChallengeLockSmith
	instanceVariableNames: ''
	classVariableNames: 'TheChallengeLockSmithSpec {FeWrapperSpec} '
	poolDictionaries: ''
	category: 'Xanadu-nadmin'!
*/
/*
udanax-top.st:24654:
FeChallengeLockSmith comment:
'Makes ChallengeLocks; see the comment there'!
*/
/*
udanax-top.st:24656:
(FeChallengeLockSmith getOrMakeCxxClassDescription)
	attributes: ((Set new) add: #ON.CLIENT; add: #CONCRETE; yourself)!
*/
/*
udanax-top.st:24689:
FeChallengeLockSmith class
	instanceVariableNames: ''!
*/
/*
udanax-top.st:24692:
(FeChallengeLockSmith getOrMakeCxxClassDescription)
	attributes: ((Set new) add: #ON.CLIENT; add: #CONCRETE; yourself)!
*/

/**
 * The type of encrypter used to create encrypted challenges.
 */
public UInt8Array encrypterName() {
throw new UnsupportedOperationException();/*
udanax-top.st:24661:FeChallengeLockSmith methodsFor: 'accessing'!
{UInt8Array CLIENT} encrypterName
	"The type of encrypter used to create encrypted challenges."
	^((((self edition get: (Sequence string: 'ChallengeLockSmith:EncrypterName'))
		cast: FeEdition) retrieve theOne) cast: FeArrayBundle) array cast: UInt8Array!
*/
}

/**
 * The public key used to construct challenges.
 */
public UInt8Array publicKey() {
throw new UnsupportedOperationException();/*
udanax-top.st:24667:FeChallengeLockSmith methodsFor: 'accessing'!
{UInt8Array CLIENT} publicKey
	"The public key used to construct challenges."
	^((((self edition get: (Sequence string: 'ChallengeLockSmith:PublicKey'))
		cast: FeEdition) retrieve theOne) cast: FeArrayBundle) array cast: UInt8Array!
*/
}

public Lock newLock(ID clubID) {
throw new UnsupportedOperationException();/*
udanax-top.st:24675:FeChallengeLockSmith methodsFor: 'server locks'!
{Lock} newLock: clubID {ID | NULL}
	self thingToDo. "Make this random"
	^ChallengeLock make: clubID
		with: self
		with: (UInt8Array string: 'random')!
*/
}

public  FeChallengeLockSmith(FeEdition edition, FeWrapperSpec spec) {
	super(null, null);
throw new UnsupportedOperationException();/*
udanax-top.st:24684:FeChallengeLockSmith methodsFor: 'private: create'!
create: edition {FeEdition} with: spec {FeWrapperSpec}
	super create: edition with: spec!
*/
}

public static Heaper make(PrimIntArray publicKey, Sequence encrypterName) {
throw new UnsupportedOperationException();/*
udanax-top.st:24697:FeChallengeLockSmith class methodsFor: 'pseudo constructors'!
{FeChallengeLockSmith CLIENT} make: publicKey {PrimIntArray}
	with: encrypterName {Sequence}
	
	| result {FeEdition} |
	result := FeEdition fromOne: (Sequence string: 'ChallengeLockSmith:PublicKey')
		with: (FeEdition fromArray: (publicKey cast: UInt8Array)).
	result := result
		with: (Sequence string: 'ChallengeLockSmith:EncrypterName')
		with: (FeEdition fromArray: encrypterName integers).
	^self construct: result!
*/
}

public static FeWrapperSpec spec() {
throw new UnsupportedOperationException();/*
udanax-top.st:24708:FeChallengeLockSmith class methodsFor: 'pseudo constructors'!
{FeWrapperSpec} spec
	^TheChallengeLockSmithSpec!
*/
}

public static boolean check(FeEdition edition) {
throw new UnsupportedOperationException();/*
udanax-top.st:24714:FeChallengeLockSmith class methodsFor: 'private: wrapping'!
{BooleanVar} check: edition {FeEdition}
	
	^(edition domain isEqual: ((Sequence string: 'ChallengeLockSmith:EncrypterName') asRegion
			with: (Sequence string: 'ChallengeLockSmith:PublicKey')))
		and: [(FeWrapper checkSubSequence: edition
			with: (Sequence string: 'ChallengeLockSmith:EncrypterName')
			with: true)
		and: [FeWrapper checkSubSequence: edition
			with: (Sequence string: 'ChallengeLockSmith:PublicKey')
			with: true]]!
*/
}

public static FeChallengeLockSmith construct(FeEdition edition) {
throw new UnsupportedOperationException();/*
udanax-top.st:24725:FeChallengeLockSmith class methodsFor: 'private: wrapping'!
{FeChallengeLockSmith} construct: edition {FeEdition}
	
	self spec endorse: edition.
	^ (self makeWrapper: edition) cast: FeChallengeLockSmith!
*/
}

public static FeWrapper makeWrapper(FeEdition edition) {
throw new UnsupportedOperationException();/*
udanax-top.st:24730:FeChallengeLockSmith class methodsFor: 'private: wrapping'!
{FeWrapper} makeWrapper: edition {FeEdition}
	
	^self create: edition with: self spec!
*/
}

public static void setSpec(FeWrapperSpec wrap) {
throw new UnsupportedOperationException();/*
udanax-top.st:24734:FeChallengeLockSmith class methodsFor: 'private: wrapping'!
{void} setSpec: wrap {FeWrapperSpec}
	TheChallengeLockSmithSpec := wrap.!
*/
}

public static void initTimeNonInherited() {
throw new UnsupportedOperationException();/*
udanax-top.st:24740:FeChallengeLockSmith class methodsFor: 'smalltalk: init'!
initTimeNonInherited
	FeWrapperSpec DIRECTWRAPPER: 'ChallengeLockSmith'
		with: 'LockSmith'
		with: #FeChallengeLockSmith.!
*/
}

public static void linkTimeNonInherited() {
throw new UnsupportedOperationException();/*
udanax-top.st:24746:FeChallengeLockSmith class methodsFor: 'smalltalk: init'!
linkTimeNonInherited
	TheChallengeLockSmithSpec := NULL.!
*/
}

/**
 * {PrimIntegerArray CLIENT} encrypterName
 * {UInt8Array CLIENT} publicKey
 */
public static void info() {
throw new UnsupportedOperationException();/*
udanax-top.st:24752:FeChallengeLockSmith class methodsFor: 'smalltalk: system'!
info.stProtocol
"{PrimIntegerArray CLIENT} encrypterName
{UInt8Array CLIENT} publicKey
"!
*/
}
}
