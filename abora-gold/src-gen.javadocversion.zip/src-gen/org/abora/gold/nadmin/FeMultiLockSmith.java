/*
 * Abora-Gold
 * Part of the Abora hypertext project: http://www.abora.org
 * Copyright 2003 David G Jones
 * 
 * Translated from Udanax-Gold source code: http://www.udanax.com
 * Copyright 1979-1999 Udanax.com. All rights reserved
 */
package org.abora.gold.nadmin;

import org.abora.gold.be.basic.ID;
import org.abora.gold.be.locks.Lock;
import org.abora.gold.nadmin.FeLockSmith;
import org.abora.gold.nadmin.FeMultiLockSmith;
import org.abora.gold.nkernel.FeEdition;
import org.abora.gold.tumbler.Sequence;
import org.abora.gold.tumbler.SequenceRegion;
import org.abora.gold.wrapper.FeWrapper;
import org.abora.gold.wrapper.FeWrapperSpec;
import org.abora.gold.xpp.basic.Heaper;


/**
 * Makes MultiLocks; see the comment there
 */
public class FeMultiLockSmith extends FeLockSmith {
	protected static FeWrapperSpec TheMultiLockSmithSpec;
/*
udanax-top.st:24861:
FeLockSmith subclass: #FeMultiLockSmith
	instanceVariableNames: ''
	classVariableNames: 'TheMultiLockSmithSpec {FeWrapperSpec} '
	poolDictionaries: ''
	category: 'Xanadu-nadmin'!
*/
/*
udanax-top.st:24865:
FeMultiLockSmith comment:
'Makes MultiLocks; see the comment there'!
*/
/*
udanax-top.st:24867:
(FeMultiLockSmith getOrMakeCxxClassDescription)
	attributes: ((Set new) add: #ON.CLIENT; add: #CONCRETE; yourself)!
*/
/*
udanax-top.st:24912:
FeMultiLockSmith class
	instanceVariableNames: ''!
*/
/*
udanax-top.st:24915:
(FeMultiLockSmith getOrMakeCxxClassDescription)
	attributes: ((Set new) add: #ON.CLIENT; add: #CONCRETE; yourself)!
*/

public Lock newLock(ID clubID) {
throw new UnsupportedOperationException();/*
udanax-top.st:24872:FeMultiLockSmith methodsFor: 'server locks'!
{Lock} newLock: clubID {ID | NULL}
	| result {MuTable of: Lock} |
	result := MuTable make: SequenceSpace make.
	self edition stepper forPositions: [ :name {Sequence} :smith {FeEdition} |
		result at: name
			introduce: (((FeLockSmith spec wrap: smith) cast: FeLockSmith) newLock: clubID)].
	^MultiLock make: clubID with: self with: result asImmuTable!
*/
}

/**
 * The named LockSmith
 */
public FeLockSmith lockSmith(Sequence name) {
throw new UnsupportedOperationException();/*
udanax-top.st:24883:FeMultiLockSmith methodsFor: 'accessing'!
{FeLockSmith CLIENT} lockSmith: name {Sequence}
	"The named LockSmith"
	
	^(FeLockSmith spec wrap: ((self edition get: name) cast: FeEdition)) cast: FeLockSmith!
*/
}

/**
 * The names of all the Locksmiths this uses.
 */
public SequenceRegion lockSmithNames() {
throw new UnsupportedOperationException();/*
udanax-top.st:24888:FeMultiLockSmith methodsFor: 'accessing'!
{SequenceRegion CLIENT of: Sequence} lockSmithNames
	"The names of all the Locksmiths this uses."
	
	^self edition domain cast: SequenceRegion!
*/
}

/**
 * Add or change a LockSmith
 */
public FeMultiLockSmith with(Sequence name, FeLockSmith smith) {
throw new UnsupportedOperationException();/*
udanax-top.st:24893:FeMultiLockSmith methodsFor: 'accessing'!
{FeMultiLockSmith CLIENT} with: name {Sequence} with: smith {FeLockSmith}
	"Add or change a LockSmith"
	
	^(FeMultiLockSmith construct: (self edition
		with: name
		with: smith edition)) cast: FeMultiLockSmith!
*/
}

/**
 * Add or change a LockSmith
 */
public FeMultiLockSmith without(Sequence name) {
throw new UnsupportedOperationException();/*
udanax-top.st:24900:FeMultiLockSmith methodsFor: 'accessing'!
{FeMultiLockSmith CLIENT} without: name {Sequence}
	"Add or change a LockSmith"
	
	^(FeMultiLockSmith construct: (self edition without: name)) cast: FeMultiLockSmith!
*/
}

public  FeMultiLockSmith(FeEdition edition, FeWrapperSpec spec) {
	super(null, null);
throw new UnsupportedOperationException();/*
udanax-top.st:24907:FeMultiLockSmith methodsFor: 'private: create'!
create: edition {FeEdition} with: spec {FeWrapperSpec}
	super create: edition with: spec!
*/
}

public static boolean check(FeEdition edition) {
throw new UnsupportedOperationException();/*
udanax-top.st:24920:FeMultiLockSmith class methodsFor: 'private: wrapping'!
{BooleanVar} check: edition {FeEdition}
	
	^(SequenceSpace make isEqual: edition coordinateSpace)
		and: [FeWrapper checkSubEditions: edition
			with: edition domain
			with: FeLockSmith spec
			with: true]!
*/
}

public static FeMultiLockSmith construct(FeEdition edition) {
throw new UnsupportedOperationException();/*
udanax-top.st:24928:FeMultiLockSmith class methodsFor: 'private: wrapping'!
{FeMultiLockSmith} construct: edition {FeEdition}
	
	self spec endorse: edition.
	^ (self makeWrapper: edition) cast: FeMultiLockSmith!
*/
}

public static FeWrapper makeWrapper(FeEdition edition) {
throw new UnsupportedOperationException();/*
udanax-top.st:24933:FeMultiLockSmith class methodsFor: 'private: wrapping'!
{FeWrapper} makeWrapper: edition {FeEdition}
	
	^self create: edition with: self spec!
*/
}

public static void setSpec(FeWrapperSpec wrap) {
throw new UnsupportedOperationException();/*
udanax-top.st:24937:FeMultiLockSmith class methodsFor: 'private: wrapping'!
{void} setSpec: wrap {FeWrapperSpec}
	TheMultiLockSmithSpec := wrap.!
*/
}

public static void initTimeNonInherited() {
throw new UnsupportedOperationException();/*
udanax-top.st:24943:FeMultiLockSmith class methodsFor: 'smalltalk: init'!
initTimeNonInherited
	FeWrapperSpec DIRECTWRAPPER: 'MultiLockSmith'
		with: 'LockSmith'
		with: #FeMultiLockSmith.!
*/
}

public static void linkTimeNonInherited() {
throw new UnsupportedOperationException();/*
udanax-top.st:24949:FeMultiLockSmith class methodsFor: 'smalltalk: init'!
linkTimeNonInherited
	TheMultiLockSmithSpec := NULL.!
*/
}

public static Heaper make() {
throw new UnsupportedOperationException();/*
udanax-top.st:24955:FeMultiLockSmith class methodsFor: 'pseudo constructors'!
{FeMultiLockSmith CLIENT} make
	^self construct: (FeEdition empty: SequenceSpace make)!
*/
}

public static FeWrapperSpec spec() {
throw new UnsupportedOperationException();/*
udanax-top.st:24959:FeMultiLockSmith class methodsFor: 'pseudo constructors'!
{FeWrapperSpec} spec
	^TheMultiLockSmithSpec!
*/
}

/**
 * {FeLockSmith CLIENT} lockSmith: name {Sequence}
 * {SequenceRegion CLIENT of: Sequence} lockSmithNames
 * {FeMultiLockSmith CLIENT} with: name {Sequence} with: smith {FeLockSmith}
 * {FeMultiLockSmith CLIENT} without: name {Sequence}
 */
public static void info() {
throw new UnsupportedOperationException();/*
udanax-top.st:24965:FeMultiLockSmith class methodsFor: 'smalltalk: system'!
info.stProtocol
"{FeLockSmith CLIENT} lockSmith: name {Sequence}
{SequenceRegion CLIENT of: Sequence} lockSmithNames
{FeMultiLockSmith CLIENT} with: name {Sequence} with: smith {FeLockSmith}
{FeMultiLockSmith CLIENT} without: name {Sequence}
"!
*/
}
}
