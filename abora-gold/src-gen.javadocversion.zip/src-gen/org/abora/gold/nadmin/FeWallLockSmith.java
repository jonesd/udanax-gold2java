/*
 * Abora-Gold
 * Part of the Abora hypertext project: http://www.abora.org
 * Copyright 2003 David G Jones
 * 
 * Translated from Udanax-Gold source code: http://www.udanax.com
 * Copyright 1979-1999 Udanax.com. All rights reserved
 */
package org.abora.gold.nadmin;

import org.abora.gold.be.basic.ID;
import org.abora.gold.be.locks.Lock;
import org.abora.gold.nadmin.FeLockSmith;
import org.abora.gold.nadmin.FeWallLockSmith;
import org.abora.gold.nkernel.FeEdition;
import org.abora.gold.wrapper.FeWrapper;
import org.abora.gold.wrapper.FeWrapperSpec;
import org.abora.gold.xpp.basic.Heaper;


/**
 * Makes WallLocks; see the comment there
 */
public class FeWallLockSmith extends FeLockSmith {
	protected static FeWrapperSpec TheWallLockSmithSpec;
/*
udanax-top.st:24972:
FeLockSmith subclass: #FeWallLockSmith
	instanceVariableNames: ''
	classVariableNames: 'TheWallLockSmithSpec {FeWrapperSpec} '
	poolDictionaries: ''
	category: 'Xanadu-nadmin'!
*/
/*
udanax-top.st:24976:
FeWallLockSmith comment:
'Makes WallLocks; see the comment there'!
*/
/*
udanax-top.st:24978:
(FeWallLockSmith getOrMakeCxxClassDescription)
	attributes: ((Set new) add: #ON.CLIENT; add: #CONCRETE; yourself)!
*/
/*
udanax-top.st:24994:
FeWallLockSmith class
	instanceVariableNames: ''!
*/
/*
udanax-top.st:24997:
(FeWallLockSmith getOrMakeCxxClassDescription)
	attributes: ((Set new) add: #ON.CLIENT; add: #CONCRETE; yourself)!
*/

public Lock newLock(ID clubID) {
throw new UnsupportedOperationException();/*
udanax-top.st:24983:FeWallLockSmith methodsFor: 'server locks'!
{Lock} newLock: clubID {ID | NULL}
	^WallLock make: clubID with: self!
*/
}

public  FeWallLockSmith(FeEdition edition, FeWrapperSpec spec) {
	super(null, null);
throw new UnsupportedOperationException();/*
udanax-top.st:24989:FeWallLockSmith methodsFor: 'private: create'!
create: edition {FeEdition} with: spec {FeWrapperSpec}
	super create: edition with: spec!
*/
}

public static boolean check(FeEdition edition) {
throw new UnsupportedOperationException();/*
udanax-top.st:25002:FeWallLockSmith class methodsFor: 'private: wrapping'!
{BooleanVar} check: edition {FeEdition}
	
	Ravi hack.
	^(edition domain isEqual: (IntegerRegion make: IntegerVarZero with: 4))
		"and: [((edition zoneOf: PrimSpec uInt8) domain
			isEqual: (IntegerRegion make: IntegerVarZero with: 4))"
		and: [((edition retrieve theOne cast: FeArrayBundle) array cast: PrimIntegerArray)
			contentsEqual: (UInt8Array string: 'wall')]"]"!
*/
}

public static FeWallLockSmith construct(FeEdition edition) {
throw new UnsupportedOperationException();/*
udanax-top.st:25011:FeWallLockSmith class methodsFor: 'private: wrapping'!
{FeWallLockSmith} construct: edition {FeEdition}
	
	self spec endorse: edition.
	^ (self makeWrapper: edition) cast: FeWallLockSmith!
*/
}

public static FeWrapper makeWrapper(FeEdition edition) {
throw new UnsupportedOperationException();/*
udanax-top.st:25016:FeWallLockSmith class methodsFor: 'private: wrapping'!
{FeWrapper} makeWrapper: edition {FeEdition}
	
	^self create: edition with: self spec!
*/
}

public static void setSpec(FeWrapperSpec wrap) {
throw new UnsupportedOperationException();/*
udanax-top.st:25020:FeWallLockSmith class methodsFor: 'private: wrapping'!
{void} setSpec: wrap {FeWrapperSpec}
	TheWallLockSmithSpec := wrap.!
*/
}

public static void initTimeNonInherited() {
throw new UnsupportedOperationException();/*
udanax-top.st:25026:FeWallLockSmith class methodsFor: 'smalltalk: init'!
initTimeNonInherited
	FeWrapperSpec DIRECTWRAPPER: 'WallLockSmith'
		with: 'LockSmith'
		with: #FeWallLockSmith.!
*/
}

public static void linkTimeNonInherited() {
throw new UnsupportedOperationException();/*
udanax-top.st:25032:FeWallLockSmith class methodsFor: 'smalltalk: init'!
linkTimeNonInherited
	TheWallLockSmithSpec := NULL.!
*/
}

public static Heaper make() {
throw new UnsupportedOperationException();/*
udanax-top.st:25038:FeWallLockSmith class methodsFor: 'pseudo constructors'!
{FeWallLockSmith CLIENT} make
	^self construct: (FeEdition fromArray: (UInt8Array string: 'wall'))!
*/
}

public static FeWrapperSpec spec() {
throw new UnsupportedOperationException();/*
udanax-top.st:25042:FeWallLockSmith class methodsFor: 'pseudo constructors'!
{FeWrapperSpec} spec
	^TheWallLockSmithSpec!
*/
}
}
