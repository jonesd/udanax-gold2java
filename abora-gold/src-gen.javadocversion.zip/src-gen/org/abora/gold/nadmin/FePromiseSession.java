/*
 * Abora-Gold
 * Part of the Abora hypertext project: http://www.abora.org
 * Copyright 2003 David G Jones
 * 
 * Translated from Udanax-Gold source code: http://www.udanax.com
 * Copyright 1979-1999 Udanax.com. All rights reserved
 */
package org.abora.gold.nadmin;

import org.abora.gold.collection.basic.UInt8Array;
import org.abora.gold.nadmin.FePromiseSession;
import org.abora.gold.nadmin.FeSession;
import org.abora.gold.proman.PromiseManager;
import org.abora.gold.xpp.basic.Heaper;


/**
 * Represent a single unique connection to the server over some underlying bytestream
 * channel.
 */
public class FePromiseSession extends FeSession {
	protected UInt8Array myPort;
	protected PromiseManager myManager;
	protected Heaper myListener;
	protected FePromiseSession myNext;
/*
udanax-top.st:23454:
FeSession subclass: #FePromiseSession
	instanceVariableNames: '
		myPort {UInt8Array}
		myManager {PromiseManager}
		myListener {Heaper}
		myNext {FePromiseSession | NULL}'
	classVariableNames: ''
	poolDictionaries: ''
	category: 'Xanadu-nadmin'!
*/
/*
udanax-top.st:23462:
FePromiseSession comment:
'Represent a single unique connection to the server over some underlying bytestream channel.'!
*/
/*
udanax-top.st:23464:
(FePromiseSession getOrMakeCxxClassDescription)
	attributes: ((Set new) add: #CONCRETE; yourself)!
*/
/*
udanax-top.st:23510:
FePromiseSession class
	instanceVariableNames: ''!
*/
/*
udanax-top.st:23513:
(FePromiseSession getOrMakeCxxClassDescription)
	attributes: ((Set new) add: #CONCRETE; yourself)!
*/

/**
 * Essential. Terminate this connection.  If withPrejudice is false, it completes the current
 * request and flushes all output before disconnecting.
 */
public void endSession(boolean withPrejudice) {
throw new UnsupportedOperationException();/*
udanax-top.st:23469:FePromiseSession methodsFor: 'accessing'!
{void CLIENT} endSession: withPrejudice {BooleanVar default: false}
	"Essential. Terminate this connection.  If withPrejudice is false, it completes the current request and flushes all output before disconnecting."
	
	withPrejudice ifFalse: [myManager force].
	myManager _ NULL.
	myListener destroy.
	myListener _ NULL.
	(CurrentSessions fluidGet basicCast: Heaper star) == self 
		ifTrue: [CurrentSessions fluidSet: self next]
		ifFalse: [CurrentSessions fluidGet remove: self]!
*/
}

/**
 * Return whether the session has sucessfully logged in.
 */
public boolean isConnected() {
throw new UnsupportedOperationException();/*
udanax-top.st:23480:FePromiseSession methodsFor: 'accessing'!
{BooleanVar} isConnected
	"Return whether the session has sucessfully logged in."
	
	^myManager ~~ NULL!
*/
}

public FePromiseSession next() {
throw new UnsupportedOperationException();/*
udanax-top.st:23485:FePromiseSession methodsFor: 'accessing'!
{FePromiseSession | NULL} next
	^myNext!
*/
}

/**
 * Essential. A system-specific description of the actual transport medium over which the
 * connection is being maintained.
 */
public UInt8Array port() {
throw new UnsupportedOperationException();/*
udanax-top.st:23488:FePromiseSession methodsFor: 'accessing'!
{UInt8Array CLIENT} port
	"Essential. A system-specific description of the actual transport medium over which the connection is being maintained."
	
	^myPort!
*/
}

public void remove(FePromiseSession session) {
throw new UnsupportedOperationException();/*
udanax-top.st:23493:FePromiseSession methodsFor: 'accessing'!
{void} remove: session {FePromiseSession}
	myNext ~~ NULL ifTrue:
		[(myNext isEqual: session) 
			ifTrue: [myNext _ session next]
			ifFalse: [myNext remove: session]]!
*/
}

public  FePromiseSession(UInt8Array port, Heaper listener, PromiseManager manager) {
throw new UnsupportedOperationException();/*
udanax-top.st:23501:FePromiseSession methodsFor: 'creation'!
create: port {UInt8Array} with: listener {Heaper} with: manager {PromiseManager}
	super create.
	myPort _ port.
	myManager _ manager.
	myListener _ listener.
	myNext _ CurrentSessions fluidFetch.
	CurrentSessions fluidSet: self.!
*/
}

public static void staticTimeNonInherited() {
throw new UnsupportedOperationException();/*
udanax-top.st:23518:FePromiseSession class methodsFor: 'smalltalk: init'!
staticTimeNonInherited
	FePromiseSession defineFluid: #CurrentSessions with: DiskManager emulsion with: [NULL].!
*/
}

public static Heaper make(UInt8Array port, Heaper listener, PromiseManager manager) {
throw new UnsupportedOperationException();/*
udanax-top.st:23523:FePromiseSession class methodsFor: 'ceration'!
make: port {UInt8Array} with: listener {Heaper} with: manager {PromiseManager}
	^FePromiseSession create: port with: listener with: manager!
*/
}
}
