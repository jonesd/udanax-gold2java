/*
 * Abora-Gold
 * Part of the Abora hypertext project: http://www.abora.org
 * Copyright 2003 David G Jones
 * 
 * Translated from Udanax-Gold source code: http://www.udanax.com
 * Copyright 1979-1999 Udanax.com. All rights reserved
 */
package org.abora.gold.appmods;

import org.abora.gold.fm.support.Thunk;
import org.abora.gold.xcvr.Rcvr;
import org.abora.gold.xcvr.Xmtr;


/**
 * The purpose of WorksIniter is to do the one-time initialization of clubs and homedocs to
 * prepare a backend for ordinary client use. It is pretty sparse right now, but will
 * eventually have much more stuff
 */
public class WorksIniter extends Thunk {
/*
udanax-top.st:62746:
Thunk subclass: #WorksIniter
	instanceVariableNames: ''
	classVariableNames: ''
	poolDictionaries: ''
	category: 'Xanadu-appmods'!
*/
/*
udanax-top.st:62750:
WorksIniter comment:
'The purpose of WorksIniter is to do the one-time initialization of clubs and homedocs to prepare a backend for ordinary client use. It is pretty sparse right now, but will eventually have much more stuff'!
*/
/*
udanax-top.st:62752:
(WorksIniter getOrMakeCxxClassDescription)
	attributes: ((Set new) add: #CONCRETE; add: #(COPY boot ); yourself)!
*/

public void initializeClubs() {
throw new UnsupportedOperationException();/*
udanax-top.st:62757:WorksIniter methodsFor: 'initialization'!
{void} initializeClubs
	
	| testClub {FeClub} testID {ID} |
	"Make an autonomous Test club"
	testClub := FeClub make: (FeClubDescription make: FeSet make with: FeBooLockSmith make) edition.
	testID := FeServer iDOf: testClub.
	testClub setReadClub: testID.
	testClub setEditClub: testID.
	testClub setSignatureClub: testID.
	testClub setOwner: testID.
	FeServer nameClub: (Sequence string: 'Test') with: testID.
	FeServer enableAccess: testID.!
*/
}

public void initializeSystem() {
throw new UnsupportedOperationException();/*
udanax-top.st:62770:WorksIniter methodsFor: 'initialization'!
{void} initializeSystem
	|  aConnection {Connection}  adminID {ID} wwd {FeWaitDetector} |
	[Transcript nextPutAll: 'creating connection'; cr; endEntry] smalltalkOnly.
	aConnection := Connection make: FeServer.
	CurrentKeyMaster fluidSet: ((FeServer
		loginByName: (Sequence string: 'System Admin')) cast: BooLock) boo.
	CurrentKeyMaster fluidGet incorporate: FeKeyMaster makePublic.
	adminID := FeServer clubID: (Sequence string: 'System Admin').
	InitialOwner fluidSet: adminID.
	InitialReadClub fluidSet: adminID.
	InitialEditClub fluidSet: adminID.
	InitialSponsor fluidSet: adminID.
	CurrentAuthor fluidSet: adminID.
	self initializeClubs.
	wwd := WorksWaitDetector create: cerr with: 'WorksInit done!!'.
	FeServer waitForWrite: wwd.
	[DiskManager] USES.
	CurrentPacker fluidGet purge.
	[Transcript nextPutAll: 'exiting'; cr; endEntry] smalltalkOnly.
	aConnection destroy!
*/
}

public void execute() {
throw new UnsupportedOperationException();/*
udanax-top.st:62795:WorksIniter methodsFor: 'execute'!
{void} execute
	self initializeSystem!
*/
}

public  WorksIniter(Rcvr receiver) {
throw new UnsupportedOperationException();/*
udanax-top.st:62801:WorksIniter methodsFor: 'generated:'!
create.Rcvr: receiver {Rcvr}
	super create.Rcvr: receiver.!
*/
}

public void sendSelfTo(Xmtr xmtr) {
throw new UnsupportedOperationException();/*
udanax-top.st:62804:WorksIniter methodsFor: 'generated:'!
{void} sendSelfTo: xmtr {Xmtr}
	super sendSelfTo: xmtr.!
*/
}
}
