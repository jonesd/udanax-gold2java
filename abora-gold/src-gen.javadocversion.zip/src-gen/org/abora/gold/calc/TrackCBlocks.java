/*
 * Abora-Gold
 * Part of the Abora hypertext project: http://www.abora.org
 * Copyright 2003 David G Jones
 * 
 * Translated from Udanax-Gold source code: http://www.udanax.com
 * Copyright 1979-1999 Udanax.com. All rights reserved
 */
package org.abora.gold.calc;

import org.abora.gold.cobbler.BootPlan;
import org.abora.gold.cobbler.Connection;
import org.abora.gold.xcvr.Rcvr;
import org.abora.gold.xcvr.Xmtr;
import org.abora.gold.xpp.basic.Category;


public class TrackCBlocks extends BootPlan {
	protected BootPlan myBootPlan;
/*
udanax-top.st:57132:
BootPlan subclass: #TrackCBlocks
	instanceVariableNames: 'myBootPlan {BootPlan}'
	classVariableNames: ''
	poolDictionaries: ''
	category: 'Xanadu-calc'!
*/
/*
udanax-top.st:57136:
(TrackCBlocks getOrMakeCxxClassDescription)
	attributes: ((Set new) add: #CONCRETE; add: #(COPY boot ); add: #NOT.A.TYPE; yourself)!
*/

public Category bootCategory() {
throw new UnsupportedOperationException();/*
udanax-top.st:57141:TrackCBlocks methodsFor: 'accessing'!
{Category} bootCategory
	^myBootPlan bootCategory!
*/
}

/**
 * Return the object representing the connection. This gives the client a handle by
 * which to terminate the connection.
 */
public Connection connection() {
throw new UnsupportedOperationException();/*
udanax-top.st:57145:TrackCBlocks methodsFor: 'accessing'!
{Connection} connection
	"Return the object representing the connection. This gives the client a handle by 
	which to terminate the connection."
	
	| result {Connection} |
	result _ myBootPlan connection.
	CurrentPacker fluidSet: (CBlockTrackingPacker make: CurrentPacker fluidGet).
	^result!
*/
}

public  TrackCBlocks(Rcvr receiver) {
throw new UnsupportedOperationException();/*
udanax-top.st:57156:TrackCBlocks methodsFor: 'generated:'!
create.Rcvr: receiver {Rcvr}
	super create.Rcvr: receiver.
	myBootPlan _ receiver receiveHeaper.!
*/
}

public void sendSelfTo(Xmtr xmtr) {
throw new UnsupportedOperationException();/*
udanax-top.st:57160:TrackCBlocks methodsFor: 'generated:'!
{void} sendSelfTo: xmtr {Xmtr}
	super sendSelfTo: xmtr.
	xmtr sendHeaper: myBootPlan.!
*/
}
}
