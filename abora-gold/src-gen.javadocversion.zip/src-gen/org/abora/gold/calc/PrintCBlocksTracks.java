/*
 * Abora-Gold
 * Part of the Abora hypertext project: http://www.abora.org
 * Copyright 2003 David G Jones
 * 
 * Translated from Udanax-Gold source code: http://www.udanax.com
 * Copyright 1979-1999 Udanax.com. All rights reserved
 */
package org.abora.gold.calc;

import org.abora.gold.fm.support.Thunk;
import org.abora.gold.xcvr.Rcvr;
import org.abora.gold.xcvr.Xmtr;


public class PrintCBlocksTracks extends Thunk {
/*
udanax-top.st:57414:
Thunk subclass: #PrintCBlocksTracks
	instanceVariableNames: ''
	classVariableNames: ''
	poolDictionaries: ''
	category: 'Xanadu-calc'!
*/
/*
udanax-top.st:57418:
(PrintCBlocksTracks getOrMakeCxxClassDescription)
	attributes: ((Set new) add: #CONCRETE; add: #(COPY boot ); add: #NOT.A.TYPE; yourself)!
*/

/**
 */
public void execute() {
throw new UnsupportedOperationException();/*
udanax-top.st:57423:PrintCBlocksTracks methodsFor: 'operate'!
{void} execute
	""
	"PrintCBlocksTracks create execute"
	
	CBlockTracker printTrackersOn: cerr.
	[cerr endEntry] smalltalkOnly!
*/
}

public  PrintCBlocksTracks(Rcvr receiver) {
throw new UnsupportedOperationException();/*
udanax-top.st:57432:PrintCBlocksTracks methodsFor: 'generated:'!
create.Rcvr: receiver {Rcvr}
	super create.Rcvr: receiver.!
*/
}

public void sendSelfTo(Xmtr xmtr) {
throw new UnsupportedOperationException();/*
udanax-top.st:57435:PrintCBlocksTracks methodsFor: 'generated:'!
{void} sendSelfTo: xmtr {Xmtr}
	super sendSelfTo: xmtr.!
*/
}
}
