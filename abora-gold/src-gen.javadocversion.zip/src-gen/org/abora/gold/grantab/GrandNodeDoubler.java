/*
 * Abora-Gold
 * Part of the Abora hypertext project: http://www.abora.org
 * Copyright 2003 David G Jones
 * 
 * Translated from Udanax-Gold source code: http://www.udanax.com
 * Copyright 1979-1999 Udanax.com. All rights reserved
 */
package org.abora.gold.grantab;

import org.abora.gold.collection.grand.GrandNode;
import org.abora.gold.turtle.AgendaItem;
import org.abora.gold.xcvr.Rcvr;
import org.abora.gold.xcvr.Xmtr;
import org.abora.gold.xpp.basic.Heaper;


/**
 * GrandNodeDoubler performs the page splitting required for the extensible
 * GrandHash<collection>s in a deferred fashion.
 */
public class GrandNodeDoubler extends AgendaItem {
	protected GrandNode myNode;
/*
udanax-top.st:504:
AgendaItem subclass: #GrandNodeDoubler
	instanceVariableNames: 'myNode {GrandNode | NULL}'
	classVariableNames: ''
	poolDictionaries: ''
	category: 'Xanadu-grantab'!
*/
/*
udanax-top.st:508:
GrandNodeDoubler comment:
'GrandNodeDoubler performs the page splitting required for the extensible GrandHash<collection>s in a deferred fashion.'!
*/
/*
udanax-top.st:510:
(GrandNodeDoubler getOrMakeCxxClassDescription)
	attributes: ((Set new) add: #LOCKED; add: #COPY; add: #SHEPHERD.PATRIARCH; add: #CONCRETE; yourself)!
*/
/*
udanax-top.st:541:
GrandNodeDoubler class
	instanceVariableNames: ''!
*/
/*
udanax-top.st:544:
(GrandNodeDoubler getOrMakeCxxClassDescription)
	attributes: ((Set new) add: #LOCKED; add: #COPY; add: #SHEPHERD.PATRIARCH; add: #CONCRETE; yourself)!
*/

public  GrandNodeDoubler(GrandNode gNode) {
throw new UnsupportedOperationException();/*
udanax-top.st:515:GrandNodeDoubler methodsFor: 'protected: creation'!
create: gNode {GrandNode}
	super create.
	myNode _ gNode.
	self newShepherd.!
*/
}

public boolean step() {
throw new UnsupportedOperationException();/*
udanax-top.st:522:GrandNodeDoubler methodsFor: 'accessing'!
{BooleanVar} step
	myNode ~~ NULL ifTrue:
		[DiskManager consistent: myNode doubleNodeConsistency + 2 with:
			[myNode doubleNode.
			myNode _ NULL.
			self diskUpdate]].
	^ false!
*/
}

public  GrandNodeDoubler(Rcvr receiver) {
throw new UnsupportedOperationException();/*
udanax-top.st:532:GrandNodeDoubler methodsFor: 'generated:'!
create.Rcvr: receiver {Rcvr}
	super create.Rcvr: receiver.
	myNode _ receiver receiveHeaper.!
*/
}

public void sendSelfTo(Xmtr xmtr) {
throw new UnsupportedOperationException();/*
udanax-top.st:536:GrandNodeDoubler methodsFor: 'generated:'!
{void} sendSelfTo: xmtr {Xmtr}
	super sendSelfTo: xmtr.
	xmtr sendHeaper: myNode.!
*/
}

public static Heaper make(GrandNode gNode) {
throw new UnsupportedOperationException();/*
udanax-top.st:549:GrandNodeDoubler class methodsFor: 'creation'!
make: gNode {GrandNode}
	DiskManager consistent: 1 with: [
		^ GrandNodeDoubler create: gNode]!
*/
}
}
