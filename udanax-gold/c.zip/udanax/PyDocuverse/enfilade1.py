from CRUM import CRUM, UpperCRUM
from __future__ import generators

x = """

Both a mapping _and_ a sequence ?? ordered mapping ??

# Grande Enfilade is a one-dimensional mapping of XXX to XXX.
# It is not bidirectional.  It stores two types of objects:
# a string or the root node of a 2d-enfilade.  There are NO
# gaps in the single dimension, so the position of any item
# is equal to the sum of the lengths of any previous items.

epiphany!  width is NOT the width of the datum necessarily, but the _distance_ to the
next content item!!!  For the last item, the width is _always_ zero, of course!

xxx = enf.keys()   # generator of subscript list
xxx = enf.values() # generator of datum list
xxx = enf.items()  # generator of (subscript, datum) list

f = enf.has_key(key)

key in enf
  turned into enf.__contains__(key)



datum = enf[key]
list_of_datums = enf[key, key] # Descend once and walk to the right
subenf = enf[key:key]
subenf = enf[key:]
subenf = enf[:key]

newenf = enf[key:key] + enf[key:key]


??? = len(enf)   # count of elements or span of subscript?

del enf[key]  # drop element
del enf[key:key] # drop multiple elements


??? = enf[-1]

enf[key] = datum



XXX Test persistence mechanism and the storing of class attributes.

"""

#class _NameSet:
#    " "
#    def __init__(self, **kwargs):
#        for k, v in kwargs.items():
#            setattr(self, k, v)

class _EnfiladeNav: # Abstract Base Class
    def __init__(self):
        self.width = self.WID_type() # Width of 'zero'

    def __repr__(self):
        f_id = self.father
        if f_id is not None:
            f_id = f_id.id

        lb_id = self.leftBrother()
        if lb_id is not None:
            lb_id = lb_id.id

        rb_id = self.rightBrother()
        if rb_id is not None:
            rb_id = rb_id.id

        if hasattr(self, 'leftson') and hasattr(self.leftson, 'id'):
            sn_id = self.leftson.id
        else:
            sn_id = None

        dtm   = getattr(self, 'datum', None)
        nsons = getattr(self, 'numsons', None)

        return "%s(#%d h=%d, f=%s, lbro=%s, rbro=%s, son=%s(#%s), wid=%s, dtm=%s)" % \
            (self.__class__.__name__, self.id, self.height, f_id, lb_id, rb_id, sn_id, nsons, `self.width`, `dtm`)

    def seek(self, sought_disp, accum_disp=None):
        """seek(sought_disp, accum_disp=None) -> (accum_disp, node)
           Walk from my position in the tree down and toward the right seeking a displacement."""

        accum_disp = accum_disp or self.DSP_type() # Default Displacement of 'zero'

        for node in self.rightpeers(): # Walk _across_ tree until correct displacement
            if accum_disp >= sought_disp or (accum_disp + node.width) > sought_disp:
                break;
            accum_disp += node.width

        if node.height > 0: # not yet at bottom level of tree, so descend...
            return node.leftson.seek(sought_disp, accum_disp)

        return accum_disp, node

#    def findPrevStreamAddr(self, upperbound, streamaddr):
#        """Find the last displacement in use, below the upperbound"""
#
#        print "Node# %d: findPrevStreamAddr(upperbound=%s, streamaddr=%s)" % (self.id, `upperbound`, `streamaddr`)
#        if self.height == 0:
#            print "bottom, returning lastBottomAddr"
#            return self.lastBottomAddr(streamaddr)
#
#        node = self.leftson
#        while node:
#            n = node.whereoncrum(streamaddr, upperbound)
#            print "whereoncrum(streamaddr=%s, upperbound=%s) ==> %s" % (streamaddr, upperbound, n)
#            if n == THRUME or n == ONMYRIGHTBORDER or node.rightBrother() is None:
#                return node.findPrevStreamAddr(upperbound, streamaddr)
#            else:
#                streamaddr += node.width
#
#            node = node.rightBrother()
#        return streamaddr

    def walknodes(self, accum_disp=None):
        """Generator: a top-down, width-first, left-to-right walk of the tree."""

        accum_disp = accum_disp or self.DSP_type() # Default Displacement of 'zero'

        stash_disp = accum_disp
        for node in self.rightpeers():
            yield (accum_disp, node)
            accum_disp += node.width   # Adjust DSP by value of WID

        if self.height > 0:  # Not at bottom, descend further
            accum_disp = stash_disp
            for node in self.rightpeers():
                for x in node.leftson.walknodes(accum_disp):
                    yield x
                accum_disp += node.width   # Adjust DSP by value of WID

    def walkleaves(self, accum_disp=None):
        """Generator: a left-to-right bottom-walk of the tree."""

        accum_disp = accum_disp or self.DSP_type() # Default Displacement of 'zero'

        if self.height == 0:  # At Bottom, Walk My Peers at *this* Level
            for node in self.rightpeers():
                yield (accum_disp, node)
                accum_disp += node.width   # Adjust DSP by value of WID
        else:                 # Descend Further
            for node in self.rightpeers():
                for x in node.leftson.walkleaves(accum_disp):
                    yield x
                accum_disp += node.width   # Adjust DSP by value of WID

    def keys(self):
        """Generator: return the set of displacements currently defined within the enfilade"""

        for accum_disp, node in self.walkleaves():
            yield accum_disp

    def values(self):
        """Generator: return the set of elements currently hanging off the enfilade"""

        for accum_disp, node in self.walkleaves():
            yield node.datum

    def items(self, accum_disp=None):
        """Generator: return the set of (displacements, elements) within the enfilade"""

        for accum_disp, node in self.walkleaves():
            yield accum_disp, node.datum

class BottomCRUM(CRUM, _EnfiladeNav):
    def __init__(self, datum=None):
        CRUM.__init__(self, height=0)
        _EnfiladeNav.__init__(self)
        self.datum = datum

class Enfilade(UpperCRUM, _EnfiladeNav):
    """One-dimensional enfilade, also called the Model-T enfilade.
    """

    def __init__(self, **kwargs):
        UpperCRUM.__init__(self, **kwargs)
        _EnfiladeNav.__init__(self)

    def dispPresent(self, disp):
        """Return boolean indicating whether this displacement explicitly resides within the tree."""
        return self.seek(disp)[0] == disp

    def remove(self, key):
        """  """
        pass # returns new root

    def adjustWisp(self):
        """The WIDdative operation in general; returns boolean of whether the wisp was changed"""

        if self.height == 0:  # If distance from bottom of tree is zero,
            return None           # We don't operate on the bottom crums

        sum = self.WID_type() # Width of 'zero'
	son = self.leftson
        while son: # Walk list of my immediate sons, summing widths across them
            print "sum is ", `sum`
            print "son.width is ", `son.width`

            sum += son.width
            son = son.rightBrother()

        if sum == self.width:
            return None

        self.width = sum
        print "adjustWisp width is a", `self.width`
        return 1

    def adjustWispUpwards(self):
        """Walk up father chain adjusting the wisp until changes stop occurring; Returns boolean"""

        any_changes = None
        whilechanges = 1

        node = self
        while node and whilechanges:
            whilechanges = node.adjustWisp()
            if whilechanges:
                any_changes = 1
            node = node.father

        return any_changes

    def insert(self, ins_disp, datum):
        """insert(ins_disp, datum) -> <newtree>
           Insert an element at the specified displacement"""

        # Walk to bottom of tree to find where to insert the new element.
        prev_disp, prev_node = self.seek(ins_disp)

        ins_node = self.CRUM_type(datum)
        prev_node.adoptAsRightBrother(ins_node)

        any_splits = ins_node.father.splitUpwards()

        if prev_node.width == self.WID_type(): # appending to last crum, then put it just before the 0-width sentinel
            print "---------- Appending to Enfilade Sequence ----------"

            ins_node.width = self.WID_type() # Width of 'zero'
            print "width of that which we are inserting is", `ins_node.width`
	    print "abs disp at which we are inserting it is", `ins_disp`
	    print "my brother's abs disp is", `prev_disp`

            prev_node.width  = ins_disp - prev_disp
            print "after insertion, my brother's new width is", `prev_node.width`

        else:
            print "---------- Inserting into Enfilade Sequence ----------"

            reach           = prev_disp + prev_node.width
            ins_node.width       = reach - ins_disp
            print "Z insert ins_node.width is a", `ins_node.width`

            prev_node.width  = ins_disp - prev_disp
            print "Z insert prev_node.width is a", `prev_node.width`

        prev_node.father.adjustWispUpwards()
        ins_node.father.adjustWispUpwards()

        if prev_node.father.splitUpwards():
            any_splits = 1

        if any_splits:
            self.recombine()

        return self # Return root of modified tree

class EnfiladeWrapper:
    " "

    def __init__(self, enf=None, enfclass=None):
        if enf is None:
            enf = enfclass(height=1, isroot=1, isleftmost=1)
            enf.adoptAsLeftmostSon( enf.CRUM_type() )
        self.enf = enf

    def __setitem__(self, key, item):
        self.enf = self.enf.insert(key, item)

    def __getitem__(self, key, *args, **kwargs):
        if type(key) == type(()):
            print  "SLICES: %s"  % `key`
            return self        
        if type(key) == type(slice(0)):
            print  "SLICE: %s"  % `key`
            return self
        return (key, args, kwargs)

    def has_key(self, key):
        return self.enf.dispPresent(key)

    def keys(self):    return self.enf.keys()
    def values(self):  return self.enf.values()
    def items(self):   return self.enf.items()

if __name__ == "__main__":

    from widdsp import myWID, myDSP

    class MyBottomCRUM(BottomCRUM):
        DSP_type, WID_type = myDSP, myWID

    class MyEnfilade(Enfilade):
        CRUM_type = MyBottomCRUM
        DSP_type  = MyBottomCRUM.DSP_type
        WID_type  = MyBottomCRUM.WID_type

    e = EnfiladeWrapper(enfclass=MyEnfilade)

    e[ myDSP(1) ] = "DataAt_1"
    e[ myDSP(3) ] = "DataAt_3"
    e[ myDSP(6) ] = "DataAt_6"

#    e[ myDSP(7) ] = "Data4"
#    e[ myDSP(8) ] = "Data5"
#    e[ myDSP(9) ] = "Data6"
#    e[ myDSP(10) ] = "Data7"
#    #e[ myDSP("1.2") ] = "Data3"

    print "At position %s we have %s" % (myDSP(6), e[ myDSP(6) ])

    print "Presence of %s is %s" % (myDSP(5), e.has_key(myDSP(5)))
    print "Presence of %s is %s" % (myDSP(9), e.has_key(myDSP(9)))

    print "\n------------------------------ EWALK of Enfilade #1"
    for x in e.items():
        print "NEXT", `x`

    print "\n------------------------------ Dump of Enfilade #1"
    for accum_disp, node in e.enf.walknodes():
        print "+%s: %s" % (`accum_disp`, node)


#    e2 = e[ myDSP(3):myDSP(5) ]
#
#    print "\n------------------------------ EWALK of Enfilade #2"
#    for x in e2.items():
#        print "NEXT", `x`
#
#    print "\n------------------------------ Dump of Enfilade #2"
#    for accum_disp, node in e2.enf.walknodes():
#        print "+%s: %s" % (`accum_disp`, node)


#    e3 = e[ myDSP(1):myDSP(2) ] + e2
#
#    print "\n------------------------------ EWALK of Enfilade #3"
#    for x in e3.items():
#        print "NEXT", `x`
#
#    print "\n------------------------------ Dump of Enfilade #3"
#    for accum_disp, node in e3.enf.walknodes():
#        print "+%s: %s" % (`accum_disp`, node)


#    e4 = e[ myDSP(3):myDSP(5), myDSP(1):myDSP(2) ]
#
#    print "\n------------------------------ EWALK of Enfilade #4"
#    for x in e4.items():
#        print "NEXT", `x`
#
#    print "\n------------------------------ Dump of Enfilade #4"
#    for accum_disp, node in e4.enf.walknodes():
#        print "+%s: %s" % (`accum_disp`, node)


    import cPickle

    fd = open('/var/tmp/junk.enf', 'w')
    cPickle.dump(e, fd, 1)
    fd.close()

    fd = open('/var/tmp/junk.enf', 'r')
    ee = cPickle.load(fd)
    fd.close()

    print "\n------------------------------ Dump of Enfilade ee"
    for accum_disp, node in ee.enf.walknodes():
        print "+%s: %s" % (`accum_disp`, node)
