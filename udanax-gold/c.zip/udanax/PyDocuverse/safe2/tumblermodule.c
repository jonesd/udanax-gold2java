 /**
 * @file  tumblermodule.c
 * @brief Memory-Resident Tumbler Objects
 *
 **/

static char tumbler_module__doc__ [] = "\
There are two basic flavors of tumbler: address tumblers and\n\
difference tumblers.  The former represent a specific\n\
zero-dimensional point along the tumbler number line and the\n\
latter represent a span or segment along the number line.\n\
\n\
However, difference tumblers don't represent a count of anything.\n\
They don't mean some N characters, N bytes or N paragraphs.  Because\n\
of this they have no meaning in isolation but only when paired with\n\
an address tumbler.  This (address, difference) tuple is called a span.";

#include "ExtensionClass.h"
#include <ctype.h>

//hash
//if tumbler in span
//if span in span         __contains__
//if tumbler == tumbler
//if span == span

#define MODNAME "Tumbler"

#define NPLACES 11
enum { LESSER=-1, EQUAL=0, GREATER=+1 };

#ifdef DIGITS_LONGLONG
    typedef unsigned long long  digit;
    #define strtodigit  strtoull
#else
    typedef unsigned long       digit;
    #define strtodigit  strtoul
#endif

#define Tumbler_Check(op) ((op)->ob_type == &TumblerType)
//jrr #define Span_Check(op)    ((op)->ob_type == &SpanType)

// A little syntactic glue...
#define UNLESS(E)    if(!(E))
#define RETURN_NONE  Py_INCREF(Py_None); return Py_None

//staticforward PyTypeObject TumblerType;
staticforward PyExtensionClass TumblerType;
//jrrstaticforward PyTypeObject SpanType;

typedef struct {
    PyObject_HEAD
    char    negsign;          // 1 if negative, otherwise 0
    short   exp;
    short   numdigits;
    long    hash;
    digit   mantissa[NPLACES];
} TumblerObject;

//jrr typedef struct {
//jrr     PyObject_HEAD
//jrr     TumblerObject *addr;
//jrr     TumblerObject *diff;
//jrr } SpanObject;

/* Standard Constants */

TumblerObject ZeroTumbler = {
    PyObject_HEAD_INIT((PyTypeObject *) &TumblerType)
    0,
    0,
    0,
};

    static void
tumbler_precalc(TumblerObject *self)
{
    long x;
    int i;

    // Precompute Number of Digits, for Performance
    self->numdigits = NPLACES;
    do { // Remove Trailing Zeroes
        --self->numdigits;
    } while (self->numdigits > 0 && self->mantissa[self->numdigits] == 0);
    self->numdigits++;

    // Precompute Pythonic Hash Code
    x = 0x876543L;

    x = (1000003 * x) ^ self->negsign;
    x = (1000003 * x) ^ self->exp;

    for (i = 0; i < self->numdigits; i++)
        x = (1000003 * x) ^ self->mantissa[i];

    x ^= self->numdigits;
    if (x == -1)
        x = -2;

    self->hash = x;
}

    static TumblerObject *
tumbler_validate(TumblerObject *self)
{
    int i;

    if (self->exp > 0) {
        PyErr_SetString(PyExc_OverflowError, "invalid exponent (>0)");
        PyMem_DEL(self);
        return NULL;
    }

    if (self->negsign && self->mantissa[0] == 0) {
        PyErr_SetString(PyExc_OverflowError, "negative zero");
        PyMem_DEL(self);
        return NULL;
    }

    if (self->exp && self->mantissa[0] == 0){
        PyErr_SetString(PyExc_OverflowError, "non-normalized");
        PyMem_DEL(self);
        return NULL;
    }

    if (self->mantissa[0] == 0) {
        for (i = 1; i < NPLACES; ++i){
            if (self->mantissa[i] != 0){
                PyErr_SetString(PyExc_OverflowError, "nonzero zero tumbler");
                PyMem_DEL(self);
                return NULL;
            }
        }
    }

    for (i = 0; i < NPLACES; ++i) {
        if (self->mantissa[i] < 0) {
            PyErr_SetString(PyExc_OverflowError, "negative digit");
            PyMem_DEL(self);
            return NULL;
        }
    }

    return self;
}

    static PyObject *
tumblerobj__init__(PyObject *self, PyObject *args)
{
    int i, j;
    TumblerObject *tumbler = (TumblerObject *) self;
    PyObject *initarg;

    UNLESS(PyArg_ParseTuple(args, "O:new_tumbler", &initarg)) return NULL;
//    UNLESS(tumbler = PyObject_New(&TumblerObject, &TumblerType)) return NULL;

    // If String, Parse and Convert String into New Tumbler
    if (PyString_Check(initarg)) {
        char *s = PyString_AsString(initarg);
	while (isspace(*s))
            s++;

        if (*s == '-') {
            tumbler->negsign = 1;
            s++;
        } else
            tumbler->negsign = 0;

        memset(&tumbler->mantissa, 0, sizeof(tumbler->mantissa));
        tumbler->exp = 0;

        for (i = 0; i < NPLACES; i++) {
            char *e;

            if (*s == '\0')
                break;

            errno = 0; // Prepare to Detect Overflows
            tumbler->mantissa[i] = strtodigit(s, &e, 10);

            if (errno) {
                PyErr_Format(PyExc_OverflowError, "digit value overflow in tumbler at: %s", s);
                PyMem_DEL(tumbler);
                return NULL;
            }

            if (s == e) { // Nothing was Parsed
                PyErr_Format(PyExc_SyntaxError, "incorrectly formed tumbler at: %s", s);
                PyMem_DEL(tumbler);
                return NULL;
            }

            s = e; // Advance Past Text Just Parsed

            if (tumbler->mantissa[i] == 0 && i == 0) { // Accumulate Leading Zeroes
                --tumbler->exp;
                --i;
            }

            if (*s == '.') {
                s++;
            } else if (isspace(*s)) {
            } else if (*s != '\0') {
                PyErr_Format(PyExc_SyntaxError, "incorrectly formed tumbler at: %s", s);
                PyMem_DEL(tumbler);
                return NULL;
            }
        }

        if (*s != '\0') {
            PyErr_Format(PyExc_OverflowError, "limit of %d digits in tumbler exceeded", NPLACES);
            PyMem_DEL(tumbler);
            return NULL;
        }

        for (j = 0; j < NPLACES && tumbler->mantissa[j] == 0; ++j)
            ; // Determine if Mantissa Consists *entirely* of Zeroes

        if (j == NPLACES)
            tumbler->exp = 0; // Mantissa is *all* Zeroes, Shorten Exponent

    // If Integer, Convert into New Tumbler
    // TBD

    // If Array of Integers, Convert into New Tumbler
    // TBD

    } else { // Initialization Argument not a Recognized Type/Object
        PyErr_SetString(PyExc_SyntaxError, "string required");
        PyMem_DEL(tumbler);
        return NULL;
    }

    tumbler_precalc(tumbler);
    return (PyObject *) tumbler_validate(tumbler);
}


//static PyObject *
//tumbler_new(PyObject *moduleself, PyObject *args)
//{
//    int i, j;
//    TumblerObject *tumbler;
//    PyObject *initarg;
//
//    UNLESS(PyArg_ParseTuple(args, "O:new_tumbler", &initarg)) return NULL;
//    UNLESS(tumbler = PyObject_New(&TumblerObject, &TumblerType)) return NULL;
//
//    // If String, Parse and Convert String into New Tumbler
//    if (PyString_Check(initarg)) {
//        char *s = PyString_AsString(initarg);
//	while (isspace(*s))
//            s++;
//
//        if (*s == '-') {
//            tumbler->negsign = 1;
//            s++;
//        } else
//            tumbler->negsign = 0;
//
//        memset(&tumbler->mantissa, 0, sizeof(tumbler->mantissa));
//        tumbler->exp = 0;
//
//        for (i = 0; i < NPLACES; i++) {
//            char *e;
//
//            if (*s == '\0')
//                break;
//
//            errno = 0; // Prepare to Detect Overflows
//            tumbler->mantissa[i] = strtodigit(s, &e, 10);
//
//            if (errno) {
//                PyErr_Format(PyExc_OverflowError, "digit value overflow in tumbler at: %s", s);
//                PyMem_DEL(tumbler);
//                return NULL;
//            }
//
//            if (s == e) { // Nothing was Parsed
//                PyErr_Format(PyExc_SyntaxError, "incorrectly formed tumbler at: %s", s);
//                PyMem_DEL(tumbler);
//                return NULL;
//            }
//
//            s = e; // Advance Past Text Just Parsed
//
//            if (tumbler->mantissa[i] == 0 && i == 0) { // Accumulate Leading Zeroes
//                --tumbler->exp;
//                --i;
//            }
//
//            if (*s == '.') {
//                s++;
//            } else if (isspace(*s)) {
//            } else if (*s != '\0') {
//                PyErr_Format(PyExc_SyntaxError, "incorrectly formed tumbler at: %s", s);
//                PyMem_DEL(tumbler);
//                return NULL;
//            }
//        }
//
//        if (*s != '\0') {
//            PyErr_Format(PyExc_OverflowError, "limit of %d digits in tumbler exceeded", NPLACES);
//            PyMem_DEL(tumbler);
//            return NULL;
//        }
//
//        for (j = 0; j < NPLACES && tumbler->mantissa[j] == 0; ++j)
//            ; // Determine if Mantissa Consists *entirely* of Zeroes
//
//        if (j == NPLACES)
//            tumbler->exp = 0; // Mantissa is *all* Zeroes, Shorten Exponent
//
//    // If Integer, Convert into New Tumbler
//    // TBD
//
//    // If Array of Integers, Convert into New Tumbler
//    // TBD
//
//    } else { // Initialization Argument not a Recognized Type/Object
//        PyErr_SetString(PyExc_SyntaxError, "string required");
//        PyMem_DEL(tumbler);
//        return NULL;
//    }
//
//    tumbler_precalc(tumbler);
//    return (PyObject *) tumbler_validate(tumbler);
//}




//static int
//BTree_ini(BTree *self)
//{
//  PyObject *b;
//
//  UNLESS(b=PyObject_CallObject(OBJECT(&BucketType), NULL)) return -1;
//  self->data->value=b;
//  self->data->count=0;
//  self->len=1;
//  self->count=0;
//  return 0;
//}

//static int
//BTree_init(BTree *self)
//{
//  UNLESS(self->data=PyMalloc(sizeof(BTreeItem)*2)) return -1;
//  self->size=2;
//  return BTree_ini(self);
//}

//jrr static PyObject *
//jrr span_new(PyObject *moduleself, PyObject *args)
//jrr {
//jrr     SpanObject *span;
//jrr     PyObject *initaddr, *initdiff, *v;
//jrr 
//jrr     UNLESS(PyArg_ParseTuple(args, "OO:new_span", &initaddr, &initdiff)) return NULL;
//jrr     UNLESS(span = PyObject_New(SpanObject, &SpanType)) return NULL;
//jrr 
//jrr     if (!Tumbler_Check(initaddr)) {
//jrr 	UNLESS(v = Py_BuildValue("(O)", initaddr)) return NULL;
//jrr         span->addr = (TumblerObject *) tumbler_new(NULL, v);
//jrr         Py_DECREF(v);
//jrr     } else
//jrr         span->addr = (TumblerObject *) initaddr;
//jrr 
//jrr     if (!Tumbler_Check(initdiff)) {
//jrr 	UNLESS(v = Py_BuildValue("(O)", initdiff)) return NULL;
//jrr         span->diff = (TumblerObject *) tumbler_new(NULL, v);
//jrr         Py_DECREF(v);
//jrr     } else
//jrr         span->diff = (TumblerObject *) initdiff;
//jrr 
//jrr     Py_INCREF(span->addr);
//jrr     Py_INCREF(span->diff);
//jrr 
//jrr     return (PyObject *) span;
//jrr }

//jrr static void
//jrr span_dealloc(SpanObject *self)
//jrr {
//jrr     Py_DECREF(self->addr);
//jrr     Py_DECREF(self->diff);
//jrr 
//jrr //    PyObject_Del(self);
//jrr     Py_DECREF(self->ob_type);
//jrr     PyMem_DEL(self);
//jrr }

static void
tumbler_dealloc(TumblerObject *self)
{
//    PyObject_Del(self);

    Py_DECREF(self->ob_type);
    PyMem_DEL(self);
}

    static PyObject *
tumbler__repr__(TumblerObject *self)
{
    PyObject *s, *period, *zeroperiod;
    int i, place = NPLACES;
    char buf[20];

    if (self->negsign)
        s = PyString_FromString("tumbler('-");
    else
        s = PyString_FromString("tumbler('");

    period = PyString_FromString(".");
    zeroperiod = PyString_FromString("0.");

    for (i = 0; i < -self->exp; i++)
        PyString_Concat(&s, zeroperiod);

    do {
        --place;
    } while (place > 0 && self->mantissa[place] == 0);

    for (i = 0; i <= place && s != NULL; i++) {
        sprintf(buf, "%ld", self->mantissa[i]);
        PyString_ConcatAndDel(&s, PyString_FromString(buf));

        if (i < place)
            PyString_Concat(&s, period);
    }

    Py_DECREF(period);
    Py_DECREF(zeroperiod);

    PyString_ConcatAndDel(&s, PyString_FromString("')"));
    return s;
}

    static PyObject *
tumbler__str__(TumblerObject *self)
{
    PyObject *s, *period, *zeroperiod;
    int i, place = NPLACES;
    char buf[20];

    if (self->negsign)
        s = PyString_FromString("-");
    else
        s = PyString_FromString("");

    period = PyString_FromString(".");
    zeroperiod = PyString_FromString("0.");

    for (i = 0; i < -self->exp; i++)
        PyString_Concat(&s, zeroperiod);

    do {
        --place;
    } while (place > 0 && self->mantissa[place] == 0);

    for (i = 0; i <= place && s != NULL; i++) {
        sprintf(buf, "%ld", self->mantissa[i]);
        PyString_ConcatAndDel(&s, PyString_FromString(buf));

        if (i < place)
            PyString_Concat(&s, period);
    }

    Py_DECREF(period);
    Py_DECREF(zeroperiod);

    return s;
}

//jrr     static PyObject *
//jrr span__repr__(SpanObject *self)
//jrr {
//jrr     PyObject *a, *d, *s;
//jrr     
//jrr     a = tumbler__str__(self->addr);
//jrr     d = tumbler__str__(self->diff);
//jrr 
//jrr     s = PyString_FromString("span(");
//jrr     PyString_ConcatAndDel(&s, a);
//jrr     PyString_ConcatAndDel(&s, PyString_FromString(", "));
//jrr     PyString_ConcatAndDel(&s, d);
//jrr     PyString_ConcatAndDel(&s, PyString_FromString(")"));
//jrr     
//jrr     return s;
//jrr }

//jrr     static PyObject *
//jrr span__str__(SpanObject *self)
//jrr {
//jrr     PyObject *a, *d, *s;
//jrr     
//jrr     a = tumbler__str__(self->addr);
//jrr     d = tumbler__str__(self->diff);
//jrr 
//jrr     s = PyString_FromString("(");
//jrr     PyString_ConcatAndDel(&s, a);
//jrr     PyString_ConcatAndDel(&s, PyString_FromString(", "));
//jrr     PyString_ConcatAndDel(&s, d);
//jrr     PyString_ConcatAndDel(&s, PyString_FromString(")"));
//jrr     
//jrr     return s;
//jrr }

//jrr    static int
//jrrtumbler__len__(TumblerObject *self)
//jrr{
//jrr    return -self->exp + self->numdigits;
//jrr}

//jrr    static int
//jrrtumbler_nonzero(TumblerObject *self)
//jrr{
//jrr    return self->mantissa[0] != 0;
//jrr}

    static int
tumbler_abscmp(TumblerObject *aptr, TumblerObject *bptr)
{
    digit *a, *b;
    int i, cmp;

    if (aptr->exp != bptr->exp) {
        if (aptr->exp < bptr->exp)  return LESSER;
        else                        return GREATER;
    }

    a = aptr->mantissa;
    b = bptr->mantissa;
    for (i = NPLACES; i--;) {
        if (!(cmp = *a++ - *b++)) {
        } else if (cmp < 0) {
            return LESSER;	/* a < b */
        } else {  /* if (cmp > 0) */
            return GREATER;
        }
    }

    return EQUAL;
}

    static int
tumbler_compare(TumblerObject *vt, TumblerObject *wt)
{
//    TumblerObject *vt, *wt;
//
//    vt = (TumblerObject *) v;
//    wt = (TumblerObject *) w;

    if (vt->mantissa[0] == 0) {
        if (wt->mantissa[0] == 0)
            return EQUAL;
        else
            return (wt->negsign ? GREATER : LESSER);
    }

    if (wt->mantissa[0] == 0)
        return (vt->negsign ? LESSER : GREATER);

    if (vt->negsign == wt->negsign)
        return (vt->negsign ? tumbler_abscmp(wt, vt) : tumbler_abscmp(vt, wt));

    return (vt->negsign ? LESSER : GREATER);
}

//jrr    static PyObject *
//jrrtumbler_item(TumblerObject *self, int i)
//jrr{
//jrr    int prefixzeroes = -self->exp;
//jrr
//jrr    if (i < 0 || i >= prefixzeroes + self->numdigits) {
//jrr        PyErr_SetString(PyExc_IndexError, "tumbler index out of range");
//jrr        return NULL;
//jrr    }
//jrr
//jrr    if (i < prefixzeroes) {
//jrr        return PyInt_FromLong(0);
//jrr    } else {
//jrr        return PyInt_FromLong(self->mantissa[i - prefixzeroes]);
//jrr    }
//jrr}

//jrr     static TumblerObject *
//jrr span_item(SpanObject *self, int i)
//jrr {
//jrr     switch (i) {
//jrr     case 0:  Py_INCREF(self->addr); return self->addr;
//jrr     case 1:  Py_INCREF(self->diff); return self->diff;
//jrr     default:
//jrr         PyErr_SetString(PyExc_IndexError, "span index out of range");
//jrr         return NULL;
//jrr     }
//jrr }

//jrr    static PyObject *
//jrrtumbler_slice(TumblerObject *self, int ilow, int ihigh)
//jrr{
//jrr    int prefixzeroes = -self->exp;
//jrr    int totdigits    = prefixzeroes + self->numdigits;
//jrr
//jrr    TumblerObject *np;
//jrr    int i;
//jrr
//jrr    if (ilow  < 0)           ilow  = 0;
//jrr    if (ihigh > totdigits)   ihigh = totdigits;
//jrr    if (ihigh < ilow)        ihigh = ilow;
//jrr
//jrr    if (ilow == 0 && ihigh == totdigits) {
//jrr        /* XXX can only do this if tumblers are immutable! */
//jrr        Py_INCREF(self);
//jrr        return (PyObject *) self;
//jrr    }
//jrr
//jrr    UNLESS(np = PyObject_New(TumblerObject, &TumblerType)) return NULL;
//jrr
//jrr    np->negsign    = self->negsign;
//jrr    memset(&np->mantissa, 0, sizeof(np->mantissa));
//jrr    np->exp = 0;
//jrr    np->numdigits = 0;
//jrr
//jrr    for (i = ilow; i < ihigh; i++) {
//jrr        if (i < prefixzeroes)
//jrr            --np->exp;
//jrr        else {
//jrr            np->mantissa[i - ilow - prefixzeroes] = self->mantissa[i - prefixzeroes];
//jrr            np->numdigits++;
//jrr        }
//jrr    }
//jrr
//jrr    return (PyObject *) tumbler_validate(np);
//jrr}

//jrr    static TumblerObject *
//jrrtumbler_absadd(TumblerObject *a, TumblerObject *b)
//jrr{
//jrr    int i, j, temp;
//jrr    TumblerObject *c;
//jrr
//jrr    i = j = 0;
//jrr
//jrr    UNLESS(c = PyObject_New(TumblerObject, &TumblerType)) return NULL;
//jrr    memset(&c->mantissa, 0, sizeof(c->mantissa));
//jrr
//jrr    c->negsign = 0;
//jrr
//jrr    if (a->exp == b->exp) {
//jrr        c->exp = a->exp;
//jrr        c->mantissa[0] = a->mantissa[0] + b->mantissa[0];
//jrr        i = j = 1;
//jrr
//jrr    } else if (a->exp > b->exp) {
//jrr        c->exp = a->exp;
//jrr        temp = a->exp - b->exp;
//jrr        while (i < temp)
//jrr            c->mantissa[j++] = a->mantissa[i++];
//jrr        c->mantissa[j++] = a->mantissa[i++] + b->mantissa[0];
//jrr        i = 1;
//jrr
//jrr    } else {
//jrr        c->exp = b->exp;
//jrr        temp = b->exp - a->exp;
//jrr        while (i <= temp)
//jrr            c->mantissa[j++] = b->mantissa[i++];
//jrr    }
//jrr
//jrr    while (j <= NPLACES - 1)
//jrr        c->mantissa[j++] = b->mantissa[i++];
//jrr
//jrr    tumbler_precalc(c);
//jrr    return c;
//jrr}

#define tumbler_eq(a, b)  (tumbler_compare((a), (b)) == EQUAL)

//jrr    static TumblerObject *
//jrrtumbler_strongsub(TumblerObject *a, TumblerObject *b)
//jrr{
//jrr    int i, j;
//jrr    TumblerObject *c;
//jrr
//jrr    if (tumbler_eq(a, b)) {
//jrr        Py_INCREF(&ZeroTumbler);
//jrr        return &ZeroTumbler;
//jrr    }
//jrr
//jrr    if (b->exp < a->exp) {
//jrr        Py_INCREF(a);
//jrr        return a;
//jrr    }
//jrr
//jrr    UNLESS(c = PyObject_New(TumblerObject, &TumblerType)) return NULL;
//jrr    memset(&c->mantissa, 0, sizeof(c->mantissa));
//jrr
//jrr    c->exp = a->exp;
//jrr    for (i = 0; a->mantissa[i] == b->mantissa[i]; i++) {
//jrr        --c->exp;
//jrr        if (i >= NPLACES)
//jrr            return c;
//jrr    }
//jrr
//jrr    c->mantissa[0] = a->mantissa[i] - b->mantissa[i];
//jrr    if (++i >= NPLACES)
//jrr        return c;
//jrr
//jrr    for (j = 1; j < NPLACES && i < NPLACES; )
//jrr        c->mantissa[j++] = a->mantissa[i++];
//jrr
//jrr    return c;
//jrr}

//jrr    static TumblerObject *
//jrrtumbler_weaksub(TumblerObject *a, TumblerObject *b)
//jrr{
//jrr    int i;
//jrr    TumblerObject *c;
//jrr
//jrr    if (tumbler_eq(a, b)) {
//jrr        Py_INCREF(&ZeroTumbler);
//jrr        return &ZeroTumbler;
//jrr    }
//jrr
//jrr    UNLESS(c = PyObject_New(TumblerObject, &TumblerType)) return NULL;
//jrr    memset(&c->mantissa, 0, sizeof(c->mantissa));
//jrr
//jrr    c->exp = a->exp;
//jrr    for (i = 0; i < (a->exp - b->exp); i++) {
//jrr        c->mantissa[i] = a->mantissa[i];
//jrr        if (i >= NPLACES)
//jrr            return c;
//jrr    }
//jrr
//jrr    c->mantissa[i] = a->mantissa[i] - b->mantissa[0];
//jrr    return c;
//jrr}

//jrr    static void
//jrrtumbler_justify(TumblerObject *self)
//jrr{
//jrr    int i, j, shift;
//jrr  
//jrr    if (self->mantissa[0] != 0)
//jrr        return;
//jrr
//jrr    for (shift = 0; self->mantissa[shift] == 0; ++shift) {
//jrr        if (shift == NPLACES - 1) {
//jrr            self->exp  = 0;
//jrr	    self->negsign = 0;
//jrr            return;
//jrr        }
//jrr    }
//jrr
//jrr    for (i = 0, j = shift; j < NPLACES;)
//jrr        self->mantissa[i++] = self->mantissa[j++];
//jrr
//jrr    while (i < NPLACES)
//jrr        self->mantissa[i++] = 0;
//jrr
//jrr    self->exp -= shift;
//jrr}

//jrr    static TumblerObject *
//jrrtumbler_add(TumblerObject *a, TumblerObject *b)
//jrr{
//jrr    TumblerObject *c;
//jrr
//jrr    if (b->mantissa[0] == 0) {
//jrr        Py_INCREF(a);
//jrr        return a;
//jrr    }
//jrr
//jrr    if (a->mantissa[0] == 0) {
//jrr        Py_INCREF(b);
//jrr        return b;
//jrr    }
//jrr
//jrr    if (a->negsign == b->negsign) {
//jrr        c = tumbler_absadd(a, b);
//jrr        c->negsign = a->negsign;
//jrr        /*absadd returns justified result so no need to justify*/
//jrr
//jrr    } else if (tumbler_abscmp(a, b) == GREATER) {
//jrr        c = tumbler_strongsub(a, b);
//jrr        c->negsign = a->negsign;
//jrr        if (c->mantissa[0] == 0)
//jrr            tumbler_justify(c);
//jrr
//jrr    } else {
//jrr        c = tumbler_weaksub(b, a);
//jrr        c->negsign = b->negsign;
//jrr        if (c->mantissa[0] == 0)
//jrr            tumbler_justify(c);
//jrr    }
//jrr
//jrr    tumbler_precalc(c);
//jrr    return tumbler_validate(c);
//jrr}

//jrr    static TumblerObject *
//jrrtumbler_subtract(TumblerObject *a, TumblerObject *b)
//jrr{
//jrr    TumblerObject *c, *bb;
//jrr
//jrr    if (b->mantissa[0] == 0) {
//jrr        Py_INCREF(a);
//jrr        return a;
//jrr    }
//jrr
//jrr    if (tumbler_eq(a, b)) {
//jrr        Py_INCREF(&ZeroTumbler);
//jrr        return &ZeroTumbler;
//jrr    }
//jrr
//jrr    if (a->mantissa[0] == 0) {
//jrr        TumblerObject *c;
//jrr
//jrr        UNLESS(c = PyObject_New(TumblerObject, &TumblerType)) return NULL;
//jrr
//jrr        c->negsign   = !b->negsign;
//jrr        c->exp       = b->exp;
//jrr        c->numdigits = b->numdigits;
//jrr        memcpy(&c->mantissa, b->mantissa, sizeof(c->mantissa));
//jrr        tumbler_precalc(c);
//jrr        return c;
//jrr    }
//jrr
//jrr    UNLESS(bb = PyObject_New(TumblerObject, &TumblerType)) return NULL;
//jrr
//jrr    bb->negsign   = !b->negsign;
//jrr    bb->exp       = b->exp;
//jrr    bb->numdigits = b->numdigits;
//jrr    memcpy(&bb->mantissa, b->mantissa, sizeof(c->mantissa));
//jrr
//jrr    c = tumbler_add(a, bb);
//jrr
//jrr    Py_DECREF(bb);
//jrr
//jrr    tumbler_justify(c);
//jrr    tumbler_precalc(c);
//jrr    return tumbler_validate(c);
//jrr}

//jrr     static PyObject *
//jrr span_richcompare(PyObject *v, PyObject *w, int op)
//jrr {
//jrr     SpanObject *vt;
//jrr     TumblerObject *wt, *right;
//jrr     int cmp1, cmp2, cmp3;
//jrr     PyObject *res;
//jrr 
//jrr     if (!Span_Check(v) || !(Span_Check(w) || Tumbler_Check(w))) {
//jrr         Py_INCREF(Py_NotImplemented);
//jrr         return Py_NotImplemented;
//jrr     }
//jrr 
//jrr     vt = (SpanObject *) v;
//jrr     if (Span_Check(w))  wt = ((SpanObject *) w)->addr;
//jrr     else                wt = (TumblerObject *) w;
//jrr 
//jrr 
//jrr     cmp1 = tumbler_compare(wt, vt->addr);
//jrr //    if (cmp1 == LESSER)
//jrr //        return TOMYLEFT;
//jrr //    else if (cmp1 == EQUAL)
//jrr //        return ONMYLEFTBORDER;
//jrr 
//jrr     right = tumbler_add(vt->addr, vt->diff);
//jrr 
//jrr     cmp2 = tumbler_compare(wt, right);
//jrr     Py_DECREF(right);
//jrr 
//jrr //    if (cmp2 == LESS)
//jrr //        return THRUME;
//jrr //    else if (cmp2 == EQUAL)
//jrr //        return ONMYRIGHTBORDER;
//jrr //    else
//jrr //        return TOMYRIGHT;
//jrr 
//jrr     switch (op) {
//jrr     case Py_LT: cmp3 = (cmp1 == LESSER);  break; // TOMYLEFT
//jrr     case Py_LE: cmp3 = (cmp1 == EQUAL);   break; // ONMYLEFTBORDER
//jrr //    case Py_EQ: cmp3 = vs == ws; break;
//jrr //    case Py_NE: cmp3 = vs != ws; break;
//jrr     case Py_GE: cmp3 = (cmp2 == EQUAL);   break; // ONMYRIGHTBORDER
//jrr     case Py_GT: cmp3 = (cmp2 == GREATER); break; // TOMYRIGHT
//jrr     default: return NULL; /* cannot happen */
//jrr     }
//jrr 
//jrr     if (cmp3)  res = Py_True;
//jrr     else       res = Py_False;
//jrr     Py_INCREF(res);
//jrr     return res;
//jrr }

static long
tumbler_hash(TumblerObject *self)
{
    return self->hash;
}

//    static PyObject *
//tumbler__getinitargs__(PyObject *self, PyObject *args)
//{
//    PyObject *v = Py_BuildValue("(s)", "9.8.7");
//
//    return v;
//}

//    static PyObject *
//tumblerobj__getstate__(PyObject *self, PyObject *args)
//{
//    PyObject *r;
//    PyObject *v;
//
//    printf("tumblerobj__getstate__ invoked\n");
//
//    UNLESS(r = PyTuple_New(1)) return NULL;
//
//    v = Py_BuildValue("s", "1.2.3");
//
//    PyTuple_SET_ITEM(r, 0, v);
    
//static PyObject *
//BTree_getstate(BTree *self, PyObject *args)
//{
//  PyObject *r=0, *item;
//  int i;
//
//  PER_USE_OR_RETURN(self, NULL);
//
//  UNLESS(r=PyTuple_New(self->len)) goto err;
//  for(i=self->len; --i >= 0; )
//    {
//      UNLESS(item=Py_BuildValue(KEY_PARSE "Oi",
//				self->data[i].key, self->data[i].value,
//				self->data[i].count))
//	goto err;
//      PyTuple_SET_ITEM(r,i,item);
//    }
//
//  PER_ALLOW_DEACTIVATION(self);
//  return r;
//
//err:
//  PER_ALLOW_DEACTIVATION(self);
//  Py_DECREF(r);
//  return NULL;
//}

//    return v;
//}

//    static PyObject *
//tumblerobj__reduce__(PyObject *self, PyObject *args)
//{
//    PyObject *r;
//
//    printf("tumblerobj__reduce__ invoked\n");
//
//    UNLESS(r = PyTuple_New(2)) return NULL;
//
//    PyTuple_SET_ITEM(r, 0, PyString_FromString("tumbler")); // Class
//    PyTuple_SET_ITEM(r, 1, Py_BuildValue("(s)", "1.2.3")); // Arguments
//    
//    return r;
//}

static struct PyMethodDef tumblerobj_methods[] = {
  {"__init__",  (PyCFunction) tumblerobj__init__,  METH_VARARGS,
   "__init__() -- Provide pickleable data"},

//  {"__getinitargs__",  (PyCFunction) tumbler__getinitargs__,  METH_VARARGS,
//   "__getinitargs__() -- Provide pickleable data"},
//
//  {"__getstate__",  (PyCFunction) tumblerobj__getstate__,  METH_VARARGS,
//   "__getstate__() -- Provide pickleable data"},
//
//  {"__reduce__",  (PyCFunction) tumblerobj__reduce__,  METH_VARARGS,
//   "__reduce__() -- Provide pickleable data"},
//
//  {"__setstate__",  (PyCFunction) tumbler__setstate__,  METH_VARARGS,
//   "__setstate__() -- Provide pickeable data"},

  {NULL,                NULL}           /* sentinel */
};

//#ifdef PERSISTENT
//  {"_p___reinit__",	(PyCFunction)bucket__p___reinit__,	METH_VARARGS,
//   "_p___reinit__() -- Reinitialize from a newly created copy"},
//  {"_p_deactivate",	(PyCFunction)bucket__p___reinit__,	METH_VARARGS,
//   "_p_deactivate() -- Reinitialize from a newly created copy"},
//#endif

//    static PyObject *
//tumbler_getattro(TumblerObject *s, PyObject *name)
//{
//    char *namestr = PyString_AsString(name);
//
//    printf("getattro(%s)\n", namestr);
//
//    if (strcmp(namestr, "__module__") == 0)
//        return PyString_FromString("tumbler");
//
//    return Py_FindMethod(tumblerobj_methods, (PyObject *) s, namestr);
//}

//    static PyObject *
//tumbler_getattr(TumblerObject *s, char *name)
//{
//    printf("getattr(%s)\n", name);
//
//    if (strcmp(name, "__safe_for_unpickling__") == 0)
//        return PyInt_FromLong(1);
//
//    return Py_FindMethod(tumblerobj_methods, (PyObject *) s, name);
//}

//jrrstatic PyNumberMethods tumbler_Number = {
//jrr    (binaryfunc)          &tumbler_add,          // nb_add
//jrr    (binaryfunc)          &tumbler_subtract,     // nb_subtract
//jrr    (binaryfunc)          0,                     // nb_multiply
//jrr    (binaryfunc)          0,                     // nb_divide
//jrr    (binaryfunc)          0,                     // nb_remainder
//jrr    (binaryfunc)          0,                     // nb_divmod
//jrr    (ternaryfunc)         0,                     // nb_power
//jrr    (unaryfunc)           0,                     // nb_negative
//jrr    (unaryfunc)           0,                     // nb_positive
//jrr    (unaryfunc)           0,                     // nb_absolute
//jrr    (inquiry)             &tumbler_nonzero,      // nb_nonzero
//jrr    (unaryfunc)           0,                     // nb_invert
//jrr    (binaryfunc)          0,                     // nb_lshift
//jrr    (binaryfunc)          0,                     // nb_rshift
//jrr    (binaryfunc)          0,                     // nb_and
//jrr    (binaryfunc)          0,                     // nb_xor
//jrr    (binaryfunc)          0,                     // nb_or
//jrr    (coercion)            0,                     // nb_coerce
//jrr    (unaryfunc)           0,                     // nb_int
//jrr    (unaryfunc)           0,                     // nb_long
//jrr    (unaryfunc)           0,                     // nb_float
//jrr    (unaryfunc)           0,                     // nb_oct
//jrr    (unaryfunc)           0,                     // nb_hex
//jrr};

//jrrstatic PySequenceMethods tumbler_Sequence = {
//jrr    (inquiry)             tumbler__len__,        // sq_length
//jrr    (binaryfunc)          0,                     // sq_concat
//jrr    (intargfunc)          0,                     // sq_repeat
//jrr    (intargfunc)          0,         // sq_item
//jrr    (intintargfunc)       0,        // sq_slice
//jrr    (intobjargproc)       0,                     // sq_ass_item
//jrr    (intintobjargproc)    0,                     // sq_ass_slice
//jrr};

static PyExtensionClass TumblerType = {
    PyObject_HEAD_INIT(NULL)
    0,                                    // ob_size
    "tumbler",                            // tp_name ::= Name of Type, for Printing
    sizeof(TumblerObject),                // tp_basicsize, for Allocation
    0,                                    // tp_itemsize, for Allocation
    // Methods to Implement Standard Operations
    (destructor)          &tumbler_dealloc,      // tp_dealloc
    (printfunc)           0,                     // tp_print
    (getattrfunc)         0,                     // tp_getattr
    (setattrfunc)         0,                     // tp_setattr
    (cmpfunc)             &tumbler_compare,      // tp_compare
    (reprfunc)            &tumbler__repr__,      // tp_repr
    // Method Suites for Standard Classes
    (PyNumberMethods *)   0,       // tp_as_number
    (PySequenceMethods *) 0,     // tp_as_sequence
    (PyMappingMethods *)  0,                     // tp_as_mapping
    // More Standard Operations
    (hashfunc)            &tumbler_hash,         // tp_hash
    (ternaryfunc)         0,                     // tp_call
    (reprfunc)            &tumbler__str__,       // tp_str
    (getattrofunc)        0,                     // tp_getattro
    (setattrofunc)        0,                     // tp_setattro
    // Functions to Access Object as I/O Buffer
    (PyBufferProcs *)     0,                     // tp_as_buffer
    // Flags to Defined Presence of Optional/Expanded Features
    (long)                0,                     // tp_flags
    (char *)              0,                     // tp_doc ::= __doc__ String

    METHOD_CHAIN(tumblerobj_methods),
//    EXTENSIONCLASS_BASICNEW_FLAG | PERSISTENT_TYPE_FLAG,
};

//jrr static PySequenceMethods span_Sequence = {
//jrr     (inquiry)             0,                     // sq_length
//jrr     (binaryfunc)          0,                     // sq_concat
//jrr     (intargfunc)          0,                     // sq_repeat
//jrr     (intargfunc)          &span_item,            // sq_item
//jrr     (intintargfunc)       0,                     // sq_slice
//jrr     (intobjargproc)       0,                     // sq_ass_item
//jrr     (intintobjargproc)    0,                     // sq_ass_slice
//jrr };

//jrr static PyTypeObject SpanType = {
//jrr     PyObject_HEAD_INIT(NULL)
//jrr     0,                                    // ob_size
//jrr     "span",                               // tp_name ::= Name of Type, for Printing
//jrr     sizeof(SpanObject),                   // tp_basicsize, for Allocation
//jrr     0,                                    // tp_itemsize, for Allocation
//jrr     // Methods to Implement Standard Operations
//jrr     (destructor)          span_dealloc,          // tp_dealloc
//jrr     (printfunc)           0,                     // tp_print
//jrr     (getattrfunc)         0,                     // tp_getattr
//jrr     (setattrfunc)         0,                     // tp_setattr
//jrr     (cmpfunc)             0,                     // tp_compare
//jrr     (reprfunc)            &span__repr__,         // tp_repr
//jrr     // Method Suites for Standard Classes
//jrr     (PyNumberMethods *)   0,                     // tp_as_number
//jrr     (PySequenceMethods *) &span_Sequence,        // tp_as_sequence
//jrr     (PyMappingMethods *)  0,                     // tp_as_mapping
//jrr     // More Standard Operations
//jrr     (hashfunc)            0,                     // tp_hash
//jrr     (ternaryfunc)         0,                     // tp_call
//jrr     (reprfunc)            &span__str__,          // tp_str
//jrr     (getattrofunc)        0,                     // tp_getattro
//jrr     (setattrofunc)        0,                     // tp_setattro
//jrr     // Functions to Access Object as I/O Buffer
//jrr     (PyBufferProcs *)     0,                     // tp_as_buffer
//jrr     // Flags to Defined Presence of Optional/Expanded Features
//jrr     (long)                0,                     // tp_flags
//jrr     (char *)              0,                     // tp_doc ::= __doc__ String
//jrr     (traverseproc)        0,                     // tp_traverse
//jrr     (inquiry)             0,                     // tp_clear
//jrr     (richcmpfunc)         &span_richcompare,     // tp_richcompare
//jrr };

static PyMethodDef module_methods[] = {
//    { "tumbler",  tumbler_new,  METH_VARARGS },
//    { "span",     span_new,     METH_VARARGS },
    {NULL, NULL}
};

DL_EXPORT(void)
inittumbler(void) 
{
    PyObject *m, *d;

    UNLESS(PyExtensionClassCAPI = PyCObject_Import("ExtensionClass", "CAPI"))
        return;

    TumblerType.tp_getattro = PyExtensionClassCAPI->getattro;
    TumblerType.ob_type     = &PyType_Type;

    m = Py_InitModule3(MODNAME, module_methods, tumbler_module__doc__);

    // Add some symbolic constants to the module
    d = PyModule_GetDict(m);

    PyExtensionClass_Export(d, "tumbler", TumblerType);

    if (PyErr_Occurred())
        Py_FatalError("can't initialize module: " MODNAME);
}

