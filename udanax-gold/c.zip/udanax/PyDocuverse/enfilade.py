from types import InstanceType
from Tumbler import tumbler, span

from CRUM import CRUM, UpperCRUM

x = """
epiphany!  width is NOT the width of the datum necessarily, but the _distance_ to the
next content item!!!  For the last item, the width is _always_ zero, of course!
"""

# Line-Segment Relationships
TOMYLEFT, ONMYLEFTBORDER, THRUME, ONMYRIGHTBORDER, TOMYRIGHT = -2, -1, 0, +1, +2

# bertModeNames[] = { "BADMODE", "ONLY", "COPYIF", "COPY" };
# char *bertTypeNames[] = { "NOBERT", "READBERT", "WRITEBERT" };
WRITEBERT = 2

NOBERTREQUIRED = 0
READBERT       = 1
WRITEBERT      = 2

BERTMODEONLY   = 1
BERTMODECOPYIF = 2
BERTMODECOPY   = 3

class NameSet:
    def __init__(self, **kwargs):
        for k, v in kwargs.items():
            setattr(self, k, v)

def intervalcmp(left, right, address):
    if address <  left:   return TOMYLEFT
    if address == left:   return ONMYLEFTBORDER

    if address <  right:  return THRUME
    if address == right:  return ONMYRIGHTBORDER
    return TOMYRIGHT

x = """
  if addr in (left, right):  #THRUME
  if addr > (left, right):   #TOMYRIGHT
  if addr >= (left, right):  #ONMYRIGHTBORDER
"""

class Displacer:
    """  """

    def __init__(self, ibasis=tumbler('0'), vbasis=tumbler('0')):
        self.I_BASIS = ibasis
        self.V_BASIS = vbasis

    def __add__(self, other):
        assert isinstance(other, Displacer)
        return self.__class__(ibasis=self.I_BASIS + other.I_BASIS, vbasis=self.V_BASIS + other.V_BASIS)

    def isEmpty(self):
        if self.I_BASIS or self.V_BASIS:
            return None # False - Displacer is NOT Empty
        return 1

    def max(self, other):
        i = max(self.I_BASIS, other.I_BASIS)
        v = max(self.V_BASIS, other.V_BASIS)
        return Displacer(ibasis=i, vbasis=v)

    def __repr__(self):
        return "Displacer(I=.%s., V=.%s.)" % (self.I_BASIS, self.V_BASIS)

class Widener:
    """  """

    def __init__(self, ibasis=tumbler('0'), vbasis=tumbler('0')):
        self.I_BASIS = ibasis
        self.V_BASIS = vbasis

    def __add__(self, other):
        assert isinstance(other, Widener)
        return self.__class__(ibasis=self.I_BASIS + other.I_BASIS, vbasis=self.V_BASIS + other.V_BASIS)

    def isEmpty(self):
        if self.I_BASIS or self.V_BASIS:
            return None # False - Widener is NOT Empty
        return 1

    def max(self, other):
        i = max(self.I_BASIS, other.I_BASIS)
        v = max(self.V_BASIS, other.V_BASIS)
        return Widener(ibasis=i, vbasis=v)

    def __repr__(self):
        return "Widener(I=.%s., V=.%s.)" % (self.I_BASIS, self.V_BASIS)

class EnfiladePOOM(UpperCRUM):
    """Permutation Ordering Operations Matrix (?)
       /* wid and dsp indexes for pm */
       #define I_BASIS  0
       #define V_BASIS  1
    """

    def __init__(self, height=1, title=''):
        UpperCRUM.__init__(self, height=height)
        self.title = title
#        print "----> POOM(id=%d)" % self.id
        self.cdsp = Displacer()
        self.cwid = Widener()



    def findsontoinsertundernd(CoreUpperCrum *father, Displacer *grasp, Displacer *origin, Widener *width, int index):
        CoreCrum *nearestonleft;

        I(!(*width)[index].iszero());

        StreamAddr spanend = (*origin)[index] + (*width)[index];

       CoreCrum *ptr = nearestonleft = father->leftSon();
        for (; ptr; ptr = ptr->rightBrother()) {
    ///////////////////////////////// FIXME
    //        StreamAddr sonstart = (*grasp)[index] + ptr->cdsp[index]; (addition of two addresses -- not legal!)
            StreamAddr sonstart = (*grasp)[index];
    ///////////////////////////////// FIXME

            if (sonstart > (*origin)[index] && ptr->cdsp[index] > nearestonleft->cdsp[index])
                nearestonleft = ptr;

            if (whereoncrum(ptr, grasp, &(*origin)[index], index) >= ONMYLEFTBORDER
            &&  whereoncrum(ptr, grasp, &spanend, index) <= ONMYRIGHTBORDER)

                return ptr;
        }

        return nearestonleft;
    }



    def makeroomonleftnd(self, dsp_offset, dsp_origin, dsp_grasp):
        self.prologuend(dsp_offset, dsp_grasp, NULL);

        for (i = 0; i < widsize(self.cenftype); ++i) {
            if ((*dsp_origin)[i] < (*dsp_grasp)[i]) {
                StreamAddr base = (*dsp_grasp)[i] - (*dsp_origin)[i];
                StreamAddr newdsp = (*dsp_origin)[i] - (*dsp_offset)[i];

                self.expandcrumleftward(&newdsp, &base, i);
                self.prologuend(dsp_offset, dsp_grasp, NULL);
            }
        }
    }


    def insertmorend(self, dsp_offset, dsp_origin, wid_width, Core2dBottomCrum::type2dbottomcruminfo *infoptr, int index):
        """
        """

        Displacer grasp;
        CoreCrum *ptr;

        if ((*wid_width)[index].iszero())
            gerror("zero width in insertmorend\n");

        self.makeroomonleftnd(dsp_offset, dsp_origin, &grasp)
        if self.height == 1:
            return self.insertcbcnd(&grasp, dsp_origin, wid_width, infoptr)

        # Insert in an uppercrum instead
        ptr = self.findsontoinsertundernd(&grasp, origin, width, index)
        temp = ptr.insertmorend(&grasp, origin, width, infoptr, index)

        self.setwispupwards()
        return temp


    def firstinsertionnd(self, dsp_origin, wid_width, Core2dBottomCrum::type2dbottomcruminfo *infoptr):
        """
        """

        son = self.leftSon()

        son.cdsp = dsp_origin
        son.cwid = wid_width

        ((Core2dBottomCrum *) son)->c2dinfo = *infoptr;
        self.setwisp()
	    

    def doinsertnd(self, dsp_origin, Widener *width, Core2dBottomCrum::type2dbottomcruminfo *infoptr, int index):
        if ((*width)[index].iszero())
            gerror("zero width in doinsertnd\n");

        if (((Enfilade *) self)->isEmpty()):
            self.firstinsertionnd(dsp_origin, width, infoptr)
            return None

        return self.insertmorend(Displacer(), dsp_origin, width, infoptr, index)


    # origin:: origin is vsa of crum; note that here they're wids,
    # width:: and in deletend they're single tumblers
    def Enfilade2d::insertnd(sess, Displacer *origin, Widener *width, Core2dBottomCrum::type2dbottomcruminfo *info, int index):
        oldheight = self.height

        if ((*width)[index].iszero())
            gerror("zero width in insertnd\n");

        oldwid = self.cwid.V_BASIS

        self.makegappm(origin, width) # Make a gap in the PM for the insertion
        checkspecandstringbefore()
        self.adjustWispUpwards()

        bothertorecombine = self.doinsertnd(origin, width, info, index)
        self.adjustWispUpwards()

        if bothertorecombine or height != oldheight:
            if not bothertorecombine:
                print "insertnd recombineing and notbothertorecombine"
            self.recombine()


    def findaddressofsecondcutforinsert(self, position):
        """ tumbler-operation: (only supports 2-digit positions)
            1.345 -> 2.345 -> 2 -> 2.1
        """

        intpart   = position[1] # Grab second digit

        secondcut = position.adjdigit(-1, 1)        # Bump next-to-last digit
        secondcut = secondcut.adjdigit(0, -intpart) # Bump last digit
        secondcut = secondcut.adjdigit(1, 1)        # Add a new last digit of 1

        return secondcut


    def whereoncrum(self, dsp_offset, addr):
        """
        """

        left = dsp_offset.V_BASIS + self.cdsp.V_BASIS
        if addr  < left:  return TOMYLEFT
        if addr == left:  return ONMYLEFTBORDER

        right = left + self.cwid.V_BASIS
        if addr  < right:  return THRUME
        if addr == right:  return ONMYRIGHTBORDER
        return TOMYRIGHT

    def crumiscut(self, dsp_offset, knives):
        """Is this CRUM being cut by the given set of knives?
        """

        for blade in knives:
            if self.whereoncrum(dsp_offset, blade) == THRUME:
                return 1
        return None

    def sonsarecut(self, dsp_offset, knives):
        """Are any of my sons being cut by the given set of knives?
        """

        grasp = dsp_offset + self.cdsp

        son = self.leftSon()
        while son:
            if son.crumiscut(grasp, knives):
                return 1

            son = son.rightBrother()
        return None

    def makecutsnd(self, knives):
        """Apply cuts from myself down in tree, until intersections between CRUMs
           are found (i.e. when none of my sons are being cut).
        """

        self.makecutsdownnd(Displacer(), knives)

        node = self.topmost()
        while node.sonsarecut(Displacer(), knives):
            node.makecutsdownnd(Displacer(), knives)
            node = node.topmost()

    def makecutsdownnd(self, dsp_offset, knives):
        """
        """

        node = self
        if len(knives) > 1:
            n = 0
	    son = node.leftSon()
            while son:
                if son.crumiscut(dsp_offset, knives):
                    n     += 1
                    sonptr = son

                son = son.rightBrother()

            if n == 1:
                dsp_offset += node.cdsp
                node        = sonptr
            else:
                break

        # Now we're at an intersection

        node.makecutsbackuptohere(dsp_offset, knives)

        if node.toomanysons():
            if node.isTopmost():
                node.levelpush()
            self.makecutsnd(knives) # and try again

        return dsp_offset

    def makecutsbackuptohere(CoreUpperCrum *ptr, dsp_offset, knives):

        # Handle case of bottom crum

        if ptr.height == 0:
            for blade in knives:
                if ptr.whereoncrum(dsp_offset, blade) == THRUME:
                    newcuc = ((Enfilade *) ptr)->createCrum((int) ptr->height, (int) ptr->cenftype);

                    if (ptr->cenftype == GRAN)
                        ((CoreBottomCrum *) newcuc)->cinfo.infotype = ((CoreBottomCrum *) ptr)->cinfo.infotype;

                    ptr.slicecbcpm(dsp_offset, newcuc, blade)
                    ptr.adjustWisp()
            return

        # Handle case of upper crum

        for (i = 0; i < knives->nblades; ++i) {
            ptr.cutsons(dsp_offset, knives)

            if not ptr.isTopmost():
                ptr.adjustWispUpwards()

                if ptr.crumiscutbyithknife(dsp_offset, knives, i):
                    son = ptr.leftSon()
                    while son:
                        nextson = son.rightBrother()

                        grasp = dsp_offset + ptr.cdsp
                        ptr.makeithcutonson(dsp_offset, son, grasp, knives, i)

                        if not ptr.crumiscutbyithknife(dsp_offset, knives, i):
                            if ptr.numberofsons == 0:
                                return
                            break

                        son = nextson

                ptr.adjustWispUpwards()

        if ptr.isTopmost():
            assert not ptr.toomanysons()
        else:
            if ptr.toomanysons():
                while ptr.toomanysons():
                    ptr.adjustWispUpwards()
                    ptr.peeloffcorrectson(knives)

                ptr.makecutsbackuptohere(dsp_offset, knives)

        ptr.adjustWispUpwards()

    def newfindintersectionnd(self, knives, CoreUpperCrum **ptrptr, Displacer *offset)
        """Given fullcrumptr & knives, sets *ptrptr & *offset to be cuc which contains all
           space between the cuts"""

        return self, Displacer()

    def setwidnd(self):
        """reset wid but leave dsp alone
        """

        son = self.leftSon()
        while son:
            newwid = max(Widener(), son.cwid, son.cenftype)
            son = son.rightBrother()

        if not self.cwid.isEqual(newwid, widsize(self.cenftype)):
            self.cwid = newwid

    def insertcutsectionnd(self, dsp_offset, knives):
        """
        """

        if len(knives) == 2:
            cmp = self.whereoncrum(dsp_offset, knives[1])
            if cmp == THRUME:
                return -1
            if cmp <= ONMYLEFTBORDER: # compare last to first
                return 2

        cmp = self.whereoncrum(dsp_offset, knives[0])
        if cmp == THRUME:
            return -1
        if cmp <= ONMYLEFTBORDER: # compare last to first
            return 1
        return 0

    def makegappm(self, origin, width):
        """Make a gap in the PM for an insertion
        """

        grasp, reach = self.cdsp, self.cdsp + self.cwid

        if self.cwid.V_BASIS == tumbler('0') \
        or origin.V_BASIS < grasp.V_BASIS    \
        or origin.V_BASIS < reach.V_BASIS:
            return  # this is for extensions to be without calling cut

        knives = [origin.V_BASIS, self.findaddressofsecondcutforinsert(origin.V_BASIS)]
        self.makecutsnd(knives)

        father, foffset = self.newfindintersectionnd(knives)
        fgrasp = foffset + father.cdsp

        ptr = father.leftSon()
        while ptr:
            i = ptr.insertcutsectionnd(fgrasp, knives)

            assert i != -1  #THRUME makegappm can't classify crum

            if i == 1:
                ptr.cdsp.V_BASIS += width.V_BASIS

            ptr = ptr.rightBrother()

        father.setwidnd()
        father.father().adjustWispUpwards()











    def __repr__(self):
        return "%s(#%s, %s)" % (self.__class__.__name__, self.id, self.title)

    def _prologuend(self, displaceroffset):
        """Sets grasp & reach from ptr & offset.
        """

        grasp = displaceroffset + self.cdsp
        reach = grasp  + self.cwid
        return grasp, reach

    def findnextaddressinvspace(self, offsetptr, nextvspacestartptr):
        """
            offsetptr is a Displacer
            nextvspacestartptr is a Tumbler
            vsaptr is a Tumbler
        """

        node = self.leftson
        if node is None:
            return

        maxt = tumbler('0')
        while node:
            grasp, reach = node._prologuend(offsetptr)
            if node.whereoncrum(offsetptr, nextvspacestartptr, V_BASIS) == THRUME:
                return node.findnextaddressinvspace(grasp, nextvspacestartptr)
            else:
                if grasp.V_BASIS > nextvspacestartptr and reach.V_BASIS > maxt:
                    maxt = reach.V_BASIS

            node = node.rightBrother()

        return maxt

    def findvsatoappend(self):
        """
        """

        vsaptr          = tumbler('0')
        linkspacevstart = tumbler('2') # 2.<linkid>

        grasp = self.cdsp
        reach = grasp + self.cwid

        print "grasp=%s, reach=%s" % (`grasp`, `reach`)

        if self.cwid.isEmpty() or grasp.V_BASIS < linkspacevstart:
            vsaptr = vsaptr.adjdigit(0, 1) # Bump to next ordinal in byte/link space
            vsaptr = vsaptr.adjdigit(1, 1) # Bump to 
        else:
            if reach.V_BASIS < linkspacevstart:
                vsaptr = reach.V_BASIS # no links in doc
            else:
                vsaptr = self.findnextaddressinvspace(grasp, linkspacevstart)

        return vsaptr

    def isEmpty(self):
        """  """
        if not self.isTopmost()
            return None

        return self.cwid.isEmpty(2) && self.cdsp.isEmpty(2)

#class EnfiladeSPAN(UpperCRUM):
#    """
#    /* wid and dsp indexes for pm */
#    #define I_BASIS  0
#    #define V_BASIS  1
#    """
#
#    def __init__(self, height=1, title=''):
#        UpperCRUM.__init__(self, height=height)
#        self.title = title
##        print "----> SPAN(id=%d)" % self.id
#        self.cdsp = Displacer()
#        self.cwid = Displacer()
#
#    # origin:: origin is vsa of crum; note that here they're wids,
#    # width:: and in deletend they're single tumblers
#    def insertnd(self, sess, Displacer *origin, Widener *width, Core2dBottomCrum::type2dbottomcruminfo *info, int index):
#        oldheight = self.height
#
#        if ((*width)[index].iszero())
#            gerror("zero width in insertnd\n");
#
#        oldwid = self.cwid.V_BASIS
#
#        bothertorecombine = self.doinsertnd(origin, width, info, index)
#        self.adjustWispUpwards()
#
#        if bothertorecombine or height != oldheight:
#            if not bothertorecombine:
#                print "insertnd recombineing and notbothertorecombine"
#            self.recombine()
#
#    def __repr__(self):
#        return "%s(#%s, %s)" % (self.__class__.__name__, self.id, self.title)

class EnfiladeNav:
    def __init__(self):
        self.width = tumbler()

    def __repr__(self):
        f_id = self.father()
        if f_id is not None:
            f_id = f_id.id

        lb_id = self.leftBrother()
        if lb_id is not None:
            lb_id = lb_id.id

        rb_id = self.rightBrother()
        if rb_id is not None:
            rb_id = rb_id.id

        if hasattr(self, 'leftson') and hasattr(self.leftson, 'id'):
            sn_id = self.leftson.id
        else:
            sn_id = None

        if hasattr(self, 'datum'):
            dtm = self.datum
        else:
            dtm = None

        if hasattr(self, 'numsons'):
            nsons = self.numsons
        else:
            nsons = None

        return "%s(#%d h=%d, f=%s, lbro=%s, rbro=%s, son=%s(#%s), wid=%s, dtm=%s)" % \
            (self.__class__.__name__, self.id, self.height, f_id, lb_id, rb_id, sn_id, nsons, `self.width`, `dtm`)

    def whereoncrum(self, offset, addr):
        n = intervalcmp(offset, offset + self.width, addr)
        print "Node# %d: %s in (%s .. %s) gives %d" % (self.id, addr, offset, offset + self.width, n)
        return n

    def seek(self, streamaddr, accum_disp=tumbler()):
#        print "Seek(accum_disp=%s, streamaddr=%s)" % (accum_disp, streamaddr)

        node = self
        while node.rightBrother():
            if streamaddr <= accum_disp or streamaddr < (accum_disp + node.width):
                break;
            accum_disp += node.width
            node = node.rightBrother()

        if node.height > 0: # not bottom level of tree...
            return node.leftson.seek(streamaddr, accum_disp)

        return NameSet(node=node, accum_disp=accum_disp, streamaddr=streamaddr)

    def find(self, streamaddr):
        # Walk From Me toward Rightmost Brother Seeking Next Step Downward
        return self.seek(streamaddr)

    def findPrevStreamAddr(self, upperbound, streamaddr):
        """Find the last tumbler address in use, below the upperbound"""

        print "Node# %d: findPrevStreamAddr(upperbound=%s, streamaddr=%s)" % (self.id, `upperbound`, `streamaddr`)
        if self.height == 0:
            print "bottom, returning lastBottomAddr"
            return self.lastBottomAddr(streamaddr)

        node = self.leftson
        while node:
            n = node.whereoncrum(streamaddr, upperbound)
            print "whereoncrum(streamaddr=%s, upperbound=%s) ==> %s" % (streamaddr, upperbound, n)
            if n == THRUME or n == ONMYRIGHTBORDER or node.rightBrother() is None:
                return node.findPrevStreamAddr(upperbound, streamaddr)
            else:
                streamaddr += node.width

            node = node.rightBrother()
        return streamaddr

    def lastBottomAddr(self, streamaddr):
        if hasattr(self, 'leftson') and isinstance(self.leftson, BottomCRUMtext):
            print "leftson, adjusting addr"
            return streamaddr.adjdigit(0, len(self.leftson) - 1)

        print "Node# %d: lastBottomAddr(%s) => %s" % (self.id, `streamaddr`, `streamaddr`)
        return streamaddr

    def walk(self, accum_disp=tumbler()):
        print "---- Height %d" % self.height

        old_disp = accum_disp

        # Walk All Brothers at *this* Level
        node = self
        while node:
            print "+%s: %s" % (`accum_disp`, node)
            accum_disp += node.width
            node = node.rightBrother()

        # Invoke a Walk on Each Son
        accum_disp = old_disp
        node = self
        while node:
            if hasattr(node, 'leftson'):
                node.leftson.walk(accum_disp)
                accum_disp += node.width
            node = node.rightBrother()

        return NameSet(accum_disp=accum_disp)


class BottomCRUM(CRUM, EnfiladeNav):
    def __init__(self, datum):
        CRUM.__init__(self, height=0)
        EnfiladeNav.__init__(self)
        self.datum = datum

class BottomCRUMtext(BottomCRUM):
    def __init__(self, text):
        BottomCRUM.__init__(self, text)

class BottomCRUMorgl(BottomCRUM):
    def __init__(self, orgl):
        BottomCRUM.__init__(self, orgl)


class Enfilade(UpperCRUM, EnfiladeNav):
    """One-dimensional enfilade, also called the Model-T enfilade.
    """

    def __init__(self, **kwargs):
        """  """
        UpperCRUM.__init__(self, **kwargs)
        EnfiladeNav.__init__(self)

    def addrExists(self, streamaddr):
        """  """
        return self.find(streamaddr).accum_disp == streamaddr
	
    def findAddrAtWhichToInsertNode(self, hint):
        """returns found-isa or None"""

        if not self.addrExists(hint.streamaddr):
            print "Address does NOT exist, using kluge..."
            return hint.streamaddr
#            return self.klugefindisatoinsertnonmolecule(hint)

        return self.findAddrToInsertNonMolecule(hint)

    def addrAtWhichToInsert(self, hint):
        """  """
        if not self.addrExists(hint.streamaddr):
            if hint.subtype != 'ATOM':
                return hint.streamaddr
#                return self.klugefindisatoinsertnonmolecule(hint)
            raise "Cannot add an atom without a document container"

        if hint.subtype == 'ATOM':  return self.findAddrToInsertMolecule(hint)
        else:                       return self.findAddrToInsertNonMolecule(hint)

    def klugefindisatoinsertnonmolecule(self, hint):
        """  """
        if hint.supertype == hint.subtype:  depth = 1
        else:                               depth = 2

        hintlength = len(hint.streamaddr)

        upperbound = hint.streamaddr.adjdigit(depth - 1, 1)
        lowerbound = tumbler('0')

        lowerbound = self.findPrevStreamAddr(upperbound, lowerbound)

        isaptr = lowerbound[:hintlength + depth]

        if len(isaptr) == hintlength:  isaptr = isaptr.adjdigit(depth, 1)
        else:                          isaptr = isaptr.adjdigit(0, 1)

        return isaptr

    def findAddrToInsertNonMolecule(self, hint):
        """  """
        if hint.supertype == hint.subtype:  depth = 1
        else:                               depth = 2

        hintlength = len(hint.streamaddr)

        upperbound = hint.streamaddr.adjdigit(depth - 1, 1)
        lowerbound = tumbler('0')

        lowerbound = self.findPrevStreamAddr(upperbound, lowerbound)

	print "findPrevStreamAddr() ==> %s" % `lowerbound`

        isaptr = lowerbound[:hintlength + depth]

        if len(isaptr) == hintlength:  isaptr = isaptr.adjdigit(depth, 1)
        else:                          isaptr = isaptr.adjdigit(0, 1)

        print "findAddrToInsertNonMolecule() ==> %s" % `isaptr`
        return isaptr

    def findAddrToInsertMolecule(self, hint):
        """  """
	incr = { 'NULLATOM': 0, 'TEXTATOM': 1, 'LINKATOM': 2 }

        upperbound = hint.streamaddr.adjdigit(2, incr[hint.atomtype] + 1)
        lowerbound = tumbler('0')

        lowerbound = self.findPrevStreamAddr(upperbound, lowerbound)

        if len(hint.streamaddr) == len(lowerbound):
            isaptr = lowerbound.adjdigit(2, incr[hint.atomtype])
            return isaptr.adjdigit(1, 1)

        if hint.atomtype == 'TEXTATOM':
            return lowerbound.adjdigit(0, 1)

        if hint.atomtype == 'LINKATOM':
            isaptr = hint.streamaddr.adjdigit(2, 2)
            if lowerbound < isaptr:
                return isaptr.adjdigit(1, 1)
            else:
                return lowerbound.adjdigit(0, 1)

        raise "Impossible condition in findAddrToInsertMolecule"

    def adjustWisp(self):
        """The WIDdative operation in general; returns boolean of whether the wisp was changed"""

        if self.height == 0:  # If distance from bottom of tree is zero,
            return None           # We don't operate on the bottom crums

        sum = tumbler()
	son = self.leftson
        while son: # Walk list of my immediate sons, summing widths acrossd them
            sum = sum + son.width
            son = son.rightBrother()

        if sum == self.width:
            return None

        self.width = sum
        return 1

    def adjustWispUpwards(self):
        """Walk up father chain adjusting the wisp until changes stop occurring; Returns boolean"""

        any_changes = None
        whilechanges = 1

        node = self
        while node and whilechanges:
            whilechanges = node.adjustWisp()
            if whilechanges:
                any_changes = 1
            node = node.father()

        return any_changes

    def remove(self, key):
        """  """
        pass # returns new root

    def inserttextgr(self, hint, text):
        """inserttextgr(hint, text) -> ispan
	   Insert a piece of text into the 1-D enfilade (Grande)"""

        # Identify an IStreamAddr at which to Insert the New DocBytes
        lsa = self.addrAtWhichToInsert(hint)
        print "addrAtWhichToInsert() returned %s" % `lsa`
        if lsa is None:
            raise ValueError, "Unable to insert text"

        spanorigin = lsa  # Origin of New Span of DocBytes

	while text: # For Each Piece of the DocBytes Sequence
            piece, text = text[:4], text[4:]
            self.insert(lsa, piece)
            lsa = lsa.adjdigit(0, len(piece)) # Increment to the Place to Put the Next Piece of the DocBytes

        # Return a Memory-Resident Tracking Object (ISpan) that is Tied to the new DocBytes
        return NameSet(itemid='ISPANID', stream=spanorigin, width=lsa-spanorigin)

    def insert(self, address, datum):
        """insert(istreamaddr, datum) -> None
           Insert a (piece of text|POOM tree) at the specified IStream address"""

        context  = self.find(address) # Place Finger into IStream
        inspoint = context.node
        offset   = context.accum_disp
        del context

        print "inspoint: ", `inspoint`
        print "offset: ", `offset`

	print "inspoint.father: ", `inspoint.father()`

        if type(datum) == type(""):  new = BottomCRUMtext(datum)
        else:                        new = BottomCRUMorgl(datum)

        inspoint.adoptAsRightBrother(new)

	print "new.father: ", `new.father()`

        any_splits = new.father().splitUpwards()

        if inspoint.width == tumbler('0'): # appending to last crum, then put it just before the 0-width sentinel
            new.width       = tumbler('0')
            inspoint.width  = address - offset
        else:
            reach           = offset + inspoint.width
            new.width       = reach - address
            inspoint.width  = address - offset

        inspoint.father().adjustWispUpwards()
        new.father().adjustWispUpwards()

        if inspoint.father().splitUpwards():
            any_splits = 1

        if any_splits:
            self.recombine()

class GrandeEnfilade(Enfilade):
    """The Grande Enfilade is the overarching organizing element in the Docuverse."""

    def __init__(self, **kwargs):
        Enfilade.__init__(self, **kwargs)

    def createDataServer(self, server_id):
        """Declare that server_id is a legal dataserver node. If server_id
           is a node tumbler, then the backend reassigns its own address
           to id-account.
        """

        hint = NameSet(supertype='NODE', subtype='NODE', atomtype=0, streamaddr=server_id)
        istreamaddr = self.findAddrAtWhichToInsertNode(hint)
        if istreamaddr is None:
            raise ValueError, "Invalid dataserver address: " + `server_id`

        print "%s => %s" % (`server_id`, `istreamaddr`)
        self.insert(istreamaddr, EnfiladePOOM(title="Server[%s]" % server_id));
        return istreamaddr

    def createAccount(self, acct_id):
        """Declare that acct_id is a legal account. If acct_i is an account
           tumbler, then the backend creates the account.
        """

        hint = NameSet(supertype='NODE', subtype='NODE', atomtype=0, streamaddr=acct_id)
        istreamaddr = self.findAddrAtWhichToInsertNode(hint)
        if istreamaddr is None:
            raise ValueError, "Invalid account address: " + `acct_id`

        print "%s => %s" % (`acct_id`, `istreamaddr`)
        self.insert(istreamaddr, EnfiladePOOM(title="Acct[%s]" % acct_id))
        return istreamaddr

    def createDocument(self, acct_id=tumbler('1.1.0.1')):
        """Create a new document under the account and node of the user who
           issued the request.  Return the global identifier for the document.
           This request creates the document but does not open it for access;
           you must issue an open request to access the data in the new document.
        """
	
        hint = NameSet(supertype='ACCOUNT', subtype='DOCUMENT', atomtype=0, streamaddr=acct_id)
        istreamaddr = self.addrAtWhichToInsert(hint)

        print "addrAtWhichToInsert() returned %s" % `istreamaddr`

        if istreamaddr is None:
            raise ValueError, "Unable to create doc"

        self.insert(istreamaddr, EnfiladePOOM(title="Doc[]"))
        return istreamaddr

    def doappend(self, docisa, text): # Granf Method
        """  """
        return self.appendpm(docisa, text)

    def appendpm(self, docisa, text): # Granf Method
        """  """
        orgl = self.findorgl(docisa, WRITEBERT)
        if orgl is None:
            return None

        vsa = orgl.findvsatoappend()

        return self.doinsert(docisa, vsa, text)

    def doinsert(self, docisa, vsa, text):
        """doinsert(docisa, vsa, text) -> boolean
           Insert a piece of text into the xanalogical storage system."""

        hint = NameSet(supertype='DOCUMENT', subtype='ATOM', atomtype='TEXTATOM', streamaddr=docisa)

        # Insert the Text into the Grande Enfilade's Invariant-Stream
        ispan = self.inserttextgr(hint, text) # Appends it to next available space in IStream
        if ispan: # And map it, via a POOM, into the document's vstream at the requested point (vsa)
            return self.docopy(docisa, vsa, (ispan, ))
        return None

    def docopy(self, docisa, vsa, specset):
        """docopy(docisa, vsa, specset) -> boolean
           Map, via a POOM, a piece of istream into someone's vstream"""

        ispanset = specset2ispanset(specset, NOBERTREQUIRED)
        if ispanset:
            docorgl = self.findorgl(docisa, WRITEBERT)
            if docorgl:
                if insertpm(docisa, docorgl, vsa, (typesporglitem *) ispanset):
                    return spanf.insertspanf(docisa, ispanset, DOCISPAN) <---------------------------------------
        return None



    def insertpm(self, orglisa, orgl, vsa, sporglset):
        """insertpm(orglisa, orgl, vsa, sporglset) -> boolean"""

        if vsa == tumbler('0') or vsa < tumbler('0'):
            raise "Invalid VSA"
	    
        for sporgl in sporglset:
            lstream, lwidth, linfo = unpacksporgl(sporgl)   <----------------------------------------------------

            crumorigin = Displacer(ibasis=lstream, vbasis=vsa)
            crumwidth  = Widener(ibasis=lwidth)

            shift = len(vsa) - 1
            inc   = lwidth[0]

            crumwidth.V_BASIS = tumbler('0').adjdigit(shift, inc)
            assert crumwidth.V_BASIS != tumbler('0')

            orgl2d.insertnd(crumorigin, crumwidth, linfo, V_BASIS)  <--------------------------------------------
            vsa += crumwidth.V_BASIS

        return 1







    def findorgl(self, isa, acctype): #BERT
        """findorgl(isa, acctype) -> orgl"""

        # if (checkforopen(isa, acctype, user) <= 0)
        #     raise "Not open!"

        return self.fetchorglgr(isa)

    def fetchorglgr(self, address):
        """fetchorglgr(istreamaddr) -> ORGL"""

        if self.width < address:
            return None

        context  = self.find(address) # Place Finger into IStream
        if context is None:
            return None

        if context.accum_disp != address:
            return None

        return context.node.datum

def specset2ispanset(specset, acctype):
    """specset2ispanset(specset, settype) -> ispanset or None
       specset is a tuple of: NameSet(itemid='ISPANID', stream=XXX, width=XXX)
    """

    ispanset = []
    for spec in specset:
        if spec.itemid == 'ISPANID': # Just copy any ISPANs into result
            ispanset.append(spec)

        else:
            assert notimplementedyet
#            if spec.itemid == 'VSPECID':
#                typevspec *vspec = (typevspec *) specset;
#
#                if (vspec->docisa.iszero())
#                    qerror("retrieve called with docisa 0\n");
#
#                if (!(granf.findorgl(&((typevspec *) specset)->docisa, &docorgl, acctype) /*BERT*/
#                && (ispansetptr = vspanset2ispanset(docorgl, ((typevspec *) specset)->vspanset, ispansetptr))))
#                    return false; /*zzzz*/
    return tuple(ispanset)


# 
# To create a new node in the Grand Enfilade, use:
# 
# First we must identify an address within the InvariantStream to assign to the new node:
# 
#     if (!findisatoinsertgr((CoreUpperCrum *) fullcrumptr, hintptr, isaptr))
# 
# If that succeeds, we fill in a 'typegranbottomcruminfo' structure:
# 
#     typegranbottomcruminfo locinfo;
#     locinfo.infotype                    = GRANORGL;
# 
#     locinfo.granstuff.orglstuff.orglptr = createenf(POOM);
#     locinfo.granstuff.orglstuff.orglptr->reserve();
# 
#     locinfo.granstuff.orglstuff.orglincore = true;
#     locinfo.granstuff.orglstuff.diskorglptr.diskblocknumber = NULLBLOCKNO;
#     locinfo.granstuff.orglstuff.diskorglptr.insidediskblocknumber = 0;
# 
#     insertseq((CoreUpperCrum *) full_granf_crumptr, isaptr, &locinfo);
# 
#     locinfo.granstuff.orglstuff.orglptr->rejuvinate();
# 
# The insertseq() function is used to insert both DocBytes and new nodes into the enfilade.
# 
# 
# Enfilade Functions:
#     // Look up an IStreamAddr in the GrandEnfilade to See If It is Already In-Use
#     typecontext *context = retrieve(crumptr, isaptr,  WIDTH);
# 
# 
# Hint objects are only used within the Grand Enfilade class.
# 
# 
# The enfilade uses the same CoreUpperCrum for each style, but
# a different CoreBottomCrum to hold the actual data.
# 
# // infotype
# #define GRANNULL        0
# #define GRANTEXT        1
# #define GRANORGL        2
# #define GRANCLEARLYILLEGALINFO 42
# 
# Grande Enfilade is a one-dimensional mapping of XXX to XXX.
# It is not bidirectional.  It stores two types of objects:
# a string or the root node of a 2d-enfilade.  There are NO
# gaps in the single dimension, so the position of any item
# is equal to the sum of the lengths of any previous items.
# 
# Key:
# 
# Datum:
#     length of displacement represented by this node and below
# 
#     (block of text)
#     -or-
#     (root node of a 2d-enfilade tree)
# 
# Node: (immutable)
#   Height (=1 if a leaf node; then contains a field LeafElems (small array of sequence elements)
#           !1 nonleaf node; then contains a field NonleafElems (small array of records)
# 	        record is:  (width, ptr-to-subtree)
# 
# An empty enfilade consists of two nodes:
#     nonleaf (root):
#         CoreUpperCrum *fullcrumptr = createcrum(1, enftype);
#         fullcrumptr->cenftype   = enftype;
#         fullcrumptr->isapex     = true;
#         fullcrumptr->isleftmost = true;
# 
#     leaf:
#         CoreCrum *ptr = createcrum(0, enftype);
#         fullcrumptr->adoptAsLeftmostSon(ptr);
# 
# context = IStream.seek(iaddr)     seek a point
# 
# Insertion of Text:
#     // Identify an IStreamAddr at which to Insert the New DocBytes
#     IStreamAddr lsa;
#     if (!fullcrumptr->findAddrToInsertAt(hintptr, &lsa))
#         return false; // Error: No Acceptable IStreamAddr was Found
# 
#     IStreamAddr spanorigin = lsa; // Origin of New Span of DocBytes
# 
# ==Leaf Node==
# class CoreBottomCrum : public CoreCrum {
#     int              infotype;
# 
#     ==Text Leaf Node==
#     struct typegrantext {
#         char      textstring[GRANTEXTLENGTH];
#         unsigned  textlength;
#     } textstuff; 
# 
#     ==Nontext Leaf Node==
#     struct typegranorgl {
#         CoreUpperCrum   *orglptr;
#         DiskLoafAddr     diskorglptr;
#         bool             orglincore;
#     } orglstuff;

e = GrandeEnfilade(height=1, isroot=1, isleftmost=1)
e.adoptAsLeftmostSon(BottomCRUMorgl(EnfiladePOOM(title='NULL')))


x = e.createDataServer(tumbler('1'))
print "Initial One: ", `x`, '='*50

x = e.createDataServer(tumbler('1.1'))
print "New Server: ", `x`, '='*50

x = e.createAccount(tumbler('1.1.0.1'))
print "New Account: ", `x`, '='*50

print "\n---Dump of Enfilade"
e.walk()

x = e.createDocument(acct_id=tumbler('1.1.0.1'))
print "New Document: ", `x`, '='*50

print "\n---Dump of Enfilade"
e.walk()

x = e.createDocument(acct_id=tumbler('1.1.0.1'))
print "New Document: ", `x`, '='*50

x = e.createDocument(acct_id=tumbler('1.1.0.1'))
print "New Document: ", `x`, '='*50

e.doappend(x, "This is a test")
e.doappend(x, "ABCDEFGHIJKLMNOPQRSTUVWXYZ")




#o = e.findorgl(x, WRITEBERT)
#print "ORGL to Write into is: ", o
#
#vsa = o.findvsatoappend()
#print "VSA to Append: ", vsa
#
#hint = NameSet(supertype='DOCUMENT', subtype='ATOM', atomtype='TEXTATOM', streamaddr=x)
#
#ispan = e.inserttextgr(hint, "This is a test")
#print "ISpan=%s", `ispan.__dict__`






    def unpacksporgl(sporgl)
        class Type2dBottomCrumInfo:
            pass
        info = Type2dBottomCrumInfo()

        if sporgl.itemid == 'ISPANID':
            stream       = sporgl.stream
            width        = sporgl.width
            info.homedoc = tumbler('0')

        elif sporgl.itemid == 'SPORGLID':
            stream       = sporgl.sporglorigin
            width        = sporgl.sporglwidth
            info.homedoc = sporgl.sporgladdress

        else:
            raise "Invalid itemid"

        if width == tumbler('0'):
            raise "zero width"

        return stream, width, info




#e.createDataServer(tumbler('1.2'))
#e.createAccount(tumbler('1.2.0.1'))

#isaptr = tumbler('1.1')
#isaptr = e.findAddrAtWhichToInsertNode( NameSet(supertype='NODE', subtype='NODE', atomtype=0, streamaddr=isaptr) )
#print "TumblerAddress at which to insert %s is %s" % (`tumbler('1.1')`, `isaptr`)

#print "\n---Inserting empty enfilade at address:", `isaptr`
#e.insert(isaptr, EnfiladePOOM(height=0))
#e.insert(isaptr, "hello")

#e.insert(tumbler('1.1'), "hello")

#e.insert(tumbler('1.1'), EnfiladePOOM(title='1.1'))
#e.insert(tumbler('1.2'), EnfiladePOOM(title='1.2'))
#e.insert(tumbler('1.3'), EnfiladePOOM(title='1.3'))
#
#print
#print "*" * 70
#e.insert(tumbler('1.4'), EnfiladePOOM(title='1.4'))
#e.insert(tumbler('1.5'), EnfiladePOOM(title='1.5'))
#e.insert(tumbler('1.6'), EnfiladePOOM(title='1.6'))
#e.insert(tumbler('1.7'), EnfiladePOOM(title='1.7'))
#e.insert(tumbler('1.8'), EnfiladePOOM(title='1.8'))
#e.insert(tumbler('1.9'), EnfiladePOOM(title='1.9'))

#e.insert(tumbler('2.1'), EnfiladePOOM(title='2.1'))
#e.insert(tumbler('2.2'), EnfiladePOOM(title='2.2'))
#e.insert(tumbler('2.3'), EnfiladePOOM(title='2.3'))
#e.insert(tumbler('2.4'), EnfiladePOOM(title='2.4'))
#e.insert(tumbler('2.5'), EnfiladePOOM(title='2.5'))
#e.insert(tumbler('2.6'), EnfiladePOOM(title='2.6'))
#e.insert(tumbler('2.7'), EnfiladePOOM(title='2.7'))
#e.insert(tumbler('2.8'), EnfiladePOOM(title='2.8'))
#e.insert(tumbler('2.9'), EnfiladePOOM(title='2.9'))


#print "\n---Does 1.2 exist?"
#print e.addrExists(tumbler('1.2'))

print "\n---Dump of Enfilade"
e.walk()




#print e.find(tumbler('1'))
#
#print e.addrExists(tumbler('0'))
#print e.addrExists(tumbler('1'))
#print e.addrExists(tumbler('2'))


# Create Node Address for Node #1
#print "Node: ", e.addrAtWhichToInsert( NameSet(supertype='NODE', subtype='NODE', atomtype='NULLATOM', streamaddr=tumbler('1.1')))

# Create UserAccount Address for User #1
#print "User: ", e.addrAtWhichToInsert( NameSet(supertype='NODE', subtype='NODE', atomtype='NULLATOM', streamaddr=tumbler('1.1.0.1')))

# Create New Document Address for Document #1
#print " Doc: ", e.addrAtWhichToInsert( NameSet(supertype='ACCOUNT', subtype='DOCUMENT', atomtype='NULLATOM', streamaddr=tumbler('1.1.0.1.0.1')))



#print "Node: ", CreateNode(e, (), tumbler('1.1'))

