from types import SliceType
from widdsp import myWID, myDSP
from __future__ import generators

#class MyEnfilade(Enfilade):
#    CRUM_type = MyBottomCRUM
#    DSP_type  = MyBottomCRUM.DSP_type
#    WID_type  = MyBottomCRUM.WID_type

"""
Properties:
  1. nodes are immutable, changes to a node result in a new node.
  2. since nodes are immutable, they are initially created in the size desired.

"""

class Node:
    """An object of an immutable sequence type cannot change once it is created.
       (If the object contains references to other objects, these other objects
       may be mutable and may be changed; however, the collection of objects
       directly referenced by an immutable object cannot change.)"""

    def __init__(self, wids=(), vals=(None, )):
        "wids are widths _into_ the node, not displacements into the tree itself."
        self.wids, self.vals = wids, vals

#__iter__(self) 
#     This method is called when an iterator is required for a container. This method should return a new iterator object that can iterate over all the objects in the container. For mappings, it should iterate over the keys
#     of the container, and should also be made available as the method iterkeys(). 
#
#     Iterator objects also need to implement this method; they are required to return themselves. For more information on iterator objects, see ``Iterator Types'' in the Python Library Reference. 

    def seek(self, sought_disp, accum_disp=None):
        """seek(sought_disp, accum_disp=None) -> (accum_disp, node)
           Walk from my position in the tree down and toward the right seeking a particular displacement.
	   return the place in the tree at or before the specified displacement, i.e. where you would insert that displacement."""

        accum_disp = accum_disp or self.DSP_type() # Default Displacement of 'zero'

        earlyexit = 0
        for slotno in xrange(len(self.wids)): # Walk _across_ tree until correct displacement
            # Try subsequence from (accum_disp, accum_disp + width)
            if sought_disp <= accum_disp or sought_disp < (accum_disp + self.wids[slotno]):
                earlyexit = 1; break
            accum_disp += self.wids[slotno]
        if not earlyexit:  slotno = len(self.wids)

        if self.height:  return self.vals[slotno].seek(sought_disp, accum_disp)
        else:            return accum_disp, self, slotno

    def __contains__(self, dsp):
        accum_disp, node, slotno = self.seek(dsp)
        return accum_disp == dsp

    def keys(self):
        """Generator: return the set of displacements currently defined within the enfilade"""

        for accum_disp, node, slotno in self.walkleaves():
            yield accum_disp

    def values(self):
        """Generator: return the set of elements currently hanging off the enfilade"""

        for accum_disp, node, slotno in self.walkleaves():
            yield node.vals[slotno]

    def items(self):
        """Generator: return the set of (displacements, elements) within the enfilade"""

        for accum_disp, node, slotno in self.walkleaves():
            yield accum_disp, node.vals[slotno]

    def __getitem__(self, dsp):
        if type(dsp) == SliceType:
            accum_disp, node, slotno = self.seek(dsp.start)
        else:
            accum_disp, node, slotno = self.seek(dsp)
        return node.vals[slotno]

    def insert(self, ins_disp, datum):
        """insert(ins_disp, datum) -> <newtree>
           Insert an element at the specified displacement"""

        accum_disp, node, slotno = self.seek(dsp)
        if accum_disp == dsp: # Already in tree, replace it
            #Dup node and replace-in-place the datum for the displacement
            #Ascend upward and splice new node into copies of parents

            newroot = self
        else: # Not in tree, add it
            newroot = self

        return newroot

#    def insert(self, ins_disp, datum):
#
#        # Walk to bottom of tree to find where to insert the new element.
#        prev_disp, prev_node = self.seek(ins_disp)
#
#        ins_node = self.CRUM_type(datum)
#        prev_node.adoptAsRightBrother(ins_node)
#
#        any_splits = ins_node.father.splitUpwards()
#
#        if prev_node.width == self.WID_type(): # appending to last crum, then put it just before the 0-width sentinel
#            print "---------- Appending to Enfilade Sequence ----------"
#
#            ins_node.width = self.WID_type() # Width of 'zero'
#            print "width of that which we are inserting is", `ins_node.width`
#	    print "abs disp at which we are inserting it is", `ins_disp`
#	    print "my brother's abs disp is", `prev_disp`
#
#            prev_node.width  = ins_disp - prev_disp
#            print "after insertion, my brother's new width is", `prev_node.width`
#
#        else:
#            print "---------- Inserting into Enfilade Sequence ----------"
#
#            reach           = prev_disp + prev_node.width
#            ins_node.width       = reach - ins_disp
#            print "Z insert ins_node.width is a", `ins_node.width`
#
#            prev_node.width  = ins_disp - prev_disp
#            print "Z insert prev_node.width is a", `prev_node.width`
#
#        prev_node.father.adjustWispUpwards()
#        ins_node.father.adjustWispUpwards()
#
#        if prev_node.father.splitUpwards():
#            any_splits = 1
#
#        if any_splits:
#            self.recombine()
#
#        return self # Return root of modified tree

class Leaf(Node):
    height = 0

    def walkleaves(self, accum_disp=None):
        """Generator: a left-to-right bottom-walk of the tree."""

        accum_disp = accum_disp or self.DSP_type() # Default Displacement of 'zero'
        for slotno in xrange(len(self.vals)):
            yield accum_disp, self, slotno
            if slotno < len(self.wids):
                accum_disp += self.wids[slotno]

class Nonleaf(Node):
    def __init__(self, height, wids=(), vals=(None, )):
        Node.__init__(self, wids, vals)
        self.height = height

    def walkleaves(self, accum_disp=None):
        """Generator: a left-to-right bottom-walk of the tree."""

        accum_disp = accum_disp or self.DSP_type() # Default Displacement of 'zero'

        for slotno in xrange(len(self.vals)):
            for x in self.vals[slotno].walkleaves(accum_disp):
                yield x
            if slotno < len(self.wids):
                accum_disp += self.wids[slotno]

class TestLeaf(Leaf):
    DSP_type, WID_type = myDSP, myWID

class TestNonleaf(Nonleaf):
    LEAF_type = TestLeaf
    DSP_type  = TestLeaf.DSP_type
    WID_type  = TestLeaf.WID_type

n3 = TestLeaf(wids=(myWID(5),), vals=('01234', '56'))
n2 = TestLeaf(wids=(myWID(3), myWID(4)), vals=('789', 'ABCD', 'EF'))
n1 = TestNonleaf(height=1, wids=(myWID(7),), vals=(n3, n2))
# 0..4 -> None
# 5..6 -> '56'
# 7..9 -> '789'
# A..D -> 'ABCD'
# E..F -> 'EF'

# seq[dsp,wid] = datum
# seq[5] = '56'
# seq[7] = '789'

#n = 6
#accum_disp, i, node = n1.seek(myDSP(n))
#print "Found DSP %d in Node %s at Slot %d, Accum DSP of %s" % (n, node, i, accum_disp)


for n in range(0, 16):
    accum_disp, node, slotno = n1.seek(myDSP(n))
    print "Found DSP %d in Node %s at Slot %d, Accum DSP of %s, Datum %s" % (n, node, slotno, accum_disp, `node.vals[slotno]`)

print myDSP(6) in n1

print n1[ myDSP(n):myDSP(n):myDSP(n) ]

#e = Leaf()
#e.insert(myDSP(1), "DataAt_1")

for w in n1.items():
    print w


