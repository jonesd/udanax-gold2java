# Iterators: over my immediate sons; from me up to my fathers

from __future__ import generators

global CRUM_ID
CRUM_ID = 1

class CRUM:
    """has no pointers downward, only side-to-side and upwards;
       no tumbler stuff in here, just std tree stuff"""

    def __init__(self, height=0, isroot=None, isleftmost=None):
        self.isroot          = isroot
        self.height          = height
        self.isleftmost      = isleftmost
        self.rightbro        = None         # Reference to next-brother to my right
        self.leftbroorfather = None
        self.id              = CRUM_ID

        global CRUM_ID
        CRUM_ID += 1

    # === Navigational Accessors ===

    def _get_father(self):
        """father() -> /my father node/"""
        return self.leftmostBrother().leftbroorfather
    father = property(_get_father)

    def weakFather(self):
        if self.isroot:
            return None

        node = self
        while node and not node.isleftmost:
            node = node.leftbroorfather

        if node:  return node.leftbroorfather
        else:     return None

    def leftBrother(self):
        """leftBrother() -> /sibling node to my immediate left, or None/"""
        if self.isleftmost:
            return None
        return self.leftbroorfather

    def rightpeers(self):
        """Generator: Return myself and then my brother nodes located to my right"""

        node = self
        while node:
            yield node
            node = node.rightBrother()

    def rightBrother(self):
        """rightBrother() -> /sibling node to my immediate right, or None/"""
        return self.rightbro

    def leftmostBrother(self):
        """leftmostBrother() -> /sibling node to my farthest left, including myself/"""
        node = self
        while node.leftBrother():
            node = node.leftBrother()
        return node

    def rightmostBrother(self):
        """rightmostBrother() -> /sibling node to my farthest right, including myself/"""
        node = self
        while node.rightBrother():
            node = node.rightBrother()
        return node

    def topmost(self):
        node = self
        while not node.isroot:
            node = node.father

    # === Affiliation Effectors ===

    def adoptAsRightBrother(self, newcrum):
        print "adoptAsRightBrother in CRUM"

        assert newcrum is not None
        assert newcrum != self
        assert newcrum.height == self.height

        left   = self
        father = left.father
        right  = left.rightBrother()

        assert father is not None
        assert father.height == newcrum.height + 1

        left.rightbro           = newcrum
        newcrum.leftbroorfather = left
        newcrum.isleftmost      = None
        newcrum.rightbro        = right

        if right:
            right.leftbroorfather = newcrum
            right.isleftmost      = None

        self.father.numsons += 1

    def disown(self):
        """  """

        father = self.weakFather()
        assert father is not None

        right = self.rightBrother()
        father.numsons -= 1

        if self.isleftmost:
            father.leftson = right
            if right:
                right.leftbroorfather = father
                right.isleftmost      = 1
        else:
            left = self.leftBrother()
            left.rightbro = right
            if right:
                right.leftbroorfather = left

        self.leftbroorfather = self.rightbro = None

class UpperCRUM(CRUM):
    """has downpointers and comprehends sons; but has no
       width/dsp; no tumbler stuff in here"""

    MAX_SONS = 4

    def __init__(self, **kwargs):
        assert kwargs.has_key('height') and kwargs['height'] > 0
        CRUM.__init__(self, **kwargs)
        self.leftson = None
        self.numsons = 0

    # === Navigational Accessors ===

    def rightmostSon(self):
        """  """
        return self.leftson.rightmostBrother()

    # === Affiliation Effectors ===

    def adoptAsLeftmostSon(self, newcrum):
        """  """

        assert newcrum is not None
        assert newcrum != self

        father = self
        left   = None
        right  = father.leftson

        assert father is not None
        assert father.height == newcrum.height + 1

        father.leftson          = newcrum
        newcrum.leftbroorfather = father
        newcrum.isleftmost      = 1

        newcrum.rightbro = right
        if right:
            right.leftbroorfather = newcrum
            right.isleftmost      = None

        self.numsons += 1

    def adoptAsRightmostSon(self, newcrum):
        """  """

        assert newcrum is not None
        assert newcrum != self
        assert newcrum.father is None
        assert self.height == newcrum.height + 1

        father = self
        if father.leftson:
            left = father.rightmostSon();
        else:
            left = None

        right = None

        assert father.height == newcrum.height + 1

        if left:
            left.rightbro           = newcrum
            newcrum.leftbroorfather = left
            newcrum.isleftmost      = None
        else:
            father.leftson          = newcrum
            newcrum.leftbroorfather = father
            newcrum.isleftmost      = 1

        newcrum.rightbro = right
        if right:
            right.leftbroorfather = newcrum
            right.isleftmost      = None

        self.numsons += 1

    def _moveTo(self, to):
        """(private)"""

        assert self != to

        ptr                 = self.leftson
        numsons             = self.numsons
        self.numsons        = 0
        to.numsons          = numsons
        ptr.leftbroorfather = to
        to.leftson          = ptr
        self.leftson        = None

    def _levelpush(self):
        """(private)
        Relocate the contents of the root crum into a new crum and then make
        the new crum a son of the now-empty root crum.
	"""

        assert self.isroot # Insure this is indeed the root crum

        print "levelpush of node# %d" % self.id

        newcrum = self.__class__(height=self.height, isleftmost=1)
        print "push creates new node# %d" % newcrum.id

        self._moveTo(newcrum)
        self.height += 1

        self.adoptAsLeftmostSon(newcrum)
        newcrum.adjustWispUpwards()

    def _levelpull(self):
        """(private)
        Relocate the contents of my left son into myself, then delete the left son.
        """

        assert self.isroot

        print "levelpull"

        if self.numsons > 1:
            return # Cannot pull up to root if root has more than a single son

        if self.height <= 1:
            return # Prevent reduction of enfilade to less than one non-leaf and one leaf node

        oldcrum = self.leftson

        oldcrum.disown()
        self.height -= 1

        oldcrum._moveTo(self)
        self.adjustWispUpwards()

    def _split(self):
        """(private)"""

        print "_split on Node# %d" % self.id

        newbro = self.__class__(height=self.height)
        print "newbro for split is node# %d" % newbro.id

        self.adoptAsRightBrother(newbro)

        son = self.rightmostSon()
        for i in range(self.numsons/2):
            if son is None:
                break
            next = son.leftBrother()
            son.disown()
            newbro.adoptAsLeftmostSon(son)
            son = next

        self.adjustWispUpwards()
        newbro.adjustWispUpwards()

    def splitUpwards(self):
        """Returns boolean indicating whether a split occurred"""

        print "Node# %d, splitUpwards.numsons=%d" % (self.id, self.numsons)

        node = self
        assert node.height > 0   # Must not try to split a bottom crum

        anysplits = None
        while node.numsons > UpperCRUM.MAX_SONS:
            print "Node# %d has too many sons (%d)" % (node.id, node.numsons)

            if node.father is None:
                node._levelpush()
                node.leftson._split()
                return 1

            node._split()
            anysplits = 1
            node = node.father

        return anysplits

    def recombine(self):
        """  """

        print "recombine"

        if self.height < 3 or self.numsons >= UpperCRUM.MAX_SONS:
            return

        node = self.leftson
        while node:
            node.recombine()
            node = node.rightBrother()

        node = self.leftson
        while node and node.rightBrother():
            if node.leftson and node.numsons < UpperCRUM.MAX_SONS:
                if node.rightBrother().leftson:
                    if node.numsons + node.rightBrother().numsons < UpperCRUM.MAX_SONS:
                        node.eatbrossubtreeseq()
                    else:
                        node.takeovernephewsseq()
                    break
            node = node.rightBrother()

        if self.father is None:
            self._levelpull()

    def takeovernephewsseq(self):
        """  """

        node = self.rightBrother().leftson
        while node and self.numsons < UpperCRUM.MAX_SONS:
            next = node.rightBrother()
            node.disown()
            self.adoptAsRightmostSon(node)
            node = next

        self.rightBrother().adjustWispUpwards()
        self.adjustWispUpwards()

    def eatbrossubtreeseq(self):
        """  """

        bro = self.rightBrother()
        bro.leftson.leftbroorfather = self.leftson.rightmostBrother()

        self.leftson.rightmostBrother().rightbro = bro.leftson
        bro.leftson.isleftmost = None

        self.numsons += bro.numsons
        bro.disown()
        self.adjustWispUpwards()

