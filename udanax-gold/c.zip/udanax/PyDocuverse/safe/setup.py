from distutils.core import setup, Extension

setup(name = "tumbler", version = "1.0",
    ext_modules = [Extension("tumbler", ["tumblermodule.c"])])
