 /**
 * @file  tumblermodule.c
 * @brief Memory-Resident Tumbler Objects
 *
 **/

static char tumbler__doc__ [] = "\
There are two basic flavors of tumbler: address tumblers and\n\
difference tumblers.  The former represent a specific\n\
zero-dimensional point along the tumbler number line and the\n\
latter represent a span or segment along the number line.\n\
\n\
However, difference tumblers don't represent a count of anything.\n\
They don't mean some N characters, N bytes or N paragraphs.  Because\n\
of this they have no meaning in isolation but only when paired with\n\
an address tumbler.  This (address, difference) tuple is called a span.";

#include <Python.h>
#include <ctype.h>

#define NPLACES 11
enum { LESSER=-1, EQUAL=0, GREATER=+1 };

#ifdef DIGITS_LONGLONG
    typedef unsigned long long  digit;
    #define strtodigit  strtoull
#else
    typedef unsigned long       digit;
    #define strtodigit  strtoul
#endif

#define Tumbler_Check(op) ((op)->ob_type == &tumbler_TumblerType)

// A little syntactic glue...
#define UNLESS(E)    if(!(E))
#define RETURN_NONE  Py_INCREF(Py_None); return Py_None

staticforward PyTypeObject tumbler_TumblerType;

typedef struct {
    PyObject_HEAD
    char    negsign;          // 1 if negative, otherwise 0
    short   exp;
    short   numdigits;
    digit   mantissa[NPLACES];
} tumbler_TumblerObject;


/* Standard Constants */

tumbler_TumblerObject ZeroTumbler = {
    PyObject_HEAD_INIT(&tumbler_TumblerType)
    0,
    0,
    0,
};

    static tumbler_TumblerObject *
tumbler_validate(tumbler_TumblerObject *self)
{
    int i;

    if (self->exp > 0) {
        PyErr_SetString(PyExc_OverflowError, "invalid exponent (>0)");
        PyMem_DEL(self);
        return NULL;
    }

    if (self->negsign && self->mantissa[0] == 0) {
        PyErr_SetString(PyExc_OverflowError, "negative zero");
        PyMem_DEL(self);
        return NULL;
    }

    if (self->exp && self->mantissa[0] == 0){
        PyErr_SetString(PyExc_OverflowError, "non-normalized");
        PyMem_DEL(self);
        return NULL;
    }

    if (self->mantissa[0] == 0) {
        for (i = 1; i < NPLACES; ++i){
            if (self->mantissa[i] != 0){
                PyErr_SetString(PyExc_OverflowError, "nonzero zero tumbler");
                PyMem_DEL(self);
                return NULL;
            }
        }
    }

    for (i = 0; i < NPLACES; ++i) {
        if (self->mantissa[i] < 0) {
            PyErr_SetString(PyExc_OverflowError, "negative digit");
            PyMem_DEL(self);
            return NULL;
        }
    }

    return self;
}

static PyObject *
tumbler_new(PyObject *moduleself, PyObject *args)
{
    int i, j;
    tumbler_TumblerObject *tumbler;
    PyObject *initarg;

    UNLESS(PyArg_ParseTuple(args, "O:new_tumbler", &initarg)) return NULL;
    UNLESS(tumbler = PyObject_New(tumbler_TumblerObject, &tumbler_TumblerType)) return NULL;

    // If String, Parse and Convert String into New Tumbler
    if (PyString_Check(initarg)) {
        char *s = PyString_AsString(initarg);
	while (isspace(*s))
            s++;

        if (*s == '-') {
            tumbler->negsign = 1;
            s++;
        } else
            tumbler->negsign = 0;

        memset(&tumbler->mantissa, 0, sizeof(tumbler->mantissa));
        tumbler->exp = 0;

        for (i = 0; i < NPLACES; i++) {
            char *e;

            if (*s == '\0')
                break;

            errno = 0; // Prepare to Detect Overflows
            tumbler->mantissa[i] = strtodigit(s, &e, 10);

            if (errno) {
                PyErr_Format(PyExc_OverflowError, "digit value overflow in tumbler at: %s", s);
                PyMem_DEL(tumbler);
                return NULL;
            }

            if (s == e) { // Nothing was Parsed
                PyErr_Format(PyExc_SyntaxError, "incorrectly formed tumbler at: %s", s);
                PyMem_DEL(tumbler);
                return NULL;
            }

            s = e; // Advance Past Text Just Parsed

            if (tumbler->mantissa[i] == 0 && i == 0) { // Accumulate Leading Zeroes
                --tumbler->exp;
                --i;
            }

            if (*s == '.') {
                s++;
            } else if (isspace(*s)) {
            } else if (*s != '\0') {
                PyErr_Format(PyExc_SyntaxError, "incorrectly formed tumbler at: %s", s);
                PyMem_DEL(tumbler);
                return NULL;
            }
        }

        if (*s != '\0') {
            PyErr_Format(PyExc_OverflowError, "limit of %d digits in tumbler exceeded", NPLACES);
            PyMem_DEL(tumbler);
            return NULL;
        }

        for (j = 0; j < NPLACES && tumbler->mantissa[j] == 0; ++j)
            ; // Determine if Mantissa Consists *entirely* of Zeroes

        if (j == NPLACES)
            tumbler->exp = 0; // Mantissa is *all* Zeroes, Shorten Exponent

    // If Integer, Convert into New Tumbler
    // TBD

    // If Array of Integers, Convert into New Tumbler
    // TBD

    } else { // Initialization Argument not a Recognized Type/Object
        PyErr_SetString(PyExc_SyntaxError, "string required");
        PyMem_DEL(tumbler);
        return NULL;
    }

    // Precompute Number of Digits, for Performance
    tumbler->numdigits = NPLACES;
    do { // Remove Trailing Zeroes
        --tumbler->numdigits;
    } while (tumbler->numdigits > 0 && tumbler->mantissa[tumbler->numdigits] == 0);
    tumbler->numdigits++;

    return (PyObject *) tumbler_validate(tumbler);
}

static void
tumbler_dealloc(PyObject* self)
{
    PyObject_Del(self);
}

    static PyObject *
tumbler__repr__(tumbler_TumblerObject *self)
{
    PyObject *s, *period, *zeroperiod;
    int i, place = NPLACES;
    char buf[20];

    if (self->negsign)
        s = PyString_FromString("tumbler('-");
    else
        s = PyString_FromString("tumbler('");

    period = PyString_FromString(".");
    zeroperiod = PyString_FromString("0.");

    for (i = 0; i < -self->exp; i++)
        PyString_Concat(&s, zeroperiod);

    do {
        --place;
    } while (place > 0 && self->mantissa[place] == 0);

    for (i = 0; i <= place && s != NULL; i++) {
        sprintf(buf, "%ld", self->mantissa[i]);
        PyString_ConcatAndDel(&s, PyString_FromString(buf));

        if (i < place)
            PyString_Concat(&s, period);
    }

    Py_DECREF(period);
    Py_DECREF(zeroperiod);

    PyString_ConcatAndDel(&s, PyString_FromString("')"));
    return s;
}

    static PyObject *
tumbler__str__(tumbler_TumblerObject *self)
{
    PyObject *s, *period, *zeroperiod;
    int i, place = NPLACES;
    char buf[20];

    if (self->negsign)
        s = PyString_FromString("-");
    else
        s = PyString_FromString("");

    period = PyString_FromString(".");
    zeroperiod = PyString_FromString("0.");

    for (i = 0; i < -self->exp; i++)
        PyString_Concat(&s, zeroperiod);

    do {
        --place;
    } while (place > 0 && self->mantissa[place] == 0);

    for (i = 0; i <= place && s != NULL; i++) {
        sprintf(buf, "%ld", self->mantissa[i]);
        PyString_ConcatAndDel(&s, PyString_FromString(buf));

        if (i < place)
            PyString_Concat(&s, period);
    }

    Py_DECREF(period);
    Py_DECREF(zeroperiod);

    return s;
}

    static int
tumbler__len__(tumbler_TumblerObject *self)
{
    return -self->exp + self->numdigits;
}

    static int
tumbler_nonzero(tumbler_TumblerObject *self)
{
    return self->mantissa[0] != 0;
}

    static int
tumbler_abscmp(tumbler_TumblerObject *aptr, tumbler_TumblerObject *bptr)
{
    digit *a, *b;
    int i, cmp;

    if (aptr->exp != bptr->exp) {
        if (aptr->exp < bptr->exp)  return LESSER;
        else                        return GREATER;
    }

    a = aptr->mantissa;
    b = bptr->mantissa;
    for (i = NPLACES; i--;) {
        if (!(cmp = *a++ - *b++)) {
        } else if (cmp < 0) {
            return LESSER;	/* a < b */
        } else {  /* if (cmp > 0) */
            return GREATER;
        }
    }

    return EQUAL;
}

    static int
tumbler_compare(tumbler_TumblerObject *vt, tumbler_TumblerObject *wt)
{
//    tumbler_TumblerObject *vt, *wt;
//
//    vt = (tumbler_TumblerObject *) v;
//    wt = (tumbler_TumblerObject *) w;

    if (vt->mantissa[0] == 0) {
        if (wt->mantissa[0] == 0)
            return EQUAL;
        else
            return (wt->negsign ? GREATER : LESSER);
    }

    if (wt->mantissa[0] == 0)
        return (vt->negsign ? LESSER : GREATER);

    if (vt->negsign == wt->negsign)
        return (vt->negsign ? tumbler_abscmp(wt, vt) : tumbler_abscmp(vt, wt));

    return (vt->negsign ? LESSER : GREATER);
}

    static PyObject *
tumbler_item(tumbler_TumblerObject *self, int i)
{
    int prefixzeroes = -self->exp;

    if (i < 0 || i >= prefixzeroes + self->numdigits) {
        PyErr_SetString(PyExc_IndexError, "tumbler index out of range");
        return NULL;
    }

    if (i < prefixzeroes) {
        return PyInt_FromLong(0);
    } else {
        return PyInt_FromLong(self->mantissa[i - prefixzeroes]);
    }
}

    static PyObject *
tumbler_slice(tumbler_TumblerObject *self, int ilow, int ihigh)
{
    int prefixzeroes = -self->exp;
    int totdigits    = prefixzeroes + self->numdigits;

    tumbler_TumblerObject *np;
    int i;

    if (ilow  < 0)           ilow  = 0;
    if (ihigh > totdigits)   ihigh = totdigits;
    if (ihigh < ilow)        ihigh = ilow;

    if (ilow == 0 && ihigh == totdigits) {
        /* XXX can only do this if tumblers are immutable! */
        Py_INCREF(self);
        return (PyObject *) self;
    }

    UNLESS(np = PyObject_New(tumbler_TumblerObject, &tumbler_TumblerType)) return NULL;

    np->negsign    = self->negsign;
    memset(&np->mantissa, 0, sizeof(np->mantissa));
    np->exp = 0;
    np->numdigits = 0;

    for (i = ilow; i < ihigh; i++) {
        if (i < prefixzeroes)
            --np->exp;
        else {
            np->mantissa[i - ilow - prefixzeroes] = self->mantissa[i - prefixzeroes];
            np->numdigits++;
        }
    }

    return (PyObject *) tumbler_validate(np);
}

    static tumbler_TumblerObject *
tumbler_absadd(tumbler_TumblerObject *a, tumbler_TumblerObject *b)
{
    int i, j, temp;
    tumbler_TumblerObject *c;

    i = j = 0;

    UNLESS(c = PyObject_New(tumbler_TumblerObject, &tumbler_TumblerType)) return NULL;
    memset(&c->mantissa, 0, sizeof(c->mantissa));

    c->negsign = 0;

    if (a->exp == b->exp) {
        c->exp = a->exp;
        c->mantissa[0] = a->mantissa[0] + b->mantissa[0];
        i = j = 1;

    } else if (a->exp > b->exp) {
        c->exp = a->exp;
        temp = a->exp - b->exp;
        while (i < temp)
            c->mantissa[j++] = a->mantissa[i++];
        c->mantissa[j++] = a->mantissa[i++] + b->mantissa[0];
        i = 1;

    } else {
        c->exp = b->exp;
        temp = b->exp - a->exp;
        while (i <= temp)
            c->mantissa[j++] = b->mantissa[i++];
    }

    while (j <= NPLACES - 1)
        c->mantissa[j++] = b->mantissa[i++];

    // Precompute Number of Digits, for Performance
    c->numdigits = NPLACES;
    do { // Remove Trailing Zeroes
        --c->numdigits;
    } while (c->numdigits > 0 && c->mantissa[c->numdigits] == 0);
    c->numdigits++;

    return c;
}

#define tumbler_eq(a, b)  (tumbler_compare((a), (b)) == EQUAL)

    static tumbler_TumblerObject *
tumbler_strongsub(tumbler_TumblerObject *a, tumbler_TumblerObject *b)
{
    int i, j;
    tumbler_TumblerObject *c;

    if (tumbler_eq(a, b)) {
        Py_INCREF(&ZeroTumbler);
        return &ZeroTumbler;
    }

    if (b->exp < a->exp) {
        Py_INCREF(a);
        return a;
    }

    UNLESS(c = PyObject_New(tumbler_TumblerObject, &tumbler_TumblerType)) return NULL;
    memset(&c->mantissa, 0, sizeof(c->mantissa));

    c->exp = a->exp;
    for (i = 0; a->mantissa[i] == b->mantissa[i]; i++) {
        --c->exp;
        if (i >= NPLACES)
            return c;
    }

    c->mantissa[0] = a->mantissa[i] - b->mantissa[i];
    if (++i >= NPLACES)
        return c;

    for (j = 1; j < NPLACES && i < NPLACES; )
        c->mantissa[j++] = a->mantissa[i++];

    return c;
}

    static tumbler_TumblerObject *
tumbler_weaksub(tumbler_TumblerObject *a, tumbler_TumblerObject *b)
{
    int i;
    tumbler_TumblerObject *c;

    if (tumbler_eq(a, b)) {
        Py_INCREF(&ZeroTumbler);
        return &ZeroTumbler;
    }

    UNLESS(c = PyObject_New(tumbler_TumblerObject, &tumbler_TumblerType)) return NULL;
    memset(&c->mantissa, 0, sizeof(c->mantissa));

    c->exp = a->exp;
    for (i = 0; i < (a->exp - b->exp); i++) {
        c->mantissa[i] = a->mantissa[i];
        if (i >= NPLACES)
            return c;
    }

    c->mantissa[i] = a->mantissa[i] - b->mantissa[0];
    return c;
}

    static void
tumbler_justify(tumbler_TumblerObject *self)
{
    int i, j, shift;
  
    if (self->mantissa[0] != 0)
        return;

    for (shift = 0; self->mantissa[shift] == 0; ++shift) {
        if (shift == NPLACES - 1) {
            self->exp  = 0;
	    self->negsign = 0;
            return;
        }
    }

    for (i = 0, j = shift; j < NPLACES;)
        self->mantissa[i++] = self->mantissa[j++];

    while (i < NPLACES)
        self->mantissa[i++] = 0;

    self->exp -= shift;
}

    static tumbler_TumblerObject *
tumbler_add(tumbler_TumblerObject *a, tumbler_TumblerObject *b)
{
    tumbler_TumblerObject *c;

    if (b->mantissa[0] == 0) {
        Py_INCREF(a);
        return a;
    }

    if (a->mantissa[0] == 0) {
        Py_INCREF(b);
        return b;
    }

    if (a->negsign == b->negsign) {
        c = tumbler_absadd(a, b);
        c->negsign = a->negsign;
        /*absadd returns justified result so no need to justify*/

    } else if (tumbler_abscmp(a, b) == GREATER) {
        c = tumbler_strongsub(a, b);
        c->negsign = a->negsign;
        if (c->mantissa[0] == 0)
            tumbler_justify(c);

    } else {
        c = tumbler_weaksub(b, a);
        c->negsign = b->negsign;
        if (c->mantissa[0] == 0)
            tumbler_justify(c);
    }

    return tumbler_validate(c);
}

    static tumbler_TumblerObject *
tumbler_subtract(tumbler_TumblerObject *a, tumbler_TumblerObject *b)
{
    tumbler_TumblerObject *c, *bb;

    if (b->mantissa[0] == 0) {
        Py_INCREF(a);
        return a;
    }

    if (tumbler_eq(a, b)) {
        Py_INCREF(&ZeroTumbler);
        return &ZeroTumbler;
    }

    if (a->mantissa[0] == 0) {
        tumbler_TumblerObject *c;

        UNLESS(c = PyObject_New(tumbler_TumblerObject, &tumbler_TumblerType)) return NULL;

        c->negsign   = !b->negsign;
        c->exp       = b->exp;
        c->numdigits = b->numdigits;
        memcpy(&c->mantissa, b->mantissa, sizeof(c->mantissa));
        return c;
    }

    UNLESS(bb = PyObject_New(tumbler_TumblerObject, &tumbler_TumblerType)) return NULL;

    bb->negsign   = !b->negsign;
    bb->exp       = b->exp;
    bb->numdigits = b->numdigits;
    memcpy(&bb->mantissa, b->mantissa, sizeof(c->mantissa));

    c = tumbler_add(a, bb);

    Py_DECREF(bb);

    tumbler_justify(c);
    return tumbler_validate(c);
}

static PyNumberMethods tumbler_Number = {
    (binaryfunc)          &tumbler_add,          // nb_add
    (binaryfunc)          &tumbler_subtract,     // nb_subtract
    (binaryfunc)          0,                     // nb_multiply
    (binaryfunc)          0,                     // nb_divide
    (binaryfunc)          0,                     // nb_remainder
    (binaryfunc)          0,                     // nb_divmod
    (ternaryfunc)         0,                     // nb_power
    (unaryfunc)           0,                     // nb_negative
    (unaryfunc)           0,                     // nb_positive
    (unaryfunc)           0,                     // nb_absolute
    (inquiry)             &tumbler_nonzero,      // nb_nonzero
    (unaryfunc)           0,                     // nb_invert
    (binaryfunc)          0,                     // nb_lshift
    (binaryfunc)          0,                     // nb_rshift
    (binaryfunc)          0,                     // nb_and
    (binaryfunc)          0,                     // nb_xor
    (binaryfunc)          0,                     // nb_or
    (coercion)            0,                     // nb_coerce
    (unaryfunc)           0,                     // nb_int
    (unaryfunc)           0,                     // nb_long
    (unaryfunc)           0,                     // nb_float
    (unaryfunc)           0,                     // nb_oct
    (unaryfunc)           0,                     // nb_hex
};

static PySequenceMethods tumbler_Sequence = {
    (inquiry)             tumbler__len__,        // sq_length
    (binaryfunc)          0,                     // sq_concat
    (intargfunc)          0,                     // sq_repeat
    (intargfunc)          &tumbler_item,         // sq_item
    (intintargfunc)       &tumbler_slice,        // sq_slice
    (intobjargproc)       0,                     // sq_ass_item
    (intintobjargproc)    0,                     // sq_ass_slice
};

static PyTypeObject tumbler_TumblerType = {
    PyObject_HEAD_INIT(NULL)
    0,                                    // ob_size
    "tumbler",                            // tp_name ::= Name of Type, for Printing
    sizeof(tumbler_TumblerObject),        // tp_basicsize, for Allocation
    0,                                    // tp_itemsize, for Allocation
    // Methods to Implement Standard Operations
    (destructor)          tumbler_dealloc,       // tp_dealloc
    (printfunc)           0,                     // tp_print
    (getattrfunc)         0,                     // tp_getattr
    (setattrfunc)         0,                     // tp_setattr
    (cmpfunc)             tumbler_compare,       // tp_compare
    (reprfunc)            tumbler__repr__,       // tp_repr
    // Method Suites for Standard Classes
    (PyNumberMethods *)   &tumbler_Number,       // tp_as_number
    (PySequenceMethods *) &tumbler_Sequence,     // tp_as_sequence
    (PyMappingMethods *)  0,                     // tp_as_mapping
    // More Standard Operations
    (hashfunc)            0,                     // tp_hash
    (ternaryfunc)         0,                     // tp_call
    (reprfunc)            tumbler__str__,        // tp_str
    (getattrofunc)        0,                     // tp_getattro
    (setattrofunc)        0,                     // tp_setattro
    // Functions to Access Object as I/O Buffer
    (PyBufferProcs *)     0,                     // tp_as_buffer
    // Flags to Defined Presence of Optional/Expanded Features
    (long)                0,                     // tp_flags
    (char *)              0,                     // tp_doc ::= __doc__ String
};

static PyMethodDef tumbler_methods[] = {
    { "tumbler", tumbler_new, METH_VARARGS },
    {NULL, NULL}
};

DL_EXPORT(void)
inittumbler(void) 
{
    tumbler_TumblerType.ob_type = &PyType_Type;

    Py_InitModule3("tumbler", tumbler_methods, tumbler__doc__);
}


