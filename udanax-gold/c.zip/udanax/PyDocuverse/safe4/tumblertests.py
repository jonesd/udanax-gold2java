import unittest

from Tumbler import tumbler

class TumblerTestCase(unittest.TestCase):
    def setUp(self):
	self.tumbler = tumbler('1.2.3')
			
    def tearDown(self):
        self.tumbler = None
							
    def testDefaultValue(self):
        self.failUnless(str(tumbler()) == '0',
            'incorrect default value')
									
    def testParser(self):
        self.failUnless(str(tumbler('1'))     == '1', '')
        self.failUnless(str(tumbler('1.2'))   == '1.2', '')
        self.failUnless(str(tumbler('1.2.3')) == '1.2.3', '')

    def testIdentityCompare(self):
        self.failUnless(tumbler('1.2.3') == tumbler('1.2.3'), '')

    def testRelationalCompare(self):
        self.failUnless(tumbler('1.2.3') <  tumbler('4.5.6'),  '')
        self.failUnless(tumbler('4.5.6') >  tumbler('1.2.3'),  '')
        self.failUnless(tumbler('1.2.3') == tumbler('1.2.3'),  '')
        self.failUnless(tumbler('4.5.6') != tumbler('1.2.3'),  '')

    def testAddition(self):
        self.failUnless(tumbler('1.2.3') + tumbler('0.0.1') == tumbler('1.2.4'),  '')

main = unittest.TestProgram

if __name__ == "__main__":
    main(module='__main__', defaultTest=None, argv=None, testRunner=None, testLoader=unittest.defaultTestLoader)
