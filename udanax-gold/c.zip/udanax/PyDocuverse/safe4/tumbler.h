#define NPLACES 11
enum { LESSER=-1, EQUAL=0, GREATER=+1 };

#ifdef DIGITS_LONGLONG
    typedef unsigned long long  digit;
    #define strtodigit  strtoull
#else
    typedef unsigned long       digit;
    #define strtodigit  strtoul
#endif

#define Tumbler_Check(op) ((op)->ob_type == (struct _typeobject *) &TumblerType)

// A little syntactic glue...
#define UNLESS(E)    if(!(E))
#define RETURN_NONE  Py_INCREF(Py_None); return Py_None
#define tumbler_eq(a, b)  (tumbler_compare((a), (b)) == EQUAL)

typedef struct {
    PyObject_HEAD
    char    negsign;          // 1 if negative, otherwise 0
    short   exp;
    short   numdigits;
    long    hash;
    digit   mantissa[NPLACES];
} TumblerObject;

extern PyExtensionClass TumblerType;
TumblerObject *tumbler_new(char *s);
PyObject *tumbler__str__(TumblerObject *self);
int tumbler_compare(TumblerObject *vt, TumblerObject *wt);
TumblerObject *tumbler_add(TumblerObject *a, TumblerObject *b);

extern PyTypeObject SpanType;
PyObject *span_new(PyObject *moduleself, PyObject *args);

