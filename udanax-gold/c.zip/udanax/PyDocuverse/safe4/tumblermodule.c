 /**
 * @file  tumblermodule.c
 * @brief Memory-Resident Tumbler Objects
 *
 **/

static char tumbler_module__doc__ [] = "\
There are two basic flavors of tumbler: address tumblers and\n\
difference tumblers.  The former represent a specific\n\
zero-dimensional point along the tumbler number line and the\n\
latter represent a span or segment along the number line.\n\
\n\
However, difference tumblers don't represent a count of anything.\n\
They don't mean some N characters, N bytes or N paragraphs.  Because\n\
of this they have no meaning in isolation but only when paired with\n\
an address tumbler.  This (address, difference) tuple is called a span.";

#include "ExtensionClass.h"
#include <ctype.h>

#include "tumbler.h"

//hash
//if tumbler in span
//if span in span         __contains__
//if span == span

#define MODNAME "Tumbler"

/* Standard Constants */

TumblerObject *ZeroTumbler;

    static void
tumbler_precalc(TumblerObject *self)
{
    long x;
    int i;

    // Precompute Number of Digits, for Performance
    self->numdigits = NPLACES;
    do { // Remove Trailing Zeroes
        --self->numdigits;
    } while (self->numdigits > 0 && self->mantissa[self->numdigits] == 0);
    self->numdigits++;

    // Precompute Pythonic Hash Code
    x = 0x876543L;

    x = (1000003 * x) ^ self->negsign;
    x = (1000003 * x) ^ self->exp;

    for (i = 0; i < self->numdigits; i++)
        x = (1000003 * x) ^ self->mantissa[i];

    x ^= self->numdigits;
    if (x == -1)
        x = -2;

    self->hash = x;
}

    static TumblerObject *
tumbler_validate(TumblerObject *self)
{
    int i;

    if (self->exp > 0) {
        PyErr_SetString(PyExc_OverflowError, "invalid exponent (>0)");
        return NULL;
    }

    if (self->negsign && self->mantissa[0] == 0) {
        PyErr_SetString(PyExc_OverflowError, "negative zero");
        return NULL;
    }

    if (self->exp && self->mantissa[0] == 0){
        PyErr_SetString(PyExc_OverflowError, "non-normalized");
        return NULL;
    }

    if (self->mantissa[0] == 0) {
        for (i = 1; i < NPLACES; ++i){
            if (self->mantissa[i] != 0){
                PyErr_SetString(PyExc_OverflowError, "nonzero zero tumbler");
                return NULL;
            }
        }
    }

    for (i = 0; i < NPLACES; ++i) {
        if (self->mantissa[i] < 0) {
            PyErr_SetString(PyExc_OverflowError, "negative digit");
            return NULL;
        }
    }

    return self;
}

    static PyObject *
tumblerobj_parse(TumblerObject *tumbler, char *s)
{
    int i, j;

    // Note: Assumes TumblerObject has already been pre-zeroed

    while (isspace(*s))
        s++;

    if (*s == '-') {
        tumbler->negsign = 1;
        s++;
    }

    for (i = 0; i < NPLACES; i++) {
        char *e;

        if (*s == '\0')
            break;

        errno = 0; // Prepare to Detect Overflows
        tumbler->mantissa[i] = strtodigit(s, &e, 10);

        if (errno) {
            PyErr_Format(PyExc_OverflowError, "digit value overflow in tumbler at: %s", s);
            return NULL;
        }

        if (s == e) { // Nothing was Parsed
            PyErr_Format(PyExc_SyntaxError, "incorrectly formed tumbler at: %s", s);
            return NULL;
        }

        s = e; // Advance Past Text Just Parsed

        if (tumbler->mantissa[i] == 0 && i == 0) { // Accumulate Leading Zeroes
            --tumbler->exp;
            --i;
        }

        if (*s == '.') {
            s++;
        } else if (isspace(*s)) {
        } else if (*s != '\0') {
            PyErr_Format(PyExc_SyntaxError, "incorrectly formed tumbler at: %s", s);
            return NULL;
        }
    }

    if (*s != '\0') {
        PyErr_Format(PyExc_OverflowError, "limit of %d digits in tumbler exceeded", NPLACES);
        return NULL;
    }

    for (j = 0; j < NPLACES && tumbler->mantissa[j] == 0; ++j)
        ; // Determine if Mantissa Consists *entirely* of Zeroes

    if (j == NPLACES)
        tumbler->exp = 0; // Mantissa is *all* Zeroes, Shorten Exponent

    return (PyObject *) tumbler;
}

    static PyObject *
tumblerobj__init__(TumblerObject *self, PyObject *args)
{
    char *initarg = NULL;

    // Note: TumblerObject has already been allocated and zeroed

    UNLESS(PyArg_ParseTuple(args, "|s:new_tumbler", &initarg)) return NULL;

    if (initarg)
        UNLESS(tumblerobj_parse(self, initarg)) return NULL;

    tumbler_precalc(self);

    UNLESS(tumbler_validate(self)) return NULL;

    Py_INCREF(Py_None);
    return Py_None;
}

static void
tumbler_dealloc(TumblerObject *self)
{
    Py_DECREF(self->ob_type);
    PyObject_Del(self);
}

    static PyObject *
tumbler__repr__(TumblerObject *self)
{
    PyObject *s, *period, *zeroperiod;
    int i, place = NPLACES;
    char buf[20];

    if (self->negsign)
        s = PyString_FromString("tumbler('-");
    else
        s = PyString_FromString("tumbler('");

    period = PyString_FromString(".");
    zeroperiod = PyString_FromString("0.");

    for (i = 0; i < -self->exp; i++)
        PyString_Concat(&s, zeroperiod);

    do {
        --place;
    } while (place > 0 && self->mantissa[place] == 0);

    for (i = 0; i <= place && s != NULL; i++) {
        sprintf(buf, "%ld", self->mantissa[i]);
        PyString_ConcatAndDel(&s, PyString_FromString(buf));

        if (i < place)
            PyString_Concat(&s, period);
    }

    Py_DECREF(period);
    Py_DECREF(zeroperiod);

    PyString_ConcatAndDel(&s, PyString_FromString("')"));
    return s;
}

    PyObject *
tumbler__str__(TumblerObject *self)
{
    PyObject *s, *period, *zeroperiod;
    int i, place = NPLACES;
    char buf[20];

    period     = PyString_FromString(".");
    zeroperiod = PyString_FromString("0.");
    s          = PyString_FromString(self->negsign ? "-" : "");

    for (i = 0; i < -self->exp; i++)
        PyString_Concat(&s, zeroperiod);

    do {
        --place;
    } while (place > 0 && self->mantissa[place] == 0);

    for (i = 0; i <= place && s != NULL; i++) {
        sprintf(buf, "%ld", self->mantissa[i]);
        PyString_ConcatAndDel(&s, PyString_FromString(buf));

        if (i < place)
            PyString_Concat(&s, period);
    }

    Py_DECREF(period);
    Py_DECREF(zeroperiod);

    return s;
}

    static int
tumbler__len__(TumblerObject *self)
{
    return -self->exp + self->numdigits;
}

    static int
tumbler_nonzero(TumblerObject *self)
{
    return self->mantissa[0] != 0;
}

    static int
tumbler_abscmp(TumblerObject *aptr, TumblerObject *bptr)
{
    digit *a, *b;
    int i, cmp;

    if (aptr->exp != bptr->exp) {
        if (aptr->exp < bptr->exp)  return LESSER;
        else                        return GREATER;
    }

    a = aptr->mantissa;
    b = bptr->mantissa;
    for (i = NPLACES; i--;) {
        if (!(cmp = *a++ - *b++)) {
        } else if (cmp < 0) {
            return LESSER;	/* a < b */
        } else {  /* if (cmp > 0) */
            return GREATER;
        }
    }

    return EQUAL;
}

    int
tumbler_compare(TumblerObject *vt, TumblerObject *wt)
{
    if (vt->mantissa[0] == 0) {
        if (wt->mantissa[0] == 0)
            return EQUAL;
        else
            return (wt->negsign ? GREATER : LESSER);
    }

    if (wt->mantissa[0] == 0)
        return (vt->negsign ? LESSER : GREATER);

    if (vt->negsign == wt->negsign)
        return (vt->negsign ? tumbler_abscmp(wt, vt) : tumbler_abscmp(vt, wt));

    return (vt->negsign ? LESSER : GREATER);
}

    static PyObject *
tumbler_item(TumblerObject *self, int i)
{
    int prefixzeroes = -self->exp;

    if (i < 0 || i >= prefixzeroes + self->numdigits) {
        PyErr_SetString(PyExc_IndexError, "tumbler index out of range");
        return NULL;
    }

    if (i < prefixzeroes) {
        return PyInt_FromLong(0);
    } else {
        return PyInt_FromLong(self->mantissa[i - prefixzeroes]);
    }
}

    TumblerObject *
tumbler_new(char *s)
{
    TumblerObject *t;
    PyObject *initarg = NULL;

    if (s != NULL) {
        initarg = PyTuple_New(1);
        PyTuple_SET_ITEM(initarg, 0, PyString_FromString(s));
    }

    t = (TumblerObject *) PyObject_CallObject((PyObject *) &TumblerType, initarg);

    Py_XDECREF(initarg);
    return t;
}

    static PyObject *
tumbler_slice(TumblerObject *self, int ilow, int ihigh)
{
    int prefixzeroes = -self->exp;
    int totdigits    = prefixzeroes + self->numdigits;

    TumblerObject *np;
    int i;

    if (ilow  < 0)           ilow  = 0;
    if (ihigh > totdigits)   ihigh = totdigits;
    if (ihigh < ilow)        ihigh = ilow;

    if (ilow == 0 && ihigh == totdigits) {
        /* XXX can only do this if tumblers are immutable! */
        Py_INCREF(self);
        return (PyObject *) self;
    }

    UNLESS(np = tumbler_new(NULL)) return NULL;

    np->negsign = self->negsign;
    for (i = ilow; i < ihigh; i++) {
        if (i < prefixzeroes)
            --np->exp;
        else {
            np->mantissa[i - ilow - prefixzeroes] = self->mantissa[i - prefixzeroes];
            np->numdigits++;
        }
    }

    tumbler_precalc(np);
    return (PyObject *) tumbler_validate(np);
}

    static TumblerObject *
tumbler_absadd(TumblerObject *a, TumblerObject *b)
{
    int i, j, temp;
    TumblerObject *c;

    i = j = 0;

    UNLESS(c = tumbler_new(NULL)) return NULL;

    if (a->exp == b->exp) {
        c->exp = a->exp;
        c->mantissa[0] = a->mantissa[0] + b->mantissa[0];
        i = j = 1;

    } else if (a->exp > b->exp) {
        c->exp = a->exp;
        temp = a->exp - b->exp;
        while (i < temp)
            c->mantissa[j++] = a->mantissa[i++];
        c->mantissa[j++] = a->mantissa[i++] + b->mantissa[0];
        i = 1;

    } else {
        c->exp = b->exp;
        temp = b->exp - a->exp;
        while (i <= temp)
            c->mantissa[j++] = b->mantissa[i++];
    }

    while (j <= NPLACES - 1)
        c->mantissa[j++] = b->mantissa[i++];

    tumbler_precalc(c);
    return c;
}

    static TumblerObject *
tumbler_strongsub(TumblerObject *a, TumblerObject *b)
{
    int i, j;
    TumblerObject *c;

    if (tumbler_eq(a, b)) {
        Py_INCREF(ZeroTumbler);
        return ZeroTumbler;
    }

    if (b->exp < a->exp) {
        Py_INCREF(a);
        return a;
    }

    UNLESS(c = tumbler_new(NULL)) return NULL;

    c->exp = a->exp;
    for (i = 0; a->mantissa[i] == b->mantissa[i]; i++) {
        --c->exp;
        if (i >= NPLACES)
            return c;
    }

    c->mantissa[0] = a->mantissa[i] - b->mantissa[i];
    if (++i >= NPLACES)
        return c;

    for (j = 1; j < NPLACES && i < NPLACES; )
        c->mantissa[j++] = a->mantissa[i++];

    return c;
}

    static TumblerObject *
tumbler_weaksub(TumblerObject *a, TumblerObject *b)
{
    int i;
    TumblerObject *c;

    if (tumbler_eq(a, b)) {
        Py_INCREF(ZeroTumbler);
        return ZeroTumbler;
    }

    UNLESS(c = tumbler_new(NULL)) return NULL;

    c->exp = a->exp;
    for (i = 0; i < (a->exp - b->exp); i++) {
        c->mantissa[i] = a->mantissa[i];
        if (i >= NPLACES)
            return c;
    }

    c->mantissa[i] = a->mantissa[i] - b->mantissa[0];
    return c;
}

    static void
tumbler_justify(TumblerObject *self)
{
    int i, j, shift;
  
    if (self->mantissa[0] != 0)
        return;

    for (shift = 0; self->mantissa[shift] == 0; ++shift) {
        if (shift == NPLACES - 1) {
            self->exp  = 0;
	    self->negsign = 0;
            return;
        }
    }

    for (i = 0, j = shift; j < NPLACES;)
        self->mantissa[i++] = self->mantissa[j++];

    while (i < NPLACES)
        self->mantissa[i++] = 0;

    self->exp -= shift;
}

    TumblerObject *
tumbler_add(TumblerObject *a, TumblerObject *b)
{
    TumblerObject *c;

    if (b->mantissa[0] == 0) {
        Py_INCREF(a);
        return a;
    }

    if (a->mantissa[0] == 0) {
        Py_INCREF(b);
        return b;
    }

    if (a->negsign == b->negsign) {
        c = tumbler_absadd(a, b);
        c->negsign = a->negsign;
        /*absadd returns justified result so no need to justify*/

    } else if (tumbler_abscmp(a, b) == GREATER) {
        c = tumbler_strongsub(a, b);
        c->negsign = a->negsign;
        if (c->mantissa[0] == 0)
            tumbler_justify(c);

    } else {
        c = tumbler_weaksub(b, a);
        c->negsign = b->negsign;
        if (c->mantissa[0] == 0)
            tumbler_justify(c);
    }

    tumbler_precalc(c);
    return tumbler_validate(c);
}

    static TumblerObject *
tumbler_subtract(TumblerObject *a, TumblerObject *b)
{
    TumblerObject *c, *bb;

    if (b->mantissa[0] == 0) {
        Py_INCREF(a);
        return a;
    }

    if (tumbler_eq(a, b)) {
        Py_INCREF(ZeroTumbler);
        return ZeroTumbler;
    }

    if (a->mantissa[0] == 0) {
        TumblerObject *c;

        UNLESS(c = tumbler_new(NULL)) return NULL;

        c->negsign   = !b->negsign;
        c->exp       = b->exp;
        c->numdigits = b->numdigits;
        memcpy(&c->mantissa, b->mantissa, sizeof(c->mantissa));
        tumbler_precalc(c);
        return c;
    }

    UNLESS(bb = tumbler_new(NULL)) return NULL;

    bb->negsign   = !b->negsign;
    bb->exp       = b->exp;
    bb->numdigits = b->numdigits;
    memcpy(&bb->mantissa, b->mantissa, sizeof(c->mantissa));

    c = tumbler_add(a, bb);

    Py_DECREF(bb);

    tumbler_justify(c);
    tumbler_precalc(c);
    return tumbler_validate(c);
}

static long
tumbler_hash(TumblerObject *self)
{
    return self->hash;
}

    static PyObject *
tumblerobj__getstate__(PyObject *self, PyObject *args)
{
    return tumbler__str__((TumblerObject *) self);
}

    static PyObject *
tumblerobj__setstate__(TumblerObject *self, PyObject *args)
{
    return tumblerobj__init__(self, args);
}

static struct PyMethodDef tumblerobj_methods[] = {
  {"__init__",  (PyCFunction) tumblerobj__init__,  METH_VARARGS,
   "__init__(digitstr) -- Initialize a tumbler object"},

  {"__getstate__",  (PyCFunction) tumblerobj__getstate__,  METH_VARARGS,
   "__getstate__() -- Provide pickleable data"},

  {"__setstate__",  (PyCFunction) tumblerobj__setstate__,  METH_VARARGS,
   "__setstate__() -- Provide pickeable data"},

  {NULL,                NULL}           /* sentinel */
};

static PyNumberMethods tumbler_Number = {
    (binaryfunc)          &tumbler_add,          // nb_add
    (binaryfunc)          &tumbler_subtract,     // nb_subtract
    (binaryfunc)          0,                     // nb_multiply
    (binaryfunc)          0,                     // nb_divide
    (binaryfunc)          0,                     // nb_remainder
    (binaryfunc)          0,                     // nb_divmod
    (ternaryfunc)         0,                     // nb_power
    (unaryfunc)           0,                     // nb_negative
    (unaryfunc)           0,                     // nb_positive
    (unaryfunc)           0,                     // nb_absolute
    (inquiry)             &tumbler_nonzero,      // nb_nonzero
    (unaryfunc)           0,                     // nb_invert
    (binaryfunc)          0,                     // nb_lshift
    (binaryfunc)          0,                     // nb_rshift
    (binaryfunc)          0,                     // nb_and
    (binaryfunc)          0,                     // nb_xor
    (binaryfunc)          0,                     // nb_or
    (coercion)            0,                     // nb_coerce
    (unaryfunc)           0,                     // nb_int
    (unaryfunc)           0,                     // nb_long
    (unaryfunc)           0,                     // nb_float
    (unaryfunc)           0,                     // nb_oct
    (unaryfunc)           0,                     // nb_hex
};

static PySequenceMethods tumbler_Sequence = {
    (inquiry)             &tumbler__len__,       // sq_length
    (binaryfunc)          0,                     // sq_concat
    (intargfunc)          0,                     // sq_repeat
    (intargfunc)          &tumbler_item,         // sq_item
    (intintargfunc)       &tumbler_slice,        // sq_slice
    (intobjargproc)       0,                     // sq_ass_item
    (intintobjargproc)    0,                     // sq_ass_slice
};

PyExtensionClass TumblerType = {
    PyObject_HEAD_INIT(NULL)
    0,                                    // ob_size
    "tumbler",                            // tp_name ::= Name of Type, for Printing
    sizeof(TumblerObject),                // tp_basicsize, for Allocation
    0,                                    // tp_itemsize, for Allocation
    // Methods to Implement Standard Operations
    (destructor)          &tumbler_dealloc,      // tp_dealloc
    (printfunc)           0,                     // tp_print
    (getattrfunc)         0,                     // tp_getattr
    (setattrfunc)         0,                     // tp_setattr
    (cmpfunc)             &tumbler_compare,      // tp_compare
    (reprfunc)            &tumbler__repr__,      // tp_repr
    // Method Suites for Standard Classes
    (PyNumberMethods *)   &tumbler_Number,       // tp_as_number
    (PySequenceMethods *) &tumbler_Sequence,     // tp_as_sequence
    (PyMappingMethods *)  0,                     // tp_as_mapping
    // More Standard Operations
    (hashfunc)            &tumbler_hash,         // tp_hash
    (ternaryfunc)         0,                     // tp_call
    (reprfunc)            &tumbler__str__,       // tp_str
    (getattrofunc)        0,                     // tp_getattro
    (setattrofunc)        0,                     // tp_setattro
    // Functions to Access Object as I/O Buffer
    (PyBufferProcs *)     0,                     // tp_as_buffer
    // Flags to Defined Presence of Optional/Expanded Features
    (long)                0,                     // tp_flags
    (char *)              0,                     // tp_doc ::= __doc__ String

    METHOD_CHAIN(tumblerobj_methods),
};

static PyMethodDef module_methods[] = {
    { "span", span_new, METH_VARARGS },
    {NULL, NULL}
};

DL_EXPORT(void)
initTumbler(void) 
{
    PyObject *m, *d;
    char *rev = "$Revision: 1.1.1.1 $";

    UNLESS(PyExtensionClassCAPI = PyCObject_Import("ExtensionClass", "CAPI"))
        return;

    TumblerType.tp_getattro = PyExtensionClassCAPI->getattro;
    TumblerType.ob_type     = &PyType_Type;

//TBD    SpanType.tp_getattro    = PyExtensionClassCAPI->getattro;
//TBD    SpanType.ob_type        = &PyType_Type;

    m = Py_InitModule4(MODNAME, module_methods, tumbler_module__doc__, (PyObject *) NULL, PYTHON_API_VERSION);

    // Add some symbolic constants to the module
    d = PyModule_GetDict(m);

    PyExtensionClass_Export(d, "tumbler", TumblerType);
//TBD    PyExtensionClass_Export(d, "span",    SpanType);

    PyDict_SetItemString(d, "__version__", PyString_FromStringAndSize(rev+11,strlen(rev+11)-2));

    ZeroTumbler = tumbler_new(NULL);

    if (PyErr_Occurred())
        Py_FatalError("can't initialize module: " MODNAME);
}

