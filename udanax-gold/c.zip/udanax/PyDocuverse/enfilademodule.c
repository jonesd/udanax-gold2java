 /**
 * @file  enfilademodule.c
 * @brief Memory-Resident Enfilade Nodes
 *
 **/

static char enfilade_module__doc__ [] = "\
There are two basic flavors of tumbler: address tumblers and\n\
difference tumblers.  The former represent a specific\n\
zero-dimensional point along the tumbler number line and the\n\
latter represent a span or segment along the number line.\n\
\n\
However, difference tumblers don't represent a count of anything.\n\
They don't mean some N characters, N bytes or N paragraphs.  Because\n\
of this they have no meaning in isolation but only when paired with\n\
an address tumbler.  This (address, difference) tuple is called a span.";

#include "ExtensionClass.h"
#include <ctype.h>

//#include "tumbler.h"

#define Enfilade_Check(op) ((op)->ob_type == (struct _typeobject *) &EnfiladeType)

// A little syntactic glue...
#define UNLESS(E)    if(!(E))
#define RETURN_NONE  Py_INCREF(Py_None); return Py_None

typedef struct {
    PyObject_HEAD
    char    negsign;          // 1 if negative, otherwise 0
    short   exp;
    short   numdigits;
    long    hash;
    digit   mantissa[NPLACES];
} EnfiladeObject;

#define MODNAME "Enfilade"

/* Standard Constants */

    static PyObject *
enfiladeobj__init__(EnfiladeObject *self, PyObject *args)
{
    char *initarg = NULL;

    // Note: EnfiladeObject has already been allocated and zeroed

    UNLESS(PyArg_ParseTuple(args, "|s:new_tumbler", &initarg)) return NULL;

    if (initarg)
        UNLESS(tumblerobj_parse(self, initarg)) return NULL;

    tumbler_precalc(self);

    UNLESS(tumbler_validate(self)) return NULL;

    Py_INCREF(Py_None);
    return Py_None;
}

static void
enfilade_dealloc(EnfiladeObject *self)
{
    Py_DECREF(self->ob_type);
    PyObject_Del(self);
}

    static PyObject *
tumbler__repr__(TumblerObject *self)
{
    PyObject *s, *period, *zeroperiod;
    int i, place = NPLACES;
    char buf[20];

    if (self->negsign)
        s = PyString_FromString("tumbler('-");
    else
        s = PyString_FromString("tumbler('");

    period = PyString_FromString(".");
    zeroperiod = PyString_FromString("0.");

    for (i = 0; i < -self->exp; i++)
        PyString_Concat(&s, zeroperiod);

    do {
        --place;
    } while (place > 0 && self->mantissa[place] == 0);

    for (i = 0; i <= place && s != NULL; i++) {
        sprintf(buf, "%ld", self->mantissa[i]);
        PyString_ConcatAndDel(&s, PyString_FromString(buf));

        if (i < place)
            PyString_Concat(&s, period);
    }

    Py_DECREF(period);
    Py_DECREF(zeroperiod);

    PyString_ConcatAndDel(&s, PyString_FromString("')"));
    return s;
}

    PyObject *
tumbler__str__(TumblerObject *self)
{
    PyObject *s, *period, *zeroperiod;
    int i, place = NPLACES;
    char buf[20];

    period     = PyString_FromString(".");
    zeroperiod = PyString_FromString("0.");
    s          = PyString_FromString(self->negsign ? "-" : "");

    for (i = 0; i < -self->exp; i++)
        PyString_Concat(&s, zeroperiod);

    do {
        --place;
    } while (place > 0 && self->mantissa[place] == 0);

    for (i = 0; i <= place && s != NULL; i++) {
        sprintf(buf, "%ld", self->mantissa[i]);
        PyString_ConcatAndDel(&s, PyString_FromString(buf));

        if (i < place)
            PyString_Concat(&s, period);
    }

    Py_DECREF(period);
    Py_DECREF(zeroperiod);

    return s;
}

    TumblerObject *
tumbler_new(char *s)
{
    TumblerObject *t;
    PyObject *initarg = NULL;

    if (s != NULL) {
        initarg = PyTuple_New(1);
        PyTuple_SET_ITEM(initarg, 0, PyString_FromString(s));
    }

    t = (TumblerObject *) PyObject_CallObject((PyObject *) &TumblerType, initarg);

    Py_XDECREF(initarg);
    return t;
}

    static PyObject *
tumblerobj__getstate__(PyObject *self, PyObject *args)
{
    return tumbler__str__((TumblerObject *) self);
}

    static PyObject *
tumblerobj__setstate__(TumblerObject *self, PyObject *args)
{
    return tumblerobj__init__(self, args);
}

static struct PyMethodDef tumblerobj_methods[] = {
  {"__init__",  (PyCFunction) tumblerobj__init__,  METH_VARARGS,
   "__init__(digitstr) -- Initialize a tumbler object"},

  {"__getstate__",  (PyCFunction) tumblerobj__getstate__,  METH_VARARGS,
   "__getstate__() -- Provide pickleable data"},

  {"__setstate__",  (PyCFunction) tumblerobj__setstate__,  METH_VARARGS,
   "__setstate__() -- Provide pickeable data"},

  {NULL,                NULL}           /* sentinel */
};

static PyNumberMethods tumbler_Number = {
    (binaryfunc)          0,          // nb_add
    (binaryfunc)          0,     // nb_subtract
    (binaryfunc)          0,                     // nb_multiply
    (binaryfunc)          0,                     // nb_divide
    (binaryfunc)          0,                     // nb_remainder
    (binaryfunc)          0,                     // nb_divmod
    (ternaryfunc)         0,                     // nb_power
    (unaryfunc)           0,                     // nb_negative
    (unaryfunc)           0,                     // nb_positive
    (unaryfunc)           0,                     // nb_absolute
    (inquiry)             0,      // nb_nonzero
    (unaryfunc)           0,                     // nb_invert
    (binaryfunc)          0,                     // nb_lshift
    (binaryfunc)          0,                     // nb_rshift
    (binaryfunc)          0,                     // nb_and
    (binaryfunc)          0,                     // nb_xor
    (binaryfunc)          0,                     // nb_or
    (coercion)            0,                     // nb_coerce
    (unaryfunc)           0,                     // nb_int
    (unaryfunc)           0,                     // nb_long
    (unaryfunc)           0,                     // nb_float
    (unaryfunc)           0,                     // nb_oct
    (unaryfunc)           0,                     // nb_hex
};

static PySequenceMethods tumbler_Sequence = {
    (inquiry)             0,       // sq_length
    (binaryfunc)          0,                     // sq_concat
    (intargfunc)          0,                     // sq_repeat
    (intargfunc)          0,         // sq_item
    (intintargfunc)       0,        // sq_slice
    (intobjargproc)       0,                     // sq_ass_item
    (intintobjargproc)    0,                     // sq_ass_slice
};

PyExtensionClass TumblerType = {
    PyObject_HEAD_INIT(NULL)
    0,                                    // ob_size
    "tumbler",                            // tp_name ::= Name of Type, for Printing
    sizeof(TumblerObject),                // tp_basicsize, for Allocation
    0,                                    // tp_itemsize, for Allocation
    // Methods to Implement Standard Operations
    (destructor)          &tumbler_dealloc,      // tp_dealloc
    (printfunc)           0,                     // tp_print
    (getattrfunc)         0,                     // tp_getattr
    (setattrfunc)         0,                     // tp_setattr
    (cmpfunc)             &tumbler_compare,      // tp_compare
    (reprfunc)            &tumbler__repr__,      // tp_repr
    // Method Suites for Standard Classes
    (PyNumberMethods *)   &tumbler_Number,       // tp_as_number
    (PySequenceMethods *) &tumbler_Sequence,     // tp_as_sequence
    (PyMappingMethods *)  0,                     // tp_as_mapping
    // More Standard Operations
    (hashfunc)            &tumbler_hash,         // tp_hash
    (ternaryfunc)         0,                     // tp_call
    (reprfunc)            &tumbler__str__,       // tp_str
    (getattrofunc)        0,                     // tp_getattro
    (setattrofunc)        0,                     // tp_setattro
    // Functions to Access Object as I/O Buffer
    (PyBufferProcs *)     0,                     // tp_as_buffer
    // Flags to Defined Presence of Optional/Expanded Features
    (long)                0,                     // tp_flags
    (char *)              0,                     // tp_doc ::= __doc__ String

    METHOD_CHAIN(tumblerobj_methods),
};

static PyMethodDef module_methods[] = {
    {NULL, NULL}
};

DL_EXPORT(void)
initEnfilade(void) 
{
    PyObject *m, *d;
    char *rev = "$Revision: 1.1 $";

    UNLESS(PyExtensionClassCAPI = PyCObject_Import("ExtensionClass", "CAPI"))
        return;

    TumblerType.tp_getattro = PyExtensionClassCAPI->getattro;
    TumblerType.ob_type     = &PyType_Type;

    m = Py_InitModule4(MODNAME, module_methods, tumbler_module__doc__, (PyObject *) NULL, PYTHON_API_VERSION);

    // Add some symbolic constants to the module
    d = PyModule_GetDict(m);

    PyExtensionClass_Export(d, "tumbler", TumblerType);

    PyDict_SetItemString(d, "__version__", PyString_FromStringAndSize(rev+11,strlen(rev+11)-2));

    if (PyErr_Occurred())
        Py_FatalError("can't initialize module: " MODNAME);
}

