 /**
 * @file  tumblermodule.c
 * @brief Memory-Resident Tumbler Objects
 *
 **/

#include "ExtensionClass.h"
#include <ctype.h>

#include "tumbler.h"

#define Span_Check(op)    ((op)->ob_type == (struct _typeobject *) &SpanType)

staticforward PyTypeObject SpanType;

typedef struct {
    PyObject_HEAD
    TumblerObject *addr;
    TumblerObject *diff;
} SpanObject;

static PyObject *
span_new(PyObject *moduleself, PyObject *args)
{
    SpanObject *span;
    PyObject *initaddr, *initdiff;

    UNLESS(PyArg_ParseTuple(args, "OO:new_span", &initaddr, &initdiff)) return NULL;
    UNLESS(span = PyObject_New(SpanObject, &SpanType)) return NULL;

    if (!Tumbler_Check(initaddr))
        span->addr = (TumblerObject *) tumbler_new(PyString_AsString(initaddr));
    else
        span->addr = (TumblerObject *) initaddr;

    if (!Tumbler_Check(initdiff))
        span->diff = (TumblerObject *) tumbler_new(PyString_AsString(initdiff));
    else
        span->diff = (TumblerObject *) initdiff;

    Py_INCREF(span->addr);
    Py_INCREF(span->diff);

    return (PyObject *) span;
}

static void
span_dealloc(SpanObject *self)
{
    Py_DECREF(self->addr);
    Py_DECREF(self->diff);

//    PyObject_Del(self);
    Py_DECREF(self->ob_type);
    PyMem_DEL(self);
}

    static PyObject *
span__repr__(SpanObject *self)
{
    PyObject *a, *d, *s;
    
    a = tumbler__str__(self->addr);
    d = tumbler__str__(self->diff);

    s = PyString_FromString("span(");
    PyString_ConcatAndDel(&s, a);
    PyString_ConcatAndDel(&s, PyString_FromString(", "));
    PyString_ConcatAndDel(&s, d);
    PyString_ConcatAndDel(&s, PyString_FromString(")"));
    
    return s;
}

    static PyObject *
span__str__(SpanObject *self)
{
    PyObject *a, *d, *s;
    
    a = tumbler__str__(self->addr);
    d = tumbler__str__(self->diff);

    s = PyString_FromString("(");
    PyString_ConcatAndDel(&s, a);
    PyString_ConcatAndDel(&s, PyString_FromString(", "));
    PyString_ConcatAndDel(&s, d);
    PyString_ConcatAndDel(&s, PyString_FromString(")"));
    
    return s;
}

    static TumblerObject *
span_item(SpanObject *self, int i)
{
    switch (i) {
    case 0:  Py_INCREF(self->addr); return self->addr;
    case 1:  Py_INCREF(self->diff); return self->diff;
    default:
        PyErr_SetString(PyExc_IndexError, "span index out of range");
        return NULL;
    }
}

    static PyObject *
span_richcompare(PyObject *v, PyObject *w, int op)
{
    SpanObject *vt;
    TumblerObject *wt, *right;
    int cmp1, cmp2, cmp3;
    PyObject *res;

    if (!Span_Check(v) || !(Span_Check(w) || Tumbler_Check(w))) {
        Py_INCREF(Py_NotImplemented);
        return Py_NotImplemented;
    }

    vt = (SpanObject *) v;
    if (Span_Check(w))  wt = ((SpanObject *) w)->addr;
    else                wt = (TumblerObject *) w;


    cmp1 = tumbler_compare(wt, vt->addr);
//    if (cmp1 == LESSER)
//        return TOMYLEFT;
//    else if (cmp1 == EQUAL)
//        return ONMYLEFTBORDER;

    right = tumbler_add(vt->addr, vt->diff);

    cmp2 = tumbler_compare(wt, right);
    Py_DECREF(right);

//    if (cmp2 == LESS)
//        return THRUME;
//    else if (cmp2 == EQUAL)
//        return ONMYRIGHTBORDER;
//    else
//        return TOMYRIGHT;

    switch (op) {
    case Py_LT: cmp3 = (cmp1 == LESSER);  break; // TOMYLEFT
    case Py_LE: cmp3 = (cmp1 == EQUAL);   break; // ONMYLEFTBORDER
//    case Py_EQ: cmp3 = vs == ws; break;
//    case Py_NE: cmp3 = vs != ws; break;
    case Py_GE: cmp3 = (cmp2 == EQUAL);   break; // ONMYRIGHTBORDER
    case Py_GT: cmp3 = (cmp2 == GREATER); break; // TOMYRIGHT
    default: return NULL; /* cannot happen */
    }

    if (cmp3)  res = Py_True;
    else       res = Py_False;
    Py_INCREF(res);
    return res;
}

static PySequenceMethods span_Sequence = {
    (inquiry)             0,                     // sq_length
    (binaryfunc)          0,                     // sq_concat
    (intargfunc)          0,                     // sq_repeat
    (intargfunc)          &span_item,            // sq_item
    (intintargfunc)       0,                     // sq_slice
    (intobjargproc)       0,                     // sq_ass_item
    (intintobjargproc)    0,                     // sq_ass_slice
};

static PyTypeObject SpanType = {
    PyObject_HEAD_INIT(NULL)
    0,                                    // ob_size
    "span",                               // tp_name ::= Name of Type, for Printing
    sizeof(SpanObject),                   // tp_basicsize, for Allocation
    0,                                    // tp_itemsize, for Allocation
    // Methods to Implement Standard Operations
    (destructor)          span_dealloc,          // tp_dealloc
    (printfunc)           0,                     // tp_print
    (getattrfunc)         0,                     // tp_getattr
    (setattrfunc)         0,                     // tp_setattr
    (cmpfunc)             0,                     // tp_compare
    (reprfunc)            &span__repr__,         // tp_repr
    // Method Suites for Standard Classes
    (PyNumberMethods *)   0,                     // tp_as_number
    (PySequenceMethods *) &span_Sequence,        // tp_as_sequence
    (PyMappingMethods *)  0,                     // tp_as_mapping
    // More Standard Operations
    (hashfunc)            0,                     // tp_hash
    (ternaryfunc)         0,                     // tp_call
    (reprfunc)            &span__str__,          // tp_str
    (getattrofunc)        0,                     // tp_getattro
    (setattrofunc)        0,                     // tp_setattro
    // Functions to Access Object as I/O Buffer
    (PyBufferProcs *)     0,                     // tp_as_buffer
    // Flags to Defined Presence of Optional/Expanded Features
    (long)                0,                     // tp_flags
    (char *)              0,                     // tp_doc ::= __doc__ String
    (traverseproc)        0,                     // tp_traverse
    (inquiry)             0,                     // tp_clear
    (richcmpfunc)         &span_richcompare,     // tp_richcompare
};

