#include <stdio.h>

//export LD_LIBRARY_PATH=../lib

#include "tumbler.h"

extern bool test_tumblers();

int debug; // Part of Main

/**********************************************************************
 *
 **********************************************************************/
    int
main(int argc, char *argv[])
{
    test_tumblers();
}

/**********************************************************************
 *
 **********************************************************************/
int qerror(char *message) { return 1; }

class Session;
bool getnum(Session *sess, int *numptr) { return true; }

class CoreCrum;
void dump(CoreCrum *ptr) {}

void dumpwholetree(CoreCrum *ptr) {}

void putnum(FILE *outfile, int num) {}
