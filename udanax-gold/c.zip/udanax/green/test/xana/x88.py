"""An object-based API to the Udanax 88.1 FeBe protocol."""

# Copyright 1999 by Ka-Ping Yee.  All rights reserved.
# This file is part of the Udanax Green distribution.
#
# Permission is hereby granted, free of charge, to any person obtaining
# a copy of this software and associated documentation files (the
# "Software"), to deal in the Software without restriction, including
# without limitation the rights to use, copy, modify, merge, publish,
# distribute, sublicense, and/or sell copies of the Software, and to
# permit persons to whom the Software is furnished to do so, subject to
# the following conditions: 
# 
# The above copyright notice and this permission notice shall be
# included in all copies or substantial portions of the Software. 
# 
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
# EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
# MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
# IN NO EVENT SHALL Ka-Ping Yee OR Udanax.com BE LIABLE FOR ANY CLAIM,
# DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR
# OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR
# THE USE OR OTHER DEALINGS IN THE SOFTWARE. 
# 
# Except as contained in this notice, "Udanax", "Udanax.com", and the
# transcluded-U logo shall not be used in advertising or otherwise to
# promote the sale, use or other dealings in this Software without
# prior written authorization from Udanax.com.

import sys, os, string, socket

from tumblers import *

# ==================================================== OBJECT TYPES AND I/O

# -------------------------------------------------- helpers for comparison
def cmpid(a, b):
    """Compare two objects by their Python id."""
    if id(a) > id(b): return 1
    if id(a) < id(b): return -1
    return 0

def istype(klass, object):
    """Return whether an object is a member of a given class."""
    try: raise object
    except klass: return 1
    except: return 0

# ------------------------------------------------------------- basic types
def Number_write(data, stream):
    """Write a number to an 88.1 protocol stream."""
    stream.write("%d~" % data)

def Number_read(stream):
    """Read a number from an 88.1 protocol stream."""
    number = 0
    chunk = stream.readchunk()
    return string.atoi(chunk)

def String_write(data, stream):
    """Write a string to an 88.1 protocol stream."""
    stream.write("t%d~" % len(data))
    stream.write(data)

def String_read(stream):
    """Read a string from an 88.1 protocol stream."""
    ch = stream.read(1)
    if ch != "t":
        raise ValueError, "starting flag missing in string read"
    length = Number_read(stream)
    return stream.read(length)

def Content_read(stream):
    """Read a string or a link from an 88.1 protocol stream."""
    ch = stream.read(1)
    if ch == "t":
        length = Number_read(stream)
        return stream.read(length)
    elif ch in string.digits:
        return Address_read(stream, ch)
    else:
        raise ValueError, "bad char \\x%x in content read" % ord(ch)

def strl(longnum):
    """Convert a long integer to a string without the trailing L."""
    return str(longnum)[:-1]

# ================================================== MAIN SESSION INTERFACE

# --------------------------------------------------------------- constants
# addresses
NOWHERE = Address()

# spans
NOWIDTH = Offset()

# specifiers
NOSPECS = SpecSet([])

# exceptions
XuError = "UdanaxError"

# access modes
(READ_ONLY, READ_WRITE) = (1, 2)

# copy modes
(CONFLICT_FAIL, CONFLICT_COPY, ALWAYS_COPY) = (1, 2, 3)

# link ends
(LINK_SOURCE, LINK_TARGET, LINK_TYPE) = (1, 2, 3)

# conventional link type addresses
LINK_DOCID = Address(1, 1, 0, 1, 0, 2)
JUMP_TYPE = VSpec(LINK_DOCID, [Span(Address(2, 1), Offset(0, 1))])
QUOTE_TYPE = VSpec(LINK_DOCID, [Span(Address(2, 2), Offset(0, 1))])
FOOTNOTE_TYPE = VSpec(LINK_DOCID, [Span(Address(2, 3), Offset(0, 1))])
MARGIN_TYPE = VSpec(LINK_DOCID, [Span(Address(2, 4), Offset(0, 1))])

LINK_TYPES = [JUMP_TYPE, QUOTE_TYPE, FOOTNOTE_TYPE, MARGIN_TYPE]
TYPE_NAMES = {JUMP_TYPE: "jump", QUOTE_TYPE: "quote",
              FOOTNOTE_TYPE: "footnote", MARGIN_TYPE: "margin"}

TYPES_BY_NAME = {}
for spec in LINK_TYPES:
    TYPES_BY_NAME[TYPE_NAMES[spec]] = spec

# ------------------------------------------------------------------ XuConn
class XuConn:
    """Methods for sending and receiving objects on a stream.  The
    stream must implement the three methods read, write, and close."""

    def __init__(self, stream):
        self.stream = stream

    def __repr__(self):
        return "<XuConn on %s>" % repr(self.stream)

    # protocol

    def handshake(self):
        """Perform the FeBe protocol handshake to open a session."""
        self.stream.write("\nP0~")
        while 1:
            if self.stream.read(1) == "\n": break
        if self.stream.read(2) != "P0":
            raise ValueError, "back-end does not speak 88.1 protocol"
        if self.stream.read(1) not in "~\n":
            raise ValueError, "back-end does not speak 88.1 protocol"

    def close(self):
        self.stream.close()

    # reading and writing objects

    def Number(self): return Number_read(self.stream)
    def String(self): return String_read(self.stream)
    def Content(self): return Content_read(self.stream)
    def Address(self): return Address_read(self.stream)
    def Offset(self): return Offset_read(self.stream)
    def Span(self): return Span_read(self.stream)
    def VSpec(self): return VSpec_read(self.stream)
    def SpecSet(self): return SpecSet_read(self.stream)

    def write(self, object):
        """Write to the connection an integer, string, Address, Offset,
        Span, VSpec, SpecSet, or list of such objects."""
        if type(object) is type(1):
            Number_write(object, self.stream)
        elif type(object) is type("a"):
            String_write(object, self.stream)
        elif type(object) is type([]):
            Number_write(len(object), self.stream)
            for item in object: self.write(item)
        else:
            object.write(self.stream)

    # issuing commands

    def command(self, code, *args):
        """Issue a command with the given order code and arguments."""
        Number_write(code, self.stream)
        for arg in args: self.write(arg)
        try:
            response = self.Number()
        except ValueError:
            raise XuError, "error response to %d from back-end" % code
        if response != code:
            raise XuError, "non-matching response to %d from back-end" % code

# --------------------------------------------------------------- XuSession
class XuSession:
    """A session conversing with an Udanax back-end server across an x88
    connection object.  The XuConn must have been just freshly created.
    (We don't create the XuConn here to allow the application to supply
    an instance of a customized subclass of XuConn if it so desires.)"""

    def __init__(self, conn):
        self.xc = conn
        self.xc.handshake()
        self.open = 1

    def __repr__(self):
        if self.open:
            return "<XuSession on %s>" % repr(self.xc.stream)
        else:
            return "<XuSession terminated>"

    # creation and access

    def create_document(self):
        self.xc.command(11)
        return self.xc.Address()

    def create_version(self, docid):
        self.xc.command(13, docid)
        return self.xc.Address()

    def open_document(self, docid, access, copy):
        self.xc.command(35, docid, access, copy)
        return self.xc.Address()

    def close_document(self, docid):
        self.xc.command(36, docid)

    def create_link(self, docid, sourcespecs, targetspecs, typespecs):
        self.xc.command(27, docid, sourcespecs, targetspecs, typespecs)
        return self.xc.Address()

    # content retrieval

    def retrieve_vspan(self, docid):
        self.xc.command(14, docid)
        return VSpan(docid, self.xc.Span())

    def retrieve_vspanset(self, docid):
        self.xc.command(1, docid)
        spans = []
        for i in range(self.xc.Number()):
            spans.append(self.xc.Span())
        return VSpec(docid, spans)

    def retrieve_contents(self, specset):
        self.xc.command(5, specset)
        data = []
        for i in range(self.xc.Number()):
            data.append(self.xc.Content())
        return data

    def retrieve_endsets(self, specset):
        self.xc.command(28, specset)
        sourcespecs = self.xc.SpecSet()
        targetspecs = self.xc.SpecSet()
        typespecs = self.xc.SpecSet()
        return sourcespecs, targetspecs, typespecs

    # connection retrieval

    def find_links(self, sourcespecs, targetspecs=NOSPECS,
                         typespecs=NOSPECS, homedocids=[]):
        self.xc.command(30, sourcespecs, targetspecs, typespecs, homedocids)
        links = []
        for i in range(self.xc.Number()):
            links.append(self.xc.Address())
        return links
    
    def follow_link(self, linkid, linkend):
        try:
            self.xc.command(18, linkend, linkid)
        except XuError:
            return NOSPECS
        else:
            return self.xc.SpecSet()

    def compare_versions(self, specseta, specsetb):
        self.xc.command(10, specseta, specsetb)
        sharedspans = []
        for i in range(self.xc.Number()):
            starta, startb = self.xc.Address(), self.xc.Address()
            width = self.xc.Offset()
            doca, locala = starta.split()
            docb, localb = startb.split()
            sharedspans.append(VSpan(doca, Span(locala, width)),
                               VSpan(docb, Span(localb, width)))
        return collapse_sharedspans(sharedspans)

    def find_documents(self, specset):
        self.xc.command(22, specset)
        docids = []
        for i in range(self.xc.Number()):
            docids.append(self.xc.Address())
        return docids

    # editing

    def insert(self, docid, vaddr, strings):
        self.xc.command(0, docid, vaddr, strings)

    def vcopy(self, docid, vaddr, specset):
        self.xc.command(2, docid, vaddr, specset)

    def delete(self, docid, start, end):
        self.xc.command(3, docid, [start, end])

    def pivot(self, docid, start, pivot, end):
        self.xc.command(3, docid, [start, pivot, end])

    def swap(self, docid, starta, enda, startb, endb):
        self.xc.command(3, docid, [starta, enda, startb, endb])

    def remove(self, docid, vspan):
        self.xc.command(12, docid, vspan)

    # session control

    def quit(self):
        self.xc.command(16)
        self.xc.close()
        self.open = 0

    # administration

    def account(self, acctid):
        self.xc.command(34, acctid)

    def create_node(self, acctid):
        self.xc.command(38, acctid)
        return self.xc.Address()


def collapse_sharedspans(sharedspans):
    """The results of a comparison are sometimes returned from the back-end
    with several adjacent spans that could be collapsed into a single span.
    This routine tries to work around that limitation."""
    result = []
    enda, endb = None, None
    for spana, spanb in sharedspans:
        starta, startb = spana.start(), spanb.start()
        width = spana.span.width
        doca, locala = spana.docid, spana.span.start
        docb, localb = spanb.docid, spanb.span.start
        if starta == enda and startb == endb: # collapse with last span
            width = lastwidth + width
            spana = VSpan(doca, Span(lastlocala, width))
            spanb = VSpan(docb, Span(lastlocalb, width))
            result[-1:] = [(spana, spanb)]
        else:
            lastlocala, lastlocalb = locala, localb
            spana = VSpan(doca, Span(locala, width))
            spanb = VSpan(docb, Span(localb, width))
            result.append((spana, spanb))
        enda, endb = spana.end(), spanb.end()
        lastwidth = width
    return result

# ================================ STREAMS OVER WHICH TO HOLD FEBE SESSIONS

class XuStream:
    """Abstract class specifying the stream interface."""
    def __init__(self, *args):
        raise TypeError, "abstract class cannot be instantiated"

    def read(self, length): pass
    def write(self, data): pass
    def close(self): pass

    def readchunk(self):
        chars = []
        while 1:
            ch = self.read(1)
            if not ch: raise XuError, "stream closed prematurely"
            if ch in ['', '\n', '~']: break
            if ch == "?": raise XuError, "error response from back-end"
            chars.append(ch)
        return string.join(chars, '')

# -------------------------------------------------------------- FileStream
class FileStream(XuStream):
    """Stream interface to two file descriptors."""

    def __init__(self, input, output=None):
        if not output: output = input
        self.input = input
        self.output = output
        self.open = 1

    def __repr__(self):
        result = self.__class__.__name__
        if self.open:
            if self.input is not self.output:
                result = result + " from %s" % repr(self.input)
            return "<%s to %s>" % (result, repr(self.output))
        else:
            return "<%s closed>" % result

    def read(self, length):
        return self.input.read(length)

    def write(self, data):
        self.output.write(data)

    def close(self):
        self.input.close()
        if self.output is not self.input: self.output.close()
        self.open = 0

# --------------------------------------------------------------- TcpStream
class TcpStream(XuStream):
    """Stream interface to a TCP connection."""

    def __init__(self, hostname, port):
        self.host = hostname
        self.port = port
        self.socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.socket.connect(hostname, port)
        self.open = 1

    def __repr__(self):
        result = self.__class__.__name__
        if self.open:
            return "<%s to %s port %d>" % (result, self.host, self.port)
        else:
            return "<%s closed>" % result

    def read(self, length):
        return self.socket.recv(length)

    def write(self, data):
        self.socket.send(data)

    def close(self):
        self.socket.close()
        self.open = 0

# -------------------------------------------------------------- PipeStream
class PipeStream(XuStream):
    """Stream interface to a piped shell command."""

    def __init__(self, command):
        self.fifo = "pyxi.%d" % os.getpid()
        try: os.unlink(self.fifo)
        except: pass
        os.mkfifo(self.fifo)

        self.command = command
        self.inpipe = os.popen(command + " < " + self.fifo)
        self.outpipe = open(self.fifo, "w")
        self.open = 1

    def __repr__(self):
        result = self.__class__.__name__
        if self.open:
            return "<%s to %s>" % (result, self.command)
        else:
            return "<%s closed>" % result

    def __del__(self):
        os.unlink(self.fifo)

    def read(self, length):
        return self.inpipe.read(length)

    def write(self, data):
        self.outpipe.write(data)
        self.outpipe.flush()

    def close(self):
        self.inpipe.close()
        self.outpipe.close()
        try: os.unlink(self.fifo)
        except: pass
        self.open = 0

# ====================================================== DEBUGGING WRAPPERS
def shortrepr(object):
    if type(object) is type([]):
        return "[" + string.join(map(shortrepr, object), ", ") + "]"
    elif type(object) is type(()):
        return "(" + string.join(map(shortrepr, object), ", ") + ")"
    elif type(object) is type(''):
        if len(object) > 20: return repr(object[:20]) + "..."
        else: return repr(object)
    else:
        return str(object)

debugindent = {}
debugmidline = {}

class MethodWrapper:
    def __init__(self, name, method, base, log):
        self.name = name
        self.method = method
        self.base = base
        self.log = log

    def __call__(self, *args):
        indent = debugindent[self.log]
        if debugmidline[self.log]:
            self.log.write("\n")

        self.log.write("%s%s \x1b[32m%s\x1b[0m%s: " %
                       (indent, repr(self.base), self.name, shortrepr(args)))
        self.log.flush()
        debugmidline[self.log] = 1

        debugindent[self.log] = indent + "  "

        try:
            result = apply(self.method, args)

            if not debugmidline[self.log]:
                basename = self.base.__class__.__name__
                self.log.write("%s%s.\x1b[32m%s\x1b[0m: " %
                               (indent, basename, self.name))
            self.log.write("\x1b[36m%s\x1b[0m\n" % shortrepr(result))
            self.log.flush()
            debugmidline[self.log] = 0

        finally:
            debugindent[self.log] = indent
        return result

class DebugWrapper:
    def __init__(self, base, log):
        self.__dict__["__base__"] = base
        self.__dict__["__log__"] = log
        if not debugindent.has_key(log):
            debugindent[log] = ""
            debugmidline[log] = 0

    def __getattr__(self, name):
        base = self.__dict__["__base__"]
        log = self.__dict__["__log__"]
        value = getattr(base, name)
        if callable(value) and name[:2] != "__":
            return MethodWrapper(name, value, base, log)
        else:
            return value

    def __setattr__(self, name, value):
        base = self.__dict__["__base__"]
        setattr(base, name, value)
                
# =============================================================== FUNCTIONS
def tcpconnect(hostname, port):
    return XuSession(XuConn(TcpStream(hostname, port)))

def pipeconnect(command):
    return XuSession(XuConn(PipeStream(command)))
   
def testconnect():
    return XuSession(XuConn(FileStream(sys.stdin, sys.stdout)))
