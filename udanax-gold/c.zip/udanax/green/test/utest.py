from xana.x88 import *
#from xana.tumblers import *

__doc__ = """

  A numbering system that permits addressing within documents so that
  material may be inserted at any point without renumbering.

  t = Tumbler("1.2.3.4.5") ::= as a string
  t = Tumbler([1,2,3,4,5]) ::= as a list of tumbler digits
  t = Tumbler(1,2,3,4,5)   ::= as an argument set of tumbler digits
      digit = t[n] # Extract a Specific Digit
      n = len(t)  # Count of Digits
      if !t:  # Test if -Any- Digit is Non-Zero
      t3 = t1 + t2
      t3 = t1 - t2
      if t1 > t2:  # Compare Two Tumblers
      h = hash(t)

  An address within the Udanax object space.  Immutable.

  a = Address("1.2.3.4.5") ::= as a string
  a = Address([1,2,3,4,5]) ::= as a list of tumbler digits
  a = Address(1,2,3,4,5)   ::= as an argument set of tumbler digits
      digit = a[n] # Extract a Specific Digit
      n = len(a)  # Count of Digits
      if !a:  # Test if -Any- Digit is Non-Zero
      a3 = a1 + o2
      o3 = a1 - a2
      if t1 > t2:  # Compare Two Tumblers
      h = hash(t)
      docid, doclocal = split()

      a = globalize(otheraddress)
      o = globalize(otheroffset)
      s = globalize(otherspan)

      a = localize(otheraddress)
      o = localize(otheroffset)
      s = localize(otherspan)

  An offset between addresses in the Udanax object space.  Immutable.

  o = Offset("1.2.3.4.5") ::= as a string
  o = Offset([1,2,3,4,5]) ::= as a list of tumbler digits
  o = Offset(1,2,3,4,5)   ::= as an argument set of tumbler digits
      digit = o[n] # Extract a Specific Digit
      n = len(o)  # Count of Digits
      if !o:  # Test if -Any- Digit is Non-Zero
      o3 = o1 + o2
      o3 = o1 - o2
      if o1 > o2:  # Compare Two Tumblers
      h = hash(o)

  # A Range of Objects in the Global Address Space; Immutable.

  s = Span(<starting address>, <ending address>)
  s = Span(<starting address>, <offset>)
      width = len(s)
      if !s:  # Test if width is non-zero or not
      if s1 > s2:  # Compare Two Spans
      h = hash(s)
      s3 = s1 & s2
      if address in s:
      if span in s:
      if vspan in s:
      s3 = s.end()   # Return First Address after This Span
      vspan = localize()

  A range within a given document.  Immutable.
  vs = VSpan(docid_address, local_span)
      if vs1 > vs2:  # Compare Two VSpans
      h = hash()
      vs3 = vs1 & vs2
      s = vs.start()
      s = vs.end()
      if spec in vs:
      s = globalize()

  A possibly discontinuous set of Udanax objects.  Mutable.
  ss = SpecSet([s], [s], [s], [s])
  ss = SpecSet(s, s, s, s, s)
      n = len(ss)   # Count of Specs in Set
      spec = ss[n]
      vspec = ss[n]
      if ss1 != ss2:  # Only useful for equality
      clear()
      ss.append(spec)
      ss.append(vspec)
"""


def verify(result, expected=1):
    if result != expected:
        raise ValueError, "result " + repr(result) + \
                          " did not match " + repr(expected)
    print "ok"

def main():
    print "Beginning Session...",
    sess = XuSession(XuConn(TcpStream('vault.timecastle.net', 55146)))
    print "Done."

    print "Creating our Site's Node Address...",
    nodeid = sess.create_node(Address(1))
    print nodeid, "Done."

    print "Creating our Site's Node Address...",
    nodeid = sess.create_node(Address(1,1))
    print nodeid, "Done."

    print "Creating our User's Account...",
    acctid = sess.create_node(Address(1,1,0,1))
    print acctid, "Done."

    docid, doclocal = acctid.split()
    print "docid = %s" % docid
    print "doclocal = %s" % doclocal

    print "Establishing our Account ID...",
    sess.account(acctid)
    print "Done."


    # vspec = sess.retrieve_vspanset(docid)
    # data = sess.retrieve_contents(specset)
    # srcspecs, tgtspecs, typespecs = sess.retrieve_endsets(specset)

    print "Creating a New Document...",
    docid = sess.create_document()
    print docid, "Done."

    print "Opening the New Document...",
    docid = sess.open_document(docid, READ_WRITE, CONFLICT_FAIL)
    print docid, "Done."

#        docid = self.xs.open_document(docid, mode, x88.CONFLICT_COPY)
#
#        self.textvspan = self.linkvspan = None
#        for vspan in self.xs.retrieve_vspanset(docid):
#            span = vspan.span
#            if vspan.span.start[0] == 1:
#                # This will break if the back-end returns more than one span.
#                self.textvspan = vspan.span
#            elif vspan.span.start[0] == 2:
#                self.linkvspan = vspan.span
#            else:
#                warn("ignoring vspan %s" % vspan)
#
#        if self.textvspan is not None:
#            textvspec = x88.VSpec(docid, [self.textvspan])
#            self.textspec = x88.SpecSet(textvspec)
#        else:
#            warn("document contains no data")

    vspan = sess.retrieve_vspan(docid)
    print vspan



#    print "Opening the New Document...",
#    docid = sess.open_document(docid, READ_WRITE, CONFLICT_FAIL)
#    print docid, "Done."

#    vaddr = Span(Address(1), Address(1))
#    sess.insert(docid, vaddr, "Testing Testing 1 2 3")
#
#    sess.close_document(docid)

    # doc = sess.create_document()
    # doc = sess.create_version(docid)
    # doc = sess.open_document(docid, READ_ONLY|READ_WRITE, CONFLICT_FAIL|CONFLICT_COPY|ALWAYS_COPY)
    # sess.close_document(docid)



#
#    docid = sess.create_node(Address(1,42,0,24))
#    print docid
##    sess.account(acctid)
#    print "Done."
#
#    docid = sess.create_document()
#    print "Created Document ", docid
#
#    specset = SpecSet(Span(Address(1,1,0,1), Offset(1)))
#    docids = sess.find_documents(specset)
#    print docids
#
#    print "Retrieving All Known VSpans...",
#    vspec = sess.retrieve_vspanset(Address(1,1,0,1))
#    print vspec
#    print "Done."
#
#
#    d = sess.retrieve_vspanset(Address(1,1,0,1,0,1))
#    print d

    # doc = sess.create_document()
    # doc = sess.create_version(docid)
    # doc = sess.open_document(docid, READ_ONLY|READ_WRITE, CONFLICT_FAIL|CONFLICT_COPY|ALWAYS_COPY)
    # sess.close_document(docid)
    # doc = create_link(docid, sourcespecs, targetspecs, typespecs)

    # vspan = sess.retrieve_vspan(docid)
    # vspec = sess.retrieve_vspanset(docid)
    # data = sess.retrieve_contents(specset)
    # srcspecs, tgtspecs, typespecs = sess.retrieve_endsets(specset)

    # [links] = sess.find_links(srcspecs, tgtspecs, typespecs, homedocids)
    # specset = sess.follow_link(linkid, linkend)
    # spans = sess.compare_versions(specseta, specsetb)
    # [docids] = sess.find_documents(specset)

    # sess.insert(docid, vaddr, strings)
    # sess.vcopy(docid, vaddr, specset)
    # sess.delete(docid, start, end)
    # sess.pivot(docid, start, pivot, end)
    # sess.swap(docid, starta, enda, startb, endb)
    # sess.remove(docid, vspan)

    # sess.quit()

    # sess.account(acctid)
    # docid = sess.create_node(acctid)

    import time
    time.sleep(5)

    print "Ending Session...",
    sess.quit()
    print "Done."





#    doca = Address(1,1,0,1,0,1)
#
#    mydoca  = sess.open_document(doca, READ_ONLY, CONFLICT_COPY)
#    vspan   = Span(Address(1,1), Offset(0,1500))
#    specset = SpecSet(VSpec(mydoca, [vspan]))
#    adata   = sess.retrieve_contents(specset)
#
#    docspan = Span(Address(1,1), Offset(1))
#    specset = SpecSet(VSpec(mydoca, [docspan]))
#    asource, atarget, atype = sess.retrieve_endsets(specset)
#
#    vspanset = sess.retrieve_vspanset(mydoca)
#
#    charspan = Span(Address(1,513), Offset(0,1))
#    specfrom = SpecSet(VSpec(mydoca, [charspan]))
#    links    = sess.find_links(specfrom)
#
#    type   = sess.follow_link(links[0], LINK_TYPE)
#    target = sess.follow_link(links[0], LINK_TARGET)
#
#    docb    = target[0].docid
#    mydocb  = sess.open_document(docb, READ_ONLY, CONFLICT_COPY)
#    vspan   = Span(Address(1,1), Offset(0,1500))
#    specset = SpecSet(VSpec(mydocb, [vspan]))
#    bdata   = sess.retrieve_contents(specset)
#
#    docspan = Span(Address(1,1), Offset(1))
#    specset = SpecSet(VSpec(mydocb, [docspan]))
#    bsource, btarget, btype = sess.retrieve_endsets(specset)

if __name__ == "__main__":
    main()

