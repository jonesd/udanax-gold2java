from xana.tumblers import *

def verify(result, expected=1):
    if result != expected:
        raise ValueError, "result " + repr(result) + \
                          " did not match " + repr(expected)
    print "ok"

# tumbler arithmetic
a = Address([2,3,4])
b = Address(2,3,4)
verify(a, b)

print a, b

c = Offset([0,0,1])
d = a + c
verify(a != d)
verify(d > a)
verify(d, Address(2,3,5))

print c, d

# span comparison
s = Span(a, d)
t = Span(a, c)
verify(s, t)

print s, t

d = Address(1,0,1,0,1,2)
v = VSpec(d, [s])
w = Span(Address(1,0,1,0,1,2,0,2,3,4), Address(1,0,1,0,1,2,0,2,3,5))
verify(v[0].globalize(), w)
verify(w.start.split(), (d, b))

print d, v, w
