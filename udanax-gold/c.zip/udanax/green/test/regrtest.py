#!/usr/bin/python

import sys,os
import test.regrtest

test.regrtest.STDTESTS = []
test.regrtest.NOTTESTS = []

if __name__ == '__main__':
    d = sys.argv[0]
else:
    d = __file__

sys.exit(test.regrtest.main(None, os.path.dirname(d) or os.curdir))
