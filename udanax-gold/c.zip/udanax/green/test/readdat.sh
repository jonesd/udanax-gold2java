#!/bin/sh

export LD_LIBRARY_PATH=lib

#rm enf.enf
./xumain <<EOF
34
1.1.0.1
21
cat test/data/intro
21
cat test/data/index
21
cat test/data/brochure
21
cat test/data/xudesc
21
cat test/data/conti.d
21
cat test/data/contdoc
21
cat test/data/contout
21
cat test/data/demo1
21
cat test/data/demo2
21
cat test/data/demo3
21
cat test/data/demo4
21
cat test/data/Addresses
21
cat test/data/Bizplan1
21
cat test/data/Bizplan2
21
cat test/data/Bizplan3
21
cat test/data/Bizplan4
21
cat test/data/Bizplan5
21
cat test/data/Bizplan6
21
cat test/data/Bizplan7
21
cat test/data/Bizplan8
21
cat test/data/Company
21
cat test/data/Datamation
21
cat test/data/Feidoc
21
cat test/data/Formats.bnf
21
cat test/data/Glossary
21
cat test/data/Outln
21
cat test/data/Overview
21
cat test/data/Propaganda
21
cat test/data/ReplacingA
21
cat test/data/ReplacingB
21
cat test/data/ReplacingC
21
cat test/data/ReplacingD
21
cat test/data/Requestlist
21
cat test/data/Spanstuff
21
cat test/data/Suespaper
21
cat test/data/Tumblers
21
cat test/data/Xuinfo.bnf
21
cat test/data/glossary.txt
16
EOF

