#include <iostream>
#include <iomanip>
#include <strstream>

#include "tumbler.h"

static char *values[] = {
    "0",
    "0.1",
    "0.0.1",
    "1.1",
    "1.2.123456789",
    "1.2.3.4.5.6.7.8.9.10.11",
    NULL
};

static bool test_conversion(const char *sin, char *smid, int smidlen, char *sout, int soutlen);
static bool test_assignment(const char *sin, char *sout, int soutlen);

    bool
test_tumblers()
{
    char **p, **q;

    cout << "---------- Regression Testing: tumblers ----------" << endl << endl;

//    Tumbler t;
    
//    , t2(0), t3("1.2.3");

//    cout << "Enter a Tumbler: ";
//    cin >> t;
//
//    cout << endl;
//    cout << t << endl;
//
//    cout << "t2=" << t2 << endl;
//    cout << "t3=" << t3 << endl;

    cout.setf(ios::scientific);
//    cout << t << endl; 

    cout.unsetf(ios::scientific);

//    ostrstream is(s);
//
//    is >> *this;
//
//    { ostrstream is("1.2.3")sTumbler t("1.2.3"); 

    // Verify the Ability to Convert Tumblers to/from ASCII Text
    // ---------------------------------------------------------

    cout << endl << "Verify Ability to Convert Tumblers to/from ASCII" << endl;

    p = values;
    while (*p) {
        char temp[100], temp2[100];
        if (test_conversion(*p, temp, sizeof(temp), temp2, sizeof(temp2)))
            cout << "  Passed: " << *p << " --> " << temp << " --> " << temp2 << endl;
        else
            cout << "  FAILED: " << *p << " --> " << temp << " --> " << temp2 << endl;

        p++;
    }

    // Verify the Ability to Assign Tumblers To Each Other
    // ---------------------------------------------------

    cout << endl << "Verify Ability to Assign Tumblers To Each Other" << endl;

    p = values;
    while (*p) {
        char temp[100];
        if (test_assignment(*p, temp, sizeof(temp)))
            cout << "  Passed: " << temp << " = " << *p << endl;
        else
            cout << "  FAILED: " << temp << " = " << *p << endl;

        p++;
    }

    // Verify the Ability to Compare Tumblers To Each Other
    // ----------------------------------------------------

    cout << endl << "Verify Ability to Compare Tumblers To Each Other" << endl;

    p = values;
    while (*p) {
        q = values;
        while (*q) {
            Tumbler t1(*p), t2(*q);

            bool f = (t1 == t2);

            if (p == q) {
                if (f)  cout << "  Passed: ";
                else    cout << "  FAILED: ";
            } else {
                if (f)  cout << "  FAILED: ";
                else    cout << "  Passed: ";
            }
            cout << f << " :: " << t1 << " == " << t2 << endl;


            f = (t1 != t2);

            if (p == q) {
                if (f)  cout << "  FAILED: ";
                else    cout << "  Passed: ";
            } else {
                if (f)  cout << "  Passed: ";
                else    cout << "  FAILED: ";
            }
            cout << f << " :: " << t1 << " != " << t2 << endl;


            f = (t1 > t2);

//            if (p == q) {
                if (f)  cout << "  FAILED: ";
                else    cout << "  Passed: ";
//            } else {
//                if (f)  cout << "  Passed: ";
//                else    cout << "  FAILED: ";
//            }
            cout << f << " :: " << t1 << " > " << t2 << endl;




            q++;
        }
        p++;
    }

    // Verify the Ability to Add Tumblers To Each Other
    // ------------------------------------------------

    cout << endl << "Verify Ability to Add Tumblers To Each Other" << endl;

    p = values;
    while (*p) {
        q = values;
        while (*q) {
            StreamAddr t1(*p);

            if (!t1.iszero()) {
                StreamDiff t2(*q);

                StreamAddr t3 = t1 + t2;

//            if (p == q) {
//                if (f)  cout << "  Passed: ";
//                else    cout << "  FAILED: ";
//            } else {
//                if (f)  cout << "  FAILED: ";
//                else    cout << "  Passed: ";
//            }
                cout << t3 << " :: " << t1 << " + " << t2 << endl;
            }

            q++;
        }
        p++;
    }

    cout << endl;
    return true;
}

    static bool
test_conversion(const char *sin, char *smid, int smidlen, char *sout, int soutlen)
{
    Tumbler t1, t2;

    istrstream is1(sin);
    is1.unsetf(ios::scientific);
    is1 >> t1;

    ostrstream os1(smid, smidlen);
    os1.setf(ios::scientific);
    os1 << t1 << ends;

    istrstream is2(smid);
    is2.setf(ios::scientific);
    is2 >> t2;

    ostrstream os2(sout, soutlen);
    os2.unsetf(ios::scientific);
    os2 << t2 << ends;

    if (is1.fail() || os1.fail() || is2.fail() || os2.fail())
        return false;

    return strcmp(sin, sout) == 0;
}

    static bool
test_assignment(const char *sin, char *sout, int soutlen)
{
    Tumbler t1(sin);
    
    Tumbler t2 = t1;

    ostrstream os(sout, soutlen);
    os << t2 << ends;

    if (os.fail())
        return false;

    return strcmp(sin, sout) == 0;
}
