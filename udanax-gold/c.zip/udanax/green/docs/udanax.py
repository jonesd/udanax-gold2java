struct typetask {
    FILE              *inp, *outp, *errp;
    typetthingheader  *tempspacehead; /* doubly linked talloc space so */
    typetthingheader  *tempspacetail; /* that single items can be freed */
    tumbler            account;
    bool               charinbuff;
    char               charbuff;
};

struct PLAYER {
    char    *name;          /* Player's name        */
    INT     userid;         /* player's user id number      */
    INT     wantsout;       /* Quit after this hand?        */
    INT     socket;         /* To communicate with player on*/
    FILE    *inp;
    FILE    *outp;
    tumbler account;        /* xanadu host and account tumbler */
};

sess    = Session(username, password)
              username
              account_tumbler

docobj  = sess.Document(docid {, open=1} )
node    = sess.nodeid()
docobj  = docobj.open(RO|RW, copyiflocked)
          docobj.close()

docobj  = sess.NewVersion(docid)


    # Document Topology Discovery
    # ---------------------------
(tumbler, tumbler) = docobj.span( {subset=BYTES|LINKS} )
[(tumbler, tumbler) {, (tumbler, tumbler)...}] = docobj.spans( {subspan} )

[links] = sess.findlinks( [ (typeset, fromset, toset, threeset) ] )


    # Document Content Retrieval/Manipulation
    # ---------------------------------------
linkid  = docobj.NewLink( [ (typeset, fromset, toset, threeset) ] )

    docobj.append(text)
    docobj.insert(vspan, text)
    docobj.copy(vspecset, vspan)
    docobj.remove(vspanset)
    docobj.swap(vspecset, vspecset)
    docobj.move(vspecset, vspecset)
    docobj.bytes[n:n]
nbytes = len(docobj.bytes)
    docobj.links[n:n]
nlinks = len(docobj.links)

    # Query Attributes of a Link Object
    # ---------------------------------
#endpoints = len(linkobj)
endset     = linkobj[n]
           = linkobj.keys() # returns symbolic names of endpoints
	   = linkobj['from'].append( (tumbler, tumbler) ]

    # Query Attributes of a Document Object
    # -------------------------------------
tum     = docobj.id
bool    = docobj.is_open


    # Add/Query/Remove User Accounts
    # ------------------------------
acctobj = sess.NewAccount(username, password)
acctobj = sess.Account(account)

    # Tumblers
    # --------
tum     = Tumbler(id)
node    = tum.node
account = tum.owner
docid   = tum.documentid
verid   = tum.versionid
id      = tum.id
tuple   = tum.digits
tuple   = tum.fields


#define RETRIEVEV                   5
#define NAVIGATEONHT                9
#define SHOWRELATIONOF2VERSIONS    10
#define FINDDOCSCONTAINING         22
#define RETRIEVEENDSETS            28
#define FINDNUMOFLINKSFROMTOTHREE  29
#define FINDLINKSFROMTOTHREE       30
#define FINDNEXTNLINKSFROMTOTHREE  31




 

 

 
Text, link ids, and document ids are 
retrieved with: 

                - RETRIEVEV 

 The topology can be examined with 
the topology retrieval operations: 

 
                - RETRIEVEDOCVSPAN 
                - RETRIEVEDOCVSPANSET 

 
     It is useful when  dealing  with 
a  document  to  know  how  much 
material  is  involved.  In the case 
of a very small document, a front- 
end may want to retrieve all of the 
text at  once,  where  in  a  large 
document, only small pieces will be 
retrieved at any one time.  This is 
one use for the topological retrieval 
operations. 

RETRIEVEV <spec set> 

 
     This retrieves the document ids, 
text,  and  link  ids  that  are 
specified by the request.  The 
information is returned in an order 
that corresponds to the order of the 
spec set, not in the order of the  
system  addresses.  This request can 
be used to retrieve the actual 
information that a link points to by 
using a link id in the place of a 
document  id  in the spec.  This 
would be following the link, but in a 
more direct fashion than with the 
FOLLOWLINK request.  RETRIEVEV will 
not be useful  for  following  links  
when  the  topology  of  the  link is 
of interest.  For instance, to 
retrieve the text that the to-set of 
a link points  to, the span in the 
spec would have a stream address of 
2.1 and a width of 1. 

RETRIEVEDOCVSPAN <doc id> 

 
     This returns the span of the 
document.  This span is the extent of 
the  entire  document, with both the 
text and the links included.  This 
means that if there are no links in 
the document, the width of the span 
will  be  the number of characters in 
the document.      Otherwise, the 
width of the span will indicate the 
number of links in the document. 

RETRIEVEDOCVSPANSET <doc id> * The 
current implementation of this 
request is incomplete. 

 
     This request is supposed to 
return two spans:  the span of all 
the document's  text,  and the span 
of all the documents links. If there 
is no text or no links in the 
document only one span will be 
returned. 

Creation of Documents and Versions of 
Documents 

Definitions: 

 [1]  documents 

          A document is a user 
created entity  that  contains  text  
or 
          other  byte  information 
and/or links.  A document is divided 
          into two distinct regions; 
a text space and a link space. 

[2]  versions 

          Versions are created from 
previously existing documents  with 
          the  CREATENEWVERSION 
request.  A version is created when 
you 
          want to preserve and intact 
copy of a  document  as  is,  and 
          have  another copy to edit. 
A new editing incarnation is NOT 
          a new version.  The Xanadu 
hypertext definition of this  term 
          is very specific.  A 
version is a document, the only 
distinction being that a version  is  
descended  from  a  previously 
          existing document.  A new 
version inherits all of its immediate 
ancestor's information, both textual 
and topological. 

     The Xanadu hypertext system has 
the following  functions  for  the 
creation of documents and versions of 
documents: 

                - CREATEDOCUMENT 
                - CREATENEWVERSION 

 
     A front-end program may let the 
user create documents or  versions 
implicitly, explicitly, or both, 
depending on the particular 
front-end. 


CREATENEWVERSION <doc id> 
  
      This request creates a new 
version  of  document  <doc  id>  and 
returns  the  id of the new version.  
The new document will have a tumbler 
address which indicates that the new 
document  is  descended  from the  
original.   For  example, if there is 
only one version of document 
23.0.17.0.256,  this  request  will  
create  a  document  with  the  id 
23.0.17.0.256.1.  Let's describe a 
more complicated case.  Say that for 
document 23.0.17.0.256, the versions 

                23.0.17.0.256, 
                23.0.17.0.256.1, 
                23.0.17.0.256.1.1, 
                23.0.17.0.256.1.2, 
                23.0.17.0.256.2, 
            and 23.0.17.0.256.3 

exist.  Now, if a new version of 
23.0.17.0.256.2 was  to  be  made,  
it would  have  the id 
23.0.17.0.256.2.1.  This will have no 
effect on any existing version, 
23.0.17.0.256.3 will still be the  
same  document  at the same address 
as before.  The new document will 
inherit ALL information that was 
associated with  the  original,  but  
be  treated  as  an independent  
document, existing simultaneously 
with the original or any other 
versions. 

Comparison of Documents and Versions 
of Documents 

       The Xanadu hypertext system 
has the following functions for  the 
comparison of documents and versions 
of documents: 

                - 
SHOWRELATIONOF2VERSIONS 
                - FINDDOCSCONTAINING 

 SHOWRELATIONOF2VERSIONS <spec set> 
<spec set> 

 
       This request returns a list of 
ordered pairs of all parts of the two 
spec sets that correspond to the same 
original source. 

FINDDOCSCONTAINING <spec set> 

 
       This request returns the ids 
of all documents that  contain  the 
same material as specified by <spec 
set>. 

Editing of Text in Documents 

       The Xanadu hypertext system 
has the following operations for the 
editing of text: 

                - INSERT 
                - DELETEVSPAN 
                - REARRANGE 
                - COPY 
                - APPEND 

 INSERT <doc id> <v-address> <text> 

 
       This request inserts <text> at 
<v-address> in document <doc id>. 

DELETE <doc id> <v-span> 

 
       This request removes the 
v-span from the document <doc id>. 

REARRANGE <doc id> <cut set> 

 
       The <cut set> consists of two 
to  four  v-addresses  within  the 
specified  document.  A two cut 
rearrange will simply delete 
everything between the cuts.  A three 
or four cut  rearrange  transposes  
the  two regions  of  text.   With 
three cuts, the two regions are from 
cut 1 to cut 2, and from cut 2 to cut 
3, assuming cut 1 < cut 2 < cut  3.   
With four  cuts,  the regions are 
from cut 1 to cut 2, and from cut 3 
to cut 4, here assuming cut 1 < cut 2 
and cut 3 < cut 4. 

COPY <spec set> <doc id> <v-address> 

 
       Copy causes all of the 
information specified by <spec set> 
to be virtually inserted at 
<v-address> in document <doc id>. 

APPEND <doc id> <text> 

 
     Append inserts <text> after the 
last character  in  document  <doc 
id>. 

Links:  Use, Content, Creation and 
Retrieval 

       There is one operation for the 
creation of links. 

                - MAKELINK 

 
       The Xanadu  hypertext  system  
has  these  operations  that  are 
involved in the retrieval of links: 

                - FOLLOWLINK 
                - 
FINDNUMOFLINKSFROMTO 
                - FINDLINKSFROMTO 
                - 
FINDNEXTNLINKSFROMTO 
                - RETRIEVEENDSETS 

MAKELINK <home doc> <end sets> 
    This request creates a link with the specified end-sets in document <homedoc>.  The new link will be 
    appended to the link space of document <home doc>.  For example if <home doc> is 1.0.2.0.3, and the 
    last link in it is 1.0.2.0.3.0.2.15, the new link will be 1.0.2.0.3.0.2.16.

FOLLOWLINK <link id> <which end> 
    This request returns a spec-set that is the end of link <link id> specified <which end> to be used 
    later by such requests as RETRIEVEV. 

FINDNUMOFLINKSFROMTO <restriction set> 
    This request returns the number of links that fall within the restriction set. 

FINDLINKSFROMTO <restriction set> 
    This request returns the ids of all the links that fall within the restriction set. 

FINDNEXTNLINKSFROMTO <restriction set> <link id> <n links> 
    This request returns the ids of the next n links after link <linkid> that fall
    within the restriction set. 

RETRIEVEENDSETS <spec set> 
    This request returns a spec set of all the from-sets and a spec set of all the to-sets
    that fall within <spec set>. 



 

 

 

Disclaimer- 

     This is a technical overview  
document.   It  covers  the  current 
status  of  the  Xanadu  hypertext 
system.  Since the system is not yet 
complete, some of the features that 
must be discussed are not currently 
implemented.  These are: 

 
     1) Link Types 

     2) Historical trace 

     3) Multi-user Capability 

     4) Networking 

 
     The above features are listed 
according to the order  priority  of 
future  implementation.  Link types 
are a simple improvement and merely 
await more computer resources (disk). 

     Historical trace is a separable 
portion of the software so it  has 
been  postponed  until it is 
convenient to implement.  This can be 
done in stages. 

     Multi-user capability will be 
implemented as a  transaction  based 
system, possibly before historical 
trace (depending on customer demands 
and resources). 

     Networking will require much 
communication between nodes to 
facilitate such things as "computer 
conferencing" applications.  
Implementation time depends on 
customer demands and resources. 

     This document will give  
examples  with  network  nodes  and  
user accounts  in the addresses.  In 
the current implementation there are 
no nodes or accounts, so all document 
ids will resemble  "0.0.1"  with  no 
node or account id. 

     This document will be updated as 
necessary.  Portions  that  refer to  
the  above  features should be taken 
as partially descriptive.  For 
instance, link type definitions are 
provided by  three-sets  which  are 
not currently implemented.  
Three-sets will appear in various 
retrieval restriction portions of 
many commands, but they aren't 
documented  that way now. 

 General System Operation 

     Backend   The backend is that 
part of the system which stores  and 
retrieves documents and links.  The 
backend is application independent. 

     Frontend  The frontend is the 
user interface in this  system.   It 
will  normally  run  on the computer 
in the user's terminal.  The front 
end contains all application 
dependent features. 

                       Maintenance of 
documents and versions of documents 

     The information in a Xanadu 
System is stored as a  set  of  
"documents".   Documents  are not 
simply "files" -- essentially long 
strings of characters stored at known 
locations on some permanent media.  
Documents  are  strings  of  text  
with  accompanying "links".  "Links" 
are instructions for getting from one 
document to another.  It is useful to 
think  of all the documents in the 
system as residing on some part of a 
virtual list indexed by tumblers -- 
the virtual stream.  (A tumbler  is a 
special kind of number; a full 
definition of tumbler is available in 
the technical specifications)  New 
documents are created on this stream 
by the following function: 

     CREATENEWDOCUMENT 
   returns a new document id 

     This command simply creates a 
way to access the document from some 
old  document  the  user  already 
"owns", such as a master index of his 
work.  Essentially the frontend is 
passed a tumbler address on the 
virtual stream for the new document. 

     All past incarnations of a 
document that have  been  developed  
on the  Xanadu system can be 
reconstructed by the system.  Thus, 
"historical backtrack", tracing the 
history of the development of a  
particular document  through  several 
editing  sessions, is a natural thing 
to do given our specialized data 
structures.  We plan to implement 
this function with the command: 

     NAVIGATEONHT 

     Such a capability will be very 
useful for any individual  involved 
with  demanding  composition  tasks  
likely  to  generate false starts, 
rethinking, and extensive rewriting.  
For  such  people  --  designers, 
researchers,  creative  writers -- 
convenient access to past approaches 
will be invaluable. 

     Likewise creating multiple 
"versions" of a document,  perhaps  
for somewhat  different  purposes  or 
audiences, is a natural capability of 
the Xanadu System.  All that is 
necessary is to create an easy  way  
to address  those versions of 
interest from among the vast number 
that can be reconstructed.  This is 
the function of the following 
command: 

     CREATENEWVERSION 
   returns document id of new version 

     The new document will have a 
tumbler address that  indicates  that 
the new document is descended from 
the original.  For example, if there 
is only one version of document 
23.0.17.0.256, this request will 
create a  document with the id 
23.0.17.0.256.1.  The new document 
will inherit ALL information that was 
associated with the original.  Note  
that  not every  incarnation of a 
document produced by every editing 
session is a "version".  A "version" 
with its own tumbler address must be 
created by a CREATENEWVERSION 
command. 

     That tumbler address provides a 
ready means of access from an  old 
version  of  a  document to a new 
one.  Such a capability is especially 
useful in the creation of new 
versions of standardized documents  
(e.g. standard  forms)  or  documents 
that  include  considerable amounts 
of "boilerplate", such as legal 
papers.  Of course, given many 
versions of a  document  one would 
like to be able to compare them so as 
to be able to determine which 
passages have remained the same and 
which have  been changed.   This  is  
crucial  for material where small 
details are very important, such as 
computer programs, contracts,  
technical  specifications or 
accounts.  This is the role of the 
following function: 

     SHOWRELATIONOF2VERSIONS 
   returns ordered pairs of common 
passages 

     Note that the information 
returned is the passages  the  two  
versions  or  documents  have  in  
common.   This  might be indicated 
conveniently on a screen divided into 
two vertical windows, each one  
containing  a  version of the 
document in question.  Common 
passages might be marked by 
attributes such as  reverse  video  
or  by  color  coding. NAVIGATEONHT 
will provide another tool for 
comparison of versions; not only will 
the user be able to retrace old 
incarnations, but one will be able to 
navigate between independently 
developed versions which share a 
common origin in some previous 
document. 

Editing of documents 

     data structures maintained by 
the backend.  So the backend must be 
passed a more detailed account of an 
editing session than standard file 
maintenance routines require.  The 
current [July 1982] minimal frontend 
achieves  this  by  contacting the 
backend after every editing command. 
Thus inserting a five letter word 
requires five calls  to  the  backend 
and five evocations of the following 
function: 

     INSERT 
   puts in text beginning at a known 
position 

     This function inserts the text 
at the specified tumbler addresses. 
Of  course  the  frontend could 
accumulate such data and send it to 
the backend as a block at some 
reasonable time.  This change will  
soon  be made. 

     Note that the  other  editing  
functions  which  follow  also  are 
defined  with  reference  to  the 
position on the virtual stream of the 
text  being  manipulated.   Keeping  
track  of  these  virtual   stream 
addresses  requires  more  processing 
time than an optimized block file 
editor would, but this is a small 
price to pay for the maintenance of a 
useful well-ordered data structure. 

     [1] DELETEVSPAN 
  virtual deletion of text where 
indicated 

     [2] COPY 
  creates virtual copies where 
indicated 
                                      
     [3] REARRANGE 
  transposes virtual text 

     [4] APPEND 
  inserts characters at the end of 
the document's text 

     The first function, "delete", 
tells the backend to delete a set of 
bytes  defined  by  their  position 
on the virtual stream.  The present 
frontend keeps constant track of 
where the cursor is in relation to 
the backend  data structure.  Thus 
the user deletes material by 
positioning the cursor and deleting 
the desired material character by 
character. 

     "Copy" puts a virtual copy of 
any specified material  (as  defined 
by vspecs, i.e. tumbler addressing of 
the virtual stream) into the 
destination indicated by the frontend 
or the user.  No  text  is  actually 
moved, rather a new way to access the 
material is created. 

     "Rearranges" are defined by 
delimiters inserted by the  user.   
If three  cuts  are supplied the 
material between cuts "1" and "2" 
appears to be moved to between "2" 
and "3", and visa versa. 
 If four are supplied the material 
between "1" and "2"  appears  to  be 
swapped  with  the  material  between 
cuts "3" and "4" .  However, once 
again only address changes are 
involved. 

     "Append" adds characters to the 
end of documents.  It is simply  a 
more  convenient  insert  for  a few 
specific applications, such as the 
implementation of the front-end 
functions that manage the initial 
entry of text into a document. 

Links 

     One of the great advantages of 
the Xanadu Hypertext System is  the 
structure of interconnections 
provided by user-defined links.  
Inasmuch as the structure is created 
by people rather than  algorithms  it 
will approximate a structure of ideas 
rather than an accounting of 
identical character strings, the 
product of a keyword search.  (Of  
course  algorithms  may  be  written 
which create the links implicitly 
specified in already published 
material, such as lists of references 
or indexes) The function for creating 
such a link follows: 

     MAKELINK 
   creates a directional link from a 
point in one document to  a  point in 
another 

     All links created by a user 
reside in some home document  of  
his, including  those  that  link 
documents which are not his.  Links 
have a directionality defined by the 
creator, thus an origin and  a  
terminus. In  the  future  the 
creator will be able to assign a link 
type -- e.g. footnote, marginal note, 
etc. -- to a link when it is made. 

     Once a set of links to or from a 
document has been  created  their 
existence  must  be  indicated  to 
the user, but only when he wishes to 
know of them.  This may be 
implemented in a frontend by 
assigning, upon the  user's  request, 
attributes or color codes to text 
that is at the end-points of links.  
The following function finds these 
endpoints: 

     RETRIEVEENDSETS 
   returns virtual stream addresses 
for the end-sets of the links  that 
start or terminate in the current 
document 

     Note that we plan to use the 
link type defined when the  link  was 
made as one constraint on the number 
of link end-sets displayed. 

 Document Retrieval -- navigating in 
the link structure 

     Ready direct access from any 
particular  document  to  an  immense 
number  of  other  documents  creates 
a number of novel problems 
unprecedented in paper document 
systems.  In the latter systems, 
checking  a reference  or  verifying 
a quotation are onerous tasks that 
may consume several minutes or a 
number of weeks.  In such 
circumstances  few  such operations 
can even be considered.  In a fully 
implemented Xanadu documentation 
system, however, cross references 
between documents are  both easy to 
follow and easy to create.  This must 
lead to the proliferation of such 
linkages.  While the growth of such a 
rich network of interconnections will 
facilitate comprehension of the 
knowledge represented, it will also 
make navigating through the  
structure  of  cross  references more 
demanding.  One will not wish to 
simply request all the links to a 
particular use of an important 
concept; such a request  might  
generate scores,  even  thousands  of 
links.   For  example, the documents 
that reference the concept "DNA" as 
used by Watson and Crick in their  
seminal  first  publication  might 
run to the tens of thousands.  In 
such a case the user may wish to  
further  specify  the  related  
material  he wishes  to  investigate  
before requesting the available 
links.  He may conveniently detect 
such situations by using the command: 

     FINDNUMOFLINKSFROMTO 

     This command simply returns the 
number of links to or  from  other 
documents  from or to the material of 
interest.  The result informs the 
user of the need to put further 
limits on the  scope  of  his  
request. This may be done in a number 
of ways. 

     First and simplest, one may 
specify the type of link to follow. 
(Indeed we plan to allow the user to 
specify the link type as a parameter 
for the FINDNUMOFLINKSFROMTO 
command.)   In principle links may be 
characterized as any sort of relation 
a user finds useful; currently we 
plan  to  implement,  however, only a 
few types, e.g. footnotes, 
quotations, andannotations. 

     Secondly, the set of documents 
linked to the passage  of  interest 
may  be  partitioned in terms of some 
of the other links to these 
documents.  Some of these sets may 
appear more promising for a 
researcher's current  objective  than 
others.   For  example, a biochemist 
might be interested in articles which 
both reference Watson  and  Crick's  
paper and  are  referenced  by  a A 
standard biochemistry text.  
Geneticists, however, would probably 
be interested  in  a  different  
subset.   Thus operations on sets, 
such as intersection and union, can 
be powerful and convenient tools for 
the user with a reasonably 
sophisticated frontend. That  is, one 
that stores a number of different 
specifications, invokes the 
appropriate backend functions, and 
supplies  the  user  with  those 
documents  that  meet  all of them.  
(Note that a number of specialized 
frontends can be designed for  
different  applications)(See  
frontends) Several  link  tracing  
functions  already implemented will 
provide the basis for this 
capability: 

     [1] FINDLINKSFROMTO 

     [2] FINDNEXTNLINKSFROMTO 

     The first command returns all of 
the links that fit the specifications 
defined  by  the accompanying 
parameters, viz.  those links that 
start and end at the specified 
end-sets and are stored in the 
specified home-set [presumably by the 
owner of the account that contains 
it].  In some cases the number of 
links defined by even a well 
considered set of restrictions  will 
be immense.  In such a case the user 
has recourse to the second command.   
This provides a systematic way to 
allow   one  to proceed  through a 
large number of links a set number at 
a time, checking out their usefulness 
one by one, rather than immediately 
recovering the entire set. 

     With his search so constrained 
to practical limits a researcher is 
ready  to  follow  a link down to his 
first reference.  His request for 
this reference from his frontend will 
generate at least  the  following 
three backend calls: 

     [1] FOLLOWLINK 

     [2] RETRIEVEDOCVSPAN 

     [3] RETRIEVEV 

     The first provides the position 
(tumbler address) of the  document in 
the  data  structure.   The  second  
provides its size, possibly of 
interest to the user, and certainly 
of interest to the  frontend  which 
must  decide  what  proportion  of it 
to pull into the frontend's local 
memory.  Finally the third command  
returns  the  specified  amount  of 
text,  links,  etc. to the frontend 
which in turn displays a portion of 
it to the user.  Note that at any 
time the user can simply jump back to 
his  place  in  the previous 
document, either to sample the 
material at the ends of other links 
or to work with the document itself. 

     In some cases one may be faced 
with too few rather than  too  many 
cross  references.   In  such  cases  
the domain of one's search can be 
enlarged by use of the following 
command: 

     FINDDOCSCONTAINING 
   returns i.d.s of documents 
containing specified passages 

     This command will return access 
directions (tumbler addresses) for 
any  document containing any passage 
that has been copied from a common 
source and meet the given set of 
specifications.   This  function  
provides  the user  with  
interconnections  between  documents  
not  made explicit by the use of 
links. 


 
  A technical overview of the Xanadu 
Hypertext System 

 

     The Xanadu Hypertext System is a 
unified system  for  storing  and 
managing certain forms of 
information, namely: bodies of 
documents.  It is built around a 
small number of relatively simple 
concepts: 

o    DOCUMENTS 

o    multiple VERSIONS of documents 

o    LINKS between documents 

o    distributed storage and 
distributed computation -- NETWORKING 

o    isolation  of  storage  
functions  from   display   functions 
-- 
     BACKEND/FRONTEND 

     We will discuss each of these in 
turn and thereby build up a  picture  
of  what  the  Xanadu  System is, 
what it does, and what makes it 
unique. 

Documents 

     A "document" is a chunk of 
contiguous characters (or  other  
data) which functions in some way as 
a conceptual unit.  It is simply a 
piece of text which some  user  has  
declared  to  be  a  single  thing.   
It corresponds roughly to the notion 
of a "file" as found in most computer 
systems.  Beware of this analogy, 
however, because it breaks down quite 
thoroughly in the face of the other 
properties of the system. 

     A document may contain whatever 
the user decides  to  put  in  it. 
While documents will generally 
contain text, the system assumes 
nothing about  their  contents.   Any 
arbitrary  set  of  data  which  can  
be represented as a string of bytes 
may be stored in a document.  
Possible documents include letters, 
books, chapters of  books,  memos,  
marginal notes,  musical  scores,  
reports,  pictures,  computer 
programs, maps, diagrams, recordings, 
etc.:  whatever the user desires the 
document  to be. 

     Each document stored in the 
system is assigned a unique 
identifier when it is created.  This 
identifier can then be used in later 
transactions with the system to  
designate  that  particular  
document.   This document  identifier 
is  a  special sort of number called 
a "tumbler". Tumblers are multipart 
numbers similar to those used to 
number sections of  technical  
manuals  and to index books in the 
Dewey Decimal System. For example, 
1.0.3.15 and 123.5.6391.0.8.1  are  
both  tumblers.   They have  the  
property  that  they can be expanded 
at any point, and it is therefore 
possible to implement a numbering 
system that never runs  out of 
precision.  This means that there is 
no limit to the number of document 
identifiers possible and therefore no 
theoretical  limit  to  the number of 
possible documents due to a finite 
address space. 

                                      
Since a document is a linear array of 
bytes, we can refer  to  any 
particular  character  in  a  
document by its position in the 
document. Thus, by combining a 
document's  unique  identifier  with  
a  character position  within  that  
document, we can uniquely address any 
character stored in the entire 
system. 

     By designating a particular 
(starting) character and a  length  
we can  address any contiguous string 
of characters in the system.  Such a 
string is called a "span".  By clever 
use of tumblers instead of  plain 
integers  to represent character 
positions and span lengths, it is 
possible to have spans which contain 
whole documents  and  cross  document 
boundaries. 

Versions 

     The Xanadu Hypertext System can 
manage multiple differing versions of 
a  single document.  Typically, 
documents will change with time, as 
they are corrected or revised.  
Parallel versions may be made, as  
when writers  weigh alternate drafts 
of a chapter or when a computer 
program and its documentation are 
maintained for  several  different  
installations. 

     Whenever a document is changed, 
the  changes  are  recorded.   The 
system  remembers  both  the  old and 
the new versions and can retrieve 
either on command.  Thus it is 
possible to retrieve a document  in  
the state  it  was in at any point in 
time since its creation.  This can be 
particularly useful, for example, in 
software development  or  creative 
writing  when one may make false 
starts and wish to back up to a 
previous state.  In addition, the 
system  can  indicate  the  changes  
which caused two alternate versions 
to differ.  Thus a complete "audit 
trail" through the history of a 
document can be constructed.  Such a 
trail  is in  the form of an 
historical trace tree which branches 
whenever parallel versions are 
maintained. 

     In the general case, the problem 
of comparing two pieces  of  text to  
determine the differences between 
them is NP-complete.  It may seem 
curious then that the Xanadu System 
is able to  do  this.   The  reason 
that  the  system can determine how 
documents differ is because it does 
not  compare  them.   Rather,  it  
performs  the  actual  changes   and 
"remembers"  them,  instead of having 
a whole new document passed to it by 
some external editor, as most systems 
would do. 

     Xanadu understands a simple set 
of editing primitives by which  it 
can be directed to make changes to a 
document: 

o    INSERT characters at some point 
in the document. 

o    DELETE characters from some 
point in the document. 

o    MOVE a span of characters from 
one location  in  the  document  to 
     another. 
                                      
o    COPY a span of characters from 
one location in  the  document  (or 
     from  anywhere in the rest of 
the system, for that matter) to some 
     location in the document. 

     A moment's thought will reveal 
that these  operations  are  
sufficient to perform any more 
complex editing operations in their 
entirety. 

     This sort of arrangement is not  
unique.   However,  most  systems 
which do this, such as Bell 
Laboratories SCCS (Source Code 
Control System) and DEC's CMS (Code 
Management System) merely keep a  log 
of  the edit  operations  and  then  
perform  those operations in 
chronological order to produce the 
desired version.  While this is 
sufficient in many cases,  it  is 
unwieldy when there are many parallel 
branching versions and it is costly 
in terms of computational overhead, 
becoming  more  so as more and more 
changes are made to a document. 

     In the Xanadu System, these 
primitives correspond to operations 
on the  proprietary  data  structures 
in  which the documents are stored. 
These data structures tell the system 
which  characters  are  in  which 
versions  and  in  what order.  This 
allows the proper retrieval of any 
version quickly and efficiently.  The 
historical traceback facility  is 
built  in  implicitly.  To the best 
of our knowledge, the Xanadu System 
is the only system in existence able 
to  manage  multiple  versions  of 
data in such a general and efficient 
manner. 

Links 

     A "link" is merely an  explicit  
logical  connection  between  one 
piece of data and another.  The 
Xanadu Hypertext System supports a 
completely generalized linking 
facility.  Any body of text in  the  
entire system  can  be  linked to any 
other body of text in the system.  
Links may connect text within a 
document or run between documents. 

     Any given link connects from one 
set of  text  in  the  system  to 
another.   The  bodies  of text at 
either end of the link are therefore 
called the link's "end-sets".  The 
first end-set is called  the  
"fromset"  and  the second is called 
the "to-set".  By convention links 
have an implied direction from the 
from-set to the to-set, not 
surprisingly, although  the  
relationship  is  entirely 
symmetrical and a link may be 
followed in either direction. 

     The potential contents of an 
end-set are totally unrestricted.  An 
end-set  may  consist  of an 
unlimited number of spans.  The 
characters linked to or from need not 
be contiguous or even in the same 
document. 

     Links themselves are said to 
reside inside documents, located in a 
separate logical address space from 
the text.  A link may reside in one 
document and link from a second 
document to yet a third.  The  
location of  residence  of a link is 
entirely independent of the contents 
of the link's end-sets.  The fact 
that links are among the potential  
contents of documents means that 
links themselves may be linked from 
or to, just as characters may.  Thus 
very general sorts of indirect 
structures  may be assembled. 

                                      
     It was mentioned above that the 
end-sets are  symmetric  and  only 
distinguished  by  convention.   In 
fact, a link may have any number of 
end-sets.  The use of these extra 
end-sets may vary  depending  on  the 
purpose  of  the link.  We have found 
it convenient to define, again by 
convention, a third end-set called 
the "three-set". 

     The purpose of the three-set is 
to designate information  pertaining 
to the link itself.  By this means we 
can define "link types" which may in 
turn be used to determine how the 
link  is  to  be  interpreted. For  
example, we might create a "quotation 
link" type, which designates that the 
passage linked to is to be displayed 
in quotation marks at the location  
linked from.  A "footnote link" on 
the other hand, might simply 
designate that a superscripted 
asterisk  be  shown  at  the  "from" 
location  and  that the to-set 
contents be displayed only when the 
user so requests.  In a more advanced 
system, the three-set might point to 
a program or subroutine to be 
downloaded into the display computer. 
This program would then decide how to 
display the link and its end-sets.  
In any case, the mechanism is totally 
general and constrained only by 
convention. 

     There are very few systems  
which  attempt  to  implement  a  
link facility  at  all like this. We 
are aware of only one system which 
even comes close, Englebart's  
"Augment",  available  on  Tymenet.   
Augment implements  links  by  
embedding code sequences directly 
into the text. This technique has a 
number of drawbacks: it rapidly 
becomes unworkable when  more  than a 
small number of links are defined, it 
is very difficult to maintain the 
bidirectionality of links  using  
such  a  scheme, discontinuous  
end-sets  are  just  about 
impossible, and embedded code 
sequences would interfere with the 
versioning mechanism.  As with  
versions,  proprietary  data 
structures enable our system to work. 
Xanadu links are not embedded in the 
text.  Although links are said to  
reside in documents, this is simply a 
means to allow links to be addressed 
and thus linked to.  There are a 
number of tricky problems that  a  
linkage system  such  as this 
presents.  In particular, answering 
the question, "what links connect 
from Qother places to a particular  
location?",  is very  difficult to 
answer using most conventional 
schemes of organizing data.  
Consider, for example, the problems 
inherent in assembling  such things  
as  citation  indices.   
Nevertheless,  we  believe we have 
the general-case solution to these 
problems. 

Xanadu Hypertext Calls to Back-end -- BNF 

 CREATENEWDOCUMENT ::= 
<createdocrequest> 
  returns <createdocrequest> <doc id> 

  <createdocrequest> ::= 11 <wdelim> 

    This creates an empty document, 
returns the id of the new document. 

 CREATENEWVERSION ::= 
<createversionrequest> <doc id> 
  returns <createversionrequest> <doc 
id> 

  <createversionrequest> ::= 13 
<wordelim> 

    This creates a new document with 
the contents of document <doc id>, 
  it returns the id of the new 
document.  The new document's id will 
  indicate it's ancestory. 

 INSERT ::= <insertrequest> <doc id> 
<doc vsa> <text set> 
  returns <insertrequest> 

  <insertrequest> ::= 0 <wdelim> 

    This inserts <text set> in 
document <doc id> at <doc vsa>, the 
 v-stream addresses of any following 
characters are increased by the 
 length of the inserted text. 

 DELETEVSPAN ::= <deleterequest> <doc 
id> <span> 
  returns <deleterequest> 

  <deleterequest> ::= 12 <wdelim> 

    This removes the given span from 
the given document. 

 REARRANGE ::= <rearrangerequest> 
<doc id> <cut set> 
  returns <rearrangerequest> 

  <rearrangerequest> ::= 3 <wdelim> 
  <cut set> ::= <ncuts> <doc vsa>* 
  <ncuts> ::= <integer> <wdelim>      
/* ncuts = 3 or 4 */ 

    The <cut set> consists of two to 
four v-addresses within the 
 specified document.  A two cut 
rearrange will simply delete every- 
 thing between the cuts.  A three or 
four cut rearrange transposes the 
 two regions of text.  With three 
cuts, the two regions are from cut 1 
 to cut 2, and from cut 2 to cut 3, 
assuming cut 1 < cut 2 < cut 3. 
 With four cuts, the regions are from 
cut 1 to cut 2, and from cut 3 
 to cut 4, here assuming cut 1 < cut 
2 and cut 3 < cut 4. 

COPY ::= <copyrequest> <doc id> <doc 
vsa> <spec set> 
  returns <copyrequest> 

  <copyrequest> ::= 2 <wdelim> 

    The material determined by <spec 
set> is copied to the document 
 determined by <doc id> at the 
address determined by <doc vsa>. 

 APPEND ::= <appendrequest> <text 
set> <doc id> 
  returns <appendrequest> 

  <appendrequest> ::= 19 <wdelim> 

    This appends <text set> onto the 
end of the text space of the 
 document <doc id>. 

 RETRIEVEV ::= <retrieverequest> 
<spec set> 
  returns <retrieverequest> 
<vstuffset> 

  <retrieverequest> ::= 5 <wdelim> 

    This returns the material (text 
and links) determined by 
 <spec set>. 

 RETRIEVEDOCVSPAN ::= 
<docvspanrequest> <doc id> 
  returns <docvspanrequest> <vspan> 

  <docvspanrequest> ::= 14 <wdelim> 

    This returns a span determining 
the origin and extent of the 
 vstream of document <doc id>. 

 RETRIEVEDOCVSPANSET ::= 
<docvspansetrequest> <doc id> 
  returns <docvspansetrequest> 
<vspanset> 

  <docvspansetrequest> ::= 1 <wdelim> 
  <vspanset> ::= <nspans> <vspan>* 

    This returns a span-set 
indicating both the number of 
characters 
 of text and the number of links in 
document <doc id>. 

 MAKELINK ::= <makelinkrequest> <doc 
id> <doc vsa> <from set> <to set> 
  returns <makelinkrequest> <link id> 

  <makelinkrequest> ::= 4 <wdelim> 

    This creates a link in document 
<doc id> from <from set> to 
 <to set>.  It returns the id of the 
link made. 

 FINDLINKSFROMTO ::= <linksrequest> 
<home set> <from set> <to set> 
  returns <linksrequest> <link set> 

  <linksrequest> ::= 7 <wdelim> 

    This returns a list of all links 
which are (1) in <home set>, 
 (2) from all 
  or any part of <from set> and (3) 
to all or any part of <to set>. 

 FINDNUMOFLINKSFROMTO ::= 
<nlinksrequest> <home set> <from set> 
<to set> 
  returns <nlinksrequest> <nlinks> 

  <nlinksrequest> ::= 6 <wdelim> 

    This returns the number of links 
which are (1) in <home set>, 
 (2) from all or any part of <from 
set> and (3) to all or any part 
 of <to set>. 

 FINDNEXTNLINKSFROMTO ::= 
<nextnlinksrequest> <from set> <to 
set> 

                         <home set> 
<link id> <nlinks> 

  returns <nextnlinksrequest> 
<linkset> 

  <nextnlinksrequest> ::= 8 <wdelim> 

    This returns a list of all links 
which are (1) in the list 
 determined by <from set>, <to set>, 
and <home set> as in 
 FINDLINKSFROMTO, (2) past the link 
given by <linkisa> on that list 
 and (3) no more than <n> items past 
that link on that list 

 RETRIEVEENDSETS ::= 
<retrieveendsetsrequest> <spec set> 
  returns <retrieveendsetsrequest> 
<from spec set> <to spec set> 

  <retrieveendsetsrequest> ::= 26 
  <from spec set> ::= <spec set> 
  <to spec set> ::= <spec set> 

    This returns a list of all link 
end-sets that are in <spec set>. 

 SHOWRELATIONOF2VERSIONS ::= 
<showrelationrequest> <spec set> 
<spec set> 
  returns <showrelationrequest> 
<correspondence list> 

  <showrelationrequest> ::= 10 <wdelim> 
  /* this is a wild guess at the vague form of the response */ 
  <correspondence list> ::= <ncorresponences> <correspondence>* 
  <corresponence> ::= <item> <item> 
  <item> ::= <doc id> <vspan> 
  <ncorrespondences> ::= <integer> 
<wdelim> 

    This returns a list of ordered pairs of the spans of the two spec-sets that correspond. 

FINDDOCSCONTAINING ::= <docscontainingrequest> <vspec set> 
    returns <docscontainingrequest> <doc set> 

  <docscontainingrequest> ::= 22 <wdelim> 

    This returns a list of all 
documents containing any portion of 
 the material included by <vspec 
set>. 

 NAVIGATEONHT ::= 
    <navigateonhtrequest> <totally undefined> 
    returns <navigateonhtrequest> <totally undefined> 

    This re-edits a document to any point in its editing history. 
