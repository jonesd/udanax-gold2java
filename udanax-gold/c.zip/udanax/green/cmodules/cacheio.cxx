/**
 * @file  cacheio.cxx
 * @brief Block-Level Caching of I/O Operations
 *
 * (to be defined)
 *
 **/

#include <iostream>
#include <stdio.h>
#include <unistd.h>
#include <fcntl.h>
#include <errno.h>
#include <sys/mman.h>

#include <nana/nana.h>  // GNU Assertion/Logging Tool

#include "cacheio.h"

/**********************************************************************
 *
 **********************************************************************/
MMapCacheIO::MMapCacheIO(int blocksize)
: CacheIO(blocksize)
{
    cerr << "CacheIO ctor" << endl;
}

/**********************************************************************
 *
 **********************************************************************/
CacheIO::~CacheIO()
{
//    if (isopen)
//        close();
}

/**********************************************************************
 *
 **********************************************************************/
    void *
MMapCacheIO::grabBlock(BlockNum blocknum)
{
    cerr << "Grabbing Block# " << dec << blocknum << ", cachemem@0x" << hex << (int) cachemem << endl;

    stats.read_requests++;

    void *p = cachemem + ((off_t) blocknum * blocksize);

    cerr << "Result of Grab is ptr " << p << endl;

    return p;
}

/**********************************************************************
 *
 * NOTE: Default creation permissions are *not* world read/writable.
 **********************************************************************/
    MMapCacheIO::OpenStatus
MMapCacheIO::open(const char *filename)
{
    I(isopen == false);

    cerr << "Opening mmap file" << endl;

    OpenStatus ostat;
    cachefd = ::open(filename, O_RDWR|O_SYNC);
    if (cachefd == -1) { // Open Failed, Try to Create a New, Empty File
        errno = 0;
        if ((cachefd = ::open(filename, O_CREAT|O_EXCL|O_RDWR|O_SYNC, 0660)) == -1)
//        if ((cachefd = ::open(filename, O_CREAT|O_EXCL|O_WRONLY|O_SYNC, 0666)) == -1)
            return OS_FAILED; // ERROR - Open and Create Failed

        lseek(cachefd, (size_t) cachelen, SEEK_SET);
	char c = 0;
        write(cachefd, &c, sizeof(c));

        ostat = OS_CREATED; // Create of New File Worked
        cachemem = (char *) mmap(0, cachelen, PROT_READ|PROT_WRITE, MAP_SHARED, cachefd, 0);

        I((int) cachemem != -1);

	if ((int) cachemem == -1) {
            ::close(cachefd);
            perror("MMapCacheIO::open");
            return OS_FAILED;
        }

    } else {
        ostat = OS_OPENED; // Open of Old File Worked
        cachemem = (char *) mmap(0, cachelen, PROT_READ|PROT_WRITE, MAP_SHARED, cachefd, 0);

        I((int) cachemem != -1);

	if ((int) cachemem == -1) {
            ::close(cachefd);
            perror("MMapCacheIO::open");
            return OS_FAILED;
        }
    }

    cerr << "Setting isopen=true" << endl;
    isopen = true;
    return ostat;
}

/**********************************************************************
 *
 **********************************************************************/
    void
MMapCacheIO::close()
{
    I(isopen == true);

    cerr << "Invoking MMapCacheIO::close()" << endl;

    sync();

    int rc = munmap(cachemem, cachelen);
    if (rc != 0)
        perror("MMapCacheIO::close");

    if (::close(cachefd) != 0)
        ; // Throw 'CloseFailed' Exception

    isopen = false;
}

/**********************************************************************
 *
 **********************************************************************/
MMapCacheIO::~MMapCacheIO()
{
    cerr << "Invoking ~MMapCacheIO" << endl;

    if (isopen)
        close();
}

/**********************************************************************
 *
 **********************************************************************/
    void
MMapCacheIO::sync()
{
    int rc = msync(cachemem, cachelen, MS_SYNC);

    I(rc == 0); //Should Never Fail Unless Program Logic is Broken
}

/**********************************************************************
 *
 **********************************************************************/
    void
MMapCacheIO::sync(BlockNum blocknum)
{
    int rc = msync(cachemem + ((off_t) blocknum * blocksize), blocksize, MS_SYNC);

    I(rc == 0); //Should Never Fail Unless Program Logic is Broken
}

/**********************************************************************
 *     Copyright � 2000 Tau Productions Inc. All Rights Reserved
 **********************************************************************/
