/**
 * @file  blockio.cxx
 * @brief Low-Level, Uncached Disk Media I/O Operations
 *
 * (to be defined)
 *
 **/

#include <stdio.h>
#include <unistd.h>
#include <fcntl.h>
#include <errno.h>
#include <limits.h>  // for ULONG_MAX

#include <nana/nana.h>  // GNU Assertion/Logging Tool

#include "blockio.h"

/**********************************************************************
 *
 * NOTE: Default creation permissions are *not* world read/writable.
 **********************************************************************/
    FileBlockIO::OpenStatus
FileBlockIO::open(const char *filename)
{
    I(isopen == false);

    OpenStatus ostat;
    blockfd = ::open(filename, O_RDWR|O_SYNC);
    if (blockfd == -1) { // Open Failed, Try to Create a New, Empty File
        errno = 0;
        if ((blockfd = ::open(filename, O_CREAT|O_EXCL|O_WRONLY|O_SYNC, 0660)) == -1)
            return OS_FAILED; // ERROR - Open and Create Failed

        ostat = OS_CREATED; // Create of New File Worked

    } else
        ostat = OS_OPENED; // Open of Old File Worked

    isopen = true;
    return ostat;
}

/**********************************************************************
 *
 **********************************************************************/
    void
FileBlockIO::close()
{
    I(isopen == true);

    isopen = false;
    if (::close(blockfd) != 0)
        ; // Throw 'CloseFailed' Exception
}

/**********************************************************************
 *
 **********************************************************************/
    bool
FileBlockIO::get(void *buf, int buflen, BlockNum blocknum)
{
    I(buf != NULL);
    I(buflen > 0 && buflen <= blocksize);

    if (lseek(blockfd, (off_t) blocknum * blocksize, SEEK_SET) < 0) {
        // assert -- lseek failed!
        return false;
    }

    if (read(blockfd, buf, buflen) != buflen) {
        // assert -- read failed!
        return false;
    }

    stats.blocks_read++;
    return true;
}

/**********************************************************************
 *
 **********************************************************************/
    bool
FileBlockIO::put(void *buf, int buflen, BlockNum blocknum)
{
    I(buf != NULL);
    I(buflen > 0 && buflen <= blocksize);
    I(blocknum < ULONG_MAX/blocksize); // Check for Overflow of Offset

    if (lseek(blockfd, (off_t) blocknum * blocksize, SEEK_SET) < 0) {
        // assert -- lseek failed!
        return false;
    }

    if (write(blockfd, buf, buflen) != buflen) {
        // assert -- write failed!
        return false;
    }

    stats.blocks_written++;
    return true;
}

/**********************************************************************
 *     Copyright � 2000 Tau Productions Inc. All Rights Reserved
 **********************************************************************/
