/**
 * @file  allocio.cxx
 * @brief Block-Level Caching of I/O Operations
 *
 * (to be defined)
 *
 **/

#include <string.h>
#include <iostream>

#include <nana/nana.h>  // GNU Assertion/Logging Tool

#include "allocio.h"

#undef  offsetof
#define offsetof(TYPE, MEMBER) ((size_t) &((TYPE *)0)->MEMBER)

/**********************************************************************
 *
 **********************************************************************/
BitmapAllocIO::~BitmapAllocIO()
{
    cerr << "Invoking ~BitmapAllocIO" << endl;
}

/**********************************************************************
 *
 **********************************************************************/
BitmapAllocIO::BitmapAllocIO(CacheIO& cio)
: AllocIO(cio)
, sblock(*(superblock *)cio.grabBlock(BLOCKNUM_SUPERBLOCK))
, sblockfixedsize(offsetof(superblock, bitmap))
, allocmap(((char *) &sblock) + sblockfixedsize, cio.blocksize - sblockfixedsize)
{
    cerr << "BitmapAllocIO ctor, sblock set to " << &sblock << endl;

    if (memcmp(sblock.signature, "UDAN", 4) != 0) {
        memcpy(sblock.signature, "UDAN", 4);
        memcpy(sblock.version, "0100", 4);

        sblock.countmax  = ((cio.blocksize - sblockfixedsize)/4) * sizeof(int);
        sblock.countfree = sblock.countmax;

        allocmap.freeall();

	allocmap.setUsed(0); // Mark Area Occupied by Superblock Allocated
        allocmap.setUsed(1);
        allocmap.setUsed(2);
        allocmap.setUsed(3);
        allocmap.setUsed(4);
        allocmap.setUsed(5);
        allocmap.setUsed(6);
        allocmap.setUsed(7);

        cio.sync(BLOCKNUM_SUPERBLOCK);
    }
}

/**********************************************************************
 *
 **********************************************************************/
    void
BitmapAllocIO::Bitmap::setUsed(BlockNum n)
{
    I(n / sizeof(int) < numints);

    bits[n / sizeof(int)] |= 1L << (n % sizeof(int));
}

/**********************************************************************
 *
 **********************************************************************/
    void
BitmapAllocIO::Bitmap::setFree(BlockNum n)
{
    I(n / sizeof(int) < numints);

    bits[n / sizeof(int)] &= ~(1L << (n % sizeof(int)));
}

/**********************************************************************
 *
 **********************************************************************/
    bool
BitmapAllocIO::Bitmap::isFree(BlockNum n)
{
    I(n / sizeof(int) < numints);

    return !(bits[n / sizeof(int)] & (1L << (n % sizeof(int))));
}

/**********************************************************************
 *
 **********************************************************************/
    BlockNum
BitmapAllocIO::Bitmap::findFree()
{
    unsigned int intidx;
    for (intidx = 0; intidx < numints; intidx++) {
        if (bits[intidx] != ~0UL) {
            BlockNum blocknum = intidx * sizeof(int);

            while (!isFree(blocknum))
                blocknum++;

            return blocknum;
	}
    }

    I(false);
    return 0; // Should Never Occur
}

/**********************************************************************
 *
 **********************************************************************/
    void
BitmapAllocIO::Bitmap::freeall()
{
    memset(&bits[0], 0, sizeof(int) * numints);
}

/**********************************************************************
 *                        Allocate a Block
 **********************************************************************/
    BlockNum
BitmapAllocIO::allocBlock()
{
    I(sblock.countfree > 0);

    BlockNum blocknum = allocmap.findFree();

    allocmap.setUsed(blocknum);
    sblock.countfree--;

    return blocknum;
}

/**********************************************************************
 *           Return Specified Block to the Free Pool
 **********************************************************************/
    void
BitmapAllocIO::freeBlock(BlockNum blocknum)
{
    I(validDataBlockNum(blocknum));

    allocmap.setFree(blocknum);
    sblock.countfree++;
}

/**********************************************************************
 *     Copyright � 2000 Tau Productions Inc. All Rights Reserved
 **********************************************************************/
