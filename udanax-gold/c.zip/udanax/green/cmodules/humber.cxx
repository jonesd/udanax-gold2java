/**
 * @file  humber.cxx
 * @brief Humungous Number (humber) Manipulation Routines
 *
 * Humbers are a data structure of a class usually called Bignums that
 * are efficient at holding both very small and extremely large
 * positive integers.  They are variable-length array of bytes.
 *
 * The MSBit of the first byte, if zero, indicates that the value is
 * contained in the lower 7-bits (0-127).  Otherwise the value in the
 * lower 7-bits indicates the length of the value, in bytes.
 *
 * One item to note: if the first byte is all zeros, then the value
 * is zero.  This represents 'true zero'.
 *
 **/

#include <nana/nana.h>

#include "common.h"
#include "tumbler.h"
#include "humber.h"

/**********************************************************************
 *
 **********************************************************************/
    int
tumblerptrtofixed(humber p, Tumbler *tptr)
{
    tptr->clear();

    int    temp    = lengthoftumbler(p);
    humber tempexp = mexponentof(p);

    if (*tempexp <= 127)
        tptr->exp = -*tempexp;
    else
        tptr->exp = -functionintof( mexponentof(p) );

    humber  humberEnd = p + temp;
    p += mlengthoflength(p);

    humber  mantissadigitptr;
    if (*p < 128) /* always the case */
        mantissadigitptr = p + 1;
    else
        mantissadigitptr = p + functionlengthof(p);

    for (int i = 0; i < Tumbler::NPLACES && mantissadigitptr < humberEnd; i++) {
        if (mantissadigitptr[0] <= 127) { /* see intof */
            tptr->mantissa[i]  = mantissadigitptr[0];
            mantissadigitptr  += 1;
        } else {
            tptr->mantissa[i]  = functionintof(mantissadigitptr);
            mantissadigitptr  += functionlengthof(mantissadigitptr);
        }
    }

    return temp;
}

/**********************************************************************
 *
 **********************************************************************/
    int
tumblerfixedtoptr(Tumbler *ptr, humber p)
{
    I(ptr->negsign != true); //invariant: Tumbler Must Not Be Negative

    humber  op = p;

    unsigned int  tumblerlength = 0;
    unsigned int lengthofexponent;
    humberput(-ptr->exp, p, &lengthofexponent);

    p += lengthofexponent;
    tumblerlength += lengthofexponent;
    unsigned int  numberofsignificantdigits = nstories(ptr);

    for (unsigned int i = 0; i < numberofsignificantdigits; i++) {
        unsigned int digitlength;
        humberput((int) ptr->mantissa[i], p, &digitlength);
        p += digitlength;
        tumblerlength += digitlength;
    }

    unsigned int  totallength = calculatetotallength(tumblerlength);
    unsigned int  lengthlength = intlengthoflength(totallength);

    memmove(op + ptr->negsign + lengthlength, op, tumblerlength);
    humberput((int) totallength, op + ptr->negsign, &lengthlength);

    return totallength;
}

/**********************************************************************
 *
 **********************************************************************/
    unsigned int
calculatetotallength(unsigned int lengthofbody) /* of tumbler ie adds length of exponent in length of body*/
{
    if      (lengthofbody < 127)                      return lengthofbody + 1;
    else if (lengthofbody < FIRSTCHAR - 1)            return lengthofbody + 2;
    else if (lengthofbody < SECONDCHAR - 1 /*?*/ )    return lengthofbody + 3;
    else if (lengthofbody < THIRDCHAR - 1)            return lengthofbody + 4;
    else if (lengthofbody < FOURTHCHAR /* - 1*/ )     return lengthofbody + 5;
    else I(false); //invariant: Length is Not Reasonable
    return 0;
}

/**********************************************************************
 *
 **********************************************************************/
    humber
humberput(int i, humber humberfoo, unsigned int *lengthofhumberptr)
{
    I(i >= 0); //invariant: humber must be non-negative

    if (i < 128) {
        *lengthofhumberptr = 1;
        *humberfoo = i;

    } else /* if (i < 256*256*256*256) impossible for a 32 bit int */ {
        /* NOTE zzz check to see that compiler does the 256*256 at compile time */
        /* and fix these damn shifts sometime to be efficient*/

        if (i < FIRSTCHAR) {
            *lengthofhumberptr = 2;
            *(humberfoo + 0)   = 128 + 2;
            *(humberfoo + 1)   = i ;

        } else if (i < SECONDCHAR) {
            *lengthofhumberptr = 3;
            *(humberfoo + 0)   = 128 + 3;
            *(humberfoo + 1)   = i >> 8;
            *(humberfoo + 2)   = i & 0xff;

        } else if (i < THIRDCHAR) {
            *lengthofhumberptr = 4;
            *(humberfoo + 0)   = 128 + 4;
            *(humberfoo + 1)   = i >> 16 ;
            *(humberfoo + 2)   = i >> 8 & 0xff;
            *(humberfoo + 3)   = i & 0xff;

        } else {
            *lengthofhumberptr = 5;
            *(humberfoo + 0)   = 128 + 5;
            *(humberfoo + 1)   = i >> 24;
            *(humberfoo + 2)   = i >> 16 & 0xff;
            *(humberfoo + 3)   = i >> 8 & 0xff;
            *(humberfoo + 4)   = i & 0xff;
        }
    }

    return humberfoo;
}

/**********************************************************************
 *
 **********************************************************************/
    humber
humber3put(int i, humber humberfoo, unsigned int *lengthofhumberptr)
{
    I(i >= 0); //invariant: humber must be non-negative

    if (i < SECONDCHAR) {
        *lengthofhumberptr = 3;
        *(humberfoo + 0)   = 128 + 3;
        *(humberfoo + 1)   = i >> 8;
        *(humberfoo + 2)   = i & 0xff;

    } else {
        fprintf(stderr, "in humber3put i = %d\n", i);
        gerror("humber3put called with too larg a value\n");
    }

    /*
     * } else if (i < THIRDCHAR) {
     *     *lengthofhumberptr = 4;
     *     *(humberfoo  )   = 128 +4;
     *     *(humberfoo + 1) = i>>16 ;
     *     *(humberfoo + 2) = i>>8 &0xff;
     *     *(humberfoo + 3) = i & 0xff;
     * } else {
     *     *lengthofhumberptr = 5;
     *     *(humberfoo  )   = 128 +5;
     *     *(humberfoo + 1) = i>>24 ;
     *     *(humberfoo + 2) = i>>16 &0xff;
     *     *(humberfoo + 3) = i>>8 &0xff;
     *     *(humberfoo + 4) = i & 0xff;
     * }
     */

    return humberfoo;
}

/**********************************************************************
 *
 **********************************************************************/
    unsigned int
functionintof(humber h)
{
    if (((unsigned) h[0]) <= 127)
        return h[0];

    else {
        int i;
        int k = h[0] - 128;
        switch (k) {
        case 0: /* reserved for chge or wierd stuff */
            fprintf(stderr, "case %d in intof first 6 bytes: ", k);

            for (i = 0; i < 6; i++)
                fprintf(stderr, "%x ", h[i]);

            gerror("weird length 0 in intof \n");
            break;

        case 2:
            /* fprintf(stderr, "%x ", h[1]); */
            return h[1];

        case 3:
            /* fprintf(stderr, "%x %x ", h[1], h[2]); */
            return (h[1] << 8) + h[2];

        case 4:
            /* fprintf(stderr, "%x %x %x ", h[1], h[2], h[3]); */
            return (((h[1] << 8) + h[2]) << 8) + h[3];

        case 5:
            /* fprintf(stderr, "%x %x %x %x ", h[1], h[2], h[3], h[4]); */

            k = (((((h[1] << 8) + h[2]) << 8) + h[3]) << 8) + h[4];
            if (k == -1)
                gerror("-1 in intof \n");

            return k;

        default:
            fprintf(stderr, "case %d in intof close by bytes: ", k);

            for (i =- 8; i < 0; i++)
                fprintf(stderr, "%x ", h[i]);

            fprintf(stderr, ": ");

            for (i = 0; i < 6; i++)
                fprintf(stderr, "%x ", h[i]);

            fprintf(stderr, "\n");

            for (i =- 8; i < 0; i++)
                fprintf(stderr, "%d ", h[i]);

            fprintf(stderr, ": ");

            for (i = 0; i < 6; i++)
                fprintf(stderr, "%d ", h[i]);

            fprintf(stderr, "\n");
            gerror("\nin intof default case\n");
            return 33333;
        }
    }

    return 0; /* for lint */
}

/**********************************************************************
 *
 **********************************************************************/
    unsigned int
intlengthoflength(unsigned int i)
{
    if      (i < 127)         return 1;
    else if (i < FIRSTCHAR)   return 2;
    else if (i < SECONDCHAR)  return 3;
    else if (i < THIRDCHAR)   return 4;
    else if (i < FOURTHCHAR)  return 5;
    else I(false); //invariant: length is unreasonable

    return 0;
}

/**********************************************************************
 *
 **********************************************************************/
    unsigned int
lengthoflength(humber ptr)
{
    /* YUCK */ int i;

    if (*ptr < 128)
        return 1;

    switch (*ptr) {
    case 128: /* break to ultraint and specialcases */
        gerror("ultraints not defined yet");
        return 12134;

    case 129:  return 1 + lengthoflength(ptr + 1);
    case 130:  return 3;
    case 131:  return 4;
    case 132:  return 5;
    case 133:  return 6;

    default:
        fprintf(stderr, "case %d in lengthoflength close by bytes:\n\t", ptr[-1]);

        for (i =- 6; i < 0; i++)
            fprintf(stderr, "%x ", ptr[i-1]);

        fprintf(stderr, ": ");

        for (i = 0; i < 6; i++)
            fprintf(stderr, "%x ", ptr[i-1]);

        fprintf(stderr, "\n");
        gerror("Bad lengthoflength\n");

        return 1;
    }
}

/**********************************************************************
 *
 **********************************************************************/
    humber
exponentof(humber /*vartumbler*/ ptr)
{
    return ptr + mlengthoflength(ptr);
}

/**********************************************************************
 *
 **********************************************************************/
    unsigned int
functionlengthof(humber ptr)   /* length of humber or vartumbler */
{
    int i;

    /*
     * typedef union {
     *     char charlongchar[ sizeof(int) ];
     *     int  charlonglong;
     * } typecharlong;
     *
     * typecharlong temp;
     * temp.charlonglong = 0;
     */

    if (*ptr < 128)
        return 1;

    switch (*ptr++) {
    case 128:     /* break to ultralong and specialcases*/
        gerror("ultralongs not defined yet");
        return 12134;

    case 129: /* negative */ return 1 + lengthof(ptr + 1); /* is this right if we use 1 in the length of length */
    case 133:  return 5;
    case 132:  return 4;
    case 131:  return 3;
    case 130:  return 2;

    default:
        fprintf(stderr, "case %d in lengthof close by bytes:\n\t", ptr[-1]);

        for (i =- 6; i < 0; i++)
            fprintf(stderr, "%x ", ptr[i-1]);

        fprintf(stderr, ": ");

        for (i = 0; i < 6; i++)
            fprintf(stderr, "%x ", ptr[i-1]);

        fprintf(stderr, "\n");

        gerror("Bad length in functionlengthof\n");
        return 1;
    }
}

/**********************************************************************
 *
 **********************************************************************/
    humber
mantissaof(humber ptr)  /* returns a ptr to the first humber in the mantissa of the vartumbler of the tumbler*/
{
    /*
     * this is correct but expensive
     *     temp = ptr + lengthoflength(ptr) + lengthofexp(ptr);
     */

    ptr = ptr + mlengthoflength(ptr); /* thus ptr points at exponent */

    if (*ptr < 128)
        return ptr + 1;
    else
        return ptr + lengthof(ptr); /* and add the length of the exponent */
}

/**********************************************************************
 *  Original Copyright � 1979-1999 Udanax.com.   All Rights Reserved
 **********************************************************************/
