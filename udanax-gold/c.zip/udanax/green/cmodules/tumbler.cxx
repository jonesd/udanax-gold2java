/**
 * @file  tumbler.cxx
 * @brief Memory-Resident Tumbler Objects
 *
 * (to be filled in)
 *
 **/

#include <strstream>

#include <nana/nana.h>

#include "tumbler.h"

/**
 * @class Tumbler

There are two basic types of tumblers: address tumblers and difference tumblers.
The former represent a specific zero-dimensional point along the tumbler number line
and the latter represent a span or segment along the number line.

However, difference tumblers don't represent a count of anything.  They don't
mean some N characters, N bytes or N paragraphs.  Because of this they have
no meaning in isolation but only when paired with an address tumbler.  This
(address, difference) tuple is called a span.


 *
 **/

//static Tumbler weakSubtract(const Tumbler& a, const Tumbler& b);

const Tumbler Tumbler::zero(0);

/**********************************************************************
 *
 **********************************************************************/
//    static void
//hexdump(char *ptr, int n)
//{
//    cout << endl;
//
//    for (int i = 0; i < n; i++) {
//        int x = *(ptr + i) & 0xff;
//        cout << hex << x << ' ';
//    }
//
//    cout << endl;
//}

/**********************************************************************
 *
 **********************************************************************/
Tumbler::Tumbler(const char *s)
{
    istrstream is(s);

    is >> *this;
}

/**********************************************************************
 *
 **********************************************************************/
Tumbler::Tumbler(int d)
{
    clear();
    mantissa[0] = d;
}

/**********************************************************************
 *
 **********************************************************************/
Tumbler::Tumbler(const Tumbler& t)
: negsign(t.negsign)
, exp(t.exp)
{
    memcpy(mantissa, t.mantissa, sizeof(mantissa));
}

/**********************************************************************
 *                 Tumbler Assignment Operator
 **********************************************************************/
//    Tumbler&
//Tumbler::operator=(Tumbler& t)
//{
//    if (this == &t)
//        return *this;
//
//    negsign = t.negsign;
//    exp = t.exp;
//
//    memcpy(mantissa, t.mantissa, sizeof(mantissa));
//
//    return *this;
//}

/**********************************************************************
 *
 **********************************************************************/
    bool
tumbleraccounteq(Tumbler *aptr, Tumbler *bptr)
{
    if (aptr->exp != bptr->exp || aptr->negsign != bptr->negsign)
        return false;

    int i, j;
    for (j = 0, i = 0; i < Tumbler::NPLACES; i++) {
        if (aptr->mantissa[i] != bptr->mantissa[i])
            return false;

        if (aptr->mantissa[i] == 0 && ++j == 2)
            return true;
    }

    return true;
}

/**********************************************************************
 *
 **********************************************************************/
//    Tumbler
//Tumbler::operator+(const
//
//class complex {
//public:
//    complex (_FLT r = 0, _FLT i = 0): re (r), im (i) { }
//
//    complex& operator += (const complex&);
//    complex& operator -= (const complex&);
//    complex& operator *= (const complex&);
//    complex& operator /= (const complex&);
//
//private:
//    _FLT re, im;
//
//    friend complex& __doapl<> (complex *, const complex&);
//    friend complex& __doami<> (complex *, const complex&);
//    friend complex& __doaml<> (complex *, const complex&);
//    friend complex& __doadv<> (complex *, const complex&);
//};
//
//template <class _FLT> istream& operator >> (istream&, complex<_FLT>&);
//template <class _FLT> ostream& operator << (ostream&, const complex<_FLT>&);
//
//bool
//operator == (const complex& x, const complex& y) __attribute__ ((const));
//
//bool
//operator == (const complex& x, const complex& y)
//{
//  return real (x) == real (y) && imag (x) == imag (y);
//}
//
//template <class _FLT> inline bool
//operator == (const complex<_FLT>& x, _FLT y) __attribute__ ((const));
//
//template <class _FLT> inline bool
//operator == (const complex<_FLT>& x, _FLT y)
//{
//  return real (x) == y && imag (x) == 0;
//}
//
//template <class _FLT> inline bool
//operator == (_FLT x, const complex<_FLT>& y) __attribute__ ((const));
//
//template <class _FLT> inline bool
//operator == (_FLT x, const complex<_FLT>& y)
//{
//  return x == real (y) && imag (y) == 0;
//}
//
//template <class _FLT> inline bool
//operator != (const complex<_FLT>& x, const complex<_FLT>& y) __attribute__ ((const));
//
//template <class _FLT> inline bool
//operator != (const complex<_FLT>& x, const complex<_FLT>& y)
//{
//  return real (x) != real (y) || imag (x) != imag (y);
//}
//
//template <class _FLT> inline bool
//operator != (const complex<_FLT>& x, _FLT y) __attribute__ ((const));
//
//template <class _FLT> inline bool
//operator != (const complex<_FLT>& x, _FLT y)
//{
//  return real (x) != y || imag (x) != 0;
//}
//
//template <class _FLT> inline bool
//operator != (_FLT x, const complex<_FLT>& y) __attribute__ ((const));
//
//template <class _FLT> inline bool
//operator != (_FLT x, const complex<_FLT>& y)
//{
//  return x != real (y) || imag (y) != 0;
//}
//
//// Some targets don't provide a prototype for hypot when -ansi.
//extern "C" double hypot (double, double) __attribute__ ((const));
//
//template <class _FLT> inline _FLT
//abs (const complex<_FLT>& x) __attribute__ ((const));
//
//template <class _FLT> inline _FLT
//abs (const complex<_FLT>& x)
//{
//  return hypot (real (x), imag (x));
//}
//
//template <class _FLT> inline _FLT
//abs (const complex<_FLT>& x) __attribute__ ((const));
//
//template <class _FLT> inline _FLT
//abs (const complex<_FLT>& x)
//{
//  return hypot (real (x), imag (x));
//}
//
//
//
//
//

/**********************************************************************
 *
 **********************************************************************/
    int
Tumbler::compareTo(const Tumbler& other) const
{
    if (iszero()) {
        if (other.iszero())
            return EQUAL;  // Case 1: 0 ? 0 => EQUAL
        else
            return other.negsign ? GREATER : LESS;
    }

    if (other.iszero())
        return negsign ? LESS : GREATER;

    if (negsign == other.negsign)
        return negsign ? other.compareToAbs(*this) : compareToAbs(other);

    return negsign ? LESS : GREATER;
}

/**********************************************************************
 *
 **********************************************************************/
    int
Tumbler::compareToAbs(const Tumbler& other) const
{
    if (exp != other.exp) {
        if (exp < other.exp)  return LESS;
        else                  return GREATER;

    } else {
        const Tumbler::digit *a = mantissa;
        const Tumbler::digit *b = other.mantissa;

        for (int i = Tumbler::NPLACES; --i; ) {
            int cmp = *a - *b;

            if (cmp == 0) { /* this is an efficiency hack */
                a++; b++;
                continue;

            } else if (cmp < 0)
                return LESS;

            else
                return GREATER;
        }
    }

    return EQUAL;
}

/**********************************************************************
 *
 **********************************************************************/
    const Tumbler
Tumbler::increment(int rightshift, int bint) const
{
    Tumbler c;

    if (iszero()) { // 0 + int => int
        c.clear();
        c.exp = -rightshift;
        c.mantissa[0] = bint;
        return c;
    }

    c = *this;

    int idx;
    for (idx = Tumbler::NPLACES; mantissa[--idx] == 0 && idx > 0; )
        ;

    I(idx + rightshift < Tumbler::NPLACES); //invariant: increment must not cause overflow

    c.mantissa[idx + rightshift] += bint;
    tumblerjustify(&c);

    return c;
}

/**********************************************************************
 *
 **********************************************************************/
    const StreamAddr
StreamAddr::increment(int rightshift, int bint) const
{
    StreamAddr c;

    if (iszero()) { // 0 + int => int
        c.clear();
        c.exp = -rightshift;
        c.mantissa[0] = bint;
        return c;
    }

    c = *this;

    int idx;
    for (idx = Tumbler::NPLACES; mantissa[--idx] == 0 && idx > 0; )
        ;

    I(idx + rightshift < Tumbler::NPLACES); //invariant: increment must not cause overflow

    c.mantissa[idx + rightshift] += bint;
    tumblerjustify(&c);

    return c;
}

/**********************************************************************
 *
 **********************************************************************/
    const IStreamAddr
IStreamAddr::increment(int rightshift, int bint) const
{
    IStreamAddr c;

    if (iszero()) { // 0 + int => int
        c.clear();
        c.exp = -rightshift;
        c.mantissa[0] = bint;
        return c;
    }

    c = *this;

    int idx;
    for (idx = Tumbler::NPLACES; mantissa[--idx] == 0 && idx > 0; )
        ;

    I(idx + rightshift < Tumbler::NPLACES); //invariant: increment must not cause overflow

    c.mantissa[idx + rightshift] += bint;
    tumblerjustify(&c);

    return c;
}

/**********************************************************************
 *    Compare Address Against the Left & Right Side of an Interval
 **********************************************************************/
    int
intervalcmp(Tumbler *left, Tumbler *right, Tumbler *address)
{
    int cmp = address->compareTo(*left);

    if (cmp == Tumbler::LESS)        return TOMYLEFT;        // address < myleft
    else if (cmp == Tumbler::EQUAL)  return ONMYLEFTBORDER;  // address = myleft

                                                             // address > myleft
    cmp = address->compareTo(*right);

    if (cmp == Tumbler::LESS)        return THRUME;          // address < myright
    else if (cmp == Tumbler::EQUAL)  return ONMYRIGHTBORDER; // address = myright
    else                             return TOMYRIGHT;       // address > myright

    return TOMYRIGHT; // DEBUG
}

/**********************************************************************
 *
 **********************************************************************/
    bool
tumblercheckptr(Tumbler *ptr, int /*typecrum*/ *crumptr)
{
//    bool wrong = false;

    I(ptr->exp <= 0); // Invalid Exponent
    I(!ptr->negsign || ptr->mantissa[0] != 0); // Negative Zero
    I(!ptr->exp || ptr->mantissa[0] != 0); // Not Normalized

    int i;
    if (ptr->mantissa[0] == 0) {
        for (i = 1; i < Tumbler::NPLACES; ++i)
            I(ptr->mantissa[i] != 0);
    }

    for (i = 0; i < Tumbler::NPLACES; ++i)
        I((int) (ptr->mantissa[i]) >= 0);

//    if (wrong) {
//#ifndef DISTRIBUTION
//        dumptumbler(ptr);
//        if (crumptr)
//            dump((CoreCrum *) crumptr);  //fixme: remove crum ref from tumbler.cpp
//
//        fprintf(stderr, "\n\n invalid tumbler \n\n");
//
//        if (crumptr)
//            dumpwholetree((CoreCrum *) crumptr); //fixme: remove crum ref from tumbler.cpp
//
//        gerror("  invalid tumbler\n");
//#else
//        gerror("");
//#endif
//        return false;
//    }

    return true;
}

/**********************************************************************
 *
 **********************************************************************/
    bool
tumblercheck(Tumbler *ptr)
{
    return tumblercheckptr(ptr, (int *) NULL);
}

/**********************************************************************
 *
 **********************************************************************/
/* says whether there is no more than a single non-zero
**  digit in mantissa
*/
    bool
is1story(Tumbler *tumblerptr)
{
    for (int i = 1; i < Tumbler::NPLACES; i++)
        if (tumblerptr->mantissa[i] != 0)
            return false;

    return true;
}

/**********************************************************************
 *
 **********************************************************************/
    int
nstories(Tumbler *tumblerptr)
{
    /*
     * if (!tumblercheck(tumblerptr))
     *     qerror();
     */

    int i;
    for (i = Tumbler::NPLACES; i > 0 && tumblerptr->mantissa[--i] == 0;)
        ;

    return i + 1;
}

/**********************************************************************
 *
 **********************************************************************/
    int
tumblerlength(Tumbler *tumblerptr)
{
    return nstories(tumblerptr) - tumblerptr->exp;
}

/**********************************************************************
 *
 **********************************************************************/
    int
lastdigitintumbler(Tumbler *tumblerptr)
{
    return tumblerptr->mantissa[ nstories(tumblerptr)-1 ];
}

/* --------- Routines below set and change tumblers -------- */

/**********************************************************************
 *
 **********************************************************************/
    void
tumblerjustify(Tumbler *tumblerptr)
{
    Tumbler::digit *mantissaptr = tumblerptr->mantissa;
    if (mantissaptr[0] != 0)
        return;

    int shift;
    for (shift = 0; mantissaptr[shift] == 0; ++shift) {
        if (shift == Tumbler::NPLACES - 1) {
            tumblerptr->exp = 0;
            tumblerptr->negsign = false;
            return;
        }
    }

    int i, j;
    for (i = 0, j = shift; j < Tumbler::NPLACES; )
        mantissaptr[i++] = mantissaptr[j++];

    while (i < Tumbler::NPLACES)
        mantissaptr[i++] = 0;

    tumblerptr->exp -= shift;
}

/**********************************************************************
 *
 **********************************************************************/
//    void
//functiontumbleradd(Tumbler *aptr, Tumbler *bptr, Tumbler *cptr)
//{
//    if (bptr->iszero()) {
//        *cptr = *aptr;
//        return;
//
//    } else if (aptr->iszero()) {
//        *cptr = *bptr;
//        return;
//
//    } else if (aptr->negsign == bptr->negsign) {
//        absadd(aptr, bptr, cptr);
//        cptr->negsign = aptr->negsign;
//
//        /* absadd returns justified result so no need to justify */
//        /* I'm not so sure of the subtracts, they aren't used much */
//
//        /*
//         * if (cptr->mantissa[0] == 0)
//         *     partialtumblerjustify(cptr);
//         */
//
////    } else if (abscmp(aptr, bptr) == GREATER) {
////        strongsub(aptr, bptr, cptr);
////        cptr->negsign = aptr->negsign;
////        if (cptr->mantissa[0] == 0)
////            partialtumblerjustify(cptr);
//
//    } else {
////        weaksub(bptr, aptr, cptr);
//        cptr->negsign = bptr->negsign;
//        if (cptr->mantissa[0] == 0)
//            partialtumblerjustify(cptr);
//    }
//}

/**********************************************************************
 *
 **********************************************************************/
    const Tumbler
operator + (const Tumbler& addr, const Tumbler& diff) // Addr = Addr + Diff
{
    I(!addr.iszero());        // Zero Stream Address has no Meaning (?)
    I(addr.negsign == false); // Negative Stream Addresses have no Meaning
    I(diff.negsign == false); // Addr = Addr - Diff     *NOT ALLOWED*

    if (diff.iszero())
        return StreamAddr(addr); // Case 1: A + 0 => A

//    if (addr.iszero())
//        return StreamAddr(diff); // Case 2: 0 + B => B


    Tumbler sum;
    sum.negsign = false;

    const Tumbler::digit *addr_mant = addr.mantissa; // Ptr to Digits of Address
    const Tumbler::digit *diff_mant = diff.mantissa; // Ptr to Digits of Difference
          Tumbler::digit *sum_mant  = sum.mantissa;  // Ptr to Digits of Sum

    int i = 0, j = 0;

    if (addr.exp == diff.exp) { // Addr and Diff have Same Prefix of Zeroes
        sum.exp = addr.exp;

        sum_mant[0] = addr_mant[0] + diff_mant[0];
        i = j = 1;

    } else if (addr.exp > diff.exp) { // Addr has Longer Prefix of Zeroes
        sum.exp = addr.exp;

        int temp = addr.exp - diff.exp;
        while (i < temp)
            sum_mant[j++] = addr_mant[i++];

        sum_mant[j++] = addr_mant[i++] + diff_mant[0];
        i = 1;

    } else { // Diff has Longer Prefix of Zeroes
        sum.exp = diff.exp;

        int temp = diff.exp - addr.exp;
        while (i <= temp)
            sum_mant[j++] = diff_mant[i++];
    }

    while (j <= Tumbler::NPLACES - 1) // Copy Down Rest of Digits
        sum_mant[j++] = diff_mant[i++];

    return sum;

//    if (addr.negsign == diff.negsign) {
//        Tumbler acc;
//        absadd(&addr, &diff, &acc);
//        acc.negsign = addr.negsign;
//        return acc; // Case 3: +A + +B => +C
//                    // -or-    -A + -B => -C
//    }

    // Case 4: +A + -B => ?C  NO! Addr - Diff  *NOT ALLOWED*
    // -or-    -A + +B => ?C  NO! Negative Stream Addresses have no Meaning
    
//    Tumbler acc = weakSubtract(diff, addr);
//
//    acc.negsign = diff.negsign;
//    if (acc.mantissa[0] == 0)
//        partialtumblerjustify(&acc);
//
//    return acc;
}

/**********************************************************************
 *
 **********************************************************************/
    const StreamAddr
operator + (const StreamAddr& addr, const StreamDiff& diff) // Addr = Addr + Diff
{
    I(!addr.iszero());        // Zero Stream Address has no Meaning (?)
    I(addr.negsign == false); // Negative Stream Addresses have no Meaning
    I(diff.negsign == false); // Addr = Addr - Diff     *NOT ALLOWED*

    if (diff.iszero())
        return StreamAddr(addr); // Case 1: A + 0 => A

//    if (addr.iszero())
//        return StreamAddr(diff); // Case 2: 0 + B => B


    StreamAddr sum;
    sum.negsign = false;

    const Tumbler::digit *addr_mant = addr.mantissa; // Ptr to Digits of Address
    const Tumbler::digit *diff_mant = diff.mantissa; // Ptr to Digits of Difference
          Tumbler::digit *sum_mant  = sum.mantissa;  // Ptr to Digits of Sum

    int i = 0, j = 0;

    if (addr.exp == diff.exp) { // Addr and Diff have Same Prefix of Zeroes
        sum.exp = addr.exp;

        sum_mant[0] = addr_mant[0] + diff_mant[0];
        i = j = 1;

    } else if (addr.exp > diff.exp) { // Addr has Longer Prefix of Zeroes
        sum.exp = addr.exp;

        int temp = addr.exp - diff.exp;
        while (i < temp)
            sum_mant[j++] = addr_mant[i++];

        sum_mant[j++] = addr_mant[i++] + diff_mant[0];
        i = 1;

    } else { // Diff has Longer Prefix of Zeroes
        sum.exp = diff.exp;

        int temp = diff.exp - addr.exp;
        while (i <= temp)
            sum_mant[j++] = diff_mant[i++];
    }

    while (j <= Tumbler::NPLACES - 1) // Copy Down Rest of Digits
        sum_mant[j++] = diff_mant[i++];

    return sum;

//    if (addr.negsign == diff.negsign) {
//        Tumbler acc;
//        absadd(&addr, &diff, &acc);
//        acc.negsign = addr.negsign;
//        return acc; // Case 3: +A + +B => +C
//                    // -or-    -A + -B => -C
//    }

    // Case 4: +A + -B => ?C  NO! Addr - Diff  *NOT ALLOWED*
    // -or-    -A + +B => ?C  NO! Negative Stream Addresses have no Meaning
    
//    Tumbler acc = weakSubtract(diff, addr);
//
//    acc.negsign = diff.negsign;
//    if (acc.mantissa[0] == 0)
//        partialtumblerjustify(&acc);
//
//    return acc;
}

/**********************************************************************
 *
 **********************************************************************/
    const Tumbler
operator - (const Tumbler& addr1, const Tumbler& addr2)
{
    I(!addr1.iszero()); // Zero Stream Address has no Meaning (?)
    I(addr1.negsign == false); // Negative Stream Addresses have no Meaning

    I(!addr2.iszero()); // Addr of Zero Not Permitted
    I(addr2.negsign == false); // Negative Stream Addresses have no Meaning

    if (addr1 == addr2)
        return StreamDiff(0); // Case 1: A - A => 0

    Tumbler diff(0);

    if (addr2.exp < addr1.exp) {
        diff = addr1;
        return diff;
    }

    diff.exp = addr1.exp;

    int i;
    for (i = 0; addr1.mantissa[i] == addr2.mantissa[i]; ++i) {
        --diff.exp;
        if (i >= Tumbler::NPLACES)
            return diff;
    }

    diff.mantissa[0] = addr1.mantissa[i] - addr2.mantissa[i];

    if (++i >= Tumbler::NPLACES)
        return diff;

    int j;
    for (j = 1; j < Tumbler::NPLACES && i < Tumbler::NPLACES; )
        diff.mantissa[j++] = addr1.mantissa[i++];

    return diff;
}

/**********************************************************************
 *
 **********************************************************************/
    const StreamDiff
operator - (const StreamAddr& addr1, const StreamAddr& addr2)
{
    I(!addr1.iszero()); // Zero Stream Address has no Meaning (?)
    I(addr1.negsign == false); // Negative Stream Addresses have no Meaning

    I(!addr2.iszero()); // Addr of Zero Not Permitted
    I(addr2.negsign == false); // Negative Stream Addresses have no Meaning

    if (addr1 == addr2)
        return StreamDiff(0); // Case 1: A - A => 0

    StreamDiff diff(0);

    if (addr2.exp < addr1.exp) {
        diff = addr1;
        return diff;
    }

    diff.exp = addr1.exp;

    int i;
    for (i = 0; addr1.mantissa[i] == addr2.mantissa[i]; ++i) {
        --diff.exp;
        if (i >= Tumbler::NPLACES)
            return diff;
    }

    diff.mantissa[0] = addr1.mantissa[i] - addr2.mantissa[i];

    if (++i >= Tumbler::NPLACES)
        return diff;

    int j;
    for (j = 1; j < Tumbler::NPLACES && i < Tumbler::NPLACES; )
        diff.mantissa[j++] = addr1.mantissa[i++];

    return diff;
}

/**********************************************************************
 * Non-Public Helper Function
 **********************************************************************/
//    Tumbler
//weakSubtract(const Tumbler& a, const Tumbler& b)
//{
//    Tumbler acc(0);
//
//    if (a == b)
//        return zero; // Case 1: N - N => 0
//
//    acc.exp = a.exp;
//
//    int expdiff = a.exp - b.exp;
//    int i;
//    for (i = 0; i < expdiff; ++i) {
//        acc.mantissa[i] = a.mantissa[i];
//
//        if (i >= Tumbler::NPLACES)
//            return acc;
//    }
//    acc.mantissa[i] = a.mantissa[i] - b.mantissa[0];
//
//    return acc;
//}

/**********************************************************************
 *
 **********************************************************************/
//    void
//absadd(const Tumbler *aptr, const Tumbler *bptr, Tumbler *cptr)
//{
//    const Tumbler::digit *amant = aptr->mantissa;
//    const Tumbler::digit *bmant = bptr->mantissa;
//
//    Tumbler answer;
//    answer.negsign = false;
//
//    Tumbler::digit *ansmant = answer.mantissa;
//
//    int i = 0, j = 0;
//    if (aptr->exp == bptr->exp) {
//        answer.exp = aptr->exp;
//        ansmant[0] = amant[0] + bmant[0];
//        i = j = 1;
//
//    } else if (aptr->exp > bptr->exp) {
//        answer.exp = aptr->exp;
//        int temp = aptr->exp-bptr->exp;
//
//        while (i < temp)
//            ansmant[j++] = amant[i++];
//
//        ansmant[j++] = amant[i++] + bmant[0];
//        i = 1;
//
//    } else {
//        answer.exp = bptr->exp;
//        int temp = bptr->exp - aptr->exp;
//
//        while (i <= temp)
//            ansmant[j++] = bmant[i++];
//    }
//
//    while ( j <= Tumbler::NPLACES -1 )
//        ansmant[j++] = bmant[i++];
//
//    *cptr = answer;
//}

/**********************************************************************
 *
 **********************************************************************/
//#ifdef  OlDVeRsIon
//    void
//absadd(Tumbler *aptr, Tumbler *bptr, Tumbler *cptr)
//{
//    Tumbler::digit *amant = aptr->mantissa;
//    Tumbler::digit *bmant = bptr->mantissa;
//
//    Tumbler answer;
//    answer.clear();
//
//    Tumbler::digit *ansmant = answer.mantissa;
//
//    int i = j = 0;
//    if (aptr->exp == bptr->exp) {
//        answer.exp = aptr->exp;
//        ansmant[0] = amant[0] + bmant[0];
//        i = j = 1;
//
//    } else if (aptr->exp > bptr->exp) {
//        answer.exp = aptr->exp;
//        int temp = aptr->exp-bptr->exp;
//
//        while (i < temp)
//            ansmant[j++] = amant[i++];
//
//        ansmant[j++] = amant[i++] + bmant[0];
//        i = 1;
//
//    } else {
//        answer.exp = bptr->exp;
//        temp = bptr->exp - aptr->exp;
//
//        while (i <= temp)
//            ansmant[j++] = bmant[i++];
//    }
//
//    while (j <= Tumbler::NPLACES-1)
//        ansmant[j++] = bmant[i++];
//
//    *cptr = answer;
//}
//#endif

/**********************************************************************
 *
 **********************************************************************/
    void
partialtumblerjustify(Tumbler *tumblerptr)
{
    Tumbler::digit *mantissaptr = tumblerptr->mantissa;

    /* test commented out because is done before this routine is called for efficiency */
    /*
     * if (mantissaptr[0] != 0)
     *     return;
     */

    int shift;
    for (shift = 0; mantissaptr[shift] == 0; ++shift) {
        if (shift == Tumbler::NPLACES - 1) {
            tumblerptr->exp = 0;
            tumblerptr->negsign = false;
            return;
        }
    }

    int i, j;
    for (i = 0, j = shift; j < Tumbler::NPLACES; )
        mantissaptr[i++] = mantissaptr[j++];

    while (i < Tumbler::NPLACES)
        mantissaptr[i++] = 0;

    tumblerptr->exp -= shift;

    /*
     * if (!tumblercheck(tumblerptr))
     *     qerror();
     */
}

/**********************************************************************
 *
 **********************************************************************/
//    StreamAddr&
//StreamAddr::operator += (const StreamDiff& x) // Addr += Diff
//{
//
//}

/**********************************************************************
 *
 **********************************************************************/
//    StreamDiff&
//StreamAddr::operator - (const StreamAddr& other) // Diff = Addr - Addr
//{
//    StreamDiff acc;
//
//    if (other.iszero())
//        acc = *this; //???
//
//    else if (*this == other)
//        acc->clear();
//
//    else if (iszero()) {
//        acc = other;
//        acc.negsign = !acc.negsign;
//
//    } else {
//        StreamAddr temp;
//        temp      = other;
//        temp.negsign = !temp.negsign;
//
//        acc = *aptr + temp;
//    }
//
//    tumblerjustify(acc);
//
//    return acc;
//}

/**********************************************************************
 *
 **********************************************************************/
//    void
//tumblersub(Tumbler *aptr, Tumbler *bptr, Tumbler *cptr)
//{
//    if (bptr->iszero())
//        *cptr = *aptr;
//
//    else if (*aptr == *bptr)
//        cptr->clear();
//
//    else if (aptr->iszero()) {
//        *cptr = *bptr;
//        cptr->negsign = !cptr->negsign;
//
//    } else {
//        Tumbler temp;
//        temp      = *bptr;
//        temp.negsign = !temp.negsign;
//        tumbleradd(aptr, &temp, cptr);
//    }
//
//    tumblerjustify(cptr);
//}

/**********************************************************************
 *
 **********************************************************************/
//    void
//strongsub(Tumbler *aptr, Tumbler *bptr, Tumbler *cptr)
//{
//    Tumbler answer;
//
//    answer.clear();
//    if (*aptr == *bptr) {
//        *cptr = answer;
//        return;
//    }
//
//    if (bptr->exp < aptr->exp) {
//        *cptr = *aptr;
//        return;
//    }
//
//    answer.exp = aptr->exp;
//
//    int i;
//    for (i = 0; aptr->mantissa[i] == bptr->mantissa[i]; ++i) {
//        --answer.exp;
//        if (i >= Tumbler::NPLACES) {
//            *cptr = answer;
//            return;
//        }
//    }
//
//    answer.mantissa[0] = aptr->mantissa[i] - bptr->mantissa[i];
//
//    if (++i >= Tumbler::NPLACES) {
//        *cptr = answer;
//        return;
//    }
//
//    int j;
//    for (j = 1; j < Tumbler::NPLACES && i < Tumbler::NPLACES;)
//        answer.mantissa[j++] = aptr->mantissa[i++];
//
//    *cptr = answer;
//}

/**********************************************************************
 *
 **********************************************************************/
    int
tumblerintdiff(const Tumbler *aptr, const Tumbler *bptr)
{
    Tumbler c = *aptr - *bptr;

    return c.mantissa[0];
}

/**********************************************************************
 *
 **********************************************************************/
//    void
//tumblerincrement(const Tumbler *aptr, int rightshift, int bint, Tumbler *cptr)
//{
//    if (aptr->iszero()) {
//        cptr->clear();
//        cptr->exp = -rightshift;
//        cptr->mantissa[0] = bint;
//        return;
//    }
//
//    if (aptr != cptr)
//        *cptr = *aptr;
//
//    int idx;
//    for (idx = Tumbler::NPLACES; aptr->mantissa[--idx] == 0 && idx > 0; )
//        ;
//
//    I(idx + rightshift < Tumbler::NPLACES); //invariant: increment must not cause overflow
//
//    cptr->mantissa[idx + rightshift] += bint;
//    tumblerjustify(cptr);
//}

/**********************************************************************
 *
 **********************************************************************/
    void
tumblertruncate(Tumbler *aptr, int bint, Tumbler *cptr)
{
    Tumbler answer = *aptr;

    int i;
    for (i = answer.exp; i < 0 && bint > 0; ++i, --bint)
        ;

    if (bint <= 0)
        answer.clear();
    else
        for (; bint < Tumbler::NPLACES; ++bint)
            answer.mantissa[bint] = 0;

    tumblerjustify(&answer);
    *cptr = answer;
}

/**********************************************************************
 *
 **********************************************************************/
    void
prefixtumbler(Tumbler *aptr, int bint, Tumbler *cptr)
{
    Tumbler temp1(0);

    temp1.mantissa[0] = bint;

    Tumbler temp2 = *aptr;

    if (!temp2.iszero()) /* yuckh! */
        temp2.exp -= 1;

    *cptr = temp1 + temp2;
//    tumbleradd(&temp1, &temp2, cptr);
}

/**********************************************************************
 *
 **********************************************************************/
    void
beheadtumbler(Tumbler *aptr, Tumbler *bptr)
{
    Tumbler temp = *aptr;
    ++temp.exp;

    if (aptr->exp == 0)
        temp.mantissa[0] = 0;

    tumblerjustify(&temp);
    *bptr = temp;
}

/**********************************************************************
 *
 **********************************************************************/
    void
docidandvstream2tumbler(Tumbler *docid, Tumbler *vstream, Tumbler *tumbleptr)
{
    *tumbleptr = *docid;

    int i;
    for (i = Tumbler::NPLACES-1; i >= 0; i--) {
        if (tumbleptr->mantissa[i]) {
            ++i;
            break;
        }
    }

    int j;
    for (j = 0; i < Tumbler::NPLACES && j < Tumbler::NPLACES; )
        tumbleptr->mantissa[++i] = vstream->mantissa[j++];
}

/**
 * @function istream& operator >> (istream& is, Tumbler& t)
 * @brief IOStream Extractor: Turn a String into a Tumbler
 **/
    istream&
operator >> (istream& is, Tumbler& t)
{
    t.clear();

    if (is.peek() == '-') { // If String Starts with a Negative Sign,
        is.get();           //   Read and Discard It and
        t.negsign = true;   //   Set the Tumbler's Sign to NEGATIVE
    }

    int i;
    if (is.flags() & ios::scientific) { // Input in Exponentized Form
        for (i = -1; is.good() && i < Tumbler::NPLACES; ++i) {
            if (i < 0)  is >> t.exp;
            else        is >> t.mantissa[i];

            if (is.peek() == '.') // If Next Character is the Digit Separator,
                is.get();         //   Discard It and Read Next Digit
            else
                break;            // Else Exit Digit Collection Loop
        }

        t.exp = -t.exp;

        char c = is.peek();
        if (c != '~' && c != '\n' && c != '\0') { // If Next Char is Not the Word Separator,
            is.setstate(ios::failbit); // Tumbler is Not Terminated Correctly
            cout << "setstate1: " << hex << int(c) << endl;
        }
        is.get(); // Discard Word Separator

    } else { // Input in Conventional Form
        for (i = 0; is.good() && i < Tumbler::NPLACES; ++i) {
            is >> t.mantissa[i];

            if (t.mantissa[i] == 0 && i == 0) {
                --t.exp;
                --i;
            }

            if (is.peek() == '.') // If Next Character is the Digit Separator,
                is.get();         //   Discard It and Read Next Digit
            else
                break;            // Else Exit Digit Collection Loop
        }

        char c = is.peek();
        if (!is.eof()) {
            if (c != '\n' && c != '\0') { // If Next Char is Not the Word Separator,
                is.setstate(ios::failbit); // Tumbler is Not Terminated Correctly
                cout << "setstate2: " << hex << int(c) << endl;
            }
            is.get(); // Discard Word Separator
        }
    }

    for (i = 0; i < Tumbler::NPLACES && t.mantissa[i] == 0; ++i)
        ;

    if (i == Tumbler::NPLACES)
        t.exp = 0;

    return is;
}

/**
 * @function ostream& operator << (ostream& os, const Tumbler& t)
 * @brief IOStream Inserter: Turn a Tumbler into a String
 **/
    ostream&
operator << (ostream& os, const Tumbler& t)
{
    int place = Tumbler::NPLACES;
    do { --place; } // Remove Trailing Zeroes from Mantissa
    while (place > 0 && t.mantissa[place] == 0);

    if (t.negsign)
        os << '-';

    int i;

    if (os.flags() & ios::scientific) { // Output in Exponentized Form
        os << dec << -t.exp; // Output Exponent (Count of Leading Zeroes)

        for (i = 0; i <= place; ++i)
            os << '.' << dec << t.mantissa[i];

        os << '~';

    } else { // Output in Conventional Form

        for (i = t.exp; i < 0; i++)
            os << "0.";

        place = Tumbler::NPLACES;
        do {
            --place;
        } while (place > 0 && t.mantissa[place] == 0);

        for (i = 0; i <= place; i++) {
            os << dec << t.mantissa[i];
            if (i < place)
                os << '.';
        }
    }

    return os;
}

/**********************************************************************
 *  Original Copyright � 1979-1999 Udanax.com.   All Rights Reserved
 **********************************************************************/
