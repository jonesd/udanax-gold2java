/**********************************************************************
 * Copyright 2002 Jeff Rush <jrush@taupro.com>
 * Original Copyright 1979-2002 Udanax.com
 *
 * This file is part of the Udanax xanalogical storage system.
 *
 * Udanax is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * Udanax is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with Udanax; if not, write to the Free Software Foundation,
 * Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 **********************************************************************/

/**
 * @file  udanax.h
 * @brief ???
 *
 * (to be defined)
 *
 **/

/* Modification History:
 * $Log: udanax.h,v $
 * Revision 1.6  2002/07/14 08:29:43  jrush
 * Added include of nana.h and assert.h
 *
 * Revision 1.5  2002/05/28 03:51:13  jrush
 * Updated sources to comply with a GPL licensing.
 *
 * Revision 1.4  2002/04/13 14:08:35  jrush
 * Changed typedef of structs into just structs, for C++ style.
 *
 * Revision 1.3  2002/04/13 13:43:45  jrush
 * Added extern of Diskheader structure.
 *
 * Revision 1.2  2002/04/12 11:46:25  jrush
 * Major rearrangement of include contents, to reflect a hopefully more
 * logical layout as we refactor Udanax into classes.
 *
 * Revision 1.1  2002/04/12 09:32:51  jrush
 * Renamed xanadu.h to udanax.h
 *
 * Revision 1.9  2002/04/10 18:01:54  jrush
 * Renamed class typeisa to IStreamAddr.
 *
 * Revision 1.8  2002/04/09 21:45:46  jrush
 * Renamed class 'tumbler' to 'Tumbler', for consistency with Python sources,
 * and changed typeisa from typedef to a subclass, in preparation for cleaning
 * up the type/class tree.
 *
 * Revision 1.7  2002/04/06 17:05:57  jrush
 * Switched from referring to 'task' for a client connection to 'session',
 * and converted the typetask typedef/struct into a Session C++ class.
 *
 * Revision 1.6  2002/04/06 15:00:34  jrush
 * Changed INT to just 'int'.
 *
 * Revision 1.5  2002/02/14 05:40:42  jrush
 * Cleaned up source:
 *
 * 1. ran thru the indent tool to achieve a standard look,
 * 2. added structured comments at top for use with DOxygen reporting
 *    as well as CVS keywords,
 * 3. added #ifndef/#defines to prevent duplicate inclusions,
 * 4. insured all struct/union defs have names,
 * 5. centralized prototypes in protos.h, removing incomplete ones,
 * 6. cleaned up use of bool/BOOLEAN type to suit C++ type,
 * 7. fixed initializer nesting in tumbler constants.
 *
 */

#ifndef __UDANAX_UDANAX_H__
#define __UDANAX_UDANAX_H__

/* udanax.h - top header file */

#include "nana.h"
#include "assert.h"
#include "constants.h"
#include "types.h"

#define typegranf int *                /* temp -- int for alignment */
extern typegranf granf;

#define typespanf int *                /* temp -- int for alignment */
extern typespanf spanf;

#define typeorgl  int *                /* temp -- int for alignment */

#define typerequest int
#define NREQUESTS 40                   /* number of requests */
extern void (*requestfns[NREQUESTS]) (Session *);

/* spanfilade span types */
#define LINKFROMSPAN    1
#define LINKTOSPAN      2
#define LINKTHREESPAN   3
#define DOCISPAN        4

struct typespanpair {
    typespanpair       *nextspanpair;
    Tumbler             stream1;
    Tumbler             stream2;
    Tumbler             widthofspan;
};

typedef typespanpair   *typespanpairset;

/* 
 */

struct typeitemheader {
    typeitemheader     *next;
    typeitemid          itemid;
};

struct typetext {
    typetext           *next;
    typeitemid          itemid;
    int                 length;
    char                string[GRANTEXTLENGTH];
};
typedef typetext       *typetextset;

typedef typespan        typevspan;
typedef typevspan      *typevspanset;
typedef typespan        typeispan;
typedef typeispan      *typeispanset;

struct typevspec {
    typevspec          *next;
    typeitemid          itemid;
    IStreamAddr         docisa;
    typevspanset        vspanset;
};

union typespec {
    typevspec           xxxvspec;
    typeispan           xxxispan;
};
typedef typespec *typespecset;

struct typeboolsetnode {
    typeboolsetnode    *next;
    typeitemid          itemid;
    typespanset         val;
};

struct typeaddress {
    typeaddress        *next;
    typeitemid          itemid;
    IStreamAddr         address;
};

typedef typeaddress    *typeaddressset;
typedef typeaddress     typelink;
typedef typelink       *typelinkset;

union typevstuff {
    typetext            xxxtext;
    typelink            xxxlink;
};
typedef typevstuff     *typevstuffset;

struct typesporgl {
    typesporgl         *next;
    typeitemid          itemid;
    Tumbler             sporglorigin;
    Tumbler             sporglwidth;
    IStreamAddr         sporgladdress;
};

union typesporglitem {
    typeispan           xxxxispan;
    typesporgl          xxxxsporgl;
};
typedef typesporglitem *typesporglset;

union typeitem {
    typetext            xxtext;
    typespan            xxspan;
    typevspec           xxvspec;
    typeboolsetnode     xxboolsetnode;
    typeaddress         xxaddress;
    typesporgl          xxsporgl;
};

typedef typeitem       *typeitemset;

#define NODE      1
#define ACCOUNT   2
#define DOCUMENT  3
#define ATOM      4
                      /* atom types - don't change these */
#define TEXTATOM  1
#define LINKATOM  2

struct typehint {
    int                 supertype;
    int                 subtype;
    int                 atomtype;
    IStreamAddr         hintisa;
};

#include "protos.h"

/*
 * Global Variables (work to remove)
 */

extern int  debug;
extern long nsessorcommand;
extern int  reservnumber;
extern int  allocsize;
extern int  incrementalallocsize;

extern int incrementalallocsize;
extern int allocsize;

extern Diskheader diskheader;

#endif /* !__UDANAX_UDANAX_H__*/
