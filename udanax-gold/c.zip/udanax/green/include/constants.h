/**********************************************************************
 * Copyright 2002 Jeff Rush <jrush@taupro.com>
 * Original Copyright 1979-2002 Udanax.com
 *
 * This file is part of the Udanax xanalogical storage system.
 *
 * Udanax is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * Udanax is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with Udanax; if not, write to the Free Software Foundation,
 * Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 **********************************************************************/

/**
 * @file  constants.h
 * @brief ???
 *
 * (to be defined)
 *
 **/

/* Modification History:
 * $Log: constants.h,v $
 * Revision 1.4  2002/05/28 03:51:13  jrush
 * Updated sources to comply with a GPL licensing.
 *
 * Revision 1.3  2002/04/16 22:39:50  jrush
 * Converted many #defines into enumeration types instead, and adjusted
 * function prototypes accordingly.
 *
 * Revision 1.2  2002/04/12 11:46:24  jrush
 * Major rearrangement of include contents, to reflect a hopefully more
 * logical layout as we refactor Udanax into classes.
 *
 * Revision 1.1  2002/04/12 09:33:32  jrush
 * To clean up include nesting, added a place to collect constants.
 *
 *
 */

#ifndef __UDANAX_CONSTANTS_H__
#define __UDANAX_CONSTANTS_H__

#define BIT
#define GRANTEXTLENGTH  950
#define XUBUFSIZ        1024
#define ERROR 	        -1
#define stdprint        2
#define INTLEN          7
#define NAMELEN         103 /* size of filename */
#define metachar        int

#define ESC             '\033' /* Standard ASCII 'escape' character */
#define OK              0      /* General purpose "no error" return value */
#define MAXLINE         400    /* Longest line of input expected from the console */
#define RECURSIVE

//#define typeitemid char
enum typeitemid {
    TEXTID=0,
    ISPANID=1,
    VSPANID=2,
    VSPECID=3,
    NODEID=4,
    ADDRESSID=5,
    SPORGLID=6,
    LINKID=ADDRESSID,
    UNKNOWNID=99, // Is never legally used, for asserts only
};

enum GranItemType {
    GRANNULL=0,
    GRANTEXT=1,
    GRANORGL=2,
    GRANCLEARLYILLEGALINFO=42,
};

/*
 * Tag constants for things allocated in memory.
 */

enum MemTags {
    SESSTAG=                     1,
    INTTAG=                      2,
    ITEMTAG=                     4,
    CONTEXTTAG=                  6,
    CONTEXT2DTAG=                8,
    CRUMCONTEXTTAG=             10,
    CUCTAG=                     12,
    CBCTAG=                     14,
    SPANTAG=                    16,
    TUMBLERTAG=                 18,
    ISPANTAG=                   20,
    VSPANTAG=                   22,
    SPORGLTAG=                  24,
    LINKTAG=                    26,
    VSPECTAG=                   28,
    FREEDISKLOAFTAG=            30,
    BERTTAG=                    32,
    BERTCONSCELLTAG=            34,
    FREEDISKENTRYTAG=           36,
    FREEDISKENTRYCONSCELLTAG=   38,
    HUMBERTAG=                  40,
    LOAFTAG=                    42,
    POINTERTAG=                100,
};


/*
 * bert
 */

enum BertType {
    NOBERTREQUIRED=0,
    READBERT=1,
    WRITEBERT=2,
};

enum BertMode {
    BERTMODEONLY=1,
    BERTMODECOPYIF=2,
    BERTMODECOPY=3,
};

/*
 * wisp
 */

/*
**        Note that dsp's of gr are not stored on crums
**          themselves, but are discovered thru tree walking
**
**                    wid             dsp
**         -----------------------------------------
**        |
**   gr:  |           WIDTH           WIDTH
**        |
**   sp:  |         ORGLRANGE         ORGLRANGE
**        |           SPANRANGE         SPANRANGE
**        |
**   pm:  |             I                     I
**        |               V                     V
**        |
*/

/* wid and dsp index for gr */
#define WIDTH  0

/* wid and dsp indexes for sp */
#define ORGLRANGE 0
#define SPANRANGE 1

/* wid and dsp indexes for pm */
#define I  0
#define V  1

#define DSPSIZEGR 1
#define WIDSIZEGR 1
#define DSPSIZESP 2
#define WIDSIZESP 2
#define DSPSIZEPM 2
#define WIDSIZEPM 2

/*
 * loaf
 */

#define GRAN            1
#define POOM            2
#define SPAN            3

#define MAXUCINLOAF     4
#define MAXBCINLOAF     1  /* so text will fit */  /* as you wish */
#define MAX2DBCINLOAF   4  /* for a start */


/*
 * reaping constants
 */

 /* age values */
#ifndef RESERVED
#define RESERVED 0xff /* keeps a crum from being reaped */
#define NEW 0
#define OLD 1         /* set this as you wish, age  up to it from NEW */
#endif


/*
 * Memory Allocation
 */

#define ALLOCSIZE /* 0x30000*/  20000000 /* 3000000*/ /* 0x20000*/ /*0x62080*/ /* 0x44080 */ /* or0x24080*/ /* 0x10000 almost works 12/24/86 */
#define INCREMENTALALLOCSIZE 2500000

#endif /* !__UDANAX_CONSTANTS_H__*/
