/**********************************************************************
 * Copyright 2002 Jeff Rush <jrush@taupro.com>
 * Original Copyright 1979-2002 Udanax.com
 *
 * This file is part of the Udanax xanalogical storage system.
 *
 * Udanax is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * Udanax is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with Udanax; if not, write to the Free Software Foundation,
 * Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 **********************************************************************/

/**
 * @file  tumbler.h
 * @brief ???
 *
 * (to be defined)
 *
 **/

/* Modification History:
 * $Log: tumbler.h,v $
 * Revision 1.7  2002/05/28 03:51:13  jrush
 * Updated sources to comply with a GPL licensing.
 *
 * Revision 1.6  2002/04/16 22:38:21  jrush
 * Added but then commented out new methods for tumblers acting as a C type.
 * Need to remove unions throughout system first, due to compiler errors.
 *
 * Revision 1.5  2002/04/09 21:45:46  jrush
 * Renamed class 'tumbler' to 'Tumbler', for consistency with Python sources,
 * and changed typeisa from typedef to a subclass, in preparation for cleaning
 * up the type/class tree.
 *
 * Revision 1.4  2002/04/06 17:05:57  jrush
 * Switched from referring to 'task' for a client connection to 'session',
 * and converted the typetask typedef/struct into a Session C++ class.
 *
 * Revision 1.3  2002/04/06 15:22:53  jrush
 * Broke out tumbler struct/typedef as a C++ class.
 *
 * Revision 1.5  2002/04/06 15:00:34  jrush
 * Changed INT to just 'int'.
 *
 * Revision 1.4  2002/02/14 05:40:42  jrush
 * Cleaned up source:
 *
 * 1. ran thru the indent tool to achieve a standard look,
 * 2. added structured comments at top for use with DOxygen reporting
 *    as well as CVS keywords,
 * 3. added #ifndef/#defines to prevent duplicate inclusions,
 * 4. insured all struct/union defs have names,
 * 5. centralized prototypes in protos.h, removing incomplete ones,
 * 6. cleaned up use of bool/BOOLEAN type to suit C++ type,
 * 7. fixed initializer nesting in tumbler constants.
 *
 */

#ifndef __UDANAX_TUMBLER_H__
#define __UDANAX_TUMBLER_H__

/*
 * humber
 */

typedef unsigned char *humber;
#define SIZEOFZEROHUMBER 3

/*
 * tumbler
 */

#define NPLACES 11                     /* places in mantissa of tumbler */

#define TUMBLERMINUS 129
typedef unsigned int tdigit;

class Tumbler {
public:
    humber  xvartumbler;
    char    varandnotfixed;
    char    sign;      /* 1 if negative, otherwise 0 */
    short   exp;
    tdigit  mantissa[NPLACES];

//    Tumbler() {}             // Default Constructor
//    Tumbler(const Tumbler&); // Copy Constructor
//    Tumbler& operator=(const Tumbler&);
//    Tumbler& operator=(int);
};

#define ZEROTUMBLER  {0,0,0,0,  0,0,0,0,0,0,0,0,0,0,0}  /* 0.0.0.0.0.0 */

extern Tumbler ZEROTUMBLERvar;  /* EXTERNAL BEWARE */

#define tumblerclear(tumblerptr) ((*(tumblerptr)) = ZEROTUMBLERvar)
#define iszerotumbler(tumblerptr) (!((tumblerptr) -> mantissa[0]))
#define movetumbler(A,B) (*((Tumbler *)(B)) = *((Tumbler *)(A)))
/* #define movetumbler(A,B) tumblercopy((A),(B)) */

    /* relationship between tumblers:
     *
     * "<" and ">" type comparisons are allowed, so don't change
     */

#define GREATER  1
#define EQUAL    0
#define LESS    -1

    /* relationship between tumbler interval and address:
     *
     * "<" and ">" type comparisons are allowed, so don't change
     */

#define TOMYLEFT        -2
#define ONMYLEFTBORDER  -1
#define THRUME           0
#define ONMYRIGHTBORDER  1
#define TOMYRIGHT        2

#define macrotumblermax(a,b,c) ((*(Tumbler*)(c))=(tumblercmp((a),(b))==GREATER)?( (*(Tumbler *)(a))) :((*(Tumbler *)(b))) )
#define macrotumblermin(a,b,c) ((*(Tumbler*)(c))=(tumblercmp((a),(b))==LESS)?( (*(Tumbler *)(a))) :((*(Tumbler *)(b))) )

/* not needed #define macrotumblermax(a,b,c) tumblermax(a,b,c) #define macrotumblermin(a,b,c) tumblermin(a,b,c) */

#define lengthoftumbler(x) intof((x))

/* tumble.cxx */

extern bool tumblereq(Tumbler *a, Tumbler *b);
extern bool tumbleraccounteq(Tumbler *aptr, Tumbler *bptr);
extern int tumblercmp(Tumbler *aptr, Tumbler *bptr);
extern int intervalcmp(Tumbler *left, Tumbler *right, Tumbler *address);
extern bool is1story(Tumbler *tumblerptr);
extern bool tumblercheckptr(Tumbler *ptr, int /* typecrum */  *crumptr);

#define intof(x) ((unsigned int)((unsigned)((humber)(x))[0]<=127)?((humber)(x))[0]:functionintof(x))

#define lengthof(x) ((unsigned int)((unsigned)((humber)(x))[0]<=127)?(unsigned int)1:functionlengthof(x))
/* #define tumbleradd(x,y,z) if(iszerotumbler(y)){movetumbler(x,z);}else{functiontumbleradd(x,y,z);} */
#define tumbleradd(x,y,z) functiontumbleradd(x,y,z)

#endif /* !__UDANAX_TUMBLER_H__*/
