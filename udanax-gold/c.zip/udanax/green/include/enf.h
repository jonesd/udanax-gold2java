/**********************************************************************
 * Copyright 2002 Jeff Rush <jrush@taupro.com>
 * Original Copyright 1979-2002 Udanax.com
 *
 * This file is part of the Udanax xanalogical storage system.
 *
 * Udanax is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * Udanax is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with Udanax; if not, write to the Free Software Foundation,
 * Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 **********************************************************************/

/**
 * @file  enf.h
 * @brief ???
 *
 * (to be defined)
 *
 **/

/* Modification History:
 * $Log: enf.h,v $
 * Revision 1.11  2002/05/28 03:51:13  jrush
 * Updated sources to comply with a GPL licensing.
 *
 * Revision 1.10  2002/05/28 02:45:08  jrush
 * Convert #define constants into enumerations and macro into inline function.
 *
 * Revision 1.9  2002/04/13 14:08:35  jrush
 * Changed typedef of structs into just structs, for C++ style.
 *
 * Revision 1.8  2002/04/12 11:46:25  jrush
 * Major rearrangement of include contents, to reflect a hopefully more
 * logical layout as we refactor Udanax into classes.
 *
 * Revision 1.7  2002/04/06 15:00:34  jrush
 * Changed INT to just 'int'.
 *
 * Revision 1.6  2002/04/02 19:01:30  jrush
 * Reduced bushiness of enfilades for better graph output.
 *
 * Revision 1.5  2002/02/14 05:40:42  jrush
 * Cleaned up source:
 *
 * 1. ran thru the indent tool to achieve a standard look,
 * 2. added structured comments at top for use with DOxygen reporting
 *    as well as CVS keywords,
 * 3. added #ifndef/#defines to prevent duplicate inclusions,
 * 4. insured all struct/union defs have names,
 * 5. centralized prototypes in protos.h, removing incomplete ones,
 * 6. cleaned up use of bool/BOOLEAN type to suit C++ type,
 * 7. fixed initializer nesting in tumbler constants.
 *
 */

#ifndef __UDANAX_ENF_H__
#define __UDANAX_ENF_H__

/* typecorecrumhedr */
struct typecorecrumhedr {
    bool                        isapex BIT;    /* TRUE if this is the fullcrum */
    unsigned char               height;        /* 0 => this is bottom crum */
    unsigned char               cenftype;      /* GRAN, SPAN, or POOM */
    bool                        modified BIT;
    bool                        isleftmost BIT;        /* whether I'm leftmost sibling */
    typecorecrumhedr           *nextcrum;
    typecorecrumhedr           *prevcrum; /* doubly linked circular list of all corecrums for grim reaping */
    unsigned char               age;       /* for deciding to grimly reap */
    typecorecrumhedr           *leftbroorfather;  /* if it is NULL then this is fullcrum father if leftmost, else leftbro */
    typecorecrumhedr           *rightbro; /* if none, this == NULL */
    typewid                     cwid;
    typedsp                     cdsp;
};
typedef typecorecrumhedr        typecorecrum;

struct typecuc { // core upper crum
    /* typecorecrumhedr         xcorecrumhedr; */
    bool                        isapex BIT;    /* TRUE if this is the fullcrum */
    unsigned char               height;        /* 0 => this is bottom crum */
    unsigned char               cenftype;      /* GRAN, SPAN, or POOM */
    bool                        modified BIT;
    bool                        isleftmost BIT;        /* whether I'm leftmost sibling */
    typecorecrum               *nextcrum;
    typecorecrum               *prevcrum; /* doubly linked circular list of all corecrums for grim reaping */
    unsigned char               age;       /* for deciding to grimly reap */
    typecorecrum               *leftbroorfather; /* if it is NULL then this is fullcrum father if leftmost, else leftbro */
    typecorecrum               *rightbro; /* if none, this == NULL */
    typewid                     cwid;
    typedsp                     cdsp;
                                /* bottom of hedr */
    typediskloafptr             sonorigin; /* if son didn't come from disk, this should be DISKPTRNULL */
    typecorecrum               *leftson; /* if no sons in core this == NULL */
    int                         numberofsons;
};

class typecbc { // core bottom crum
public:
    /* typecorecrumhedr         xcorecrumhedr; */
    bool                        isapex BIT;    /* TRUE if this is the fullcrum */
    unsigned char               height;        /* 0 => this is bottom crum */
    unsigned char               cenftype;      /* GRAN, SPAN, or POOM */
    bool                        modified BIT;
    bool                        isleftmost BIT;        /* whether I'm leftmost sibling */
    typecorecrum               *nextcrum;
    typecorecrum               *prevcrum; /* doubly linked circular list of all corecrums for grim reaping */
    unsigned char               age;       /* for deciding to grimly reap */
    typecorecrum               *leftbroorfather; /* if it is NULL then this is fullcrum father if leftmost, else leftbro */
    typecorecrum               *rightbro; /* if none, this == NULL */
    typewid                     cwid;
    typedsp                     cdsp; /* bottom of hedr */
    typegranbottomcruminfo      cinfo;
};

struct type2dcbc { // 2d core bottom crum
    /* typecorecrumhedr         xcorecrumhedr; */
    bool                        isapex BIT;    /* TRUE if this is the fullcrum */
    unsigned char               height;        /* 0 => this is bottom crum */
    unsigned char               cenftype;      /* GRAN, SPAN, or POOM */
    bool                        modified BIT;
    bool                        isleftmost BIT;        /* whether I'm leftmost sibling */
    typecorecrum               *nextcrum;
    typecorecrum               *prevcrum; /* doubly linked circular list of all corecrums for grim reaping */
    unsigned char               age;       /* for deciding to grimly reap */
    typecorecrum               *leftbroorfather; /* if it is NULL then this is fullcrum father if leftmost, else leftbro */
    typecorecrum               *rightbro; /* if none, this == NULL */
    typewid                     cwid;
    typedsp                     cdsp;
                                /* bottom of hedr */
    type2dbottomcruminfo        c2dinfo;
};

/* relatives used as parameters to adopt */

enum AdoptPlacement {
    LEFTMOSTSON=0,
    RIGHTMOSTSON=1,
    SON=LEFTMOSTSON,
    LEFTBRO=2,
    RIGHTBRO=3,
};

//#define isfullcrum(x) ((bool)((typecorecrum *)(x))->isapex)
inline bool
isfullcrum(typecorecrum *x)
{
    return (bool) x->isapex;
}

#endif /* !__UDANAX_ENF_H__*/
