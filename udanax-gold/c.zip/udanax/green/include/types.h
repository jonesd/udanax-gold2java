/**********************************************************************
 * Copyright 2002 Jeff Rush <jrush@taupro.com>
 * Original Copyright 1979-2002 Udanax.com
 *
 * This file is part of the Udanax xanalogical storage system.
 *
 * Udanax is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * Udanax is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with Udanax; if not, write to the Free Software Foundation,
 * Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 **********************************************************************/

/**
 * @file  types.h
 * @brief ???
 *
 * (to be defined)
 *
 **/

/* Modification History:
 * $Log: types.h,v $
 * Revision 1.4  2002/05/28 03:51:13  jrush
 * Updated sources to comply with a GPL licensing.
 *
 * Revision 1.3  2002/04/13 14:08:35  jrush
 * Changed typedef of structs into just structs, for C++ style.
 *
 * Revision 1.2  2002/04/12 11:46:25  jrush
 * Major rearrangement of include contents, to reflect a hopefully more
 * logical layout as we refactor Udanax into classes.
 *
 * Revision 1.1  2002/04/12 09:34:25  jrush
 * Renamed xanatypes.h to types.h
 *
 * Revision 1.1  2002/04/10 18:01:05  jrush
 * Provide a place to collect cleaned up type/class tree declarations.
 *
 * Revision 1.7  2002/04/06 17:05:57  jrush
 * Switched from referring to 'task' for a client connection to 'session',
 * and converted the typetask typedef/struct into a Session C++ class.
 *
 * Revision 1.6  2002/04/06 15:00:34  jrush
 * Changed INT to just 'int'.
 *
 * Revision 1.5  2002/02/14 05:40:42  jrush
 * Cleaned up source:
 *
 * 1. ran thru the indent tool to achieve a standard look,
 * 2. added structured comments at top for use with DOxygen reporting
 *    as well as CVS keywords,
 * 3. added #ifndef/#defines to prevent duplicate inclusions,
 * 4. insured all struct/union defs have names,
 * 5. centralized prototypes in protos.h, removing incomplete ones,
 * 6. cleaned up use of bool/BOOLEAN type to suit C++ type,
 * 7. fixed initializer nesting in tumbler constants.
 *
 */

#ifndef __UDANAX_TYPES_H__
#define __UDANAX_TYPES_H__

#include "queue.h"

typedef unsigned tagtype;       /* for tagging allocated things -- see credel.d */

typedef int ALIGN;
union header {
    struct {
        union header *ptr;
        unsigned size;
    } s;
    ALIGN x;
};

typedef union header HEADER;

/*
 * On-Disk Navigation Types
 */

typedef int typediskloafptrdigit;       /* long disk block number */
#define DISKPTRNULL -1                 /* invalid disk pointer */

struct typediskloafptr {
    typediskloafptrdigit  diskblocknumber;
    int                   insidediskblocknumber;
};

/*
 * Coordinate Types
 */

#include "tumbler.h"

class IStreamAddr: public Tumbler
{
};

/*
 * span
 */

struct typespan {
    typespan    *next;
    typeitemid   itemid;
    Tumbler      stream;
    Tumbler      width;
};
typedef typespan *typespanset;

/*
 * knives
 */

#define MAXCUTS  4
struct typecutseq {
    int      numberofcuts;
    Tumbler  cutsarray[MAXCUTS];
};

struct typeknives { /* this is nd internal version of cutseq */
    int      nblades;
    Tumbler  blades[MAXCUTS];
    int      dimension;      /* always V, assigned by rearrange2d */
};


/*
 * wisp
 */

#define MAXLOXIZE 2

struct typewid {
    Tumbler dsas[MAXLOXIZE];
};
typedef typewid typedsp;
typedef typewid typewisp;

#include "session.h"
#include "crum.h"
#include "context.h"
#include "enf.h"
#include "coredisk.h"

#endif /* !__UDANAX_TYPES_H__*/
