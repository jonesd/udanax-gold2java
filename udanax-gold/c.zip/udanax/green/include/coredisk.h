/**********************************************************************
 * Copyright 2002 Jeff Rush <jrush@taupro.com>
 * Original Copyright 1979-2002 Udanax.com
 *
 * This file is part of the Udanax xanalogical storage system.
 *
 * Udanax is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * Udanax is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with Udanax; if not, write to the Free Software Foundation,
 * Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 **********************************************************************/

/**
 * @file  coredisk.h
 * @brief ???
 *
 * (to be defined)
 *
 **/

/* Modification History:
 * $Log: coredisk.h,v $
 * Revision 1.12  2002/05/28 03:51:13  jrush
 * Updated sources to comply with a GPL licensing.
 *
 * Revision 1.11  2002/05/28 02:44:44  jrush
 * Move macro functions into more appropriate protos.h
 *
 * Revision 1.10  2002/04/13 13:44:35  jrush
 * Convert typedefs of structs to just structs, for C++ style.
 *
 * Revision 1.9  2002/04/12 11:46:25  jrush
 * Major rearrangement of include contents, to reflect a hopefully more
 * logical layout as we refactor Udanax into classes.
 *
 * Revision 1.8  2002/04/06 15:00:34  jrush
 * Changed INT to just 'int'.
 *
 * Revision 1.7  2002/02/14 05:40:42  jrush
 * Cleaned up source:
 *
 * 1. ran thru the indent tool to achieve a standard look,
 * 2. added structured comments at top for use with DOxygen reporting
 *    as well as CVS keywords,
 * 3. added #ifndef/#defines to prevent duplicate inclusions,
 * 4. insured all struct/union defs have names,
 * 5. centralized prototypes in protos.h, removing incomplete ones,
 * 6. cleaned up use of bool/BOOLEAN type to suit C++ type,
 * 7. fixed initializer nesting in tumbler constants.
 *
 */

#ifndef __UDANAX_COREDISK_H__
#define __UDANAX_COREDISK_H__

struct typediskloafhedr {
    int                       sizeofthisloaf;
    unsigned char /* bool */  isapex;        /* TRUE if this is top of orgl */
    unsigned char             height;        /* if == 0, then dbcloaf */
    unsigned char             denftype;      /* GRAN, SPAN, POOM */
    unsigned char             numberofcrums;
    unsigned char             refcount;      /* for subtree sharing, disk garbage collecting */
    unsigned char             allignmentdummy;
};

struct typeduc { // disk upper crum
    typewid                   dwid;
    typedsp                   ddsp;
    typediskloafptr           sonloafptr;
};

struct typedbc { // disk bottom crum = loaf
    typediskloafhedr          xdbchedr;
    typewid                   dbcwid;
    typedsp                   dbcdsp;
    typebottomcruminfo        dinfo;
};

//#define typedbcloaf           struct structdbc
#define typedbcloaf           typedbc

struct type2ddbc { // disk bottom crum = loaf
    typediskloafhedr          xdbchedr;
    typewid                   dbcwid;
    typedsp                   dbcdsp;
    type2dbottomcruminfo      d2dinfo;
};

struct type2ddbcloaf { // disk upper loaf
    typediskloafhedr          x2ddbcloafhedr;
    type2ddbc                 d2dbcarray[MAX2DBCINLOAF];
};

struct typeducloaf { // disk upper loaf
    typediskloafhedr          xducloafhedr;
    typeduc                   ducarray[MAXUCINLOAF];
};

union typediskloaf {
    typeducloaf               xducloaf;
    typedbcloaf               xdbcloaf;
    type2ddbcloaf             x2ddbcloaf;
};

struct typeuberdiskloaf {
    int                       versiondisknumber;
    unsigned short            numberofunterloafs;
    unsigned char             anoherallignmentdummy;
    typediskloaf              fakepartialuberloaf;
};

struct typeuberdiskloaffake {
    int                       versiondisknumber;
    unsigned short            numberofunterloafs;
    unsigned char             yetanotherallignmentdummy;
    int                       fakepartialuberloaf;
};

union typediskcrum {
    typeduc                   xduc;
    typedbc                   xdbc;
    type2ddbc                 x2ddbc;
    typeducloaf               xducloaf;
    typedbcloaf               xdbcloaf;
    type2ddbcloaf             x2ddbcloaf;
};

struct typefreediskloaf { // inverse crum for disk freeing
    typefreediskloaf         *nextloaftofree;
    typefreediskloaf         *sonloaftofree;
    typediskloafptr           freeloafptr;
};

#define NUMDISKBLOCKSINLOAF   1          /* ((sizeof(typeuberdiskloaf) +XUBUFSIZ -1)/XUBUFSIZ) */
#define NUMBYTESINLOAF        ((NUMDISKBLOCKSINLOAF)*XUBUFSIZ)

union typeuberrawdiskloaf {
    typeuberdiskloaffake      xuberdiskloaf;
    char                      rawdiskloaf[NUMBYTESINLOAF];
};

#define MAXTHINGIESINLOAF     9          /* ((1024-sizeof(struct structdiskloafhedr))/sizeof(struct structduc)) // change these numbers // */
#define NUMLOAFSOFBITMAP      50
#define BITMAPSIZE            (NUMBYTESINLOAF*NUMLOAFSOFBITMAP-(sizeof(unsigned)+sizeof(bool)))

struct Diskheader { // header for file
    unsigned                  filesize;            /* number of last allocated block */
    char                      bitmap[BITMAPSIZE];  /* bit set for each free block */
    bool                      hasenftops;          /* GRAN & SPAN tops are in file */
};

#define NUMDISKLOAFSINHEADER  (sizeof(Diskheader)/NUMBYTESINLOAF+1)
#define GRANFDISKLOCATION     (NUMDISKLOAFSINHEADER+1)
#define SPANFDISKLOCATION     (NUMDISKLOAFSINHEADER+2)
#define PARTIALFREEDISKLOCATION (NUMDISKLOAFSINHEADER+3)

struct freediskentry {
    int                       partialdiskblocknumber;
    unsigned short            freespaceinloaf;
    unsigned char             moreallignmentdummy;
};

#define NFREEENTRYS           ((NUMBYTESINLOAF - sizeof(freediskentry))/(sizeof(freediskentry)))

struct freediskarray {
    int                       nextdiskblocknumber;
    int                       numberofentrysinthisblock;
    freediskentry             freeentryarray[NFREEENTRYS];
};

#define SIZEOFUBERDISKHEADER  6

#endif /* !__UDANAX_COREDISK_H__*/
