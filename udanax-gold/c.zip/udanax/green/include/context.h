/**********************************************************************
 * Copyright 2002 Jeff Rush <jrush@taupro.com>
 * Original Copyright 1979-2002 Udanax.com
 *
 * This file is part of the Udanax xanalogical storage system.
 *
 * Udanax is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * Udanax is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with Udanax; if not, write to the Free Software Foundation,
 * Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 **********************************************************************/

/**
 * @file  context.h
 * @brief ???
 *
 * (to be defined)
 *
 **/

/* Modification History:
 * $Log: context.h,v $
 * Revision 1.3  2002/05/28 03:51:13  jrush
 * Updated sources to comply with a GPL licensing.
 *
 * Revision 1.2  2002/04/13 13:44:35  jrush
 * Convert typedefs of structs to just structs, for C++ style.
 *
 * Revision 1.1  2002/04/12 11:44:12  jrush
 * Created new file to hold Context set of classes.
 *
 * Revision 1.7  2002/04/06 15:00:34  jrush
 * Changed INT to just 'int'.
 *
 * Revision 1.6  2002/04/02 19:01:30  jrush
 * Reduced bushiness of enfilades for better graph output.
 *
 * Revision 1.5  2002/02/14 05:40:42  jrush
 * Cleaned up source:
 *
 * 1. ran thru the indent tool to achieve a standard look,
 * 2. added structured comments at top for use with DOxygen reporting
 *    as well as CVS keywords,
 * 3. added #ifndef/#defines to prevent duplicate inclusions,
 * 4. insured all struct/union defs have names,
 * 5. centralized prototypes in protos.h, removing incomplete ones,
 * 6. cleaned up use of bool/BOOLEAN type to suit C++ type,
 * 7. fixed initializer nesting in tumbler constants.
 *
 */

#ifndef __UDANAX_CONTEXT_H__
#define __UDANAX_CONTEXT_H__

class typecbc; // Forward Reference

class ContextBase {
public:
    ContextBase         *nextcontext;
    int                  contexttype;
    typedsp              totaloffset;
    typewid              contextwid;
};

class Context: public ContextBase {
public:
    typebottomcruminfo   contextinfo;
    Context             *lastcontext;
};

struct type2dcontext {
    type2dcontext          *nextcontext;
    int                     contexttype;
    typedsp                 totaloffset;
    typewid                 contextwid;

    type2dbottomcruminfo    context2dinfo;
};

class CrumContext {
public:
    CrumContext  *nextcrumcontext;
    typecbc      *corecrum;
    typedsp       totaloffset;
};

#endif /* !__UDANAX_CONTEXT_H__*/
