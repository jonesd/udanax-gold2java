/**********************************************************************
 * Copyright 2002 Jeff Rush <jrush@taupro.com>
 * Original Copyright 1979-2002 Udanax.com
 *
 * This file is part of the Udanax xanalogical storage system.
 *
 * Udanax is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * Udanax is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with Udanax; if not, write to the Free Software Foundation,
 * Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 **********************************************************************/

/**
 * @file  queues.h
 * @brief General purpose queue
 *
 * (to be defined)
 *
 **/

/* Modification History:
 * $Log: queue.h,v $
 * Revision 1.4  2002/05/28 03:51:13  jrush
 * Updated sources to comply with a GPL licensing.
 *
 * Revision 1.3  2002/05/28 02:46:36  jrush
 * Converted a macro function into an inline function.
 *
 * Revision 1.2  2002/04/12 11:46:25  jrush
 * Major rearrangement of include contents, to reflect a hopefully more
 * logical layout as we refactor Udanax into classes.
 *
 * Revision 1.1  2002/04/12 09:47:24  jrush
 * Renamed queues.h to queue.h
 *
 * Revision 1.5  2002/04/06 15:00:34  jrush
 * Changed INT to just 'int'.
 *
 * Revision 1.4  2002/02/14 05:40:42  jrush
 * Cleaned up source:
 *
 * 1. ran thru the indent tool to achieve a standard look,
 * 2. added structured comments at top for use with DOxygen reporting
 *    as well as CVS keywords,
 * 3. added #ifndef/#defines to prevent duplicate inclusions,
 * 4. insured all struct/union defs have names,
 * 5. centralized prototypes in protos.h, removing incomplete ones,
 * 6. cleaned up use of bool/BOOLEAN type to suit C++ type,
 * 7. fixed initializer nesting in tumbler constants.
 *
 */

#ifndef __UDANAX_QUEUES_H__
#define __UDANAX_QUEUES_H__

#undef NULL
#if defined(__cplusplus)
#define NULL 0
#else
#define NULL ((void *)0)
#endif

class queue {
public:
    queue *qnext;  // Next item in queue
    queue *qprev;  // Previous item in queue

    queue *next(queue *qhead);
};

//#define qempty(x) (qnext((struct queue *)(x),(struct queue *)(x))==NULL)

inline bool
qempty(queue *x)
{
    return x->next(x) == NULL;
}

#endif /* !__UDANAX_QUEUES_H__*/
