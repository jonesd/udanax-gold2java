/**********************************************************************
 * Copyright 2002 Jeff Rush <jrush@taupro.com>
 * Original Copyright 1979-2002 Udanax.com
 *
 * This file is part of the Udanax xanalogical storage system.
 *
 * Udanax is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * Udanax is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with Udanax; if not, write to the Free Software Foundation,
 * Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 **********************************************************************/

/**
 * @file  protos.h
 * @brief ???
 *
 * (to be defined)
 *
 **/

/* Modification History:
 * $Log: protos.h,v $
 * Revision 1.18  2002/07/14 08:28:05  jrush
 * Removed definition of qerror proto and gerror macro.
 *
 * Revision 1.17  2002/05/28 03:51:13  jrush
 * Updated sources to comply with a GPL licensing.
 *
 * Revision 1.16  2002/05/28 02:45:48  jrush
 * Commented out functions made static, used within a single source file.
 * Added some macro functions moved from coredisk.h and crum.h
 *
 * Revision 1.15  2002/04/16 22:46:14  jrush
 * Rollback bad attempt to eliminate typebottomcrum union; try again later.
 *
 * Revision 1.14  2002/04/16 22:39:50  jrush
 * Converted many #defines into enumeration types instead, and adjusted
 * function prototypes accordingly.
 *
 * Revision 1.13  2002/04/13 14:07:46  jrush
 * Removed no longer necessary duplicate typedefs at top of file.
 *
 * Revision 1.12  2002/04/12 22:53:20  jrush
 * Changed from using my setmem() to the clib's memset() and removed no
 * longer-needed usefull.cxx
 *
 * Revision 1.11  2002/04/12 11:46:25  jrush
 * Major rearrangement of include contents, to reflect a hopefully more
 * logical layout as we refactor Udanax into classes.
 *
 * Revision 1.10  2002/04/10 18:01:54  jrush
 * Renamed class typeisa to IStreamAddr.
 *
 * Revision 1.9  2002/04/09 21:45:46  jrush
 * Renamed class 'tumbler' to 'Tumbler', for consistency with Python sources,
 * and changed typeisa from typedef to a subclass, in preparation for cleaning
 * up the type/class tree.
 *
 * Revision 1.8  2002/04/08 18:55:56  jrush
 * Switched from using global variable 'user' to object 'Session' as a
 * connection for tracking open document descriptors in the bert table.
 *
 * Revision 1.7  2002/04/07 14:04:37  jrush
 * Add ptr to Session to checkforopen() and isthisusersdocument() so that we
 * have session information available to make the decision.
 *
 * Revision 1.6  2002/04/06 17:05:57  jrush
 * Switched from referring to 'task' for a client connection to 'session',
 * and converted the typetask typedef/struct into a Session C++ class.
 *
 * Revision 1.5  2002/04/06 15:22:53  jrush
 * Broke out tumbler struct/typedef as a C++ class.
 *
 * Revision 1.4  2002/04/06 15:00:34  jrush
 * Changed INT to just 'int'.
 *
 * Revision 1.3  2002/04/06 13:31:04  jrush
 * Removed entries for some functions that turned out to be static/private.
 *
 * Revision 1.2  2002/04/02 19:01:45  jrush
 * Removed private hashoftumbler().
 *
 * Revision 1.1  2002/02/14 05:14:17  jrush
 * Temporarily added a new file just to hold function prototypes, so the build
 * will pass lint and other warnings.  Eventually the prototypes will be relocated
 * to better places, probably C++ methods and such.
 *
 */

#ifndef __UDANAX_PROTOS_H__
#define __UDANAX_PROTOS_H__

#include <memory.h>
#include "types.h"

/* alloc.cxx */

void  lookatalloc();
//STATIC int   statusofalloc(char *c);
//STATIC int   validallocthinge(char *ptr);
int   checkalloc(char *c);
//STATIC void  checkallocedptr(char *ptr, char *string);
int  *falloc(unsigned nbytes);
void  ffree(char *ap);

/* allocdebug.cxx */

void  lookatalloc2(HEADER * abaseallocated);

/* bert.cxx */

class Session; // Forward Declaration
struct typecuc; // Forward Declaration

int   checkforopen(Session *sess, Tumbler *tp, int type);
void  logbertmodifiedforcrum(Session *sess, typecuc *crumptr);
void  logbertmodified(Session *sess, Tumbler *tp);
//STATIC void  incrementopen(Session *sess, Tumbler *tp);
//STATIC void  addtoopen(Session *sess, Tumbler *tp, int created, int type);
//STATIC void  deleteversion(Tumbler *tp);
//STATIC bool  removefromopen(Session *sess, Tumbler *tp);
//STATIC void  exitbert(Session *sess);
bool  doopen(Session *sess, IStreamAddr *tp, IStreamAddr *newtp, int type, int mode);
bool  doclose(Session *sess, IStreamAddr *tp);
void  dobertexit(Session *sess);

/* context.cxx */

class Context; // Forward Declaration
class CrumContext; // Forward Declaration

//STATIC Context *createcontext(unsigned char type);
void  contextfree(Context *context);
CrumContext *createcrumcontext(typecorecrum *crumptr, typedsp *offsetptr);
void  crumcontextfree(CrumContext *context);
void  incontextlistnd(Context **clistptr, Context *c, int index);
void  oncontextlistseq(Context **clistptr, Context *c);
//STATIC int   whereoncontext(Context *ptr, Tumbler *address, int index);
Context *makecontextfromcbc(typecbc *crumptr, typewid *offsetptr);
void  context2span(Context *context, typespan *restrictionspanptr, int idx1, typespan *foundspanptr, int idx2);
//STATIC void  prologuecontextnd(Context *ptr, typedsp *grasp, typedsp *reach);
//STATIC typeitemid index2itemid(int index, Context *context);
bool  context2vstuff(Session *sess, Context *context, typeispan *ispanptr, typevstuffset *vstuffsetptr);
//STATIC void  context2vtext(Context *context, typeispan *ispanptr, typevstuffset vstuffset);

/* corediskin.cxx */

void  initkluge(typecuc ** granfptr, typecuc ** spanfptr);
//STATIC typediskloaf *lookinsideloaffor(int insidenumber, typediskloaf * uloafptr);
void  inloaf(typecuc * father);
void  inorgl(typecbc * granorglptr);
void  inorglinternal(typecbc * granorglptr, typeuberrawdiskloaf * crumptr);
//STATIC void  hgetinfo(typecbc * ptr, char **loafptrptr);

/* corediskout.cxx */

void  diskexit();
void  diskflush();
void  writeenfilades();
//STATIC void  hputinfo(typecbc * ptr, char **loafptrptr);
void  orglwrite(typecbc * orglcbcptr);
//STATIC void  deletefullcrumandgarbageddescendents(typediskloafptr diskptr, bool deletefullcrumflag, typediskloaf * loafp, typediskloafptr newdiskptr);
//STATIC void  deletewithgarbageddescendents(typediskloafptr diskptr, typecuc * father, bool deletefullcrumflag);
void  subtreewrite(typecuc * father);
//STATIC void  checkmodifiednotthere(typecuc * father, char *string);

/* correspond.cxx */

void  restrictspecsetsaccordingtoispans(Session *sess, typeispanset ispanset, typespecset * specset1, typespecset * specset2);
//STATIC void  restrictvspecsetovercommonispans(Session *sess, typeispanset ispanset, typespecset specset, typespecset * newspecsetptr);
//STATIC void  removespansnotinoriginal(Session *sess, typespecset original, typespecset * newptr);
bool  intersectspansets(Session *sess, typespanset set1, typespanset set2, typespanset *set3, typeitemid spantype);
//STATIC bool  comparespans(Session *sess, typespan *span1, typespan *span2, typespan **span3, typeitemid spantype);
//STATIC bool  spanintersection(typespan * aptr, typespan * bptr, typespan * cptr);
void  makespanpairset(Session *sess, typeispanset ispanset, typespecset specset1, typespecset specset2, typespanpairset * pairsetptr);
//STATIC void  makespanpairsforispan(Session *sess, Tumbler * iwidth, typespecset * specset1ptr, typespecset * specset2ptr, typespanpairset * pairsetptr);
//STATIC typespanpair *makespanpair(Session *sess, Tumbler * doc1, Tumbler * start1, Tumbler * doc2, Tumbler * start2, Tumbler * width);
//STATIC int   spansubtract(typespan * aptr, typespan * bptr, typespan * cptr);

/* credel.cxx */

int  *eallocwithtag(unsigned nbytes, tagtype tag);
//STATIC int  *ealloc(unsigned nbytes);
void  efree(char *ptr);
void  initgrimreaper();
//STATIC void  grimlyreap();
//STATIC bool  isreapable(int *fuckinap, typecorecrum * localreaper);
//STATIC void  reap(typecorecrum * localreaper);
int   testforrejuvinate(typecorecrum * ptr);
void  funcrejuvinate(typecorecrum * ptr);
void  reserve(typecorecrum * ptr);
void  testforreservedness(char *msg);
void  subtreefree(typecorecrum * ptr);
void  freecrum(typecorecrum * ptr);
void  loaffree(typecuc * father);
void  orglfree(typecuc * ptr);
typecuc *createenf(int enftype);
typecorecrum *createcrum(int crumheight, int enftype);
void  initcrum(int crumheight, int enftype, typecorecrum * ptr);
//STATIC typecorecrum *createcruminternal(int crumheight, int enftype, typecorecrum * allocated);
void  initqueues();
//STATIC void  dumptable();
//STATIC char *allocfromqueue(int n);
//STATIC void  freetoqueue(char *ptr);
//STATIC void  xgrabmorecore();

/* disk.cxx */

int   findnumberofdamnsons(typediskloafptr diskptr);
int   changerefcount(typediskloafptr diskptr, int delta);
//STATIC int   changeunterrefcount(typediskloaf * wholeloafp, char *originalloafp, int delta);
void  readloaf(typediskloaf * loafptr, typediskloafptr diskptr);
void  actuallyreadrawloaf(typeuberrawdiskloaf * loafptr, int blocknumber);
void  writeloaf(typediskloaf * loafptr, typediskloafptr diskptr, int newloaf);
void  actuallywriteloaf(typeuberrawdiskloaf * loafptr, int diskblocknumber);
bool  initenffile(char *filename);
void  closediskfile();
//STATIC void  dieandclosefiles();
//STATIC void  warning(char *message);

/* diskalloc.cxx */

//static int   isalloced(int n);
typediskloafptr diskalloc();
void  diskfree(typediskloafptrdigit loafptr);
void  diskset(typediskloafptrdigit loafptr);
bool  readallocinfo(int fd);
void  initheader();
void  diskallocexit(int fd);
void  writeallocinfo(int fd);
bool  goodblock(typediskloafptrdigit diskptr);

/* do1.cxx */

bool  dofinddocscontaining(Session *sess, typespecset specset, typelinkset * addresssetptr);
bool  doappend(Session *sess, IStreamAddr * docptr, typetextset textset);
bool  dorearrange(Session *sess, IStreamAddr * docisaptr, typecutseq * cutseqptr);
bool  docopy(Session *sess, IStreamAddr * docisaptr, Tumbler * vsaptr, typespecset specset);
bool  docopyinternal(Session *sess, IStreamAddr * docisaptr, Tumbler * vsaptr, typespecset specset);
bool  doinsert(Session *sess, IStreamAddr * docisaptr, Tumbler * vsaptr, typetextset textset);
void  checkspecandstringbefore();
bool  dodeletevspan(Session *sess, IStreamAddr * docisaptr, typevspan * vspanptr);
bool  domakelink(Session *sess, IStreamAddr * docisaptr, typespecset fromspecset, typespecset tospecset, IStreamAddr * linkisaptr);
bool  docreatelink(Session *sess, IStreamAddr * docisaptr, typespecset fromspecset, typespecset tospecset, typespecset threespecset, IStreamAddr * linkisaptr);
bool  dofollowlink(Session *sess, IStreamAddr * linkisaptr, typespecset * specsetptr, int whichend);
bool  docreatenewdocument(Session *sess, IStreamAddr * isaptr);
bool  docreatenode_or_account(Session *sess, IStreamAddr * isaptr);
bool  docreatenewversion(Session *sess, IStreamAddr *isaptr, IStreamAddr *wheretoputit, IStreamAddr *newisaptr);
bool  doretrievedocvspan(Session *sess, IStreamAddr * docisaptr, typevspan * vspanptr);
bool  doretrievedocvspanset(Session *sess, IStreamAddr * docisaptr, typevspanset * vspansetptr);
bool  doretrievev(Session *sess, typespecset specset, typevstuffset * vstuffsetptr);
bool  dofindlinksfromtothree(Session *sess, typespecset fromvspecset, typespecset tovspecset, typespecset threevspecset, typeispan * orglrangeptr, typelinkset * linksetptr);
bool  dofindnumoflinksfromtothree(Session *sess, typespecset * fromvspecset, typespecset * tovspecset, typespecset * threevspecset, typeispan * orglrangeptr, int * numptr);
bool  dofindnextnlinksfromtothree(Session *sess, typevspec * fromvspecptr, typevspec * tovspecptr, typevspec * threevspecptr, typeispan * orglrangeptr, IStreamAddr * lastlinkisaptr, typelinkset * nextlinksetptr, int * nptr);
bool  doretrieveendsets(Session *sess, typespecset specset, typespecset * fromsetptr, typespecset * tosetptr, typespecset * threesetptr);
bool  doshowrelationof2versions(Session *sess, typespecset version1, typespecset version2, typespanpairset * relation);

/* do2.cxx */

bool  specset2ispanset(Session *sess, typespec * specset, typeispanset * ispansetptr, int type);
bool  tumbler2spanset(Session *sess, IStreamAddr * tumblerptr, typespanset * spansetptr);
void  makehint(int typeabove, int typebelow, int typeofatom, IStreamAddr * isaptr, typehint * hintptr);
void  validhint(typehint * hintptr);
bool  acceptablevsa(Tumbler * vsaptr, typeorgl orglptr);
bool  insertendsetsinspanf(Session *sess, typespanf spanfptr, IStreamAddr * linkisaptr, typesporglset fromsporglset, typesporglset tosporglset, typesporglset threesporglset);
bool  insertendsetsinorgl(Session *sess, Tumbler * linkisaptr, typeorgl link, Tumbler * fromvsa, typesporglset fromsporglset, Tumbler * tovsa, typesporglset tosporglset, Tumbler * threevsa, typesporglset threesporglset);
bool  findnextlinkvsa(Session *sess, IStreamAddr * docisaptr, Tumbler * vsaptr);
bool  setlinkvsas(Tumbler * fromvsaptr, Tumbler * tovsaptr, Tumbler * threevsaptr);
bool  ispansetandspecsets2spanpairset(Session *sess, typeispanset ispanset, typespecset specset1, typespecset specset2, typespanpairset * pairsetptr);

/* edit.cxx */

//STATIC void  deleteseq(typecuc * fullcrumptr, Tumbler * address, int index);
void  deletend(typecuc * fullcrumptr, Tumbler * origin, Tumbler * width, int index);
void  rearrangend(typecuc * fullcrumptr, typecutseq * cutseqptr, int index);
//STATIC void  makeoffsetsfor3or4cuts(typeknives * knives, Tumbler diff[]);
//STATIC int   rearrangecutsectionnd(typecorecrum * ptr, typewid * offset, typeknives * knives);
int   insertcutsectionnd(typecorecrum * ptr, typewid * offset, typeknives * knives);
//STATIC int   deletecutsectionnd(typecorecrum * ptr, typewid * offset, typeknives * knives);
//STATIC void  sortknives(typeknives * knifeptr);

/* entexit.cxx */

void  initmagicktricks();

/* genf.cxx */

bool  is2dcrum(typecorecrum * ptr);
typecorecrum *getleftson(typecuc * ptr);
typecorecrum *routinegetrightbro(typecorecrum * ptr);
typecorecrum *getrightmostbro(typecorecrum * ptr);
//STATIC typecorecrum *getleftbro(typecorecrum * ptr);
//STATIC typecorecrum *getleftmostbro(typecorecrum * ptr);
typecuc *getfather(typecorecrum * ptr);
typecuc *findfullcrum(typecorecrum * descendant);
bool  isemptyenfilade(typecuc * ptr);
typecuc *functionweakfindfather(typecorecrum * ptr);
typecuc *findfather(typecorecrum * son);
typecorecrum *findleftbro(typecorecrum * ptr);
typecorecrum *findleftmostbro(typecorecrum * ptr);
typecorecrum *weakfindleftmostbro(typecorecrum * ptr);
typecorecrum *funcfindrightbro(typecorecrum * ptr);
typecorecrum *weakfindrightbro(typecorecrum * ptr);
typecorecrum *weakfindrightbro(typecorecrum * ptr);
typecorecrum *findrightmostbro(typecorecrum * leftbro);
typecorecrum *findleftson(typecuc * ptr);
typecorecrum *findrightmostson(typecuc * ptr);
bool  toomanysons(typecuc * ptr);
bool  toofewsons(typecuc * ptr);
bool  roomformoresons(typecuc * ptr);
void  levelpush(typecuc * fullcrumptr);
//STATIC void  transferloaf(typecuc * from, typecuc * to);
void  levelpull(typecuc * fullcrumptr);
void  disown(typecorecrum * crumptr);
void  disownnomodify(typecorecrum * crumptr);
void  adopt(typecorecrum * newcrum, int relative, typecorecrum * old);
void  ivemodified(typecorecrum * ptr);
//OBSOLETE int   qerror(char *message);
//STATIC int   nferror(char *message);

/* granf1.cxx */

bool  findorgl(Session * sess, typegranf granfptr, IStreamAddr * isaptr, typeorgl * orglptr, int type);
bool  inserttextingranf(Session * sess, typegranf granfptr, typehint * hintptr, typetextset textset, typeispanset * ispansetptr);
bool  createorglingranf(Session * sess, typegranf granfptr, typehint * hintptr, IStreamAddr * isaptr);
bool  ispanset2vstuffset(Session * sess, typegranf granfptr, typeispanset ispanset, typevstuffset * vstuffsetptr);

/* granf2.cxx */

typeorgl fetchorglgr(Session * sess, typegranf fullcrumptr, IStreamAddr * address);
bool  inserttextgr(Session * sess, typegranf fullcrumptr, typehint * hintptr, typetextset textset, typeispanset * ispansetptr);
bool  createorglgr(Session * sess, typegranf fullcrumptr, typehint * hintptr, IStreamAddr * isaptr);
//STATIC bool  findisatoinsertgr(typecuc * fullcrumptr, typehint * hintptr, IStreamAddr * isaptr);
//STATIC bool  isaexistsgr(typecuc * crumptr, IStreamAddr * isaptr);
//STATIC void  findpreviousisagr(typecorecrum * crumptr, IStreamAddr * upperbound, IStreamAddr * offset);
//STATIC void  findlastisaincbcgr(typecbc * ptr, IStreamAddr * offset);
typevstuffset *ispan2vstuffset(Session * sess, typegranf fullcrumptr, typeispan * ispanptr, typevstuffset * vstuffsetptr);

/* init.cxx */

void  init(bool safe);

/* insert.cxx */

void  insertseq(typecuc * fullcrumptr, Tumbler * address, typegranbottomcruminfo * info);
//STATIC bool  fillupcbcseq(typecbc * ptr, Tumbler * crumboundary, typegranbottomcruminfo * info);

/* insertnd.cxx */

void  insertnd(Session * sess, typecuc * fullcrumptr, typewid * origin, typewid * width, type2dbottomcruminfo * infoptr, int index);
//STATIC void  makegappm(Session * sess, typecuc * fullcrumptr, typewid * origin, typewid * width);
//STATIC void  findaddressofsecondcutforinsert(Tumbler * position, Tumbler * secondcut);
//STATIC int   doinsertnd(typecuc * father, typewid * origin, typewid * width, type2dbottomcruminfo * infoptr, int index);
//STATIC void  firstinsertionnd(typecuc * father, typewid * origin, typewid * width, type2dbottomcruminfo * infoptr);
//STATIC int   insertmorend(typecuc * father, typedsp * offset, typewid * origin, typewid * width, type2dbottomcruminfo * infoptr, int index);
//STATIC int   insertcbcnd(typecuc * father, typedsp * grasp, typewid * origin, typewid * width, type2dbottomcruminfo * infoptr);
//STATIC typecorecrum *findsontoinsertundernd(typecuc * father, typedsp * grasp, typewid * origin, typewid * width, int index);
//STATIC bool  isanextensionnd(typecbc * ptr, typedsp * offsetptr, typedsp * originptr, type2dbottomcruminfo * infoptr);

/* makeroom.cxx */

void  makeroomonleftnd(typecuc * father, typedsp * offset, typewid * origin, typedsp * grasp);
//STATIC void  expandcrumleftward(typecorecrum * crumptr, Tumbler * newdsp, Tumbler * base, int index);

/* multiloaf.cxx */

//STATIC void  dumpincoretables();
//STATIC void  dumpfdhashtable();
//STATIC void  dumpfdorderedtable();
//STATIC void  dumpfreediskentry(freediskentry * ptr);
void  initincorealloctables();
void  savepartialdiskalloctabletodisk();
void  readpartialdiskalloctablefromdisk();
//STATIC void  addtofreediskstructures(freediskentry * diskentry);
void  addallocatedloaftopartialallocedtables(typediskloafptr dp, int size);
//STATIC void  changefreediskstructures(freediskentry * diskentry, int newsize);
//STATIC int   fdhash(int diskblocknumber);
//STATIC freediskentry *findfreeenoughloafinbucket(int size);
typediskloafptr partialdiskalloc(int size, int * newloafp);
//STATIC void  deletefromfreediskstructures(freediskentry * diskentry);
void  newpartialdiskfree(typediskloafptr diskloaf);
int   deallocateinloaf(typeuberdiskloaf * loafp, int insidediskblocknumber);
//STATIC int   findandallocateinsidediskblocknumber(int diskblocknumber, int size, typeuberdiskloaf * loafp);
int   numberofliveunterloafs(typeuberdiskloaf * loafp);
char *findinsideloaf(typeuberdiskloaf * loafp, int ninsideloaf);

/* ndcuts.cxx */

void  makecutsnd(typecuc * fullcrumptr, typeknives * knives);
//STATIC void  makecutsdownnd(typecuc * fullcrumptr, typewid * offset, typeknives * knives);
//STATIC void  makecutsbackuptohere(typecuc * ptr, typewid * offset, typeknives * knives);
//STATIC void  cutsons(typecuc * ptr, typewid * offset, typeknives * knives);
//STATIC void  makeithcutonson(typecorecrum * ptr, typewid * offset, typecorecrum * son, typewid * grasp, typeknives * knives, int i);
//STATIC void  peelsoncorrectly(typecorecrum * ptr, typewid * offset, typecorecrum * son, typewid * grasp, typeknives * knives, int i);
//STATIC bool  crumleftofithcut(typecorecrum * ptr, typewid * offset, typeknives * knives, int i);
//STATIC bool  peeloffcorrectson(typecorecrum * ptr, typeknives * knives);
//STATIC void  newpeelcrumoffnd(typecorecrum * ptr, typecorecrum * newuncle);
//STATIC bool  crumiscut(typecuc * ptr, typewid * offset, typeknives * knives);
//STATIC bool  crumiscutbyithknife(typecuc * ptr, typewid * offset, typeknives * knives, int i);
//STATIC bool  sonsarecut(typecuc * ptr, typewid * offset, typeknives * knives);
//STATIC void  slicecbcpm(typecorecrum * ptr, typewid * offset, typecorecrum * newcrum, Tumbler * cut, int index);

/* ndinters.cxx */

void  newfindintersectionnd(typecuc * fullcrumptr, typeknives * knives, typecuc ** ptrptr, typewid * offset);
bool  cutinthiscrumnd(typecorecrum * ptr, typewid * offset, typeknives * knives);
bool  allcutswiththiscrumnd(typecorecrum * ptr, typewid * offset, typeknives * knives);

/* orglinks.cxx */

bool  appendpm(Session * sess, IStreamAddr * docisaptr, typetextset textset);
bool  insertpm(Session * sess, Tumbler * orglisa, typeorgl orgl, Tumbler * vsaptr, typesporglset sporglset);
bool  rearrangepm(Session * sess, Tumbler * docisaptr, typeorgl docorgl, typecutseq * cutseqptr);
bool  deletevspanpm(Session * sess, Tumbler * docisaptr, typeorgl docorgl, typevspan * vspanptr);
bool  retrievedocumentpartofvspanpm(Session * sess, typeorgl orgl, typevspan * vspanptr);
bool  retrievevspanpm(Session * sess, typeorgl orgl, typevspan * vspanptr);
bool  retrievevspansetpm(Session * sess, typeorgl orgl, typevspanset * vspansetptr);
//STATIC bool  istextcrum(typecorecrum * crumptr);
//STATIC bool  islinkcrum(typecorecrum * crumptr);
bool  retrievevspansetpm(Session * sess, typeorgl orgl, typevspanset * vspansetptr);
void  walkorglonvpm(Session * sess, typecorecrum * crumptr, Tumbler * voffset, typevspanset * vspansetptr);
void  cleanupvspanlist(Session * sess, typevspanset * vspansetptr);
//STATIC typevspan *makevspan(Session * sess, typevspan * spanptr, typevspan * nextspan);
//STATIC void  putvspaninlist(Session * sess, typevspan * spanptr, typevspanset * spansetptr);
typevspanset *ispan2vspanset(Session * sess, typeorgl orgl, typeispan * ispanptr, typevspanset * vspansetptr);
typeispanset *vspanset2ispanset(Session * sess, typeorgl orgl, typevspanset vspanptr, typeispanset * ispansetptr);
//STATIC typespanset *permute(Session * sess, typeorgl orgl, typespanset restrictionspanset, int restrictionindex, typespanset * targspansetptr, int targindex);
//STATIC typespanset *span2spanset(Session * sess, typeorgl orgl, typespanset restrictionspanptr, int restrictionindex, typespanset * targspansetptr, int targindex);
typeitem *onitemlist(Session * sess, typeitem * itemptr, typeitemset * itemsetptr);
bool  isemptyorgl(typeorgl fullcrumptr);

/* put.cxx */

//void  prompt(Session * sess, char *string);
//void  error(Session * sess, char *string);
void  puttumbler(FILE * outfile, Tumbler * tumblerptr);
//void  putnum(FILE * outfile, int num);
//void  putisa(Session * sess, IStreamAddr * isaptr);
void  putitemset(Session * sess, typeitemset itemset);
//void  putitem(Session * sess, typeitem * itemptr);
//void  putspan(Session * sess, typespan * spanptr);
//void  puttext(Session * sess, typetext * textptr);
//void  putspanpairset(Session * sess, typespanpairset spanpairset);
//void  putspanpair(Session * sess, typespanpair * spanpair);
//void  putcreatelink(Session * sess, IStreamAddr * istreamptr);
//void  putfollowlink(Session * sess, typespecset specset);
//void  putretrievedocvspanset(Session * sess, typespanset * spansetptr);
//void  putretrievedocvspan(Session * sess, typespan * vspanptr);
//void  putretrievev(Session * sess, typevstuffset * vstuffsetptr);
//void  putfindlinksfromtothree(Session * sess, typelinkset linkset);
//void  putfindnumoflinksfromtothree(Session * sess, int num);
//void  putfindnextnlinksfromtothree(Session * sess, int n, typelinkset nextlinkset);
//void  putshowrelationof2versions(Session * sess, typespanpairset relation);
//void  putcreatenewdocument(Session * sess, IStreamAddr * newdocisaptr);
//void  putcreatenewversion(Session * sess, IStreamAddr * newdocisaptr);
//void  putfinddocscontaining(Session * sess, typeitemset addressset);
//void  putretrieveendsets(Session * sess, typespecset fromset, typespecset toset, typespecset threeset);
//void  putinsert(Session * sess);
//void  putcopy(Session * sess);
//void  putdeletevspan(Session * sess);
//void  putrearrange(Session * sess);
//void  putrequestfailed(Session * sess);

/* putfe.cxx */

//void  xuputc(char c, FILE * fd);
//void  xuputstring(char *string, FILE * fd);
//void  putnum(FILE * outfile, int num);
//void  sendresultoutput(Session * sess);
//void  error(Session * sess, char *string);
//void  prompt(Session * sess, char *string);
//void  putnumber(FILE * outfile, int num);
//void  puttumbler(FILE * outfile, Tumbler * tumblerptr);
//void  putisa(Session * sess, IStreamAddr * isaptr);
//void  putitemset(Session * sess, typeitemset itemset);
//void  putitem(Session * sess, typeitem * itemptr);
//void  putspan(Session * sess, typespan * spanptr);
//void  puttextset(Session * sess, typetext ** textptrptr);
//void  puttext(Session * sess, typetext * textptr);
//void  putspanpairset(Session * sess, typespanpairset spanpairset);
//void  putspanpair(Session * sess, typespanpair * spanpair);
//void  putinsert(Session * sess);
//void  putretrievedocvspanset(Session * sess, typespanset * spansetptr);
//void  putcopy(Session * sess);
//void  putrearrange(Session * sess);
//void  putcreatelink(Session * sess, IStreamAddr * istreamptr);
//void  putretrievev(Session * sess, typevstuffset * vstuffsetptr);
//void  putfindnumoflinksfromtothree(Session * sess, int num);
//void  putfindlinksfromtothree(Session * sess, typelinkset linkset);
//void  putfindnextnlinksfromtothree(Session * sess, int n, typelinkset nextlinkset);
//void  putshowrelationof2versions(Session * sess, typespanpairset relation);
//void  putcreatenewdocument(Session * sess, IStreamAddr * newdocisaptr);
//void  putdeletevspan(Session * sess);
//void  putcreatenewversion(Session * sess, IStreamAddr * newdocisaptr);
//void  putretrievedocvspan(Session * sess, typespan * vspanptr);
//void  putfollowlink(Session * sess, typespecset specset);
//void  putfinddocscontaining(Session * sess, typeitemset addressset);
//void  putretrieveendsets(Session * sess, typespecset fromset, typespecset toset, typespecset threeset);
//void  putrequestfailed(Session * sess);
//void  putxaccount(Session * sess);
//void  putcreatenode_or_account(Session * sess, Tumbler * tp);
//void  putopen(Session * sess, Tumbler * tp);
//void  putclose(Session * sess);
//void  putquitxanadu(Session * sess);

/* queues.cxx */

void  qinit(struct queue *qhead);
void  qinsert(struct queue *qhead, struct queue *object);
void  qpush(struct queue *qhead, struct queue *object);
struct queue *qremove(struct queue *qhead);
struct queue *qnext(struct queue *qthis, struct queue *qhead);
struct queue *qdchain(struct queue *qitem);
int   qlength(struct queue *qhead);
bool  qvalid(struct queue * qhead);

/* recombine.cxx */

void  recombine(typecuc * father);
//STATIC void  recombineseq(typecuc * father);
//STAIIC void  takeovernephewsseq(typecorecrum * me);
//STATIC void  eatbrossubtreeseq(typecuc * me);
//STATIC void  recombinend(typecuc * father);
//STATIC bool  randomness(float probability);
bool  ishouldbother(typecuc * dest, typecuc * src);
//STATIC bool  takeovernephewsnd(typecuc ** meptr, typecuc ** broptr);
//STATIC void  eatbrossubtreend(typecuc * me, typecuc * bro);
//STATIC void  takenephewnd(typecuc * me, typecuc * nephew);
//STATIC void  fixdspsofbroschildren(typecuc * me, typecuc * bro);
//STATIC void  getorderedsons(typecuc * father, typecorecrum * sons[]);
//STATIC void  shellsort(typecorecrum * v[], int n);
int   comparecrumsdiagonally(typecorecrum * a, typecorecrum * b);
void  fixincoresubtreewids(typecuc * ptr);

/* retrie.cxx */

CrumContext *retrievecrums(typecuc * fullcrumptr, Tumbler * address, int index);
Context *retrieve(typecuc * fullcrumptr, Tumbler * address, int index);
Context *retrieverestricted(typecuc * fullcrumptr, typespan * span1ptr, int index1, typespan * span2ptr, int index2, IStreamAddr * docisaptr);
//STATIC Context *retrieveinarea(typecuc * fullcrumptr, Tumbler * span1start, Tumbler * span1end, int index1, Tumbler * span2start, Tumbler * span2end, int index2, typebottomcruminfo * infoptr);
Context *retrieveinspan(typecuc * fullcrumptr, Tumbler * spanstart, Tumbler * spanend, int index);
//STATIC Context *findlastcbcseq(typecorecrum * fullcrumptr);
//STATIC CrumContext *findcbcseqcrum(typecorecrum * ptr, typedsp * offsetptr, Tumbler * address);
//STATIC Context *findcbcseq(typecorecrum * ptr, typedsp * offsetptr, Tumbler * address);
//STATIC Context *findcbcnd(typecorecrum * father, typewid * offsetptr, Tumbler * address, int index);
//STATIC void  findcbcinarea2d(typecorecrum * crumptr, typedsp * offsetptr, Tumbler * span1start, Tumbler * span1end, int index1, Tumbler * span2start, Tumbler * span2end, int index2, Context **headptr, typebottomcruminfo * infoptr);
//STATIC bool  crumqualifies2d(typecorecrum * crumptr, typedsp * offset, Tumbler * span1start, Tumbler * span1end, int index1, Tumbler * span2start, Tumbler * span2end, int index2, type2dbottomcruminfo * infoptr);
//STATIC void  findcbcinspanseq(typecorecrum * crumptr, typewid * offsetptr, Tumbler * spanstart, Tumbler * spanend, Context ** headptr) ;
void  prologuend(typecorecrum * ptr, typedsp * offset, typedsp * grasp, typedsp * reach);
int   whereoncrum(typecorecrum * ptr, typewid * offset, Tumbler * address, int index);
//STATIC bool  crumintersectsspanseq(typecorecrum * crumptr, Tumbler * offsetptr, Tumbler * spanstart, Tumbler * spanend);

/* spanf1.cxx */

bool insertspanf(Session * sess, typespanf spanfptr, IStreamAddr * isaptr, typesporglset sporglset, int spantype);
bool findlinksfromtothreesp(Session * sess, typespanf spanfptr, typespecset fromvspecset, typespecset tovspecset, typespecset threevspecset, typeispan * orglrange, typelinkset * linksetptr);
bool findnumoflinksfromtothreesp(Session * sess, typespanf spanfptr, typespecset fromvspecset, typespecset tovspecset, typespecset threevspecset, typeispan * orglrange, int * numptr);
bool findnextnlinksfromtothreesp(Session * sess, typespecset fromvspecset, typespecset tovspecset, typespecset threevspecset, typeispan * orglrangeptr, IStreamAddr * lastlinkisaptr, typelinkset * nextlinksetptr, int * nptr);
bool finddocscontainingsp(Session * sess, typespanset ispanset, typelinkset * addresssetptr);
bool retrieveendsetsfromspanf(Session * sess, typespecset specset, typespecset * fromsetptr, typespecset * tosetptr, typespecset * threesetptr);
//STATIC bool retrievesporglsetinrange(Session * sess, typesporglset sporglptr, typespan * whichspace, typesporglset * sporglsetptr);

/* spanf2.cxx */

bool  isinlinklist(typelinkset linkset, IStreamAddr * linkisaptr);
void  onlinklist(Session *sess, typelinkset *linksetptr, IStreamAddr *linkisaptr);
void  intersectlinksets(Session * sess, typelinkset linkset1, typelinkset linkset2, typelinkset linkset3, typelinkset * linkset4ptr);
//STATIC typelink *makelinkitem(Session * sess, IStreamAddr * linkisa);

/* split.cxx */

bool  splitcrumupwards(typecuc * father);
void  splitcrum(typecuc * father);
//STATIC void  splitcrumseq(typecuc * father);
//STATIC void  splitcrumsp(typecuc * father);
//STATIC void  splitcrumpminthiscrum(typecuc * father);
//STATIC void  splitcrumpm(typecuc * father);
void  peelcrumoffnd(typecorecrum * ptr);

/* sporgl.cxx */

bool  specset2sporglset(Session * sess, typespecset specset, typesporglset * sporglsetptr, int type);
//STATIC typesporglset *vspanset2sporglset(Session * sess, IStreamAddr * docisa, typevspanset vspanset, typesporglset * sporglsetptr, int type);
bool  link2sporglset(Session * sess, IStreamAddr * linkisa, typesporglset * sporglsetptr, int whichend, int type);
bool  linksporglset2specset(Session * sess, IStreamAddr * homedoc, typesporglset sporglset, typespecset * specsetptr, int type);
//STATIC void  linksporglset2vspec(Session * sess, IStreamAddr * homedoc, typesporglset * sporglsetptr, typevspec * specptr, int type);
//STATIC void  sporglset2vspanset(Session * sess, IStreamAddr * homedoc, typesporglset * sporglsetptr, typevspanset * vspansetptr, int type);
void  unpacksporgl(typesporglset sporglptr, Tumbler * streamptr, Tumbler * widthptr, type2dbottomcruminfo * infoptr);
void  contextintosporgl(type2dcontext * context, Tumbler * linkid, typesporgl * sporglptr, int index);
void  sporglset2linkset(Session * sess, typecuc * spanfptr, typesporglset sporglset, typelinkset * linksetptr, typeispan * homeset, int spantype);
//STATIC void  sporglset2linksetinrange(Session * sess, typecuc * spanfptr, typesporglset sporglset, typelinkset * linksetptr, typeispan * orglrange, int spantype);

/* test.cxx */

void  foo(char *msg);
void  foospan(char *msg, typespan * span);
void  foospanset(char *msg, typespan * spanset);
void  dumpspanset(typespan * spanset);
void  foocrum(char *msg, typecorecrum * crumptr);
void  foohex(char *msg, int num);
void  foodec(char *msg, int num);
void  foocontext(char *msg, Context * context);
void  foocontextlist(char *msg, Context * context);
void  fooitemset(char *msg, typeitemset iptr);
void  fooitem(char *msg, typeitem * iptr);
void  footumbler(char *msg, Tumbler * tptr);
void  foodsp(char *msg, typedsp * dptr, int enftype);
void  foowid(char *msg, typewid * wptr, int enftype);
void  dumpsubtree(typecuc * father);
void  dumpwholesubtree(typecuc * father);
void  assertspecisstring(typespecset specptr, char *string);
bool  asserttreeisok(typecorecrum * ptr);
void  assertsubtreeisok(typecorecrum * ptr);
void  assertsonswispmatchesfather(typecuc * father);
void  assertwidsarepositive(typecorecrum * ptr);
void  dumpwholetree(typecorecrum * ptr);
int   checkwholesubtree(typecuc * father);
int   check(typecuc * ptr);
void  dump(typecorecrum * ptr);
void  yesdump(typecorecrum * ptr);
void  dumphedr(typecorecrumhedr * ptr);
void  dumpwid(typewid * widptr, int enftype);
void  dumpdsp(typewid * dspptr, int enftype);
void  dumpinfo(typegranbottomcruminfo * infoptr, int enftype);
void  dumptumbler(Tumbler * tumblerptr);
void  displaycutspm(typeknives * knivesptr);
void  dumphint(typehint * hintptr);
void  examine(Session * sess);
void  showorgl(Session * sess);
void  showsubtree(typecorecrum * father);
void  showistream(typecuc * granfptr);
void  showspanf(typecuc * spanfptr);
void  doshowspanf(typecorecrum * crumptr, typedsp * offsetptr, int enfheight);
void  showspanfcrum(typecorecrum * crumptr, typedsp * offsetptr, int enfheight);
void  dumpmem(char *loc, unsigned count);
bool  dumpgranfwids(Session * sess);
void  showgranwids(typecorecrum * crum, int down, Tumbler * retptr);
void  dumppoomwisps(typecorecrum * orgl);
void  showpoomwisps(typecuc * crum, int down);
void  dumpistreamgr(typecuc * crumptr);
void  dodumpistreamgr(typecuc * crumptr, Tumbler * offsetptr);
void  dumpmoleculegr(Tumbler * offsetptr, typecbc * cbcptr);
void  dumpisagr(Tumbler * offsetptr);
typecorecrum *checkenftypes(typecuc * father, char *message);
typecorecrum *checkthebleedingcrum(typecorecrum * crumptr);
void  teststack();
char *enftypestring(int type);
typecorecrum *sonoriginok(typecorecrum * father);
void  dumpcontextlist(Context * context);
void  dumpcontext(Context * context);
void  dumpitemset(typeitemset itemset);
void  dumpitem(typeitem * itemptr);
void  dumpspan(typespan * spanptr);
void  dumptext(typetext * textptr);
bool  ioinfo(Session * sess);
void  showenfilades(Session * sess);
char *itemidstring(typeitem * item);
void  checkitem(char *msg, typeitem * ptr);
void  checkpointer(char *msg, char *ptr);
void  dumpspanpairset(typespanpairset spanpairset);
void  dumpspanpair(typespanpair * spanpair);
void  dumphexstuff(char *ptr);
void  checknumofsons(typecuc * ptr);
void  nchecknumofsons(typecuc * ptr);

/* tumble.cxx */

bool  tumblereq(Tumbler *a, Tumbler *b);
bool  tumbleraccounteq(Tumbler *aptr, Tumbler *bptr);
int   tumblercmp(Tumbler *aptr, Tumbler *bptr);
int   intervalcmp(Tumbler *left, Tumbler *right, Tumbler *address);
bool  tumblercheckptr(Tumbler *ptr, int /* typecrum */  *crumptr);
bool  tumblercheck(Tumbler * ptr);
bool  is1story(Tumbler *tumblerptr);
int   nstories(Tumbler * tumblerptr);
int   tumblerlength(Tumbler * tumblerptr);
int   lastdigitintumbler(Tumbler * tumblerptr);
void  tumblerjustify(Tumbler * tumblerptr);
//STATIC void  partialtumblerjustify(Tumbler * tumblerptr);
void  tumblercopy(Tumbler *fromptr, Tumbler *toptr);
void  tumblermax(Tumbler * aptr, Tumbler * bptr, Tumbler * cptr);
void  functiontumbleradd(Tumbler * aptr, Tumbler * bptr, Tumbler * cptr);
void  tumblersub(Tumbler * aptr, Tumbler * bptr, Tumbler * cptr);
void  absadd(Tumbler * aptr, Tumbler * bptr, Tumbler * cptr);
void  absadd(Tumbler * aptr, Tumbler * bptr, Tumbler * cptr);
void  strongsub(Tumbler * aptr, Tumbler * bptr, Tumbler * cptr);
void  weaksub(Tumbler * aptr, Tumbler * bptr, Tumbler * cptr);
int   tumblerintdiff(Tumbler * aptr, Tumbler * bptr);
void  tumblerincrement(Tumbler * aptr, int rightshift, int bint, Tumbler * cptr);
void  tumblertruncate(Tumbler * aptr, int bint, Tumbler * cptr);
void  prefixtumbler(Tumbler * aptr, int bint, Tumbler * cptr);
void  beheadtumbler(Tumbler * aptr, Tumbler * bptr);
void  docidandvstream2tumbler(Tumbler * docid, Tumbler * vstream, Tumbler * tumbleptr);

/* tumbleari.cxx */

int tumblerptrtofixed(humber p, Tumbler * tptr);
int tumblerfixedtoptr(Tumbler * ptr, humber p);
humber fooalloc(unsigned int size);
void foofree(humber ptr);
//STATIC unsigned int calculatetotallength(unsigned int lengthofbody);
humber humberput(int i, humber humberfoo, unsigned int * lengthofhumberptr);
humber humber3put(int i, humber humberfoo, unsigned int * lengthofhumberptr);
unsigned int functionintof(humber h);
unsigned int intlengthoflength(unsigned int i);
//STATIC unsigned int lengthoflength(humber ptr);
//STATIC humber exponentof(humber ptr);
//STATIC unsigned int lengthofexp(Tumbler * ptr);
unsigned int functionlengthof(humber ptr);
humber mantissaof(humber ptr);

/* wisp.cxx */

void  dspadd(typedsp * a, typewisp * b, typedsp * c, int enftype);
void  dspsub(typedsp * a, typewisp * b, typedsp * c, int enftype);
bool  setwispupwards(typecuc * ptr, int testflag);
void  setwispsofsons(typecuc * ptr);
bool  setwisp(typecorecrum * ptr);
//STATIC bool  setwidseq(typecuc * father);
//STATIC bool  setwispnd(typecuc * father);
//STATIC void  didntchangewisps();
void  setwidnd(typecuc * father);
bool  iszerolock(Tumbler * lock, unsigned loxize);
bool  lockeq(Tumbler * lock1, Tumbler * lock2, unsigned loxize);
void  lockadd(Tumbler * lock1, Tumbler * lock2, Tumbler * lock3, unsigned loxize);
void  locksubtract(Tumbler * lock1, Tumbler * lock2, Tumbler * lock3, unsigned loxize);
//STATIC void  lockmin(Tumbler * lock1, Tumbler * lock2, Tumbler * lock3, unsigned loxize);
//STATIC void  lockmax(Tumbler * lock1, Tumbler * lock2, Tumbler * lock3, unsigned loxize);
bool  lockis1story(Tumbler * lock, unsigned loxize);

/* credel.cxx */
extern void etag();
extern int *eallocwithtag(unsigned nbytes, tagtype tag);
//STATIC extern int *ealloc(unsigned nbytes);
extern void efree(char *ptr);
extern void efreewithtag();

void *operator new(size_t nbytes, Session *sess);

extern humber humberput();
extern humber humber3put();

/* 
 * #define lengthof(x) functionlengthof(x) */
#define weakfindfather(x) ((typecuc *)(((!(((typecuc*)(x))->isapex))&&(((typecuc*)(x))->isleftmost))?((typecuc*)((typecuc*)(x))->leftbroorfather):(typecuc*)functionweakfindfather((typecorecrum *)(typecuc*)(x))))

#define clear(ptr,count) memset(ptr,0,count)
#define movmem(src,dest,count) memmove(dest,src,count)

//#define move2dinfo(A,B) movmem((A), (B), sizeof(type2dbottomcruminfo))
inline void
move2dinfo(type2dbottomcruminfo *A, type2dbottomcruminfo *B)
{
    movmem(A, B, sizeof(type2dbottomcruminfo));
}

//#define moveinfo(A,B) movmem((A),(B),sizeof(typebottomcruminfo))
inline void
moveinfo(typebottomcruminfo *A, typebottomcruminfo *B)
{
    movmem(A, B, sizeof(typebottomcruminfo));
}

//OBSOLETE #define gerror(s) assert(false); //qerror(s)

#define rejuvinateifnotRESERVED(x) (((x)->age==RESERVED)?(int)(x):((x)->age = NEW))

#define rejuvinate(x) ((x)->age==RESERVED)?(reservnumber?--reservnumber:testforrejuvinate(x)):0,(x)->age = NEW
//inline void rejuvinate(typecorecrum *x)
//{
//  (x->age==RESERVED) ? (reservnumber ? --reservnumber : testforrejuvinate(x)) : 0, x->age = NEW;
//}
/* not needed #define rejuvinate(x) funcrejuvinate(x) */

#define getrightbro(x) routinegetrightbro(x)

#define macrogetrightbro(x)    ((rejuvinateifnotRESERVED (x), (x) = (x)->rightbro,  ((x)? (rejuvinateifnotRESERVED (x)): 0),(x)))

/* not needed#define macrogetrightbro(x) getrightbro() */

/* #define findrightbro(A) macrogetrightbro(A) */
#define findrightbro(A) funcfindrightbro(A)

#ifndef max
#define max(a,b)        (((a) > (b)) ? (a) : (b))
#endif
#ifndef min
#define min(a,b)        (((a) < (b)) ? (a) : (b))
#endif

/*
 * wisp
 */

#define movewisp(A,B)  movmem((A),(B),sizeof(typewisp))
#define widsize(A)     ((A)==GRAN?WIDSIZEGR:((A)==SPAN?WIDSIZESP:WIDSIZEPM))
#define dspsize(A)     ((A)==GRAN?DSPSIZEGR:((A)==SPAN?DSPSIZESP:DSPSIZEPM))


extern bool isthisusersdocument(Session *sess, Tumbler * tp);

//#define hgetfromloaf(ip,lp)   (*(ip)=intof((humber)lp),(lp)=((char*)lp)+lengthof((humber)lp))
inline int
hgetfromloaf(int *ip, char *lp)
{
    *ip = intof((humber) lp);
    lp  = lp + lengthof((humber) lp);
}

#endif /* !__UDANAX_PROTOS_H__*/
