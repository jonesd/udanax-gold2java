/**********************************************************************
 * Copyright 2002 Jeff Rush <jrush@taupro.com>
 * Original Copyright 1979-2002 Udanax.com
 *
 * This file is part of the Udanax xanalogical storage system.
 *
 * Udanax is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * Udanax is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with Udanax; if not, write to the Free Software Foundation,
 * Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 **********************************************************************/

/**
 * @file  requests.h
 * @brief ???
 *
 * (to be defined)
 *
 **/

/* Modification History:
 * $Log: requests.h,v $
 * Revision 1.2  2002/05/28 03:58:42  jrush
 * Sources modified to comply with GPL licensing.
 *
 * Revision 1.1  2002/04/12 10:00:12  jrush
 * Moved include/requests.h to server/requests.h
 *
 * Revision 1.5  2002/04/06 14:57:47  jrush
 * Cosmetic.
 *
 * Revision 1.4  2002/02/14 05:40:42  jrush
 * Cleaned up source:
 *
 * 1. ran thru the indent tool to achieve a standard look,
 * 2. added structured comments at top for use with DOxygen reporting
 *    as well as CVS keywords,
 * 3. added #ifndef/#defines to prevent duplicate inclusions,
 * 4. insured all struct/union defs have names,
 * 5. centralized prototypes in protos.h, removing incomplete ones,
 * 6. cleaned up use of bool/BOOLEAN type to suit C++ type,
 * 7. fixed initializer nesting in tumbler constants.
 *
 */

#ifndef __UDANAX_REQUESTS_H__
#define __UDANAX_REQUESTS_H__

/* The requests */
/* see xanadu.j for NREQUESTS currently set to 40 */


#define INSERT                      0
#define RETRIEVEDOCVSPANSET         1
#define COPY                        2
#define REARRANGE                   3

#define RETRIEVEV                   5

#define NAVIGATEONHT                9
#define SHOWRELATIONOF2VERSIONS    10
#define CREATENEWDOCUMENT          11
#define DELETEVSPAN                12
#define CREATENEWVERSION           13
#define RETRIEVEDOCVSPAN           14
#define SETDEBUG                   15  /* debug 15 */
#define QUIT                       16
#define SHOWENFILADES              17  /* show enfs 17 */
#define FOLLOWLINK                 18
#define EXAMINE                    20  /* examine 20 */
#define SOURCEUNIXCOMMAND          21
#define FINDDOCSCONTAINING         22
#define DUMPGRANFWIDS              23  /* dump gran 23f */
#define JUSTEXIT                   24
#define IOINFO                     25

#define CREATELINK                 27
#define RETRIEVEENDSETS            28
#define FINDNUMOFLINKSFROMTOTHREE  29
#define FINDLINKSFROMTOTHREE       30
#define FINDNEXTNLINKSFROMTOTHREE  31
#define SETMAXIMUMSETUPSIZE        32
#define PLAYWITHALLOC              33  /* alloc 33 */
#define XACCOUNT                   34
#define OPEN                       35
#define CLOSE                      36

#define CREATENODE_OR_ACCOUNT      38

#endif /* !__UDANAX_REQUESTS_H__ */
