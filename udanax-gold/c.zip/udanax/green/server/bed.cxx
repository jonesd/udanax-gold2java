/**********************************************************************
 * Copyright 2002 Jeff Rush <jrush@taupro.com>
 * Original Copyright 1979-2002 Udanax.com
 *
 * This file is part of the Udanax xanalogical storage system.
 *
 * Udanax is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * Udanax is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with Udanax; if not, write to the Free Software Foundation,
 * Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 **********************************************************************/

/**
 * @file  bed.cxx
 * @brief multi-user backend main
 *
 * (to be defined)
 *
 **/

/* Modification History:
 * $Log: bed.cxx,v $
 * Revision 1.13  2002/07/26 04:33:47  jrush
 * Replaced gerror() with assert()
 *
 * Revision 1.12  2002/05/28 03:58:42  jrush
 * Sources modified to comply with GPL licensing.
 *
 * Revision 1.11  2002/04/12 11:48:50  jrush
 * Major reorganization of includes into a single base-include style.
 *
 * Revision 1.10  2002/04/09 21:45:46  jrush
 * Renamed class 'tumbler' to 'Tumbler', for consistency with Python sources,
 * and changed typeisa from typedef to a subclass, in preparation for cleaning
 * up the type/class tree.
 *
 * Revision 1.9  2002/04/08 18:55:56  jrush
 * Switched from using global variable 'user' to object 'Session' as a
 * connection for tracking open document descriptors in the bert table.
 *
 * Revision 1.8  2002/04/06 19:51:30  jrush
 * Renamed TRUE/FALSE constant use to the C++ standard of true/false.
 *
 * Revision 1.7  2002/04/06 17:05:57  jrush
 * Switched from referring to 'task' for a client connection to 'session',
 * and converted the typetask typedef/struct into a Session C++ class.
 *
 * Revision 1.6  2002/04/06 15:01:44  jrush
 * Changed INT to just 'int'.
 *
 * Revision 1.5  2002/04/02 17:43:10  jrush
 * Fixed select() and FD_SET to work with Gnu C under Linux; added debugging
 * msgs, some cosmetic cleanup.
 *
 * Revision 1.4  2002/02/14 10:08:25  jrush
 * Cleaned up source:
 *
 * 1. ran thru the indent tool to achieve a standard look,
 * 2. added structured comments at top for use with DOxygen reporting
 *    as well as CVS keywords,
 * 3. centralized prototypes in protos.h, removing incomplete ones,
 * 4. cleaned up use of bool/BOOLEAN type to suit C++ type,
 * 5. fixed initializer nesting in tumbler constants,
 * 6. converted select() int bits into ANSI fd_set type,
 * 7. added Makefile.am for use by automake.
 *
 */

int backenddaemon;       /* backend version */

#include <errno.h>
#include <setjmp.h>                    /* an easy way to deal with unexpected EOF on frontend input */
#include <stdlib.h>
#include <signal.h>
#include <sys/time.h>                  /* includes <time.h> */
#ifndef sun
#include <time.h>
#endif                                 /* sun */
#include "udanax.h"
#include "players.h"
#include "requests.h"

jmp_buf frontendeof;

int user = 0;   /* Global current user ID */

extern int errno;

FILE *logfile;
FILE *nulllog;
FILE *reallog;
char outputbuffer[BUFSIZ];
char inputbuffer[BUFSIZ];
bool logstuff;
FILE *interfaceinput;
extern FILE *febelog;
struct timeval timeout;
extern int main_socket;
static Tumbler currentaccount;
bool quitafteruser = false;
bool mightbeblocked = false;

extern bool getrequest(Session *sess, typerequest *requestptr);
extern void sendresultoutput(Session * session);
extern void xuputstring(char *string, FILE * fd);
extern void processrcfile();
extern void crash(int /*sigarg*/);
extern void leave(PLAYER player[], int * xn_players);
extern int open_sock();
extern void new_players(PLAYER player[], int * n_playersp, int block, Session * sess);
extern void logaccount(Tumbler * tp);

void
xanadu(Session *sess)
{
    fprintf(stderr, "Entering xanadu()\n");

    typerequest request;

    logstuff = false;
    if (setjmp(frontendeof)) {
        dobertexit(sess);
        player[user].wantsout = true;

    } else if (getrequest(sess, &request)) {

        (*requestfns[request]) (sess);
        sendresultoutput(sess);

        if (request == QUIT)
            player[user].wantsout = true;
    }

    sess->free();

    if (interfaceinput && interfaceinput != nulllog)
        fflush(interfaceinput);

    logstuff = false;
    fprintf(stderr, "Leaving xanadu()\n");
}

void
flagquitting(int /*sigarg*/)
{
    signal(SIGINT, SIG_IGN);           /* Don't die too early */
    if (mightbeblocked) {
        if (interfaceinput) {
            fprintf(interfaceinput, "%d~\n", QUIT);
            fclose(interfaceinput);
        }
        writeenfilades();
        closediskfile();
        exit(0);
    } else
        quitafteruser = true;          /* Flag to stop backend after current request */
}

int
main(int argc, char *argv[])
{                                      /* inside temporary */
    Session sess;
    char buf[100];
    //UNUSED FILE *fd;
    struct tm *local;
    long clock;

/* extern void crash();* *//* if broken pipe, release port (I hope) */

    //UNUSED int s;      /* for socket */
    fd_set inputfds2;
    int i;

    freopen("backenderror", "w", stderr);
    setbuf(stderr, NULL);

    backenddaemon = 1;

    FD_ZERO(&inputfds);

    processrcfile();

    signal(SIGPIPE, crash);
    signal(SIGHUP, crash);
    signal(SIGXCPU, SIG_IGN);
    signal(SIGINT, flagquitting);

    febelog = interfaceinput = reallog = logfile = nulllog = fopen("/dev/null", "a");

    clock = time(0);
    local = localtime(&clock);
    sprintf(buf, "ln%d.%d.%d:%d", local->tm_mon + 1, local->tm_mday, local->tm_hour, local->tm_min);
    interfaceinput = fopen(buf, "w");

#ifndef DISTRIBUTION
    sprintf(buf, "febe%d.%d.%d:%d", local->tm_mon + 1, local->tm_mday, local->tm_hour, local->tm_min);
    febelog = fopen(buf, "w");
    setbuf(febelog, NULL);
#endif

    setbuf(stdin, inputbuffer);
    setbuf(stdout, outputbuffer);
    debug = 0;
    init(1);
    //now uses a ctor:: inittask(&sess);
    errno = 0;
    initmagicktricks();
    main_socket = open_sock();

    if (n_players < 1) {
        mightbeblocked = true;
        new_players(player, &n_players, true, &sess);   /* wait for fe to talk to */
        mightbeblocked = false;
    }

    for (;;) {
        if (n_players < 1) {
            diskflush();               /* Write out everything when no one around */
            mightbeblocked = true;
            new_players(player, &n_players, true, &sess);       /* wait for fe to talk to */
            mightbeblocked = false;
        }

        inputfds2       = inputfds;
        timeout.tv_sec  = 2;                /* wait 2 seconds on a select, then look for a new user */
	timeout.tv_usec = 0;

        int nevents = select(nfds + 1, &inputfds2, 0, 0, &timeout);
        if (nevents < 0) {
            if (errno == EINTR) {
                continue;
            }
            perror("select");
            assert(0); // select in main
        } else {

            if (nevents)
                fprintf(stderr, "Somone connected to our main socket\n");

            for (i = 0; i <= nfds; i++) {
                if (FD_ISSET(i, &inputfds2)) {
//OBSOLETE                if ((1 << i) & inputfds2) {
                    fprintf(stderr, "Read-Event on socket %d\n", i);

                    user         = fdtoplayer[i];
                    sess.inp     = player[user].inp;
                    sess.outp    = player[user].outp;
                    sess.account = player[user].account;

                    if (!tumblereq(&currentaccount, &sess.account)) {
                        currentaccount = sess.account;
                        logaccount(&sess.account);
                    }

                    xanadu(&sess);

                    if (quitafteruser) {
                        if (interfaceinput) {
                            fprintf(interfaceinput, "%d~\n", QUIT);
                            fclose(interfaceinput);
                        }
                        writeenfilades();
                        closediskfile();
                        exit(0);
                    }
/* testforreservedness("main"); */
/* logfile = nulllog; */
                    nsessorcommand++;
                }
            }
        }

        leave(player, &n_players);
        mightbeblocked = true;
        new_players(player, &n_players, false, &sess);
        mightbeblocked = false;
    }
    return 0;
}

bool
establishprotocol(FILE *inp, FILE *outp)
{
    fprintf(stderr, "Entering establishprotocol()\n");

    metachar ch;

/* This is the metaprotocol for the time being */
    while ((ch = getc(inp)) != '\n')
        putc((ch > ' ' ? ch : '.'), stderr);

    while ((ch = getc(inp)) == '\n')
        putc(ch, stderr);

    fprintf(stderr, "establishprotocol: synced up\n");

    if (ch == 'P' && getc(inp) == '0' && getc(inp) == '~') {
        if (!feof(inp)) {              /* Don't send to a dead pipe */
            xuputstring("\nP0~", outp);
            fflush(outp);
            fprintf(stderr, "Leaving establishprotocol(), SUCCESS\n");
            return true;
        }
    } else {
        if (!feof(inp)) {              /* Don't send to a dead pipe */
            xuputstring("\nP?~", outp);
            fflush(outp);
        }
    }
    fprintf(stderr, "Leaving establishprotocol(), FAIL\n");
    return false;
}

void
frontenddied()
{
    longjmp(frontendeof, 1);
}

/* for linker until we get this cleaned up */
void
setmaximumsetupsize(Session *sess)
{
}

void
sourceunixcommand(Session *sess)
{
}

bool
decrementusers()
{
    if (n_players > 1) {
        player[user].wantsout = 1;
    }
    return (n_players > 1);
}
