/**********************************************************************
 * Copyright 2002 Jeff Rush <jrush@taupro.com>
 * Original Copyright 1979-2002 Udanax.com
 *
 * This file is part of the Udanax xanalogical storage system.
 *
 * Udanax is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * Udanax is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with Udanax; if not, write to the Free Software Foundation,
 * Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 **********************************************************************/

/**
 * @file  get1fe.cxx
 * @brief Udanax top-level input routines - front end version
 *
 * (to be defined)
 *
 **/

/* Modification History:
 * $Log: get1fe.cxx,v $
 * Revision 1.12  2002/05/28 03:58:42  jrush
 * Sources modified to comply with GPL licensing.
 *
 * Revision 1.11  2002/04/16 22:39:50  jrush
 * Converted many #defines into enumeration types instead, and adjusted
 * function prototypes accordingly.
 *
 * Revision 1.10  2002/04/12 11:48:50  jrush
 * Major reorganization of includes into a single base-include style.
 *
 * Revision 1.9  2002/04/10 18:01:54  jrush
 * Renamed class typeisa to IStreamAddr.
 *
 * Revision 1.8  2002/04/09 21:45:46  jrush
 * Renamed class 'tumbler' to 'Tumbler', for consistency with Python sources,
 * and changed typeisa from typedef to a subclass, in preparation for cleaning
 * up the type/class tree.
 *
 * Revision 1.7  2002/04/06 19:51:30  jrush
 * Renamed TRUE/FALSE constant use to the C++ standard of true/false.
 *
 * Revision 1.6  2002/04/06 17:05:57  jrush
 * Switched from referring to 'task' for a client connection to 'session',
 * and converted the typetask typedef/struct into a Session C++ class.
 *
 * Revision 1.5  2002/04/06 15:01:45  jrush
 * Changed INT to just 'int'.
 *
 * Revision 1.4  2002/02/14 10:08:25  jrush
 * Cleaned up source:
 *
 * 1. ran thru the indent tool to achieve a standard look,
 * 2. added structured comments at top for use with DOxygen reporting
 *    as well as CVS keywords,
 * 3. centralized prototypes in protos.h, removing incomplete ones,
 * 4. cleaned up use of bool/BOOLEAN type to suit C++ type,
 * 5. fixed initializer nesting in tumbler constants,
 * 6. converted select() int bits into ANSI fd_set type,
 * 7. added Makefile.am for use by automake.
 *
 */

#include "udanax.h"
#include "requests.h"

extern FILE *logfile;
extern FILE *nulllog;
extern FILE *reallog;
extern bool logstuff;
extern FILE *interfaceinput;

bool  gettumbler(Session * sess, Tumbler * tumblerptr);
bool  gettextset(Session * sess, typetextset * textsetptr);
bool  getspecset(Session * sess, typespecset * specsetptr);
bool  getcutseq(Session * sess, typecutseq * cutseqptr);
bool  getspanset(Session * sess, typespanset * spansetptr, typeitemid id);
bool  kluge();
bool  getnumber(Session * sess, int * numptr);
bool  getspan(Session * sess, typespan * spanptr, typeitemid id);
void  prompt(Session * sess, char *string);
bool  getfindlinksfromtothree(Session * sess, typespecset * fromvspecsetptr, typespecset * tovspecsetptr, typespecset * threevspecsetptr, typeispanset * homesetptr);
bool  validaccount(Session * sess, IStreamAddr * accountptr);

bool
getinsert(Session * sess, IStreamAddr * docisaptr, Tumbler * vsaptr, typetextset * textsetptr)
{
/* logfile = reallog; fprintf (logfile, "\nINSERT\n"); */
    logstuff = true;
    fprintf(interfaceinput, "%d~", INSERT);
    return (gettumbler(sess, docisaptr)
            && gettumbler(sess, vsaptr)
            && gettextset(sess, textsetptr));
/* 
 * if (! gettumbler (sess, docisaptr)) return (false);
 * fprintf(stderr,"\ndocid "); puttumbler(stderr,docisaptr); if (! gettumbler 
 * (sess, vsaptr)) return (false); fprintf(stderr,"\nvsa ");
 * puttumbler(stderr,vsaptr); fprintf(stderr,"\n"); if (! gettextset
 * (sess, textsetptr)) return (false); return (true); */
}

bool
getretrievedocvspanset(Session * sess, IStreamAddr * docisaptr)
{
/* fprintf (logfile, "\nRETRIEVEDOCVSPANSET\n"); */
    return (gettumbler(sess, docisaptr));
}

bool
getcopy(Session * sess, IStreamAddr * docisaptr, IStreamAddr * vsaptr, typespecset * localspecsetptr)
{
/* logfile = reallog; fprintf (logfile, "\nCOPY\n"); */
    logstuff = true;
    fprintf(interfaceinput, "%d~", COPY);
    return (gettumbler(sess, docisaptr)
            && gettumbler(sess, vsaptr)
            && getspecset(sess, localspecsetptr));
}

bool
getrearrange(Session * sess, IStreamAddr * docisaptr, typecutseq * cutseqptr)
{
/* logfile = reallog; fprintf (logfile, "\nREARRANGE\n"); */
    logstuff = true;
    fprintf(interfaceinput, "%d~", REARRANGE);
    return (gettumbler(sess, docisaptr)
            && getcutseq(sess, cutseqptr));
}

bool
getcreatelink(Session * sess, IStreamAddr * docisaptr, typespecset * fromspecsetptr, typespecset * tospecsetptr,
              typespecset * threespecsetptr)
{
    logstuff = true;
    fprintf(interfaceinput, "%d~", CREATELINK);
    return (gettumbler(sess, docisaptr)
            && getspecset(sess, fromspecsetptr)
            && getspecset(sess, tospecsetptr)
            && getspecset(sess, threespecsetptr));
}

bool
getretrievev(Session * sess, typespecset * specsetptr)
{
/* fprintf (logfile, "\nRETRIEVEV\n"); */

    if (getspecset(sess, specsetptr)) {
        return (true);
    } else {
        return (false);
    }
}

bool
getfindnumoflinksfromtothree(Session * sess, typespecset * fromvspecsetptr, typespecset * tovspecsetptr,
                             typespecset * threevspecsetptr, typeispanset * homesetptr)
{
    return (getfindlinksfromtothree(sess, fromvspecsetptr, tovspecsetptr, threevspecsetptr, homesetptr));
}

bool
getfindlinksfromtothree(Session * sess, typespecset * fromvspecsetptr, typespecset * tovspecsetptr,
                        typespecset * threevspecsetptr, typeispanset * homesetptr)
{
    return (getspecset(sess, fromvspecsetptr)
            && getspecset(sess, tovspecsetptr)
            && getspecset(sess, threevspecsetptr)
            && getspanset(sess, homesetptr, ISPANID) && kluge());
}

bool
getfindnextnlinksfromtothree(Session * sess, typespecset * fromvspecsetptr, typespecset * tovspecsetptr,
                             typespecset * threevspecsetptr, typeispanset * homesetptr, IStreamAddr * lastlinkptr,
                             int * nptr)
{
    return getfindlinksfromtothree(sess, fromvspecsetptr, tovspecsetptr, threevspecsetptr, homesetptr)
            && gettumbler(sess, lastlinkptr)
            && getnumber(sess, nptr);
}

bool
getshowrelationof2versions(Session * sess, typespecset * version1ptr, typespecset * version2ptr)
{
    return (getspecset(sess, version1ptr)
            && getspecset(sess, version2ptr));
}

/* createnewdocument - no get routine */
void
getcreatenewdocument()
{
    logstuff = true;
    fprintf(interfaceinput, "%d~", CREATENEWDOCUMENT);
}

bool
getdeletevspan(Session * sess, IStreamAddr * docisaptr, typevspan * vspanptr)
{
/* logfile = reallog; fprintf (logfile, "\nDELETEVSPAN\n"); */
    logstuff = true;
    fprintf(interfaceinput, "%d~", DELETEVSPAN);
    return (gettumbler(sess, docisaptr)
            && getspan(sess, vspanptr, VSPANID));
}

bool
getcreatenewversion(Session * sess, IStreamAddr * docisaptr)
{
/* logfile = reallog; fprintf (logfile, "\nCREATENEWVERSION\n"); */
    logstuff = true;
    fprintf(interfaceinput, "%d~", CREATENEWVERSION);
    return (gettumbler(sess, docisaptr));
}

bool
getretrievedocvspan(Session * sess, IStreamAddr * docisaptr)
{
/* fprintf (logfile, "\nRETRIEVEDOCVSPAN\n"); */
    return (gettumbler(sess, docisaptr));
}

void
setdebug(Session * sess)
{
    getnumber(sess, &debug);
}

/* disk exit */

/* show enfilades */

bool
getfollowlink(Session * sess, IStreamAddr * linkisaptr, int * whichendptr)
{
/* fprintf (logfile, "\nFOLLOWLINK\n"); */
    return (getnumber(sess, whichendptr)
            && gettumbler(sess, linkisaptr));
}

/* examine */

/* source unix command */

bool
getfinddocscontaining(Session * sess, typespecset * specsetptr)
{
/* fprintf (logfile, "\nFINDDOCSCONTAINING\n"); */
    return (getspecset(sess, specsetptr));
}

bool
getretrieveendsets(Session * sess, typespecset * specsetptr)
{
/* fprintf (logfile, "\nRETRIEVEENDSETS\n"); */
    return (getspecset(sess, specsetptr));
}

bool
kluge()
{
/* fclose (reallog); reallog = fopen("xueditlog","a"); */ return (true);
}

void
playwithalloc(Session * sess)
{
    prompt(sess, "playwithalloc\n");
    lookatalloc();
}

#include "players.h"

bool
getxaccount(Session * sess, IStreamAddr * accountptr)
{
    logstuff = true;
    if (interfaceinput)
        fprintf(interfaceinput, "%d~", XACCOUNT);

    gettumbler(sess, accountptr)
            && validaccount(sess, accountptr);
    player[user].account = *accountptr;
    sess->account = *accountptr;
    return (true);
}

bool
getcreatenode_or_account(Session * sess, Tumbler * tp)
{
    logstuff = true;
    if (interfaceinput)
        fprintf(interfaceinput, "%d~", CREATENODE_OR_ACCOUNT);
    gettumbler(sess, tp);
    return (true);

}

void
logaccount(Tumbler * tp)
{
    if (interfaceinput) {
        fprintf(interfaceinput, "%d~", XACCOUNT);
        puttumbler(interfaceinput, tp);
    }
}

bool
getclose(Session * sess, Tumbler * tp)
{
    logstuff = true;
    if (interfaceinput)
        fprintf(interfaceinput, "%d~", CLOSE);
    gettumbler(sess, tp);
    return (true);
}

bool
getopen(Session * sess, Tumbler * tp, int *typep, int *modep)
{
    logstuff = true;
    if (interfaceinput)
        fprintf(interfaceinput, "%d~", OPEN);
    gettumbler(sess, tp);
    getnumber(sess, typep);
    getnumber(sess, modep);
    return (*typep != NOBERTREQUIRED);
}
