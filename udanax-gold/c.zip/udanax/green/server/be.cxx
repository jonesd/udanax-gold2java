/**********************************************************************
 * Copyright 2002 Jeff Rush <jrush@taupro.com>
 * Original Copyright 1979-2002 Udanax.com
 *
 * This file is part of the Udanax xanalogical storage system.
 *
 * Udanax is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * Udanax is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with Udanax; if not, write to the Free Software Foundation,
 * Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 **********************************************************************/

/**
 * @file  be.cxx
 * @brief Udanax main program: backend version
 *
 * (to be defined)
 *
 **/

/* Modification History:
 * $Log: be.cxx,v $
 * Revision 1.12  2002/07/26 04:33:47  jrush
 * Replaced gerror() with assert()
 *
 * Revision 1.11  2002/05/28 03:58:42  jrush
 * Sources modified to comply with GPL licensing.
 *
 * Revision 1.10  2002/04/12 11:48:50  jrush
 * Major reorganization of includes into a single base-include style.
 *
 * Revision 1.9  2002/04/09 21:45:46  jrush
 * Renamed class 'tumbler' to 'Tumbler', for consistency with Python sources,
 * and changed typeisa from typedef to a subclass, in preparation for cleaning
 * up the type/class tree.
 *
 * Revision 1.8  2002/04/07 14:04:37  jrush
 * Add ptr to Session to checkforopen() and isthisusersdocument() so that we
 * have session information available to make the decision.
 *
 * Revision 1.7  2002/04/06 19:51:30  jrush
 * Renamed TRUE/FALSE constant use to the C++ standard of true/false.
 *
 * Revision 1.6  2002/04/06 17:05:57  jrush
 * Switched from referring to 'task' for a client connection to 'session',
 * and converted the typetask typedef/struct into a Session C++ class.
 *
 * Revision 1.5  2002/04/06 15:01:44  jrush
 * Changed INT to just 'int'.
 *
 * Revision 1.4  2002/02/14 10:08:25  jrush
 * Cleaned up source:
 *
 * 1. ran thru the indent tool to achieve a standard look,
 * 2. added structured comments at top for use with DOxygen reporting
 *    as well as CVS keywords,
 * 3. centralized prototypes in protos.h, removing incomplete ones,
 * 4. cleaned up use of bool/BOOLEAN type to suit C++ type,
 * 5. fixed initializer nesting in tumbler constants,
 * 6. converted select() int bits into ANSI fd_set type,
 * 7. added Makefile.am for use by automake.
 *
 */

#include <stdlib.h>
#include <time.h>
#include "udanax.h"
#include "players.h"

#define MAX_PLAYERS 5
int user = 0;
PLAYER player[MAX_PLAYERS];
extern int errno;

FILE *logfile;
FILE *nulllog;
FILE *reallog;
char outputbuffer[BUFSIZ];
char inputbuffer[BUFSIZ];
bool logstuff;
FILE *interfaceinput;
extern FILE *febelog;
extern bool firstputforrequest;
Session *sessx;
int backenddaemon;       /* backend version */
Tumbler defaultaccount = { 0, 0, 0, 0, { 1, 1, 0, 1, 0, 0, 0, 0, 0, 0, 0 } };        /* 1.1.0.1 */

extern bool getrequest(Session *sess, typerequest *requestptr);
extern void sendresultoutput(Session * session);
extern char pullc(Session *sess);
extern void xuputstring(char *string, FILE * fd);
extern void processrcfile();

void
xanadu(Session *sess)
{
    typerequest request;

    if (febelog && febelog != nulllog)
        fprintf(febelog, "\nfe:\n");
    firstputforrequest = true;
    logstuff = false;
    if (getrequest(sess, &request)) {
        (*requestfns[request]) (sess);
        sendresultoutput(sess);
    } else {
        sess->inp = stdin;
    }
    sess->free();
/* lookatalloc(); */
    if (interfaceinput && interfaceinput != nulllog)
        fflush(interfaceinput);
    logstuff = false;
}

bool
establishprotocol(FILE *inp, FILE *outp)
{
    char ch;
    Session tempsess;

    if (febelog && febelog != nulllog)
        fprintf(febelog, "fe:\n");
    firstputforrequest = true;

/* This is the metaprotocol for the time being */

    tempsess.inp = inp;
    tempsess.outp = outp;
    tempsess.errp = stderr;

    while ((ch = pullc(&tempsess)) != '\n') ;
    while ((ch = pullc(&tempsess)) == '\n') ;
    if (ch == 'P' && pullc(&tempsess) == '0' && pullc(&tempsess) == '~') {
        xuputstring("\nP0~", tempsess.outp);
        sendresultoutput(&tempsess);
        return true;
    } else {
        xuputstring("\nP?~", tempsess.outp);
        sendresultoutput(&tempsess);
        return false;
    }
}

int
main(int argc, char *argv[])
{
    Session sess;
    char buf[100];
    //UNUSED FILE *fd;
    struct tm *local;
    long clock;

    sessx = &sess;
    febelog = interfaceinput = reallog = logfile = nulllog = fopen("/dev/null", "a");

    clock = time(0);
    local = localtime(&clock);
    sprintf(buf, "ln%d.%d.%d:%d", local->tm_mon + 1, local->tm_mday, local->tm_hour, local->tm_min);
/* 
 * #ifndef DISTRIBUTION
 * sprintf(buf,"febe%d.%d.%d:%d",local->tm_mon+1,local->tm_mday,local->tm_hour,local->tm_min);
 * febelog = fopen(buf, "w"); #endif */

    freopen("backenderror", "w", stderr);       /* CHANGE THIS ?? */
    setbuf(stderr, NULL);
    processrcfile();

    setbuf(stdin, inputbuffer);
    setbuf(stdout, outputbuffer);

    if (!establishprotocol(stdin, stdout))
        exit(1);

    debug = false;

    init(1);
    //now uses a ctor:: inittask(&sess);

    initmagicktricks();

    movetumbler(&defaultaccount, &sess.account);

    for (;;) {
        nsessorcommand++;
        xanadu(&sess);
/* testforreservedness ("main"); */
        logfile = nulllog;
    }
/* lookatalloc(); */
    return 0;
}

void
frontenddied()
{
    fprintf(stderr, "The frontend apparently has died.\n");
    diskexit();
    assert(0); // The frontend died
}

/* for linker until we get this cleaned up */
void
setmaximumsetupsize(Session *sess)
{
}

void
sourceunixcommand(Session *sess)
{
}

bool
decrementusers()
{
    return false;
}

bool
isthisusersdocument(Session *sess, Tumbler *tp)
{
    return tumbleraccounteq(tp, &sess->account);
}
