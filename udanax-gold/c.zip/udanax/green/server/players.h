/**********************************************************************
 * Copyright 2002 Jeff Rush <jrush@taupro.com>
 * Original Copyright 1979-2002 Udanax.com
 *
 * This file is part of the Udanax xanalogical storage system.
 *
 * Udanax is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * Udanax is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with Udanax; if not, write to the Free Software Foundation,
 * Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 **********************************************************************/

/**
 * @file  players.h
 * @brief ???
 *
 * (to be defined)
 *
 **/

/* Modification History:
 * $Log: players.h,v $
 * Revision 1.2  2002/05/28 03:58:42  jrush
 * Sources modified to comply with GPL licensing.
 *
 * Revision 1.1  2002/04/12 09:38:24  jrush
 * Moved include/players.h to server/players.h
 *
 * Revision 1.7  2002/04/10 18:01:54  jrush
 * Renamed class typeisa to IStreamAddr.
 *
 * Revision 1.6  2002/04/09 21:45:46  jrush
 * Renamed class 'tumbler' to 'Tumbler', for consistency with Python sources,
 * and changed typeisa from typedef to a subclass, in preparation for cleaning
 * up the type/class tree.
 *
 * Revision 1.5  2002/04/06 15:00:34  jrush
 * Changed INT to just 'int'.
 *
 * Revision 1.4  2002/02/14 05:40:42  jrush
 * Cleaned up source:
 *
 * 1. ran thru the indent tool to achieve a standard look,
 * 2. added structured comments at top for use with DOxygen reporting
 *    as well as CVS keywords,
 * 3. added #ifndef/#defines to prevent duplicate inclusions,
 * 4. insured all struct/union defs have names,
 * 5. centralized prototypes in protos.h, removing incomplete ones,
 * 6. cleaned up use of bool/BOOLEAN type to suit C++ type,
 * 7. fixed initializer nesting in tumbler constants.
 *
 */

#ifndef __UDANAX_PLAYERS_H__
#define __UDANAX_PLAYERS_H__

#include <sys/types.h> // For fd_set

/* 
 * ** A structure is maintained with information on each player. */

typedef struct _player {
    char         *name;      /* Player's name */
    int           userid;    /* player's user id number */
    int           wantsout;  /* Quit after this hand? */
    int           socket;    /* To communicate with player on */
    FILE         *inp;
    FILE         *outp;
    IStreamAddr   account;   /* xanadu host and account tumbler */
} PLAYER;

extern PLAYER player[];

extern int n_players;   /* current number of players (including computer) */

extern int fdtoplayer[32];
extern fd_set inputfds;
extern int nfds;
extern int user;

#endif /* !__UDANAX_PLAYERS_H__*/
