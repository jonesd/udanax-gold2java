/**********************************************************************
 * Copyright 2002 Jeff Rush <jrush@taupro.com>
 * Original Copyright 1979-2002 Udanax.com
 *
 * This file is part of the Udanax xanalogical storage system.
 *
 * Udanax is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * Udanax is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with Udanax; if not, write to the Free Software Foundation,
 * Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 **********************************************************************/

/**
 * @file  xumain.cxx
 * @brief Udanax main program - stand alone version
 *
 * (to be defined)
 *
 **/

/* Modification History:
 * $Log: xumain.cxx,v $
 * Revision 1.14  2002/07/26 04:33:47  jrush
 * Replaced gerror() with assert()
 *
 * Revision 1.13  2002/05/28 03:58:42  jrush
 * Sources modified to comply with GPL licensing.
 *
 * Revision 1.12  2002/04/12 11:48:51  jrush
 * Major reorganization of includes into a single base-include style.
 *
 * Revision 1.11  2002/04/10 18:01:54  jrush
 * Renamed class typeisa to IStreamAddr.
 *
 * Revision 1.10  2002/04/09 21:45:47  jrush
 * Renamed class 'tumbler' to 'Tumbler', for consistency with Python sources,
 * and changed typeisa from typedef to a subclass, in preparation for cleaning
 * up the type/class tree.
 *
 * Revision 1.9  2002/04/07 14:04:37  jrush
 * Add ptr to Session to checkforopen() and isthisusersdocument() so that we
 * have session information available to make the decision.
 *
 * Revision 1.8  2002/04/06 20:42:50  jrush
 * Switch from sess->alloc() style to new(sess) Object parameterized allocator.
 *
 * Revision 1.7  2002/04/06 19:51:30  jrush
 * Renamed TRUE/FALSE constant use to the C++ standard of true/false.
 *
 * Revision 1.6  2002/04/06 17:05:57  jrush
 * Switched from referring to 'task' for a client connection to 'session',
 * and converted the typetask typedef/struct into a Session C++ class.
 *
 * Revision 1.5  2002/04/06 15:01:45  jrush
 * Changed INT to just 'int'.
 *
 * Revision 1.4  2002/02/14 10:08:26  jrush
 * Cleaned up source:
 *
 * 1. ran thru the indent tool to achieve a standard look,
 * 2. added structured comments at top for use with DOxygen reporting
 *    as well as CVS keywords,
 * 3. centralized prototypes in protos.h, removing incomplete ones,
 * 4. cleaned up use of bool/BOOLEAN type to suit C++ type,
 * 5. fixed initializer nesting in tumbler constants,
 * 6. converted select() int bits into ANSI fd_set type,
 * 7. added Makefile.am for use by automake.
 *
 */

#include <errno.h>
#include <unistd.h>
#include <stdlib.h>
#include <string.h>
#include "udanax.h"
#include "players.h"

#define MAX_PLAYERS 5
int user = 0;
PLAYER player[MAX_PLAYERS];

extern int errno;
FILE *febelog = NULL;
extern bool isxumain;
bool maximumsetupsizehasbeenhit;
int maximumsetupsize;
bool logstuff;
Session *sessx;
FILE *interfaceinput = NULL;
int backenddaemon;       /* backend version */

extern bool  getrequest(Session * sess, typerequest * requestptr);
extern void  processrcfile();
extern void  prompt(Session * sess, char *string);
extern void  putcreatenewdocument(Session * sess, IStreamAddr * newdocisaptr);

/* "xanadu" is the backend request dispatcher */
void
xanadu(Session *sess)
{
    typerequest request;

    logstuff = false;
    if (getrequest(sess, &request))
        (*requestfns[request]) (sess);
/* 
 * else sess->inp = stdin; */
    logstuff = false;
    sess->free();
}

int
main(int argc, char *argv[])
{                                      /* inside temporary */
    Session sess;
    //UNUSED FILE *fd;
    //UNUSED int i = 0;

    isxumain = true;

    setbuf(stderr, NULL);
    debug = false;
    processrcfile();
    init(0);
    //now uses a ctor:: inittask(&sess);
/* 
 * if (fd = fopen ("xusetup", "r")) sess.inp = fd; errno = 0; */
    initmagicktricks();
    sessx = &sess;
    sess.getaccount(&sess.account);
    for (;;) {
        nsessorcommand++;
/* 
 * fprintf(stderr,"%d ",i++); */
        xanadu(&sess);
        testforreservedness("main");
/* 
 * if (maximumsetupsizehasbeenhit) { fprintf (stderr,"Setup has reached size
 * limit.\n"); diskexit (); } */
    }
    return 0;
}

bool
setmaximumsetupsize(Session * sess)
{
    char buff[100];

    fprintf(sess->outp, "maximumsetupsize = ? ");
    maximumsetupsize = atoi(fgets(buff, 100, sess->inp));
    return true;
}

bool
getmuchtext(Session * sess, typetext * textptr)
{                                      /* 
                                        * * this code stolen from get2.d which could * use some improvement but be
                                        * careful */
    int numinstring = 0;
    int temp;

    numinstring = temp = 0;
    for (;;) {
        if (!fgets(textptr->string + numinstring, GRANTEXTLENGTH - numinstring, sess->inp)) {
            temp = 0;
            break;
        }
        temp = strlen(textptr->string + numinstring);
        if (temp < 1) {
            break;
        }
        numinstring += temp;
        if (numinstring >= GRANTEXTLENGTH) {
            break;
        }
    }

    if (numinstring > GRANTEXTLENGTH)
        assert(0); // got too much in getmuchtext

    if (numinstring == 0) {
        textptr->length = 0;
        return false;
    }

    textptr->length = numinstring;
    textptr->itemid = TEXTID;
    return true;
}

void
sourceunixcommand(Session *sess)
{
    char unixcommand[132];
    char file[64];
    IStreamAddr docisa;
    typetext *textsetptr;

    FILE *infile;
    int count, lines, bugger;
    int status;

    count = 0;
    lines = 0;
    bugger = debug;

    sprintf(file, "xum%d", getpid());
    prompt(sess, " Enter unix command : ");
    fgets(unixcommand, 132, sess->inp);

    if (unixcommand[strlen(unixcommand) - 1] == '\n')
        unixcommand[strlen(unixcommand) - 1] = '\0';

    strcat(unixcommand, " >");
    strcat(unixcommand, file);

    if ((status = system(unixcommand)) != 0) {
        fprintf(stderr, "Exit status = %d\n", status);
        perror("Udanax(system call 0)");
// return false;
    }
    if (debug) {
        prompt(sess, "lines until debug : ");
        count = atoi(fgets(unixcommand, 132, sess->inp));
        if (count)
            debug = 0;
    }

    docreatenewdocument(sess, &docisa);
/* testforreservedness ("eatunixcommand createdoc"); */
    putcreatenewdocument(sess, &docisa);

    infile = sess->inp;
    if (!(sess->inp = fopen(file, "r"))) {
        perror("xanadu");
        fprintf(stderr, "Couldn't open %s\n", file);
        assert(0); // Awful badness in sourceunixfile
    }
    while ((textsetptr = new(sess) typetext) != NULL
//    while ((textsetptr = (typetext *) sess->alloc(sizeof(typetext)))
           && (getmuchtext(sess, textsetptr) || (textsetptr->length > 0))) {
        if (debug)
            fprintf(stderr, "line # %d\n", lines);
        textsetptr->next = NULL;
        textsetptr->itemid = TEXTID;
        textsetptr->length = strlen(textsetptr->string);
        doappend(sess, &docisa, textsetptr);
/* testforreservedness ("eatunixcommand loop"); */
        ++lines;
        sess->free();
        if (count && --count == 0)
            debug = bugger;
    }
    fclose(sess->inp);
    unlink(file);
    sess->inp = infile;

    //NOBODY CARES  return true;
}

bool
decrementusers()
{
    return (false);
}

bool
isthisusersdocument(Session *sess, Tumbler * tp)
{
    return tumbleraccounteq(tp, &sess->account);
}
