/**********************************************************************
 * Copyright 2002 Jeff Rush <jrush@taupro.com>
 * Original Copyright 1979-2002 Udanax.com
 *
 * This file is part of the Udanax xanalogical storage system.
 *
 * Udanax is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * Udanax is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with Udanax; if not, write to the Free Software Foundation,
 * Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 **********************************************************************/

/**
 * @file  put.cxx
 * @brief Udanax output routines - no front end version
 *
 * (to be defined)
 *
 **/

/* Modification History:
 * $Log: put.cxx,v $
 * Revision 1.12  2002/05/28 03:58:42  jrush
 * Sources modified to comply with GPL licensing.
 *
 * Revision 1.11  2002/04/12 11:48:50  jrush
 * Major reorganization of includes into a single base-include style.
 *
 * Revision 1.10  2002/04/10 18:01:54  jrush
 * Renamed class typeisa to IStreamAddr.
 *
 * Revision 1.9  2002/04/09 21:45:47  jrush
 * Renamed class 'tumbler' to 'Tumbler', for consistency with Python sources,
 * and changed typeisa from typedef to a subclass, in preparation for cleaning
 * up the type/class tree.
 *
 * Revision 1.8  2002/04/06 19:51:30  jrush
 * Renamed TRUE/FALSE constant use to the C++ standard of true/false.
 *
 * Revision 1.7  2002/04/06 17:05:57  jrush
 * Switched from referring to 'task' for a client connection to 'session',
 * and converted the typetask typedef/struct into a Session C++ class.
 *
 * Revision 1.6  2002/04/06 15:01:45  jrush
 * Changed INT to just 'int'.
 *
 * Revision 1.5  2002/04/02 17:12:52  jrush
 * Pure cosmetic changes.
 *
 * Revision 1.4  2002/02/14 10:08:25  jrush
 * Cleaned up source:
 *
 * 1. ran thru the indent tool to achieve a standard look,
 * 2. added structured comments at top for use with DOxygen reporting
 *    as well as CVS keywords,
 * 3. centralized prototypes in protos.h, removing incomplete ones,
 * 4. cleaned up use of bool/BOOLEAN type to suit C++ type,
 * 5. fixed initializer nesting in tumbler constants,
 * 6. converted select() int bits into ANSI fd_set type,
 * 7. added Makefile.am for use by automake.
 *
 */

#include <unistd.h>
#include "udanax.h"

#define MINEXP  -10

void  putnum(FILE * outfile, int num);
void  putitem(Session * sess, typeitem * itemptr);
void  putspan(Session * sess, typespan * spanptr);
void  puttext(Session * sess, typetext * textptr);
void  putspanpair(Session * sess, typespanpair * spanpair);

void
prompt(Session * sess, char *string)
{
    fprintf(sess->outp, "%s", string);
}

void
error(Session * sess, char *string)
{
    fprintf(sess->errp, "%s", string);
}

void
puttumbler(FILE * outfile, Tumbler * tumblerptr)
{
    int i, place;

    if (!tumblercheck(tumblerptr) || tumblerptr->exp < MINEXP) {
        dumptumbler(tumblerptr);
        return;
    }

    if (tumblerptr->sign)
        fprintf(outfile, "-");

    for (i = tumblerptr->exp; i < 0; ++i)
        fprintf(outfile, "0.");

    place = NPLACES;
    do {
        --place;
    } while (place > 0 && tumblerptr->mantissa[place] == 0);

    for (i = 0; i <= place; ++i) {
        putnum(outfile, tumblerptr->mantissa[i]);
        if (i < place)
            putc('.', outfile);
    }
}

void
putnum(FILE * outfile, int num)
{
    fprintf(outfile, "%d", num);
}

void
putisa(Session * sess, IStreamAddr * isaptr)
{
    puttumbler(sess->outp, isaptr);
}

void
putitemset(Session * sess, typeitemset itemset)
{
    if (itemset == NULL) {
        fprintf(sess->outp, "  \nitemset empty\n");
        return;
    }
    for (; itemset; itemset = (typeitemset) ((typeitemheader *) itemset)->next) {
        putitem(sess, itemset);
        if (!
            (((typeitemheader *) itemset)->next && ((typeitemheader *) itemset)->itemid == TEXTID
             && ((typeitemheader *) itemset)->next->itemid == TEXTID))
            putc('\n', sess->outp);
    }
}

void
putitem(Session * sess, typeitem * itemptr)
{
    switch (((typeitemheader *) itemptr)->itemid) {
    case ISPANID:
        fprintf(sess->outp, "  ispan\n");
        putspan(sess, (typespan *) itemptr);
        break;
    case VSPANID:
        fprintf(sess->outp, "  vspan\n");
        putspan(sess, (typespan *) itemptr);
        break;
    case VSPECID:
        fprintf(sess->outp, "document: ");
        putisa(sess, &((typevspec *) itemptr)->docisa);
        fprintf(sess->outp, "\nspans");
        putitemset(sess, (typeitem *) ((typevspec *) itemptr)->vspanset);
        break;
    case TEXTID:
        puttext(sess, (typetext *) itemptr);
        break;
    case LINKID:
        putisa(sess, &((typelink *) itemptr)-> /* link */ address);
        break;

#ifndef DISTRIBUTION
    case SPORGLID:
        fprintf(sess->outp, "sporgl address: ");
        putisa(sess, &((typesporgl *) itemptr)->sporgladdress);

        fprintf(sess->outp, "\n   sporgl origin: ");
        putisa(sess, (IStreamAddr *) &((typesporgl *) itemptr)->sporglorigin);

        fprintf(sess->outp, "\n   sporgl width: ");
        putisa(sess, (IStreamAddr *) &((typesporgl *) itemptr)->sporglwidth);

        fprintf(sess->outp, "\n");
        break;
#endif
    default:
        error(sess, "illegal item id for putitem ");
        fprintf(sess->outp, "%x  %d\nd", (int) itemptr, ((typeitemheader *) itemptr)->itemid);
        return;
    }
}

void
putspan(Session * sess, typespan * spanptr)
{
    fprintf(sess->outp, "   span address: ");
    puttumbler(sess->outp, &spanptr->stream);
    fprintf(sess->outp, "\n   span width: ");
    puttumbler(sess->outp, &spanptr->width);
}

void
puttext(Session * sess, typetext * textptr)
{
    write(fileno(sess->outp), textptr->string, textptr->length);
}

void
putspanpairset(Session * sess, typespanpairset spanpairset)
{
    if (!spanpairset)
        fprintf(sess->outp, "NULL relationship\n");
    else
        for (; spanpairset; spanpairset = spanpairset->nextspanpair)
            putspanpair(sess, spanpairset);
}

void
putspanpair(Session * sess, typespanpair * spanpair)
{
    fprintf(sess->outp, "start1:  ");
    puttumbler(sess->outp, &spanpair->stream1);
    fprintf(sess->outp, "\nstart2:  ");
    puttumbler(sess->outp, &spanpair->stream2);
    fprintf(sess->outp, "\nwidth:  ");
    puttumbler(sess->outp, &spanpair->widthofspan);
    fprintf(sess->outp, "\n");
}

void
putcreatelink(Session * sess, IStreamAddr * istreamptr)
{
    fprintf(sess->outp, "\nlink made: ");
    putisa(sess, istreamptr);
    fprintf(sess->outp, "\n");
}

void
putfollowlink(Session * sess, typespecset specset)
{
    fprintf(sess->outp, "link endset is:\n");
    putitemset(sess, (typeitem *) specset);
}

void
putretrievedocvspanset(Session * sess, typespanset * spansetptr)
{
    fprintf(sess->outp, "docvspans are:\n");
    putitemset(sess, (typeitem *) *spansetptr);
}

void
putretrievedocvspan(Session * sess, typespan * vspanptr)
{
    fprintf(sess->outp, "docvspan is:\n");
    putspan(sess, vspanptr);
}

void
putretrievev(Session * sess, typevstuffset * vstuffsetptr)
{
    fprintf(sess->outp, "\nvstuff is:\n");
    putitemset(sess, (typeitem *) *vstuffsetptr);
}

void
putfindlinksfromtothree(Session * sess, typelinkset linkset)
{
    fprintf(sess->outp, "\nlinks\n");
    putitemset(sess, (typeitem *) linkset);
}

void
putfindnumoflinksfromtothree(Session * sess, int num)
{
    fprintf(sess->outp, "\nnumber of links: %d\n", num);
}

void
putfindnextnlinksfromtothree(Session * sess, int n, typelinkset nextlinkset)
{
    fprintf(sess->outp, "next number of links: %d\n", n);
    putitemset(sess, (typeitem *) nextlinkset);
}

void
putshowrelationof2versions(Session * sess, typespanpairset relation)
{
    fprintf(sess->outp, "relation between versions:\n");
    putspanpairset(sess, relation);
}

void
putcreatenewdocument(Session * sess, IStreamAddr * newdocisaptr)
{
    fprintf(sess->outp, "new document: ");
    putisa(sess, newdocisaptr);
    fprintf(sess->outp, "\n\n");
}

void
putcreatenewversion(Session * sess, IStreamAddr * newdocisaptr)
{
    fprintf(sess->outp, "new version: ");
    putisa(sess, newdocisaptr);
    fprintf(sess->outp, "\n");
}

void
putfinddocscontaining(Session * sess, typeitemset addressset)
{
    fprintf(sess->outp, "\ndocuments\n");
    putitemset(sess, addressset);
}

void
putretrieveendsets(Session * sess, typespecset fromset, typespecset toset, typespecset threeset)
{
    fprintf(sess->outp, "\nfromset\n");
    putitemset(sess, (typeitem *) fromset);
    fprintf(sess->outp, "\ntoset\n");
    putitemset(sess, (typeitem *) toset);
    fprintf(sess->outp, "\nthreeset\n");
    putitemset(sess, (typeitem *) toset);
}

void
putinsert(Session * sess)
{
}

void
putcopy(Session * sess)
{
}

void
putdeletevspan(Session * sess)
{
}

void
putrearrange(Session * sess)
{
}

void
putrequestfailed(Session * sess)
{
    fprintf(sess->outp, "?\n");
}

bool
kluge()
{
    return (true);
}

void
putxaccount(Session * sess)
{
    //UNUSED return (true);
}

void
putcreatenode_or_account(Session * sess, Tumbler * tp)
{
    puttumbler(sess->outp, tp);
    //UNUSED return (true);
}

void
putopen(Session * sess, Tumbler * tp)
{
    puttumbler(sess->outp, tp);
    //UNUSED return (true);
}

void
putclose(Session * sess)
{
    //UNUSED return (true);
}

void
putquitxanadu(Session * sess)
{
    fprintf(sess->outp, "Good Bye.\n");
    //UNUSED return (true);
}
