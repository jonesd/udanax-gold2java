/**********************************************************************
 * Copyright 2002 Jeff Rush <jrush@taupro.com>
 * Original Copyright 1979-2002 Udanax.com
 *
 * This file is part of the Udanax xanalogical storage system.
 *
 * Udanax is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * Udanax is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with Udanax; if not, write to the Free Software Foundation,
 * Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 **********************************************************************/

/**
 * @file  get2.cxx
 * @brief Udanax input routines - file #2 - no front end version
 *
 * (to be defined)
 *
 **/

/* Modification History:
 * $Log: get2.cxx,v $
 * Revision 1.13  2002/05/28 03:58:42  jrush
 * Sources modified to comply with GPL licensing.
 *
 * Revision 1.12  2002/04/16 22:39:50  jrush
 * Converted many #defines into enumeration types instead, and adjusted
 * function prototypes accordingly.
 *
 * Revision 1.11  2002/04/12 11:48:50  jrush
 * Major reorganization of includes into a single base-include style.
 *
 * Revision 1.10  2002/04/10 18:01:54  jrush
 * Renamed class typeisa to IStreamAddr.
 *
 * Revision 1.9  2002/04/09 21:45:46  jrush
 * Renamed class 'tumbler' to 'Tumbler', for consistency with Python sources,
 * and changed typeisa from typedef to a subclass, in preparation for cleaning
 * up the type/class tree.
 *
 * Revision 1.8  2002/04/06 20:42:50  jrush
 * Switch from sess->alloc() style to new(sess) Object parameterized allocator.
 *
 * Revision 1.7  2002/04/06 17:05:57  jrush
 * Switched from referring to 'task' for a client connection to 'session',
 * and converted the typetask typedef/struct into a Session C++ class.
 *
 * Revision 1.6  2002/04/06 15:01:45  jrush
 * Changed INT to just 'int'.
 *
 * Revision 1.5  2002/04/02 17:38:46  jrush
 * Purely cosmetic.
 *
 * Revision 1.4  2002/02/14 10:08:25  jrush
 * Cleaned up source:
 *
 * 1. ran thru the indent tool to achieve a standard look,
 * 2. added structured comments at top for use with DOxygen reporting
 *    as well as CVS keywords,
 * 3. centralized prototypes in protos.h, removing incomplete ones,
 * 4. cleaned up use of bool/BOOLEAN type to suit C++ type,
 * 5. fixed initializer nesting in tumbler constants,
 * 6. converted select() int bits into ANSI fd_set type,
 * 7. added Makefile.am for use by automake.
 *
 */

#include <string.h>
#include <unistd.h>
#include <stdlib.h>
#include <ctype.h>
#include "udanax.h"

bool  getspecset(Session * sess, typespecset * specsetptr);
void  prompt(Session * sess, char *string);
bool  getisa(Session * sess, IStreamAddr * isaptr);
bool  getvsa(Session * sess, Tumbler * vsaptr);
bool  gettextset(Session * sess, typetextset * textsetptr);
bool  getnumber(Session * sess, int * numptr);
bool  getcutseq(Session * sess, typecutseq * cutseqptr);
bool  getspanset(Session * sess, typespanset * spansetptr, typeitemid id);
bool  getspan(Session * sess, typespan * spanptr, typeitemid id);
bool  gettumbler(Session * sess, Tumbler * tumblerptr);
bool  validaccount(Session * sess, IStreamAddr * accountptr);
void  error(Session * sess, char *string);
bool  gettext(Session * sess, typetext * textptr);
bool  getvspec(Session * sess, typevspec * vspecptr);
bool  validrequest(Session * sess, typerequest request);

/**
 * @function getnum
 * @brief parse an unsigned integer value from the input stream
 *
 * (to be defined)
 *
 **/

bool
getnum(Session *sess, int *numptr)
{                                      /* inside temporary */
    metachar c;
    int num;

    bool flag = false;                 /* should check for minus */
    for (num = 0; (c = getc(sess->inp)) != EOF && isdigit(c);) {
        num = num * 10 + c - '0';
        flag = true;
    }

    if (!flag) {
        fprintf(sess->errp, "no number\n");
#ifndef DISTRIBUTION
        if (c == '?' || c == 'h') {
            system("cat /usr3/xu/requests.j");
        } else if (c == '!') {
            system("csh");
        }
#endif
    } else {
        ungetc(c, sess->inp);
        *numptr = num;
    }
    return flag;
}

/**
 * @function eatchar
 * @brief if specified char is at front of input stream, grab and discard; else leave it alone
 *
 * (to be defined)
 *
 **/

bool
eatchar(Session *sess, char c)
{
    metachar m;

    if ((m = getc(sess->inp)) != c) {
        ungetc(m, sess->inp);
        return false;
    } else
        return true;
}

bool
needchar(Session * sess, char c)
{
    if (!eatchar(sess, c)) {
        fprintf(sess->errp, "needed a ");

        if (c == '\n')
            fprintf(sess->errp, "newline\n");
        else
            fprintf(sess->errp, "%c\n", c);

        return false;
    }
    return true;
}

bool
getnumber(Session * sess, int * numptr)
{
    return getnum(sess, numptr) && needchar(sess, '\n');
}

/**
 * @function gettumbler
 * @brief parse a tumbler value from the input stream
 *
 * (to be defined)
 *
 **/

bool
gettumbler(Session *sess, Tumbler *tumblerptr)
{
    int i;

    tumblerclear(tumblerptr);
    if (eatchar(sess, '-'))
        tumblerptr->sign = 1;

    for (i = 0; i < NPLACES; ++i) {
        if (!getnum(sess, (int *) &tumblerptr->mantissa[i]))
            return false;

        if (tumblerptr->mantissa[i] == 0 && i == 0) {
            --tumblerptr->exp;
            --i;
        }

        if (!eatchar(sess, '.'))
            break;
    }

    if (eatchar(sess, '.')) {
        fprintf(sess->errp, "tumbler overflow\n");
        return false;
    }

    for (i = 0; i < NPLACES && tumblerptr->mantissa[i] == 0; ++i)
        ;

    if (i == NPLACES)
        tumblerptr->exp = 0;

    return needchar(sess, '\n');
}

bool
getbool(Session *sess, bool *boolptr)
{
    prompt(sess, "(y/n) ");
    int c = getc(sess->inp);
    if (isupper(c))
        c = tolower(c);

    eatchar(sess, '\n');

    if (c == 'y') {
        *boolptr = true;
        return true;

    } else if (c == 'n') {
        *boolptr = false;
        return true;

    } else {
        error(sess, "need 'y' or 'n'");
        return false;
    }
}

bool
getisa(Session *sess, IStreamAddr *isaptr)
{
    return gettumbler(sess, isaptr);
}

bool
getvsa(Session *sess, Tumbler *vsaptr)
{
    return gettumbler(sess, vsaptr);
}

bool
getrequest(Session *sess, typerequest *requestptr)
{
    prompt(sess, "\nrequest? ");
    int c = getc(sess->inp);
    if ((int) c == EOF) {
        fprintf(stderr, "endfile\n");
        sess->inp = stdin;
    }                                  /* else if (c == ':') { while ((c = * getc (sess->inp)) != '\n'); * return
                                        * (false); } */
    ungetc(c, sess->inp);
    return getnumber(sess, requestptr) && validrequest(sess, *requestptr);
}

bool
validrequest(Session *sess, typerequest request)
{
    if (request >= 0 && request < NREQUESTS && requestfns[request] != NULL)
        return true;

    fprintf(sess->errp, "invalid request: %d\n", request);
    return false;
}

bool
validaccount(Session *sess, IStreamAddr *accountptr)
{
    return (true);
}

bool
getspecset(Session *sess, typespecset *specsetptr)
{
    bool any, type;
    typespec *specset;

    for (;;) {
        prompt(sess, "any spans or vspecs? ");
        if (!getbool(sess, &any))
            return false;

        if (!any) {
            *specsetptr = NULL;
            return true;
        }

        prompt(sess, "a span? ");
        if (!getbool(sess, &type))
            return false;

        if (type) {
            specset = (typespec *) new(sess) typespan;
//            specset = (typespec *) sess->alloc(sizeof(typespan));
            if (!getspan(sess, (typespan *) specset, ISPANID))
                return false;

        } else {
            specset = (typespec *) new(sess) typevspec;
//            specset = (typespec *) sess->alloc(sizeof(typevspec));
            if (!getvspec(sess, (typevspec *) specset))
                return false;
        }
        *specsetptr = specset;
        specsetptr = (typespecset *) & (((typevspec *) specset)->next);
    }
}

bool
getvspec(Session *sess, typevspec *vspecptr)
{
    vspecptr->itemid = VSPECID;
    vspecptr->next   = NULL;

    prompt(sess, "document=> ");
    if (!(getisa(sess, &vspecptr->docisa) && getspanset(sess, &vspecptr->vspanset, VSPANID)))
        return false;

    return true;
}

bool
getspanset(Session *sess, typespanset *spansetptr, typeitemid id)
{
    bool any;
    typespan *spanset;

    for (;;) {
        prompt(sess, "any spans? ");
        if (!getbool(sess, &any))
            return false;

        if (!any) {
            *spansetptr = NULL;
            return true;
        }

        spanset = new(sess) typespan;
//        spanset = (typespan *) sess->alloc(sizeof(typespan));
        if (!getspan(sess, spanset, id))
            return false;

        *spansetptr = spanset;
        spansetptr  = &spanset->next;
    }
}

bool
getspan(Session *sess, typespan *spanptr, typeitemid id)
{
    prompt(sess, "enter span\n       start=> ");
    if (!getisa(sess, (IStreamAddr *) &spanptr->stream))
        return false;

    spanptr->itemid = id;

    prompt(sess, "	width=> ");
    if (!(getisa(sess, (IStreamAddr *) &spanptr->width)))
        return false;

    return true;
}

bool
gettextset(Session *sess, typetextset *textsetptr)
{
    typetext *textset;

    for (;;) {
        textset = new(sess) typetext;
//        textset = (typetext *) sess->alloc(sizeof(typetext));
        if (!gettext(sess, textset)) {
            *textsetptr = NULL;
            break;
        }
        *textsetptr = textset;
        textsetptr  = &textset->next;
    }
    return true;
}

bool
gettext(Session *sess, typetext *textptr)
{
    if (!fgets(textptr->string, GRANTEXTLENGTH, sess->inp)) {
        textptr->length = 0;
        return false;
    }

    textptr->length = strlen(textptr->string);
    if (textptr->length <= 1)
        return false;

/* remove newlines */
/* 
 * if (textptr->string[textptr->length - 1] == '\n')
 * textptr->string[--textptr->length] = '\0'; */

    textptr->itemid = TEXTID;
    return true;
}

bool
getcutseq(Session *sess, typecutseq *cutseqptr)
{
    int i;
    bool anycuts;

    i = 0;
    for (;;) {
        prompt(sess, "any cuts? ");
        if (!getbool(sess, &anycuts))
            return false;

        if (!anycuts)
            break;

        prompt(sess, "cut address=> ");
        if (!getvsa(sess, &cutseqptr->cutsarray[i]))
            return false;

        if (++i > MAXCUTS)
            break;

        cutseqptr->numberofcuts = i;
    }
    return true;
}

bool
getboolset(Session *sess, typeboolsetnode **boolsetptr)
{
    bool disjunct;
    typeboolsetnode *boolset;

    for (;;) {
        prompt(sess, "any disjunctions? ");
        if (!getbool(sess, &disjunct))
            return false;

        if (!disjunct) {
            *boolsetptr = NULL;
            return true;
        }

        boolset = new(sess) typeboolsetnode;
//        boolset = (typeboolsetnode *) sess->alloc(sizeof(typeboolsetnode));

        prompt(sess, "enter disjunction=> ");
        if (!getspanset(sess, &boolset->val, ISPANID))
            return false;

/* zzz & zzz */
        boolset->itemid = NODEID;
        *boolsetptr     = boolset;
        boolsetptr      = &boolset->next;
    }
}
