/**********************************************************************
 * Copyright 2002 Jeff Rush <jrush@taupro.com>
 * Original Copyright 1979-2002 Udanax.com
 *
 * This file is part of the Udanax xanalogical storage system.
 *
 * Udanax is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * Udanax is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with Udanax; if not, write to the Free Software Foundation,
 * Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 **********************************************************************/

/**
 * @file  cashedisk.cxx
 * @brief ???
 *
 * (to be defined)
 *
 **/

/* Modification History:
 * $Log: cashedisk.cxx,v $
 * Revision 1.7  2002/05/28 03:58:42  jrush
 * Sources modified to comply with GPL licensing.
 *
 * Revision 1.6  2002/04/12 11:48:50  jrush
 * Major reorganization of includes into a single base-include style.
 *
 * Revision 1.5  2002/04/06 15:01:44  jrush
 * Changed INT to just 'int'.
 *
 * Revision 1.4  2002/02/14 10:08:25  jrush
 * Cleaned up source:
 *
 * 1. ran thru the indent tool to achieve a standard look,
 * 2. added structured comments at top for use with DOxygen reporting
 *    as well as CVS keywords,
 * 3. centralized prototypes in protos.h, removing incomplete ones,
 * 4. cleaned up use of bool/BOOLEAN type to suit C++ type,
 * 5. fixed initializer nesting in tumbler constants,
 * 6. converted select() int bits into ANSI fd_set type,
 * 7. added Makefile.am for use by automake.
 *
 */

#include "udanax.h"

/* crude random replacement hash cashe */
#define HASHSIZE 301
#define HASHMULT 754343                /* random prime */

typedef struct hashfoo {
    int blocknumber;
    typeuberrawdiskloaf urdloaf;
} hashtable;

hashtable xhashtable[HASHSIZE];

void
inithash()
{
    int i;
    for (i = 0; i < HASHSIZE; i++)
        xhashtable[i].blocknumber = -1;
}

void
actuallyreadrawloaffromhash(typeuberrawdiskloaf * loafptr, int blocknumber)
{
    int temp;
    void addtohash(), actuallyreadrawloaf();

/* fprintf(stderr,"actuallyreadrawloaffromhash %d \n",blocknumber); */
    if (temp = blockisinhash(blocknumber)) {
        *loafptr = xhashtable[temp].urdloaf;
        return;
    }
    actuallyreadrawloaf(loafptr, blocknumber);
    addtohash(loafptr, blocknumber);

}

void
writethruhash(typeuberrawdiskloaf * loafptr, int blocknumber)
{
    int temp;
    void addtohash();

    if (temp = blockisinhash(blocknumber)) {
        xhashtable[temp].urdloaf = *loafptr;
    } else {
        addtohash(loafptr, blocknumber);
    }
}

void
hashcasheclash()
{
}

int
blockisinhash(int blocknumber)
{
    int temp = hash(blocknumber);

    if (xhashtable[temp].blocknumber == blocknumber)
        return temp;
    else
        return 0;
}

void
addtohash(typeuberrawdiskloaf * loafptr, int blocknumber)
{
    int temp = hash(blocknumber);

    if (xhashtable[temp].blocknumber != -1)
        hashcasheclash();

    xhashtable[temp].blocknumber = blocknumber;
    xhashtable[temp].urdloaf     = *loafptr;
}

int
hash(int blocknumber)
{
    return abs(blocknumber * HASHMULT) % HASHSIZE;
}
