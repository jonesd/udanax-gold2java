/**********************************************************************
 * Copyright 2002 Jeff Rush <jrush@taupro.com>
 * Original Copyright 1979-2002 Udanax.com
 *
 * This file is part of the Udanax xanalogical storage system.
 *
 * Udanax is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * Udanax is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with Udanax; if not, write to the Free Software Foundation,
 * Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 **********************************************************************/

/**
 * @file  socketbe.cxx
 * @brief ???
 *
 * (to be defined)
 *
 **/

/* Modification History:
 * $Log: socketbe.cxx,v $
 * Revision 1.12  2002/05/28 03:58:42  jrush
 * Sources modified to comply with GPL licensing.
 *
 * Revision 1.11  2002/04/12 11:48:51  jrush
 * Major reorganization of includes into a single base-include style.
 *
 * Revision 1.10  2002/04/09 21:45:47  jrush
 * Renamed class 'tumbler' to 'Tumbler', for consistency with Python sources,
 * and changed typeisa from typedef to a subclass, in preparation for cleaning
 * up the type/class tree.
 *
 * Revision 1.9  2002/04/07 14:04:37  jrush
 * Add ptr to Session to checkforopen() and isthisusersdocument() so that we
 * have session information available to make the decision.
 *
 * Revision 1.8  2002/04/06 19:51:30  jrush
 * Renamed TRUE/FALSE constant use to the C++ standard of true/false.
 *
 * Revision 1.7  2002/04/06 17:05:57  jrush
 * Switched from referring to 'task' for a client connection to 'session',
 * and converted the typetask typedef/struct into a Session C++ class.
 *
 * Revision 1.6  2002/04/06 15:01:45  jrush
 * Changed INT to just 'int'.
 *
 * Revision 1.5  2002/04/02 17:17:25  jrush
 * Fixed select() and FD_SET handling to work under Gnu C on Linux.
 *
 * Revision 1.4  2002/02/14 10:08:26  jrush
 * Cleaned up source:
 *
 * 1. ran thru the indent tool to achieve a standard look,
 * 2. added structured comments at top for use with DOxygen reporting
 *    as well as CVS keywords,
 * 3. centralized prototypes in protos.h, removing incomplete ones,
 * 4. cleaned up use of bool/BOOLEAN type to suit C++ type,
 * 5. fixed initializer nesting in tumbler constants,
 * 6. converted select() int bits into ANSI fd_set type,
 * 7. added Makefile.am for use by automake.
 *
 */

#include <stdio.h>
#include <stdlib.h>
#include <errno.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <sys/time.h>
#include <netdb.h>
#include <string.h>
#include <unistd.h>
#include "udanax.h"
#include "players.h"
#include "port.h"

#define ERROR           -1
#define typerequest int
#define MAX_PLAYERS     25             /* max # concurrent players */

/* These two are set in rcfile.c, possibly from the .backendrc file */
extern char hostname[];
extern int portname;

int fdtoplayer[32];
Tumbler defaultaccount = { 0, 0, 0, 0, { 1, 1, 0, 14, 0, 0, 0, 0, 0, 0, 0 } };

PLAYER player[MAX_PLAYERS];     /* player information */
int n_players = 0;
fd_set inputfds;
int nfds = 0;

int main_socket = ERROR;        /* socket to accept connections on */

extern bool establishprotocol(FILE *inp, FILE *outp);

void
new_players(PLAYER player[], int * n_playersp, int block, Session * sess)
    /* array of player info structures */
    /* number of players (incl comp) */
    /* if nobody wants to join, wait on socket until somebody * does. */
{
    int s;      /* temp holder for new socket */
    int rc;     /* # ready selected sockets */
    struct sockaddr_in from;    /* connection acceptor */
    socklen_t fromlen = sizeof(from);
    struct timeval t;   /* don't let select() run forever */
    //UNUSED int i;
    //UNUSED FILE *temp;
    //UNUSED char devicename[100];
    //UNUSED int len;
    //UNUSED typerequest requestinstance;
    int open_sock();    /* to open main socket */

    if (main_socket == ERROR)
        main_socket = open_sock();

/* set up 0 second timeout for use on select() calls */
/* well it USED to be 0 seconds, but that seems too fast now !<reg sep 10 1999> */
    t.tv_sec = 0L;
    t.tv_usec = 3L;
    
    for (;;) {
        fd_set readfds;
        FD_ZERO(&readfds);
        FD_SET(main_socket, &readfds);
//OBSOLETE        readfds = 1 << main_socket;

        t.tv_sec  = 0L;
        t.tv_usec = 3L;
        if ((rc = select(32, &readfds, 0, 0, &t)) == -1) { // Wait on Main Socket
            perror("new_players:select");
            fflush(stdout);
            break;
        }
        if (rc > 0 || block) {
            if ((s = accept(main_socket, (sockaddr *) &from, &fromlen)) < 0) {
                perror("new_players:accept");
                fflush(stdout);
                break;
            }
            if (*n_playersp >= MAX_PLAYERS) {
                fprintf(stderr, "TOOMANY frontends: won't log another one\n");
                close(s);
            } else {
                block = false;
#ifndef DISTRIBUTION
                fprintf(stderr, "accepted connection from %d ", s);
#endif
/* read ttyname and open socket for it; */

                player[*n_playersp].socket = s;
                if ((player[*n_playersp].inp = fdopen(s, "r")) == NULL) {
                    perror("fdopen(r)");
                    break;
                }
                if ((sess->outp = player[*n_playersp].outp = fdopen(s, "w")) == NULL) {
                    perror("fdopen(w)");
                    break;
                }
                sess->inp = player[*n_playersp].inp;

#ifndef DISTRIBUTION
                fprintf(stderr, "%s\n", (char *) &(player[*n_playersp].account));
#endif
                if (!establishprotocol(sess->inp, sess->outp)) {
                    break;
                }
// getrequest(sess, &requestinstance);
// getxaccount(sess, &(player[*n_playersp].account));
// logaccount(&(player[*n_playersp].account));
                player[*n_playersp].wantsout = false;

                fdtoplayer[s] = *n_playersp;
                FD_SET(s, &inputfds);
                nfds = max(s, nfds);
                (*n_playersp)++;
                break;
            }
        } else
            break;
    }
}

void
leave(PLAYER player[], int * xn_players)
{
    register int i;

    for (i = 0; i < *xn_players; i++)
        if (player[i].wantsout) {
            FD_CLR(player[i].socket, &inputfds);
//OBSOLETE            inputfds ^= (1 << (player[i].socket));

            if (close(player[i].socket) != 0) {
                fprintf(stderr, "user %d: ", i);
                perror("close player.socket");
            }
            if (*xn_players > 1) {
                player[i] = player[*xn_players - 1];
            }
            (*xn_players)--;
            --i;                       /* since this entry is new, test again */
        }
}

int
open_sock()
{                                      /* Open the main socket. */
    int s;
    struct sockaddr_in sockaddr;
    //UNUSED struct hostent *host;

    if ((s = socket(AF_INET, SOCK_STREAM, 0)) < 0) {
        perror("socket()");
        exit(1);
    }
/* 
 * if ((host = gethostbyname(hostname)) == NULL) { perror("gethostbyname()");
 * exit(1); } */
    sockaddr.sin_family = AF_INET;
    sockaddr.sin_port = htons(portname);
    sockaddr.sin_addr.s_addr = /* inetaddr */ INADDR_ANY;

    fprintf(stderr, "calling bind s = %d \n", s);

    if (bind(s, (struct sockaddr *) &sockaddr, sizeof(sockaddr)) < 0) {
        perror("bind()");
        exit(1);
    }
    if (listen(s, 0) < 0) {
        perror("listen()");
        exit(1);
    }
    return (s);
}

void
crash(int /*sigarg*/)
{
    int i;

    fprintf(stderr, "CRASH while dealing with user %d\n", user);
    for (i = 0; i < 32; i++)
        close(i);                      /* BOO HISS: too many closes */
    exit(9);
}

bool
isthisusersdocument(Session *sess, Tumbler *tp)
{
    return tumbleraccounteq(tp, &(player[user].account));
}
