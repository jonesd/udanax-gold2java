/**********************************************************************
 * Copyright 2002 Jeff Rush <jrush@taupro.com>
 * Original Copyright 1979-2002 Udanax.com
 *
 * This file is part of the Udanax xanalogical storage system.
 *
 * Udanax is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * Udanax is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with Udanax; if not, write to the Free Software Foundation,
 * Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 **********************************************************************/

/**
 * @file  rcfile.cxx
 * @brief process .backendrc for xlog, backenddaemon and ??
 *
 * (to be defined)
 *
 **/

/* Modification History:
 * $Log: rcfile.cxx,v $
 * Revision 1.6  2002/05/28 03:58:42  jrush
 * Sources modified to comply with GPL licensing.
 *
 * Revision 1.5  2002/04/12 11:48:51  jrush
 * Major reorganization of includes into a single base-include style.
 *
 * Revision 1.4  2002/04/12 10:43:50  jrush
 * Moved libsrc/rcfile.cxx to server/rcfile.cxx
 *
 * Revision 1.4  2002/04/06 15:01:17  jrush
 * Changed INT to just 'int'.
 *
 * Revision 1.3  2002/02/17 10:10:45  jrush
 * Commented out unused Udanax-configuration file directives, to avoid confusion.
 *
 * Revision 1.2  2002/02/14 09:27:43  jrush
 * Cleaned up source:
 *
 * 1. ran thru the indent tool to achieve a standard look,
 * 2. added structured comments at top for use with DOxygen reporting
 *    as well as CVS keywords,
 * 3. fixed compiler warnings re ambiguous assign/compares,
 *    needed casts and unused/uninitialized variables,
 * 4. fixed funcs that didn't specify a return type,
 * 5. centralized prototypes in protos.h, removing incomplete ones,
 * 6. cleaned up use of bool/BOOLEAN type to suit C++ type,
 * 7. fixed initializer nesting in tumbler constants,
 * 8. renamed vars that conflict with C++ keywords (new, this),
 * 9. fixed global/extern confusion re some global vars.
 *
 */

#include <stdio.h>
#include <string.h>
#include "udanax.h"
#include "port.h"

#define RCFILENAME               ".backendrc"
#define PORTMETANAME		 "port"
#define HOSTMETANAME		 "host"
//UNUSED #define BACKENDDIRECTORYMETANAME "backenddir"
//UNUSED #define BACKENDFILEMETANAME      "backend"
//UNUSED #define ACCOUNTFILEMETANAME      "accountfile"
//UNUSED #define FRONTENDFILEMETANAME     "frontend"
//UNUSED #define BACKENDGLUEFILEMETANAME  "backglue"
//UNUSED #define FRONTENDGLUEFILEMETANAME "frontglue"
#define ALLOCSIZENAME		 "allocsize"
#define INCREMENTALALLOCSIZENAME "incrementalallocsize"

int portname = PORT;
char hostname[256] = "localhost";
//UNUSED char backenddirectoryname[256] = ".";
//UNUSED char backendfilename[256] = "backenddaemon";
//UNUSED char accountfilename[256] = "accountfile";
//UNUSED char frontendfilename[256] = "fex";
//UNUSED char backendgluefilename[256] = "intx";
//UNUSED char frontendgluefilename[256] = "ints";

int incrementalallocsize = INCREMENTALALLOCSIZE;
int allocsize = ALLOCSIZE;

/* Read run-time parameters from ./.backendrc ECH 7-7-88 This is real dumb, but it should be enough to get the job done 
 * for now. */
void
processrcfile()
{
    FILE *rcfd;
    static char buf[BUFSIZ];
    static char line[256];
    static char name[256];
    int temp;

    if ((rcfd = fopen(RCFILENAME, "r")) != NULL) {
        while (fgets(buf, BUFSIZ, rcfd)) {
            if (buf[0] != '#' && sscanf(buf, "%s = %s", name, line) == 2) {
//UNUSED                if (!strcmp(name, BACKENDFILEMETANAME))
//UNUSED                    strcpy(backendfilename, line);
//UNUSED                else if (!strcmp(name, ACCOUNTFILEMETANAME))
//UNUSED                     strcpy(accountfilename, line);
//UNUSED                else
                if (!strcmp(name, PORTMETANAME)) {
                    if (sscanf(line, "%d", &portname) < 1) {
                        fprintf(stderr, "Could not use port = %s, using %d\n", line, PORT);
                        portname = PORT;
                    }
                } else if (!strcmp(name, HOSTMETANAME))
                    strcpy(hostname, line);
//UNUSED                else if (!strcmp(name, BACKENDDIRECTORYMETANAME))
//UNUSED                    strcpy(backenddirectoryname, line);
//UNUSED                else if (!strcmp(name, BACKENDGLUEFILEMETANAME))
//UNUSED                    strcpy(backendgluefilename, line);
//UNUSED                else if (!strcmp(name, FRONTENDGLUEFILEMETANAME))
//UNUSED                    strcpy(frontendgluefilename, line);
//UNUSED                else if (!strcmp(name, FRONTENDFILEMETANAME))
//UNUSED                    strcpy(frontendfilename, line);
                else if (!strcmp(name, ALLOCSIZENAME)) {
                    temp = allocsize;
                    sscanf(line, "%d", &allocsize);
                    if (allocsize < 100000 || allocsize > 300000000) {  /* minimal sanity checking */
                        incrementalallocsize = temp;
                    }
                } else if (!strcmp(name, INCREMENTALALLOCSIZENAME)) {
                    temp = incrementalallocsize;
                    sscanf(line, "%d", &incrementalallocsize);
                    if (incrementalallocsize < 10000 || incrementalallocsize > 100000000) {
                        incrementalallocsize = temp;
                    }
                } else
                    fprintf(stderr, "Don't know about %s = %s\n", name, line);
            }
        }
        fclose(rcfd);
    }
}
