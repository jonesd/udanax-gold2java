/**********************************************************************
 * Copyright 2002 Jeff Rush <jrush@taupro.com>
 * Original Copyright 1979-2002 Udanax.com
 *
 * This file is part of the Udanax xanalogical storage system.
 *
 * Udanax is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * Udanax is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with Udanax; if not, write to the Free Software Foundation,
 * Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 **********************************************************************/

/**
 * @file  fns.cxx
 * @brief Udanax Back-end Top Level Functions
 *
 * (to be defined)
 *
 **/

/* Modification History:
 * $Log: fns.cxx,v $
 * Revision 1.11  2002/05/28 03:58:42  jrush
 * Sources modified to comply with GPL licensing.
 *
 * Revision 1.10  2002/04/13 14:08:35  jrush
 * Changed typedef of structs into just structs, for C++ style.
 *
 * Revision 1.9  2002/04/12 11:48:50  jrush
 * Major reorganization of includes into a single base-include style.
 *
 * Revision 1.8  2002/04/10 18:01:54  jrush
 * Renamed class typeisa to IStreamAddr.
 *
 * Revision 1.7  2002/04/09 21:45:46  jrush
 * Renamed class 'tumbler' to 'Tumbler', for consistency with Python sources,
 * and changed typeisa from typedef to a subclass, in preparation for cleaning
 * up the type/class tree.
 *
 * Revision 1.6  2002/04/08 18:55:56  jrush
 * Switched from using global variable 'user' to object 'Session' as a
 * connection for tracking open document descriptors in the bert table.
 *
 * Revision 1.5  2002/04/07 14:03:48  jrush
 * Moved console-interactive functions examine(), showorgl() and showenfilades()
 * from libsrc/test.cxx to server/fns.cxx.
 *
 * Revision 1.4  2002/04/07 13:11:13  jrush
 * Relocated fns.cxx from libsrc to server directory
 *
 * Revision 1.5  2002/04/06 17:05:57  jrush
 * Switched from referring to 'task' for a client connection to 'session',
 * and converted the typetask typedef/struct into a Session C++ class.
 *
 * Revision 1.4  2002/04/06 15:01:17  jrush
 * Changed INT to just 'int'.
 *
 * Revision 1.3  2002/04/02 18:45:12  jrush
 * Purely cosmetic changes.
 *
 * Revision 1.2  2002/02/14 09:27:43  jrush
 * Cleaned up source:
 *
 * 1. ran thru the indent tool to achieve a standard look,
 * 2. added structured comments at top for use with DOxygen reporting
 *    as well as CVS keywords,
 * 3. fixed compiler warnings re ambiguous assign/compares,
 *    needed casts and unused/uninitialized variables,
 * 4. fixed funcs that didn't specify a return type,
 * 5. centralized prototypes in protos.h, removing incomplete ones,
 * 6. cleaned up use of bool/BOOLEAN type to suit C++ type,
 * 7. fixed initializer nesting in tumbler constants,
 * 8. renamed vars that conflict with C++ keywords (new, this),
 * 9. fixed global/extern confusion re some global vars.
 *
 */

#include "udanax.h"
#include "players.h"
#include "requests.h"

bool  getfinddocscontaining(Session * sess, typespecset * specsetptr);
bool  getcopy(Session * sess, IStreamAddr * docisaptr, IStreamAddr * vsaptr, typespecset * localspecsetptr);
bool  getinsert(Session * sess, IStreamAddr * docisaptr, Tumbler * vsaptr, typetextset * textsetptr);
bool  getcreatelink(Session * sess, IStreamAddr * docisaptr, typespecset * fromspecsetptr, typespecset * tospecsetptr, typespecset * threespecsetptr);
bool  getfollowlink(Session * sess, IStreamAddr * linkisaptr, int * whichendptr);
bool  getcreatenewversion(Session * sess, IStreamAddr * docisaptr);
bool  getretrievedocvspanset(Session * sess, IStreamAddr * docisaptr);
bool  getretrievedocvspan(Session * sess, IStreamAddr * docisaptr);
bool  getrearrange(Session * sess, IStreamAddr * docisaptr, typecutseq * cutseqptr);
bool  getretrievev(Session * sess, typespecset * specsetptr);
bool  getfindlinksfromtothree(Session * sess, typespecset * fromvspecsetptr, typespecset * tovspecsetptr, typespecset * threevspecsetptr, typeispanset * homesetptr);
bool  getfindnumoflinksfromtothree(Session * sess, typespecset * fromvspecsetptr, typespecset * tovspecsetptr, typespecset * threevspecsetptr, typeispanset * homesetptr);
bool  getfindnextnlinksfromtothree(Session * sess, typespecset * fromvspecsetptr, typespecset * tovspecsetptr, typespecset * threevspecsetptr, typeispanset * homesetptr, IStreamAddr * lastlinkptr, int * nptr);
bool  getshowrelationof2versions(Session * sess, typespecset * version1ptr, typespecset * version2ptr);
void  getcreatenewdocument();
bool  getdeletevspan(Session * sess, IStreamAddr * docisaptr, typevspan * vspanptr);
void  setdebug(Session * sess);
void  playwithalloc(Session * sess);
bool  getretrieveendsets(Session * sess, typespecset * specsetptr);
bool  getxaccount(Session * sess, IStreamAddr * accountptr);
bool  getcreatenode_or_account(Session *sess, Tumbler *tp);
bool  getopen(Session *sess, Tumbler *tp, int *typep, int *modep);
bool  getclose(Session *sess, Tumbler *tp);
bool  gettumbler(Session * sess, Tumbler * tumblerptr);

void  prompt(Session * sess, char *string);
void  error(Session * sess, char *string);
void  puttumbler(FILE * outfile, Tumbler * tumblerptr);
void  putnum(FILE * outfile, int num);
void  putisa(Session * sess, IStreamAddr * isaptr);
void  putitemset(Session * sess, typeitemset itemset);
void  putitem(Session * sess, typeitem * itemptr);
void  putspan(Session * sess, typespan * spanptr);
void  puttext(Session * sess, typetext * textptr);
void  putspanpairset(Session * sess, typespanpairset spanpairset);
void  putspanpair(Session * sess, typespanpair * spanpair);
void  putcreatelink(Session * sess, IStreamAddr * istreamptr);
void  putfollowlink(Session * sess, typespecset specset);
void  putretrievedocvspanset(Session * sess, typespanset * spansetptr);
void  putretrievedocvspan(Session * sess, typespan * vspanptr);
void  putretrievev(Session * sess, typevstuffset * vstuffsetptr);
void  putfindlinksfromtothree(Session * sess, typelinkset linkset);
void  putfindnumoflinksfromtothree(Session * sess, int num);
void  putfindnextnlinksfromtothree(Session * sess, int n, typelinkset nextlinkset);
void  putshowrelationof2versions(Session * sess, typespanpairset relation);
void  putcreatenewdocument(Session * sess, IStreamAddr * newdocisaptr);
void  putcreatenewversion(Session * sess, IStreamAddr * newdocisaptr);
void  putfinddocscontaining(Session * sess, typeitemset addressset);
void  putretrieveendsets(Session * sess, typespecset fromset, typespecset toset, typespecset threeset);
void  putinsert(Session * sess);
void  putcopy(Session * sess);
void  putdeletevspan(Session * sess);
void  putrearrange(Session * sess);
void  putrequestfailed(Session * sess);
void  putxaccount(Session * sess);
void  putcreatenode_or_account(Session * sess, Tumbler * tp);
void  putopen(Session * sess, Tumbler * tp);
void  putclose(Session * sess);
void  putquitxanadu(Session * sess);

extern FILE *interfaceinput;

extern int backenddaemon;

extern bool docreatenewversion(Session *sess, IStreamAddr *isaptr, IStreamAddr *wheretoputit, IStreamAddr *newisaptr);

void
finddocscontaining(Session *sess)
{
    typespecset specset;
    typelinkset addressset;

    if (getfinddocscontaining(sess, &specset) && dofinddocscontaining(sess, specset, &addressset))
        putfinddocscontaining(sess, (typeitemset) addressset);
    else
        putrequestfailed(sess);
}

void
copy(Session *sess)
{
    IStreamAddr docisa, vsa;
    typespecset localspecset;

    if (getcopy(sess, &docisa, &vsa, &localspecset) && docopy(sess, &docisa, &vsa, localspecset))
        putcopy(sess);
    else
        putrequestfailed(sess);
}

#ifdef UnDEfined
void
copy(Session * sess)
{                                      /* kluged unix version for speed */
    IStreamAddr docisa, vsa;
    typespecset localspecset;

    getcopy(sess, &docisa, &vsa, &localspecset);
    putcopy(sess);

    if (!docopy(sess, &docisa, &vsa, /* & ECH according to lint */ &localspecset))   /* zzz * aug * 21 * 1999 *
                                                                                         * reg * ? * this * may *
                                                                                         * cause * trouble * * */
#ifndef DISTRIBUTION
        fprintf(stderr, "copy failed \n");
#else
        ;
#endif
}
#endif

/* void insert (sess) Session *sess; { IStreamAddr docisa, vsa; typetextset textset; bool getinsert(), doinsert();
 * if ( getinsert (sess, &docisa, &vsa, &textset) && doinsert (sess, &docisa, &vsa, textset)) putinsert
 * (sess); else putrequestfailed (sess); } */

void
insert(Session *sess)
{                                      /* cheating version for unix zzz */
    IStreamAddr docisa, vsa;
    typetextset textset;

    getinsert(sess, &docisa, &vsa, &textset);
    putinsert(sess);

    if (!doinsert(sess, &docisa, &vsa, textset))
#ifndef DISTRIBUTION
        fprintf(stderr, "requestfailed in insert\n");
#else
        ;
#endif
}

void
createlink(Session *sess)
{
    IStreamAddr docisa, linkisa;
    typespecset fromspecset, tospecset, threespecset;

    if (getcreatelink(sess, &docisa, &fromspecset, &tospecset, &threespecset)
        && docreatelink(sess, &docisa, fromspecset, tospecset, threespecset, &linkisa)) {
        putcreatelink(sess, &linkisa);
    } else
        putrequestfailed(sess);
}

void
followlink(Session *sess)
{
    IStreamAddr linkisa;
    typespecset specset;
    int whichend;

    if (getfollowlink(sess, &linkisa, &whichend)
        && dofollowlink(sess, &linkisa, &specset, whichend)) {
        putfollowlink(sess, specset);
    } else
        putrequestfailed(sess);
}

void
retrievedocvspanset(Session *sess)
{
    IStreamAddr docisa;
    typevspanset vspanset;

    if (getretrievedocvspanset(sess, &docisa)
        && doretrievedocvspanset(sess, &docisa, &vspanset))
        putretrievedocvspanset(sess, &vspanset);
    else
        putrequestfailed(sess);
}

/* void rearrange (sess) Session *sess; { IStreamAddr docisa; typecutseq cutseq; bool getrearrange(), dorearrange();
 * if ( getrearrange (sess, &docisa, &cutseq) && dorearrange (sess, &docisa, &cutseq)) putrearrange (sess); else 
 * putrequestfailed (sess); } */

void
rearrange(Session *sess)
{                                      /* speed hack for unix */
    IStreamAddr docisa;
    typecutseq cutseq;

    (void)getrearrange(sess, &docisa, &cutseq);
    putrearrange(sess);
    if (!dorearrange(sess, &docisa, &cutseq))
#ifndef DISTRIBUTION
        fprintf(stderr, "rearrange failed \n");
#else
        ;
#endif
}

void
retrievev(Session *sess)
{
    typespecset specset;
    typevstuffset vstuffset;

    if (getretrievev(sess, &specset)
        && doretrievev(sess, specset, &vstuffset))
        putretrievev(sess, &vstuffset);
    else
        putrequestfailed(sess);
}

void
findlinksfromtothree(Session *sess)
{
    typespecset fromvspecset, tovspecset, threevspecset;
    typeispanset homeset;
    typelinkset linkset;

    if (getfindlinksfromtothree(sess, &fromvspecset, &tovspecset, &threevspecset, &homeset)
        && dofindlinksfromtothree(sess, fromvspecset, tovspecset, threevspecset, (typeispan *) NULL /* homeset */ ,
                                  &linkset))
        putfindlinksfromtothree(sess, linkset);
    else
        putrequestfailed(sess);
}

void
findnumoflinksfromtothree(Session *sess)
{
    typespecset fromvspecset, tovspecset, threevspecset;
    typeispanset homeset;
    int numberoflinks;

    if (getfindnumoflinksfromtothree(sess, &fromvspecset, &tovspecset, &threevspecset, &homeset)
        && dofindnumoflinksfromtothree(sess, (typespec **) fromvspecset, (typespec **) tovspecset, (typespec **) threevspecset, homeset, &numberoflinks))
        putfindnumoflinksfromtothree(sess, numberoflinks);
    else
        putrequestfailed(sess);
}

void
findnextnlinksfromtothree(Session *sess)
{
    typespecset fromvspecset, tovspecset, threevspecset;
    typeispanset homeset;
    IStreamAddr lastlink;
    typelinkset nextlinkset;
    int n;

    if (getfindnextnlinksfromtothree(sess, &fromvspecset, &tovspecset, &threevspecset, &homeset, &lastlink, &n)
        && dofindnextnlinksfromtothree(sess, (typevspec *) fromvspecset, (typevspec *) tovspecset, (typevspec *) threevspecset, homeset, &lastlink,
                                       &nextlinkset, &n))
        putfindnextnlinksfromtothree(sess, n, nextlinkset);
    else
        putrequestfailed(sess);
}

void
navigateonht(Session *sess)
{
#ifndef DISTRIBUTION
    error(sess, "GACK !  (historical trace)\n");
#endif

/* 
 * IStreamAddr docisa, htisa; typehtpath turninginstructions; bool
 * getnavigateonht(); if (getnavigateonht(sess, &docisa, &htisa,
 * &turninginstructions)) donavigateonht(sess, &docisa, &htisa,
 * &turninginstructions); */
}

void
showrelationof2versions(Session *sess)
{
    typespecset version1, version2;
    typespanpairset relation;

    if (getshowrelationof2versions(sess, &version1, &version2)
        && doshowrelationof2versions(sess, version1, version2, &relation))
        putshowrelationof2versions(sess, relation);
    else
        putrequestfailed(sess);
}

/* 
 * void showrelationof2versions (sess) Session *sess; { IStreamAddr doc1,
 * doc2; int relation; // temp // bool getshowrelationof2versions(),
 * doshowrelationof2versions();
 * 
 * if (getshowrelationof2versions(sess, &doc1, &doc2)) if
 * (doshowrelationof2versions(sess, &doc1, &doc2, &relation))
 * putshowrelationof2versions(sess, &relation); } */

void
createnewdocument(Session *sess)
{
    IStreamAddr newdocisa;

    getcreatenewdocument();
    if (docreatenewdocument(sess, &newdocisa))
        putcreatenewdocument(sess, &newdocisa);
    else
        putrequestfailed(sess);
}

void
createnewversion(Session *sess)
{
    IStreamAddr originaldocisa, newdocisa;

    if (getcreatenewversion(sess, &originaldocisa)
        && docreatenewversion(sess, &originaldocisa, &originaldocisa, &newdocisa))
        putcreatenewversion(sess, &newdocisa);
    else
        putrequestfailed(sess);
}

void
retrievedocvspan(Session *sess)
{
    IStreamAddr docisa;
    typevspan vspan;

    if (getretrievedocvspan(sess, &docisa)
        && doretrievedocvspan(sess, &docisa, &vspan))
        putretrievedocvspan(sess, &vspan);
    else
        putrequestfailed(sess);
}

/* 
 * void deletevspan (sess) Session *sess; { IStreamAddr docisa; typespan
 * vspan; bool getdeletevspan(), dodeletevspan();
 * 
 * if ( getdeletevspan (sess, &docisa, &vspan) && dodeletevspan (sess,
 * &docisa, &vspan)) putdeletevspan (sess); else putrequestfailed
 * (sess); } */
void
deletevspan(Session *sess)
{                                      /* kluged unix version for speed */
    IStreamAddr docisa;
    typespan vspan;

    (void)getdeletevspan(sess, &docisa, &vspan);
    putdeletevspan(sess);
    if (!dodeletevspan(sess, &docisa, &vspan))
#ifndef DISTRIBUTION
        fprintf(stderr, "deletevspan failed \n");
#else
        ;
#endif
}

void
retrieveendsets(Session *sess)
{
    typespecset specset, fromset, toset, threeset;

    if (getretrieveendsets(sess, &specset)
        && doretrieveendsets(sess, specset, &fromset, &toset, &threeset)) {

        putretrieveendsets(sess, fromset, toset, threeset);
    } else
        putrequestfailed(sess);
}

void
xaccount(Session *sess)
{
    if (getxaccount(sess, (IStreamAddr *) &(player[user].account))) {
        putxaccount(sess);
    } else {
        putrequestfailed(sess);
    }
}

void
createnode_or_account(Session *sess)
{
    IStreamAddr t;

    if (getcreatenode_or_account(sess, &t)
        && docreatenode_or_account(sess, &t)) {
        putcreatenode_or_account(sess, &t);
    } else {
        putrequestfailed(sess);
    }
}

void
myopen(Session *sess)
{
    IStreamAddr t, newt;
    int type, mode;

    if (getopen(sess, &t, &type, &mode)
        && doopen(sess, &t, &newt, type, mode)) {
        putopen(sess, &newt);
    } else {
        putrequestfailed(sess);
    }
}

void
myclose(Session *sess)
{
    IStreamAddr t;

    if (getclose(sess, &t)
        && doclose(sess, &t)) {
        putclose(sess);
    } else {
        putrequestfailed(sess);
    }
}

void
quitxanadu(Session *sess)
{
    putquitxanadu(sess);

    if (!backenddaemon) {
        if (interfaceinput) {
            fprintf(interfaceinput, "%d~\n", QUIT);
            fclose(interfaceinput);
        }
        diskexit();
    } else
        dobertexit(sess);              /* Close all of the user's outstanding opens */
}

void
examine(Session *sess)
{
#ifndef DISTRIBUTION
    char c;
    //UNUSED IStreamAddr orglisa;
    //UNUSED typeorgl orgl;

    prompt(sess, "\nspanf (s), orgl (o) or istream (i) ? ");
    c = getc(sess->inp);
    if (c != '\n')
        getc(sess->inp);

    fprintf(stderr, "\n");
    switch (c) {
    case 'i':
        showistream((typecuc *) granf);
        break;
    case 's':
        showspanf((typecuc *) spanf);
        break;

    case 'o':
/* prompt (sess, "orgl isa => "); if (!( gettumbler (sess, &orglisa) && findorgl (sess, granf, &orglisa,
 * &orgl,READBERT))) { fprintf(stderr,sess->errp, "\nnot found\n"); } else { showspanf (orgl); } */
        showorgl(sess);
        break;

    default:
        return;
    }
#endif
}

void
showorgl(Session *sess)
{
#ifndef DISTRIBUTION
    typeorgl orgl;
    IStreamAddr orglisa;

    prompt(sess, "orgl isa => ");
    if (!(gettumbler(sess, &orglisa)
          && findorgl(sess, granf, &orglisa, &orgl, READBERT))) {
        fprintf(stderr, "\nnot found\n");
    } else {
        showsubtree((typecorecrum *) orgl);
    }
#endif
}

void
showenfilades(Session *sess)
{
#ifndef DISTRIBUTION
    char c;

    prompt(sess, "\ngranf (g), spanf (s) or orgl (o) ? ");
    c = getc(sess->inp);
    if (c != '\n')
        getc(sess->inp);

    fprintf(stderr /* sess->outps */ , "\n");

    switch (c) {
    case 'o':  showorgl(sess);                           break;
    case 'g':  showsubtree((typecorecrumhedr *) granf);  break;
    case 's':  showsubtree((typecorecrumhedr *) spanf);  break;
    default:                                             break;
    }
#endif
}
