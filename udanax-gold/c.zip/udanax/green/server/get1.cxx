/**********************************************************************
 * Copyright 2002 Jeff Rush <jrush@taupro.com>
 * Original Copyright 1979-2002 Udanax.com
 *
 * This file is part of the Udanax xanalogical storage system.
 *
 * Udanax is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * Udanax is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with Udanax; if not, write to the Free Software Foundation,
 * Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 **********************************************************************/

/**
 * @file  get1.cxx
 * @brief Udanax top-level input routines
 *
 * (to be defined)
 *
 **/

/* Modification History:
 * $Log: get1.cxx,v $
 * Revision 1.13  2002/05/28 03:58:42  jrush
 * Sources modified to comply with GPL licensing.
 *
 * Revision 1.12  2002/04/16 22:39:50  jrush
 * Converted many #defines into enumeration types instead, and adjusted
 * function prototypes accordingly.
 *
 * Revision 1.11  2002/04/12 11:48:50  jrush
 * Major reorganization of includes into a single base-include style.
 *
 * Revision 1.10  2002/04/10 18:01:54  jrush
 * Renamed class typeisa to IStreamAddr.
 *
 * Revision 1.9  2002/04/09 21:45:46  jrush
 * Renamed class 'tumbler' to 'Tumbler', for consistency with Python sources,
 * and changed typeisa from typedef to a subclass, in preparation for cleaning
 * up the type/class tree.
 *
 * Revision 1.8  2002/04/06 19:51:30  jrush
 * Renamed TRUE/FALSE constant use to the C++ standard of true/false.
 *
 * Revision 1.7  2002/04/06 17:05:57  jrush
 * Switched from referring to 'task' for a client connection to 'session',
 * and converted the typetask typedef/struct into a Session C++ class.
 *
 * Revision 1.6  2002/04/06 15:01:44  jrush
 * Changed INT to just 'int'.
 *
 * Revision 1.5  2002/04/02 17:29:10  jrush
 * Purely cosmetic cleanup.
 *
 * Revision 1.4  2002/02/14 10:08:25  jrush
 * Cleaned up source:
 *
 * 1. ran thru the indent tool to achieve a standard look,
 * 2. added structured comments at top for use with DOxygen reporting
 *    as well as CVS keywords,
 * 3. centralized prototypes in protos.h, removing incomplete ones,
 * 4. cleaned up use of bool/BOOLEAN type to suit C++ type,
 * 5. fixed initializer nesting in tumbler constants,
 * 6. converted select() int bits into ANSI fd_set type,
 * 7. added Makefile.am for use by automake.
 *
 */

#include "udanax.h"

bool  getspecset(Session * sess, typespecset * specsetptr);
void  prompt(Session * sess, char *string);
bool  getisa(Session * sess, IStreamAddr * isaptr);
bool  getvsa(Session * sess, Tumbler * vsaptr);
bool  gettextset(Session * sess, typetextset * textsetptr);
bool  getnumber(Session * sess, int * numptr);
bool  getcutseq(Session * sess, typecutseq * cutseqptr);
bool  getspanset(Session * sess, typespanset * spansetptr, typeitemid id);
bool  getspan(Session * sess, typespan * spanptr, typeitemid id);
bool  gettumbler(Session * sess, Tumbler * tumblerptr);
bool  validaccount(Session * sess, IStreamAddr * accountptr);

bool
getfinddocscontaining(Session *sess, typespecset *specsetptr)
{
    return getspecset(sess, specsetptr);
}

bool
getcopy(Session *sess, IStreamAddr *docisaptr, IStreamAddr *vsaptr, typespecset *localspecsetptr)
{
    prompt(sess, "copy to this document=> ");
    if (!getisa(sess, docisaptr))
        return false;

    prompt(sess, "at this address=> ");
    if (!(getvsa(sess, vsaptr) && getspecset(sess, localspecsetptr)))
        return false;

    return true;
}

bool
getinsert(Session *sess, IStreamAddr *docisaptr, Tumbler *vsaptr, typetextset *textsetptr)
{
    prompt(sess, "text=>\n\n");
    if (!gettextset(sess, textsetptr))
        return false;

    prompt(sess, "document=> ");
    if (!getisa(sess, docisaptr))
        return false;

    prompt(sess, "address=> ");
    if (!getvsa(sess, vsaptr))
        return false;

    return true;
}

bool
getcreatelink(Session *sess, IStreamAddr *docisaptr,
              typespecset *fromspecsetptr,
              typespecset *tospecsetptr,
              typespecset *threespecsetptr)
{
    prompt(sess, "home document=> ");
    if (!getisa(sess, docisaptr))
        return false;

    prompt(sess, "fromset\n");
    if (!getspecset(sess, fromspecsetptr))
        return false;

    prompt(sess, "toset\n");
    if (!getspecset(sess, tospecsetptr))
        return false;

    prompt(sess, "threeset\n");
    if (!getspecset(sess, threespecsetptr))
        return false;

    return true;
}

bool
getfollowlink(Session *sess, IStreamAddr *linkisaptr, int *whichendptr)
{
    prompt(sess, "enter link=> ");
    if (!getisa(sess, linkisaptr))
        return false;

    prompt(sess, "enter endset=> ");
    if (!(getnumber(sess, whichendptr) && (*whichendptr == 1 || *whichendptr == 2 || *whichendptr == 3)))
        return false;

    return true;
}

bool
getcreatenewversion(Session *sess, IStreamAddr *docisaptr)
{
    prompt(sess, "enter document=> ");
    return getisa(sess, docisaptr);
}

bool
getretrievedocvspanset(Session *sess, IStreamAddr *docisaptr)
{
    prompt(sess, "enter document=> ");
    return getisa(sess, docisaptr);
}

bool
getretrievedocvspan(Session *sess, IStreamAddr *docisaptr)
{
    prompt(sess, "enter document=> ");
    return getisa(sess, docisaptr);
}

bool
getrearrange(Session *sess, IStreamAddr *docisaptr, typecutseq *cutseqptr)
{
    prompt(sess, "enter document=> ");
    if (!getisa(sess, docisaptr))
        return false;

    prompt(sess, "enter cutseq=>\n");
    if (!getcutseq(sess, cutseqptr))
        return false;

    return true;
}

bool
getretrievev(Session *sess, typespecset *specsetptr)
{
    return getspecset(sess, specsetptr);
}

bool
getfindlinksfromtothree(Session *sess, typespecset *fromvspecsetptr, typespecset *tovspecsetptr,
                        typespecset *threevspecsetptr, typeispanset *homesetptr)
{
    prompt(sess, "fromset\n");
    if (!getspecset(sess, fromvspecsetptr))
        return false;

    prompt(sess, "toset\n");
    if (!getspecset(sess, tovspecsetptr))
        return false;

    prompt(sess, "threeset\n");
    if (!getspecset(sess, threevspecsetptr))
        return false;

    prompt(sess, "home documents\n");
    if (!getspanset(sess, homesetptr, ISPANID))
        return false;

    return true;
}

bool
getfindnumoflinksfromtothree(Session *sess, typespecset *fromvspecsetptr, typespecset *tovspecsetptr,
                             typespecset *threevspecsetptr, typeispanset *homesetptr)
{
    return getfindlinksfromtothree(sess, fromvspecsetptr, tovspecsetptr, threevspecsetptr, homesetptr);
}

bool
getfindnextnlinksfromtothree(Session *sess, typespecset *fromvspecsetptr, typespecset *tovspecsetptr,
                             typespecset *threevspecsetptr, typeispanset *homesetptr, IStreamAddr *lastlinkptr,
                             int *nptr)
{
    if (!getfindlinksfromtothree(sess, fromvspecsetptr, tovspecsetptr, threevspecsetptr, homesetptr))
        return false;

    prompt(sess, "last link=> ");
    if (!getisa(sess, lastlinkptr))
        return false;

    prompt(sess, "number of links => ");
    if (!getnumber(sess, nptr))
        return false;

    return true;
}

/* getnavigateonht */

bool
getshowrelationof2versions(Session *sess, typespecset *version1ptr, typespecset *version2ptr)
{
    prompt(sess, "version1\n");
    if (!getspecset(sess, version1ptr))
        return false;

    prompt(sess, "version2\n");
    if (!getspecset(sess, version2ptr))
        return false;

    return true;
}

void
getcreatenewdocument()
{
}

bool
getdeletevspan(Session *sess, IStreamAddr *docisaptr, typevspan *vspanptr)
{
    prompt(sess, "document=> ");
    if (!getisa(sess, docisaptr))
        return false;

    prompt(sess, "delete this part\n");
    if (!getspan(sess, vspanptr, VSPANID /* zzz */ ))
        return false;

    return true;
}

void
setdebug(Session *sess)
{
    prompt(sess, "set debug => ");
    getnumber(sess, &debug);
}

void
playwithalloc(Session *sess)
{
    prompt(sess, "playwithalloc\n");
    lookatalloc();
}

bool
getretrieveendsets(Session *sess, typespecset *specsetptr)
{
    return getspecset(sess, specsetptr);
}

bool
getxaccount(Session *sess, IStreamAddr *accountptr)
{
/* tumblerclear (accountptr); return true; */

/* prompt (sess, "account? "); */

    gettumbler(sess, accountptr) && validaccount(sess, accountptr);
    sess->account = *accountptr;

    fprintf(stderr, "in get xaccount \n");

    return true;
}

bool
getcreatenode_or_account(Session *sess, Tumbler *tp)
{
    gettumbler(sess, tp);
    return true;
}

bool
getopen(Session *sess, Tumbler *tp, int *typep, int *modep)
{

    gettumbler(sess, tp);
    getnumber(sess, typep);
    getnumber(sess, modep);

    return true;
}

bool
getclose(Session *sess, Tumbler *tp)
{
    gettumbler(sess, tp);

    return true;
}
