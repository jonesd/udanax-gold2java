/**********************************************************************
 * Copyright 2002 Jeff Rush <jrush@taupro.com>
 * Original Copyright 1979-2002 Udanax.com
 *
 * This file is part of the Udanax xanalogical storage system.
 *
 * Udanax is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * Udanax is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with Udanax; if not, write to the Free Software Foundation,
 * Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 **********************************************************************/

/**
 * @file  get2fe.cxx
 * @brief Udanax bottom-level input routines - front end version
 *
 * (to be defined)
 *
 **/

/* Modification History:
 * $Log: get2fe.cxx,v $
 * Revision 1.14  2002/07/26 04:33:47  jrush
 * Replaced gerror() with assert()
 *
 * Revision 1.13  2002/05/28 03:58:42  jrush
 * Sources modified to comply with GPL licensing.
 *
 * Revision 1.12  2002/04/16 22:39:50  jrush
 * Converted many #defines into enumeration types instead, and adjusted
 * function prototypes accordingly.
 *
 * Revision 1.11  2002/04/12 11:48:50  jrush
 * Major reorganization of includes into a single base-include style.
 *
 * Revision 1.10  2002/04/10 18:01:54  jrush
 * Renamed class typeisa to IStreamAddr.
 *
 * Revision 1.9  2002/04/09 21:45:47  jrush
 * Renamed class 'tumbler' to 'Tumbler', for consistency with Python sources,
 * and changed typeisa from typedef to a subclass, in preparation for cleaning
 * up the type/class tree.
 *
 * Revision 1.8  2002/04/06 20:42:50  jrush
 * Switch from sess->alloc() style to new(sess) Object parameterized allocator.
 *
 * Revision 1.7  2002/04/06 19:51:30  jrush
 * Renamed TRUE/FALSE constant use to the C++ standard of true/false.
 *
 * Revision 1.6  2002/04/06 17:05:57  jrush
 * Switched from referring to 'task' for a client connection to 'session',
 * and converted the typetask typedef/struct into a Session C++ class.
 *
 * Revision 1.5  2002/04/06 15:01:45  jrush
 * Changed INT to just 'int'.
 *
 * Revision 1.4  2002/02/14 10:08:25  jrush
 * Cleaned up source:
 *
 * 1. ran thru the indent tool to achieve a standard look,
 * 2. added structured comments at top for use with DOxygen reporting
 *    as well as CVS keywords,
 * 3. centralized prototypes in protos.h, removing incomplete ones,
 * 4. cleaned up use of bool/BOOLEAN type to suit C++ type,
 * 5. fixed initializer nesting in tumbler constants,
 * 6. converted select() int bits into ANSI fd_set type,
 * 7. added Makefile.am for use by automake.
 *
 */

#include <ctype.h>
#include "udanax.h"
#include "players.h"

#define WORDELIM '~'
#define TUMDELIM '.'
#define SPANFLAG 's'
#define VSPECFLAG 'v'
#define TEXTFLAG 't'

extern FILE *logfile;
extern FILE *nulllog;
extern FILE *reallog;

extern bool logstuff;
extern FILE *interfaceinput;
extern FILE *febelog;

bool  getnum(Session * sess, int * numptr);
bool  gettdigit(Session * sess, int * valueptr);
bool  getspan(Session * sess, typespan * spanptr, typeitemid id);
bool  getvspec(Session * sess, typevspec * vspecptr);
bool  getspanset(Session * sess, typespanset * spansetptr, typeitemid id);
bool  gettext(Session * sess, typetext * textptr);
bool  validrequest(Session * sess, typerequest request);
void  error(Session * sess, char *string);
void  frontenddied();

void
pushc(Session *sess, char c)
{
    if (sess->charinbuff)
        error(sess, "charbuff occupied\n");
    else {
        sess->charinbuff = true;
        sess->charbuff = c;
    }
}

char
pullc(Session *sess)
{
    int temp;

    if (sess->charinbuff) {
        sess->charinbuff = false;
        return sess->charbuff;

    } else {
        temp = getc(sess->inp);
        if (temp == EOF) {
            fprintf(stderr, "EOF on user %d in pullc\n", user);
            frontenddied();            /* does longjmp in backenddaemon, exit in backend */

            /* fprintf (stderr, "Premature end-of-file in backend\n"); diskexit (); // try to avoid screwing enf.enf //
 * assert(0); "pullc" */
        }

        temp &= 0x7f;
        if (logstuff && interfaceinput && interfaceinput != nulllog) {
            if (temp == WORDELIM)
                putc('\n', interfaceinput);
            else
                putc(temp, interfaceinput);
        }

        if (febelog && febelog != nulllog)
            putc(temp, febelog);
        return temp;
    }
}

bool
gettumbler(Session *sess, Tumbler *tumblerptr)
{
    char c;
    int i, num, value;

/* fprintf(sess->errp,"X gettumbler\n"); */
    tumblerclear(tumblerptr);
    getnum(sess, &num);
    tumblerptr->exp = -num;

    for (i = 0; gettdigit(sess, &value); i++) {
        if (i > NPLACES) {
            error(sess, "gettumbler overflow\n");
            return false;
        }
        tumblerptr->mantissa[i] = value;
    }
/* fprintf (logfile, " "); puttumbler (logfile, tumblerptr); */
    return (c = pullc(sess)) == WORDELIM || c == '\n';
}

bool
gettdigit(Session *sess, int *valueptr)
{
    char c;
    if ((c = pullc(sess)) != TUMDELIM) {
        pushc(sess, c);
        return (false);
    }
    return getnum(sess, valueptr);
}

bool
getnum(Session *sess, int *numptr)
{
/* fprintf(sess->errp,"X getnum\n"); */
    int num = 0;
    bool flag = false;

    char c;
    while ((c = pullc(sess)) /* && putc (c,sess->errp) */ &&isdigit(c)) {
        num = num * 10 + c - '0';
        flag = true;
    }

/* fprintf(sess->errp,"\n"); */
    pushc(sess, c);
    *numptr = num;
    return flag;
}

bool
getnumber(Session *sess, int *numptr)
{
    int num = 0;
    bool flag = false;

    char c;
    while ((c = pullc(sess)) && isdigit(c)) {
        num = num * 10 + c - '0';
        flag = true;
    }
    *numptr = num;
/* fprintf (logfile, " %d", *numptr); */
    return flag && (c == WORDELIM || c == '\n');
}

bool
eatchar(Session *sess, char c)
{
    metachar m;

    if ((m = pullc(sess)) != c) {
        pushc(sess, m);
        return false;
    } else
        return true;
}

bool
getspecset(Session *sess, typespecset *specsetptr)
{
    int num;
    char c, c1;
    typespecset specset;

    *specsetptr = NULL;
    if (!getnumber(sess, &num))
        return false;

    if (num == 0)
        return true;

    while (num--) {
        c = pullc(sess);
        if ((c != SPANFLAG) && (c != VSPECFLAG))
            return false;

/* mightn't work */ if ((c1 = pullc(sess)) != WORDELIM && c1 != '\n')
            return false;

        if (c == SPANFLAG) {
            specset = (typespecset) new(sess) typespan;
//            specset = (typespecset) sess->alloc(sizeof(typespan));
            if (!getspan(sess, (typespan *) specset, ISPANID))
                return false;
        } else {
            specset = (typespecset) new(sess) typevspec;
//            specset = (typespecset) sess->alloc(sizeof(typevspec));
            if (!getvspec(sess, (typevspec *) specset))
                return false;
        }

        *specsetptr = specset;
        specsetptr = (typespecset *) & ((typeitemheader *) specset)->next;
    }
    return true;
}

bool
getvspec(Session *sess, typevspec *vspecptr)
{
/* fprintf (logfile, " vspec"); fprintf (sess->errp, "X getvspec\n"); */
    vspecptr->itemid = VSPECID;
    vspecptr->next   = NULL;
    return gettumbler(sess, &vspecptr->docisa) && getspanset(sess, &vspecptr->vspanset, VSPANID);
}

bool
getspanset(Session *sess, typespanset *spansetptr, typeitemid id)
{
    typespanset spanset;
    int num;

/* fprintf (logfile, " spanset"); fprintf (sess->errp, "X getspanset\n"); */
    *spansetptr = NULL;
    if (!getnumber(sess, &num))
        return false;

/* fprintf (sess->errp, "X nspans %d\n", num); fprintf (logfile, " {"); */
    while (num--) {
        spanset = (typespanset) new(sess) typespan;
//        spanset = (typespanset) sess->alloc(sizeof(typespan));
        if (!getspan(sess, spanset, id))
            return (false);
        *spansetptr = spanset;
        spansetptr = &spanset->next;
    }
/* fprintf (logfile, " }"); */
    return true;
}

bool
getspan(Session *sess, typespan *spanptr, typeitemid id)
{
/* fprintf (logfile, " span"); fprintf (sess->errp, "X getspan\n"); */
    spanptr->itemid = id;
    spanptr->next = NULL;
    return gettumbler(sess, &spanptr->stream) && gettumbler(sess, &spanptr->width);
}

bool
getcutseq(Session *sess, typecutseq *cutseqptr)
{
    int ncuts, i;

/* fprintf (logfile, " cutseq"); */
    if (!(getnumber(sess, &ncuts) && (ncuts == 3 || ncuts == 4)))
        return false;

/* fprintf (logfile, " {"); */
    cutseqptr->numberofcuts = ncuts;

    for (i = 0; i < ncuts; ++i) {
        if (!gettumbler(sess, &cutseqptr->cutsarray[i]))
            return false;
    }
/* fprintf (logfile, " }"); */
    return true;
}

bool
gettextset(Session *sess, typetextset *textsetptr)
{
    typetextset textset;
    int num;

/* fprintf (logfile, " textset"); fprintf (sess->errp, "X gettextset\n"); */
    *textsetptr = NULL;
    if (!getnumber(sess, &num))
        return false;

/* fprintf (sess->errp, "X number of texts is %d\n", num); fprintf (logfile, " {"); */
    while (num--) {
        textset = (typetextset) new(sess) typetext;
//        textset = (typetextset) sess->alloc(sizeof(typetext));
        if (!gettext(sess, textset))
            return false;

        *textsetptr = textset;
        textsetptr = &textset->next;
    }
/* fprintf (logfile, " }"); */
    return true;
}

bool
gettext(Session *sess, typetext *textptr)
{
    int i;

/* fprintf (sess->errp, "X gettext\n"); */
    if (!(eatchar(sess, TEXTFLAG)
          && getnumber(sess, &textptr->length))) {
        fprintf(sess->errp, "\33[55;1fBackend receiving nothing in insert request.\n");
        return false;
    }
    textptr->itemid = TEXTID;
    textptr->next = NULL;

/* fprintf (logfile, " \""); */
    for (i = 0; i < textptr->length; ++i) {
        textptr->string[i] = pullc(sess);
/* fprintf (logfile, "%c", textptr->string[i]); */
    }

/* 
 * if (i != -1 && i != 0) { write (fileno(sess->errp), textptr->string,
 * textptr->length); fprintf(sess->errp, "FINIS\n"); } else fprintf
 * (sess->errp, "read failed\n"); */
/* if (! (eatchar (sess, WORDELIM) || eatchar (sess, '\n'))) return (false); REDUNDANT */
/* fprintf (logfile, "\""); */
    return i != -1 && i != 0;
}

bool
getrequest(Session *sess, typerequest *requestptr)
{
    char c;
    int num;
    bool flag;

/* fprintf (logfile, "\nrequest "); */
    sess->charinbuff = false;
/* 
 * return ( getnumber (sess, requestptr) && validrequest (sess,
 * *requestptr)); */
    num = 0;
    flag = false;
    while ((c = pullc(sess)) != 0) {
        fprintf(logfile, "%c", c);
        if (!isdigit(c))
            break;
        num = num * 10 + c - '0';
        flag = true;
    }
    *requestptr = num;
    return flag && (c == WORDELIM || c == '\n') && validrequest(sess, *requestptr);
}

bool
validrequest(Session *sess, typerequest request)
{
    if (request >= 0 && request < NREQUESTS && requestfns[request] != NULL)
        return true;
    else {
        fprintf(sess->errp, "invalid request: %d\n", request);
        return false;
    }
}

bool
validaccount(Session *sess, IStreamAddr *accountptr)
{
    return true;
}
