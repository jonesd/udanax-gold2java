/**********************************************************************
 * Copyright 2002 Jeff Rush <jrush@taupro.com>
 * Original Copyright 1979-2002 Udanax.com
 *
 * This file is part of the Udanax xanalogical storage system.
 *
 * Udanax is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * Udanax is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with Udanax; if not, write to the Free Software Foundation,
 * Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 **********************************************************************/

/**
 * @file  init.cxx
 * @brief ???
 *
 * (to be defined)
 *
 **/

/* Modification History:
 * $Log: init.cxx,v $
 * Revision 1.7  2002/05/28 03:58:42  jrush
 * Sources modified to comply with GPL licensing.
 *
 * Revision 1.6  2002/04/12 11:48:50  jrush
 * Major reorganization of includes into a single base-include style.
 *
 * Revision 1.5  2002/04/09 21:45:47  jrush
 * Renamed class 'tumbler' to 'Tumbler', for consistency with Python sources,
 * and changed typeisa from typedef to a subclass, in preparation for cleaning
 * up the type/class tree.
 *
 * Revision 1.4  2002/04/07 13:10:55  jrush
 * Relocated init.cxx from libsrc to server directory
 *
 * Revision 1.4  2002/04/06 17:05:57  jrush
 * Switched from referring to 'task' for a client connection to 'session',
 * and converted the typetask typedef/struct into a Session C++ class.
 *
 * Revision 1.3  2002/04/06 15:01:17  jrush
 * Changed INT to just 'int'.
 *
 * Revision 1.2  2002/02/14 09:27:43  jrush
 * Cleaned up source:
 *
 * 1. ran thru the indent tool to achieve a standard look,
 * 2. added structured comments at top for use with DOxygen reporting
 *    as well as CVS keywords,
 * 3. fixed compiler warnings re ambiguous assign/compares,
 *    needed casts and unused/uninitialized variables,
 * 4. fixed funcs that didn't specify a return type,
 * 5. centralized prototypes in protos.h, removing incomplete ones,
 * 6. cleaned up use of bool/BOOLEAN type to suit C++ type,
 * 7. fixed initializer nesting in tumbler constants,
 * 8. renamed vars that conflict with C++ keywords (new, this),
 * 9. fixed global/extern confusion re some global vars.
 *
 */

#include <time.h>
#include "udanax.h"
#include "requests.h"

extern FILE *febelog;
extern bool isxumain;
void (*requestfns[NREQUESTS]) (Session *sess);

long nsessorcommand;

void  putrequestfailed(Session * sess);

extern void finddocscontaining(Session *sess);
extern void copy(Session *sess);
extern void insert(Session *sess);
extern void createlink(Session *sess);
extern void followlink(Session *sess);
extern void retrievedocvspanset(Session *sess);
extern void rearrange(Session *sess);
extern void retrievev(Session *sess);
extern void findlinksfromtothree(Session *sess);
extern void findnumoflinksfromtothree(Session *sess);
extern void findnextnlinksfromtothree(Session *sess);
extern void navigateonht(Session *sess);
extern void showrelationof2versions(Session *sess);
extern void createnewdocument(Session *sess);
extern void createnewversion(Session *sess);
extern void retrievedocvspan(Session *sess);
extern void deletevspan(Session *sess);
extern void retrieveendsets(Session *sess);
extern void xaccount(Session *sess);
extern void createnode_or_account(Session *sess);
extern void myopen(Session *sess);
extern void myclose(Session *sess);
extern void quitxanadu(Session *sess);
extern void examine(Session *sess);
extern void showorgl(Session *sess);
extern void showenfilades(Session *sess);
extern void sourceunixcommand(Session *sess);

void
nullfun(Session * sess)
{
    putrequestfailed(sess);
}

void
init(bool safe)
{
/* Debugging stuff */

//UNUSED    long        start_time = time((long *) 0);
//UNUSED    struct tm  *tm         = gmtime(&start_time);

    int i;
    for (i = 0; i < NREQUESTS; ++i)
        requestfns[i] = nullfun;

    requestfns[COPY] = copy;
    requestfns[INSERT] = insert;
    requestfns[RETRIEVEDOCVSPANSET] = retrievedocvspanset;
    requestfns[REARRANGE] = rearrange;
    requestfns[RETRIEVEV] = retrievev;
    requestfns[NAVIGATEONHT] = navigateonht;
    requestfns[SHOWRELATIONOF2VERSIONS] = showrelationof2versions;
    requestfns[CREATENEWDOCUMENT] = createnewdocument;
    requestfns[DELETEVSPAN] = deletevspan;
    requestfns[CREATENEWVERSION] = createnewversion;
    requestfns[RETRIEVEDOCVSPAN] = retrievedocvspan;
    requestfns[QUIT] = quitxanadu;
    requestfns[SOURCEUNIXCOMMAND] = sourceunixcommand;
    requestfns[FOLLOWLINK] = followlink;
    requestfns[FINDDOCSCONTAINING] = finddocscontaining;
    requestfns[CREATELINK] = createlink;
    requestfns[RETRIEVEENDSETS] = retrieveendsets;
    requestfns[FINDNUMOFLINKSFROMTOTHREE] = findnumoflinksfromtothree;
    requestfns[FINDLINKSFROMTOTHREE] = findlinksfromtothree;
    requestfns[FINDNEXTNLINKSFROMTOTHREE] = findnextnlinksfromtothree;
    requestfns[CREATENODE_OR_ACCOUNT] = createnode_or_account;
    requestfns[OPEN] = myopen;
    requestfns[CLOSE] = myclose;
    requestfns[XACCOUNT] = xaccount;

    if (safe) {
        requestfns[SOURCEUNIXCOMMAND] = nullfun;
        requestfns[NAVIGATEONHT] = nullfun;
        requestfns[FINDNUMOFLINKSFROMTOTHREE] = nullfun;
        requestfns[FINDNEXTNLINKSFROMTOTHREE] = nullfun;
    }

    nsessorcommand = 0;
}
