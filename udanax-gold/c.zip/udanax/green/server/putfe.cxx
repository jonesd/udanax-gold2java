/**********************************************************************
 * Copyright 2002 Jeff Rush <jrush@taupro.com>
 * Original Copyright 1979-2002 Udanax.com
 *
 * This file is part of the Udanax xanalogical storage system.
 *
 * Udanax is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * Udanax is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with Udanax; if not, write to the Free Software Foundation,
 * Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 **********************************************************************/

/**
 * @file  putfe.cxx
 * @brief Udanax output routines - front end version
 *
 * (to be defined)
 *
 **/

/* Modification History:
 * $Log: putfe.cxx,v $
 * Revision 1.12  2002/07/26 04:33:47  jrush
 * Replaced gerror() with assert()
 *
 * Revision 1.11  2002/05/28 03:58:42  jrush
 * Sources modified to comply with GPL licensing.
 *
 * Revision 1.10  2002/04/12 11:48:51  jrush
 * Major reorganization of includes into a single base-include style.
 *
 * Revision 1.9  2002/04/10 18:01:54  jrush
 * Renamed class typeisa to IStreamAddr.
 *
 * Revision 1.8  2002/04/09 21:45:47  jrush
 * Renamed class 'tumbler' to 'Tumbler', for consistency with Python sources,
 * and changed typeisa from typedef to a subclass, in preparation for cleaning
 * up the type/class tree.
 *
 * Revision 1.7  2002/04/06 19:51:30  jrush
 * Renamed TRUE/FALSE constant use to the C++ standard of true/false.
 *
 * Revision 1.6  2002/04/06 17:05:57  jrush
 * Switched from referring to 'task' for a client connection to 'session',
 * and converted the typetask typedef/struct into a Session C++ class.
 *
 * Revision 1.5  2002/04/06 15:01:45  jrush
 * Changed INT to just 'int'.
 *
 * Revision 1.4  2002/02/14 10:08:25  jrush
 * Cleaned up source:
 *
 * 1. ran thru the indent tool to achieve a standard look,
 * 2. added structured comments at top for use with DOxygen reporting
 *    as well as CVS keywords,
 * 3. centralized prototypes in protos.h, removing incomplete ones,
 * 4. cleaned up use of bool/BOOLEAN type to suit C++ type,
 * 5. fixed initializer nesting in tumbler constants,
 * 6. converted select() int bits into ANSI fd_set type,
 * 7. added Makefile.am for use by automake.
 *
 */

#include <string.h>
#include "udanax.h"
#include "requests.h"

extern FILE *logfile;
extern FILE *nulllog;
extern FILE *reallog;

extern FILE *febelog = NULL;
bool firstputforrequest;

#define WORDELIM '~'
#define TUMDELIM '.'
#define SPANFLAG 's'
#define VSPECFLAG 'v'
#define TEXTFLAG 't'
#define FAILFLAG '?'

void  puttextset(Session * sess, typetext ** textptrptr);
void  putitem(Session * sess, typeitem * itemptr);
void  putspan(Session * sess, typespan * spanptr);
void  puttext(Session * sess, typetext * textptr);
void  putspanpair(Session * sess, typespanpair * spanpair);
void  frontenddied();

/* #define xuputc(c,fd) putc ((c), (fd)) */

void
xuputc(char c, FILE * fd)
{
    if (putc(c, fd) == EOF) {
        perror("xuputc");
        frontenddied();
    } else if (febelog && febelog != nulllog) {
        if (firstputforrequest)
            fprintf(febelog, "\nbe:\n");
        firstputforrequest = false;
        putc(c, febelog);
    }

}

void
xuputstring(char *string, FILE * fd)
{
/* while (*string) xuputc (*string++, fd); */
    fwrite(string, 1, strlen(string), fd);
}

void
putnum(FILE * outfile, int num)
{
    char digits[32];
    int i;

    if (num == 0)
        xuputc('0', outfile);
    else {
        if (num < 0) {
            num = -num;
            xuputc('-', outfile);
        }
        for (i = 0; num != 0;) {
            digits[i++] = (char)(num % 10 + (int) '0');
            num /= 10;
        }
        while (i > 0)
            xuputc(digits[--i], outfile);
    }
}

void
sendresultoutput(Session * session)
{
/* FILE *fd; fd = session->outp; write (fd->_file, fd->_base, (int) (fd->_ptr - fd->_base)); fd->_ptr = fd->_base;
 * fd->_cnt = BUFSIZ; */
    fflush(session->outp);
}

void
error(Session * session, char *string)
{
    xuputstring(string, session->errp);
}

void
prompt(Session * session, char *string)
{
    xuputstring(string, session->outp);
}

void
putnumber(FILE * outfile, int num)
{
    putnum(outfile, num);
    xuputc(WORDELIM, outfile);
}

void
puttumbler(FILE * outfile, Tumbler * tumblerptr)
{
    int i, place;

    putnum(outfile, -tumblerptr->exp);
    place = NPLACES;
    do {
        --place;
    } while (place > 0 && tumblerptr->mantissa[place] == 0);
    for (i = 0; i <= place; ++i) {
        xuputc(TUMDELIM, outfile);
        putnum(outfile, (int) tumblerptr->mantissa[i]);
    }
    xuputc(WORDELIM, outfile);
}

void
putisa(Session * session, IStreamAddr * isaptr)
{
    puttumbler(session->outp, isaptr);
}

void
putitemset(Session * session, typeitemset itemset)
{
    int i;
    typeitemset temp;

    for (temp = itemset, i = 0; temp; temp = (typeitemset) ((typeitemheader *) temp)->next, ++i) {
        while (((typeitemheader *) temp)->itemid == TEXTID && ((typeitemheader *) temp)->next
               && ((typeitemheader *) temp)->next->itemid == TEXTID)
            temp = (typeitemset) ((typeitemheader *) temp)->next;       /* count lots of textitems as one item */
    }
    putnumber(session->outp, i);
/* fprintf (session->errp, "X putitemset nitems is %d\n", i); */
    for (; itemset; itemset = (typeitemset) ((typeitemheader *) itemset)->next) {
        if (((typeitemheader *) itemset)->itemid == TEXTID)
            puttextset(session, (typetext **) & itemset);
        else
            putitem(session, itemset);
    }
}

void
putitem(Session * session, typeitem * itemptr)
{
    FILE *outfile;

    outfile = session->outp;
    switch (((typeitemheader *) itemptr)->itemid) {
    case ISPANID:
        xuputc(SPANFLAG, outfile);
        xuputc(WORDELIM, outfile);
        putspan(session, (typespan *) itemptr);
        break;
    case VSPANID:
        putspan(session, (typespan *) itemptr);
        break;
    case VSPECID:
        xuputc(VSPECFLAG, outfile);
        xuputc(WORDELIM, outfile);
        puttumbler(outfile, &((typevspec *) itemptr)->docisa);
        putitemset(session, (typeitemset) ((typevspec *) itemptr)->vspanset);
        break;
    case TEXTID:
/* fprintf (session->errp, "X put text %d characters\n",itemptr->length); */
        puttext(session, (typetext *) itemptr);
        break;
    case ADDRESSID:
/* 
 * fprintf (session->errp, "X put address "); puttumbler (session->errp,
 * &itemptr->address); fprintf(session->errp, "\n"); */
        puttumbler(outfile, &((typeaddress *) itemptr)->address);
        break;

    default:
        error(session, "illegal item id for senditem");
        return;
    }
}

void
putspan(Session * session, typespan * spanptr)
{
    fprintf(logfile, "putspan\n");
    puttumbler(session->outp, &spanptr->stream);
    puttumbler(session->outp, &spanptr->width);
}

void
puttextset(Session * session, typetext ** textptrptr)
{
    typetext *textptr, *last;
    int i;

    for (i = 0, textptr = *textptrptr; textptr && textptr->itemid == TEXTID; textptr = textptr->next) {
        i += textptr->length;
    }
    xuputc(TEXTFLAG, session->outp);
    putnumber(session->outp, i);
    last = NULL;
    for (textptr = *textptrptr; textptr && textptr->itemid == TEXTID; textptr = textptr->next) {
        for (i = 0; i < textptr->length; ++i)
            xuputc(textptr->string[i], session->outp);
        last = textptr;
    }
    *textptrptr = last;
}

void
puttext(Session * session, typetext * textptr)
{
    int i;

    fprintf(logfile, "puttext\n");
/* fprintf (session->errp, "X puttext %d characters\n", textptr->length); */
    xuputc(TEXTFLAG, session->outp);
    putnumber(session->outp, textptr->length);

/* write (fileno(session->outp), textptr->string, textptr->length); */
    for (i = 0; i < textptr->length; ++i)
        xuputc(textptr->string[i], session->outp);
}

void
putspanpairset(Session * session, typespanpairset spanpairset)
{
    typespanpair *ptr;
    int n;

    for (n = 0, ptr = spanpairset; ptr; ++n, ptr = ptr->nextspanpair) ;
    putnumber(session->outp, n);
    for (; spanpairset; spanpairset = spanpairset->nextspanpair)
        putspanpair(session, spanpairset);
}

void
putspanpair(Session * session, typespanpair * spanpair)
{
    puttumbler(session->outp, &spanpair->stream1);
    puttumbler(session->outp, &spanpair->stream2);
    puttumbler(session->outp, &spanpair->widthofspan);
}

/* ---------------- top level put routines --------------- */

void
putinsert(Session * session)
{
    putnumber(session->outp, INSERT);
}

void
putretrievedocvspanset(Session * session, typespanset * spansetptr)
{
    putnumber(session->outp, RETRIEVEDOCVSPANSET);
    putitemset(session, (typeitemset) * spansetptr);
}

void
putcopy(Session * session)
{
    putnumber(session->outp, COPY);
}

void
putrearrange(Session * session)
{
    putnumber(session->outp, REARRANGE);
}

void
putcreatelink(Session * session, IStreamAddr * istreamptr)
{
    putnumber(session->outp, CREATELINK);
    putisa(session, istreamptr);
}

void
putretrievev(Session * session, typevstuffset * vstuffsetptr)
{
/* fprintf (session->errp, "X putretrievev\n"); */
    putnumber(session->outp, RETRIEVEV);
    putitemset(session, (typeitemset) * vstuffsetptr);
}

void
putfindnumoflinksfromtothree(Session * session, int num)
{
    putnumber(session->outp, FINDNUMOFLINKSFROMTOTHREE);
    putnumber(session->outp, num);
}

void
putfindlinksfromtothree(Session * session, typelinkset linkset)
{
    fprintf(logfile, "putfindlinksfromtothree\n");
    putnumber(session->outp, FINDLINKSFROMTOTHREE);
    putitemset(session, (typeitemset) linkset);
}

void
putfindnextnlinksfromtothree(Session * session, int n, typelinkset nextlinkset)
{
/* fprintf (session->errp, "X putfindnextnlinksfromtothree\n"); */
    putnumber(session->outp, FINDNEXTNLINKSFROMTOTHREE);
    putitemset(session, (typeitemset) nextlinkset);
}

/* historical trace */

void
putshowrelationof2versions(Session * session, typespanpairset relation)
{
    putnumber(session->outp, SHOWRELATIONOF2VERSIONS);
    putspanpairset(session, relation);
}

void
putcreatenewdocument(Session * session, IStreamAddr * newdocisaptr)
{
/* 
 * fprintf (session->errp, "X new document created "); puttumbler
 * (session->errp, newdocisaptr); fprintf (session->errp, "\n"); */
    putnumber(session->outp, CREATENEWDOCUMENT);
    putisa(session, newdocisaptr);
}

void
putdeletevspan(Session * session)
{
    putnumber(session->outp, DELETEVSPAN);
}

void
putcreatenewversion(Session * session, IStreamAddr * newdocisaptr)
{
    putnumber(session->outp, CREATENEWVERSION);
    putisa(session, newdocisaptr);
}

void
putretrievedocvspan(Session * session, typespan * vspanptr)
{
    putnumber(session->outp, RETRIEVEDOCVSPAN);
    putspan(session, vspanptr);
}

/* set debug */

/* disk exit */

/* show enfilades */

void
putfollowlink(Session * session, typespecset specset)
{
    putnumber(session->outp, FOLLOWLINK);
    putitemset(session, (typeitemset) specset);
}

/* examine */

/* source unix command */

void
putfinddocscontaining(Session * session, typeitemset addressset)
{
/* fprintf (session->errp, "X putfinddocscontaining\n"); */
    putnumber(session->outp, FINDDOCSCONTAINING);
    putitemset(session, addressset);
}

void
putretrieveendsets(Session * session, typespecset fromset, typespecset toset, typespecset threeset)
{
    putnumber(session->outp, RETRIEVEENDSETS);
    putitemset(session, (typeitemset) fromset);
    putitemset(session, (typeitemset) toset);
    putitemset(session, (typeitemset) threeset);
}

void
putrequestfailed(Session * session)
{
    //assert(0); // putrequestfailed
    xuputc(FAILFLAG, session->outp);
}

void
putxaccount(Session * session)
{
    putnumber(session->outp, XACCOUNT);
}

void
putcreatenode_or_account(Session * session, Tumbler * tp)
{
    putnumber(session->outp, CREATENODE_OR_ACCOUNT);
    puttumbler(session->outp, tp);
}

void
putopen(Session * session, Tumbler * tp)
{
    putnumber(session->outp, OPEN);
    puttumbler(session->outp, tp);
}

void
putclose(Session * session)
{
    putnumber(session->outp, CLOSE);
}

void
putquitxanadu(Session * session)
{
    putnumber(session->outp, QUIT);
}
