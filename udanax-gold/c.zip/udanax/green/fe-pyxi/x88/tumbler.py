#!/usr/bin/env python2

import string
from types import StringType

def _cmpid(a, b):
    """Compare two objects by their Python id."""
    if id(a) > id(b): return 1
    if id(a) < id(b): return -1
    return 0

class Tumbler:
    """A numbering system that permits addressing within documents
    so that material may be inserted at any point without renumbering."""

    def __init__(self, *args):
        """Construct from a list of tumbler digits or a string."""

        if len(args) == 1 and type(args[0]) is StringType:
            self.digits = map(string.atol, string.split(args[0], "."))
        else:
            if len(args) == 1 and type(args[0]) is type([]):
                digits = args[0]
            else:
                digits = list(args)
            for digit in digits:
                if type(digit) not in [type(1), type(1L)]:
                    raise TypeError, repr(digits) + "is not a string or list of integers"

            self.digits = map(long, digits)

    def __repr__(self):
        """Return a Python expression which will reconstruct this tumbler."""
        return self.__class__.__name__ + \
            "(" + string.join(map(str, self.digits), ", ") + ")"

    def __str__(self):
        """Return the period-separated string representation of the tumbler."""
        return string.join(map(str, self.digits), ".")

    def __getitem__(self, index):
        return self.digits[index]

    def __len__(self):
        return len(self.digits)

    def __nonzero__(self):
        for digit in self.digits:
            if digit != 0: return 1
        return 0

    def __add__(self, other):
        for i in range(len(self)):
            if other[i] != 0:
                return Tumbler(self.digits[:i] + [self[i] + other[i]] + other.digits[i+1:])

        for i in range(len(self), len(other)):
            if other[i] != 0:
                return Tumbler(self.digits + other.digits[len(self):])

        return Tumbler(self.digits)

    def __sub__(self, other):
        for i in range(min(len(self), len(other))):
            if self[i] < other[i]:
                raise ValueError, "%s is larger than %s" % (other, self)
            if self[i] > other[i]:
                return Tumbler([0] * i + [self[i] - other[i]] + self.digits[i+1:])

        if len(self) < len(other):
            raise ValueError, "%s is larger than %s" % (other, self)

        if len(self) > len(other):
            return Tumbler([0] * len(other) + self.digits[len(other):])

        return NOWIDTH

    def __cmp__(self, other):
        """Compare two address tumblers or offset tumblers."""

        if not isinstance(other, Tumbler):
            return _cmpid(self, other)

        for i in range(min(len(self), len(other))):
            if self[i] > other[i]: return 1
            if self[i] < other[i]: return -1

        if len(other) > len(self): return 1
        if len(other) < len(self): return -1
        return 0

    def __hash__(self):
        return hash(str(self))

    def write(self, stream):
        """Write a tumbler to an 88.1 protocol stream."""

        exp = 0
        for exp in range(len(self.digits)):
            if self.digits[exp] != 0:
                break

        dump = "%d" % exp
        for digit in self.digits[exp:]:
            dump = dump + "." + str(digit)

        stream.write(dump + "~")

def Tumbler_read(stream, prefix=""):
    """Read a tumbler from an 88.1 protocol stream."""

    chunk = prefix + stream.readchunk()
    digits = map(string.atol, string.split(chunk, "."))
    if not digits:
        raise ValueError, "exponent missing in tumbler read"

    digits[:1] = [0L] * int(digits[0])
    return Tumbler(digits)

# ----------------------------------------------------------------- Address
class Address(Tumbler):
    """An address within the Udanax object space.  Immutable."""

    def __add__(self, offset):
        """Add an offset to a tumbler."""

        if not isinstance(offset, Offset):
            raise TypeError, "%s is not an offset" % repr(offset)

        return Address(Tumbler.__add__(self, offset).digits)

    def __sub__(self, address):
        """Subtract a tumbler from another tumbler to get an offset."""

        if not isinstance(address, Address):
            raise TypeError, "%s is not an address" % repr(address)

        return Offset(Tumbler.__sub__(self, address).digits)

    def split(self):
        """For a global address, return the docid and local components."""

        delim = len(self.digits) - 1

        while self.digits[delim] != 0:
            delim = delim - 1

        return Address(self.digits[:delim]), Address(self.digits[delim+1:])

    def globalize(self, other):
        """Return an global address given a local address into this one, a
        global width given a local width, or global span given a local span."""

        if isinstance(other, Address):
            return Address(self.digits + [0] + other.digits)

        if isinstance(other, Offset):
            return Offset([0] * len(self.digits) + [0] + other.digits)

        if isinstance(other, Span):
            return Span(self.globalize(other.start), self.globalize(other.width))

        raise TypeError, "%s is not an address, offset, or span" % repr(other)

    def localize(self, other):
        """Return a local address given a global address under this one, a
        local width given a global width, or local span given a global span."""

        if isinstance(other, Address):
            if len(other) > len(self) and self.digits[:len(self)] + [0] == other.digits[:len(self)+1]:
                return Address(other.digits[len(self)+1:])
            else:
                raise ValueError, "%s is not within %s" % (other, self)

        if isinstance(other, Offset):
            if [0] * len(self) + [0] == other.digits[:len(self)+1]:
                return Offset(other.digits[len(self)+1:])
            else:
                raise ValueError, "%s extends outside of %s" % (other, self)

        if isinstance(other, Span):
            return Span(self.localize(other.start), self.localize(other.width))

        raise TypeError, "%s is not an address, offset, or span" % repr(other)

def Address_read(stream, prefix=""):
    """Read a tumbler address from an 88.1 protocol stream."""

    return Address(Tumbler_read(stream, prefix).digits)

# ------------------------------------------------------------------ Offset
class Offset(Tumbler):
    """An offset between addresses in the Udanax object space.  Immutable."""

    def __add__(self, offset):
        """Add an offset to an offset."""

        if not isinstance(offset, Offset):
            raise TypeError, "%s is not an offset" % repr(offset)

        return Offset(Tumbler.__add__(self, offset).digits)

    def __sub__(self, offset):
        """Subtract a tumbler from another tumbler to get an offset."""

        if not isinstance(offset, Offset):
            raise TypeError, "%s is not an offset" % repr(offset)

        return Offset(Tumbler.__sub__(self, offset).digits)

def Offset_read(stream):
    """Read a tumbler offset from an 88.1 protocol stream."""
    return Offset(Tumbler_read(stream).digits)

# --------------------------------------------------------------- constants

NOWHERE = Address()
NOWIDTH = Offset()

if __name__ == "__main__":
    pass

