"""An object-based API to the Udanax 88.1 FeBe protocol."""

import sys, os, string, socket
from spec import *

class XuError(Exception):
    pass

# --------------------------------------------------------------- XuSession
class XuSession:
    """A session conversing with an Udanax back-end server across an x88
    connection object.  The XuConn must have been just freshly created.
    (We don't create the XuConn here to allow the application to supply
    an instance of a customized subclass of XuConn if it so desires.)"""

    def __init__(self, conn):
        self.xc = conn
        self.xc.handshake()
        self.open = 1

    def __repr__(self):
        if self.open:  return "<XuSession on %s>" % repr(self.xc.stream)
        else:          return "<XuSession terminated>"

    # creation and access

    def create_document(self):
        self.xc.command(11)
        return self.xc.Address()

    def create_version(self, docid):
        self.xc.command(13, docid)
        return self.xc.Address()

    def open_document(self, docid, access, copy):
        print str(docid)
        self.xc.command(35, docid, access, copy)
        return self.xc.Address()

    def close_document(self, docid):
        self.xc.command(36, docid)

    def create_link(self, docid, sourcespecs, targetspecs, typespecs):
        self.xc.command(27, docid, sourcespecs, targetspecs, typespecs)
        return self.xc.Address()

    # content retrieval

    def retrieve_vspan(self, docid):
        self.xc.command(14, docid)
        return VSpan(docid, self.xc.Span())

    def retrieve_vspanset(self, docid):
        self.xc.command(1, docid)
        spans = []
        for i in range(self.xc.Number()):
            spans.append(self.xc.Span())
        return VSpec(docid, spans)

    def retrieve_contents(self, specset):
        self.xc.command(5, specset)
        data = []
        for i in range(self.xc.Number()):
            data.append(self.xc.Content())
        return data

    def retrieve_endsets(self, specset):
        self.xc.command(28, specset)
        sourcespecs = self.xc.SpecSet()
        targetspecs = self.xc.SpecSet()
        typespecs = self.xc.SpecSet()
        return sourcespecs, targetspecs, typespecs

    # connection retrieval

    def find_links(self, sourcespecs, targetspecs=NOSPECS, typespecs=NOSPECS, homedocids=[]):
        self.xc.command(30, sourcespecs, targetspecs, typespecs, homedocids)
        links = []
        for i in range(self.xc.Number()):
            links.append(self.xc.Address())
        return links
    
    def follow_link(self, linkid, linkend):
        try:
            self.xc.command(18, linkend, linkid)
        except XuError:
            return NOSPECS
        else:
            return self.xc.SpecSet()

    def compare_versions(self, specseta, specsetb):
        self.xc.command(10, specseta, specsetb)
        sharedspans = []
        for i in range(self.xc.Number()):
            starta, startb = self.xc.Address(), self.xc.Address()
            width = self.xc.Offset()
            doca, locala = starta.split()
            docb, localb = startb.split()
            sharedspans.append(VSpan(doca, Span(locala, width)),
                               VSpan(docb, Span(localb, width)))
        return _collapse_sharedspans(sharedspans)

    def find_documents(self, specset):
        self.xc.command(22, specset)
        docids = []
        for i in range(self.xc.Number()):
            docids.append(self.xc.Address())
        return docids

    # editing

    def insert(self, docid, vaddr, strings):
        self.xc.command(0, docid, vaddr, strings)

    def vcopy(self, docid, vaddr, specset):
        self.xc.command(2, docid, vaddr, specset)

    def delete(self, docid, start, end):
        self.xc.command(3, docid, [start, end])

    def pivot(self, docid, start, pivot, end):
        self.xc.command(3, docid, [start, pivot, end])

    def swap(self, docid, starta, enda, startb, endb):
        self.xc.command(3, docid, [starta, enda, startb, endb])

    def remove(self, docid, vspan):
        self.xc.command(12, docid, vspan)

    # session control

    def quit(self):
        self.xc.command(16)
        self.xc.close()
        self.open = 0

    # administration

    def account(self, acctid):
        assert isinstance(acctid, Address)
        self.xc.command(34, acctid)

    def create_node(self, acctid):
        assert isinstance(acctid, Address)
        self.xc.command(38, acctid)
        return self.xc.Address()

def _collapse_sharedspans(sharedspans):
    """The results of a comparison are sometimes returned from the back-end
    with several adjacent spans that could be collapsed into a single span.
    This routine tries to work around that limitation."""
    result = []
    enda, endb = None, None
    for spana, spanb in sharedspans:
        starta, startb = spana.start(), spanb.start()
        width = spana.span.width
        doca, locala = spana.docid, spana.span.start
        docb, localb = spanb.docid, spanb.span.start
        if starta == enda and startb == endb: # collapse with last span
            width = lastwidth + width
            spana = VSpan(doca, Span(lastlocala, width))
            spanb = VSpan(docb, Span(lastlocalb, width))
            result[-1:] = [(spana, spanb)]
        else:
            lastlocala, lastlocalb = locala, localb
            spana = VSpan(doca, Span(locala, width))
            spanb = VSpan(docb, Span(localb, width))
            result.append((spana, spanb))
        enda, endb = spana.end(), spanb.end()
        lastwidth = width
    return result
