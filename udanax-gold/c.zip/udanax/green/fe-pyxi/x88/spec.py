import sys, os, string, socket

from tumbler import Address
from span    import Span, VSpan

def Number_write(data, stream):
    """Write a number to an 88.1 protocol stream."""

    stream.write("%d~" % data)

def Number_read(stream):
    """Read a number from an 88.1 protocol stream."""

    number = 0
    chunk = stream.readchunk()
    return string.atoi(chunk)

# ------------------------------------------------------------------- VSpec
class VSpec:
    """A set of ranges within a given document.  Immutable."""

    def __init__(self, docid, spans):
        """Construct from a document address and a list of spans."""

        if not isinstance(docid, Address):
            raise TypeError, "%s is not a tumbler address" % repr(docid)

        if type(spans) not in (type([]), type(())):
            raise TypeError, "%s is not a sequence of spans" % repr(spans)

        for span in spans:
            if not isinstance(span, Span):
                raise TypeError, "%s is not a sequence of spans" % repr(spans)

        self.docid = docid
        spanlist   = list(spans)
        spanlist.sort()
        self.spans = tuple(spanlist)

    def __repr__(self):
        return "VSpec(" + repr(self.docid) + ", " + repr(self.spans) + ")"

    def __str__(self):
        spans = []
        for span in self.spans:
            spans.append(", at %s for %s" % (span.start, span.width))

        return "<VSpec in " + str(self.docid) + string.join(spans, "") + ">"

    def __getitem__(self, index):
        return VSpan(self.docid, self.spans[index])

    def __len__(self):
        return len(self.spans)

    def __cmp__(self, other):
        """Compare two vspans (first by document address, then by span)."""

        cmp = self.docid.__cmp__(other.docid)
        if cmp != 0:
            return cmp

        for i in range(min(len(self), len(other))):
            cmp = self.spans[i].__cmp__(other.spans[i])
            if cmp != 0:
                return cmp

        if len(self) > len(other): return 1
        if len(self) < len(other): return -1
        return 0

    def __hash__(self):
        return hash((self.docid, self.spans))

    def contains(self, spec):
        """Return true if the given spec lies entirely within this spec."""

        for vspan in self:
            if vspan.contains(spec): return 1
        return 0

    def write(self, stream):
        """Write a vspec to an 88.1 protocol stream."""

        self.docid.write(stream)
        Number_write(len(self.spans), stream)
        for span in self.spans:
            span.write(stream)

def VSpec_read(stream):
    """Read a vspec from an 88.1 protocol stream."""

    docid = Address_read(stream)
    nspans = Number_read(stream)
    spans = []
    for j in range(nspans):
        spans.append(Span_read(stream))
    return VSpec(docid, spans)

# ----------------------------------------------------------------- SpecSet
class SpecSet:
    """A possibly discontinuous set of Udanax objects.  Mutable."""

    def __init__(self, *args):
        """Construct from a list of spans or vspecs."""

        if len(args) > 0 and type(args[0]) is type([]):  specs = args[0]
        else:                                            specs = list(args)

        self.specs = []
        for spec in specs:
            if isinstance(spec, Span) or isinstance(spec, VSpec):
                self.specs.append(spec)
            elif isinstance(spec, VSpan):
                self.specs.append(VSpec(spec.docid, [spec.span]))
            else:
                raise TypeError, "%s is not a list of specs" % repr(args)

    def __repr__(self):
        return "SpecSet(" + repr(self.specs) + ")"

    def __str__(self):
        return "<SpecSet [" + string.join(map(str, self.specs), ", ") + "]>"

    def __len__(self):
        return len(self.specs)

    def __getitem__(self, index):
        return self.specs[index]

    def __cmp__(self, other):
        """Compare two specsets (stably, but only useful for equality)."""

        for i in range(min(len(self.specs), len(other.specs))):
            cmp = self[i].__cmp__(other[i])
            if cmp != 0: return cmp

        if len(self) > len(other): return 1
        if len(self) < len(other): return -1
        return 0

    def clear(self):
        self.specs = []

    def append(self, spec):
        if not isinstance(spec, Span) and not isinstance(spec, VSpec):
            raise TypeError, "%s is not a span or a vspec" % spec

        self.specs.append(spec)
        
    def write(self, stream):
        """Write a specset to an 88.1 protocol stream."""

        stream.write("%d~" % (len(self.specs)))
        for spec in self.specs:
            if isinstance(spec, Span):
                stream.write("s~")
                spec.write(stream)

            elif isinstance(spec, VSpec):
                stream.write("v~")
                spec.write(stream)

def SpecSet_read(stream):
    """Read a specset from an 88.1 protocol stream."""

    nspecs = Number_read(stream)
    specs = []
    for i in range(nspecs):
        ch = stream.read(2)
        if ch[1] not in "~\n":
            raise ValueError, "bad char \\x%x in specset read" % ord(ch[1])

        if ch[0] == "s":
            specs.append(Span_read(stream))
        elif ch[0] == "v":
            specs.append(VSpec_read(stream))
        else:
            raise ValueError, "bad flag \\x%x in specset read" % ord(ch[1])

    return SpecSet(specs)

# --------------------------------------------------------------- constants
NOSPECS = SpecSet( [] )
