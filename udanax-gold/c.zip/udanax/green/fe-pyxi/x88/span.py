import sys, os, string, socket

from tumbler import *

def _cmpid(a, b):
    """Compare two objects by their Python id."""
    if id(a) > id(b): return 1
    if id(a) < id(b): return -1
    return 0

# -------------------------------------------------------------------- Span
class Span:
    """A range of Udanax objects in the global address space.  Immutable."""

    def __init__(self, start, other):
        """Construct from either a starting and ending address, or
        a starting address and a width offset."""

        if not isinstance(start, Address):
            raise TypeError, "%s is not an address" % repr(start)

        self.start = start
        if isinstance(other, Address):   self.width = other - start
        elif isinstance(other, Offset):  self.width = other
        else:
            raise TypeError, "%s is not an address or offset" % repr(other)

    def __repr__(self):
        return "Span(" + repr(self.start) + ", " + repr(self.width) + ")"

    def __str__(self):
        return "<Span at " + str(self.start) + " for " + str(self.width) + ">"

    def __len__(self):  
        return self.width

    def __nonzero__(self):
        return self.width and 1 or 0

    def __cmp__(self, other):
        """Compare two spans (first by starting address, then by width)."""

        if not isinstance(other, Span):
            return _cmpid(self, other)

        cmp = self.start.__cmp__(other.start)

        if cmp != 0:
            return cmp

        return self.width.__cmp__(other.width)

    def __hash__(self):
        return hash((self.start, self.width))

    def __and__(self, span):
        """Return the intersection of this span with another span."""

        if isinstance(span, VSpan):
            span = span.globalize()
        elif not isinstance(span, Span):
            raise TypeError, "%s is not a span" % repr(span)

        if self.start in span:
            if self.end in span:  return Span(self.start, self.width)
            else:                 return Span(self.start, span.end())

        elif self.end() in span:  return Span(span.start, self.end())
        elif span.start in self:  return Span(span.start, span.width)
        else:                     return Span(NOWHERE, NOWIDTH)

    def contains(self, spec):
        """Return true if the given spec lies entirely within this span."""

        if   isinstance(spec, Address):  return self.start <= spec < self.end()
        elif isinstance(spec, Span):     return self.start <= spec.start <= spec.end() <= self.end()
        elif isinstance(spec, VSpan):    return self.contains(spec.globalize())
        else:
            raise TypeError, "%s is not an address or span" % repr(spec)

    def write(self, stream):
        """Write a span to an 88.1 protocol stream."""

        self.start.write(stream)
        self.width.write(stream)

    def end(self):
        """Return the first address after the start not in this span."""

        return self.start + self.width

    def localize(self):
        """Return this span as a vspan within one document."""

        docid, local = self.start.split()
        return VSpan(docid, docid.localize(self))

def Span_read(stream):
    """Read a span from an 88.1 protocol stream."""

    start = Address_read(stream)
    width = Offset_read(stream)
    return Span(start, width)

# ------------------------------------------------------------------- VSpan
class VSpan:
    """A range within a given document.  Immutable."""

    def __init__(self, docid, span):
        """Construct from a document id and a local span."""

        if not isinstance(docid, Address):
            raise TypeError, "%s is not a document address" % repr(docid)

        if not isinstance(span, Span):
            raise TypeError, "%s is not a span" % repr(span)

        self.docid = docid
        self.span = span

    def __repr__(self):
        return "VSpan(" + repr(self.docid) + ", " + repr(self.span) + ")"

    def __str__(self):
        return "<VSpan in %s at %s for %s>" % (self.docid, self.span.start, self.span.width)

    def __cmp__(self, other):
        """Compare two vspans (first by document address, then by span)."""

        if not isinstance(other, VSpan):
            return _cmpid(self, other)

        cmp = self.docid.__cmp__(other.docid)
        if cmp != 0:
            return cmp

        return self.span.__cmp__(other.span)

    def __hash__(self):
        return hash((self.docid, self.span))

    def __and__(self, span):
        """Return the intersection of this span with another span."""

        return self.globalize() & span
    
    def start(self):
        return self.docid.globalize(self.span.start)

    def end(self):
        return self.docid.globalize(self.span.end())

    def contains(self, spec):
        """Return true if the given spec lies entirely within this span."""

        return self.globalize().contains(spec)

    def globalize(self):
        """Return this vspan as a span with a global starting address
        and width within this document."""

        return Span(self.docid.globalize(self.span.start),
                    self.docid.globalize(self.span.width))
