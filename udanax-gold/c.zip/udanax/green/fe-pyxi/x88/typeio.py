"""An object-based API to the Udanax 88.1 FeBe protocol."""

from tumbler import Address_read
from span    import Span_read
from spec    import SpecSet_read

from types import StringType, IntType, LongType, TupleType, ListType

class XuError(Exception):
    pass

import sys, os, string, socket

def Number_write(data, stream):
    """Write a number to an 88.1 protocol stream."""

    stream.write("%d~" % data)

def Number_read(stream):
    """Read a number from an 88.1 protocol stream."""

    number = 0
    chunk = stream.readchunk()
    return string.atoi(chunk)

def String_write(data, stream):
    """Write a string to an 88.1 protocol stream."""

    stream.write("t%d~" % len(data))
    stream.write(data)

def String_read(stream):
    """Read a string from an 88.1 protocol stream."""

    ch = stream.read(1)
    if ch != "t":
        raise ValueError, "starting flag missing in string read"

    length = Number_read(stream)
    return stream.read(length)

def Content_read(stream):
    """Read a string or a link from an 88.1 protocol stream."""

    ch = stream.read(1)
    if ch == "t":
        length = Number_read(stream)
        return stream.read(length)
    elif ch in string.digits:
        return Address_read(stream, ch)
    else:
        raise ValueError, "bad char \\x%x in content read" % ord(ch)

# ------------------------------------------------------------------ XuConn
class XuConn:
    """Methods for sending and receiving objects on a stream.  The
    stream must implement the three methods read, write, and close."""

    def __init__(self, stream):
        self.stream = stream

    def __repr__(self):
        return "<XuConn on %s>" % repr(self.stream)

    # protocol

    def handshake(self):
        """Perform the FeBe protocol handshake to open a session."""
        self.stream.write("\nP0~")
        while 1:
            if self.stream.read(1) == "\n": break
        if self.stream.read(2) != "P0":
            raise ValueError, "back-end does not speak 88.1 protocol"
        if self.stream.read(1) not in "~\n":
            raise ValueError, "back-end does not speak 88.1 protocol"

    def close(self):
        self.stream.close()

    # reading and writing objects

    def Number(self): return Number_read(self.stream)
    def String(self): return String_read(self.stream)
    def Content(self): return Content_read(self.stream)
    def Address(self): return Address_read(self.stream)
    def Offset(self): return Offset_read(self.stream)
    def Span(self): return Span_read(self.stream)
    def VSpec(self): return VSpec_read(self.stream)
    def SpecSet(self): return SpecSet_read(self.stream)

    def write(self, object):
        """Write to the connection an integer, string, Address, Offset,
        Span, VSpec, SpecSet, or list of such objects."""

        if type(object) in (IntType, LongType):
            Number_write(object, self.stream)

        elif type(object) is StringType:
            String_write(object, self.stream)

        elif type(object) in (TupleType, ListType):
            Number_write(len(object), self.stream)
            for item in object:
                self.write(item)
        else:
            object.write(self.stream)

    # issuing commands

    def command(self, code, *args):
        """Issue a command with the given order code and arguments."""

        Number_write(code, self.stream)

        for arg in args:
            self.write(arg)

        try:
            response = self.Number()
        except ValueError:
            raise XuError, "error response to %d from back-end" % code

        if response != code:
            raise XuError, "non-matching response to %d from back-end" % code
