"""An object-based API to the Udanax 88.1 FeBe protocol."""

import sys, os, string, socket

class XuError(Exception):
    pass

# ================================ STREAMS OVER WHICH TO HOLD FEBE SESSIONS

class XuStream:
    """Abstract class specifying the stream interface."""

    def __init__(self, *args):
        raise TypeError, "abstract class cannot be instantiated"

    def read(self, length): pass
    def write(self, data): pass
    def close(self): pass

    def readchunk(self):
        chars = []
        while 1:
            ch = self.read(1)
            if not ch: raise XuError, "stream closed prematurely"
            if ch in ['', '\n', '~']: break
            if ch == "?": raise XuError, "error response from back-end"
            chars.append(ch)
        return string.join(chars, '')

# -------------------------------------------------------------- FileStream
class FileStream(XuStream):
    """Stream interface to two file descriptors."""

    def __init__(self, input, output=None):
        if not output: output = input
        self.input = input
        self.output = output
        self.open = 1

    def __repr__(self):
        result = self.__class__.__name__
        if self.open:
            if self.input is not self.output:
                result = result + " from %s" % repr(self.input)
            return "<%s to %s>" % (result, repr(self.output))
        else:
            return "<%s closed>" % result

    def read(self, length):
        return self.input.read(length)

    def write(self, data):
        self.output.write(data)

    def close(self):
        self.input.close()
        if self.output is not self.input: self.output.close()
        self.open = 0

# --------------------------------------------------------------- TcpStream
class TcpStream(XuStream):
    """Stream interface to a TCP connection."""

    def __init__(self, hostname, port):
        self.host   = hostname
        self.port   = port
        self.socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

        self.socket.connect((hostname, port))
        self.open = 1

    def __repr__(self):
        result = self.__class__.__name__
        if self.open:  return "<%s to %s port %d>" % (result, self.host, self.port)
        else:          return "<%s closed>" % result

    def read(self, length):
        return self.socket.recv(length)

    def write(self, data):
        self.socket.send(data)

    def close(self):
        self.socket.close()
        self.open = 0

# -------------------------------------------------------------- PipeStream
class PipeStream(XuStream):
    """Stream interface to a piped shell command."""

    def __init__(self, command):
        self.fifo = "pyxi.%d" % os.getpid()
        try: os.unlink(self.fifo)
        except: pass
        os.mkfifo(self.fifo)

        self.command = command
        self.inpipe  = os.popen(command + " < " + self.fifo)
        self.outpipe = open(self.fifo, "w")
        self.open    = 1

    def __repr__(self):
        result = self.__class__.__name__
        if self.open:  return "<%s to %s>" % (result, self.command)
        else:          return "<%s closed>" % result

    def __del__(self):
        os.unlink(self.fifo)

    def read(self, length):
        return self.inpipe.read(length)

    def write(self, data):
        self.outpipe.write(data)
        self.outpipe.flush()

    def close(self):
        self.inpipe.close()
        self.outpipe.close()
        try: os.unlink(self.fifo)
        except: pass
        self.open = 0
