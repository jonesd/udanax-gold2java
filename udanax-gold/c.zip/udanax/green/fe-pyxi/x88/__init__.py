"""An object-based API to the Udanax 88.1 FeBe protocol."""

from typeio import *
from tumbler import *
from span import *
from spec import *
from session import *
from stream import *
from debug import *

class XuError:
    pass

# --------------------------------------------------------------- constants
# specifiers
NOSPECS = SpecSet([])

# access modes
(READ_ONLY, READ_WRITE) = (1, 2)

# copy modes
(CONFLICT_FAIL, CONFLICT_COPY, ALWAYS_COPY) = (1, 2, 3)

# link ends
(LINK_SOURCE, LINK_TARGET, LINK_TYPE) = (1, 2, 3)

# conventional link type addresses
LINK_DOCID    = Address(1, 1, 0, 1, 0, 2)
JUMP_TYPE     = VSpec(LINK_DOCID, [Span(Address(2, 1), Offset(0, 1))])
QUOTE_TYPE    = VSpec(LINK_DOCID, [Span(Address(2, 2), Offset(0, 1))])
FOOTNOTE_TYPE = VSpec(LINK_DOCID, [Span(Address(2, 3), Offset(0, 1))])
MARGIN_TYPE   = VSpec(LINK_DOCID, [Span(Address(2, 4), Offset(0, 1))])

LINK_TYPES = [ JUMP_TYPE, QUOTE_TYPE, FOOTNOTE_TYPE, MARGIN_TYPE ]
TYPE_NAMES = {
    JUMP_TYPE: "jump",
    QUOTE_TYPE: "quote",
    FOOTNOTE_TYPE: "footnote",
    MARGIN_TYPE: "margin"
}

TYPES_BY_NAME = {}
for spec in LINK_TYPES:
    TYPES_BY_NAME[ TYPE_NAMES[spec] ] = spec

def tcpconnect(hostname, port):
    return XuSession(XuConn(TcpStream(hostname, port)))

def pipeconnect(command):
    return XuSession(XuConn(PipeStream(command)))
   
def testconnect():
    return XuSession(XuConn(FileStream(sys.stdin, sys.stdout)))
