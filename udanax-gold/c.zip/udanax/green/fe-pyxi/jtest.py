import sys, x88

host, port = "localhost", 55146

ps = x88.DebugWrapper(x88.TcpStream(host, port), sys.stderr)
xc = x88.DebugWrapper(x88.XuConn(ps), sys.stderr)
xs = x88.DebugWrapper(x88.XuSession(xc), sys.stderr)

#try:
#    print xs.find_documents( x88.SpecSet(x88.Span(x88.Address("1"), x88.Offset("1"))) )

xs.create_node(x88.Address("1")) # Create Node# 1 for Our Server
xs.create_node(x88.Address("1.1")) # Create Account# 1 for Our Work
xs.create_node(x88.Address("1.1.0.1")) # Create Account# 1 for Our Work

xs.account(x88.Address("1.1.0.1"))

docid = xs.create_document()
print "Created new document, DocID is ", docid

verid = xs.create_version(docid)
print "Created new version of document, VerID is ", verid

docid = xs.open_document(docid, x88.READ_WRITE, x88.CONFLICT_COPY)

docid = x88.Address("1.1.0.1.0.1")
docid = xs.open_document(docid, x88.READ_WRITE, x88.CONFLICT_COPY)
print "VSPAN of DocID %s is %s" % (`docid`, `xs.retrieve_vspan(docid)`)

#docid = x88.Address("1.1.0.1.0.2")
#docid = xs.open_document(docid, x88.READ_WRITE, x88.CONFLICT_COPY)
#print "VSPAN of DocID %s is %s" % (docid, xs.retrieve_vspan(docid))

#docid = x88.Address("1.1.0.1.0.3")
#docid = xs.open_document(docid, x88.READ_WRITE, x88.CONFLICT_COPY)
#print "VSPAN of DocID %s is %s" % (docid, xs.retrieve_vspan(docid))

docid = x88.Address("1.1.0.1.0.1")
docid = xs.open_document(docid, x88.READ_WRITE, x88.CONFLICT_COPY)
xs.insert(docid, x88.Address("1.1"), "This is a test of insertion")

xs.close_document(docid)



#print xs.find_documents( x88.SpecSet(x88.Span(x88.Address("1.1.0.1.0.1"), x88.Offset("0.0.0.0.0.2"))) )

#finally:
xs.quit()

#34 {XACCOUNT}
#1.1.0.1
#21 {SOURCEUNIXCOMMAND}
#cat olddemo/demo_docs/intro

# x = XuSession(XuConn(TestStream()))
# doca = Address(1,1,0,1,0,1)
# mydoca = x.open_document(doca, READ_ONLY, CONFLICT_COPY)
# vspan = Span(Address(1,1), Offset(0,1500))
# specset = SpecSet(VSpec(mydoca, [vspan]))
# adata = x.retrieve_contents(specset)
# 
# docspan = Span(Address(1,1), Offset(1))
# specset = SpecSet(VSpec(mydoca, [docspan]))
# asource, atarget, atype = x.retrieve_endsets(specset)
# 
# vspanset = x.retrieve_vspanset(mydoca)
# 
# charspan = Span(Address(1,513), Offset(0,1))
# specfrom = SpecSet(VSpec(mydoca, [charspan]))
# links = x.find_links(specfrom)
# 
# type = x.follow_link(links[0], LINK_TYPE)
# target = x.follow_link(links[0], LINK_TARGET)
# 
# docb = target[0].docid
# mydocb = x.open_document(docb, READ_ONLY, CONFLICT_COPY)
# vspan = Span(Address(1,1), Offset(0,1500))
# specset = SpecSet(VSpec(mydocb, [vspan]))
# bdata = x.retrieve_contents(specset)
# 
# docspan = Span(Address(1,1), Offset(1))
# specset = SpecSet(VSpec(mydocb, [docspan]))
# bsource, btarget, btype = x.retrieve_endsets(specset)
# x.quit()
# 
# verify(mydoca, Address(1, 1, 0, 1, 0, 1))
# verify(adata, ['abcdefghij'])
# verify(asource, SpecSet([VSpec(Address(1, 1, 0, 1, 0, 1),
#                                [Span(Address(1, 504), Offset(0, 49))])]))
# verify(atarget, SpecSet([VSpec(Address(1, 1, 0, 1, 0, 1),
#                                [Span(Address(1, 2), Offset(0, 6))])]))
# verify(atype, SpecSet([]))
# verify(vspanset, VSpec(Address(1, 1, 0, 1, 0, 1),
#                        [Span(Address(1, 1), Offset(0, 553))]))
# verify(links, [Address(1, 1, 0, 1, 0, 2, 0, 2, 22)])
# verify(type, SpecSet([VSpec(Address(1, 1, 0, 1, 0, 2),
#                             [Span(Address(2, 1), Offset(0, 1))])]))
# verify(target, SpecSet([VSpec(Address(1, 1, 0, 1, 0, 2),
#                               [Span(Address(1, 1), Offset(0, 57))])]))
# 
# verify(mydocb, Address(1, 1, 0, 1, 0, 2))
# verify(bdata, ['klmnopqrst'])
# verify(bsource, SpecSet([VSpec(Address(1, 1, 0, 1, 0, 2),
#                                [Span(Address(1, 1), Offset(0, 1)),
#                                 Span(Address(1, 1), Offset(0, 1)),
#                                 Span(Address(1, 1), Offset(0, 1)),
#                                 Span(Address(1, 1), Offset(0, 1)),
#                                 Span(Address(1, 1), Offset(0, 1)),
#                                 Span(Address(1, 75), Offset(0, 9)),
#                                 Span(Address(1, 102), Offset(0, 35)),
#                                 Span(Address(1, 143), Offset(0, 11)),
#                                 Span(Address(1, 232), Offset(0, 11)),
#                                 Span(Address(1, 253), Offset(0, 13)),
#                                 Span(Address(1, 276), Offset(0, 6)),
#                                 Span(Address(1, 317), Offset(0, 6)),
#                                 Span(Address(1, 333), Offset(0, 5)),
#                                 Span(Address(1, 348), Offset(0, 5)),
#                                 Span(Address(1, 363), Offset(0, 5)),
#                                 Span(Address(1, 447), Offset(0, 4)),
#                                 Span(Address(1, 492), Offset(0, 6)),
#                                 Span(Address(1, 542), Offset(0, 9)),
#                                 Span(Address(1, 569), Offset(0, 11)),
#                                 Span(Address(1, 682), Offset(0, 8)),
#                                 Span(Address(1, 694), Offset(0, 12)),
#                                 Span(Address(1, 707), Offset(0, 14)),
#                                 Span(Address(1, 748), Offset(0, 8)),
#                                 Span(Address(1, 765), Offset(0, 8)),
#                                 Span(Address(1, 782), Offset(0, 8)),
#                                 Span(Address(1, 799), Offset(0, 8)),
#                                 Span(Address(1, 799), Offset(0, 8)),
#                                 Span(Address(1, 816), Offset(0, 8)),
#                                 Span(Address(1, 833), Offset(0, 8)),
#                                 Span(Address(1, 850), Offset(0, 8)),
#                                 Span(Address(1, 867), Offset(0, 8))])]))
# verify(btarget, SpecSet([VSpec(Address(1, 1, 0, 1, 0, 2),
#                                [Span(Address(1, 1), Offset(0, 57)),
#                                 Span(Address(1, 1), Offset(0, 1)),
#                                 Span(Address(1, 1), Offset(0, 1)),
#                                 Span(Address(1, 1), Offset(0, 1)),
#                                 Span(Address(1, 1), Offset(0, 1)),
#                                 Span(Address(1, 1), Offset(0, 1))])]))
# verify(btype, SpecSet([VSpec(Address(1, 1, 0, 1, 0, 2),
#                              [Span(Address(1, 1), Offset(0, 1)),
#                               Span(Address(1, 1), Offset(0, 1)),
#                               Span(Address(1, 1), Offset(0, 1)),
#                               Span(Address(1, 1), Offset(0, 1)),
#                               Span(Address(1, 1), Offset(0, 1))])]))
