/**********************************************************************
 * Copyright 2002 Jeff Rush <jrush@taupro.com>
 * Original Copyright 1979-2002 Udanax.com
 *
 * This file is part of the Udanax xanalogical storage system.
 *
 * Udanax is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * Udanax is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with Udanax; if not, write to the Free Software Foundation,
 * Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 **********************************************************************/

/**
 * @file  context.cxx
 * @brief ???
 *
 * (to be defined)
 *
 **/

/* Modification History:
 * $Log: context.cxx,v $
 * Revision 1.13  2002/07/26 04:30:29  jrush
 * Replaced gerror() with assert()
 *
 * Revision 1.12  2002/05/28 04:22:29  jrush
 * Adjusted source files to comply with GPL licensing.
 *
 * Revision 1.11  2002/05/28 02:49:42  jrush
 * Made static any functions and global variables private to this source file
 * and commented out any unused functions.
 *
 * Revision 1.10  2002/04/16 22:39:50  jrush
 * Converted many #defines into enumeration types instead, and adjusted
 * function prototypes accordingly.
 *
 * Revision 1.9  2002/04/12 11:56:42  jrush
 * Reorganized include file layout, renamed xanadu.h to udanax.h and
 * typecontext/typecrumcontext to C++ class Context/CrumContext.
 *
 * Revision 1.8  2002/04/10 18:01:54  jrush
 * Renamed class typeisa to IStreamAddr.
 *
 * Revision 1.7  2002/04/09 21:45:46  jrush
 * Renamed class 'tumbler' to 'Tumbler', for consistency with Python sources,
 * and changed typeisa from typedef to a subclass, in preparation for cleaning
 * up the type/class tree.
 *
 * Revision 1.6  2002/04/06 20:42:50  jrush
 * Switch from sess->alloc() style to new(sess) Object parameterized allocator.
 *
 * Revision 1.5  2002/04/06 19:51:30  jrush
 * Renamed TRUE/FALSE constant use to the C++ standard of true/false.
 *
 * Revision 1.4  2002/04/06 17:05:57  jrush
 * Switched from referring to 'task' for a client connection to 'session',
 * and converted the typetask typedef/struct into a Session C++ class.
 *
 * Revision 1.3  2002/04/06 15:01:17  jrush
 * Changed INT to just 'int'.
 *
 * Revision 1.2  2002/02/14 09:27:43  jrush
 * Cleaned up source:
 *
 * 1. ran thru the indent tool to achieve a standard look,
 * 2. added structured comments at top for use with DOxygen reporting
 *    as well as CVS keywords,
 * 3. fixed compiler warnings re ambiguous assign/compares,
 *    needed casts and unused/uninitialized variables,
 * 4. fixed funcs that didn't specify a return type,
 * 5. centralized prototypes in protos.h, removing incomplete ones,
 * 6. cleaned up use of bool/BOOLEAN type to suit C++ type,
 * 7. fixed initializer nesting in tumbler constants,
 * 8. renamed vars that conflict with C++ keywords (new, this),
 * 9. fixed global/extern confusion re some global vars.
 *
 */

#include <memory.h>
#include "udanax.h"

static int contextnum = 0;
static int c2dontextnum = 0;
static int crumcontextnum = 0;

static Context *
createcontext(unsigned char type)
{
    Context *ret;

    if (type == GRAN) {
        ret = (Context *) eallocwithtag(sizeof(Context), CONTEXTTAG);
        clear(ret, sizeof(Context));
        ++contextnum;
    } else {
        ret = (Context *) eallocwithtag(sizeof(type2dcontext), CONTEXT2DTAG);
        clear(ret, sizeof(type2dcontext));
        ++c2dontextnum;
    }
    ret->contexttype = type;
    return (ret);
}

void
contextfree(Context *context)
{
    Context *c;

    for (; (c = context) != 0;) {
        if (c->contexttype == GRAN) {
            --contextnum;
        } else {
            --c2dontextnum;
        }

        context = (Context *) context->nextcontext;;
        efree((char *)c);
    }
}

CrumContext *
createcrumcontext(typecorecrum *crumptr, typedsp *offsetptr)
{
    reserve(crumptr);
    CrumContext *ret = (CrumContext *) eallocwithtag(sizeof(CrumContext), CRUMCONTEXTTAG);
    ret->nextcrumcontext = NULL;
    ret->corecrum = (typecbc *) crumptr;
    movewisp(offsetptr, &ret->totaloffset);
    ++crumcontextnum;
    return ret;
}

void
crumcontextfree(CrumContext *context)
{
    CrumContext *c;

    for (; (c = context) != 0; context = context->nextcrumcontext, efree((char *)c)) {
        rejuvinate((typecorecrum *) c->corecrum);
        --crumcontextnum;
    }
}

static int
whereoncontext(Context *ptr, Tumbler *address, int index /* used when enftype == SPAN or POOM */)
{
    Tumbler left, right;

    switch (ptr->contexttype) {
    case GRAN:
        movetumbler(&ptr->totaloffset.dsas[WIDTH], &left);
        tumbleradd(&left, &ptr->contextwid.dsas[WIDTH], &right);
        break;
    case SPAN:
        /* zzz
         * if (iszerotumbler(&ptr->contextwid.dsas[SPANRANGE])) {
         *     assert(0) // zero spanrange in whereoncontext
         * }
         */
    case POOM:
        movetumbler(&ptr->totaloffset.dsas[index], &left);
        tumbleradd(&left, &ptr->contextwid.dsas[index], &right);
        break;
    default:
        assert(0); // whereoncontext: bad enftype
    }

    return intervalcmp(&left, &right, address);
}

/* sets grasp & reach from ptr */
/* reach may be NULL so that we won't set it */
static void
prologuecontextnd(Context *ptr, typedsp *grasp, typedsp *reach)
{
    movewisp(&ptr->totaloffset, grasp);
    if (reach)
        dspadd(grasp, &ptr->contextwid, reach, ptr->contexttype);
}

/* put c on clist in index order */
void
incontextlistnd(Context **clistptr, Context *c, int index)
{
    Context *clist, *nextc;
    typedsp grasp;

    prologuecontextnd(c, &grasp, (typedsp *) NULL);
    c->nextcontext = NULL;
    clist = *clistptr;
/* 1st insertion */
    if (!clist) {
/* if (debug) fprintf (stderr, "first insertion\n"); */
        *clistptr = c;
        return;
    }
/* on beginning */
    if (whereoncontext(clist, &grasp.dsas[index], index) < THRUME) {
/* if (debug) fprintf (stderr, "beginning\n"); */
        c->nextcontext = clist;
        *clistptr = c;
        return;
    } else {
        for (; (nextc = (Context *) clist->nextcontext) != 0; clist = nextc) {
/* in middle */
            if ((whereoncontext(clist, &grasp.dsas[index], index) > ONMYLEFTBORDER)
                && (whereoncontext(nextc, &grasp.dsas[index], index) < ONMYLEFTBORDER)) {
/* if (debug) fprintf (stderr, "middle\n"); */
                c->nextcontext = nextc;
                clist->nextcontext = c;
                return;
            }
        }
    }
/* on end */
/* if (debug) fprintf (stderr, "end\n"); */
    c->nextcontext = NULL;
    clist->nextcontext = c;
}

void
oncontextlistseq(Context **clistptr, Context *c)
{                                      /* add to list of context */
    c->nextcontext = NULL;
    if (!*clistptr) {                  /* 1st insertion */
        *clistptr = c;
        c->lastcontext = c;
    } else {                           /* on end */
        (*clistptr)->lastcontext->nextcontext = c;
        (*clistptr)->lastcontext = c;
    }
}

Context *
makecontextfromcbc(typecbc *crumptr, typewid *offsetptr)
{
    Context *context;

#ifndef DISTRIBUTION
    if (debug) {
        foo("make contextfromcbc crum is ");
        dump((typecorecrum *) crumptr);
    }
#endif
    reserve((typecorecrum *) crumptr);
    context = createcontext(crumptr->cenftype);
    movewisp(offsetptr, &context->totaloffset);
    movewisp(&crumptr->cwid, &context->contextwid);

    if (is2dcrum((typecorecrum *) crumptr))
        move2dinfo(&((type2dcbc *) crumptr)->c2dinfo, &((type2dcontext *) context)->context2dinfo);
    else
        moveinfo((typebottomcruminfo *) &crumptr->cinfo, &context->contextinfo);

    if (crumptr->cenftype != GRAN)
        dspadd(&context->totaloffset, &crumptr->cdsp, &context->totaloffset, (int) crumptr->cenftype);
    context->nextcontext = NULL;
    rejuvinate((typecorecrum *) crumptr);
#ifndef DISTRIBUTION
    if (debug) {
        dumpcontext(context);
    }
#endif
    return context;
}

static typeitemid
index2itemid(int index, Context *context)
{
    switch (context->contexttype) {
    case POOM:  return (index == I) ? ISPANID : VSPANID;
    case SPAN:  return ISPANID;
    default:
        assert(0); // index2itemid bad enftype
        return UNKNOWNID;
    }
}

void
context2span(Context *context, typespan *restrictionspanptr, int idx1, typespan *foundspanptr, int idx2)
{
    Tumbler upperbound, lowerbound;
    typedsp grasp, reach;

/* int i; */

/* foo("entering context2span\n"); */
/* foocontext("context = \n",context); */
/* foospanset("restrictionspan = \n",restrictionspanptr); */

    movetumbler(&restrictionspanptr->stream, &lowerbound);
    tumbleradd(&lowerbound, &restrictionspanptr->width, &upperbound);
    prologuecontextnd(context, &grasp, &reach);
/* footumbler("lowerbound = \n",&lowerbound); */
/* footumbler("upperbound = \n",&upperbound); */
    if (tumblercmp(&grasp.dsas[idx1], &lowerbound) == LESS) {
/* foo("LESSER\n"); */
/* foodsp("grasp = \n",&grasp,POOM); */
        tumblerincrement(&grasp.dsas[idx2], 0, (int) tumblerintdiff(&lowerbound, &grasp.dsas[idx1]), &grasp.dsas[idx2]);
/* foodsp("grasp = \n",&grasp,POOM); */
    }
    if (tumblercmp(&reach.dsas[idx1], &upperbound) == GREATER) {
/* foo("GREATER\n"); */
/* foodsp("reach = \n",&reach,POOM); */
        tumblerincrement(&reach.dsas[idx2], 0,  /* i= */
                         -tumblerintdiff(&reach.dsas[idx1], &upperbound), &reach.dsas[idx2]);
/* foodec("tumblerintdiff = ",i); */
/* foodsp("reach = \n",&reach,POOM); */
    }
/* foodsp("grasp = \n",&grasp,POOM); */
/* foodsp("reach = \n",&reach,POOM); */
    movetumbler(&grasp.dsas[idx2], &foundspanptr->stream);
    tumblersub(&reach.dsas[idx2], &grasp.dsas[idx2], &foundspanptr->width);
/* footumbler("foundspanwidth = \n",&foundspanptr->width); */
    foundspanptr->itemid = index2itemid(idx2, context);
    foundspanptr->next = NULL;
/* foospanset("leaving context2span with foundspan = \n",foundspanptr); */
}

static void
context2vtext(Context *context, typeispan *ispanptr, typevstuffset vstuffset)
{
    IStreamAddr crumistart, crumiend, ispanstart, ispanend;
    int i, vtlength;

    movetumbler(&context->totaloffset.dsas[WIDTH], &crumistart);
#ifndef DISTRIBUTION
    footumbler("crumistart = ", &crumistart);
#endif
    tumblerincrement(&crumistart, 0, (int) context->contextinfo.granbottomcruminfo.granstuff.textstuff.textlength,
                     &crumiend);
#ifndef DISTRIBUTION
    footumbler("crumiend = ", &crumiend);
#endif
    movetumbler(&ispanptr->stream, &ispanstart);
    tumbleradd(&ispanstart, &ispanptr->width, &ispanend);
    i = 0;
    vtlength = context->contextinfo.granbottomcruminfo.granstuff.textstuff.textlength;
    if (tumblercmp(&crumistart, &ispanstart) == LESS) {
#ifndef DISTRIBUTION
        foo("first if\n\ti = tumblerintdiff (&ispanstart, &crumistart)\n");
#endif
        i = tumblerintdiff(&ispanstart, &crumistart);
        vtlength -= i;
    }
    if (tumblercmp(&crumiend, &ispanend) == GREATER) {
#ifndef DISTRIBUTION
        foo("second if\n\tvtlength -= tumblerintdiff (&crumiend, &ispanend)\n");
#endif
        vtlength -= tumblerintdiff(&crumiend, &ispanend);
    }
    ((typetext *) vstuffset)->length = vtlength > 0 ? vtlength : -vtlength;
    movmem(&context->contextinfo.granbottomcruminfo.granstuff.textstuff.textstring[i], ((typetext *) vstuffset)->string,
           ((typetext *) vstuffset)->length);
}

bool
context2vstuff(Session *sess, Context *context, typeispan *ispanptr, typevstuffset *vstuffsetptr)
{
    typevstuffset vstuffset = NULL;

#ifndef DISTRIBUTION
    foo("context2stuff\n");
#endif

    int contextinfotype = context->contextinfo.granbottomcruminfo.infotype;

    if (contextinfotype != GRANTEXT && contextinfotype != GRANORGL)
        return false;

    switch (contextinfotype) {
    case GRANTEXT:
        vstuffset = (typevstuffset) new(sess) typetext;
//        vstuffset = (typevstuffset) sess->alloc(sizeof(typetext));

        ((typeitemheader *) vstuffset)->next = NULL;
#ifndef DISTRIBUTION
        foocontext("context after item= ", context);
#endif
        ((typeitemheader *) vstuffset)->itemid = TEXTID;
        context2vtext(context, ispanptr, vstuffset);
        if (((typetext *) vstuffset)->length == 0)
            return false;
        break;

    case GRANORGL:
        vstuffset = (typevstuffset) new(sess) typeaddress;
//        vstuffset = (typevstuffset) sess->alloc(sizeof(typeaddress));

        ((typeitemheader *) vstuffset)->next = NULL;
#ifndef DISTRIBUTION
        foocontext("context after item= ", context);
#endif
        ((typeitemheader *) vstuffset)->itemid = ADDRESSID;
        movetumbler(&context->totaloffset.dsas[WIDTH], &((typelink *) vstuffset)->address);
    }

    *vstuffsetptr = vstuffset;
    return true;
}
