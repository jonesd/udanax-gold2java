/**********************************************************************
 * Copyright 2002 Jeff Rush <jrush@taupro.com>
 * Original Copyright 1979-2002 Udanax.com
 *
 * This file is part of the Udanax xanalogical storage system.
 *
 * Udanax is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * Udanax is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with Udanax; if not, write to the Free Software Foundation,
 * Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 **********************************************************************/

/**
 * @file  queues.cxx
 * @brief ???
 *
 * (to be defined)
 *
 **/

/* Modification History:
 * $Log: queue.cxx,v $
 * Revision 1.4  2002/07/14 08:28:33  jrush
 * Rearranged unused functions
 *
 * Revision 1.3  2002/05/28 04:22:29  jrush
 * Adjusted source files to comply with GPL licensing.
 *
 * Revision 1.2  2002/05/28 02:51:11  jrush
 * Made static any functions and global variables private to this source file
 * and commented out any unused functions.
 *
 * Revision 1.1  2002/04/12 11:50:24  jrush
 * Renamed queues.cxx to queue.cxx, to reflect renaming of corresponding
 * include file.
 *
 * Revision 1.3  2002/04/06 19:51:30  jrush
 * Renamed TRUE/FALSE constant use to the C++ standard of true/false.
 *
 * Revision 1.2  2002/02/14 09:27:43  jrush
 * Cleaned up source:
 *
 * 1. ran thru the indent tool to achieve a standard look,
 * 2. added structured comments at top for use with DOxygen reporting
 *    as well as CVS keywords,
 * 3. fixed compiler warnings re ambiguous assign/compares,
 *    needed casts and unused/uninitialized variables,
 * 4. fixed funcs that didn't specify a return type,
 * 5. centralized prototypes in protos.h, removing incomplete ones,
 * 6. cleaned up use of bool/BOOLEAN type to suit C++ type,
 * 7. fixed initializer nesting in tumbler constants,
 * 8. renamed vars that conflict with C++ keywords (new, this),
 * 9. fixed global/extern confusion re some global vars.
 *
 */

/* 
 * 
 * Queue manipulation routines
 * 
 * Designed and implemented by John Walker in January 1986
 * 
 * Derived from the Masterstroke multitasking process scheduler, and before
 * that the Marinchip NOS/MT scheduler, the Marinchip Disc Executive kernel,
 * the ISD Interactive Network real time operating system, the FANG task
 * handler, and CHI/OS.
 * 
 */

#define I_LEVEL 1
#include "udanax.h"

/* QINIT -- Initialise links for null queue */

void
qinit(struct queue *qhead)
{
    qhead->qnext = qhead->qprev = qhead;
}

/* QPUSH -- Push object at start of queue */

void
qpush(struct queue *qhead, struct queue *object)
{
    assert(qhead->qprev->qnext == qhead);
    assert(qhead->qnext->qprev == qhead);

    object->qprev        = qhead;
    object->qnext        = qhead->qnext;
    qhead->qnext         = object;
    object->qnext->qprev = object;
}

/* QREMOVE -- Remove object from queue.  Returns NULL if queue empty */

struct queue *
qremove(struct queue *qhead)
{
    struct queue *object;

    assert(qhead->qprev->qnext == qhead);
    assert(qhead->qnext->qprev == qhead);

    if ((object = qhead->qnext) == qhead)
        return NULL;

    qhead->qnext         = object->qnext;
    object->qnext->qprev = qhead;

    return object;
}

/* QNEXT -- Get next object from queue nondestructively. Returns NULL at end of queue */

queue *
queue::next(queue *qhead)
{
    struct queue *object = this->qnext;

    if (object == qhead)
        object = NULL;

    return object;
}

/* QLENGTH -- Return number of items on queue, zero if queue empty. Note that this must traverse all the links of the
 * queue, so if all you're testing is whether the queue is empty or not, you should use the qempty(queue) macro
 * (defined in queues.h) which uses qnext() to detect an empty queue much faster. */

int
qlength(struct queue *qhead)
{
    struct queue *qp;

    int l = 0;
    qp = qhead->qnext;

    while (qp != qhead) {
        l++;
        qp = qp->qnext;
    }
    return l;
}

/* QDCHAIN -- Dequeue an item from the middle of a queue.  Passed the queue item, returns the (now dechained) queue
 * item. */

//UNUSED struct queue *
//UNUSED qdchain(struct queue *qitem)
//UNUSED {
//UNUSED     assert(qitem->qprev->qnext == qitem);
//UNUSED     assert(qitem->qnext->qprev == qitem);
//UNUSED 
//UNUSED     return qremove(qitem->qprev);
//UNUSED }

/* QINSERT -- Insert object at end of queue */

//UNUSED void
//UNUSED qinsert(struct queue *qhead, struct queue *object)
//UNUSED {
//UNUSED     assert(qhead->qprev->qnext == qhead);
//UNUSED     assert(qhead->qnext->qprev == qhead);
//UNUSED 
//UNUSED     object->qnext = qhead;
//UNUSED     object->qprev = qhead->qprev;
//UNUSED     qhead->qprev = object;
//UNUSED     object->qprev->qnext = object;
//UNUSED }

/* QVALID -- Validates all of the links in a queue. Returns 1 if all of the links are valid and 0 otherwise. Note that
 * if the queue contains any bad pointers this routine may crash.  */

//UNUSED bool
//UNUSED qvalid(struct queue * qhead)
//UNUSED {
//UNUSED     struct queue *qp = qhead;
//UNUSED     if (qp == NULL)
//UNUSED         return false;
//UNUSED 
//UNUSED     do {
//UNUSED         if ((qp->qnext == NULL) || (qp->qprev == NULL)
//UNUSED             || (qp->qnext->qprev != qp) || (qp->qprev->qnext != qp))
//UNUSED             return false;
//UNUSED 
//UNUSED         qp = qp->qnext;
//UNUSED     } while (qp != qhead);
//UNUSED 
//UNUSED     return true;
//UNUSED }
