/**********************************************************************
 * Copyright 2002 Jeff Rush <jrush@taupro.com>
 * Original Copyright 1979-2002 Udanax.com
 *
 * This file is part of the Udanax xanalogical storage system.
 *
 * Udanax is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * Udanax is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with Udanax; if not, write to the Free Software Foundation,
 * Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 **********************************************************************/

/**
 * @file  granf1.cxx
 * @brief Udanax granfilade calls
 *
 * (to be defined)
 *
 **/

/* Modification History:
 * $Log: granf1.cxx,v $
 * Revision 1.11  2002/07/26 04:32:01  jrush
 * Replaced gerror() with assert()
 *
 * Revision 1.10  2002/05/28 04:22:29  jrush
 * Adjusted source files to comply with GPL licensing.
 *
 * Revision 1.9  2002/05/28 02:47:35  jrush
 * Cosmetic cleanup of code.
 *
 * Revision 1.8  2002/04/12 11:56:43  jrush
 * Reorganized include file layout, renamed xanadu.h to udanax.h and
 * typecontext/typecrumcontext to C++ class Context/CrumContext.
 *
 * Revision 1.7  2002/04/10 18:01:54  jrush
 * Renamed class typeisa to IStreamAddr.
 *
 * Revision 1.6  2002/04/08 18:55:55  jrush
 * Switched from using global variable 'user' to object 'Session' as a
 * connection for tracking open document descriptors in the bert table.
 *
 * Revision 1.5  2002/04/07 14:04:37  jrush
 * Add ptr to Session to checkforopen() and isthisusersdocument() so that we
 * have session information available to make the decision.
 *
 * Revision 1.4  2002/04/06 19:51:30  jrush
 * Renamed TRUE/FALSE constant use to the C++ standard of true/false.
 *
 * Revision 1.3  2002/04/06 17:05:57  jrush
 * Switched from referring to 'task' for a client connection to 'session',
 * and converted the typetask typedef/struct into a Session C++ class.
 *
 * Revision 1.2  2002/02/14 09:27:43  jrush
 * Cleaned up source:
 *
 * 1. ran thru the indent tool to achieve a standard look,
 * 2. added structured comments at top for use with DOxygen reporting
 *    as well as CVS keywords,
 * 3. fixed compiler warnings re ambiguous assign/compares,
 *    needed casts and unused/uninitialized variables,
 * 4. fixed funcs that didn't specify a return type,
 * 5. centralized prototypes in protos.h, removing incomplete ones,
 * 6. cleaned up use of bool/BOOLEAN type to suit C++ type,
 * 7. fixed initializer nesting in tumbler constants,
 * 8. renamed vars that conflict with C++ keywords (new, this),
 * 9. fixed global/extern confusion re some global vars.
 *
 */

#include "udanax.h"

bool isxumain = false;

bool
findorgl(/*BERT*/ Session *sess, typegranf granfptr, IStreamAddr *isaptr, typeorgl *orglptr, int type)
{
    int temp;

    if ( /* backenddaemon && */ (temp = checkforopen(sess, isaptr, type)) <= 0) {
#ifndef DISTRIBUTION
        if (!isxumain) {
            fprintf(stderr, "orgl for ");
            dumptumbler(isaptr);
            fprintf(stderr, " not open in findorgl temp = %d\n", temp);
            return false;

// assert(0); /* Temporary crash in findorgl */);
/* ECH ?? or should I simply return false? */
        }
#else
        if (!isxumain) {
            *orglptr = NULL;
            return false;
        }
#endif
    }
    *orglptr = fetchorglgr(sess, granfptr, isaptr);
    return *orglptr ? true : false;
}

bool
inserttextingranf(Session * sess, typegranf granfptr, typehint * hintptr, typetextset textset,
                  typeispanset * ispansetptr)
{
    return inserttextgr(sess, granfptr, hintptr, textset, ispansetptr);
}

bool
createorglingranf(Session * sess, typegranf granfptr, typehint * hintptr, IStreamAddr * isaptr)
{
    return createorglgr(sess, /* GRR not defd (typecuc*) */ granfptr, hintptr, isaptr);
}

bool
ispanset2vstuffset(Session * sess, typegranf granfptr, typeispanset ispanset, typevstuffset * vstuffsetptr)
{
    typevstuffset *save = vstuffsetptr;

#ifndef DISTRIBUTION
    if (debug) {
        fprintf(stderr, "\n\nISPANSET2VSTUFFSET\n");
        fooitemset("", (typeitem *) ispanset);
    }
#endif

    *vstuffsetptr = NULL;
    for (; ispanset; ispanset = ispanset->next)
        vstuffsetptr = ispan2vstuffset(sess, granfptr, ispanset, vstuffsetptr);

#ifndef DISTRIBUTION
    if (debug)
        fooitemset("", (typeitem *) *save);
#endif

    return true;
}
