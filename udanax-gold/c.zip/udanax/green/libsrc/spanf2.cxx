/**********************************************************************
 * Copyright 2002 Jeff Rush <jrush@taupro.com>
 * Original Copyright 1979-2002 Udanax.com
 *
 * This file is part of the Udanax xanalogical storage system.
 *
 * Udanax is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * Udanax is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with Udanax; if not, write to the Free Software Foundation,
 * Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 **********************************************************************/

/**
 * @file  spanf2.cxx
 * @brief lower-level spanfilade calls
 *
 * (to be defined)
 *
 **/

/* Modification History:
 * $Log: spanf2.cxx,v $
 * Revision 1.9  2002/05/28 04:22:29  jrush
 * Adjusted source files to comply with GPL licensing.
 *
 * Revision 1.8  2002/05/28 02:52:23  jrush
 * Made static any functions and global variables private to this source file
 * and commented out any unused functions.
 *
 * Revision 1.7  2002/04/12 11:56:43  jrush
 * Reorganized include file layout, renamed xanadu.h to udanax.h and
 * typecontext/typecrumcontext to C++ class Context/CrumContext.
 *
 * Revision 1.6  2002/04/10 18:01:54  jrush
 * Renamed class typeisa to IStreamAddr.
 *
 * Revision 1.5  2002/04/06 20:42:50  jrush
 * Switch from sess->alloc() style to new(sess) Object parameterized allocator.
 *
 * Revision 1.4  2002/04/06 19:51:30  jrush
 * Renamed TRUE/FALSE constant use to the C++ standard of true/false.
 *
 * Revision 1.3  2002/04/06 17:05:57  jrush
 * Switched from referring to 'task' for a client connection to 'session',
 * and converted the typetask typedef/struct into a Session C++ class.
 *
 * Revision 1.2  2002/02/14 09:27:43  jrush
 * Cleaned up source:
 *
 * 1. ran thru the indent tool to achieve a standard look,
 * 2. added structured comments at top for use with DOxygen reporting
 *    as well as CVS keywords,
 * 3. fixed compiler warnings re ambiguous assign/compares,
 *    needed casts and unused/uninitialized variables,
 * 4. fixed funcs that didn't specify a return type,
 * 5. centralized prototypes in protos.h, removing incomplete ones,
 * 6. cleaned up use of bool/BOOLEAN type to suit C++ type,
 * 7. fixed initializer nesting in tumbler constants,
 * 8. renamed vars that conflict with C++ keywords (new, this),
 * 9. fixed global/extern confusion re some global vars.
 *
 */

#include "udanax.h"

bool
isinlinklist(typelinkset linkset, IStreamAddr *linkisaptr)
{
    for (; linkset; linkset = linkset->next) {
        if (tumblereq(&linkset->address, linkisaptr))
            return true;
    }
    return false;
}

static typelink *
makelinkitem(Session *sess, IStreamAddr *linkisa)
{
#ifndef DISTRIBUTION
    footumbler("makelinkitem", linkisa);
#endif

    typelink *link = new(sess) typelink;
    movetumbler(linkisa, &link->address);
    link->itemid = LINKID;
    link->next   = NULL;
    return link;
}

void
onlinklist(Session *sess, typelinkset *linksetptr, IStreamAddr *linkisaptr)
{
    typelink *linkset, *temp, *nextlink;

    linkset = makelinkitem(sess, linkisaptr);

    if (*linksetptr == NULL) {
        *linksetptr = linkset;
        return;
    }

    for (temp = *linksetptr; (nextlink = temp->next) != 0; temp = nextlink) {
        if (tumblereq(&temp->address, linkisaptr))
            return;
    }

    temp->next = linkset;
}

void
intersectlinksets(Session *sess, typelinkset linkset1, typelinkset linkset2, typelinkset linkset3, typelinkset *linkset4ptr)
{
    typelinkset linkset4;
    typelinkset temp1 = NULL;
    typelinkset temp2;
    typelinkset temp3;
    bool olddebug = debug;

#ifndef DISTRIBUTION
    if (debug) {
        fprintf(stderr, "\nINTERSECTLINKSETS\n");
        fooitemset("", (typeitem *) linkset1);
        fooitemset("", (typeitem *) linkset2);
        fprintf(stderr, "inter linkset1 = %x, linkset2 = %x, linkset3 = %x\n", (int) linkset1, (int) linkset2, (int) linkset3);
    }
#endif

/* If only one linkset is non-null, then just use it */
    if (linkset1 && !linkset2 && !linkset3)
        *linkset4ptr = linkset1;
    else if (!linkset1 && linkset2 && !linkset3)
        *linkset4ptr = linkset2;
    else if (!linkset1 && !linkset2 && linkset3)
        *linkset4ptr = linkset3;
    else
        *linkset4ptr = NULL;

    if (*linkset4ptr) {
#ifndef DISTRIBUTION
        if (debug) {
            fprintf(stderr, "*linkset4ptr = %x\n", (int) *linkset4ptr);
        }
#endif
        debug = olddebug;
        return;
    }

/* At least two linksets aren't null */
/* If only two are, put them in temp1 and linkset2 */
    if (linkset1)
        temp1 = linkset1;
    if (linkset1 && !linkset2 && linkset3) {
        linkset2 = linkset3;
        linkset3 = NULL;
    } else if (!linkset1 && linkset2 && linkset3) {
        temp1 = linkset3;
        linkset3 = NULL;
    }

#ifndef DISTRIBUTION
    if (debug) {
        fprintf(stderr, "temp1 = %x, linkset2 = %x, linkset3 = %x\n", (int) temp1, (int) linkset2, (int) linkset3);
    }
#endif

    if (!linkset3) {
        for (; temp1; temp1 = temp1->next) {
            for (temp2 = linkset2; temp2; temp2 = temp2->next) {
                if (tumblereq(&temp1->address, &temp2->address)) {
                    linkset4 = makelinkitem(sess, &temp1->address);
                    *linkset4ptr = linkset4;
                    linkset4ptr = &linkset4->next;
                }
            }
        }
    } else {
        for (; temp1; temp1 = temp1->next) {
            for (temp2 = linkset2; temp2; temp2 = temp2->next) {
                for (temp3 = linkset3; temp3; temp3 = temp3->next) {
                    if (tumblereq(&temp1->address, &temp2->address)
                        && tumblereq(&temp2->address, &temp3->address)) {
                        linkset4 = makelinkitem(sess, &temp1->address);
                        *linkset4ptr = linkset4;
                        linkset4ptr = &linkset4->next;
                    }
                }
            }
        }
    }
    debug = olddebug;
}
