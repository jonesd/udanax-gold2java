/**********************************************************************
 * Copyright 2002 Jeff Rush <jrush@taupro.com>
 * Original Copyright 1979-2002 Udanax.com
 *
 * This file is part of the Udanax xanalogical storage system.
 *
 * Udanax is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * Udanax is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with Udanax; if not, write to the Free Software Foundation,
 * Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 **********************************************************************/

/**
 * @file  orglinks.cxx
 * @brief permutation matrix enfilade calls, with link following routines
 *
 * (to be defined)
 *
 **/

/* Modification History:
 * $Log: orglinks.cxx,v $
 * Revision 1.14  2002/07/26 04:32:01  jrush
 * Replaced gerror() with assert()
 *
 * Revision 1.13  2002/05/28 04:22:29  jrush
 * Adjusted source files to comply with GPL licensing.
 *
 * Revision 1.12  2002/05/28 02:51:11  jrush
 * Made static any functions and global variables private to this source file
 * and commented out any unused functions.
 *
 * Revision 1.11  2002/04/12 11:56:43  jrush
 * Reorganized include file layout, renamed xanadu.h to udanax.h and
 * typecontext/typecrumcontext to C++ class Context/CrumContext.
 *
 * Revision 1.10  2002/04/10 18:01:54  jrush
 * Renamed class typeisa to IStreamAddr.
 *
 * Revision 1.9  2002/04/09 21:45:46  jrush
 * Renamed class 'tumbler' to 'Tumbler', for consistency with Python sources,
 * and changed typeisa from typedef to a subclass, in preparation for cleaning
 * up the type/class tree.
 *
 * Revision 1.8  2002/04/08 18:55:55  jrush
 * Switched from using global variable 'user' to object 'Session' as a
 * connection for tracking open document descriptors in the bert table.
 *
 * Revision 1.7  2002/04/06 20:42:50  jrush
 * Switch from sess->alloc() style to new(sess) Object parameterized allocator.
 *
 * Revision 1.6  2002/04/06 17:05:57  jrush
 * Switched from referring to 'task' for a client connection to 'session',
 * and converted the typetask typedef/struct into a Session C++ class.
 *
 * Revision 1.5  2002/04/06 15:01:17  jrush
 * Changed INT to just 'int'.
 *
 * Revision 1.4  2002/04/06 14:10:09  jrush
 * Cosmetic changes, commenting and rearrangement.
 *
 * Revision 1.3  2002/04/02 18:45:33  jrush
 * Fixed retrievevspansetpm() which seems to have never worked.  It was only
 * ever used by the front-end, so no one noticed, I guess.  Also added
 * useful debug messages.
 *
 * Revision 1.2  2002/02/14 09:27:43  jrush
 * Cleaned up source:
 *
 * 1. ran thru the indent tool to achieve a standard look,
 * 2. added structured comments at top for use with DOxygen reporting
 *    as well as CVS keywords,
 * 3. fixed compiler warnings re ambiguous assign/compares,
 *    needed casts and unused/uninitialized variables,
 * 4. fixed funcs that didn't specify a return type,
 * 5. centralized prototypes in protos.h, removing incomplete ones,
 * 6. cleaned up use of bool/BOOLEAN type to suit C++ type,
 * 7. fixed initializer nesting in tumbler constants,
 * 8. renamed vars that conflict with C++ keywords (new, this),
 * 9. fixed global/extern confusion re some global vars.
 *
 */

#include <memory.h>
#include "udanax.h"

static void
findnextaddressinvspace(typecorecrum *crumptr, typewid *offsetptr, Tumbler *nextvspacestartptr, Tumbler *vsaptr)
{
    typecorecrum *ptr;
    if (!(ptr = findleftson((typecuc *) crumptr)))
        return;

    Tumbler maxt;
    tumblerclear(&maxt);

    for (; ptr; ptr = findrightbro(ptr)) {
        typewid reach, grasp;
        prologuend(ptr, offsetptr, &grasp, &reach);

        if (whereoncrum(ptr, offsetptr, nextvspacestartptr, V) == THRUME) {
            findnextaddressinvspace(ptr, &grasp, nextvspacestartptr, vsaptr);
            return;

        } else if (tumblercmp(&grasp.dsas[V], nextvspacestartptr) != GREATER) {
            tumblermax(&reach.dsas[V], &maxt, &maxt);

        }
    }
    movetumbler(&maxt, vsaptr);
}

/**
 * @function findvsatoappend
 * @brief ???
 *
 * Compute the V-stream address just beyond the last byte of text, but before
 * any links; i.e. something in 1.xxx but before 2.
 *
 **/

static void
findvsatoappend(typecorecrum *ptr, Tumbler *vsaptr)
{
    typewid offset;
    clear(&offset, sizeof(offset));

    tumblerclear(vsaptr);

    Tumbler linkspacevstart;
    tumblerclear(&linkspacevstart);
    tumblerincrement(&linkspacevstart, 0, 2, &linkspacevstart);

    typewid grasp, reach;
    prologuend(ptr, &offset, &grasp, &reach);

    // If document contains no text but has links, just return a stream address of 1.1
    if (iszerolock((Tumbler *) &ptr->cwid, widsize(POOM)) || (tumblercmp(&grasp.dsas[V], &linkspacevstart) != LESS)) {
        tumblerincrement(vsaptr, 0, 1, vsaptr); /* no text in doc */
        tumblerincrement(vsaptr, 1, 1, vsaptr);

    // If document contains text but no links, return a stream address of the text's reach
    } else if (tumblercmp(&reach.dsas[V], &linkspacevstart) == LESS) {
        movetumbler(&reach.dsas[V], vsaptr);    /* no links in doc */

    // If document contains _both_ text and links
    } else
        findnextaddressinvspace(ptr, &grasp, &linkspacevstart, vsaptr);
}

/**
 * @function appendpm
 * @brief ???
 *
 * (to be defined)
 *
 **/

bool
appendpm(Session *sess, IStreamAddr *doc_isa, typetextset textset)
{
    /*
     * Walk the granfilade to find and lock the ORGL for the specified document.
     */
    typeorgl orglptr;
    if (!findorgl(sess, granf, doc_isa, &orglptr, WRITEBERT))
        return false;

    /*
     * Compute the highest stream address in use within the document, at which
     * to append the new content.
     */
    Tumbler vsa;
    findvsatoappend((typecorecrum *) orglptr, &vsa);

    return doinsert(sess, doc_isa, &vsa, textset);
}

bool
insertpm(Session *sess, Tumbler *orglisa, typeorgl orgl, Tumbler *vsaptr, typesporglset sporglset)
{
    Tumbler lstream, lwidth;
    type2dbottomcruminfo linfo;
    typewid crumorigin, crumwidth;
    Tumbler zero;
    int shift, inc;

#ifndef DISTRIBUTION
    if (debug) {
        fprintf(stderr, "\nINSERTpm  vsa ");
        dumptumbler(vsaptr);
        fprintf(stderr, "\n");
        dumpitemset((typeitem *) sporglset);
    }
#endif

    if (iszerotumbler(vsaptr)) {
#ifndef DISTRIBUTION
        fprintf(stderr, "insertpm inserting at 0 ---punt zzzz?");
#endif
        return false;
    }

    tumblerclear(&zero);

    if (tumblercmp(vsaptr, &zero) == LESS)
        assert(0); // insertpm called with negative vsa

    logbertmodified(sess, orglisa);
    for (; sporglset; sporglset = (typesporglset) sporglset->xxxxsporgl.next) {
        unpacksporgl(sporglset, &lstream, &lwidth, &linfo);

#ifndef DISTRIBUTION
        footumbler("lstream = ", &lstream);
#endif
        movetumbler(&lstream, &crumorigin.dsas[I]);

#ifndef DISTRIBUTION
        footumbler("lwidth = ", &lwidth);
#endif
        movetumbler(&lwidth, &crumwidth.dsas[I]);

#ifndef DISTRIBUTION
        footumbler("vsaptr = ", vsaptr);
#endif
        movetumbler(vsaptr, &crumorigin.dsas[V]);
/* I'm suspissious of this shift <reg> 3/1/85 zzzz */
        shift = tumblerlength(vsaptr) - 1;
        inc = tumblerintdiff(&lwidth, &zero);
        tumblerincrement(&zero, shift, inc, &crumwidth.dsas[V]);

#ifndef DISTRIBUTION
        footumbler("crumwidth = ", &crumwidth.dsas[V]);
#endif

        if (iszerotumbler(&crumwidth.dsas[V]))
            assert(0); // crum width 0 in insertpm

#ifndef DISTRIBUTION
        if (debug) {
            fprintf(stderr, "    crumorigin: ");
            dumpwid(&crumorigin, POOM);
            fprintf(stderr, "    crumwidth: ");
            dumpwid(&crumwidth, POOM);
        }
#endif
        insertnd(sess, (typecuc *) orgl, &crumorigin, &crumwidth, &linfo, V);
         /**/ tumbleradd(vsaptr, &crumwidth.dsas[V], vsaptr);
    }
    return true;
}

bool
rearrangepm(Session *sess, Tumbler *docisaptr, typeorgl docorgl, typecutseq *cutseqptr)
{
    rearrangend((typecuc *) docorgl, cutseqptr, V);
    logbertmodified(sess, docisaptr);

    return true;
}

bool
deletevspanpm(Session *sess, Tumbler *docisaptr, typeorgl docorgl, typevspan *vspanptr)
{
    if (iszerotumbler(&vspanptr->width))
        return false;

    deletend((typecuc *) docorgl, &vspanptr->stream, &vspanptr->width, V);
    logbertmodified(sess, docisaptr);

    return true;
}

bool
retrievedocumentpartofvspanpm(Session *sess, typeorgl orgl, typevspan *vspanptr)
{                                      /* this is a kluge */
    vspanptr->next   = NULL;
    vspanptr->itemid = VSPANID;

    movetumbler(&((typecuc *) orgl)->cdsp.dsas[V], &vspanptr->stream);
    movetumbler(&((typecuc *) orgl)->cwid.dsas[V], &vspanptr->width);

    return true;
}

bool
retrievevspanpm(Session *sess, typeorgl orgl, typevspan *vspanptr)
{
    vspanptr->next   = NULL;
    vspanptr->itemid = VSPANID;

    movetumbler(&((typecuc *) orgl)->cdsp.dsas[V], &vspanptr->stream);
    movetumbler(&((typecuc *) orgl)->cwid.dsas[V], &vspanptr->width);

    return true;
}

static bool
istextcrum(typecorecrum *crumptr)
{
    if (crumptr->cdsp.dsas[V].mantissa[1] == 0 && is1story(&crumptr->cwid.dsas[V])) {
        return true;
    }
    return false;
}

static bool
islinkcrum(typecorecrum *crumptr)
{
    if (crumptr->cdsp.dsas[V].mantissa[0] == 1 && crumptr->cdsp.dsas[V].mantissa[1] != 0) {
/* if the whold crum is displaced into link space it is a link crum; this is true if the tumbler is a 1.n tumbler where 
 * n!= 0 */
        return true;
    }
    return false;
}

static void
maxtextwid(Session *sess, typecorecrum *crumptr, Tumbler *voffset, Tumbler *maxwid)
{
    if (istextcrum(crumptr)) {
        Tumbler localvoffset;
        tumbleradd(voffset, &crumptr->cwid.dsas[V], &localvoffset);

        tumblermax(&localvoffset, maxwid, maxwid);

    } else { // Non-Text CRUM
        Tumbler localvoffset;
//        tumbleradd(voffset, &crumptr->cwid.dsas[V], &localvoffset);
//        tumbleradd(voffset, &crumptr->cdsp.dsas[V], &localvoffset);
        tumblercopy(voffset, &localvoffset);

        typecorecrum *ptr;
        for (ptr = findleftson((typecuc *) crumptr); ptr; ptr = findrightbro(ptr)) {
            if (ptr && !islinkcrum(ptr)) // only look for text or overlapping stuff
                maxtextwid(sess, ptr, &localvoffset, maxwid);

//            tumbleradd(&localvoffset, &ptr->cwid.dsas[V], &localvoffset);
        }
    }
}

static typevspan *
makevspan(Session *sess, typevspan *spanptr, typevspan *nextspan)
{
    typevspan *ret = new(sess) typevspan;
//    typevspan *ret = (typevspan *) sess->alloc(sizeof(typevspan));

    movetumbler(&spanptr->stream, &ret->stream);
    movetumbler(&spanptr->width, &ret->width);

    ret->itemid = VSPANID;
    ret->next   = nextspan;

    return ret;
}

static void
putvspaninlist(Session *sess, typevspan *spanptr, typevspanset *spansetptr)
{
    typevspan *ptr, *last;
    Tumbler newspanend, oldspanend;
    int startcmp, endcmp, spancmp;

    ptr = *spansetptr;
    last = NULL;
    if (!ptr) {
        *spansetptr = makevspan(sess, spanptr, (typevspan *) NULL);
        return;
    }

    for (; ptr; last = ptr, ptr = ptr->next) {
        tumbleradd(&spanptr->stream, &spanptr->width, &newspanend);
        tumbleradd(&ptr->stream, &ptr->width, &oldspanend);

        spancmp = tumblercmp(&spanptr->stream, &oldspanend);
        if (!spancmp) {
            tumbleradd(&ptr->width, &spanptr->width, &ptr->width);
            return;
        } else if (spancmp == GREATER)
            continue;

        spancmp = tumblercmp(&ptr->stream, &newspanend);
        if (!spancmp) {
            movetumbler(&spanptr->stream, &ptr->stream);
            tumbleradd(&spanptr->width, &ptr->width, &ptr->width);
            return;
        } else if (spancmp == GREATER) {
            if (ptr != *spansetptr)
                last->next = makevspan(sess, spanptr, ptr);
            else
                *spansetptr = makevspan(sess, spanptr, ptr);
            return;
        }

        startcmp = tumblercmp(&spanptr->stream, &ptr->stream);
        endcmp = tumblercmp(&newspanend, &oldspanend);
        if (startcmp > LESS && endcmp < GREATER)
            return;

        switch (startcmp) {
        case EQUAL:
            if (endcmp == GREATER)
                movetumbler(&spanptr->width, &ptr->width);
            return;
        case LESS:
            movetumbler(&spanptr->stream, &ptr->stream);
            if (endcmp == GREATER)
                movetumbler(&spanptr->width, &ptr->width);
            else
                tumblersub(&oldspanend, &spanptr->stream, &ptr->width);
            break;
        case GREATER:
            if (endcmp == GREATER) {
                tumblersub(&newspanend, &ptr->stream, &ptr->width);
                return;
            }
        }
    }
    last->next = makevspan(sess, spanptr, (typevspan *) NULL);
}

bool
retrievevspansetpm(Session *sess, typeorgl orgl, typevspanset *vspansetptr)
{                                      /* return spans for doc and link part */
    typecorecrum *ccptr = (typecorecrum *) orgl;

    *vspansetptr = NULL;
    if (is1story(&ccptr->cwid.dsas[V])) {       /* if it is just text return that */
        typevspan  vspan;
        vspan.next   = NULL;
        vspan.itemid = VSPANID;

        movetumbler(&ccptr->cdsp.dsas[V], &vspan.stream);
        movetumbler(&ccptr->cwid.dsas[V], &vspan.width);

        putvspaninlist(sess, &vspan, vspansetptr);
        return true;

    } else {
        /* The link part is simple, just grab the last digit off the wid.  The
         * text part we get from a max function that delves into the crums. In
         * both cases we have to remove the first digit of the tumbler, the 1
         * and hack it around a bit.
         */

        typevspan  bytevspan;
        bytevspan.next   = NULL;
        bytevspan.itemid = VSPANID;

        typevspan  linkvspan;
        linkvspan.next   = NULL;
        linkvspan.itemid = VSPANID;

        movetumbler(&ccptr->cdsp.dsas[V], &bytevspan.stream);

        Tumbler voffset;
        tumblerclear(&voffset);

        Tumbler  maxwid;
        tumblerclear(&maxwid);
        maxtextwid(sess, ccptr, &voffset, &maxwid);

        movetumbler(&maxwid, &bytevspan.width);

        movetumbler(&ccptr->cdsp.dsas[V], &linkvspan.stream);
        linkvspan.stream.mantissa[0] = 2;

        movetumbler(&ccptr->cwid.dsas[V], &linkvspan.width);
        linkvspan.width.mantissa[0] = 0;
        tumblerjustify(&linkvspan.width);

        putvspaninlist(sess, &bytevspan, vspansetptr);
        putvspaninlist(sess, &linkvspan, vspansetptr);

        return true;
    }
}

#ifdef UnDEFined

//UNUSED bool
//UNUSED retrievevspansetpm(Session *sess, typeorgl orgl, typevspanset *vspansetptr)
//UNUSED /* return spans for doc and link part */
//UNUSED {
//UNUSED     Tumbler voffset;
//UNUSED 
//UNUSED     tumblerclear(&voffset);
//UNUSED     *vspansetptr = NULL;
//UNUSED 
//UNUSED     walkorglonvpm(sess, (typecorecrum *) orgl, &voffset, vspansetptr);
//UNUSED     cleanupvspanlist(sess, vspansetptr);
//UNUSED 
//UNUSED     return true;
//UNUSED }

//UNUSED void
//UNUSED walkorglonvpm(Session *sess, typecorecrum *crumptr, Tumbler *voffset, typevspanset *vspansetptr)
//UNUSED {
//UNUSED     typecorecrum *ptr;
//UNUSED     typevspan vspan;
//UNUSED     Tumbler localvoffset;
//UNUSED 
//UNUSED     if (is1story(&crumptr->cwid.dsas[V])) {
//UNUSED         vspan.itemid = VSPANID;
//UNUSED         tumbleradd(voffset, &crumptr->cdsp.dsas[V], &vspan.stream);
//UNUSED         movetumbler(&crumptr->cwid.dsas[V], &vspan.width);
//UNUSED         vspan.next = NULL;
//UNUSED 
//UNUSED         putvspaninlist(sess, &vspan, vspansetptr);
//UNUSED 
//UNUSED     } else {
//UNUSED         tumbleradd(voffset, &crumptr->cdsp.dsas[V], &localvoffset);
//UNUSED         for (ptr = findleftson((typecuc *) crumptr); ptr; ptr = findrightbro(ptr)) {
//UNUSED             walkorglonvpm(sess, ptr, &localvoffset, vspansetptr);
//UNUSED         }
//UNUSED     }
//UNUSED }

//UNUSED void
//UNUSED cleanupvspanlist(Session *sess, typevspanset *vspansetptr)
//UNUSED {
//UNUSED     typevspan *ptr;
//UNUSED     Tumbler spanend;
//UNUSED 
//UNUSED     if (!(ptr = *vspansetptr))
//UNUSED         return;
//UNUSED 
//UNUSED     for (; ptr && ptr->next; ptr = ptr->next) {
//UNUSED         tumbleradd(&ptr->stream, &ptr->width, &spanend);
//UNUSED         if (tumblereq(&spanend, &ptr->next->stream)) {
//UNUSED             tumbleradd(&ptr->width, &ptr->next->width, &ptr->width);
//UNUSED             ptr->next = ptr->next->next;
//UNUSED         }
//UNUSED     }
//UNUSED }
#endif

static typespanset *
span2spanset(Session *sess, typeorgl orgl, typespanset restrictionspanptr, int restrictionindex,
             typespanset *targspansetptr, int targindex)
{
    typespan foundspan;
    typespan *nextptr = NULL;

#ifndef DISTRIBUTION
    foo("entering span2spanset\n");
#endif

    Context *context = retrieverestricted((typecuc *) orgl, restrictionspanptr, restrictionindex, (typespan *) NULL, targindex, (IStreamAddr *) NULL);

#ifndef DISTRIBUTION
    foocontextlist("in sapan2spanset after retrieverestrictec context =", context);
#endif

    Context *c;
    for (c = context; c; c = (Context *) c->nextcontext) {

#ifndef DISTRIBUTION
        foocontext("in span2spanset loop  ", c);
#endif

        context2span(c, restrictionspanptr, restrictionindex, &foundspan, targindex);
        nextptr = (typespan *) onitemlist(sess, (typeitem *) & foundspan, (typeitemset *) targspansetptr);
    }

    if (!context) {
        return (targspansetptr);
    }

#ifndef DISTRIBUTION
    foocontext("leaving span2spanset returning context = \n", context);
#endif

    contextfree(context);
    return &nextptr->next;
}

static typespanset *
permute(Session *sess, typeorgl orgl, typespanset restrictionspanset, int restrictionindex,
        typespanset *targspansetptr, int targindex)
{
    typespanset *save = targspansetptr;

#ifndef DISTRIBUTION
    foo("entering permute\n");
    foospanset("targspanset ", *targspansetptr);
    foospanset("restrictionset is ", restrictionspanset);
#endif

/* consolidatespans(restrictionspanset); foospanset("restrictionset after consolidation is ",restrictionspanset); */

    for (; restrictionspanset; restrictionspanset = restrictionspanset->next) {
        targspansetptr = span2spanset(sess, orgl, restrictionspanset, restrictionindex, targspansetptr, targindex);
    }

#ifndef DISTRIBUTION
    foospanset("leaving permute\n", *save);
/* checkpointer ("targspansetptr(permute): ", targspansetptr); */
#endif

    return save;
}

typevspanset *
ispan2vspanset(Session *sess, typeorgl orgl, typeispan *ispanptr, typevspanset *vspansetptr)
{
    return permute(sess, orgl, ispanptr, I, vspansetptr, V);
}

typeispanset *
vspanset2ispanset(Session *sess, typeorgl orgl, typevspanset vspanptr, typeispanset *ispansetptr)
{
    return permute(sess, orgl, vspanptr, V, ispansetptr, I);
}

/* 
 * consolidatespanset(spanset); typespan *spanset; {
 * for(;spanset->next;spanset = spanset->next){ if( } } */

typeitem *
onitemlist(Session *sess, typeitem *itemptr, typeitemset *itemsetptr)
{
    typeitem *temp, *newitem = NULL;

/* foo("entering onitemlist\n"); */
#ifndef DISTRIBUTION
    if (!itemsetptr)
        assert(0); // Null itemsetptr

    if (!itemptr)
        assert(0); // Null itemptr
#else
    if (!itemsetptr || !itemptr)
        assert(0);
#endif

    switch (((typeitemheader *) itemptr)->itemid) {     /* allocate and copy to proper sized item */
    case TEXTID:
        newitem = (typeitem *) new(sess) typetext;
//        newitem = (typeitem *) sess->alloc(sizeof(typetext));
        movmem(itemptr, newitem, sizeof(typetext));
        break;

    case ISPANID:
        newitem = (typeitem *) new(sess) typeispan;
//        newitem = (typeitem *) sess->alloc(sizeof(typeispan));
        movmem(itemptr, newitem, sizeof(typeispan));
        break;

    case VSPANID:
        newitem = (typeitem *) new(sess) typevspan;
//        newitem = (typeitem *) sess->alloc(sizeof(typevspan));
        movmem(itemptr, newitem, sizeof(typevspan));
        break;

    case VSPECID:
        newitem = (typeitem *) new(sess) typevspec;
//        newitem = (typeitem *) sess->alloc(sizeof(typevspec));
        movmem(itemptr, newitem, sizeof(typevspec));
        break;

    case NODEID:
        newitem = (typeitem *) new(sess) typeboolsetnode;
//        newitem = (typeitem *) sess->alloc(sizeof(typeboolsetnode));
        movmem(itemptr, newitem, sizeof(typeboolsetnode));
        break;

    case ADDRESSID:                   /* also LINKID */
        newitem = (typeitem *) new(sess) typeaddress;
//        newitem = (typeitem *) sess->alloc(sizeof(typeaddress));
        movmem(itemptr, newitem, sizeof(typeaddress));
        break;

    case SPORGLID:                    /* zzz kluge sporglitem is union * sporgl is struct which should i use * here
                                        * i.e. how is this used and set * in fact sporgl happens to be big * member in
                                        * union but this is * troubles me REG 1/5/86 */
        newitem = (typeitem *) new(sess) typesporglitem;
//        newitem = (typeitem *) sess->alloc(sizeof(typesporglitem));
        movmem(itemptr, newitem, sizeof(typesporglitem));
        break;

    default:
        assert(0); // improper item
    }

    ((typeitemheader *) newitem)->next = NULL;
    if (*itemsetptr == NULL) {
        *itemsetptr = newitem;
    } else {

        /* this loop advances the ptr ot the end of the list */
        for (temp = *itemsetptr;
#ifndef DISTRIBUTION
             checkitem("onitem2.5: ", temp), checkitem("onitem2.75: ", (typeitem *) ((typeitemheader *) temp)->next),
#endif
             temp && ((typeitemheader *) temp)->next; temp = (typeitem *) ((typeitemheader *) temp)->next)

#ifndef DISTRIBUTION
            if (debug) {
                checkitem("onitem3: ", temp);
            }
#else
            ;
#endif

        ((typeitemheader *) temp)->next = (typeitemheader *) newitem;
    }

    return newitem;
}

bool
isemptyorgl(typeorgl fullcrumptr)
{
    return iszerolock((Tumbler *) & ((typecuc *) fullcrumptr)->cwid, widsize(POOM)) && iszerolock((Tumbler *) & ((typecuc *) fullcrumptr)->cdsp, dspsize(POOM));
}

