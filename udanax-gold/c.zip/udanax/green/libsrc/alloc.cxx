/**********************************************************************
 * Copyright 2002 Jeff Rush <jrush@taupro.com>
 * Original Copyright 1979-2002 Udanax.com
 *
 * This file is part of the Udanax xanalogical storage system.
 *
 * Udanax is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * Udanax is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with Udanax; if not, write to the Free Software Foundation,
 * Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 **********************************************************************/

/**********************************************************************
 * @file  alloc.cxx
 * @brief xxx
 *
 * (to be defined)
 *
 **********************************************************************/

/*
 * $Log: alloc.cxx,v $
 * Revision 1.9  2002/07/26 04:30:29  jrush
 * Replaced gerror() with assert()
 *
 * Revision 1.8  2002/05/28 04:22:29  jrush
 * Adjusted source files to comply with GPL licensing.
 *
 * Revision 1.7  2002/05/28 02:49:42  jrush
 * Made static any functions and global variables private to this source file
 * and commented out any unused functions.
 *
 * Revision 1.6  2002/04/12 22:53:20  jrush
 * Changed from using my setmem() to the clib's memset() and removed no
 * longer-needed usefull.cxx
 *
 * Revision 1.5  2002/04/12 11:56:42  jrush
 * Reorganized include file layout, renamed xanadu.h to udanax.h and
 * typecontext/typecrumcontext to C++ class Context/CrumContext.
 *
 * Revision 1.4  2002/04/06 19:51:30  jrush
 * Renamed TRUE/FALSE constant use to the C++ standard of true/false.
 *
 * Revision 1.3  2002/04/06 15:01:17  jrush
 * Changed INT to just 'int'.
 *
 * Revision 1.2  2002/02/14 09:27:43  jrush
 * Cleaned up source:
 *
 * 1. ran thru the indent tool to achieve a standard look,
 * 2. added structured comments at top for use with DOxygen reporting
 *    as well as CVS keywords,
 * 3. fixed compiler warnings re ambiguous assign/compares,
 *    needed casts and unused/uninitialized variables,
 * 4. fixed funcs that didn't specify a return type,
 * 5. centralized prototypes in protos.h, removing incomplete ones,
 * 6. cleaned up use of bool/BOOLEAN type to suit C++ type,
 * 7. fixed initializer nesting in tumbler constants,
 * 8. renamed vars that conflict with C++ keywords (new, this),
 * 9. fixed global/extern confusion re some global vars.
 *
 * Revision 1.2  2002/01/31 11:32:47  jrush
 * Ran C source thru 'ident' program; added void return type to those
 * functions missing any return type whatsoever; and converted args
 * from old K&R to new ANSI C inline style.  Also added basic DOxygen
 * source-markup header to top of each file, as well as a copyright
 * notice at the bottom.
 *
 */

#include <unistd.h>
#include <sys/errno.h>
#include "udanax.h"

//extern int errno;
extern int ingrimreaper;

int incrementalallocsize = INCREMENTALALLOCSIZE;
int allocsize = ALLOCSIZE;

static HEADER base;
static HEADER *allocp = NULL;
static HEADER baseallocated;

static int flag = 0;
static char *zzalloctop = 0, *zzallocbot = 0;
static int alloccount = 0;

/**********************************************************************
 *
 **********************************************************************/
void
lookatalloc()
{
    lookatalloc2(&baseallocated);
}

/**********************************************************************
 *
 **********************************************************************/
static int
statusofalloc(char * /*c*/)
{
    unsigned number, maxsize, cumsize;

/* checkalloc (c); */
    number = maxsize = cumsize = 0;

    HEADER *r;
    for (r = base.s.ptr; flag && (r != &base); r = r->s.ptr) {
        maxsize = (maxsize > r->s.size ? maxsize : r->s.size);
        cumsize += r->s.size;
        number++;
    }
    fprintf(stderr, "%d free hunks %d maxsize %d total free\n", number, maxsize, cumsize);
    return true;
}

/**********************************************************************
 *
 **********************************************************************/
static int
validallocthinge(char *ptr)
{
    return 1;

//    if (!flag)
//        return true;
//
//    HEADER *p = (HEADER *) ptr;
//    if (p->s.size == 0 && p != * (HEADER *)zzalloctop) {
//        fprintf(stderr, "validallocthinge called with ptr = %x bottom = %x top = %x\n", ptr, zzallocbot, zzalloctop);
//        statusofalloc("");
//        assert(0); // attempt to free zero size thing
//    }
//
//    if (flag && (unsigned) ptr > (unsigned) zzalloctop || (unsigned) ptr < (unsigned) zzallocbot) {
//        fprintf(stderr, "validallocthinge called with ptr = %x bottom = %x top = %xn", ptr, zzallocbot, zzalloctop);
//        assert(0); // bad validity check in alloc
//        return 0;
//    }
//    return true;
}

/**********************************************************************
 *
 **********************************************************************/
int
checkalloc(char *c)
{
    HEADER *r, *oldr;
    unsigned size;

    if (!flag)
        return /*BUG: original code returned nothing, I guess I'll return a zero*/ 0;

    if (debug && *c)
        fprintf(stderr, "%s", c);

    unsigned oldsize = 0;
    for (oldr = r = base.s.ptr; flag && (r != &base) && (r != (HEADER *) zzalloctop); r = r + r->s.size) {
        size = r->s.size;
        validallocthinge((char *) r);
        if (r->s.size == 0 && r != (HEADER *) zzalloctop) {
            fprintf(stderr, "checkalloc glorphed with ptr = %x bottom = %x top = %x\n", (int) r, (int) zzallocbot, (int) zzalloctop);
            statusofalloc("");
            assert(0); // found zero size in alloced stuff
            return 1;
        }
        oldr = r;
        oldsize = size;
    }
    return true;
}

/**********************************************************************
 *
 **********************************************************************/
//UNUSED static void // never called
//UNUSED checkallocedptr(char *ptr, char *string)
//UNUSED {
//UNUSED     if (((HEADER *) (ptr - sizeof(HEADER) - sizeof(tagtype)))->s.size == 0) {
//UNUSED         fprintf(stderr, "checkallocedptr %s \n", string);
//UNUSED         assert(0); // found null size
//UNUSED     }
//UNUSED 
//UNUSED }

/**********************************************************************
 *
 **********************************************************************/
static HEADER *
weresurethatthisisourmorecore()
{
    HEADER *up;
    int temp;

    if (flag)
        return NULL;

    char *cp   = (char *) sbrk(allocsize);
    zzalloctop = (char *)cp + allocsize;
    zzallocbot = (char *)cp;

    if ((int) cp == -1) {
        flag = 1;
        return NULL;
    }

    up   = (HEADER *) cp;
    temp = up->s.size = ((unsigned) allocsize) / sizeof(HEADER);

    if (temp == 0)
        assert(0); // this dumb fucker doesnt do arithmetic right

    baseallocated.s.ptr = (HEADER *) cp;
    baseallocated.s.size = temp;
    ffree((char *)(cp + sizeof(HEADER) /* up +1 */ ));
    flag = 1;

    return allocp;
}

/**********************************************************************
 *
 **********************************************************************/
int *
falloc(unsigned nbytes)
{
    register HEADER *p, *q;
    register unsigned nunits;

/* if (errno) { if (errno != ENOTTY) perror ("xumain/backend/alloc"); errno = 0; } */

    if (ingrimreaper) {
        fprintf(stderr, "really error in falloc called from under grimreaper\n");
        assert(0); // falloc called from under grimreaper
    }

    assert(nbytes > 0); // falloc called with nbytes = 0

    //fprintf(stderr,"falloc called with %d\n",nbytes);

    alloccount++;
    nunits = 1 + (nbytes + sizeof(HEADER) - 1) / sizeof(HEADER);
    if ((q = allocp) == NULL) {
        base.s.ptr = allocp = q = &base;
        base.s.size = 0;
    } else {
/* checkalloc(""); */
    }
    for (p = q->s.ptr;; q = p, p = p->s.ptr) {
        if (p->s.size >= nunits) {
            if (p->s.size == nunits)
                q->s.ptr = p->s.ptr;
            else {
                p->s.size -= nunits;
                p += p->s.size;
                p->s.size = nunits;
            }
            p->s.ptr = NULL;
            allocp = q;
            return (int *) (p + 1);
        }
        if (p == allocp)
            if ((p = weresurethatthisisourmorecore()) == NULL)
                return NULL;
    }
}

/**********************************************************************
 *
 **********************************************************************/
void
ffree(char *ap)
{
    register HEADER *p, *q;

/* if (errno) { if (errno != ENOTTY) perror ("xumain/backend/free"); errno = 0; } */
    p = (HEADER *) ap - 1;
    if (flag) {

        if (!validallocthinge((char *) p))
            assert(0); // wierd free in alloc
    }

    // memset(ap, 0, (p->s.size - 1) * sizeof(HEADER));

    for (q = allocp; !(p > q && p < q->s.ptr); q = q->s.ptr) {
        if (q >= q->s.ptr && (p > q || p < q->s.ptr)) {
            break;
        }
    }

    if (p + p->s.size == q->s.ptr) {
        p->s.size += q->s.ptr->s.size;
        p->s.ptr = q->s.ptr->s.ptr;
    } else {
        p->s.ptr = q->s.ptr;
    }
    if (q + q->s.size == p) {
        q->s.size += p->s.size;
        q->s.ptr = p->s.ptr;
    } else {
        q->s.ptr = p;
    }
    allocp = q;
/* checkalloc(""); */
}
