/**********************************************************************
 * Copyright 2002 Jeff Rush <jrush@taupro.com>
 * Original Copyright 1979-2002 Udanax.com
 *
 * This file is part of the Udanax xanalogical storage system.
 *
 * Udanax is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * Udanax is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with Udanax; if not, write to the Free Software Foundation,
 * Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 **********************************************************************/

/**
 * @file  do1.cxx
 * @brief Udanax document handling routines
 *
 * (to be defined)
 *
 **/

/* Modification History:
 * $Log: do1.cxx,v $
 * Revision 1.14  2002/07/26 04:32:01  jrush
 * Replaced gerror() with assert()
 *
 * Revision 1.13  2002/05/28 04:22:29  jrush
 * Adjusted source files to comply with GPL licensing.
 *
 * Revision 1.12  2002/05/28 02:47:11  jrush
 * Cosmetic -- removed some comments.
 *
 * Revision 1.11  2002/04/12 11:56:42  jrush
 * Reorganized include file layout, renamed xanadu.h to udanax.h and
 * typecontext/typecrumcontext to C++ class Context/CrumContext.
 *
 * Revision 1.10  2002/04/10 18:01:54  jrush
 * Renamed class typeisa to IStreamAddr.
 *
 * Revision 1.9  2002/04/09 21:45:46  jrush
 * Renamed class 'tumbler' to 'Tumbler', for consistency with Python sources,
 * and changed typeisa from typedef to a subclass, in preparation for cleaning
 * up the type/class tree.
 *
 * Revision 1.8  2002/04/08 18:55:56  jrush
 * Switched from using global variable 'user' to object 'Session' as a
 * connection for tracking open document descriptors in the bert table.
 *
 * Revision 1.7  2002/04/07 14:04:37  jrush
 * Add ptr to Session to checkforopen() and isthisusersdocument() so that we
 * have session information available to make the decision.
 *
 * Revision 1.6  2002/04/06 17:05:57  jrush
 * Switched from referring to 'task' for a client connection to 'session',
 * and converted the typetask typedef/struct into a Session C++ class.
 *
 * Revision 1.5  2002/04/06 15:01:17  jrush
 * Changed INT to just 'int'.
 *
 * Revision 1.4  2002/04/06 14:05:24  jrush
 * Added functions to graph POOMs via the DOT tool, as well as more debug
 * messages as I attempt to get docopy() to work in all cases.
 *
 * Revision 1.3  2002/04/02 18:44:50  jrush
 * Added calls to output graphs of the enfilade trees in docopy(), some debug
 * messages and a few cosmetic changes.
 *
 * Revision 1.2  2002/02/14 09:27:43  jrush
 * Cleaned up source:
 *
 * 1. ran thru the indent tool to achieve a standard look,
 * 2. added structured comments at top for use with DOxygen reporting
 *    as well as CVS keywords,
 * 3. fixed compiler warnings re ambiguous assign/compares,
 *    needed casts and unused/uninitialized variables,
 * 4. fixed funcs that didn't specify a return type,
 * 5. centralized prototypes in protos.h, removing incomplete ones,
 * 6. cleaned up use of bool/BOOLEAN type to suit C++ type,
 * 7. fixed initializer nesting in tumbler constants,
 * 8. renamed vars that conflict with C++ keywords (new, this),
 * 9. fixed global/extern confusion re some global vars.
 *
 */

#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include "udanax.h"

extern void graphwholetree(char *filename, typecorecrum *ptr, char *graphtitle);

typespec spec, spec2, spec3;
typevstuffset uppervstuffset;
Tumbler fivetumbler = { 0, 0, 0, 0, { 500 /* 100 */ , 0, 0, 0, 0, 0, 0, 0, 0, 0, 0} };

bool
dofinddocscontaining(Session *sess, typespecset specset, typelinkset *addresssetptr)
{
    typeispanset ispanset;

    return specset2ispanset(sess, specset, &ispanset, NOBERTREQUIRED)
            && finddocscontainingsp(sess, ispanset, addresssetptr);
}

/**
 * @function doappend
 * @brief ???
 *
 * Append a set of text strings to the end of the bytestream of a document.
 *
 **/

bool
doappend(Session *sess, IStreamAddr *doc_isa, typetextset textset)
{
    return appendpm(sess, doc_isa, textset);

    /* && appendpm includes * insertspanf! *
    * insertspanf(sess,spanf,docptr,textset,DOCISPAN) */
}

bool
dorearrange(Session *sess, IStreamAddr *docisaptr, typecutseq *cutseqptr)
{
    typeorgl docorgl;

    return (findorgl(sess, granf, docisaptr, &docorgl, WRITEBERT)
            && rearrangepm(sess, docisaptr, docorgl, cutseqptr)
/* && true *//* ht stuff */
            );
}

bool
docopy(Session *sess, IStreamAddr *docisaptr, Tumbler *vsaptr, typespecset specset)
{
    bool f;

    printf("(specset2ispanset p=0x%08X)\n", (int) specset); putitemset(sess, (typeitem *) specset);  printf(")\n");

    typeispanset ispanset;
    f = specset2ispanset(sess, specset, &ispanset, NOBERTREQUIRED);
    if (!f) {
        printf("(specset2ispanset FAILED)\n");
        return false;
    }

    printf("ispanset is 0x%08X\n", (int) ispanset);
    printf("(specset2ispanset ispanset=");  putitemset(sess, (typeitem *) ispanset);  printf(")\n");
    printf("(findorgl for docisa=");  puttumbler(stdout, docisaptr);  printf(")\n");

    /*
     * Walk the granfilade to locate and lock, for writing, the document to receive
     * the copied material.
     */

    typeorgl docorgl;
    f = findorgl(sess, granf, docisaptr, &docorgl, WRITEBERT);
    if (!f) {
        printf("(attempt to findorgl FAILED)\n");
        return false;
    }

    /*
     * Validate the V-stream address at which to insert the content for reasonableness.
     */	
    printf("(acceptablevsa)\n");
    f = acceptablevsa(vsaptr, docorgl);
    if (!f) {
        printf("(acceptablevsa FAILED)\n");
        return false;
    }

    printf("(asserttreeisok)\n");
    f = asserttreeisok((typecorecrum *) docorgl);
    if (!f) {
        printf("(asserttreeisok FAILED)\n");
        return false;
    }

//    printf("---- Dump of Entire Granfilade Before Copy ----\n");
//    dumpwholetree((typecorecrum *) granf);
    graphwholetree("/var/tmp/granf_before.dot", (typecorecrum *) granf, "Granfilade before Copy");

//    printf("---- End of Dump of Entire Granfilade Before Copy ----\n");

//    printf("---- Dump of Entire Spanfilade Before Copy ----\n");
//    dumpwholetree((typecorecrum *) spanf);
    graphwholetree("/var/tmp/spanf_before.dot", (typecorecrum *) spanf, "Spanfilade before Copy");
//    printf("---- End of Dump of Entire Spanfilade Before Copy ----\n");

    /*
     *
     */

/* the meat of docopy: */
    printf("(insertpm)\n");
    f = insertpm(sess, docisaptr, docorgl, vsaptr, (typesporglitem *) ispanset);
    if (!f) {
        printf("(insertpm FAILED)\n");
        return false;
    }

    printf("(insertspanf)\n");
    f = insertspanf(sess, spanf, docisaptr, (typesporglitem *) ispanset, DOCISPAN);
    if (!f) {
        printf("(insertspanf FAILED)\n");
        return false;
    }

    printf("(asserttreeisok)\n");
    f = asserttreeisok((typecorecrum *) docorgl);
    if (!f) {
        printf("(asserttreeisok FAILED)\n");
        return false;
    }

/* && ht stuff */

//    printf("---- Dump of Entire Granfilade After Copy ----\n");
//    dumpwholetree((typecorecrum *) granf);
    graphwholetree("/var/tmp/granf_after.dot", (typecorecrum *) granf, "Granfilade after Copy");
//    printf("---- End of Dump of Entire Granfilade After Copy ----\n");

//    printf("---- Dump of Entire Spanfilade After Copy ----\n");
//    dumpwholetree((typecorecrum *) spanf);
    graphwholetree("/var/tmp/spanf_after.dot", (typecorecrum *) spanf, "Spanfilade after Copy");
//    printf("---- End of Dump of Entire Spanfilade After Copy ----\n");

    return true;
}

bool
docopyinternal(Session *sess, IStreamAddr *docisaptr, Tumbler *vsaptr, typespecset specset)
{
    typeispanset ispanset;

/* IStreamAddr htisa; */
    typeorgl docorgl;

    return (specset2ispanset(sess, specset, &ispanset, NOBERTREQUIRED)
            && findorgl(sess, granf, docisaptr, &docorgl, NOBERTREQUIRED)
            && acceptablevsa(vsaptr, docorgl)
            && asserttreeisok((typecorecrum *) docorgl)

/* the meat of docopy: */
            && insertpm(sess, docisaptr, docorgl, vsaptr, (typesporglitem *) ispanset)

            && insertspanf(sess, spanf, docisaptr, (typesporglitem *) ispanset, DOCISPAN)
            && asserttreeisok((typecorecrum *) docorgl)
/* && ht stuff */
            );
}

bool
doinsert(Session *sess, IStreamAddr *docisaptr, Tumbler *vsaptr, typetextset textset)
{
    typehint hint;
    typespanset ispanset;

/* these defs for debug */
/* typespan thisspan; */
    int ret;

/* int temp; */

/* if(debug){ debug = false; spec.docisa = *docisaptr; ((typeitemheader)spec).next = NULL; spec.itemid = VSPECID;
 * spec.vspanset = &thisspan; thisspan.itemid = VSPANID; thisspan.next = NULL; temp = vsaptr->mantissa[1];
 * thisspan.stream = *vsaptr; thisspan.width = fivetumbler; spec.vspanset->stream.mantissa[1] =1// +=5//;
 * copyspecset(sess,&spec,&spec2); copyspecset(sess,&spec,&spec3); spec3.vspanset->stream.mantissa[1] +=
 * textset->length; doretrievev(sess,&spec2,&uppervstuffset); vsaptr->mantissa[1] = temp; debug = true; } */

    makehint(DOCUMENT, ATOM, TEXTATOM, docisaptr, &hint);
    ret = (inserttextingranf(sess, granf, &hint, textset, &ispanset)
           && docopy(sess, docisaptr, vsaptr, (typespec *) ispanset)
/* no ht stuff here, 'cause it's taken care of in */
/* docopy */ );
    return (ret);
}

void
checkspecandstringbefore()
{
    printf("--checkspecandstringbefore is a NOP--\n");
    return;
/* if(debug){ assertspecisstring(&spec2,uppervstuffset->xxtest.string); } */
}

//obsolete void
//obsolete copyspecset(Session *sess, typespec *specptr, typespec *newptr)
//obsolete {
//obsolete     typespec *thisspec;
//obsolete 
//obsolete     if (specptr == NULL)
//obsolete         return;
//obsolete 
//obsolete     thisspec = newptr;
//obsolete 
//obsolete     for (; specptr;
//obsolete          specptr = (typespec *) ((typeitemheader *) specptr)->next, thisspec =
//obsolete          (typespec *) talloc(sess, sizeof(typespec))) {
//obsolete         *thisspec = *specptr;
//obsolete         copyspanset(sess, ((typevspec *) specptr)->vspanset, &((typevspec *) thisspec)->vspanset);
//obsolete     }
//obsolete 
//obsolete     ((typeitemheader *) thisspec)->next = NULL;
//obsolete }

//obsolete void
//obsolete copyspanset(Session *sess, typespan *spanptr, typespan **newptrptr)
//obsolete {
//obsolete     typespan *thisspan = (typespan *) talloc(sess, sizeof(typespan));
//obsolete 
//obsolete     *newptrptr = thisspan;
//obsolete 
//obsolete     for (; spanptr; spanptr = spanptr->next, thisspan->next = (typespan *) talloc(sess, sizeof(typespan))) {
//obsolete         *thisspan = *spanptr;
//obsolete     }
//obsolete 
//obsolete     thisspan->next = NULL;
//obsolete }

bool
dodeletevspan(Session *sess, IStreamAddr *docisaptr, typevspan *vspanptr)
{
    typeorgl docorgl;

    if (findorgl(sess, granf, docisaptr, &docorgl, WRITEBERT))
        return deletevspanpm(sess, docisaptr, docorgl, vspanptr);

    return false;
}

bool
domakelink(Session *sess, IStreamAddr *docisaptr, typespecset fromspecset, typespecset tospecset, IStreamAddr *linkisaptr)
{
    typehint hint;
    Tumbler linkvsa, fromvsa, tovsa;
    typespanset ispanset;
    typesporglset fromsporglset;
    typesporglset tosporglset;
    typeorgl link;

    makehint(DOCUMENT, ATOM, LINKATOM, docisaptr, &hint);
    return createorglingranf(sess, granf, &hint, linkisaptr)
            && tumbler2spanset(sess, linkisaptr, &ispanset)
            && findnextlinkvsa(sess, docisaptr, &linkvsa)
            && docopy(sess, docisaptr, &linkvsa, (typespec *) ispanset)
            && findorgl(sess, granf, linkisaptr, &link, WRITEBERT)
            && specset2sporglset(sess, fromspecset, &fromsporglset, NOBERTREQUIRED)
            && specset2sporglset(sess, tospecset, &tosporglset, NOBERTREQUIRED)
            && setlinkvsas(&fromvsa, &tovsa, NULL)
            && insertendsetsinorgl(sess, linkisaptr, link, &fromvsa, fromsporglset, &tovsa, tosporglset, NULL, NULL)
            && insertendsetsinspanf(sess, spanf, linkisaptr, fromsporglset, tosporglset, NULL)
            ;
}

bool
docreatelink(Session *sess, IStreamAddr *docisaptr, typespecset fromspecset, typespecset tospecset,
             typespecset threespecset, IStreamAddr *linkisaptr)
{
    typehint hint;
    Tumbler linkvsa, fromvsa, tovsa, threevsa;
    typespanset ispanset;
    typesporglset fromsporglset;
    typesporglset tosporglset;
    typesporglset threesporglset;
    typeorgl link;

    makehint(DOCUMENT, ATOM, LINKATOM, docisaptr, &hint);
    return (createorglingranf(sess, granf, &hint, linkisaptr)
            && tumbler2spanset(sess, linkisaptr, &ispanset)
            && findnextlinkvsa(sess, docisaptr, &linkvsa)
            && docopy(sess, docisaptr, &linkvsa, (typespec *) ispanset)
            && findorgl(sess, granf, linkisaptr, &link, /* WRITEBERT ECH 7-1 */ NOBERTREQUIRED)
            && specset2sporglset(sess, fromspecset, &fromsporglset, NOBERTREQUIRED)
            && specset2sporglset(sess, tospecset, &tosporglset, NOBERTREQUIRED)
            && specset2sporglset(sess, threespecset, &threesporglset, NOBERTREQUIRED)
            && setlinkvsas(&fromvsa, &tovsa, &threevsa)
            && insertendsetsinorgl(sess, linkisaptr, link, &fromvsa, fromsporglset, &tovsa, tosporglset, &threevsa,
                                   threesporglset)
            && insertendsetsinspanf(sess, spanf, linkisaptr, fromsporglset, tosporglset, threesporglset)
            );
}

bool
dofollowlink(Session *sess, IStreamAddr *linkisaptr, typespecset *specsetptr, int whichend)
{
    typesporglset sporglset;

    return (link2sporglset(sess, linkisaptr, &sporglset, whichend, NOBERTREQUIRED)
            && linksporglset2specset(sess, &((typesporgl *) sporglset)->sporgladdress, sporglset, specsetptr, /* ECH 
                                                                                                                  * 6-29 
                                                                                                                  * READBERT 
                                                                                                                  */ NOBERTREQUIRED));

}

bool
docreatenewdocument(Session *sess, IStreamAddr *isaptr)
{
    typehint hint;
    makehint(ACCOUNT, DOCUMENT, 0, &sess->account, &hint);

    return createorglingranf(sess, granf, &hint, isaptr);
}

bool
docreatenode_or_account(Session *sess, IStreamAddr *isaptr)
{
    IStreamAddr  isa;
    tumblercopy(isaptr, &isa);

    typehint hint;
    makehint(NODE, NODE, 0, /* &sess->account */ &isa, &hint);

    return createorglingranf(sess, granf, &hint, &isa);
}

static bool
doretrievedocvspanfoo(Session *sess, IStreamAddr *docisaptr, typevspan *vspanptr)
{                                      /* Internal routine, * no open required *//* this routine is a kluge not yet kluged */
    typeorgl docorgl;

    return findorgl(sess, granf, docisaptr, &docorgl, NOBERTREQUIRED)
            && retrievedocumentpartofvspanpm(sess, docorgl, vspanptr);
}

bool
docreatenewversion(Session *sess, IStreamAddr *isaptr, IStreamAddr *wheretoputit, IStreamAddr *newisaptr)
{
    IStreamAddr newtp;      /* for internal open */

/* ECH 7-13 introduced test for ownership to do right thing for explicit creation of new version of someone else's
 * document */

    typehint hint;
    if (tumbleraccounteq(isaptr, wheretoputit) && isthisusersdocument(sess, isaptr)) {
        makehint(DOCUMENT, DOCUMENT, 0, isaptr /* wheretoputit */ , &hint);
    } else {
/* This does the right thing for new version of someone else's document, as it duplicates the behavior of
 * docreatenewdocument */
        makehint(ACCOUNT, DOCUMENT, 0, wheretoputit, &hint);
    }

    if (!createorglingranf(sess, granf, &hint, newisaptr))
        return false;

    /*
     * Determine the full span of the parent document, to know the range to
     * copy into the newly created version.
     */

    typevspan vspan;
    if (!doretrievedocvspanfoo(sess, isaptr, &vspan))
        return false;

    typevspec vspec;
    vspec.next     = NULL;
    vspec.itemid   = VSPECID;
    movetumbler(isaptr, &vspec.docisa);
    vspec.vspanset = &vspan;

/* BERTMODEONLY to prevent recursive createnewversions */
    if (!doopen(sess, newisaptr, &newtp, WRITEBERT, BERTMODEONLY))
        assert(0); // Couldn't do internal doopen for new doc in docreatenewversion

    /*
     * Map (copy virtually) the entire content of the original document into
     * V-stream of the newly created version.
     */

    docopyinternal(sess, newisaptr, &vspan.stream, (typespec *) &vspec);
    doclose(sess, newisaptr);

    return true;
}

bool
doretrievedocvspan(Session *sess, IStreamAddr *docisaptr, typevspan *vspanptr)
{
    typeorgl docorgl;

    return findorgl(sess, granf, docisaptr, &docorgl, READBERT)
            && retrievevspanpm(sess, docorgl, vspanptr);
}

/*fix: The function doretrievedocvspanset() should not fail on an empty doc
 *but instead return an empty result set.  It also should return a set for
 *each type of data, even when there are none of that type.
 */
bool
doretrievedocvspanset(Session *sess, IStreamAddr *docisaptr, typevspanset *vspansetptr)
{
    typeorgl docorgl;

    if (findorgl(sess, granf, docisaptr, &docorgl, READBERT)) {
        if (!isemptyorgl(docorgl)) {
            if (retrievevspansetpm(sess, docorgl, vspansetptr)) {
                return true;
            }
        }
    }
    return false;
}

bool
doretrievev(Session *sess, typespecset specset, typevstuffset *vstuffsetptr)
{
    typeispanset ispanset;

    return specset2ispanset(sess, specset, &ispanset, READBERT)
            && ispanset2vstuffset(sess, granf, ispanset, vstuffsetptr);
}

bool
dofindlinksfromtothree(Session *sess, typespecset fromvspecset, typespecset tovspecset, typespecset threevspecset,
                       typeispan *orglrangeptr, typelinkset *linksetptr)
{
    return findlinksfromtothreesp(sess, spanf, fromvspecset, tovspecset, threevspecset, orglrangeptr, linksetptr);
}

bool
dofindnumoflinksfromtothree(Session *sess, typespecset *fromvspecset, typespecset *tovspecset,
                            typespecset *threevspecset, typeispan *orglrangeptr, int *numptr)
{
    /*BUG: there is some inconsistency re arg 'fromvspecset' as whether it is (typespec *)[fn below] or (typespec **)[passed-in] */
    return findnumoflinksfromtothreesp(sess, spanf, (typespec *) fromvspecset, (typespec *) tovspecset, (typespec *) threevspecset, orglrangeptr, numptr);
}

bool
dofindnextnlinksfromtothree(Session *sess, typevspec *fromvspecptr, typevspec *tovspecptr,
                            typevspec *threevspecptr, typeispan *orglrangeptr, IStreamAddr *lastlinkisaptr,
                            typelinkset *nextlinksetptr, int *nptr)
{
    return findnextnlinksfromtothreesp(sess, (typespec *) fromvspecptr, (typespec *) tovspecptr, (typespec *) threevspecptr, orglrangeptr, lastlinkisaptr,
                                       nextlinksetptr, nptr);
}

bool
doretrieveendsets(Session *sess, typespecset specset, typespecset *fromsetptr, typespecset *tosetptr,
                  typespecset *threesetptr)
{
    return retrieveendsetsfromspanf(sess, specset, fromsetptr, tosetptr, threesetptr);
}

bool
doshowrelationof2versions(Session *sess, typespecset version1, typespecset version2, typespanpairset *relation)
{
    typeispanset version1ispans = NULL;
    typeispanset version2ispans = NULL;
    typeispanset commonispans   = NULL;

    return specset2ispanset(sess, version1, &version1ispans, READBERT)
            && specset2ispanset(sess, version2, &version2ispans, READBERT)
            && intersectspansets(sess, version1ispans, version2ispans, &commonispans, ISPANID)
            && ispansetandspecsets2spanpairset(sess, commonispans, version1, version2, relation);
}
