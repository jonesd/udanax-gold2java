/**********************************************************************
 * Copyright 2002 Jeff Rush <jrush@taupro.com>
 * Original Copyright 1979-2002 Udanax.com
 *
 * This file is part of the Udanax xanalogical storage system.
 *
 * Udanax is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * Udanax is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with Udanax; if not, write to the Free Software Foundation,
 * Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 **********************************************************************/

/**
 * @file  insert.cxx
 * @brief enfilade crum insertion routines
 *
 * (to be defined)
 *
 **/

/* Modification History:
 * $Log: insert.cxx,v $
 * Revision 1.8  2002/05/28 04:22:29  jrush
 * Adjusted source files to comply with GPL licensing.
 *
 * Revision 1.7  2002/05/28 02:51:11  jrush
 * Made static any functions and global variables private to this source file
 * and commented out any unused functions.
 *
 * Revision 1.6  2002/04/12 11:56:43  jrush
 * Reorganized include file layout, renamed xanadu.h to udanax.h and
 * typecontext/typecrumcontext to C++ class Context/CrumContext.
 *
 * Revision 1.5  2002/04/09 21:45:46  jrush
 * Renamed class 'tumbler' to 'Tumbler', for consistency with Python sources,
 * and changed typeisa from typedef to a subclass, in preparation for cleaning
 * up the type/class tree.
 *
 * Revision 1.4  2002/04/06 19:51:30  jrush
 * Renamed TRUE/FALSE constant use to the C++ standard of true/false.
 *
 * Revision 1.3  2002/04/06 15:01:17  jrush
 * Changed INT to just 'int'.
 *
 * Revision 1.2  2002/02/14 09:27:43  jrush
 * Cleaned up source:
 *
 * 1. ran thru the indent tool to achieve a standard look,
 * 2. added structured comments at top for use with DOxygen reporting
 *    as well as CVS keywords,
 * 3. fixed compiler warnings re ambiguous assign/compares,
 *    needed casts and unused/uninitialized variables,
 * 4. fixed funcs that didn't specify a return type,
 * 5. centralized prototypes in protos.h, removing incomplete ones,
 * 6. cleaned up use of bool/BOOLEAN type to suit C++ type,
 * 7. fixed initializer nesting in tumbler constants,
 * 8. renamed vars that conflict with C++ keywords (new, this),
 * 9. fixed global/extern confusion re some global vars.
 *
 */

#include <memory.h>
#include "udanax.h"

/* use with GRAN */

static bool
fillupcbcseq(typecbc *ptr, Tumbler *crumboundary, typegranbottomcruminfo *info)
{
    char temp[GRANTEXTLENGTH];

        /** first     copy the text from the info to the crum that ptr points to */
/* do it nicer than this * */

    int crumlength    = ptr->cinfo.granstuff.textstuff.textlength;
    int remainingroom = GRANTEXTLENGTH - crumlength;
    int textlength    = info->granstuff.textstuff.textlength;

    if (remainingroom > textlength) {
        movmem(&info->granstuff.textstuff.textstring, (char *)(&(ptr->cinfo.granstuff.textstuff)) + crumlength, textlength);
        ptr->cinfo.granstuff.textstuff.textlength = crumlength + textlength;
        tumblerincrement(crumboundary, 0, textlength, crumboundary);
        return false;

    } else {
        movmem(&info->granstuff.textstuff.textstring, (char *)(&(ptr->cinfo.granstuff.textstuff)) + crumlength,
               remainingroom);
        ptr->cinfo.granstuff.textstuff.textlength = GRANTEXTLENGTH;
        tumblerincrement(crumboundary, 0, remainingroom, crumboundary);
    }

/* then take whats left in info and renormalize it */
    info->granstuff.textstuff.textlength -= remainingroom;

    movmem(&info->granstuff.textstuff.textstring[remainingroom], temp, info->granstuff.textstuff.textlength);
    clear(info->granstuff.textstuff.textstring, GRANTEXTLENGTH);
    movmem(temp, info->granstuff.textstuff.textstring, info->granstuff.textstuff.textlength);

    return true;
}

void
insertseq(typecuc *fullcrumptr, Tumbler *address, typegranbottomcruminfo *info)
{
    typedsp reach;

    Tumbler nextaddress;
    movetumbler(address, &nextaddress);

    CrumContext *context = retrievecrums(fullcrumptr, address, WIDTH);
    typecbc *ptr = context->corecrum;

    typedsp offset;
    clear(&offset, sizeof(offset));
    movewisp(&context->totaloffset, &offset);

    crumcontextfree(context);

    if (/* crum can be extended */ info->infotype == GRANTEXT && ptr->cinfo.infotype == GRANTEXT && ptr->cinfo.granstuff.textstuff.textlength < GRANTEXTLENGTH) {
        if (!fillupcbcseq(ptr, &nextaddress, info)) {
            ivemodified((typecorecrum *) ptr);
            return;
        }
    }
    reserve((typecorecrum *) ptr);

    typecorecrum *newcc = createcrum(0, (int) ptr->cenftype);
    reserve(newcc);

    adopt(newcc, RIGHTBRO, (typecorecrum *) ptr);
    ivemodified(newcc);

    bool splitsomething = splitcrumupwards(findfather(newcc));

    if (info->infotype == GRANORGL)
        info->granstuff.orglstuff.orglptr->leftbroorfather = newcc;

    moveinfo((typebottomcruminfo *) info, (typebottomcruminfo *) &((typecbc *) newcc)->cinfo);  /* in GRAN */
    if (iszerotumbler(&ptr->cwid.dsas[WIDTH])) {        /* last crum in granf */
        tumblerclear(&newcc->cwid.dsas[WIDTH]);
        tumblersub(&nextaddress, &offset.dsas[WIDTH], &ptr->cwid.dsas[WIDTH]);
    } else {
        dspadd(&offset, &ptr->cwid, &reach, GRAN);
        tumblersub(&reach.dsas[WIDTH], &nextaddress, &newcc->cwid.dsas[WIDTH]);
        tumblersub(&nextaddress, &offset.dsas[WIDTH], &ptr->cwid.dsas[WIDTH]);
    }

    ivemodified((typecorecrum *) ptr);
    setwispupwards(findfather((typecorecrum *) ptr), 0);
    setwispupwards(findfather((typecorecrum *) newcc), 1);
    splitsomething |= splitcrumupwards(findfather((typecorecrum *) ptr));
    rejuvinate((typecorecrum *) ptr);
    rejuvinate(newcc);

    if (splitsomething)
        recombine(fullcrumptr);
}
