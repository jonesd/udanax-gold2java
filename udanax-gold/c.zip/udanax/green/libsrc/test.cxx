/**********************************************************************
 * Copyright 2002 Jeff Rush <jrush@taupro.com>
 * Original Copyright 1979-2002 Udanax.com
 *
 * This file is part of the Udanax xanalogical storage system.
 *
 * Udanax is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * Udanax is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with Udanax; if not, write to the Free Software Foundation,
 * Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 **********************************************************************/

/**
 * @file  test.cxx
 * @brief functions to test 2d, Span and Gran enfilades
 *
 * (to be defined)
 *
 **/

/* Modification History:
 * $Log: test.cxx,v $
 * Revision 1.12  2002/07/26 04:33:47  jrush
 * Replaced gerror() with assert()
 *
 * Revision 1.11  2002/05/28 04:22:29  jrush
 * Adjusted source files to comply with GPL licensing.
 *
 * Revision 1.10  2002/05/28 02:48:03  jrush
 * Removed unused extern variable declarations.
 *
 * Revision 1.9  2002/04/12 11:56:43  jrush
 * Reorganized include file layout, renamed xanadu.h to udanax.h and
 * typecontext/typecrumcontext to C++ class Context/CrumContext.
 *
 * Revision 1.8  2002/04/09 21:45:46  jrush
 * Renamed class 'tumbler' to 'Tumbler', for consistency with Python sources,
 * and changed typeisa from typedef to a subclass, in preparation for cleaning
 * up the type/class tree.
 *
 * Revision 1.7  2002/04/07 14:03:48  jrush
 * Moved console-interactive functions examine(), showorgl() and showenfilades()
 * from libsrc/test.cxx to server/fns.cxx.
 *
 * Revision 1.6  2002/04/06 17:05:57  jrush
 * Switched from referring to 'task' for a client connection to 'session',
 * and converted the typetask typedef/struct into a Session C++ class.
 *
 * Revision 1.5  2002/04/06 15:01:17  jrush
 * Changed INT to just 'int'.
 *
 * Revision 1.4  2002/04/06 14:11:46  jrush
 * Added functions to graph POOMs and tweaked DOT settings.
 *
 * Revision 1.3  2002/04/02 18:45:48  jrush
 * Defined functions to output graphs of enfilades, and uncommented existing
 * code that verifies an enfilade tree is valid, for further testing.
 *
 * Revision 1.2  2002/02/14 09:27:43  jrush
 * Cleaned up source:
 *
 * 1. ran thru the indent tool to achieve a standard look,
 * 2. added structured comments at top for use with DOxygen reporting
 *    as well as CVS keywords,
 * 3. fixed compiler warnings re ambiguous assign/compares,
 *    needed casts and unused/uninitialized variables,
 * 4. fixed funcs that didn't specify a return type,
 * 5. centralized prototypes in protos.h, removing incomplete ones,
 * 6. cleaned up use of bool/BOOLEAN type to suit C++ type,
 * 7. fixed initializer nesting in tumbler constants,
 * 8. renamed vars that conflict with C++ keywords (new, this),
 * 9. fixed global/extern confusion re some global vars.
 *
 */

/* 
 *      testenf.c -- a file of functions written to test
 *      Two dimensional enfilades
 *      created 79/11/12
 *      modified as intest.c to test
 *      2d, Span and Gran enfilades
 *      on 80/10/12
 */

#include <unistd.h>
#include <memory.h>
#include <stdlib.h>
#include <fcntl.h>
#include <ctype.h>
#include "udanax.h"

extern typecorecrum *grimreaper;
extern int reservnumber;
int numfoo = NUMDISKBLOCKSINLOAF;
int debug;

//UNUSED extern char end;        /* lower limit (pointers should be into alloc space */
//UNUSED extern char etext;      /* as another lower limit on valid pointers */

extern long nolread;
static long nowread;

void graphpoom(FILE *fd, typecorecrum *ptr);
void graphcrum(FILE *fd, typecorecrum *ptr, typedsp *offsetptr, char *indent);
void graphwid(FILE *fd, typewid *widptr, int enftype);
void graphdsp(FILE *fd, typewid *dspptr, int enftype);
void graphoffset(FILE *fd, typedsp *dspptr, int enftype);
char *nodeid(typecorecrum *ptr, char *s);

void
foo(char *msg)
{
#ifndef DISTRIBUTION
    if (debug)
        fprintf(stderr, msg);
#endif
}

void
foospan(char *msg, typespan *span)
{
#ifndef DISTRIBUTION
    if (debug) {
        fprintf(stderr, msg);
        dumpspan(span);
    }
#endif
}

void
foospanset(char *msg, typespan *spanset)
{
#ifndef DISTRIBUTION
    if (debug) {
        fprintf(stderr, msg);
        if (!spanset) {
            fprintf(stderr, "null spanset\n");
        } else {
            for (; spanset; spanset = spanset->next) {
                dumpspan(spanset);
            }
        }
    }
#endif
}

void
dumpspanset(typespan *spanset)
{
#ifndef DISTRIBUTION
    if (!spanset) {
        fprintf(stderr, "null spanset\n");
    } else {
        for (; spanset; spanset = spanset->next) {
            dumpspan(spanset);
        }
    }
#endif
}

void
foocrum(char *msg, typecorecrum *crumptr)
{
#ifndef DISTRIBUTION
    if (debug) {
        fprintf(stderr, msg);
        dump(crumptr);
    }
#endif
}

void
foohex(char *msg, int num)
{
#ifndef DISTRIBUTION
    if (debug)
        fprintf(stderr, "%s %x\n", msg, num);
#endif
}

void
foodec(char *msg, int num)
{
#ifndef DISTRIBUTION
    if (debug)
        fprintf(stderr, "%s %d\n", msg, num);
#endif
}

void
foocontext(char *msg, Context *context)
{
#ifndef DISTRIBUTION
    if (debug) {
        fprintf(stderr, msg);
        dumpcontext(context);
    }
#endif
}

void
foocontextlist(char *msg, Context *context)
{
#ifndef DISTRIBUTION
    if (debug) {
        fprintf(stderr, msg);
        dumpcontextlist(context);
    }
#endif
}

void
fooitemset(char *msg, typeitemset iptr)
{
#ifndef DISTRIBUTION
    if (debug) {
        fprintf(stderr, msg);
        dumpitemset(iptr);
    }
#endif
}

void
fooitem(char *msg, typeitem *iptr)
{
#ifndef DISTRIBUTION
    if (debug) {
        fprintf(stderr, msg);
        dumpitem(iptr);
        fprintf(stderr, "\n");
    }
#endif
}

void
footumbler(char *msg, Tumbler *tptr)
{
#ifndef DISTRIBUTION
    if (debug) {
        fprintf(stderr, msg);
        if (tptr)
            puttumbler(stderr, tptr);
        else
            fprintf(stderr, "NULL");
        fprintf(stderr, "\n");
    }
#endif
}

void
foodsp(char *msg, typedsp *dptr, int enftype)
{
#ifndef DISTRIBUTION
    if (debug) {
        fprintf(stderr, msg);
        if (dptr)
            dumpdsp(dptr, enftype);
        else
            fprintf(stderr, "NULL");
        fprintf(stderr, "\n");
    }
#endif
}

void
foowid(char *msg, typewid *wptr, int enftype)
{
#ifndef DISTRIBUTION
    if (debug) {
        fprintf(stderr, msg);
        if (wptr)
            dumpwid(wptr, enftype);
        else
            fprintf(stderr, "NULL");
        fprintf(stderr, "\n");
    }
#endif
}

/* pass this the fullcrum to dump the entire (incore) enfilade */
void
dumpsubtree(typecuc *father)
{
#ifndef DISTRIBUTION
    typecorecrum *ptr;

    if (father->cenftype == POOM) {
        dumppoomwisps((typecorecrum *) father);
        return;
    }
    dump((typecorecrum *) father);
    if (father->height <= 0)
        return;
    for (ptr = father->leftson; ptr; ptr = ptr->rightbro)
        dumpsubtree((typecuc *) ptr);
#endif
}

void
dumpwholesubtree(typecuc *father)
{
#ifndef DISTRIBUTION
    fprintf(stderr, "dump whole subtree");

    if (father->cenftype == POOM) {
        dumppoomwisps((typecorecrum *) father);
        return;
    }

    dump((typecorecrum *) father);

    if (father->height <= 0)
        return;

    typecorecrum *ptr;
    for (ptr = findleftson(father); ptr; ptr = findrightbro(ptr))
        dumpwholesubtree((typecuc *) ptr);
#endif
}

void
graphwholesubtree(FILE *fd, typecuc *father, typedsp *offsetptr, char *indent)
{
    typecorecrum *ptr;
//jrr    if (father->cenftype == POOM) {
//jrr        dumppoomwisps((typecorecrum *) father);
//jrr        return;
//jrr    }

    graphcrum(fd, (typecorecrum *) father, offsetptr, indent);

    if (father->height <= 0)
        return;

    if (strlen(indent) == 0) {
        fprintf(fd, "\n  { rank=same; ");

        for (ptr = findleftson(father); ptr; ptr = findrightbro(ptr)) {
            char temp[10];
            fprintf(fd, "%s; ", nodeid(ptr, temp));
        }
        fprintf(fd, "} /* height = %u */\n\n", findleftson(father)->height);
    }

    for (ptr = findleftson(father); ptr; ptr = findrightbro(ptr)) {
        graphwholesubtree(fd, (typecuc *) ptr, offsetptr, indent);
    }
}

void
assertspecisstring(typespecset specptr, char *string)
{
#ifndef DISTRIBUTION
    Session sessfoo;
    typevstuffset vstuffset;
    //UNUSED int i;
    int savedebug;

    fprintf(stderr, "assertspecisstring entering \n");
    savedebug = debug;

/* debug = false; */

    //Now done via a ctor:: inittask(&sessfoo);

    doretrievev(&sessfoo, specptr, &vstuffset);

// for(i=0;(i<vstuffset->length)&&(string[i] == vstuffset->string[i]);i++) ; if(i != vstuffset->length){
// fprintf(stderr,"in assertspecisstring failedstring1 =%s string2 =%s
// %d\n",string,vstuffset->string,vstuffset->length); debug = true; fooitem("spec is ",specptr); fooitem("\nvstuff is
// ",vstuffset); // crash bang boom // assert(0); /* assertspecisstring asserton failed \n */; } fprintf(stderr,"in
// assertspecisstring succeded %s \n",string);

    fprintf(stderr, "in assertspecisstring string2 =%s %d\n", vstuffset->xxxtext.string, vstuffset->xxxtext.length);
    sessfoo.free();
    debug = savedebug;
    fprintf(stderr, "assertspecisstring leaving \n");
#endif
}

bool
asserttreeisok(typecorecrum *ptr)
{
//    printf("--asserttreeisok is a NOP--\n");
//    return (true);

    fprintf(stderr,"entering asserttreeisok\n");
    for (; !isfullcrum(ptr); ptr = (typecorecrum *) findfather(ptr)); assertsubtreeisok(ptr)
        ;
	
    return(true);
}

void
assertsubtreeisok(typecorecrum *ptr)
{
#ifndef DISTRIBUTION
    typecorecrum *son;

    if (!ptr)
        assert(0); // assertsubtreeok failed null ptr

    assertwidsarepositive(ptr);
    if (!reservnumber) {
        if (ptr->age == RESERVED) {
            dump(ptr);
            assert(0); // incorrect reserved in assertsubtreeisok
        }
    }

    if (ptr->height == 0)
        return;

// if (toomanysons(ptr)) { // dump(ptr); fprintf(stderr, "fatherhas too many sons\n"); // //assert(0); "foo"// }

    assertsonswispmatchesfather((typecuc *) ptr);
    for (son = ((typecuc *) ptr)->leftson /* findleftson//getleftson//(ptr) */ ;
         son; son = son->rightbro) {
        assertsubtreeisok(son);
    }
#endif
}

void
assertsonswispmatchesfather(typecuc *father)
{
#ifndef DISTRIBUTION
    //UNUSED typecorecrum *son;

    if (father->numberofsons == 0) {
        if (father->sonorigin.diskblocknumber != DISKPTRNULL)
            return;

        fprintf(stderr, "zerosons in assert\n");
        return;
    }

    if (setwisp((typecorecrum *) father)) {
        fprintf(stderr, "assert wisp matched father failed \n");
        dump((typecorecrum *) father);
        dumpwholetree((typecorecrum *) father);

        assert(0); // father didn't match sons wid and disp
    }
#endif
}

void
assertwidsarepositive(typecorecrum *ptr)
{
#ifndef DISTRIBUTION
    int nstreams, i;

    int enftype = ptr->cenftype;

    if (enftype == GRAN)
        return;

    nstreams = widsize(enftype);
    for (i = 0; i < nstreams; ++i) {
        tumblercheckptr(&(ptr->cwid.dsas[i]), (int *) ptr);
    }

    nstreams = dspsize(enftype);
    for (i = 0; i < nstreams; ++i) {
        tumblercheckptr(&(ptr->cdsp.dsas[i]), (int *) ptr);
    }
#endif
}

void
dumpwholetree(typecorecrum *ptr)
{
#ifndef DISTRIBUTION
    fprintf(stderr, "dump whole tree\n");

    for (; !isfullcrum(ptr); ptr = (typecorecrum *) findfather(ptr))
        ;

    dumpwholesubtree((typecuc *) ptr);
#endif
}

void
graphwholetree(char *filename, typecorecrum *ptr, char *graphlabel)
{
    FILE *fd = fopen(filename, "w");

    fprintf(fd, "digraph G {\n");
    fprintf(fd, "    nodesep=0.40;\n");
    fprintf(fd, "    ranksep=\"0.40 equally\";\n");
    fprintf(fd, "    center=true;\n");
    fprintf(fd, "    page=\"8.5, 11\"; /* unit of pagination */\n");
    fprintf(fd, "    size=\"8.25, 10.75\";\n");
    fprintf(fd, "    /* ratio=auto; */\n");
    fprintf(fd, "    orientation=landscape;\n");
    fprintf(fd, "    label=\"%s\";\n", graphlabel);
    fprintf(fd, "    fontsize=14;\n");
    fprintf(fd, "    fontcolor=blue;\n");
    fprintf(fd, "\n");
    fprintf(fd, "    node [shape = record];\n");
    fprintf(fd, "\n");

    for (; !isfullcrum(ptr); ptr = (typecorecrum *) findfather(ptr))
        ;

    typedsp offset;
    clear(&offset, sizeof(offset));

    graphwholesubtree(fd, (typecuc *) ptr, &offset, "");

    fprintf(fd, "    A [width=0.1, height=0.1, style=invis];\n");
    fprintf(fd, "    B [width=0.1, height=0.1, style=invis];\n");
    fprintf(fd, "    C [width=0.1, height=0.1, style=invis];\n");
    fprintf(fd, "    A -> B [style=invis];\n");
    fprintf(fd, "    B -> C [style=invis];\n");

    fprintf(fd, "}\n");
    fclose(fd);
}

void
graphpoom(FILE *fd, typecorecrum *ptr)
{
    fprintf(fd, "\n    subgraph cluster_%08X {\n", (int) ptr);

    for (; !isfullcrum(ptr); ptr = (typecorecrum *) findfather(ptr))
        ;

    typedsp offset;
    clear(&offset, sizeof(offset));

    graphwholesubtree(fd, (typecuc *) ptr, &offset, "    ");

    fprintf(fd, "\n");
    fprintf(fd, "        label = \"POOM\";\n");
    fprintf(fd, "        color = royalblue;\n");
    fprintf(fd, "        fillcolor = lightgrey;\n");
    fprintf(fd, "        style = filled;\n");
    fprintf(fd, "    }\n\n");
}

int
checkwholesubtree(typecuc *father)
{
#ifndef DISTRIBUTION
    //UNUSED typecorecrum *ptr;

    return 0;

#ifdef UndEfIneD
    if (!father)
        return 0;

    if (check(father)) {
        fprintf(stderr, "found something bad in checkwholesubtree\n");
        dumpsubtree(father);

        // assert(0); // in checkwholesubtree
        return 1;
    }

    if (father->height <= 0)
        return 0;

    for (ptr = father->leftson; ptr; ptr = ptr->rightbro)
        if (checkwholesubtree(ptr))
            return 1;

    return 0;
#endif
#endif
}

int
check(typecuc *ptr)
{
    return 0;

#ifdef UnDeeFiNeD
    if (ptr->height == 0) {
        return 0;
    }

    if (ptr->leftson == NULL           /* &&ptr->sonorigin.diskblocknumber==-1 */
        && ptr->modified) {
        dump(ptr);
        assert(0); // in check
    } else {
        return 0;
    }

    assert(0); // check: can't get there
    return 0;
#endif
}

               /* dump a core crum */
void
dump(typecorecrum *ptr)
{
#ifndef DISTRIBUTION
    fprintf(stderr, "\n");
    dumphedr(ptr);

    if (ptr->height) {
        fprintf(stderr, "sonorigin = %x insideloaf %x  leftson = %x  #sons = %x\n",
                ((typecuc *) ptr)->sonorigin.diskblocknumber, ((typecuc *) ptr)->sonorigin.insidediskblocknumber,
                (int) ((typecuc *) ptr)->leftson, ((typecuc *) ptr)->numberofsons);
    } else {
        dumpinfo(&((typecbc *) ptr)->cinfo, ptr->cenftype);
    }
#endif
}

char *
safetext(char *s)
{
    static char buffer[11];
    char *p = buffer;

    while (*s && p < &buffer[ sizeof(buffer)-2 ]) {
        if (!isalnum(*s))
            *p++ = '\\';
        *p++ = *s++;
    }
    *p = '\0';
    return buffer;
}

char *
nodeid(typecorecrum *ptr, char *s)
{
    char c;

    switch (ptr->cenftype) {
    case GRAN:  c = 'G';  break; // GRAN
    case SPAN:  c = 'S';  break; // SPAN
    case POOM:  c = 'P';  break; // POOM
    default:    c = 'x';  break;
    }
    sprintf(s, "%c%08X", c, (int) ptr);
    return s;
}

char *
nodecolor(typecorecrum *ptr)
{
    switch (ptr->cenftype) {
    case GRAN: return "darkgreen";  break;
    case POOM: return "blue";       break;
    case SPAN: return "red";        break;
    default:   return "black";      break;
    }
}

char *
nodefillcolor(typecorecrum *ptr)
{
    switch (ptr->cenftype) {
    case GRAN: return "palegreen";  break;
    case POOM: return "powderblue"; break;
    case SPAN: return "pink";       break;
    default:   return "black";      break;
    }
}
               /* dump a core crum */
void
graphcrum(FILE *fd, typecorecrum *ptr, typedsp *offsetptr, char *indent)
{
    const char *full = (ptr->isapex ? "(top)" : "");
    char mynodeid[10], hisnodeid[10];
    typecorecrum *orgl = NULL;

    nodeid(ptr, mynodeid);

    char *color     = nodecolor(ptr);
    char *fillcolor = nodefillcolor(ptr);

    // Define Attributes of This Node
    fprintf(fd, "%s    %s [color=%s, fillcolor=%s, style=filled, label = \"", indent, mynodeid, color, fillcolor);
    fprintf(fd, "{ %s\\nheight=%u %s |",
                mynodeid, ptr->height, full);

    if (ptr->cenftype != GRAN)
        graphdsp(fd, &ptr->cdsp, ptr->cenftype);

    graphwid(fd, &ptr->cwid, ptr->cenftype);
    graphoffset(fd, offsetptr, ptr->cenftype);

    if (ptr->height == 0 && ptr->cenftype == GRAN) {
        int infotype = ((typecbc *) ptr)->cinfo.infotype;
        typegrantext *gtext;
        typegranorgl *gorgl;
        char *safe, *ellipse;

        switch (infotype) {
        case GRANTEXT:
            gtext = &((typecbc *) ptr)->cinfo.granstuff.textstuff;
            safe = safetext(gtext->textstring);
            if (gtext->textlength > strlen(safe)) ellipse = "...";
            else ellipse = "";
            fprintf(fd, " | TEXT[%u]\\n'%s'%s", gtext->textlength, safe, ellipse);
            break;
        case GRANORGL:
            gorgl = &((typecbc *) ptr)->cinfo.granstuff.orglstuff;
            orgl = (typecorecrum *) gorgl->orglptr; // Used Below
            fprintf(fd, " | ORGL");
            break;
        case GRANNULL:  fprintf(fd, " | NULL"); break;
        default:        fprintf(fd, " | { err=\\< ???? \\>\\l }"); break;
        }
    }

    if (ptr->height) {
        fprintf(fd, " | nsons=%u ", ((typecuc *) ptr)->numberofsons);
    }
    fprintf(fd, "}\"];\n");

    // Define Connections of This Node
    if (ptr->rightbro)
        fprintf(fd, "%s    %s -> %s [tailport=e, headport=w, taillabel=RBRO, labeldistance=2, labelfontname=Helvetica, labelfontsize=10, labelfontcolor=%s, color=%s];\n",
                    indent, mynodeid, nodeid(ptr->rightbro, hisnodeid), nodecolor(ptr->rightbro), nodecolor(ptr->rightbro));

    if (ptr->leftbroorfather) {
        if (ptr->isleftmost)
            fprintf(fd, "%s    %s -> %s [tailport=n, headport=s, taillabel=FATHER, labeldistance=2, labelfontname=Helvetica, labelfontsize=10, labelfontcolor=%s, color=%s];\n",
                        indent, mynodeid, nodeid(ptr->leftbroorfather, hisnodeid), nodecolor(ptr->leftbroorfather), nodecolor(ptr->leftbroorfather));
        else
            fprintf(fd, "%s    %s -> %s [tailport=w, headport=e, taillabel=LBRO, labeldistance=2, labelfontname=Helvetica, labelfontsize=10, labelfontcolor=%s, color=%s];\n",
                        indent, mynodeid, nodeid(ptr->leftbroorfather, hisnodeid), nodecolor(ptr->leftbroorfather), nodecolor(ptr->leftbroorfather));
    }

    if (orgl)
        fprintf(fd, "%s    %s -> %s [tailport=s, headport=n, taillabel=SON, labeldistance=2, labelfontname=Helvetica, labelfontsize=10, labelfontcolor=%s, color=%s];\n",
                    indent, mynodeid, nodeid(orgl, hisnodeid), nodecolor(orgl), nodecolor(orgl));

    if (ptr->height) {
        fprintf(fd, "%s    %s -> %s [tailport=s, headport=n, taillabel=SON, labeldistance=2, labelfontname=Helvetica, labelfontsize=10, labelfontcolor=%s, color=%s];\n",
                    indent, mynodeid, nodeid(((typecuc *) ptr)->leftson, hisnodeid), nodecolor(((typecuc *) ptr)->leftson), nodecolor(((typecuc *) ptr)->leftson));
    } else {
//        if (ptr->cenftype == GRAN) {
//            typegranbottomcruminfo *cinfo = &((typecbc *) ptr)->cinfo;
//
//struct structorgl {
//    struct structcuc *orglptr;
//    typediskloafptr diskorglptr;
//};
//
//        } else {
//        //    type2dbottomcruminfo c2dinfo;
//        }
    }

//    if (ptr->height == 0 && ptr->cenftype == GRAN) {
//        int infotype = ((typecbc *) ptr)->cinfo.infotype;
//        if (infotype == GRANORGL) {
//            typegranorgl *gorgl = &((typecbc *) ptr)->cinfo.granstuff.orglstuff;
//            graphpoom(fd, (typecorecrum *) gorgl->orglptr);
//        }
//    }

    if (orgl)
        graphpoom(fd, orgl);

//    fprintf(stderr, "%s %scrum core location = %x\n", temp, full, (int) ptr);
//    fprintf(stderr, "height = %x nextcrum = %x  modified = %x\n", ptr->height, (int) ptr->nextcrum, ptr->modified);
//    fprintf(stderr, " age = %x ", ptr->age);
//    fprintf(stderr, "isleftmost = %x leftbro = %x rightbro = %x\n", ptr->isleftmost, (int) ptr->leftbroorfather, (int) ptr->rightbro);

//    dumpdsp(&ptr->cdsp, ptr->cenftype);
//    dumpwid(&ptr->cwid, ptr->cenftype);


//    if (ptr->height) {
//        fprintf(stderr, "sonorigin = %x insideloaf %x  leftson = %x  #sons = %x\n",
//                ((typecuc *) ptr)->sonorigin.diskblocknumber, ((typecuc *) ptr)->sonorigin.insidediskblocknumber,
//                (int) ((typecuc *) ptr)->leftson, ((typecuc *) ptr)->numberofsons);
//    } else {
//        dumpinfo(&((typecbc *) ptr)->cinfo, ptr->cenftype);
//    }

    if (ptr->height == 0)
        dspadd(offsetptr, &ptr->cwid, offsetptr, ptr->cenftype);
}

void
yesdump(typecorecrum *ptr)
{                                      /* because dbx has a builtin dump name * * conflict */
#ifndef DISTRIBUTION
    dump(ptr);
#endif
}

                 /* dump a corecrumhedr */
void
dumphedr(typecorecrumhedr *ptr)
{
#ifndef DISTRIBUTION
    char *temp;

    switch (ptr->cenftype) {
    case GRAN:  temp = "GRAN";  break;
    case SPAN:  temp = "SPAN";  break;
    case POOM:  temp = "POOM";  break;
    default:    temp = "????";  fprintf(stderr, " %d ", ptr->cenftype); break;
    }

    const char *full = (ptr->isapex ? "full" : "");

//                   ===GRAN fullcrum height=0
//  00000000 <  coreaddr@xxxxxxxx  > 00000000
//            | age=dd  modified=1  next@xxxxxxxx
//            | dsp = < 0 >
//            | wid = < 1.7.0.9.0.1.0.1 >
//            \         v		/
//                  00000000

//	      /--GRAN fullcrum h=0
//  00000000 <  coreaddr@xxxxxxxx  > 00000000
//            | age=dd  modified=1  next@xxxxxxxx
//            | dsp = < 0 >
//            | wid = < 1.7.0.9.0.1.0.1 >
//            \         v		/
//                  00000000



    fprintf(stderr, "%s %scrum core location = %x\n", temp, full, (int) ptr);
    fprintf(stderr, "height = %x nextcrum = %x  modified = %x\n", ptr->height, (int) ptr->nextcrum, ptr->modified);
    fprintf(stderr, " age = %x ", ptr->age);
    fprintf(stderr, "isleftmost = %x leftbro = %x rightbro = %x\n", ptr->isleftmost, (int) ptr->leftbroorfather, (int) ptr->rightbro);

    dumpdsp(&ptr->cdsp, ptr->cenftype);
    dumpwid(&ptr->cwid, ptr->cenftype);
#endif
}

void
dumpwid(typewid *widptr, int enftype)
{
#ifndef DISTRIBUTION
    int i;

    int nstreams = widsize(enftype);
    fprintf(stderr, "wid = < ");
    for (i = 0; i < nstreams; ++i) {
        if (i > 0)
            fprintf(stderr, " , ");
        puttumbler(stderr, &widptr->dsas[i]);
    }
    fprintf(stderr, " >\n");
#endif
}

void
graphwid(FILE *fd, typewid *widptr, int enftype)
{
    int nstreams = widsize(enftype);
    fprintf(fd, " wid=\\<");

    for (int i = 0; i < nstreams; ++i) {
        if (i > 0)
            fprintf(fd, " :: ");
        puttumbler(fd, &widptr->dsas[i]);
    }
    fprintf(fd, "\\> \\n");
}

void
dumpdsp(typewid * dspptr, int enftype)
{
#ifndef DISTRIBUTION
    int i;

/* if (enftype == GRAN) return; */
    int nstreams = dspsize(enftype);
    fprintf(stderr, "dsp = < ");
    for (i = 0; i < nstreams; ++i) {
        if (i > 0)
            fprintf(stderr, " , ");
        puttumbler(stderr, &dspptr->dsas[i]);
    }
    fprintf(stderr, " >\n");
#endif
}

void
graphdsp(FILE *fd, typewid *dspptr, int enftype)
{
/* if (enftype == GRAN) return; */
    int nstreams = dspsize(enftype);
    fprintf(fd, " dsp=\\<");

    for (int i = 0; i < nstreams; ++i) {
        if (i > 0)
            fprintf(fd, " :: ");
        puttumbler(fd, &dspptr->dsas[i]);
    }
    fprintf(fd, "\\> \\n");
}

void
graphoffset(FILE *fd, typedsp *dspptr, int enftype)
{
    int nstreams = dspsize(enftype);
    fprintf(fd, " isa=\\<");

    for (int i = 0; i < nstreams; ++i) {
        if (i > 0)
            fprintf(fd, " :: ");
        puttumbler(fd, &dspptr->dsas[i]);
    }
    fprintf(fd, "\\> \\n");
}

void
dumpinfo(typegranbottomcruminfo *infoptr, int enftype)
{
#ifndef DISTRIBUTION
    if (enftype == GRAN) {
        switch (infoptr->infotype) {
        case GRANTEXT:
            fprintf(stderr, "text:  %s\n", infoptr->granstuff.textstuff.textstring);
            break;
        case GRANORGL:
            fprintf(stderr, " diskorgl %x, ", infoptr->granstuff.orglstuff.diskorglptr);
            fprintf(stderr, "orgl %x\n ", (int) infoptr->granstuff.orglstuff.orglptr);
            break;
        case GRANNULL:
            fprintf(stderr, "GRANNULL info\n");
            break;
        default:
            fprintf(stderr, "empty infotype: %d\n", infoptr->infotype);
            assert(0); // bad in dumpinfo
        }
    } else {
        fprintf(stderr, "home document: ");
        puttumbler(stderr, &((type2dbottomcruminfo *) infoptr)->homedoc);
        fprintf(stderr, "\n");
    }
#endif
}

void
dumptumbler(Tumbler *tumblerptr)
{
#ifndef DISTRIBUTION
    int i;

    if (!tumblerptr) {
        fprintf(stderr, "NULL POINTER TO TUMBLER");
        return;
    }

    if (!debug)
        puttumbler(stderr, tumblerptr);
    else {
        fprintf(stderr, " %d | ", tumblerptr->sign);
        fprintf(stderr, "%d | ", tumblerptr->exp);
        for (i = 0; i < NPLACES; ++i)
            fprintf(stderr, "%d ", tumblerptr->mantissa[i]);
        if (tumblerptr->exp > 0) {
            fprintf(stderr, "in dumptumbler exponent positive i.e. negative number of leading zeros!\n");
            assert(0); // dumptumbler
        }
    }
#endif
}

void
displaycutspm(typeknives *knivesptr)
{
#ifndef DISTRIBUTION
    int i;

    fprintf(stderr, "%x cuts:", knivesptr->nblades);
    for (i = 0; i < knivesptr->nblades; ++i) {
        fprintf(stderr, "\n       ");
        puttumbler(stderr, &knivesptr->blades[i]);
    }
    fprintf(stderr, "\n");
#endif
}

void
dumphint(typehint *hintptr)
{
#ifndef DISTRIBUTION
    fprintf(stderr, "\nHINT\n");
    fprintf(stderr, "  supertype: %d\n", hintptr->supertype);
    fprintf(stderr, "  subtype:   %d\n", hintptr->subtype);
    fprintf(stderr, "  atomtype:  %d\n", hintptr->atomtype);
    fprintf(stderr, "  isa:       ");
    puttumbler(stderr, &hintptr->hintisa);
    fprintf(stderr, "\n");
#endif
}

void
showsubtree(typecorecrum *father)
{
#ifndef DISTRIBUTION
    //UNUSED int temp;

/* temp = debug; debug = 5; */
    dumpwholesubtree((typecuc *) father);
/* debug = temp; */
#endif
}

void
showistream(typecuc *granfptr)
{
#ifndef DISTRIBUTION
    //UNUSED int temp;

/* temp = debug; debug = 5; */
    dumpistreamgr(granfptr);
/* debug = temp; */
#endif
}

void
showspanf(typecuc *spanfptr)
{
#ifndef DISTRIBUTION
    typedsp offset;
    clear(&offset, sizeof(typedsp));

    int enfheight = spanfptr->height;

    fprintf(stderr, "\n");
    doshowspanf((typecorecrum *) spanfptr, &offset, enfheight);
#endif
}

void
doshowspanf(typecorecrum *crumptr, typedsp *offsetptr, int enfheight)
{
#ifndef DISTRIBUTION
    typecorecrum *ptr = NULL;
    typedsp loffset;

    showspanfcrum(crumptr, offsetptr, enfheight);
    if (crumptr->height <= 0)
        return;

    dspadd(offsetptr, &crumptr->cdsp, &loffset, crumptr->cenftype);
    for (ptr = findleftson((typecuc *) crumptr); ptr; ptr = ptr->rightbro)
        doshowspanf(ptr, &loffset, enfheight);
#endif
}

void
showspanfcrum(typecorecrum *crumptr, typedsp *offsetptr, int enfheight)
{
#ifndef DISTRIBUTION
    int depth;
    typedsp lstream;

    for (depth = enfheight - crumptr->height; depth--;)
        fprintf(stderr, "  ");

    fprintf(stderr, "[spandsp");
    dspadd(offsetptr, &crumptr->cdsp, &lstream, crumptr->cenftype);
    puttumbler(stderr, &lstream.dsas[SPANRANGE]);

    fprintf(stderr, " ,spanwid  ");
    puttumbler(stderr, &crumptr->cwid.dsas[SPANRANGE]);

    fprintf(stderr, "]\n");
    for (depth = enfheight - crumptr->height; depth--;)
        fprintf(stderr, "  ");

    fprintf(stderr, "[orgldsp ");
    puttumbler(stderr, &lstream.dsas[ORGLRANGE]);

    fprintf(stderr, " ,orglwid  ");
    puttumbler(stderr, &crumptr->cwid.dsas[ORGLRANGE]);

    fprintf(stderr, "]   ");
    if (crumptr->height == 0)
        puttumbler(stderr, &((type2dcbc *) crumptr)->c2dinfo.homedoc);

    fprintf(stderr, "\n\n");
#endif
}

void
dumpmem(char *loc, unsigned count)
{
#ifndef DISTRIBUTION
    int i;

    fprintf(stderr, " loc = %x\n", (int) loc);
    for (i = 0; count--; ++loc, (i + 1 < 64 ? ++i : (i = 0))) {
        if ((*loc & 0x7f) < ' ')
            fprintf(stderr, "%c", '.');
        else
            fprintf(stderr, "%c", *loc);
        if (i == 63)
            fprintf(stderr, "\n");
    }
    fprintf(stderr, "\n");
#endif
}

bool
dumpgranfwids(Session *sess)
{
#ifndef DISTRIBUTION
    Tumbler subtreewid;
    //UNUSED int fullheight;

/* fullheight = ((typecorecrum *)granf)->height; */
    showgranwids((typecorecrum *) granf, 0, &subtreewid);
    if (!tumblereq(&subtreewid, &((typecorecrum *) granf)->cwid.dsas[WIDTH])) {

        fprintf(stderr, "Granfilade fullcrum wid and widded enfilade don\'t match.\n");
        fprintf(stderr, "gran fullcrum wid ");
        puttumbler(stderr, &((typecorecrum *) granf)->cwid.dsas[WIDTH]);

        fprintf(stderr, "\nreturned wid from subtree ");
        puttumbler(stderr, &subtreewid);

        fprintf(stderr, "\nHit \"<return>\" to continue, \"a<return>\" to abort ");
        if (getc(sess->inp) == 'a')
            abort();
    }
    fprintf(stderr, "\n");
#endif
    return true;
}

void
showgranwids(typecorecrum *crum, int down, Tumbler *retptr)
{                                      /* down is distance from top */
#ifndef DISTRIBUTION
    typecorecrum *ptr;
    Tumbler subtreewid;
    int i;

    fprintf(stderr, "\n");
    clear(retptr, sizeof(*retptr));

    for (i = 0; i < down; ++i)
        fprintf(stderr, "        ");

    fprintf(stderr, "%x (%d%c) < ", (int) crum, crum->height, (crum->modified ? 'M' : '-'));
    puttumbler(stderr, &crum->cwid.dsas[WIDTH]);
    fprintf(stderr, " >");
    if (crum->height != 0) {
        if (((typecuc *) crum)->leftson) {
            for (ptr = ((typecuc *) crum)->leftson; ptr; ptr = ptr->rightbro) {
                tumbleradd(retptr, &ptr->cwid.dsas[WIDTH], retptr);
                showgranwids(ptr, down + 1, &subtreewid);
                if (!tumblereq(&subtreewid, &ptr->cwid.dsas[WIDTH])) {

                    fprintf(stderr, "\n%d level crum\'s wid and result from subtree don\'t match\n", crum->height);
                    fprintf(stderr, "father wid ");
                    puttumbler(stderr, &ptr->cwid.dsas[WIDTH]);

                    fprintf(stderr, "\nreturned wid ");
                    puttumbler(stderr, &subtreewid);

                    fprintf(stderr, "\n");
                }
            }
        } else {
            fprintf(stderr, " disksonloaf = %x ", ((typecuc *) crum)->sonorigin.diskblocknumber);
            movetumbler(&crum->cwid.dsas[WIDTH], retptr);
/* so that lacking incore sons will not cause error */
        }
    } else if (((typecbc *) crum)->cinfo.infotype == GRANORGL) {
        if (((typecbc *) crum)->cinfo.granstuff.orglstuff.orglincore)
            fprintf(stderr, " orgl %x ", (int) ((typecbc *) crum)->cinfo.granstuff.orglstuff.orglptr);
        else
            fprintf(stderr, " diskorgl %x", ((typecbc *) crum)->cinfo.granstuff.orglstuff.diskorglptr);

        movetumbler(&crum->cwid.dsas[WIDTH], retptr);
    } else
        movetumbler(&crum->cwid.dsas[WIDTH], retptr);
#endif
}

void
dumppoomwisps(typecorecrum *orgl)
{
    printf("Entering dumppoomwisps\n");

#ifndef DISTRIBUTION
    //UNUSED int fullheight;

/* fullheight = orgl->height; */
    showpoomwisps((typecuc *) orgl, 0);
    fprintf(stderr, "\n");
#endif
    printf("Leaving dumppoomwisps\n");
}

void
showpoomwisps(typecuc *crum, int down)
{                                      /* down is distance from top */
#ifndef DISTRIBUTION
    typecorecrum *ptr;
    int i;

    fprintf(stderr, "\n");

    for (i = 0; i < down; ++i)
        fprintf(stderr, "   ");

    fprintf(stderr, "%x (%d%c) <Idsp ", (int) crum, crum->height, (crum->modified ? 'M' : '-'));
    puttumbler(stderr, &crum->cdsp.dsas[I]);

    fprintf(stderr, ",Vdsp ");
    puttumbler(stderr, &crum->cdsp.dsas[V]);

    fprintf(stderr, " > <Iwid ");
    puttumbler(stderr, &crum->cwid.dsas[I]);

    fprintf(stderr, ",Vwid ");
    puttumbler(stderr, &crum->cwid.dsas[V]);

    fprintf(stderr, " >");
    if (crum->height != 0) {
        if (crum->leftson) {
            for (ptr = findleftson(crum); ptr; ptr = ptr->rightbro) {
                showpoomwisps((typecuc *) ptr, down + 1);
            }
        } else {
            fprintf(stderr, " disksonloaf = %x ", crum->sonorigin.diskblocknumber);
        }
    }
#endif
}

#define TABSTOP 20

void
dumpistreamgr(typecuc *crumptr)
{
#ifndef DISTRIBUTION
    Tumbler offset;

    if (debug < 5)
        return;

    tumblerclear(&offset);
    dodumpistreamgr(crumptr, &offset);
#endif
}

void
dodumpistreamgr(typecuc *crumptr, Tumbler *offsetptr)
{
#ifndef DISTRIBUTION
    typecorecrum *ptr;

    if (crumptr->height == 0) {
        dumpmoleculegr(offsetptr, (typecbc *) crumptr);
        tumbleradd(offsetptr, &crumptr->cwid.dsas[WIDTH], offsetptr);
        return;
    }

    for (ptr = findleftson(crumptr); ptr; ptr = ptr->rightbro)
        dodumpistreamgr((typecuc *) ptr, offsetptr);
#endif
}

void
dumpmoleculegr(Tumbler *offsetptr, typecbc *cbcptr)
{
#ifndef DISTRIBUTION
    //UNUSED int i;
    //UNUSED Tumbler localoffset;

/* fprintf(stderr,"\n"); dumpisagr (offsetptr); if (cbcptr->cinfo.infotype == GRANTEXT) { if
 * (cbcptr->cinfo.textstring[0] == '\n') fprintf(stderr,"\\n"); else if (cbcptr->cinfo.textstring[0] == '\t')
 * fprintf(stderr,"\\t"); else fprintf(stderr,"%c ",cbcptr->cinfo.textstring[0]); fprintf(stderr," | %x ", cbcptr);
 * dumpwid (&cbcptr->cwid, GRAN); movetumbler (offsetptr, &localoffset); for (i = 1; i < cbcptr->cinfo.textlength;
 * ++i){ tumblerincrement (&localoffset, 0, 1, &localoffset); dumpisagr (&localoffset); if (cbcptr->cinfo.textstring[i]
 * == '\n') fprintf(stderr,"\\n"); else if (cbcptr->cinfo.textstring[i] == '\t') fprintf(stderr,"\\t"); else
 * fprintf(stderr,"%c ",cbcptr->cinfo.textstring[i]); fprintf(stderr," |\n"); } } else if (cbcptr->cinfo.infotype ==
 * GRANORGL) { fprintf(stderr,"%x",cbcptr->cinfo.orglptr); fprintf(stderr," | %x ", cbcptr); dumpwid (&cbcptr->cwid,
 * GRAN); } else { fprintf(stderr," | %x ", cbcptr); dumpwid (&cbcptr->cwid, GRAN); } */
#endif
}

void
dumpisagr(Tumbler *offsetptr)
{
#ifndef DISTRIBUTION
    int i, j, k;
    Tumbler offset;

    movetumbler(offsetptr, &offset);

    i = nstories(&offset) - offset.exp;
    i += i - 1;
    for (j = 0; j < NPLACES; ++j)
        for (k = offset.mantissa[j]; k /= 10; ++i)
            ;

    i = TABSTOP - i;
    if (i < 2) {
        fprintf(stderr, "too long");
        i = 8;
    } else
        puttumbler(stderr, &offset);

    while (i--)
        fprintf(stderr, " ");
#endif
}

typecorecrum *
checkenftypes(typecuc *father, char *message)
{
#ifndef DISTRIBUTION
    //UNUSED typecorecrum *ptr;

    if (grimreaper == NULL)
        fprintf(stderr, "grimreaper tests null");

    return (typecorecrum *) father;

//    if (!father) {
//        fputs(stderr, message);
//        assert(0); // ARGH!! null father ptr
//    }
//    
//    if (!father->height)
//        return father;
//	
//    if (father->cenftype == SPAN) {
//        if (father->cwid.dsas[ORGLRANGE].exp == 0 && father->cwid.dsas[ORGLRANGE].mantissa[0] > 2) {
//            dumpsubtree(father);
//            fputs(stderr, message);
//            assert(0); // I think the wid is too big
//        }
//    }
//    
//    for (ptr * = father->leftson; ptr; ptr = ptr->rightbro) {
//        if (ptr->cenftype != GRAN && ptr->cenftype != POOM && ptr->cenftype != SPAN) {
//            fputs(stderr, message);
//            assert(0); // bad enftype
//        }
//	
//        if (ptr->cenftype != father->cenftype) {
//            fputs(stderr, message);
//            assert(0); // enftype mismatch
//        }
//	
//        checkenftypes(ptr, message);
//    }
//    return father;
#endif
}

typecorecrum *
checkthebleedingcrum(typecorecrum *crumptr)
{
#ifndef DISTRIBUTION
    if (grimreaper == NULL)
        fprintf(stderr, "grimreaper tests null");

    return crumptr;

//    assert(crumptr != NULL); // checkbleeding NULL crum
//    
//    if (crumptr->cenftype != GRAN && crumptr->cenftype != SPAN && crumptr->cenftype != POOM) {
//        fprintf(stderr, "Bad enftype in check the bleeding crum\n\n\n");
//        dump(crumptr);
//        assert(0); // Bad enftype
//    }
//    
//    if (!crumptr->isapex&&crumptr->leftbroorfather..disowned.. && crumptr->cenftype != crumptr->leftbroorfather->cenftype) {
//        dump(crumptr);
//        fprintf(stderr,"\n\n\n and here comes the spanf \n");
//        dumpsubtree(spanf);
//        dump(crumptr);
//        assert(0); // Enftype mismatch
//    }
//    
//    if (crumptr->cenftype !=GRAN) {
//        if (!tumblercheck(&crumptr->cdsp.dsas[V]))
//            assert(0); // cleckbleeding disp V
//
//        if (!tumblercheck(&crumptr->cdsp.dsas[I]))
//            assert(0); // cleckbleeding disp I
//    }
//    return crumptr;
#endif
}

void
teststack()
{
    //UNUSED int testloc;

/* checkalloc (""); */
}

char *
enftypestring(int type)
{
#ifndef DISTRIBUTION
    static char errbuf[60];

    switch (type) {
    case GRAN:
        return ("GRAN");
    case POOM:
        return ("POOM");
    case SPAN:
        return ("SPAN");
    default:
        sprintf(errbuf, "bad enftype %d", type);
        return ((char *)errbuf);
    }
#endif
}

typecorecrum *
sonoriginok(typecorecrum *father)
{
    return (father);                   /* 
                                        * if (!father) return (father); if
                                        * (father->height == 0) return
                                        * (father); if
                                        * (father->sonorigin.diskblocknumber
                                        * == -1) return (father); if
                                        * (goodblock
                                        * (father->sonorigin.diskblocknumber))
                                        * return (father); dumpsubtree
                                        * (father); fprintf(stderr,"enter y to
                                        * procede\n"); if(getchar() == 'y') {
                                        * getchar(); return(father); } assert(0);
                                        * "Bad Sonorigin"; return(NULL);// 
                                        * for lint// */
}

void
dumpcontextlist(Context *context)
{
#ifndef DISTRIBUTION
    fprintf(stderr, "contextlist :\n");

    if (!context) {
        fprintf(stderr, "  contextlist NULL\n");
        return;
    }

    for (; context; context = (Context *) context->nextcontext) {
        dumpcontext(context);
    }
#endif
}

void
dumpcontext(Context *context)
{
#ifndef DISTRIBUTION
    fprintf(stderr, "  context %x:\n", (int) context);

    if (context == NULL) {
        fprintf(stderr, "NULL context\n");
        return;
    }

    fprintf(stderr, "    contexttype %s\n", enftypestring(context->contexttype));
    fprintf(stderr, "    totaloffset ");
    dumpdsp(&context->totaloffset, context->contexttype);

    fprintf(stderr, "    contextwid ");
    dumpwid(&context->contextwid, context->contexttype);

    if (debug > 1) {
        fprintf(stderr, "    contextinfo ");
        dumpinfo((typegranbottomcruminfo *) &context->contextinfo, context->contexttype);
    }
#endif
}

void
dumpitemset(typeitemset itemset)
{
#ifndef DISTRIBUTION
    if (itemset == NULL)
        fprintf(stderr, "  \nitemset empty\n");

    for (; itemset; itemset = (typeitemset) ((typeitemheader *) itemset)->next) {
        dumpitem(itemset);
        if (!
            (((typeitemheader *) itemset)->next && ((typeitemheader *) itemset)->itemid == TEXTID
             && ((typeitemheader *) itemset)->next->itemid == TEXTID))
            putc('\n', stderr);
    }
#endif
}

void
dumpitem(typeitem *itemptr)
{
#ifndef DISTRIBUTION
    int bugger = debug;

    debug = 0;
/* checkitem ("dumpitem: ", itemptr); */
    fprintf(stderr, "%x ->%x:", (int) itemptr, (int) ((typeitemheader *) itemptr)->next);
    switch (((typeitemheader *) itemptr)->itemid) {
    case ISPANID:
        fprintf(stderr, "  ispan\n");
        dumpspan((typespan *) itemptr);
        break;

    case VSPANID:
        fprintf(stderr, "  vspan\n");
        dumpspan((typespan *) itemptr);
        break;

    case VSPECID:
        fprintf(stderr, "document: ");
        puttumbler(stderr, &((typevspec *) itemptr)->docisa);
        fprintf(stderr, "\nspans");
        dumpitemset((typeitem *) ((typevspec *) itemptr)->vspanset);
        break;

    case TEXTID:
        dumptext((typetext *) itemptr);
        break;

    case LINKID:
        puttumbler(stderr, &((typelink *) itemptr)->address);
        break;

    case SPORGLID:
        fprintf(stderr, "sporgl address: ");
        puttumbler(stderr, &((typesporgl *) itemptr)->sporgladdress);
        fprintf(stderr, "\n   sporgl origin: ");
        puttumbler(stderr, &((typesporgl *) itemptr)->sporglorigin);
        fprintf(stderr, "\n   sporgl width: ");
        puttumbler(stderr, &((typesporgl *) itemptr)->sporglwidth);
        fprintf(stderr, "\n");
        break;

    default:
        fprintf(stderr, "illegal item id for dumpitem ");
        fprintf(stderr, "%x  %d\nd", (int) itemptr, ((typeitemheader *) itemptr)->itemid);
        assert(0); // Illegal item in dumpitem!
    }
    debug = bugger;
#endif
}

void
dumpspan(typespan *spanptr)
{
#ifndef DISTRIBUTION
    if (!spanptr) {
        fprintf(stderr, "null span ptr\n");
        return;
    }

    fprintf(stderr, "   span address: ");
    puttumbler(stderr, &spanptr->stream);

    fprintf(stderr, "   span width: ");
    puttumbler(stderr, &spanptr->width);

    fprintf(stderr, "\n");
#endif
}

void
dumptext(typetext *textptr)
{
#ifndef DISTRIBUTION
    write(2, textptr->string, textptr->length);
#endif
}

bool
ioinfo(Session *sess)
{
#ifndef DISTRIBUTION
    fprintf(stderr, "Total reads = %ld,  total writes = %ld\n", nolread, nowread);
#endif

    return true;
}

char *
itemidstring(typeitem *item)
{
#ifndef DISTRIBUTION
    switch (((typeitemheader *) item)->itemid) {
    case TEXTID:     return "TEXTID";
    case ISPANID:    return "ISPANID";
    case VSPANID:    return "VSPANID";
    case VSPECID:    return "VSPECID";
    case NODEID:     return "NODEID";
    case ADDRESSID:  return "ADDRESSID";
    case SPORGLID:   return "SPORGLID";
    }
#endif
    return NULL; /* for lint ? */
}

void
checkitem(char *msg, typeitem *ptr)
{
#ifndef DISTRIBUTION
    //UNUSED char buf[100];

    checkpointer(msg, (char *) ptr);
    if (!ptr)
        return;

    if (debug) {
        fprintf(stderr, msg);
        dumpitem(ptr);
    }

    if (((typeitemheader *) ptr)->itemid < TEXTID || ((typeitemheader *) ptr)->itemid > SPORGLID) {
        fprintf(stderr, msg);
        assert(0); // Bad itemtype
    }

/* checkpointer (sprintf (buf, "%s ptr->next: ", msg), ((typeitemheader *)ptr)->next); */
    if (((typeitemheader *) ptr)->itemid == VSPANID) {
        if (((typevspan *) ptr)->stream.mantissa[0] != 1 && ((typevspan *) ptr)->stream.mantissa[0] != 2) {
            fprintf(stderr, msg);
            puttumbler(stderr, &((typevspan *) ptr)->stream);
            fprintf(stderr, "  ");
            assert(0); // Bad span stream address
        }
    }
    if (((typeitemheader *) ptr)->itemid == VSPECID) {
        checkitem(msg, (typeitem *) ((typevspec *) ptr)->vspanset);
        if (((typevspec *) ptr)->vspanset->itemid != VSPANID)
            assert(0); // vspanset doesn't have proper itemid
    }
#endif
}

void
checkpointer(char *msg, char *ptr)
{
    return;
    
//    if (!ptr) {
//        if (debug) {
//            fprintf(stderr, msg);
//            fprintf(stderr, "NULL pointer\n");
//        }
//        return;
//    }
//    
//    if (((unsigned) ptr) & 1) {
//        fprintf(stderr, msg);
//        assert(0); // Pointer non-aligned
//    }
//    
//    if (ptr > (char *) 0x1bffff) {
//        fprintf(stderr, msg);
//
//        if (ptr < (char *) 0x1e0000)
//            fprintf(stderr, "Pointer in framebuffer\n");
//
//        assert(0); // Pointer in high-mem
//    }
//	
//    if (ptr < (char *) 0x40000) {
//        fprintf (stderr, msg);
//        assert(0); // Pointer to hardware protected low memory
//    }
//	
//    if (ptr < &end //etext//) {
//        fprintf(stderr, msg);
//        assert(0); // Pointer below end
//    }
}

void
dumpspanpairset(typespanpairset spanpairset)
{
#ifndef DISTRIBUTION
    for (; spanpairset; spanpairset = spanpairset->nextspanpair)
        dumpspanpair(spanpairset);
#endif
}

void
dumpspanpair(typespanpair * spanpair)
{
#ifndef DISTRIBUTION
    fprintf(stderr, "stream1:  ");
    dumptumbler(&spanpair->stream1);

    fprintf(stderr, "\nstream2:  ");
    dumptumbler(&spanpair->stream2);

    fprintf(stderr, "\nwidth:  ");
    dumptumbler(&spanpair->widthofspan);

    fprintf(stderr, "\n");
#endif
}

void
dumphexstuff(char *ptr)
{
#ifndef DISTRIBUTION
    int i;

    fprintf(stderr, "\n");

    for (i = 0; i < 120; i++) {

        fprintf(stderr, "%x ", *(ptr + i) & 0xff);
    }
    fprintf(stderr, "\n");
#endif
}

void
checknumofsons(typecuc *ptr)
{
#ifndef DISTRIBUTION
    typecuc *np;

    int i = 0;
    if (!ptr || !ptr->height)
        return;

    for (np = (typecuc *) ptr->leftson; np; np = (typecuc *) np->rightbro, i++)
        ;

    if (i != ptr->numberofsons) {
        dumpsubtree(ptr);
        fprintf(stderr, "i = %d numberofsons = %d\n", i, ptr->numberofsons);

        for (np = (typecuc *) ptr->leftson; np; np = (typecuc *) np->rightbro, i++) {
/* dump(np) */ ;
        }
        fprintf(stderr, "numberofson mismach in checknumofsons\n");
    }
#endif
}

void
nchecknumofsons(typecuc *ptr)
{
#ifndef DISTRIBUTION
    typecuc *np;

    int i = 0;
    if (!ptr || !ptr->height)
        return;

    for (np = (typecuc *) ptr->leftson; np; np = (typecuc *) np->rightbro, i++)
        ;

    if (i != ptr->numberofsons) {
        dumpsubtree(ptr);
        fprintf(stderr, "i = %d numberofsons = %d\n", i, ptr->numberofsons);

        for (np = (typecuc *) ptr->leftson; np; np = (typecuc *) np->rightbro, i++) {
/* dump(np) */ ;
        }
        fprintf(stderr, "numberofson mismach in nchecknumofsons\n");
    }
#endif
}
