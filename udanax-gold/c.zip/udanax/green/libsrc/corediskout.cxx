/**********************************************************************
 * Copyright 2002 Jeff Rush <jrush@taupro.com>
 * Original Copyright 1979-2002 Udanax.com
 *
 * This file is part of the Udanax xanalogical storage system.
 *
 * Udanax is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * Udanax is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with Udanax; if not, write to the Free Software Foundation,
 * Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 **********************************************************************/

/**
 * @file  corediskout.cxx
 * @brief orglwrite and subtree write are called from reap in credel.cxx
 *
 * (to be defined)
 *
 **/

/* Modification History:
 * $Log: corediskout.cxx,v $
 * Revision 1.9  2002/07/26 04:30:29  jrush
 * Replaced gerror() with assert()
 *
 * Revision 1.8  2002/05/28 04:22:29  jrush
 * Adjusted source files to comply with GPL licensing.
 *
 * Revision 1.7  2002/05/28 02:49:42  jrush
 * Made static any functions and global variables private to this source file
 * and commented out any unused functions.
 *
 * Revision 1.6  2002/04/12 11:56:42  jrush
 * Reorganized include file layout, renamed xanadu.h to udanax.h and
 * typecontext/typecrumcontext to C++ class Context/CrumContext.
 *
 * Revision 1.5  2002/04/06 19:51:30  jrush
 * Renamed TRUE/FALSE constant use to the C++ standard of true/false.
 *
 * Revision 1.4  2002/04/06 17:05:57  jrush
 * Switched from referring to 'task' for a client connection to 'session',
 * and converted the typetask typedef/struct into a Session C++ class.
 *
 * Revision 1.3  2002/04/06 15:01:17  jrush
 * Changed INT to just 'int'.
 *
 * Revision 1.2  2002/02/14 09:27:43  jrush
 * Cleaned up source:
 *
 * 1. ran thru the indent tool to achieve a standard look,
 * 2. added structured comments at top for use with DOxygen reporting
 *    as well as CVS keywords,
 * 3. fixed compiler warnings re ambiguous assign/compares,
 *    needed casts and unused/uninitialized variables,
 * 4. fixed funcs that didn't specify a return type,
 * 5. centralized prototypes in protos.h, removing incomplete ones,
 * 6. cleaned up use of bool/BOOLEAN type to suit C++ type,
 * 7. fixed initializer nesting in tumbler constants,
 * 8. renamed vars that conflict with C++ keywords (new, this),
 * 9. fixed global/extern confusion re some global vars.
 *
 */

#include <memory.h>
#include <stdlib.h>
#include "udanax.h"

extern int nolread;
extern int nolwrote;
extern int noishouldbother;
extern int notakenephewnd;
extern int noeatbrosnd;

typegranf granf;
typespanf spanf;

typediskloaf zzzeroloaf;
typeuberdiskloaf zzzerouberloaf;

static void subtreewriterecurs(Session *sess, typecuc *father);
static void orglwritepart2(Session *sess, typecbc *orglcbcptr);

extern bool decrementusers(); //FIXME: remove ref to function in server/ backends

/* make sure file is up to date when exitting program */
static void
indiskexit()
{
    if (decrementusers())
        return;

    writeenfilades();
    closediskfile();

/* record = fopen ("diskiocount", "a"); fprintf (record, "%s: ", (isxumain?"xumain":"backend")); fprintf (record, "%5ld 
 * reads, %5ld writes, ", nolread, nolwrote); fprintf (record, "%5ld isb, %5ld ebnd, %5ld tnnd\n",noishouldbother,
 * noeatbrosnd, notakenephewnd); fclose (record); */

    exit(0);
}

void
diskexit()
{
    indiskexit();
}

/* Update disk copy of all enfilades, and reset core versions for multiuser */
void
diskflush()
{
    writeenfilades();
    initkluge((typecuc **) &granf, (typecuc **) &spanf);
}

/* Write entire granfilade and spanfilade to disk and flag as unmodified in core */
void
writeenfilades()
{
    typecbc temporgl;

    temporgl.leftbroorfather = NULL;
    temporgl.modified = true;
    temporgl.cinfo.granstuff.orglstuff.orglincore = true;
    temporgl.cinfo.granstuff.orglstuff.diskorglptr.diskblocknumber = GRANFDISKLOCATION;
    temporgl.cinfo.granstuff.orglstuff.diskorglptr.insidediskblocknumber = 0;
    temporgl.cinfo.granstuff.orglstuff.orglptr = (typecuc *) granf;
    ((typecuc *) granf)->leftbroorfather = (typecorecrum *) & temporgl;
    orglwrite(&temporgl);

    temporgl.modified = true;
    temporgl.cinfo.granstuff.orglstuff.orglincore = true;
    temporgl.cinfo.granstuff.orglstuff.diskorglptr.diskblocknumber = SPANFDISKLOCATION;
    temporgl.cinfo.granstuff.orglstuff.diskorglptr.insidediskblocknumber = 0;
    temporgl.cinfo.granstuff.orglstuff.orglptr = (typecuc *) spanf;
    ((typecuc *) spanf)->leftbroorfather = (typecorecrum *) & temporgl;
    orglwrite(&temporgl);
}

#define hputinloaf(hp,lp,tp) ((void)humberput((int)(hp),(humber)(lp),(unsigned int *)(tp)),(lp)=((char*)lp)+*(tp))
/* #define hputwisp(wp,lp,tp)
 * ((tp)=tumblerfixedtoptr((lp),&(wp.dsas[0])),((char*)lp)+=(tp),(tp)=tumblerfixedtoptr((lp),&(wp.dsas[1])),((char
 * *)lp)+=(tp)) */

static void
hputwiddsp(typecuc *ptr, char **loafptrptr)
{
    unsigned int temp;

    int nstreams = widsize(ptr->cenftype);
    typewid *wptr = &ptr->cdsp;

    int i;
    for (i = 0; i < nstreams; ++i) {
        temp = tumblerfixedtoptr(&wptr->dsas[i], (humber) *loafptrptr);
        *loafptrptr += temp;
    }

    wptr = &ptr->cwid;

    for (i = 0; i < nstreams; ++i) {
        temp = tumblerfixedtoptr(&wptr->dsas[i], (humber) *loafptrptr);
        *loafptrptr += temp;
    }
}

/* 
 * #define hputinloaf(hp,lp,tp)
 * (humberput((hp),(lp),(tp)),(lp)=((char*)lp)+*(tp)) */

static void
hputinfo(typecbc *ptr, char **loafptrptr)
{
    unsigned int temp;

    if (!is2dcrum((typecorecrum *) ptr)) {
        (void)humberput(ptr->cinfo.infotype, (humber) * loafptrptr, &temp);
        *loafptrptr += temp;
        if (ptr->cinfo.infotype == GRANTEXT) {
            (void)humberput((int) ptr->cinfo.granstuff.textstuff.textlength, (humber) * loafptrptr, &temp);
            *loafptrptr += temp;
/* hputinloaf(ptr->cinfo.granstuff.textstuff.textlength,(*loafptrptr),&temp); */
            movmem(ptr->cinfo.granstuff.textstuff.textstring, (*loafptrptr), ptr->cinfo.granstuff.textstuff.textlength);
            *loafptrptr += ptr->cinfo.granstuff.textstuff.textlength;
            return;
        } else if (ptr->cinfo.infotype == GRANORGL) {
            (void)humberput(ptr->cinfo.granstuff.orglstuff.diskorglptr.diskblocknumber, (humber) * loafptrptr, &temp);
            *loafptrptr += temp;
            (void)humberput(ptr->cinfo.granstuff.orglstuff.diskorglptr.insidediskblocknumber, (humber) * loafptrptr,
                            &temp);
            *loafptrptr += temp;
/* hputinloaf(ptr->cinfo.granstuff.orglstuff.diskorglptr,(*loafptrptr),&temp); */
            return;
        } else if (ptr->cinfo.infotype == GRANNULL) {
            return;
        } else {
            fprintf(stderr, "weird infotype in hputinfo %d \n", ptr->cinfo.infotype);
            assert(0); // weird infotype in hputinfo
            return;
        }
    } else {
        if (ptr->height) {
/* looks like we got this all */
        } else {
            temp = tumblerfixedtoptr(&((type2dcbc *) ptr)->c2dinfo.homedoc, (humber) * loafptrptr);
            (*loafptrptr) += temp;
        }
    }
}

/* hdump(n,ptr) int n; char *ptr; { #ifndef DISTRIBUTION int i; for (i = 0; i < n; i++) { fprintf(stderr,"%x ",
 * *(ptr+i)); } #endif } */

static int
varpackloaf(typecuc *father, typediskloaf *xloafptr, int refcount, int flag)
{
    typecorecrum *ptr;
    int ret;
    unsigned int temp;

    char *loafptr = (char *) xloafptr;

    if (!flag) {
        if (!father || father->height == 0 || !loafptr) {
            dump((typecorecrum *) father);
            assert(0); // bad packloaf call
        }

        assert(!father->leftson || !toomanysons(father)); // ERROR: Too many sons in packloaf
	
/* tempptr = loafptr; */
        loafptr += 3;                  /* make room for loaflength */
        hputinloaf(false, loafptr, &temp);
        hputinloaf(father->height - 1, loafptr, &temp);
        hputinloaf(father->cenftype, loafptr, &temp);
        hputinloaf(father->numberofsons, loafptr, &temp);
        hputinloaf(refcount, loafptr, &temp);

    } else {
/* tempptr = loafptr; */
        loafptr += 3;                  /* make room for loaflength */
        hputinloaf(true, loafptr, &temp);
        hputinloaf(father->height, loafptr, &temp);
        hputinloaf(father->cenftype, loafptr, &temp);
        hputinloaf(1, loafptr, &temp);
        hputinloaf(refcount, loafptr, &temp);

        hputwiddsp(father, &loafptr);
        hputinloaf(father->sonorigin.diskblocknumber, loafptr, &temp);
        hputinloaf(father->sonorigin.insidediskblocknumber, loafptr, &temp);

        if (father->sonorigin.diskblocknumber == 0) {
            // dump (ptr);
            assert(0); // trying to write 0 block
        }
        if (father->sonorigin.diskblocknumber == DISKPTRNULL) {
            /* dump (ptr); */
            assert(0); // trying to write DSKPTRNULL block
        }

        return (int) loafptr - (int) xloafptr;
    }

    for (ptr = (typecorecrum *) findleftson(father); ptr; ptr = ptr->rightbro) {
        hputwiddsp((typecuc *) ptr, (char **)&loafptr);
        if (ptr->height != 0) {
            hputinloaf(((typecuc *) ptr)->sonorigin.diskblocknumber, loafptr, &temp);
            hputinloaf(((typecuc *) ptr)->sonorigin.insidediskblocknumber, loafptr, &temp);

            if (((typecuc *) ptr)->sonorigin.diskblocknumber == 0) {
                dump(ptr);
                assert(0); // trying to write 0 block
            }

            if (((typecuc *) ptr)->sonorigin.diskblocknumber == DISKPTRNULL) {
                dump(ptr);
                assert(0); // trying to write DISKPTRNULL block
            }
        } else
            hputinfo((typecbc *) ptr, &loafptr);
    }

    ret = (int) loafptr - (int) xloafptr;
    humber3put(ret, (humber) xloafptr, &temp);
    return ret;
}

static int
packloaf(typecuc *father, typediskloaf *loafptr, int refcount, int flag)
{
    return varpackloaf(father, loafptr, refcount, flag);
}

static void
uniqueoutloaf(typecuc *father, int refcount)
{
    int size;
    unsigned int temp;
    int newloaf;

    /* fprintf(stderr,"entering uniqueoutloaf\n"); */

    if (!father->modified)
        assert(0); // uniqueoutloaf called with not modified

    typeuberdiskloaf loaf = zzzerouberloaf;
    if ((!father->leftson) && father->sonorigin.diskblocknumber != DISKPTRNULL) {
        /* fprintf(stderr,"in uniqueoutloaf calling findleftson\n"); dump(father); */
        findleftson(father);     /* get it in so we know numberof sons zzz KLUGE is this right aug 15 86 */
        /* father->numberofsons = findnumberofdamnsons(father); */
    }

    size = packloaf(father, (typediskloaf *) & loaf, refcount, 0);
    father->sonorigin = partialdiskalloc(size, &newloaf);
    /* dumphexstuff(&loaf); */
    humber3put(size, (humber) & loaf, &temp);

    /* dumphexstuff(&loaf); */
    /* loaf.numberofunterloafs = 1; */

    if (false && newloaf) {
        addallocatedloaftopartialallocedtables(father->sonorigin, size);
    }

    /* dumphexstuff(&loaf); */
    /* fprintf(stderr,"height in uniqueoutloaf = %d\n",father->height); */
    writeloaf((typediskloaf *) & loaf, father->sonorigin, newloaf);
    father->modified = false;
    /* fprintf(stderr,"leaving uniqueoutloaf\n"); */
}

static void
checkmodifiednotthere(typecuc *father, char *string)
{
    return;

#ifndef DISTRIBUTION
#ifdef UnDeFineD
    if (father->modified && (!father->leftson) /* &&father->sonor.diskblocknumber== * DISKPTRNULL */ ) {
        dump(father);
        fprintf(stderr, "in %s subtreewrite", string);
        assert(0); // in   subtreewriterecurs bad crum
    }
#endif
#endif
}

static void
subtreewriterecurs(Session *sess, typecuc *father)
{
    typecbc *ptr;

    /* fprintf(stderr,"entering subtreewriterecurs \n"); */

    if (!father || !father->height)
        assert(0); // Bad subtreewrite call

    /* this, of course, assumes modified is set right */
    if (!father->modified) {
        if (father->sonorigin.diskblocknumber == DISKPTRNULL) {
            fprintf(stderr, "insubtreewriterecurs sonorigin == -1\n");
            dumpsubtree(father);
            assert(0); // in subtreewriterecurs
        }
        loaffree(father);
        return;
    }

//    /* if (//father->sonorigin.diskblocknumber == DISKPTRNULL&&//!father->leftson) { fprintf(stderr," case b
//     * insubtreewriterecurs sonorigin == -1\n"); dumpsubtree(father); assert(0); /* in subtreewriterecurs */); } */

    // in order to guarantee integrity of disk, it's important to write out or increment sons before father

    checkmodifiednotthere(father, "A");
    for (ptr = (typecbc *) father->leftson; ptr; ptr = (typecbc *) ptr->rightbro) {
        if (ptr->height == 0 && ptr->cenftype == GRAN && ptr->cinfo.infotype != GRANTEXT
            && ptr->cinfo.infotype != GRANORGL && ptr->cinfo.infotype != GRANORGL && ptr->cinfo.infotype != GRANNULL) {
            fprintf(stderr, "bad infotypein subtreewriterecursive  = %d\n", ptr->cinfo.infotype);
            dump((typecorecrum *) ptr);
            assert(0); // subtreewriterecurs
        }

        if (ptr->height != 0) {
            subtreewriterecurs(sess, (typecuc *) ptr);
        } else if (ptr->cenftype == GRAN && ptr->height == 0 && ((typecbc *) ptr)->cinfo.infotype == GRANORGL) {
            orglwritepart2(sess, ptr);
        }

        ptr->modified = false;
    }

    if (father->modified) {
        checkmodifiednotthere(father, "B");

        for (ptr = (typecbc *) father->leftson; ptr; ptr = (typecbc *) ptr->rightbro) {
            if (ptr->height > 0 && ((typecuc *) ptr)->sonorigin.diskblocknumber != DISKPTRNULL) {
                changerefcount(((typecuc *) ptr)->sonorigin, 1);
            }
        }
        checkmodifiednotthere(father, "C");
        uniqueoutloaf(father, 0);

    }

    /* rejuvinate(father); */
    loaffree(father);
}

static void deletewithgarbageddescendents(typediskloafptr diskptr, typecuc *father, bool deletefullcrumflag);

static void
deletefullcrumandgarbageddescendents(typediskloafptr diskptr, bool deletefullcrumflag, typediskloaf *loafp, typediskloafptr newdiskptr)
{
    typecbc *tempcbc;
    typecbc crum;
    typeuberrawdiskloaf crum2;

    if (diskptr.diskblocknumber == DISKPTRNULL)
        return;

/* kluge up a bottum crum, use it to read in granf, similarly for spanf */
/* tempcbc = (typecbc *)createcrum(0,GRAN); */
    tempcbc = &crum;
    initcrum(0, GRAN, (typecorecrum *) & crum);

    tempcbc->cinfo.infotype = GRANORGL;
    tempcbc->cinfo.granstuff.orglstuff.diskorglptr = diskptr;
    if (deletefullcrumflag) {
        inorglinternal(tempcbc, &crum2);
/* reserve(tempcbc); */
    } else {
        inorglinternal(tempcbc, &crum2);
/* reserve(tempcbc); */
        diskset(newdiskptr.diskblocknumber);
        writeloaf(loafp, newdiskptr, false);
    }

    tempcbc->cinfo.granstuff.orglstuff.orglptr->leftbroorfather = NULL;
    deletewithgarbageddescendents(diskptr, (typecuc *) tempcbc, deletefullcrumflag);
/* kluge SKIMP reserve and rejuvinate added 11-23-86 */
}

static void
deletewithgarbageddescendents(typediskloafptr diskptr, typecuc *father, bool deletefullcrumflag)
{
    typecbc *ptr;
    typediskloafptr ignoreddiskptr;

    if (father->height > 0)
        ptr = (typecbc *) findleftson(father);

/* if !flag changerefcount and then possibly recurse */
    if (!deletefullcrumflag || !changerefcount(diskptr, -1)) {
        if (father->height > 0) {
            for (; ptr; ptr = (typecbc *) findrightbro((typecorecrum *) ptr)) {
                if (ptr->height > 0)
                    deletewithgarbageddescendents(((typecuc *) ptr)->sonorigin, (typecuc *) ptr, true);
            }
        } else if (father->cenftype == GRAN && ((typecbc *) father)->cinfo.infotype == GRANORGL
                   && ((typecbc *) father)->cinfo.granstuff.orglstuff.orglincore
                   && ((typecbc *) father)->cinfo.granstuff.orglstuff.diskorglptr.diskblocknumber != GRANFDISKLOCATION
                   && ((typecbc *) father)->cinfo.granstuff.orglstuff.diskorglptr.diskblocknumber !=
                   SPANFDISKLOCATION) {
            deletefullcrumandgarbageddescendents(((typecbc *) father)->cinfo.granstuff.orglstuff.diskorglptr, true,     /* ECH 
                                                                                                                         * 8-28-88ignoreddiskptr, */
                                                 (typediskloaf *) NULL, ignoreddiskptr);
        }
    }
/* subtreefree(ptr); *//*12/04/86 */
}

static void
orglwritepart2(Session *sess, typecbc *orglcbcptr)
{
    typediskloafptr olddiskptr;
    typediskloafptr temploaf;
    int size;
    unsigned int dummy;
    int newloaf;

    typediskloaf loaf = zzzeroloaf;

    if (!orglcbcptr)
        assert(0); // orglwrite argh!

    typegranbottomcruminfo *infoptr = &orglcbcptr->cinfo;
    typecuc *orglptr                = infoptr->granstuff.orglstuff.orglptr;

    if (!orglcbcptr->modified && orglptr) {
        orglfree(orglptr);
        return;
    }

    if (infoptr->granstuff.orglstuff.orglincore) {
        reserve((typecorecrum *) orglcbcptr);
        olddiskptr = infoptr->granstuff.orglstuff.diskorglptr;
        subtreewriterecurs(sess, orglptr);
/* writefullcrum (orgl); */
        size = packloaf(orglptr, &loaf, 1, 1);
        (void)humber3put(size, (humber) & loaf, &dummy);

        if (orglptr->cenftype == POOM) {
            temploaf = partialdiskalloc(size, &newloaf);
            writeloaf(&loaf, temploaf, newloaf);
            changerefcount(temploaf, 1);
            infoptr->granstuff.orglstuff.diskorglptr = temploaf;
            deletefullcrumandgarbageddescendents(olddiskptr, true, (typediskloaf *) NULL, olddiskptr    /* olddiskptr
                                                                                                         * is just a
                                                                                                         * place holder 
                                                                                                         */ );
/* writeloaf(&loaf,infoptr->granstuff.orglstuff.diskorglptr,true); */
        } else {
            if (diskheader.hasenftops) {
                deletefullcrumandgarbageddescendents(olddiskptr, false, &loaf,
                                                     infoptr->granstuff.orglstuff.diskorglptr);
/* writeloaf(&loaf,infoptr->granstuff.orglstuff.diskorglptr,true); */
            } else {
                writeloaf(&loaf, infoptr->granstuff.orglstuff.diskorglptr, true);
            }
        }
/* NULL EFFECT HERE */
/* ptr->modified = false; */
        rejuvinate((typecorecrum *) orglcbcptr);
        orglfree(orglptr);
    } else
        return;                        /* zzz */
}

void
orglwrite(typecbc *orglcbcptr)
{
    Session sess;

    assert(orglcbcptr != NULL); // in orglwrite passed NULL

    //now done via a ctor:: inittask(&sess);
    orglwritepart2(&sess, orglcbcptr);
    sess.free();
}

void
subtreewrite(typecuc *father)
{
    Session sess;

    //Now done via a ctor:: inittask(&sess);
    subtreewriterecurs(&sess, father);
/* decrementandfreedisk (top); */
    sess.free();
}
