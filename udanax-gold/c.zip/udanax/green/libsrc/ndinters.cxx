/**********************************************************************
 * Copyright 2002 Jeff Rush <jrush@taupro.com>
 * Original Copyright 1979-2002 Udanax.com
 *
 * This file is part of the Udanax xanalogical storage system.
 *
 * Udanax is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * Udanax is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with Udanax; if not, write to the Free Software Foundation,
 * Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 **********************************************************************/

/**
 * @file  ndinters.cxx
 * @brief nd enfilade cut routines - file #2
 *
 * (to be defined)
 *
 **/

/* Modification History:
 * $Log: ndinters.cxx,v $
 * Revision 1.8  2002/05/28 04:22:29  jrush
 * Adjusted source files to comply with GPL licensing.
 *
 * Revision 1.7  2002/05/28 02:51:11  jrush
 * Made static any functions and global variables private to this source file
 * and commented out any unused functions.
 *
 * Revision 1.6  2002/04/12 11:56:43  jrush
 * Reorganized include file layout, renamed xanadu.h to udanax.h and
 * typecontext/typecrumcontext to C++ class Context/CrumContext.
 *
 * Revision 1.5  2002/04/09 21:45:46  jrush
 * Renamed class 'tumbler' to 'Tumbler', for consistency with Python sources,
 * and changed typeisa from typedef to a subclass, in preparation for cleaning
 * up the type/class tree.
 *
 * Revision 1.4  2002/04/06 19:51:30  jrush
 * Renamed TRUE/FALSE constant use to the C++ standard of true/false.
 *
 * Revision 1.3  2002/04/06 15:01:17  jrush
 * Changed INT to just 'int'.
 *
 * Revision 1.2  2002/02/14 09:27:43  jrush
 * Cleaned up source:
 *
 * 1. ran thru the indent tool to achieve a standard look,
 * 2. added structured comments at top for use with DOxygen reporting
 *    as well as CVS keywords,
 * 3. fixed compiler warnings re ambiguous assign/compares,
 *    needed casts and unused/uninitialized variables,
 * 4. fixed funcs that didn't specify a return type,
 * 5. centralized prototypes in protos.h, removing incomplete ones,
 * 6. cleaned up use of bool/BOOLEAN type to suit C++ type,
 * 7. fixed initializer nesting in tumbler constants,
 * 8. renamed vars that conflict with C++ keywords (new, this),
 * 9. fixed global/extern confusion re some global vars.
 *
 */

#include <memory.h>
#include "udanax.h"

/* given fullcrumptr & knives ** sets *ptrptr & *offset to be cuc which contains all ** space between the cuts */
/* findintersectionnd (fullcrumptr, knives, ptrptr, offset) typecuc *fullcrumptr; typeknives *knives; typecuc **ptrptr; 
 * typewid *offset; { typecorecrum *ptr, *next; typecorecrum *findthecutsonnd(); clear (offset, sizeof(*offset)); ptr
 * = fullcrumptr; for (;;) { // descend down the generations // if ((next = findthecutsonnd (ptr, offset, knives)) ==
 * NULL) break; lockadd (offset, &ptr->cdsp, offset, dspsize (ptr->cenftype)); ptr = next; } *ptrptr = ptr; // offset
 * is already set appropriately // } */

void
newfindintersectionnd(typecuc *fullcrumptr, typeknives *knives, typecuc **ptrptr, typewid *offset)
{
    *ptrptr = fullcrumptr;
    clear(offset, sizeof(*offset));
}

//UNUSED static bool
//UNUSED cutinthiscrumnd(typecorecrum *ptr, typewid *offset, typeknives *knives)
//UNUSED {
//UNUSED     int i;
//UNUSED     for (i = 0; i < knives->nblades; ++i) {
//UNUSED         if (whereoncrum(ptr, offset, &knives->blades[i], knives->dimension) == THRUME)
//UNUSED             return true;
//UNUSED     }
//UNUSED 
//UNUSED     return false;
//UNUSED }

//UNUSED static bool                                   /* old version */
//UNUSED allcutswiththiscrumnd(typecorecrum *ptr, typewid *offset, typeknives *knives)
//UNUSED {
//UNUSED     Tumbler cut;
//UNUSED     int i, cmp;
//UNUSED 
//UNUSED     for (i = 0; i < knives->nblades; ++i) {
//UNUSED         tumblercopy(&knives->blades[i], &cut);
//UNUSED         cmp = whereoncrum(ptr, offset, &cut, knives->dimension);
//UNUSED         if (cmp == TOMYLEFT || cmp == TOMYRIGHT)
//UNUSED             return false;
//UNUSED     }
//UNUSED     return true;
//UNUSED }

/* typecorecrum * findthecutsonnd (father, offset, knives) typecorecrum *father; typewid *offset; typeknives *knives; { 
 * typedsp grasp; typecorecrum *ptr, *cutcrum; bool allcutswiththiscrumnd(); bool cutinthiscrumnd(); // note that
 * intersection can't be bottom crum // if (father->height == 1 || (ptr = findleftson (father)) == NULL) return (NULL); 
 * prologuend (father, offset, &grasp, (typedsp *)NULL); cutcrum = NULL; for (; ptr; ptr = findrightbro (ptr)) { if
 * (cutinthiscrumnd (ptr, &grasp, knives)) { if (cutcrum) // cuts thru > 1 // return (NULL); else // first that cuts
 * thru // cutcrum = ptr; } } if (!cutcrum) // cuts thru none of them // return (NULL); if (!allcutswiththiscrumnd
 * (cutcrum, &grasp, knives)) return (NULL); // missed some somehow // return (cutcrum); } */
/* is true if satisfied on ANY cuts ** is ONLY satisfied by cuts within */

/* is true only if satisfied on ALL cuts. ** is satisfied by cut at edge as well as within. */

/* //new version// bool allcutswiththiscrumnd (ptr, offset, knives) typecorecrum *ptr; typewid *offset; typeknives
 * *knives; { int i,cmp; for (i = 0; i < knives->nblades; ++i) { cmp = whereoncrum (ptr, offset, &knives->blades[i],
 * knives->dimension); if (cmp == TOMYLEFT || cmp == TOMYRIGHT) return (false); } return (true); } */
