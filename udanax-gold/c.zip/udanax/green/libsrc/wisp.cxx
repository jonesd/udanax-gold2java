/**********************************************************************
 * Copyright 2002 Jeff Rush <jrush@taupro.com>
 * Original Copyright 1979-2002 Udanax.com
 *
 * This file is part of the Udanax xanalogical storage system.
 *
 * Udanax is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * Udanax is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with Udanax; if not, write to the Free Software Foundation,
 * Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 **********************************************************************/

/**
 * @file  wisp.cxx
 * @brief integrated wid and dsp arithmetic routines
 *
 * (to be defined)
 *
 **/

/* Modification History:
 * $Log: wisp.cxx,v $
 * Revision 1.9  2002/07/26 04:33:47  jrush
 * Replaced gerror() with assert()
 *
 * Revision 1.8  2002/05/28 04:22:29  jrush
 * Adjusted source files to comply with GPL licensing.
 *
 * Revision 1.7  2002/05/28 02:52:23  jrush
 * Made static any functions and global variables private to this source file
 * and commented out any unused functions.
 *
 * Revision 1.6  2002/04/12 11:56:43  jrush
 * Reorganized include file layout, renamed xanadu.h to udanax.h and
 * typecontext/typecrumcontext to C++ class Context/CrumContext.
 *
 * Revision 1.5  2002/04/09 21:45:46  jrush
 * Renamed class 'tumbler' to 'Tumbler', for consistency with Python sources,
 * and changed typeisa from typedef to a subclass, in preparation for cleaning
 * up the type/class tree.
 *
 * Revision 1.4  2002/04/06 19:51:30  jrush
 * Renamed TRUE/FALSE constant use to the C++ standard of true/false.
 *
 * Revision 1.3  2002/04/06 15:01:17  jrush
 * Changed INT to just 'int'.
 *
 * Revision 1.2  2002/02/14 09:27:43  jrush
 * Cleaned up source:
 *
 * 1. ran thru the indent tool to achieve a standard look,
 * 2. added structured comments at top for use with DOxygen reporting
 *    as well as CVS keywords,
 * 3. fixed compiler warnings re ambiguous assign/compares,
 *    needed casts and unused/uninitialized variables,
 * 4. fixed funcs that didn't specify a return type,
 * 5. centralized prototypes in protos.h, removing incomplete ones,
 * 6. cleaned up use of bool/BOOLEAN type to suit C++ type,
 * 7. fixed initializer nesting in tumbler constants,
 * 8. renamed vars that conflict with C++ keywords (new, this),
 * 9. fixed global/extern confusion re some global vars.
 *
 */

#include <memory.h>
#include "udanax.h"

/* GRAN dsps across, POOM and SPAN dsp down */
void
dspadd(typedsp *a, typewisp *b, typedsp *c, int enftype)
    /* adds a dsp */
    /* to either a wid or a dsp */
    /* to get another dsp */
{
    lockadd(a->dsas, b->dsas, c->dsas, (unsigned)dspsize(enftype));
}

void
dspsub(typedsp *a, typewisp *b, typedsp *c, int enftype)
{
    locksubtract(a->dsas, b->dsas, c->dsas, (unsigned)dspsize(enftype));
}

// widequal(a,b) char//typewisp// *a,*b; { int i; for( i=0 ;i<widsize(enftype);i++){ if(*a++ != *b++) return(false); }
// return(true); } */

// These two routines are presently macros int dspsize (enftype) short enftype; { switch (enftype) { case GRAN: return
// (DSPSIZEGR); case POOM: return (DSPSIZEPM); case SPAN: return (DSPSIZESP); default: #ifndef DISTRIBUTION assert(0);
// /* dspsize: bad enftype */); #else assert(0); #endif } return (-1); } int widsize (enftype) short enftype; { switch
// (enftype) { case GRAN: return (WIDSIZEGR); case POOM: return (WIDSIZEPM); case SPAN: return (WIDSIZESP); default:
// #ifndef DISTRIBUTION assert(0); /* widsize: bad enftype */); #else assert(0); #endif } return (-1); } */

// Should be called whenever the wisp of a crum may need to be recalculated by looking at its son.
bool
setwispupwards(typecuc *ptr, int testflag)
{
    typecuc *father;

    int ntimeschanged = 0;
/* checkwholesubtree(ptr); */
/* asserttreeisok(ptr); */
    if (!ptr)
        return 0;

    typecuc *oldptr = ptr;

    bool changed;
    for (changed = true; changed && ptr; ptr = father) {
        father  = findfather((typecorecrum *) ptr);
        changed = setwisp((typecorecrum *) ptr);
        if (changed)
            ntimeschanged += 1;
    }

    if (ntimeschanged)
        ivemodified((typecorecrum *) oldptr);

#ifndef DISTRIBUTION
    if (testflag)
        asserttreeisok((typecorecrum *) oldptr);
#endif

    return 0 != ntimeschanged;
}

//UNUSED void
//UNUSED setwispsofsons(typecuc *ptr)
//UNUSED {
//UNUSED     for (ptr = (typecuc *) findleftmostbro((typecorecrum *) ptr); ptr;
//UNUSED          ptr = (typecuc *) getrightbro((typecorecrum *) ptr)) {
//UNUSED         setwisp((typecorecrum *) ptr);
//UNUSED     }
//UNUSED }

/* the local widditive operation in sequential enfilades */
/* widopseq (aptr, bptr, cptr) typewid *aptr,*bptr,*cptr; { lockadd (aptr->dsas, bptr->dsas, cptr->dsas,
 * widsize(GRAN)); } */
#define widopseq(a,b,c) lockadd((a)->dsas,(b)->dsas,(c)->dsas,widsize(GRAN))

/* the widditive operation in sequential enfilades */
static bool
setwidseq(typecuc *father)
{
    typecorecrum *ptr;

    if (father->height == 0)
        return false;

    typewid sum;
    clear(&sum, sizeof(sum));

    for (ptr = findleftson(father); ptr; ptr = getrightbro(ptr))
        widopseq(&sum, &ptr->cwid, &sum);

    if (lockeq(sum.dsas, father->cwid.dsas, (unsigned) widsize(father->cenftype)))
        return false;

    movewisp(&sum, &father->cwid);
    ivemodified((typecorecrum *) father);       /* zzzz */

    return true;
}

static void
lockmin(Tumbler *lock1, Tumbler *lock2, Tumbler *lock3, unsigned loxize)
{
    while (loxize--) {
        macrotumblermin(lock1, lock2, lock3);
        lock1++;
        lock2++;
        lock3++;
    }
}

static void
lockmax(Tumbler *lock1, Tumbler *lock2, Tumbler *lock3, unsigned loxize)
{
    while (loxize--) {
        macrotumblermax(lock1, lock2, lock3);
        lock1++;
        lock2++;
        lock3++;
    }
}

static void
didntchangewisps()
{
}

/* the widditive operation for nd */
static bool
setwispnd(typecuc *father)
{
    typecorecrum *ptr;
    typedsp newdsp, mindsp;
    typewid newwid, tempwid;
    bool lockiszerop;
    bool somethingchangedp = false;     /* mindsp != 0 or some tempwid !=0 */

    if (father->height == 0)
        return false;

/* remember original so can tell if changed */
    if ((ptr = findleftson(father)) == NULL) {
#ifndef DISTRIBUTION
        assert(0); // in setwispnd null findleftson
        clear(&father->cdsp, sizeof(father->cdsp));
        clear(&father->cwid, sizeof(father->cwid));
        ivemodified((typecorecrum *) father);
        return true;
#else
        assert(0);
#endif
    }

/* find new upper-left corner */
    movewisp(&ptr->cdsp, &mindsp);
    for (ptr = getrightbro(ptr); ptr; ptr = getrightbro(ptr))
        lockmin((Tumbler *) & mindsp, (Tumbler *) & ptr->cdsp, (Tumbler *) & mindsp, (unsigned)dspsize(ptr->cenftype));

    lockiszerop = iszerolock((Tumbler *) & mindsp, (unsigned)dspsize(father->cenftype));
    if (!lockiszerop) {
        somethingchangedp = true;
        dspadd(&father->cdsp, &mindsp, &newdsp, (int) father->cenftype);
    } else
        movewisp(&father->cdsp, &newdsp);

/* find new lower-right corner at the same time that */
/* we are readjusting the son's dsps to compensate */
/* for change in the father */
    clear(&newwid, sizeof(newwid));
    for (ptr = findleftson(father); ptr; ptr = getrightbro(ptr)) {
        if (!lockiszerop) {
            ptr->modified = true;      /* father gets ivemodified soon */
            dspsub(&ptr->cdsp, &mindsp, &ptr->cdsp, (int) ptr->cenftype);
        }

        lockadd((Tumbler *) & ptr->cdsp, (Tumbler *) & ptr->cwid, (Tumbler *) & tempwid,
                (unsigned)widsize(ptr->cenftype));
        lockmax((Tumbler *) & newwid, (Tumbler *) & tempwid, (Tumbler *) & newwid, (unsigned) widsize(ptr->cenftype));
    }

    if (!somethingchangedp && !lockeq((Tumbler *) & newwid, (Tumbler *) & father->cwid, (unsigned) widsize(father->cenftype)))
        somethingchangedp = true;

/* report whether anything changed */
    if (!somethingchangedp) {
        didntchangewisps();
        return false;
    }

    movewisp(&newdsp, &father->cdsp);
    movewisp(&newwid, &father->cwid);
    ivemodified((typecorecrum *) father);

    return true;
}

/* the widditive operation in general */
bool                                   /* return whether wisp of ptr has changed */
setwisp(typecorecrum *ptr)
{
    if (ptr->height == 0)
        return false;

    switch (ptr->cenftype) {
    case GRAN:
        return setwidseq((typecuc *) ptr);
    case SPAN:
    case POOM:
        return setwispnd((typecuc *) ptr);
    default:
        assert(0); // setwisp: bad enftype
    }

    return -1;                       /* Oh, the things one has to do to make computers happy */
}

/* reset father's wid but leave dsp alone */
void
setwidnd(typecuc *father)
{
    typecorecrum *ptr;
    typewid newwid;

    for (ptr = findleftson(father); ptr; ptr = getrightbro(ptr)) {
        clear(&newwid, sizeof(newwid));
        lockmax((Tumbler *) &newwid, (Tumbler *) &ptr->cwid, (Tumbler *) &newwid, (unsigned) widsize(ptr->cenftype));
    }

    if (!lockeq((Tumbler *) &father->cwid, (Tumbler *) &newwid, (unsigned) widsize(father->cenftype))) {
        movewisp(&newwid, &father->cwid);
        ivemodified((typecorecrum *) father);   /* zzz */
    }
}

/* --------- lock routines deal with full lock ------------- */
/* a lock is an array of loxize tumblers */

bool
iszerolock(Tumbler *lock, unsigned loxize)
{
    while (loxize--)
        if (!iszerotumbler(lock++))
            return false;

    return true;
}

bool
lockeq(Tumbler *lock1, Tumbler *lock2, unsigned loxize)
{
    while (loxize--)
        if (!tumblereq(lock1++, lock2++))
            return false;

    return true;
}

void
lockadd(Tumbler *lock1, Tumbler *lock2, Tumbler *lock3, unsigned loxize)
/* arrays of tumblers */
{
    while (loxize--)
        tumbleradd(lock1++, lock2++, lock3++);
}

void
locksubtract(Tumbler *lock1, Tumbler *lock2, Tumbler *lock3, unsigned loxize)
{
    while (loxize--)
        tumblersub(lock1++, lock2++, lock3++);
}

/* Returns whether ALL the lock is 1 story */
bool
lockis1story(Tumbler *lock, unsigned loxize)
{
    while (loxize--)
        if (!is1story(lock++))
            return false;

    return true;
}

/* setwispallthewayupwards (ptr) typecuc *ptr; { typecuc *father, *findfather(),*oldptr; bool setwisp(); bool changed;
 * if (!ptr) return; oldptr = ptr; for (; ptr; ptr = father) { father = findfather (ptr); for(ptr =
 * findleftmostbro(ptr);ptr;ptr= getrightbro(ptr)){ setwisp (ptr); } } if(true&&changed){ ivemodified(oldptr); } } */
