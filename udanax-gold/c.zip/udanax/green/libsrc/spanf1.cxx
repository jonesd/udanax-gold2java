/**********************************************************************
 * Copyright 2002 Jeff Rush <jrush@taupro.com>
 * Original Copyright 1979-2002 Udanax.com
 *
 * This file is part of the Udanax xanalogical storage system.
 *
 * Udanax is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * Udanax is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with Udanax; if not, write to the Free Software Foundation,
 * Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 **********************************************************************/

/**
 * @file  spanf1.cxx
 * @brief Udanax spanfilade calls
 *
 * (to be defined)
 *
 **/

/* Modification History:
 * $Log: spanf1.cxx,v $
 * Revision 1.12  2002/07/26 04:32:01  jrush
 * Replaced gerror() with assert()
 *
 * Revision 1.11  2002/05/28 04:22:29  jrush
 * Adjusted source files to comply with GPL licensing.
 *
 * Revision 1.10  2002/05/28 02:52:23  jrush
 * Made static any functions and global variables private to this source file
 * and commented out any unused functions.
 *
 * Revision 1.9  2002/04/12 11:56:43  jrush
 * Reorganized include file layout, renamed xanadu.h to udanax.h and
 * typecontext/typecrumcontext to C++ class Context/CrumContext.
 *
 * Revision 1.8  2002/04/10 18:01:54  jrush
 * Renamed class typeisa to IStreamAddr.
 *
 * Revision 1.7  2002/04/09 21:45:46  jrush
 * Renamed class 'tumbler' to 'Tumbler', for consistency with Python sources,
 * and changed typeisa from typedef to a subclass, in preparation for cleaning
 * up the type/class tree.
 *
 * Revision 1.6  2002/04/06 20:42:50  jrush
 * Switch from sess->alloc() style to new(sess) Object parameterized allocator.
 *
 * Revision 1.5  2002/04/06 19:51:30  jrush
 * Renamed TRUE/FALSE constant use to the C++ standard of true/false.
 *
 * Revision 1.4  2002/04/06 17:05:57  jrush
 * Switched from referring to 'task' for a client connection to 'session',
 * and converted the typetask typedef/struct into a Session C++ class.
 *
 * Revision 1.3  2002/04/06 15:01:17  jrush
 * Changed INT to just 'int'.
 *
 * Revision 1.2  2002/02/14 09:27:43  jrush
 * Cleaned up source:
 *
 * 1. ran thru the indent tool to achieve a standard look,
 * 2. added structured comments at top for use with DOxygen reporting
 *    as well as CVS keywords,
 * 3. fixed compiler warnings re ambiguous assign/compares,
 *    needed casts and unused/uninitialized variables,
 * 4. fixed funcs that didn't specify a return type,
 * 5. centralized prototypes in protos.h, removing incomplete ones,
 * 6. cleaned up use of bool/BOOLEAN type to suit C++ type,
 * 7. fixed initializer nesting in tumbler constants,
 * 8. renamed vars that conflict with C++ keywords (new, this),
 * 9. fixed global/extern confusion re some global vars.
 *
 */

#include <memory.h>
#include "udanax.h"

bool
insertspanf(Session *sess, typespanf spanfptr, IStreamAddr *isaptr, typesporglset sporglset, int spantype)
{
    typedsp crumorigin;
    typewid crumwidth;
    Tumbler lstream, lwidth;
    type2dbottomcruminfo linfo; /* zzz 2dinfo ? fix ? 5/27/84 ----- */

    prefixtumbler(isaptr, spantype, &crumorigin.dsas[ORGLRANGE]);
    tumblerclear(&crumwidth.dsas[ORGLRANGE]);
    clear(&linfo, sizeof(linfo));
    for (; sporglset; sporglset = (typesporglset) ((typeitemheader *) sporglset)->next) {
        if (((typeitemheader *) sporglset)->itemid == ISPANID) {
            movetumbler(&((typeispan *) sporglset)->stream, &lstream);
            movetumbler(&((typeispan *) sporglset)->width, &lwidth);
            movetumbler(isaptr, &linfo.homedoc);
        } else if (((typeitemheader *) sporglset)->itemid == SPORGLID) {
            movetumbler(&((typesporgl *) sporglset)->sporglorigin, &lstream);
            movetumbler(&((typesporgl *) sporglset)->sporglwidth, &lwidth);
            movetumbler(&((typesporgl *) sporglset)->sporgladdress, &linfo.homedoc);
        } else if (((typeitemheader *) sporglset)->itemid == TEXTID) {
            movetumbler(isaptr, &lstream);

/* create lwidth out of sporglset->length */
            tumblerclear(&lwidth);
            lwidth.mantissa[1] = ((typetext *) sporglset)->length;
            tumblerjustify(&lwidth);

            movetumbler(isaptr, &linfo.homedoc);
        } else
            assert(0); // insertspanf - bad itemid

        movetumbler(&lstream, &crumorigin.dsas[SPANRANGE]);
        movetumbler(&lwidth, &crumwidth.dsas[SPANRANGE]);
        insertnd(sess, (typecuc *) spanfptr, &crumorigin, &crumwidth, &linfo, SPANRANGE);
    }
    return true;
}

bool
findlinksfromtothreesp(Session *sess, typespanf spanfptr, typespecset fromvspecset, typespecset tovspecset,
                       typespecset threevspecset, typeispan *orglrange, typelinkset *linksetptr)
{
    typesporglset fromsporglset;
    typesporglset tosporglset;
    typesporglset threesporglset;
    typelinkset fromlinkset;
    typelinkset tolinkset;
    typelinkset threelinkset;
    bool olddebug = debug;

#ifndef DISTRIBUTION
    if (debug) {
        fprintf(stderr, "findlinksfromtothreesp fromset = %x, toset = %x, threeset = %x\n", (int) fromvspecset, (int) tovspecset,
                (int) threevspecset);
    }
#endif

    fromlinkset = tolinkset = threelinkset = NULL;

    if (fromvspecset)
        specset2sporglset(sess, fromvspecset, &fromsporglset, NOBERTREQUIRED);

    if (tovspecset)
        specset2sporglset(sess, tovspecset, &tosporglset, NOBERTREQUIRED);

    if (threevspecset)
        specset2sporglset(sess, threevspecset, &threesporglset, NOBERTREQUIRED);

    if (fromvspecset) {
        sporglset2linkset(sess, (typecuc *) spanfptr, fromsporglset, &fromlinkset, orglrange, LINKFROMSPAN);
        if (!fromlinkset) {
            *linksetptr = NULL;
            debug = olddebug;
            return true;
        }
    }

    if (tovspecset) {
        sporglset2linkset(sess, (typecuc *) spanfptr, tosporglset, &tolinkset, orglrange, LINKTOSPAN);
        if (!tolinkset) {
            *linksetptr = NULL;
            debug = olddebug;
            return true;
        }
    }

    if (threevspecset) {
        sporglset2linkset(sess, (typecuc *) spanfptr, threesporglset, &threelinkset, orglrange, LINKTHREESPAN);
        if (!threelinkset) {
            *linksetptr = NULL;
            debug = olddebug;
            return true;
        }
    }

    intersectlinksets(sess, fromlinkset, tolinkset, threelinkset, linksetptr);
    debug = olddebug;
    return true;
}

bool
findnumoflinksfromtothreesp(Session *sess, typespanf spanfptr, typespecset fromvspecset, typespecset tovspecset,
                            typespecset threevspecset, typeispan *orglrange, int *numptr)
{
    typelinkset linkset;
    int n;

    if (!findlinksfromtothreesp(sess, spanfptr, fromvspecset, tovspecset, threevspecset, orglrange, &linkset))
        return (false);
    for (n = 0; linkset; linkset = linkset->next, ++n) ;
    *numptr = n;
    return true;
}

bool
findnextnlinksfromtothreesp(Session *sess, typespecset fromvspecset, typespecset tovspecset,
                            typespecset threevspecset, typeispan *orglrangeptr, IStreamAddr *lastlinkisaptr,
                            typelinkset *nextlinksetptr, int *nptr)
{
    int n;
    typelinkset linkset;

    n = 0;
    *nextlinksetptr = NULL;

    if (!findlinksfromtothreesp(sess, spanf, fromvspecset, tovspecset, threevspecset, orglrangeptr, &linkset))
        return false;

    if (iszerotumbler(lastlinkisaptr)) {
        *nextlinksetptr = linkset;
    } else {
        for (; linkset; linkset = linkset->next) {
            if (tumblereq(&linkset->address, lastlinkisaptr)) {
                *nextlinksetptr = linkset->next;
                break;
            }
        }
    }

    if (!linkset) {
        *nextlinksetptr = NULL;
        *nptr = 0;
        return true;
    }

    for (linkset = *nextlinksetptr; linkset; linkset = linkset->next) {
        if (++n >= *nptr) {
            linkset->next = NULL;
            break;
        }
    }
    *nptr = n;
    return true;
}

bool
finddocscontainingsp(Session *sess, typespanset ispanset, typelinkset *addresssetptr)
{
    Tumbler docid;
    Context *context, *c;
    typelinkset *headptr;
    typelink document;
    typespan docspace;

#ifndef DISTRIBUTION
    if (debug) {
        fprintf(stderr, "\nFINDDOCSCONTAININGsp\n");
        fooitemset("", (typeitem *) ispanset);
    }
#endif

    headptr = addresssetptr;
    *addresssetptr = NULL;
    clear(&docspace, sizeof(typespan));
    tumblerincrement(&docspace.stream, 0, DOCISPAN, &docspace.stream);
    tumblerincrement(&docspace.width, 0, 1, &docspace.width);

    for (; ispanset; ispanset = ispanset->next) {
        context = retrieverestricted((typecuc *) spanf, &docspace, ORGLRANGE, ispanset, SPANRANGE, (IStreamAddr *) NULL);

        for (c = context; c; c = (Context *) c->nextcontext) {
            movetumbler(&c->totaloffset.dsas[ORGLRANGE], &docid);
            beheadtumbler(&docid, &document.address);
            if (isinlinklist(*headptr, &document.address))
                continue;

            document.itemid = LINKID;
            document.next = NULL;
            addresssetptr = (typelinkset *) onitemlist(sess, (typeitem *) & document, (typeitemset *) addresssetptr);
        }
        contextfree(context);
    }

#ifndef DISTRIBUTION
    if (debug)
        fooitemset("", (typeitem *) *headptr);
#endif

    return true;
}

static bool
retrievesporglsetinrange(Session *sess, typesporglset sporglptr, typespan *whichspace, typesporglset *sporglsetptr)
{
    Context *context, *c, *tmp;
    typesporgl *sporglset;

    for (; sporglptr; sporglptr = (typesporglset) sporglptr->xxxxsporgl.next) {
        context = retrieverestricted((typecuc *) spanf, (typespan *) sporglptr, SPANRANGE, whichspace, ORGLRANGE, (IStreamAddr *) NULL
        /* kluge to make links show thru to version &sporglptr->sporgladdress */ );

        /* dumpcontextlist(context); */
        for (c = context; c;) {
            sporglset = new(sess) typesporgl;
            contextintosporgl((type2dcontext *) c, (Tumbler *) NULL, sporglset, SPANRANGE);
            *sporglsetptr = (typesporglset) sporglset;
            sporglsetptr = (typesporglset *) & sporglset->next;

            tmp = (Context *) c->nextcontext;

            /*
             * if (c->contexttype == GRAN)
             *     --contextnum;
             * else
             *     --c2dontextnum;
             * efree((char*)c);
             */

            c = tmp;
        }
        contextfree(context);
    }
    return true;
}

bool
retrieveendsetsfromspanf(Session *sess, typespecset specset, typespecset *fromsetptr, typespecset *tosetptr,
                         typespecset *threesetptr)
{
    typespan fromspace, tospace, threespace;
    typesporglset sporglset;
    typesporglset fromsporglset;
    typesporglset tosporglset;
    typesporglset threesporglset;
    bool bang(), retrievesporglsetinrange(), linksporglset2specset();
    bool temp;

#ifndef DISTRIBUTION
    if (debug) {
        fprintf(stderr, "retrieveendsetsfromspanf\n");
        fooitemset("", (typeitem *) specset);
    }
#endif

    clear(&fromspace, sizeof(typespan));
    clear(&tospace, sizeof(typespan));
    clear(&threespace, sizeof(typespan));

    fromspace.stream.mantissa[0] = LINKFROMSPAN;
    fromspace.width.mantissa[0] = 1;

    tospace.stream.mantissa[0] = LINKTOSPAN;
    tospace.width.mantissa[0] = 1;

    threespace.stream.mantissa[0] = LINKTHREESPAN;
    threespace.width.mantissa[0] = 1;

    fromsporglset = tosporglset = threesporglset = NULL;

    if (!(specset2sporglset(sess, specset, &sporglset, NOBERTREQUIRED)
          && retrievesporglsetinrange(sess, sporglset, &fromspace, &fromsporglset)
          && linksporglset2specset(sess, &((typevspec *) specset)->docisa, fromsporglset, fromsetptr, NOBERTREQUIRED)
          && retrievesporglsetinrange(sess, sporglset, &tospace, &tosporglset)
          && linksporglset2specset(sess, &((typevspec *) specset)->docisa, tosporglset, tosetptr, NOBERTREQUIRED))) {
        return false;
    }
    if (threesetptr) {
        temp = (retrievesporglsetinrange(sess, sporglset, &threespace, &threesporglset)
                && linksporglset2specset(sess, &((typevspec *) specset)->docisa, threesporglset, threesetptr,
                                         NOBERTREQUIRED));
        return temp;
    }
    return true;
}
