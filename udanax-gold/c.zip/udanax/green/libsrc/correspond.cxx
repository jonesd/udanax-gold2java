/**********************************************************************
 * Copyright 2002 Jeff Rush <jrush@taupro.com>
 * Original Copyright 1979-2002 Udanax.com
 *
 * This file is part of the Udanax xanalogical storage system.
 *
 * Udanax is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * Udanax is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with Udanax; if not, write to the Free Software Foundation,
 * Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 **********************************************************************/

/**
 * @file  correspond.cxx
 * @brief Routines for comparing versions --- lower level
 *
 * (to be defined)
 *
 **/

/* Modification History:
 * $Log: correspond.cxx,v $
 * Revision 1.12  2002/07/26 04:30:29  jrush
 * Replaced gerror() with assert()
 *
 * Revision 1.11  2002/05/28 04:22:29  jrush
 * Adjusted source files to comply with GPL licensing.
 *
 * Revision 1.10  2002/05/28 02:49:42  jrush
 * Made static any functions and global variables private to this source file
 * and commented out any unused functions.
 *
 * Revision 1.9  2002/04/16 22:39:50  jrush
 * Converted many #defines into enumeration types instead, and adjusted
 * function prototypes accordingly.
 *
 * Revision 1.8  2002/04/12 11:56:42  jrush
 * Reorganized include file layout, renamed xanadu.h to udanax.h and
 * typecontext/typecrumcontext to C++ class Context/CrumContext.
 *
 * Revision 1.7  2002/04/09 21:45:46  jrush
 * Renamed class 'tumbler' to 'Tumbler', for consistency with Python sources,
 * and changed typeisa from typedef to a subclass, in preparation for cleaning
 * up the type/class tree.
 *
 * Revision 1.6  2002/04/06 20:42:50  jrush
 * Switch from sess->alloc() style to new(sess) Object parameterized allocator.
 *
 * Revision 1.5  2002/04/06 19:51:30  jrush
 * Renamed TRUE/FALSE constant use to the C++ standard of true/false.
 *
 * Revision 1.4  2002/04/06 17:05:57  jrush
 * Switched from referring to 'task' for a client connection to 'session',
 * and converted the typetask typedef/struct into a Session C++ class.
 *
 * Revision 1.3  2002/04/06 15:01:17  jrush
 * Changed INT to just 'int'.
 *
 * Revision 1.2  2002/02/14 09:27:43  jrush
 * Cleaned up source:
 *
 * 1. ran thru the indent tool to achieve a standard look,
 * 2. added structured comments at top for use with DOxygen reporting
 *    as well as CVS keywords,
 * 3. fixed compiler warnings re ambiguous assign/compares,
 *    needed casts and unused/uninitialized variables,
 * 4. fixed funcs that didn't specify a return type,
 * 5. centralized prototypes in protos.h, removing incomplete ones,
 * 6. cleaned up use of bool/BOOLEAN type to suit C++ type,
 * 7. fixed initializer nesting in tumbler constants,
 * 8. renamed vars that conflict with C++ keywords (new, this),
 * 9. fixed global/extern confusion re some global vars.
 *
 */

#include "udanax.h"

static void
restrictvspecsetovercommonispans(Session *sess, typeispanset ispanset, typespecset specset, typespecset *newspecsetptr)
{
    typeorgl versionorgl;
    typevspec *s1;
    typevspanset docvspanset;

#ifndef DISTRIBUTION
    fooitemset("entering restrictspecsetovercommonispans \n", (typeitem *) ispanset);
    fooitemset("\nspecset = \n", (typeitem *) specset);
#endif

    *newspecsetptr = NULL;
    for (; ispanset; ispanset = ispanset->next) {
        for (; specset; specset = (typespecset) ((typeitemheader *) specset)->next) {
            if (!findorgl(sess, granf, &((typevspec *) specset)->docisa, &versionorgl, READBERT))
                assert(0); // restrictvspecset

            docvspanset = NULL;
            if (ispan2vspanset(sess, versionorgl, ispanset, &docvspanset)) {
                s1 = new(sess) typevspec;
//                s1 = (typevspec *) sess->alloc(sizeof(typevspec));
                s1->itemid = VSPECID;
                *newspecsetptr = (typespecset) s1;
                movetumbler(&((typevspec *) specset)->docisa, &s1->docisa);
                s1->vspanset = docvspanset;
                newspecsetptr = (typespecset *) & s1->next;
            }
        }
    }
    *newspecsetptr = NULL;
#ifndef DISTRIBUTION
    fooitemset("leaving restrictspecsetovercommonispans \n", (typeitem *) ispanset);
    fooitemset("\nspecset = \n", (typeitem *) specset);
    fooitemset("\n newspecset = \n", (typeitem *) *newspecsetptr);
#endif
}

static void
removespansnotinoriginal(Session *sess, typespecset original, typespecset *newptr)
{
    typevspanset newspanset;
    typevspec *okspec;

    if (!newptr || !*newptr || !original)
        assert(0); // Bad removespans call

    typevspec *first = NULL;
    typevspec **nextptr = NULL;

    typespecset newss;
    for (newss = *newptr; newss; newss = (typespecset) ((typeitemheader *) newss)->next) {
        typespecset oldss;

        for (oldss = original; oldss; oldss = (typespecset) ((typeitemheader *) oldss)->next) {

            if (tumblercmp(&((typevspec *) newss)->docisa, &((typevspec *) oldss)->docisa))
                continue;

            if (intersectspansets(sess, ((typevspec *) newss)->vspanset, ((typevspec *) oldss)->vspanset, &newspanset, VSPANID)) {
                okspec = new(sess) typevspec;
//                okspec = (typevspec *) sess->alloc(sizeof(typevspec));
                okspec->itemid = VSPECID;
                movetumbler(&((typevspec *) newss)->docisa, &okspec->docisa);
                okspec->vspanset = newspanset;

                if (!first)
                    first = okspec;
                else
                    *nextptr = okspec;

                nextptr = &okspec->next;
            }
        }
    }

    sess->freeitemset((typeitemset) * newptr);
    *nextptr = NULL;
    *newptr = (typespecset) first;
}

void
restrictspecsetsaccordingtoispans(Session *sess, typeispanset ispanset, typespecset *specset1, typespecset *specset2)
{
    typespecset s1;
    typespecset s2;

#ifndef DISTRIBUTION
    fooitemset("entering retrievespecsetsaccordingtoispans \n", (typeitem *) *specset1);
    fooitemset("\n specset2 = \n", (typeitem *) *specset2);
#endif
    restrictvspecsetovercommonispans(sess, ispanset, *specset1, &s1);
/* removespansnotinoriginal (sess, *specset1, &s1); */
    removespansnotinoriginal(sess, s1, specset1);

    sess->freeitemset(/**specset1*/ (typeitemset) s1);
/* *specset1 = s1; */
    restrictvspecsetovercommonispans(sess, ispanset, *specset2, &s2);
/* removespansnotinoriginal (sess, *specset2, &s2); */
    removespansnotinoriginal(sess, s2, specset2);

    sess->freeitemset(/**specset2*/ (typeitemset) s2);
/* *specset2 = s2; */
#ifndef DISTRIBUTION
    fooitemset("leaving retrievespecsetsaccordingtoispans \n", (typeitem *) *specset1);
    fooitemset("\n specset2 = \n", (typeitem *) *specset2);
#endif
}

static bool
spanintersection(typespan *aptr, typespan *bptr, typespan *cptr)
{
    Tumbler aend, bend;

    tumblerclear(&cptr->stream);
    tumblerclear(&cptr->width);
    tumbleradd(&bptr->stream, &bptr->width, &bend);
    if (tumblercmp(&aptr->stream, &bend) >= EQUAL)
        return (false);
    tumbleradd(&aptr->stream, &aptr->width, &aend);
    if (tumblercmp(&bptr->stream, &aend) >= EQUAL)
        return (false);
/* these following assignments are clearly wrong 12/4/84 */
    switch (tumblercmp(&aptr->stream, &bptr->stream)) {
    case EQUAL:                       /* this ones probably ok */
        movetumbler(&aptr->stream, &cptr->stream);
        switch (tumblercmp(&aend, &bend)) {
        case EQUAL:
        case LESS:
            movetumbler(&aptr->width, &cptr->width);
            break;
        case GREATER:
            movetumbler(&bptr->width, &cptr->width);
        }
        break;
    case GREATER:
        movetumbler(&aptr->stream, &cptr->stream);
        switch (tumblercmp(&aend, &bend)) {
        case EQUAL:
        case LESS:                    /* ok */
            movetumbler(&aptr->width, &cptr->width);
            break;
        case GREATER:                 /* ???? */
            tumblersub(&bend, &aptr->stream, &cptr->width);
/* movetumbler (&bptr->width, &cptr->width); */
        }
        break;
    case LESS:
        movetumbler(&bptr->stream, &cptr->stream);
        switch (tumblercmp(&aend, &bend)) {
        case EQUAL:
        case GREATER:                 /* ok */
            movetumbler(&bptr->width, &cptr->width);
            break;
        case LESS:                    /* ??? */
            tumblersub(&aend, &bptr->stream, &cptr->width);
/* movetumbler (&aptr->width, &cptr->width); */
        }
    }
#ifndef DISTRIBUTION
    foospan("in spanintersection \n aspan = ", aptr);
    foospan("\n bspan = ", bptr);
    foospan("\n cspan = ", cptr);
#endif
    return (true);
}

static bool
comparespans(Session *sess, typespan *span1, typespan *span2, typespan **span3, typeitemid spantype)
{
    if (iszerotumbler(&span1->width) || iszerotumbler(&span2->width))
        return false;

    *span3 = new(sess) typespan;
//    *span3 = (typespan *) sess->alloc(sizeof(typespan));
    (*span3)->itemid = spantype;
    (*span3)->next   = NULL;

    if (spanintersection(span1, span2, *span3))
        return true;
    else {
        sess->freeexplicit((char *) *span3);
        *span3 = NULL;
        return false;
    }
}

bool
intersectspansets(Session *sess, typespanset set1, typespanset set2, typespanset *set3, typeitemid spantype)
{
    /*BUG: there is some inconsistency in this function as to whether set3 is a typespanset or a ptr to a typespanset */
    typespan *p;

#ifndef DISTRIBUTION
    foo("entering intersectspansets");
#endif

    if (!set1 || !set2 || !set3)
        assert(0); // Bad intersectspansets call

#ifndef DISTRIBUTION
    foo("dumping set1\n");
    foospanset("", set1);
    foo("dumping set2\n");
    foospanset("", set2);
#endif
    *set3 = NULL;
    for (; set1; set1 = set1->next) {
        for (p = set2; p; p = p->next) {
            if (comparespans(sess, set1, p, set3, spantype))
                set3 = &(*set3)->next;
        }
    }
#ifndef DISTRIBUTION
    foo("leaving intersectspansets");
    foo("dumping set3\n");
    foospanset("", *set3);
#endif
    return true;
}

static typespanpair *
makespanpair(Session *sess, Tumbler *doc1, Tumbler *start1, Tumbler *doc2, Tumbler *start2, Tumbler *width)
{
    typespanpair *spanpair = new(sess) typespanpair;
    //    spanpair = (typespanpair *) sess->alloc(sizeof(typespanpair));

    docidandvstream2tumbler(doc1, start1, &spanpair->stream1);
    docidandvstream2tumbler(doc2, start2, &spanpair->stream2);
    movetumbler(width, &spanpair->widthofspan);

    return spanpair;
}

static void
makespanpairsforispan(Session *sess, Tumbler *iwidth, typespecset *specset1ptr, typespecset *specset2ptr, typespanpairset *pairsetptr)
{
    typevspec *spec1, *spec2;
    typespan *span1, *span2;
    Tumbler sum;
    int cmp;

#ifndef DISTRIBUTION
    foo("entering makespanpairsforispan\n");
    fooitemset("\n*specset1ptr = \n", (typeitem *) *specset1ptr);
    fooitemset("\n*specset2ptr = \n", (typeitem *) *specset2ptr);
#endif
    *pairsetptr = NULL;
    tumblerclear(&sum);
    spec1 = (typevspec *) * specset1ptr;
    span1 = spec1->vspanset;
    spec2 = (typevspec *) * specset2ptr;
    span2 = spec2->vspanset;
    while (span1 && span2 && tumblercmp(iwidth, &sum) == GREATER) {
        cmp = tumblercmp(&span1->width, &span2->width);
        switch (cmp) {
        case LESS:
        case EQUAL:
            *pairsetptr =
                    makespanpair(sess, &spec1->docisa, &span1->stream, &spec2->docisa, &span2->stream,
                                 &span1->width);
            tumbleradd(&sum, &span1->width, &sum);
            if (cmp == EQUAL)
                span2 = span2->next;
            else {
                tumbleradd(&span2->stream, &span1->width, &span2->stream);
                tumblersub(&span2->width, &span1->width, &span2->width);
            }
            span1 = span1->next;
            break;
        case GREATER:
            *pairsetptr =
                    makespanpair(sess, &spec1->docisa, &span1->stream, &spec2->docisa, &span2->stream,
                                 &span2->width);
            tumbleradd(&sum, &span2->width, &sum);
            tumbleradd(&span1->stream, &span2->width, &span1->stream);
            tumblersub(&span1->width, &span2->width, &span1->width);
            span2 = span2->next;
        }
        spec1->vspanset = span1;
        spec2->vspanset = span2;
        if (!span1) {
            spec1 = spec1->next;
            *specset1ptr = (typespecset) spec1;
            if (spec1)
                span1 = spec1->vspanset;
        }
        if (!span2) {
            spec2 = spec2->next;
            *specset2ptr = (typespecset) spec2;
            if (spec2)
                span2 = spec2->vspanset;
        }
        pairsetptr = &(*pairsetptr)->nextspanpair;
    }
#ifndef DISTRIBUTION
    foo("leaving makespanpairsforispan\n");
#endif
}

void
makespanpairset(Session *sess, typeispanset ispanset, typespecset specset1, typespecset specset2, typespanpairset *pairsetptr)
{
    Tumbler iwidth;
    typespanpairset pairset;

#ifndef DISTRIBUTION
    foo("entering makespanpairset");
    fooitemset("ispanset = \n", (typeitem *) ispanset);
    fooitemset("specset1 = \n", (typeitem *) specset1);
    fooitemset("specset2 = \n", (typeitem *) specset2);
#endif
    *pairsetptr = NULL;
    for (; ispanset; ispanset = ispanset->next) {
        movetumbler(&ispanset->width, &iwidth);
        makespanpairsforispan(sess, &iwidth, &specset1, &specset2, &pairset);
        *pairsetptr = pairset;
        pairsetptr = &pairset->nextspanpair;
    }
    *pairsetptr = NULL;
#ifndef DISTRIBUTION
    foo("leaving makespanpairset");
#endif
}

//UNUSED
//UNUSED static int                                    /* return LESS, EQUAL or GREATER */
//UNUSED spansubtract(typespan *aptr, typespan *bptr, typespan *cptr)
//UNUSED {                                      /* no negative spans (whatever they * may be) */
//UNUSED /* all returned tumbler values are * positive */
//UNUSED 
//UNUSED     int cmp = tumblercmp(&aptr->width, &bptr->width);
//UNUSED     switch (cmp) {
//UNUSED     case EQUAL:
//UNUSED         tumblerclear(&cptr->stream);
//UNUSED         tumblerclear(&cptr->width);
//UNUSED         break;
//UNUSED     case GREATER:
//UNUSED         tumbleradd(&aptr->stream, &bptr->width, &cptr->stream);
//UNUSED         tumblersub(&aptr->width, &bptr->width, &cptr->width);
//UNUSED         break;
//UNUSED     case LESS:
//UNUSED         tumbleradd(&bptr->stream, &aptr->width, &cptr->stream);
//UNUSED         tumblersub(&bptr->width, &aptr->width, &cptr->width);
//UNUSED     }
//UNUSED 
//UNUSED     return cmp;
//UNUSED }
