/**********************************************************************
 * Copyright 2002 Jeff Rush <jrush@taupro.com>
 * Original Copyright 1979-2002 Udanax.com
 *
 * This file is part of the Udanax xanalogical storage system.
 *
 * Udanax is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * Udanax is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with Udanax; if not, write to the Free Software Foundation,
 * Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 **********************************************************************/

/**
 * @file  diskalloc.cxx
 * @brief ???
 *
 * (to be defined)
 *
 **/

/* Modification History:
 * $Log: diskalloc.cxx,v $
 * Revision 1.10  2002/07/26 04:30:29  jrush
 * Replaced gerror() with assert()
 *
 * Revision 1.9  2002/05/28 04:22:29  jrush
 * Adjusted source files to comply with GPL licensing.
 *
 * Revision 1.8  2002/05/28 02:49:42  jrush
 * Made static any functions and global variables private to this source file
 * and commented out any unused functions.
 *
 * Revision 1.7  2002/04/13 13:44:10  jrush
 * Renamed struct _diskheader to Diskheader, for C++ style.
 *
 * Revision 1.6  2002/04/12 22:53:20  jrush
 * Changed from using my setmem() to the clib's memset() and removed no
 * longer-needed usefull.cxx
 *
 * Revision 1.5  2002/04/12 11:56:42  jrush
 * Reorganized include file layout, renamed xanadu.h to udanax.h and
 * typecontext/typecrumcontext to C++ class Context/CrumContext.
 *
 * Revision 1.4  2002/04/06 19:51:30  jrush
 * Renamed TRUE/FALSE constant use to the C++ standard of true/false.
 *
 * Revision 1.3  2002/04/06 15:01:17  jrush
 * Changed INT to just 'int'.
 *
 * Revision 1.2  2002/02/14 09:27:43  jrush
 * Cleaned up source:
 *
 * 1. ran thru the indent tool to achieve a standard look,
 * 2. added structured comments at top for use with DOxygen reporting
 *    as well as CVS keywords,
 * 3. fixed compiler warnings re ambiguous assign/compares,
 *    needed casts and unused/uninitialized variables,
 * 4. fixed funcs that didn't specify a return type,
 * 5. centralized prototypes in protos.h, removing incomplete ones,
 * 6. cleaned up use of bool/BOOLEAN type to suit C++ type,
 * 7. fixed initializer nesting in tumbler constants,
 * 8. renamed vars that conflict with C++ keywords (new, this),
 * 9. fixed global/extern confusion re some global vars.
 *
 */

#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <memory.h>
#include "udanax.h"

extern int enffiledes;
extern bool isxumain;

static bool maximumsetupsizehasbeenhit = false;
int maximumsetupsize = 0; // ref from servers

Diskheader diskheader; //ref by corediskout.cxx only

static char mask[8] = { 1, 2, 4, 8, 16, 32, 64, 128 };

//UNUSED static int // UNUSED
//UNUSED isalloced(int n)
//UNUSED {
//UNUSED     return (diskheader.bitmap[n / 8] | mask[n % 8]);
//UNUSED }

typediskloafptr
diskalloc()
/* Find an unallocated loaf on the the disk, * allocate it (take it off the free list), and * return something thru
 * which I can deal with it. */
{
    int i, j;
    typediskloafptr ret;

    for (i = 0; i < BITMAPSIZE && !diskheader.bitmap[i]; ++i)
        ;

    if (i == BITMAPSIZE)
        assert(0); // Out of diskalloc bitmap space

    for (j = 0; j < 8; ++j) {
        if (diskheader.bitmap[i] & mask[j]) {
            diskheader.bitmap[i] = diskheader.bitmap[i] & ~mask[j];
            break;
        }
    }
    ret.diskblocknumber = i * 8 + j;
    ret.insidediskblocknumber = 0 /* 1 */ ;

    if (maximumsetupsize && ret.diskblocknumber >= maximumsetupsize)
        maximumsetupsizehasbeenhit = true;

    return ret;
}

/* Return the named piece of disk to free space, * i.e. de-allocate it */
void
diskfree(typediskloafptrdigit loafptr)
{
    if (loafptr == DISKPTRNULL)
        return;

    if (!goodblock(loafptr))
        assert(0); // Unallocated block in diskfree

    diskheader.bitmap[loafptr / 8] = diskheader.bitmap[loafptr / 8] | mask[loafptr % 8];
}

void
diskset(typediskloafptrdigit loafptr)
{
    if (loafptr == DISKPTRNULL)
        return;

    if (!goodblock(loafptr))
        assert(0); // Unallocated block in diskfree

    diskheader.bitmap[loafptr / 8] = diskheader.bitmap[loafptr / 8] & ~mask[loafptr % 8];
}

bool                                   /* false is not good enfilade file */
readallocinfo(int fd)
{
    if (lseek(fd, 0L, 0) < 0) {
        perror("lseek in readallocinfo");
        assert(0); // lseek failed
    }

    if (read(fd, (char *)&diskheader, sizeof(diskheader)) <= 0) {
        perror("read");
        assert(0); // read
    }

    bool ret = diskheader.hasenftops;
    if (ret) {
        enffiledes = fd;
        readpartialdiskalloctablefromdisk();
    } else {
        fprintf(stderr, "Old enffile invalid... re-initializing\n");
        initheader();
    }

    return ret;
}

void
initheader()
{
    memset(diskheader.bitmap, 0xFF, sizeof(diskheader.bitmap)); /* free all */
    clear(diskheader.bitmap, (NUMDISKLOAFSINHEADER + 3) / 8 + 1);

/* unfree bitmap and granf and spanf */
/* zzzz this rounds up a byte thus may reserve unused blocks fix by clearing bits ! */

    diskheader.hasenftops = false;
    initincorealloctables();
}

void
diskallocexit(int fd)
{
    diskheader.hasenftops = true;
    savepartialdiskalloctabletodisk();
    writeallocinfo(fd);
}

void
writeallocinfo(int fd)
{
    if (lseek(fd, 0L, 0) < 0) {
        perror("lseek in writeallocinfo");
        assert(0); // lseek failed
    }

    if (write(fd, (char *) &diskheader, sizeof(diskheader)) == -1) {
        perror("write in writeallocinfo");
        assert(0); // write failed
    }
}

/* 
 * bool isalloced (loafptr) typediskloafptr loafptr; { return
 * (!(diskheader.bitmap[loafptr/8] & mask[loafptr%8])); } */
bool
goodblock(typediskloafptrdigit diskptr)
{
    if (diskptr == 0)
        return false;

    return !(diskheader.bitmap[diskptr / 8] & mask[diskptr % 8]);
}
