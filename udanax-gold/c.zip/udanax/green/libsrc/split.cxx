/**********************************************************************
 * Copyright 2002 Jeff Rush <jrush@taupro.com>
 * Original Copyright 1979-2002 Udanax.com
 *
 * This file is part of the Udanax xanalogical storage system.
 *
 * Udanax is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * Udanax is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with Udanax; if not, write to the Free Software Foundation,
 * Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 **********************************************************************/

/**
 * @file  split.cxx
 * @brief routines to split overfull loaves
 *
 * (to be defined)
 *
 **/

/* Modification History:
 * $Log: split.cxx,v $
 * Revision 1.8  2002/07/26 04:33:47  jrush
 * Replaced gerror() with assert()
 *
 * Revision 1.7  2002/05/28 04:22:29  jrush
 * Adjusted source files to comply with GPL licensing.
 *
 * Revision 1.6  2002/05/28 02:52:23  jrush
 * Made static any functions and global variables private to this source file
 * and commented out any unused functions.
 *
 * Revision 1.5  2002/04/12 11:56:43  jrush
 * Reorganized include file layout, renamed xanadu.h to udanax.h and
 * typecontext/typecrumcontext to C++ class Context/CrumContext.
 *
 * Revision 1.4  2002/04/06 19:51:30  jrush
 * Renamed TRUE/FALSE constant use to the C++ standard of true/false.
 *
 * Revision 1.3  2002/04/06 15:01:17  jrush
 * Changed INT to just 'int'.
 *
 * Revision 1.2  2002/02/14 09:27:43  jrush
 * Cleaned up source:
 *
 * 1. ran thru the indent tool to achieve a standard look,
 * 2. added structured comments at top for use with DOxygen reporting
 *    as well as CVS keywords,
 * 3. fixed compiler warnings re ambiguous assign/compares,
 *    needed casts and unused/uninitialized variables,
 * 4. fixed funcs that didn't specify a return type,
 * 5. centralized prototypes in protos.h, removing incomplete ones,
 * 6. cleaned up use of bool/BOOLEAN type to suit C++ type,
 * 7. fixed initializer nesting in tumbler constants,
 * 8. renamed vars that conflict with C++ keywords (new, this),
 * 9. fixed global/extern confusion re some global vars.
 *
 */

#include <memory.h>
#include "udanax.h"

/* Should be called whenever a crum may have too many sons ** if it does, it is split, and its father is checked,
 * etc... */
bool
splitcrumupwards(typecuc *father)
{
    bool splitsomething = false;

    if (father->height <= 0)
        assert(0); // splitcrumupwards on bottom crum

    for (; toomanysons(father); father = (typecuc *) findfather((typecorecrum *) father)) {
        if (isfullcrum((typecorecrum *) father)) {
            levelpush(father);
            splitcrum((typecuc *) findleftson(father));

#ifndef DISTRIBUTION
            fprintf(stderr, "splitcrumupwards split something\n");
            asserttreeisok((typecorecrum *) father);
#endif
            return true;
        }
        splitcrum(father);
        splitsomething = true;
    }

#ifndef DISTRIBUTION
    asserttreeisok((typecorecrum *) father);
#endif

    return splitsomething;
}

/* splits a crum for sequential enfilades */
static void
splitcrumseq(typecuc *father)
{
    typecorecrum *newcc, *ptr, *next;
    int i, halfsons;

    ivemodified((typecorecrum *) father);
    newcc = createcrum((int) father->height, (int) father->cenftype);
    reserve(newcc);
    adopt(newcc, RIGHTBRO, (typecorecrum *) father);
    rejuvinate(newcc);
    ivemodified(newcc);
    halfsons = father->numberofsons / 2;
    for (i = 0, ptr = findrightmostson(father); i < halfsons && ptr; ++i, ptr = next) {
        next = findleftbro(ptr);
        disown(ptr);
        adopt(ptr, LEFTMOSTSON, newcc);
        rejuvinate(ptr);
        ivemodified(ptr);              /* zzz */
    }

    setwispupwards(father, 0);
    setwispupwards((typecuc *) newcc, 0);
}

static void
splitcrumsp(typecuc *father)
{
    typecorecrum *ptr, *correctone;

    for (correctone = ptr = findleftson(father); ptr; ptr = findrightbro(ptr)) {
/* if (tumblercmp(&ptr->cdsp.dsas[SPANRANGE], &correctone->cdsp.dsas[SPANRANGE]) == GREATER) */
        if (comparecrumsdiagonally(ptr, correctone) == GREATER)
            correctone = ptr;
    }
    peelcrumoffnd(correctone);
}

static void
splitcrumpm(typecuc *father)
{
    typecorecrum *ptr, *correctone;

    for (correctone = ptr = findleftson(father); ptr; ptr = findrightbro(ptr)) {
        if (tumblercmp(&ptr->cdsp.dsas[SPANRANGE], &correctone->cdsp.dsas[SPANRANGE]) == GREATER)
/* if (comparecrumsdiagonally(ptr, correctone) == LESS) */
            correctone = ptr;
    }
    peelcrumoffnd(correctone);
}

//UNUSED static void
//UNUSED splitcrumpminthiscrum(typecuc *father)
//UNUSED {
//UNUSED     for (; father; father = (typecuc *) findrightbro((typecorecrum *) father)) {
//UNUSED         while (toomanysons(father)) {
//UNUSED             splitcrumpm(father);
//UNUSED         }
//UNUSED     }
//UNUSED }

/* splits an individual crum */
void
splitcrum(typecuc *father)
{
    switch (father->cenftype) {
    case GRAN:  splitcrumseq(father);  break;
    case POOM:  splitcrumpm(father);   break;
    case SPAN:  splitcrumsp(father);   break;
    default:
        assert(0); // splitcrum: bad enftype
    }
    setwispupwards(father, 0);
}

void
peelcrumoffnd(typecorecrum *ptr)
{
    if (isfullcrum(ptr))
        assert(0); // peeloffcurmnd called with fullcrum

    typecuc *father     = findfather(ptr);
    int      ofatherage = father->age;
    int      optrage    = ptr->age;

    father->age = NEW;
    ptr->age    = NEW;

    reserve((typecorecrum *) father);
    father->modified = true;           /* an uncle will get ivemodified shortly in 10 lines */
    reserve(ptr);
    disown(ptr);

    typecorecrum *newcc = createcrum((int) father->height, (int) father->cenftype);
    adopt(newcc, RIGHTBRO, (typecorecrum *) father);
    movewisp(&father->cdsp, &newcc->cdsp);
    adopt(ptr, LEFTMOSTSON, newcc);
    rejuvinate(newcc);
    rejuvinate(ptr);
    rejuvinate((typecorecrum *) father);

    if (ofatherage == RESERVED)
        father->age = RESERVED;

    if (optrage == RESERVED)
        ptr->age = RESERVED;

    ivemodified(ptr);
    setwispupwards(father, 0);
    setwispupwards((typecuc *) newcc, 0);
    setwispupwards((typecuc *) ptr, 1);
}
