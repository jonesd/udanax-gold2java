/**********************************************************************
 * Copyright 2002 Jeff Rush <jrush@taupro.com>
 * Original Copyright 1979-2002 Udanax.com
 *
 * This file is part of the Udanax xanalogical storage system.
 *
 * Udanax is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * Udanax is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with Udanax; if not, write to the Free Software Foundation,
 * Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 **********************************************************************/

/**
 * @file  allocdebug.cxx
 * @brief ???
 *
 * (to be defined)
 *
 **/

/* Modification History:
 * $Log: allocdebug.cxx,v $
 * Revision 1.6  2002/05/28 04:22:29  jrush
 * Adjusted source files to comply with GPL licensing.
 *
 * Revision 1.5  2002/04/12 11:56:42  jrush
 * Reorganized include file layout, renamed xanadu.h to udanax.h and
 * typecontext/typecrumcontext to C++ class Context/CrumContext.
 *
 * Revision 1.4  2002/04/09 21:45:46  jrush
 * Renamed class 'tumbler' to 'Tumbler', for consistency with Python sources,
 * and changed typeisa from typedef to a subclass, in preparation for cleaning
 * up the type/class tree.
 *
 * Revision 1.3  2002/04/06 17:05:57  jrush
 * Switched from referring to 'task' for a client connection to 'session',
 * and converted the typetask typedef/struct into a Session C++ class.
 *
 * Revision 1.2  2002/02/14 09:27:43  jrush
 * Cleaned up source:
 *
 * 1. ran thru the indent tool to achieve a standard look,
 * 2. added structured comments at top for use with DOxygen reporting
 *    as well as CVS keywords,
 * 3. fixed compiler warnings re ambiguous assign/compares,
 *    needed casts and unused/uninitialized variables,
 * 4. fixed funcs that didn't specify a return type,
 * 5. centralized prototypes in protos.h, removing incomplete ones,
 * 6. cleaned up use of bool/BOOLEAN type to suit C++ type,
 * 7. fixed initializer nesting in tumbler constants,
 * 8. renamed vars that conflict with C++ keywords (new, this),
 * 9. fixed global/extern confusion re some global vars.
 *
 */

#include "udanax.h"

static void
analyzeanddebug(char *ptr)
{                                      /* ptr to thing with alloc header and * tag header */
#ifndef DISTRIBUTION
    tagtype tag;
    char *tagptr;
    HEADER *allocptr;

    allocptr = (HEADER *) ptr;
    tagptr = ptr + sizeof(HEADER);
    tag = *tagptr;
    ptr = tagptr + sizeof(tagtype);
/* fprintf(stderr,"\n size is %d ", ((HEADER *)allocptr)->s.size * sizeof(HEADER)); */
    if (tag == SESSTAG) {              /* undifferientated session alloced stuff */

    }                                  /* else if(tag & SESSTAG){ //tagged * session alloced stuff// switch(tag *
                                        * &~SESSTAG){ } } */
    else {
        switch (tag) {
        case INTTAG:
            fprintf(stderr, "int  in allocspace \n");
            break;

        case ITEMTAG:
            fprintf(stderr, "item  in allocspace \n");
            dumpitem((typeitem *) ptr);
            break;

        case CONTEXTTAG:
            fprintf(stderr, "context %x in allocspace \n", (int) ptr);
            dumpcontext((Context *) ptr);
            break;

        case CONTEXT2DTAG:
            fprintf(stderr, "context2d %x in allocspace \n", (int) ptr);
            break;

        case CRUMCONTEXTTAG:
            fprintf(stderr, "crumcontext  in allocspace \n");
            break;

        case CUCTAG:
            break;                     /* 
                                        * fprintf(stderr,"cuc in allocspace
                                        * "); dump(ptr); break; */

        case CBCTAG:
            break;                     /* 
                                        * fprintf(stderr,"cbc in allocspace
                                        * "); dump(ptr); break; */

        case SPANTAG:
            fprintf(stderr, "span  in allocspace \n");
            dumpspan((typespan *) ptr);
            break;

        case TUMBLERTAG:
            fprintf(stderr, "tumbler  in allocspace \n");
            dumptumbler((Tumbler *) ptr);
            break;

        case ISPANTAG:
            fprintf(stderr, "aspan  in allocspace \n");
            break;

        case VSPANTAG:
            fprintf(stderr, "vspan  in allocspace \n");
            break;

        case SPORGLTAG:
            fprintf(stderr, "sporgl  in allocspace \n");
            break;

        case LINKTAG:
            fprintf(stderr, "link  in allocspace \n");
            break;

        case VSPECTAG:
            fprintf(stderr, "vspec  in allocspace \n");
            break;

        case FREEDISKLOAFTAG:
            fprintf(stderr, "freediskloaf  in allocspace \n");
            break;

        default:
            fprintf(stderr, "randomunidentified thing  in allocspace \n");
            break;
        }
    }
#endif
}

void
lookatalloc2(HEADER * abaseallocated)
{                                      /* baseallocated is statics in alloc.d */
#ifndef DISTRIBUTION
    register HEADER *p;
    unsigned allocated = 0, unallocated = 0, maxunallocatedblock = 0;   /* in header units */

    p = abaseallocated->s.ptr;
    for (; p < abaseallocated->s.ptr + abaseallocated->s.size;) {
        if (!p->s.ptr) {               /* allocated */
            analyzeanddebug((char *) p);
            allocated += p->s.size;
        } else {                       /* unallocated */
            unallocated += p->s.size;
            maxunallocatedblock = max(p->s.size, maxunallocatedblock);
        }
/* step past current one */
        p = p + p->s.size;

    }
    fprintf(stderr, " allocated = %d unallocated = %d maxunallocatedblock = %d\n", allocated * sizeof(HEADER),
            unallocated * sizeof(HEADER), maxunallocatedblock * sizeof(HEADER));
#endif
}
