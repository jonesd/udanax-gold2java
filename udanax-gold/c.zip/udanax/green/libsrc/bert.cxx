/**********************************************************************
 * Copyright 2002 Jeff Rush <jrush@taupro.com>
 * Original Copyright 1979-2002 Udanax.com
 *
 * This file is part of the Udanax xanalogical storage system.
 *
 * Udanax is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * Udanax is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with Udanax; if not, write to the Free Software Foundation,
 * Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 **********************************************************************/

/**
 * @file  bert.cxx
 * @brief ???
 *
 * (to be defined)
 *
 **/

/* Modification History:
 * $Log: bert.cxx,v $
 * Revision 1.14  2002/07/26 04:30:29  jrush
 * Replaced gerror() with assert()
 *
 * Revision 1.13  2002/05/28 04:22:29  jrush
 * Adjusted source files to comply with GPL licensing.
 *
 * Revision 1.12  2002/05/28 02:49:42  jrush
 * Made static any functions and global variables private to this source file
 * and commented out any unused functions.
 *
 * Revision 1.11  2002/04/13 13:09:40  jrush
 * Convert typedef of struct into just struct, for C++ style.
 *
 * Revision 1.10  2002/04/12 11:56:42  jrush
 * Reorganized include file layout, renamed xanadu.h to udanax.h and
 * typecontext/typecrumcontext to C++ class Context/CrumContext.
 *
 * Revision 1.9  2002/04/10 18:01:54  jrush
 * Renamed class typeisa to IStreamAddr.
 *
 * Revision 1.8  2002/04/09 21:45:46  jrush
 * Renamed class 'tumbler' to 'Tumbler', for consistency with Python sources,
 * and changed typeisa from typedef to a subclass, in preparation for cleaning
 * up the type/class tree.
 *
 * Revision 1.7  2002/04/08 18:55:56  jrush
 * Switched from using global variable 'user' to object 'Session' as a
 * connection for tracking open document descriptors in the bert table.
 *
 * Revision 1.6  2002/04/07 14:02:28  jrush
 * Restored large tabular comments garbled during source indent operation.
 * Also added code in a few places to stuff meaningful errorcodes into the
 * Session structure upon API failure.
 *
 * Revision 1.5  2002/04/06 17:05:57  jrush
 * Switched from referring to 'task' for a client connection to 'session',
 * and converted the typetask typedef/struct into a Session C++ class.
 *
 * Revision 1.4  2002/04/06 15:01:17  jrush
 * Changed INT to just 'int'.
 *
 * Revision 1.3  2002/04/02 18:44:16  jrush
 * Redefined hashoftumbler() to be static, and then some cosmetic changes.
 *
 * Revision 1.2  2002/02/14 09:27:43  jrush
 * Cleaned up source:
 *
 * 1. ran thru the indent tool to achieve a standard look,
 * 2. added structured comments at top for use with DOxygen reporting
 *    as well as CVS keywords,
 * 3. fixed compiler warnings re ambiguous assign/compares,
 *    needed casts and unused/uninitialized variables,
 * 4. fixed funcs that didn't specify a return type,
 * 5. centralized prototypes in protos.h, removing incomplete ones,
 * 6. cleaned up use of bool/BOOLEAN type to suit C++ type,
 * 7. fixed initializer nesting in tumbler constants,
 * 8. renamed vars that conflict with C++ keywords (new, this),
 * 9. fixed global/extern confusion re some global vars.
 *
 */

#include "udanax.h"

struct bertentry {
    Session    *sess;       // Ptr to Session in which the document was opened
    Tumbler     documentid; // ID of document that was opened
    char        created;
    char        modified;
    int         type;
    int         count;
};

struct conscell {
    conscell   *next;
    bertentry  *stuff;
};

static const int primes[] = {
      3,   7,  11,  17,  37,  41,  59,  71,  97,  103,
    113, 131, 151, 137, 277, 421, 433, 567, 643,  743
};

#define NUMBEROFBERTTABLE 1327

static conscell *berttable[NUMBEROFBERTTABLE];

#ifndef DISTRIBUTION
//UNUSED static char *bertModeNames[] = { "BADMODE", "ONLY", "COPYIF", "COPY" };
static char *bertTypeNames[] = { "NOBERT", "READBERT", "WRITEBERT" };
//UNUSED char bertMsgBuf[256] = "";
#endif

static unsigned int
hashoftumbler(Tumbler *tp)
{
    unsigned int ret = tp->exp;

    for (int i = 0; i < NPLACES; i++)
        ret += (unsigned int) tp->mantissa[i] * primes[i];

    return ret % NUMBEROFBERTTABLE;
}

/*  checkforopen
 *	Returns:  >0 for sufficiently open
 *			integer indicates type of open
 *		  0 if open required
 *		 -1 if new version should be made
 *
 *	Open state -->
 *	type		    Not Open	#   Open READ	#  Open WRITE
 *	  |		!owned	| owned	#conn==	|conn!=	#conn==	|conn!=
 *	  v		--------+-------#-------+-------#-------+-------
 *	READ		   0	|   0	#  READ |   0   # WRITE | -1
 *	------------------------+-------#-------+-------#-------+-------
 *	WRITE		  -1	|   0	#  -1	|  -1	# WRITE | -1
 *	
 */
int
checkforopen(Session *sess, Tumbler *tp, int type)
{
    int foundnonread = false;

    if (type == NOBERTREQUIRED)
        return 1;                      /* Random > 0 */

    conscell *p;
    for (p = berttable[hashoftumbler(tp)]; p && p->stuff; p = p->next) {
        bertentry *bert = p->stuff;

        if (tumblereq(tp, &bert->documentid)) {
            if (sess == bert->sess) {
                switch (bert->type) {
                case READBERT:
                    return (type == READBERT) ? READBERT : /* WRITE */ -1;
                case WRITEBERT:
                    return WRITEBERT;
                }
            } else {
                if (bert->type != READBERT) {
                    foundnonread = true;
                }
            }
        }
    }

    if (!foundnonread && (type == READBERT || isthisusersdocument(sess, tp)))
        return 0;
    else
        return -1;
}

void
logbertmodifiedforcrum(Session *sess, typecuc *crumptr)
{
/* logbertmodified(xxx); */
}

void
logbertmodified(Session *sess, Tumbler *tp)
{
    /* fprintf(stderr,"logbertmodified sess= %d bert= ", (int) sess);dumptumbler(tp);fprintf(stderr,"\n"); */

    conscell *p;
    for (p = berttable[ hashoftumbler(tp) ]; p && p->stuff; p = p->next) {
        bertentry *bert = (bertentry *) p->stuff;
        if (bert->sess == sess && tumblereq(tp, &bert->documentid)) {
            bert->modified = true;
            return;
        }
    }
}

static void
incrementopen(Session *sess, Tumbler *tp)
{
#ifndef DISTRIBUTION
    fprintf(stderr, "incrementopen:  sess = %d  tp = ", (int) sess);
    dumptumbler(tp);
    fprintf(stderr, "\n");
#endif

    conscell *p;
    for (p = berttable[ hashoftumbler(tp) ]; p && p->stuff; p = p->next) {
        bertentry *bert = (bertentry *) p->stuff;
        if (bert->sess == sess && tumblereq(tp, &bert->documentid))
            bert->count += 1;
    }
}

static void
addtoopen(Session *sess, Tumbler *tp, int created, int type)
{
#ifndef DISTRIBUTION
    fprintf(stderr, "addtoopen:  sess = %d  type = %s  created = %d  tp = ", (int) sess, bertTypeNames[type], created);
    dumptumbler(tp);
    fprintf(stderr, "\n");
#endif

    int hash = hashoftumbler(tp);

/* these eallocwithtags changed to malloc by hill zzzz */

    bertentry *ptr;
    if ((ptr = (bertentry *) eallocwithtag(sizeof(bertentry), BERTTAG)) == NULL)
        assert(0); // out of memory

    tumblercopy(tp, &ptr->documentid);

    ptr->sess       = sess;
    ptr->count      = 1;
    ptr->created    = created;
    ptr->modified   = false;
    ptr->type       = type;

    conscell *consp;
    if ((consp = (conscell *) eallocwithtag(sizeof(conscell), BERTCONSCELLTAG)) == NULL)
        assert(0); // out of memory

    consp->stuff    = ptr;
    consp->next     = berttable[hash];
    berttable[hash] = consp;
}

static void
deleteversion(Tumbler *tp)
{
#ifndef DISTRIBUTION
    fprintf(stderr, "deleteversion: tp = ");
    dumptumbler(tp);
    fprintf(stderr, "\n");
#endif
}

static bool
removefromopen(Session *sess, Tumbler *tp)
{
#ifndef DISTRIBUTION
    fprintf(stderr, "removefromopen:  sess = %d  tp = ", (int) sess);
    dumptumbler(tp);
    fprintf(stderr, "\n");
#endif

    int hash = hashoftumbler(tp);
    conscell *oldptr = NULL;

    conscell *p;
    for (p = berttable[hash]; p && p->stuff; p = p->next) {
        bertentry *bert = p->stuff;
        if (bert->sess == sess && tumblereq(tp, &bert->documentid)) {
            if (--bert->count)
                return true;

            /* status = bert->modified && bert->created ; */
            int status = bert->created && !bert->modified;
            if (status)
                deleteversion(tp);

            efree((char *) p->stuff);

            conscell *temp;
            if (oldptr == NULL) {
                temp = berttable[hash];
                berttable[hash] = berttable[hash]->next;
                efree((char *)temp);
                return true;
            } else {
                temp = oldptr->next;
                oldptr->next = p->next;
                efree((char *)temp);
                return true;
            }
        }
        oldptr = p;
    }
    return false;
}

static void
exitbert(Session *sess)
{
#ifndef DISTRIBUTION
    fprintf(stderr, "exitbert:  sess = %d\n", (int) sess);
#endif

    conscell *oldptr = NULL;
    int i;
    for (i = 0; i < NUMBEROFBERTTABLE; i++) {
        conscell *p;
        for (p = berttable[i]; p && p->stuff; p = p->next) {
            bertentry *bert = p->stuff;
            if (bert->sess == sess) {
                int status = bert->modified && bert->created;
                if (status)
                    deleteversion(&bert->documentid);

                efree((char *)p->stuff);

                conscell *temp;
                if (oldptr == NULL) {
                    temp = berttable[i];
                    berttable[i] = berttable[i]->next;
                    efree((char *) temp);
                    return;
                } else {
                    temp = oldptr->next;
                    oldptr->next = p->next;
                    efree((char *) temp);
                    return;
                }
            }
            oldptr = p;
        }
    }
}

/*
 *	Open state -->
 *	type & mode	     Not Open	#   Open READ	#   Open WRITE
 *	  |		!owned	| owned	#conn==	|conn!=	#conn==	|conn!=
 *	  v		========+=======#=======+=======#=======+=======
 *		read	   0	|   0   #   0   |   0   #  -1   |   -1
 *	COPYIF	----------------+-------#-------+-------#-------+-------
 *		write	  -1    |   0   #  -1   |  -1   #  -1   |   -1
 *		================+=======#=======+=======#=======+=======
 *		read	   0    |   0   #   0   |   0   #   X   |    X
 *	ONLY	----------------+-------#-------+-------#-------+-------
 *		write	   X    |   0   #   X   |   X   #   X   |    X
 *		================+=======#=======+=======#=======+=======
 *		read	  -1    |  -1   #  -1   |  -1   #  -1   |   -1
 *	COPY	----------------+-------#-------+-------#-------+-------
 *		write	  -1    |  -1   #  -1   |  -1   #  -1   |   -1
 *
 */
bool
doopen(Session *sess, IStreamAddr *tp, IStreamAddr *newtp, int type, int mode)
{
    fprintf(stderr, "Entered doopen()\n");

    if (type == NOBERTREQUIRED)
        return true;

    fprintf(stderr, "type != NOBERTREQUIRED\n");

    if (mode == BERTMODECOPY) {
        fprintf(stderr, "mode == BERTMODECOPY, trying to copy document\n");

        if (docreatenewversion(sess, tp, &sess->account, newtp)) {
            addtoopen(sess, newtp, true, type);
            return true;
        } else {
            sess->errorcode = ERR_OPEN_COPY; // Attempt to make a copy to open failed
            return false;
        }
    }

    fprintf(stderr, "about to call checkforopen()\n");

    int openState = checkforopen(sess, tp, type);

    fprintf(stderr, "returned from call to checkforopen(), openState = %d\n", openState);

    if (openState == 0) {
        fprintf(stderr, "already open in R/O, just trying to inc open count\n");

        addtoopen(sess, tp, false, type);
        tumblercopy(tp, newtp);
        return true;
    }

    switch (mode) {
    case BERTMODECOPYIF:
        if (openState == -1) { // Document not already open
            if (docreatenewversion(sess, tp, &sess->account, newtp)) {
                addtoopen(sess, newtp, true, type);
            } else {
                sess->errorcode = ERR_OPEN_COPY; // Attempt to make a copy to open failed
                return false;
            }

        } else if (type != WRITEBERT && openState != WRITEBERT) { // Open another Shared Read-Open Reference
            incrementopen(sess, tp);
            tumblercopy(tp, newtp);

        } else { // Document is already open, Open a new copy
            docreatenewversion(sess, tp, &sess->account, newtp);
            addtoopen(sess, newtp, true, type);
        }
        return true;

    case BERTMODEONLY:
        if (openState == -1 || type == WRITEBERT || openState == WRITEBERT) {
            return false;
        } else {
            incrementopen(sess, tp);
            tumblercopy(tp, newtp);
            return true;
        }

    default:
        assert(0); // DEFAULT CASE IN DOOPEN
        return false;
    }
}

bool
doclose(Session *sess, IStreamAddr *tp)
{
#ifndef DISTRIBUTION
    fprintf(stderr, "doclose: sess = %d  tp = ", (int) sess);
    dumptumbler(tp);
    fprintf(stderr, "\n");
#endif

    if (!removefromopen(sess, tp)) {
        sess->errorcode = ERR_CLOSE_WO_OPEN; // Attempted close of a document that was never opened
        return false;
    }

    return true;                       /* for now, so as to not upset front-end */
}

void
dobertexit(Session *sess)
{
#ifndef DISTRIBUTION
    fprintf(stderr, "dobertexit: sess = %d\n", (int) sess);
#endif
    exitbert(sess);
}
