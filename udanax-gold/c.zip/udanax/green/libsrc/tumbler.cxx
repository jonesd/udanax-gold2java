/**********************************************************************
 * Copyright 2002 Jeff Rush <jrush@taupro.com>
 * Original Copyright 1979-2002 Udanax.com
 *
 * This file is part of the Udanax xanalogical storage system.
 *
 * Udanax is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * Udanax is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with Udanax; if not, write to the Free Software Foundation,
 * Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 **********************************************************************/

/**
 * @file  tumbler.cxx
 * @brief ???
 *
 * (to be defined)
 *
 **/

/* Modification History:
 * $Log: tumbler.cxx,v $
 * Revision 1.4  2002/05/28 04:22:29  jrush
 * Adjusted source files to comply with GPL licensing.
 *
 * Revision 1.3  2002/04/16 22:38:21  jrush
 * Added but then commented out new methods for tumblers acting as a C type.
 * Need to remove unions throughout system first, due to compiler errors.
 *
 * Revision 1.2  2002/04/12 11:56:43  jrush
 * Reorganized include file layout, renamed xanadu.h to udanax.h and
 * typecontext/typecrumcontext to C++ class Context/CrumContext.
 *
 * Revision 1.1  2002/04/10 17:46:43  jrush
 * Create a place to accumulate Tumbler class methods as we factor them out.
 *
 *
 */

#include <assert.h>
#include <memory.h>
#include "udanax.h"

//Tumbler::Tumbler(const Tumbler& other) // Copy Constructor
//{
//    printf("Tumbler::Tumbler(const Tumbler&) invoked\n");
//
//    memcpy(this, other, sizeof(*this));
//}

//Tumbler&
//Tumbler::operator=(const Tumbler& other)
//{
//    printf("Tumbler::operator=(const Tumbler&) invoked\n");
//    memcpy(this, other, sizeof(*this));
//
//    return *this;
//}

//Tumbler&
//Tumbler::operator=(int n)
//{
//    assert(n == 0);
//
//    printf("Tumbler::operator=(int) invoked\n");
//
//    memset(this, 0, sizeof(*this));
//}
