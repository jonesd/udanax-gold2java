/**********************************************************************
 * Copyright 2002 Jeff Rush <jrush@taupro.com>
 * Original Copyright 1979-2002 Udanax.com
 *
 * This file is part of the Udanax xanalogical storage system.
 *
 * Udanax is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * Udanax is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with Udanax; if not, write to the Free Software Foundation,
 * Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 **********************************************************************/

/**
 * @file  corediskin.cxx
 * @brief ???
 *
 * (to be defined)
 *
 **/

/* Modification History:
 * $Log: corediskin.cxx,v $
 * Revision 1.8  2002/07/26 04:30:29  jrush
 * Replaced gerror() with assert()
 *
 * Revision 1.7  2002/05/28 04:22:29  jrush
 * Adjusted source files to comply with GPL licensing.
 *
 * Revision 1.6  2002/05/28 02:49:42  jrush
 * Made static any functions and global variables private to this source file
 * and commented out any unused functions.
 *
 * Revision 1.5  2002/04/12 11:56:42  jrush
 * Reorganized include file layout, renamed xanadu.h to udanax.h and
 * typecontext/typecrumcontext to C++ class Context/CrumContext.
 *
 * Revision 1.4  2002/04/06 19:51:30  jrush
 * Renamed TRUE/FALSE constant use to the C++ standard of true/false.
 *
 * Revision 1.3  2002/04/06 15:01:17  jrush
 * Changed INT to just 'int'.
 *
 * Revision 1.2  2002/02/14 09:27:43  jrush
 * Cleaned up source:
 *
 * 1. ran thru the indent tool to achieve a standard look,
 * 2. added structured comments at top for use with DOxygen reporting
 *    as well as CVS keywords,
 * 3. fixed compiler warnings re ambiguous assign/compares,
 *    needed casts and unused/uninitialized variables,
 * 4. fixed funcs that didn't specify a return type,
 * 5. centralized prototypes in protos.h, removing incomplete ones,
 * 6. cleaned up use of bool/BOOLEAN type to suit C++ type,
 * 7. fixed initializer nesting in tumbler constants,
 * 8. renamed vars that conflict with C++ keywords (new, this),
 * 9. fixed global/extern confusion re some global vars.
 *
 */

#include <memory.h>
#include "udanax.h"

//extern bool isxumain;
static void hgetwiddsp(typecuc * ptr, char **loafptrptr);
static void varunpackloaf(int insidediskblocknumber, typediskloaf *uloafptr, typecuc *father);

/* Initialize thing from old enf.enf */
void
initkluge(typecuc **granfptr, typecuc **spanfptr)
{
    typecbc *tempcbc;

/* kluge up a bottum crum, use it to read in granf, similarly for spanf */
    tempcbc = (typecbc *) createcrum(0, GRAN);
    tempcbc->cinfo.infotype = GRANORGL;
    tempcbc->cinfo.granstuff.orglstuff.diskorglptr.diskblocknumber = GRANFDISKLOCATION;
    tempcbc->cinfo.granstuff.orglstuff.diskorglptr.insidediskblocknumber = 0 /* 1 */ ;
    inorgl(tempcbc);

    tempcbc->cinfo.granstuff.orglstuff.orglptr->leftbroorfather = NULL;
    *granfptr = tempcbc->cinfo.granstuff.orglstuff.orglptr;
    (*granfptr)->numberofsons = 0;     /* hack to make number of sons in granf be correct */

/* this is a hack to read in the spanf like an orgl! */
    tempcbc->cinfo.granstuff.orglstuff.diskorglptr.diskblocknumber = SPANFDISKLOCATION;
    tempcbc->cinfo.granstuff.orglstuff.diskorglptr.insidediskblocknumber = 0 /* 1 */ ;
    inorgl(tempcbc);

    tempcbc->cinfo.granstuff.orglstuff.orglptr->leftbroorfather = NULL;
    *spanfptr = tempcbc->cinfo.granstuff.orglstuff.orglptr;
    (*spanfptr)->numberofsons = 0;

    freecrum((typecorecrum *) tempcbc);
}

static typediskloaf *
lookinsideloaffor(int insidenumber, typediskloaf *uloafptr)
{
    return uloafptr;
}

static void
unpackloaf(int insidediskblocknumber, typediskloaf *uloafptr, typecuc *father)
{
    varunpackloaf(insidediskblocknumber, uloafptr, father);
}

/* #define hgetfromloaf(ip,lp) (*(ip)=intof(lp),fprintf(stderr,"hgetfromloaf gets
 * %d\n",*(ip)),(lp)=((char*)lp)+lengthof(lp)) */

static void
hgetinfo(typecbc *ptr, char **loafptrptr)
{                                      /* this assumes ptr crum is ok except * for info */
    unsigned int temp;

    if (!is2dcrum((typecorecrum *) ptr)) {
        hgetfromloaf(&ptr->cinfo.infotype, *loafptrptr);
/* dump(ptr); */
        if (ptr->cinfo.infotype == GRANTEXT) {
            ptr->cinfo.granstuff.textstuff.textlength = intof((humber) * loafptrptr);
            (*loafptrptr) += lengthof((humber) * loafptrptr);
            movmem((*loafptrptr), ptr->cinfo.granstuff.textstuff.textstring, ptr->cinfo.granstuff.textstuff.textlength);
            (*loafptrptr) += ptr->cinfo.granstuff.textstuff.textlength;
            return;
        } else if (ptr->cinfo.infotype == GRANORGL) {
            ptr->cinfo.granstuff.orglstuff.diskorglptr.diskblocknumber = intof((humber) * loafptrptr);

            /* if (temp == 0 || temp == -1) {
             *     fprintf(stderr, "bad diskblocknumber = %d \n", temp);
             *     assert(0); // boo in hgetinfo
             * }
             */

            (*loafptrptr) += lengthof((humber) * loafptrptr);
            ptr->cinfo.granstuff.orglstuff.diskorglptr.insidediskblocknumber = intof((humber) * loafptrptr);
            (*loafptrptr) += lengthof((humber) * loafptrptr);
            return;
        } else {
            return;
        }
    } else {
        if (ptr->height) {
/* looks like we got this all */
        } else {

            temp = tumblerptrtofixed((humber) * loafptrptr, &((type2dcbc *) ptr)->c2dinfo.homedoc);
            (*loafptrptr) += temp;
        }
    }
}

static void
varunpackloaf(int insidediskblocknumber, typediskloaf *uloafptr, typecuc *father)
{
    typediskloaf *xloafptr;
    typecuc *ptr;
    char *loafp;
    int numberofsonstoread;
    int height, enftype;
    int isapex, refcount;
    int size;

    if (!uloafptr || !father || father->height <= 0)
        assert(0); // bad varunpackloaf call

    xloafptr = lookinsideloaffor(insidediskblocknumber, uloafptr);
    loafp = (char *)xloafptr;
/* loafp += 3; */
    hgetfromloaf(&size, loafp);
    hgetfromloaf(&isapex, loafp);
/* fprintf(stderr,"isapex = %d\n",isapex); */
    if (isapex /*ISAPEX*/) {
#ifndef DISTRIBUTION
        dumphexstuff((char *) uloafptr);
        dumphexstuff((char *) xloafptr);
        assert(0); // attempt to read apex in varumpackloaf
#else
        assert(0);
#endif
    }
    hgetfromloaf(&height, loafp);

    if (height != father->height - 1) {
#ifndef DISTRIBUTION
        dump((typecorecrum *) father);
        dumphexstuff((char *) uloafptr);
        fprintf(stderr, "next thing = %d\n", intof((humber) loafp));
        fprintf(stderr, "father height = %d %d\n", father->height, height);
        assert(0); // height mismatch in varunpackloaf
#else
        assert(0);
#endif
    }
#ifdef glurg
    father->modified = false;
#endif                                 /* glurg */
    hgetfromloaf(&enftype, loafp);

    if (enftype != father->cenftype)
        assert(0); // enftype mismatch in varunpackloaf

    hgetfromloaf(&numberofsonstoread, loafp);
    hgetfromloaf(&refcount, loafp);
    father->numberofsons = 0;
    while (numberofsonstoread--) {
        ptr = (typecuc *) createcrum(height, enftype);
        adopt((typecorecrum *) ptr, RIGHTMOSTSON, (typecorecrum *) father);
        hgetwiddsp(ptr, &loafp);
        if (height != 0) {
            ptr->isapex = isapex;
            hgetfromloaf(&ptr->sonorigin.diskblocknumber, loafp);
            hgetfromloaf(&ptr->sonorigin.insidediskblocknumber, loafp);

            if (ptr->sonorigin.diskblocknumber == 0) {
#ifndef DISTRIBUTION
                dumphexstuff(loafp);
                dump((typecorecrum *) ptr);
                dumphexstuff((char *) uloafptr);
                assert(0); // trying to read 0 block
#else
                assert(0);
#endif
            }
            if (ptr->sonorigin.diskblocknumber == DISKPTRNULL) {
#ifndef DISTRIBUTION
                dump((typecorecrum *) ptr);
                assert(0); // trying to read DISKPTRNULL block
#else
                assert(0);
#endif
            }

        } else {
            ptr->isapex = false;
            hgetinfo((typecbc *) ptr, &loafp);
        }
        ptr->modified = false;
    }
}

void
inloaf(typecuc *father)
{
    if (father->height == 0)
        assert(0); // inloaf on bottom crum

    if (father->leftson)
        assert(0); // Its already got sons, and we aren't going to use pseudo-crums!

    typediskloaf loaf;
    readloaf(&loaf, father->sonorigin);
    unpackloaf(father->sonorigin.insidediskblocknumber, &loaf, father);
/* nchecknumofsons(father); */
}

void
inorglinternal(typecbc *granorglptr, typeuberrawdiskloaf *crumptr)
{
    unsigned int temp, temp2;

    typediskloaf loaf;
    readloaf(&loaf, granorglptr->cinfo.granstuff.orglstuff.diskorglptr);

    char *loafp = (char *)&loaf;

    int size;
    hgetfromloaf(&size, loafp);
    hgetfromloaf((int *) &temp, loafp);        /* isapex */
    hgetfromloaf((int *) &temp, loafp);
    hgetfromloaf((int *) &temp2, loafp);

    typecuc *ptr;
    if ( /* false&& */ crumptr) {
        ptr = (typecuc *) crumptr;     /* ECH I DON'T LIKE THIS!!! */
    } else {
        ptr = (typecuc *) createcrum((int) temp, (int) temp2);
    }

    ptr->cenftype   = temp2;
    ptr->isapex     = true;
    ptr->isleftmost = true;
    hgetfromloaf((int *) &temp, loafp);

    ptr->numberofsons = temp;
    hgetfromloaf((int *) &temp, loafp);
/* ptr->refcount = temp; */

    hgetwiddsp(ptr, &loafp);
    hgetfromloaf((int *) &temp, loafp);
    ptr->sonorigin.diskblocknumber = temp;

    if (ptr->sonorigin.diskblocknumber == 0) {
#ifndef DISTRIBUTION
        dump((typecorecrum *) ptr);
        assert(0); // trying to write 0 block
#else
        assert(0);
#endif
    }

    if (ptr->sonorigin.diskblocknumber == DISKPTRNULL) {
#ifndef DISTRIBUTION
        dump((typecorecrum *) ptr);
        assert(0); // trying to write DSKPTRNULL block
#else
        assert(0);
#endif
    }

    hgetfromloaf((int *) &temp, loafp);

    ptr->sonorigin.insidediskblocknumber = temp;
    ptr->modified                        = false;
    ptr->leftbroorfather                 = (typecorecrum *) granorglptr;

    granorglptr->cinfo.granstuff.orglstuff.orglptr    = (typecuc *) ptr;
    granorglptr->cinfo.granstuff.orglstuff.orglincore = true;
    rejuvinate((typecorecrum *) ptr);

/* checknumofsons(ptr); */
/* dump(ptr); */
}

void
inorgl(typecbc *granorglptr)
{
    inorglinternal(granorglptr, (typeuberrawdiskloaf *) NULL);
}

static void
hgetwiddsp(typecuc *ptr, char **loafptrptr)
{
    unsigned int temp;

    int nstreams = widsize(ptr->cenftype);
    typewid *wptr = &ptr->cdsp;

    int i;
    for (i = 0; i < nstreams; ++i) {
        temp = tumblerptrtofixed((humber) * loafptrptr, &wptr->dsas[i]);
        *loafptrptr += temp;
    }

    wptr = &ptr->cwid;
    for (i = 0; i < nstreams; ++i) {
        temp = tumblerptrtofixed((humber) * loafptrptr, &wptr->dsas[i]);
        *loafptrptr += temp;
    }
}

//    void
//finmoveinfo(typecbc *fromptr, typecbc *toptr)
//{
//    // moveinfo(fromptr,toptr); return;
//    // toptr->cinfo.infotype = fromptr->cinfo.infotype;
//    if (toptr->cinfo.infotype == GRANTEXT) {
//        //moveinfo(fromptr,toptr);
//        return;
//        //toptr->cinfo.granstuff.textstuff.textlength = fromptr->cinfo.granstuff.textstuff.textlength;
//        movmem(fromptr->cinfo.granstuff.textstuff.textstring, toptr->cinfo.granstuff.textstuff.textstring, toptr->cinfo.granstuff.textstuff.textlength);
//        return;
//    } else if (toptr->cinfo.infotype == GRANORGL) {
//        //moveinfo(fromptr,toptr);
//        return;
//        //toptr->cinfo.granstuff.orglstuff.diskorglptr.diskblocknumber = fromptr->cinfo.granstuff.orglstuff.diskorglptr.diskblocknumber;
//        toptr->cinfo.granstuff.orglstuff.diskorglptr.insidediskblocknumber = fromptr->cinfo.granstuff.orglstuff.diskorglptr.insidediskblocknumber;
//        return;
//    } else if (toptr->cinfo.infotype == GRANNULL) {
//        return;
//    } else {
//        fprintf(stderr, "in finmoveinfo bad case = %d\n", toptr->cinfo.infotype);
//        #ifndef DISTRIBUTION
//            assert(0); // in finmoveinfo bad case
//        #else
//            assert(0);
//        #endif
//        return;
//    }
//    //return;
//    moveinfo(fromptr, toptr);
//}

//    void
//finmove2dinfo(type2dcbc *fromptr, type2dcbc *toptr)
//{
//    if (fromptr->height == 0)
//        toptr->c2dinfo.homedoc = fromptr->c2dinfo.homedoc;
//    
//    return;
//    //move2dinfo(fromptr, toptr);
//}

