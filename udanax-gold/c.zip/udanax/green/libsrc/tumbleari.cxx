/**********************************************************************
 * Copyright 2002 Jeff Rush <jrush@taupro.com>
 * Original Copyright 1979-2002 Udanax.com
 *
 * This file is part of the Udanax xanalogical storage system.
 *
 * Udanax is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * Udanax is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with Udanax; if not, write to the Free Software Foundation,
 * Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 **********************************************************************/

/**
 * @file  tumbleari.cxx
 * @brief ???
 *
 * (to be defined)
 *
 **/

/* Modification History:
 * $Log: tumbleari.cxx,v $
 * Revision 1.8  2002/07/26 04:33:47  jrush
 * Replaced gerror() with assert()
 *
 * Revision 1.7  2002/05/28 04:22:29  jrush
 * Adjusted source files to comply with GPL licensing.
 *
 * Revision 1.6  2002/05/28 02:52:23  jrush
 * Made static any functions and global variables private to this source file
 * and commented out any unused functions.
 *
 * Revision 1.5  2002/04/12 11:56:43  jrush
 * Reorganized include file layout, renamed xanadu.h to udanax.h and
 * typecontext/typecrumcontext to C++ class Context/CrumContext.
 *
 * Revision 1.4  2002/04/09 21:45:46  jrush
 * Renamed class 'tumbler' to 'Tumbler', for consistency with Python sources,
 * and changed typeisa from typedef to a subclass, in preparation for cleaning
 * up the type/class tree.
 *
 * Revision 1.3  2002/04/06 15:01:17  jrush
 * Changed INT to just 'int'.
 *
 * Revision 1.2  2002/02/14 09:27:43  jrush
 * Cleaned up source:
 *
 * 1. ran thru the indent tool to achieve a standard look,
 * 2. added structured comments at top for use with DOxygen reporting
 *    as well as CVS keywords,
 * 3. fixed compiler warnings re ambiguous assign/compares,
 *    needed casts and unused/uninitialized variables,
 * 4. fixed funcs that didn't specify a return type,
 * 5. centralized prototypes in protos.h, removing incomplete ones,
 * 6. cleaned up use of bool/BOOLEAN type to suit C++ type,
 * 7. fixed initializer nesting in tumbler constants,
 * 8. renamed vars that conflict with C++ keywords (new, this),
 * 9. fixed global/extern confusion re some global vars.
 *
 */

#include <memory.h>
#include "udanax.h"

/* Various integers relating to humbers */
#define FIRSTCHAR  0x100
#define SECONDCHAR 0x10000
#define THIRDCHAR  0x1000000
#define FOURTHCHAR 0xffffffff

/* --------- Routines below set and change tumblers -------- */

#define mlengthoflength(x) (unsigned int)((*(x))<128?1:lengthoflength(x))
#define mexponentof(x) (humber)((x)+mlengthoflength(x))

static unsigned int
lengthoflength(humber ptr)
{                                      /* YUCK */
    int i;

    if (*ptr < 128)
        return 1;

    switch (*ptr) {
    case 128:                         /* break to ultraINT and specialcases */
        assert(0); // ultraINTs not defined yet
        return 12134;
    case 129:
        return 1 + lengthoflength(ptr + 1);
    case 130:
        return 3;
    case 131:
        return 4;
    case 132:
        return 5;
    case 133:
        return 6;
    default:
        fprintf(stderr, "case %d in lengthoflength close by bytes:\n\t", ptr[-1]);

        for (i = -6; i < 0; i++)
            fprintf(stderr, "%x ", ptr[i - 1]);
        fprintf(stderr, ": ");

        for (i = 0; i < 6; i++)
            fprintf(stderr, "%x ", ptr[i - 1]);
        fprintf(stderr, "\n");

        assert(0); // Bad lengthoflength
        return 1;
    }
}

unsigned int
functionlengthof(humber ptr)
{                                      /* length of humber or vartumbler */
    int i;

/* typedef union{char charlongchar[sizeof(int)];int charlonglong;} typecharlong; typecharlong temp; temp.charlonglong
 * = 0; */
    if (*ptr < 128)
        return 1;

    switch (*ptr++) {
    case 128:                         /* break to ultralong and specialcases */
        assert(0); // ultralongs not defined yet
        return 12134;

    case 129:                         /* negative */
        return 1 + lengthof(ptr + 1); /* is this right if we use 1 in the length of length */
    case 133:
        return 5;
    case 132:
        return 4;
    case 131:
        return 3;
    case 130:
        return 2;

    default:
        fprintf(stderr, "case %d in lengthof close by bytes:\n\t", ptr[-1]);
        for (i = -6; i < 0; i++)
            fprintf(stderr, "%x ", ptr[i - 1]);
        fprintf(stderr, ": ");

        for (i = 0; i < 6; i++)
            fprintf(stderr, "%x ", ptr[i - 1]);
        fprintf(stderr, "\n");

        assert(0); // Bad length in functionlengthof
        return 1;
    }
}

unsigned int
functionintof(humber h)
{
    int k;
    int i;

    if (((unsigned)h[0]) <= 127) {
        return h[0];

    } else {
        k = h[0] - 128;
        switch (k) {
        case 0:                       /* reserved for chge or wierd stuff */
            fprintf(stderr, "case %d in intof first 6 bytes: ", k);
            for (i = 0; i < 6; i++)
                fprintf(stderr, "%x ", h[i]);
            assert(0); // weird length 0 in intof
            break;
        case 2:
/* fprintf(stderr,"%x ",h[1]); */
            return (h[1]);
        case 3:
/* fprintf(stderr,"%x %x ",h[1],h[2]); */
            return ((h[1] << 8) + h[2]);
        case 4:
/* fprintf(stderr,"%x %x %x ",h[1],h[2],h[3]); */
            return ((((h[1] << 8) + h[2]) << 8) + h[3]);
        case 5:
/* fprintf(stderr,"%x %x %x %x ",h[1],h[2],h[3],h[4]); */
            k = (((((h[1] << 8) + h[2]) << 8) + h[3]) << 8) + h[4];
            if (k == -1)
                assert(0); // -1 in intof

            return k;

        default:
            fprintf(stderr, "case %d in intof close by bytes: ", k);
            for (i = -8; i < 0; i++)
                fprintf(stderr, "%x ", h[i]);
            fprintf(stderr, ": ");

            for (i = 0; i < 6; i++)
                fprintf(stderr, "%x ", h[i]);
            fprintf(stderr, "\n");

            for (i = -8; i < 0; i++)
                fprintf(stderr, "%d ", h[i]);
            fprintf(stderr, ": ");

            for (i = 0; i < 6; i++)
                fprintf(stderr, "%d ", h[i]);
            fprintf(stderr, "\n");

            assert(0); // in intof default case
            return 33333;
        }
    }
    return 0;                          /* for lint */
}

int
tumblerptrtofixed(humber p, Tumbler *tptr)
{
    tumblerclear(tptr);

    int temp = lengthoftumbler(p);

    humber tempexp = mexponentof(p);
    if (*tempexp <= 127)
        tptr->exp = -*tempexp;
    else
        tptr->exp = -functionintof(mexponentof(p));

    humber humberEnd = p + temp;

    humber mantissadigitptr;
    p += mlengthoflength(p);
    if (*(p) < 128)                  /* always the case */
        mantissadigitptr = p + 1;
    else
        mantissadigitptr = p + functionlengthof(p);

    int i;
    for (i = 0; i < NPLACES && mantissadigitptr < humberEnd; i++) {
        if (mantissadigitptr[0] <= 127) {       /* see intof */
            tptr->mantissa[i] = mantissadigitptr[0];
            mantissadigitptr += 1;
        } else {
            tptr->mantissa[i] = functionintof(mantissadigitptr);
            mantissadigitptr += functionlengthof(mantissadigitptr);
        }
    }

    return temp;
}

static unsigned int
calculatetotallength(unsigned int lengthofbody)
/* of tumbler ie adds length of exponent in length of body */
{
    if (lengthofbody < 127) {
        return (lengthofbody + 1);
    } else if (lengthofbody < FIRSTCHAR - 1) {
        return (lengthofbody + 2);
    } else if (lengthofbody < SECONDCHAR - 1 /* ? */ ) {
        return (lengthofbody + 3);
    } else if (lengthofbody < THIRDCHAR - 1) {
        return (lengthofbody + 4);
    } else if (lengthofbody < FOURTHCHAR /* - 1 */ ) {
        return (lengthofbody + 5);
    } else
        assert(0); // difficultly large length

    return 333333;
}

int
tumblerfixedtoptr(Tumbler *ptr, humber p)
{
    unsigned int lengthofexponent;
    unsigned int digitlength;
    unsigned int totallength;
    unsigned int lengthlength;
    unsigned int numberofsignificantdigits;

    if (ptr->sign)
        assert(0); // negative tumbler in tumblerfixedtoptr

    humber op = p;

/* dumptumbler(ptr); */

    unsigned int tumblerlength = 0;
    humberput(-ptr->exp, p, &lengthofexponent);

    p             += lengthofexponent;
    tumblerlength += lengthofexponent;

    numberofsignificantdigits = nstories(ptr);

    unsigned int i;
    for (i = 0; i < numberofsignificantdigits; i++) {
        humberput((int) ptr->mantissa[i], p, &digitlength);
        p += digitlength;
        tumblerlength += digitlength;
    }

    totallength  = calculatetotallength(tumblerlength);
    lengthlength = intlengthoflength(totallength);

    movmem(op, op + ptr->sign + lengthlength, tumblerlength);
    humberput((int) totallength, op + ptr->sign, &lengthlength);

    return totallength;
}

/* 
 * humberfree(ptr) humber ptr; { foofree(ptr); } */
/* humber vartumbleralloc(size) unsigned int size; { return(fooalloc(size)); } */
//UNUSED humber
//UNUSED fooalloc(unsigned int size)
//UNUSED {
//UNUSED     return (humber) eallocwithtag((unsigned) size, HUMBERTAG);
//UNUSED }

//UNUSED void
//UNUSED foofree(humber ptr)
//UNUSED {
//UNUSED     efree((char *)ptr);
//UNUSED }

humber
humberput(/* unsigned */ int i, humber humberfoo, unsigned int *lengthofhumberptr)
{
    if (i == -1)
        assert(0); // humberput of -1

    if (i < 0) {
        fprintf(stderr, "humberput of %d\n", i);
        assert(0); // humberput of negative number
    }

    if (i < 128) {
        *lengthofhumberptr = 1;
        *humberfoo         = i;

    } else {                           /* if(i<256*256*256*256) impossible for a 32 bit int */

/* NOTE zzz check to see that compiler does the 256*256 at compile time */
/* and fix these damn shifts sometime to be efficient */
        if (i < FIRSTCHAR) {
            *lengthofhumberptr = 2;
            *(humberfoo)       = 128 + 2;
            *(humberfoo + 1)   = i;

        } else if (i < SECONDCHAR) {
            *lengthofhumberptr = 3;
            *(humberfoo)       = 128 + 3;
            *(humberfoo + 1)   = i >> 8;
            *(humberfoo + 2)   = i & 0xff;

        } else if (i < THIRDCHAR) {
            *lengthofhumberptr = 4;
            *(humberfoo)       = 128 + 4;
            *(humberfoo + 1)   = i >> 16;
            *(humberfoo + 2)   = i >> 8 & 0xff;
            *(humberfoo + 3)   = i & 0xff;

        } else {
            *lengthofhumberptr = 5;
            *(humberfoo)       = 128 + 5;
            *(humberfoo + 1)   = i >> 24;
            *(humberfoo + 2)   = i >> 16 & 0xff;
            *(humberfoo + 3)   = i >> 8 & 0xff;
            *(humberfoo + 4)   = i & 0xff;
        }
    }

/* fprintf(stderr,"humberput puts %d\n",i); */
    return humberfoo;
}

humber
humber3put(/* unsigned */ int i, humber humberfoo, unsigned int *lengthofhumberptr)
{
    if (i == -1)
        assert(0); // humber3put of -1

    if (i < 0) {
        fprintf(stderr, "humberput of %d\n", i);
        assert(0); // humber3put of negative number
    }

    if (i < SECONDCHAR) {
        *lengthofhumberptr = 3;
        *(humberfoo)       = 128 + 3;
        *(humberfoo + 1)   = i >> 8;
        *(humberfoo + 2)   = i & 0xff;
    } else {
        fprintf(stderr, "in humber3put i = %d\n", i);
        assert(0); // humber3put called with too larg a value
    }

/* 
 * }else if (i<THIRDCHAR){ *lengthofhumberptr = 4; *(humberfoo ) = 128 +4;
 * *(humberfoo + 1) = i>>16 ; *(humberfoo + 2) = i>>8 &0xff; *(humberfoo + 3) 
 * = i & 0xff; }else { *lengthofhumberptr = 5; *(humberfoo ) = 128 +5;
 * *(humberfoo + 1) = i>>24 ; *(humberfoo + 2) = i>>16 &0xff; *(humberfoo +
 * 3) = i>>8 &0xff; *(humberfoo + 4) = i & 0xff; } } */
/* fprintf(stderr,"humberput puts %d\n",i); */

    return humberfoo;
}

unsigned int
intlengthoflength(unsigned int i)
{
    if      (i < 127)        return 1;
    else if (i < FIRSTCHAR)  return 2;
    else if (i < SECONDCHAR) return 3;
    else if (i < THIRDCHAR)  return 4;
    else if (i < FOURTHCHAR) return 5;

    assert(0); // impossible  in intlengthof
    return 0;
}

//UNUSED static humber
//UNUSED exponentof(humber /* vartumbler */ ptr)
//UNUSED {
//UNUSED     return ptr + mlengthoflength(ptr);
//UNUSED }

//UNUSED static unsigned int
//UNUSED lengthofexp(Tumbler *ptr)
//UNUSED {
//UNUSED     return lengthof(mexponentof(ptr->xvartumbler));   /* ZZZ ECH 8-26-88 */
//UNUSED }

//UNUSED humber
//UNUSED mantissaof(humber ptr)
//UNUSED {                                      /* returns a ptr to the first humber in the mantissa of the * vartumbler of the
//UNUSED                                         * tumbler */
//UNUSED     humber temp;
//UNUSED 
//UNUSED /* this is correct but expensive temp =ptr+lengthoflength(ptr)+lengthofexp(ptr); */
//UNUSED     ptr = ptr + mlengthoflength(ptr);  /* thus ptr points at expenent */
//UNUSED 
//UNUSED     if (*ptr < 128)
//UNUSED         temp = ptr + 1;
//UNUSED     else
//UNUSED         temp = ptr + lengthof(ptr);    /* and add the length of the exponent */
//UNUSED 
//UNUSED     return temp;
//UNUSED }
