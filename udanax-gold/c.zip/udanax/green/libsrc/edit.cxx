/**********************************************************************
 * Copyright 2002 Jeff Rush <jrush@taupro.com>
 * Original Copyright 1979-2002 Udanax.com
 *
 * This file is part of the Udanax xanalogical storage system.
 *
 * Udanax is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * Udanax is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with Udanax; if not, write to the Free Software Foundation,
 * Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 **********************************************************************/

/**
 * @file  edit.cxx
 * @brief crum rearrange and deletion routines
 *
 * (to be defined)
 *
 **/

/* Modification History:
 * $Log: edit.cxx,v $
 * Revision 1.9  2002/07/26 04:30:29  jrush
 * Replaced gerror() with assert()
 *
 * Revision 1.8  2002/05/28 04:22:29  jrush
 * Adjusted source files to comply with GPL licensing.
 *
 * Revision 1.7  2002/05/28 02:49:42  jrush
 * Made static any functions and global variables private to this source file
 * and commented out any unused functions.
 *
 * Revision 1.6  2002/04/12 11:56:43  jrush
 * Reorganized include file layout, renamed xanadu.h to udanax.h and
 * typecontext/typecrumcontext to C++ class Context/CrumContext.
 *
 * Revision 1.5  2002/04/09 21:45:46  jrush
 * Renamed class 'tumbler' to 'Tumbler', for consistency with Python sources,
 * and changed typeisa from typedef to a subclass, in preparation for cleaning
 * up the type/class tree.
 *
 * Revision 1.4  2002/04/06 19:51:30  jrush
 * Renamed TRUE/FALSE constant use to the C++ standard of true/false.
 *
 * Revision 1.3  2002/04/06 15:01:17  jrush
 * Changed INT to just 'int'.
 *
 * Revision 1.2  2002/02/14 09:27:43  jrush
 * Cleaned up source:
 *
 * 1. ran thru the indent tool to achieve a standard look,
 * 2. added structured comments at top for use with DOxygen reporting
 *    as well as CVS keywords,
 * 3. fixed compiler warnings re ambiguous assign/compares,
 *    needed casts and unused/uninitialized variables,
 * 4. fixed funcs that didn't specify a return type,
 * 5. centralized prototypes in protos.h, removing incomplete ones,
 * 6. cleaned up use of bool/BOOLEAN type to suit C++ type,
 * 7. fixed initializer nesting in tumbler constants,
 * 8. renamed vars that conflict with C++ keywords (new, this),
 * 9. fixed global/extern confusion re some global vars.
 *
 */

#include <string.h>
#include "udanax.h"

/* use with GRAN */
//UNUSED static void // UNUSED
//UNUSED deleteseq(typecuc *fullcrumptr, Tumbler *address, int index)
//UNUSED {
//UNUSED     CrumContext *context;
//UNUSED     typecbc *ptr;
//UNUSED 
//UNUSED     context = retrievecrums(fullcrumptr, address, index);
//UNUSED     ptr = (typecbc *) context->corecrum;
//UNUSED     freecrum((typecorecrum *) & context->corecrum);
//UNUSED     crumcontextfree(context);
//UNUSED     setwispupwards(findfather((typecorecrum *) ptr), 1);
//UNUSED     recombine(findfather((typecorecrum *) ptr));
//UNUSED }

static int
deletecutsectionnd(typecorecrum *ptr, typewid *offset, typeknives *knives)
{
    int i, cmp;

    for (i = knives->nblades - 1; i >= 0; --i) {        /* unique to delete */
        cmp = whereoncrum(ptr, offset, &knives->blades[i], knives->dimension);
        if (cmp == THRUME) {
            return (-1);
        } else if (cmp <= ONMYLEFTBORDER) {     /* compare last to first */
            return (i + 1);
        }
    }
    return (0);
}

/* use with SPAN and POOM */
void
deletend(typecuc *fullcrumptr, Tumbler *origin, Tumbler *width, int index)
{
    typeknives knives;
    typewid offset, grasp, reach;
    typecuc *father, *ptr, *next;
    typewid foffset, fgrasp;

    clear(&offset, sizeof(offset));    /* fullcrum alway has zero offset */
    prologuend((typecorecrum *) fullcrumptr, &offset, &grasp, &reach);
    movetumbler(origin, &knives.blades[0]);
    tumbleradd(origin, width, &knives.blades[1]);
    knives.nblades = 2;
    knives.dimension = index;
    makecutsnd(fullcrumptr, &knives);
    newfindintersectionnd(fullcrumptr, &knives, &father, &foffset);
    prologuend((typecorecrum *) father, &foffset, &fgrasp, (typedsp *) NULL);
    for (ptr = (typecuc *) findleftson(father); ptr; ptr = next) {
        next = (typecuc *) findrightbro((typecorecrum *) ptr);
        switch (deletecutsectionnd((typecorecrum *) ptr, &fgrasp, &knives)) {
        case -1:
            assert(0); // deletend can't classify crum
        case 0:
            break;
        case 1:
            disown((typecorecrum *) ptr);
            subtreefree((typecorecrum *) ptr);
            break;
        case 2:
            tumblersub(&ptr->cdsp.dsas[index], width, &ptr->cdsp.dsas[index]);
/* This will get set to modified in setwisp */
            break;
        default:
            assert(0); // unexpected cutsection
        }
    }
    setwispupwards(father, 1);
    recombine(father);
}

/* Prepares offsets for both 3 and 4 cut rearranges */

static void
makeoffsetsfor3or4cuts(typeknives *knives, Tumbler diff[])
{
    Tumbler a, b;

/* diff[0] is simply ignored */
    if (knives->nblades == 4) {
        tumblersub(&knives->blades[2], &knives->blades[0], &(diff[1]));
        tumblersub(&knives->blades[1], &knives->blades[0], &a);
        tumblersub(&knives->blades[3], &knives->blades[2], &b);
        tumblersub(&b, &a, &(diff[2]));
/* tumblersub (&knives->blades[0], &knives->blades[2], &(diff[3])); *//* should be <0 */
        movetumbler(&diff[1], &diff[3]);
        diff[3].sign = !diff[1].sign;
    } else if (knives->nblades == 3) {
        tumblersub(&knives->blades[2], &knives->blades[1], &diff[1]);
        tumblersub(&knives->blades[1], &knives->blades[0], &diff[2]);   /* should be negative */
        diff[2].sign = !diff[2].sign;
        tumblerclear(&(diff[3]));
    } else
        assert(0); // Wrong number of cuts
}

/* Returns which between-cut slice the crum is in. Does this ** by finding the first cut to the right of the crum **
 * Each editting routine requires a slightly different version of ** this function. */
static int
rearrangecutsectionnd(typecorecrum *ptr, typewid *offset, typeknives *knives)
{
    int i, cmp;

    for (i = knives->nblades - 1; i >= 0; --i) {
        cmp = whereoncrum(ptr, offset, &knives->blades[i], knives->dimension);
        if (cmp == THRUME) {
            return -1;
        } else if (cmp <= ONMYLEFTBORDER) {
            return i + 1;
        }
    }
    return 0;
}

static void
sortknives(typeknives *knifeptr)
{
    Tumbler temp;
    int i;

    for (i = 0; i < knifeptr->nblades - 1; ++i) {
        if (tumblercmp(&knifeptr->blades[i], &knifeptr->blades[i + 1]) == GREATER) {
            movetumbler(&knifeptr->blades[i + 1], &temp);
            movetumbler(&knifeptr->blades[i], &knifeptr->blades[i + 1]);
            movetumbler(&temp, &knifeptr->blades[i]);
            --i;
        }
    }
}

void
rearrangend(typecuc *fullcrumptr, typecutseq *cutseqptr, int index)
{
    typecuc *father, *ptr;
    typewid foffset, fgrasp;
    typeknives knives;
    Tumbler diff[4];
    int i;

#ifdef UNdeFined
    fprintf(stderr, "entering rearrangend\n");
     /**/ fixincoresubtreewids(fullcrumptr);    /* 1999 // a temp kluge zzz till we find where setwisp * isnt called// 
 *//* this is a brute  force kluge, if this fixes anything it means that the wids aren't being set properly somplace else probably near here */
    fprintf(stderr, "in rearrangend \n");
    switch (fullcrumptr->cenftype) {
    case POOM:
        fprintf(stderr, "in rearrangend  dumppoomwisps\n");
        dumppoomwisps(fullcrumptr);
        break;
    case SPAN:
        fprintf(stderr, "in rearrangend  showspanf\n");
        showspanf(fullcrumptr);
        break;
    }
#endif
/* displaycutspm(cutseqptr); */
    knives.dimension = index;
    knives.nblades = cutseqptr->numberofcuts;
    for (i = 0; i < knives.nblades; i++) {
        movetumbler(&cutseqptr->cutsarray[i], &knives.blades[i]);
    }
    sortknives(&knives);
    makeoffsetsfor3or4cuts(&knives, diff);
/* for(i=1;i<=knives.nblades;i++){fprintf(stderr,"\noffset for cut %d = ",i);dumptumbler(&diff[i]);} */
    makecutsnd(fullcrumptr, &knives);
    newfindintersectionnd(fullcrumptr, &knives, &father, &foffset);
    prologuend((typecorecrum *) father, &foffset, &fgrasp, (typedsp *) NULL);
    for (ptr = (typecuc *) findleftson(father); ptr; ptr = (typecuc *) findrightbro((typecorecrum *) ptr)) {
        i = rearrangecutsectionnd((typecorecrum *) ptr, &fgrasp, &knives);
        switch (i) {
        case -1:
            assert(0); // rearrangend can't classify crum
        case 0:
        case 4:                       /* these never move */
            break;
        case 1:
        case 2:
        case 3:                       /* 3 only moves in 4 cuts */
            tumbleradd(&ptr->cdsp.dsas[index], &diff[i], &ptr->cdsp.dsas[index]);
/* fprintf(stderr,"\nptr = %x i = %d ",ptr,i); dump(ptr); */
            ivemodified((typecorecrum *) ptr);
            break;
        default:
            assert(0); // unexpected cutsection
        }
    }
    setwispupwards(father, 1);         /* should do nothing, */
/* but, just on general principles.. */
    recombine(fullcrumptr);

    (void)splitcrumupwards(fullcrumptr);        /* can we move this before recombine ? */
#ifdef UnDEfINed
    fprintf(stderr, "leaving rearrangend\n");

     /**/ fixincoresubtreewids(fullcrumptr);    /* 1999 // a temp kluge zzz till we find where setwisp * isnt called// 
 *//* this is a brute  force kluge, if this fixes anything it means that the wids aren't being set properly somplace else probably near here */
    fprintf(stderr, "in rearrangend \n");
    switch (fullcrumptr->cenftype) {
    case POOM:
        fprintf(stderr, "in rearrangend  dumppoomwisps\n");
        dumppoomwisps(fullcrumptr);
        break;
    case SPAN:
        fprintf(stderr, "in rearrangend  showspanf\n");
        showspanf(fullcrumptr);
        break;
    }
#endif

}

int
insertcutsectionnd(typecorecrum *ptr, typewid *offset, typeknives *knives)
{
    int i, cmp; /* hacked from delete */

/* for (i = knives->nblades-1; i >= 0; --i){ */
    if (knives->nblades == 2) {
        i = 1;
        cmp = whereoncrum(ptr, offset, &knives->blades[i], knives->dimension);
        if ( /* false&& */ cmp == THRUME) {
            dumpwid((typewid *) &ptr->cwid.dsas[i], ptr->cenftype);
            return -1;
        } else if (cmp <= ONMYLEFTBORDER) {     /* compare last to first */
            return 2;
        }
    }

    i = 0;

    cmp = whereoncrum(ptr, offset, &knives->blades[i], knives->dimension);
    if (cmp == THRUME) {
        dumpwid((typewid *) &ptr->cwid.dsas[i], ptr->cenftype);
        return -1;
    } else if (cmp <= ONMYLEFTBORDER) { /* compare last to first */
        return 1;
    }

/* } */
    return 0;
}
