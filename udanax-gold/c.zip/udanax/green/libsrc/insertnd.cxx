/**********************************************************************
 * Copyright 2002 Jeff Rush <jrush@taupro.com>
 * Original Copyright 1979-2002 Udanax.com
 *
 * This file is part of the Udanax xanalogical storage system.
 *
 * Udanax is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * Udanax is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with Udanax; if not, write to the Free Software Foundation,
 * Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 **********************************************************************/

/**
 * @file  insertnd.cxx
 * @brief ???
 *
 * (to be defined)
 *
 **/

/* Modification History:
 * $Log: insertnd.cxx,v $
 * Revision 1.10  2002/07/26 04:32:01  jrush
 * Replaced gerror() with assert()
 *
 * Revision 1.9  2002/05/28 04:22:29  jrush
 * Adjusted source files to comply with GPL licensing.
 *
 * Revision 1.8  2002/05/28 02:51:11  jrush
 * Made static any functions and global variables private to this source file
 * and commented out any unused functions.
 *
 * Revision 1.7  2002/04/12 11:56:43  jrush
 * Reorganized include file layout, renamed xanadu.h to udanax.h and
 * typecontext/typecrumcontext to C++ class Context/CrumContext.
 *
 * Revision 1.6  2002/04/09 21:45:46  jrush
 * Renamed class 'tumbler' to 'Tumbler', for consistency with Python sources,
 * and changed typeisa from typedef to a subclass, in preparation for cleaning
 * up the type/class tree.
 *
 * Revision 1.5  2002/04/06 19:51:30  jrush
 * Renamed TRUE/FALSE constant use to the C++ standard of true/false.
 *
 * Revision 1.4  2002/04/06 17:05:57  jrush
 * Switched from referring to 'task' for a client connection to 'session',
 * and converted the typetask typedef/struct into a Session C++ class.
 *
 * Revision 1.3  2002/04/06 15:01:17  jrush
 * Changed INT to just 'int'.
 *
 * Revision 1.2  2002/02/14 09:27:43  jrush
 * Cleaned up source:
 *
 * 1. ran thru the indent tool to achieve a standard look,
 * 2. added structured comments at top for use with DOxygen reporting
 *    as well as CVS keywords,
 * 3. fixed compiler warnings re ambiguous assign/compares,
 *    needed casts and unused/uninitialized variables,
 * 4. fixed funcs that didn't specify a return type,
 * 5. centralized prototypes in protos.h, removing incomplete ones,
 * 6. cleaned up use of bool/BOOLEAN type to suit C++ type,
 * 7. fixed initializer nesting in tumbler constants,
 * 8. renamed vars that conflict with C++ keywords (new, this),
 * 9. fixed global/extern confusion re some global vars.
 *
 */

#include <memory.h>
#include "udanax.h"

/* use with SPAN and POOM */

static int
widdiffs(typecuc *crumptr)
{
    if (crumptr->cenftype != POOM)
        return 0;

    int i = lastdigitintumbler(&crumptr->cwid.dsas[I]);
    int v = lastdigitintumbler(&crumptr->cwid.dsas[V]);
    return i - v;
}

static void
findaddressofsecondcutforinsert(Tumbler *position, Tumbler *secondcut)
{                                      /* needs this to give it a place to find intersectionof for text is 2.1 */
    Tumbler zero, intpart;

    tumblerclear(&zero);
    tumblerincrement(position, -1, 1, secondcut);
    beheadtumbler(position, &intpart);
    tumblerincrement(secondcut, 0, -tumblerintdiff(&intpart, &zero), secondcut);
    tumblerincrement(secondcut, 1, 1, secondcut);
}

static void
makegappm(Session *sess, typecuc *fullcrumptr, typewid *origin, typewid *width)
{
    typeknives knives;
    typewid offset, grasp, reach;
    typecuc *father;
    typecorecrum *ptr;
    typewid foffset, fgrasp;
    int i /* ,enfheight */ ;

#ifndef DISTRIBUTION
    foo("makegappm\n");
    checkwholesubtree(fullcrumptr);
#endif

/* enfheight = fullcrumptr->height; */
    clear(&offset, sizeof(offset));    /* fullcrum alway has zero offset */
    prologuend((typecorecrum *) fullcrumptr, &offset, &grasp, &reach);
    if (iszerotumbler(&fullcrumptr->cwid.dsas[V])
        || tumblercmp(&origin->dsas[V], &grasp.dsas[V]) == LESS || tumblercmp(&origin->dsas[V], &reach.dsas[V]) != LESS)
        return;                        /* this if for extensions to bc without calling cut */

    movetumbler(&origin->dsas[V], &knives.blades[0]);
    findaddressofsecondcutforinsert(&origin->dsas[V], &knives.blades[1]);
    knives.nblades = /* 1 */ 2;
    knives.dimension = V;

    makecutsnd(fullcrumptr, &knives);
    newfindintersectionnd(fullcrumptr, &knives, &father, &foffset);
    prologuend((typecorecrum *) father, &foffset, &fgrasp, (typedsp *) NULL);

    for (ptr = findleftson(father); ptr; ptr = findrightbro(ptr)) {
        i = insertcutsectionnd(ptr, &fgrasp, &knives);
        switch (i) {
        case 0:
        case 2:
            break;
        case -1:                      /* THRUME */
            dump(ptr);
            assert(0); // makegappm can't classify crum
            break;
        case 1:                       /* 9-17-87 fix */
            tumbleradd(&ptr->cdsp.dsas[V], &width->dsas[V], &ptr->cdsp.dsas[V]);
/* tumbleradd(&width->dsas[V],&ptr->cdsp.dsas[V],&ptr->cdsp.dsas[V]); */
            ivemodified(ptr);
            break;
        default:
            assert(0); // unexpected cutsection
        }
    }
    setwidnd(father);
    setwispupwards(findfather((typecorecrum *) father), 1);
}

static void
firstinsertionnd(typecuc *father, typewid *origin, typewid *width, type2dbottomcruminfo *infoptr)
{
    typecorecrum *ptr = findleftson(father);
    movewisp(origin, &ptr->cdsp);
    movewisp(width, &ptr->cwid);
    move2dinfo(infoptr, &((type2dcbc *) ptr)->c2dinfo);
    ivemodified(ptr);
    setwisp((typecorecrum *) father);
}

static bool
isanextensionnd(typecbc *ptr, typedsp *offsetptr, typedsp *originptr, type2dbottomcruminfo *infoptr)
{
    if (!tumblereq(&infoptr->homedoc, &((type2dcbc *) ptr)->c2dinfo.homedoc))
        return false;

    typedsp grasp, reach;
    prologuend((typecorecrum *) ptr, offsetptr, &grasp, &reach);
    return lockeq(reach.dsas, originptr->dsas, (unsigned) dspsize(ptr->cenftype));
}

static int
insertcbcnd(typecuc *father, typedsp *grasp, typewid *origin, typewid *width, type2dbottomcruminfo *infoptr)
{
    typecorecrum *ptr, *newcc;
    bool splitsomething;

    for (ptr = findleftson(father); ptr; ptr = findrightbro(ptr)) {
        if (isanextensionnd((typecbc *) ptr, grasp, origin, infoptr)) {
            dspadd(&ptr->cwid, width, &ptr->cwid, (int) father->cenftype);
            ivemodified(ptr);
            setwispupwards(father, 1);

            if (!isfullcrum((typecorecrum *) father))
                return setwispupwards(findfather((typecorecrum *) father), 1);        /* was ...),1); ECH *** */

            return false;
        }
    }

    newcc = createcrum(0, (int) father->cenftype);
    reserve(newcc);
    adopt(newcc, SON, (typecorecrum *) father);
    dspsub(origin, grasp, &newcc->cdsp, (int) father->cenftype);

    if (iszerolock((Tumbler *) width, 2))
        assert(0); // zero width in insertnd

    movewisp(width, &newcc->cwid);
    move2dinfo(infoptr, &((type2dcbc *) newcc)->c2dinfo);
    ivemodified(newcc);
/* setwispallthewayupwards (newcc//father//); */
    setwispupwards((typecuc *) newcc /* father */ , 0);
    setwispupwards(father, 1);
    splitsomething = splitcrumupwards(father);
    rejuvinate(newcc);

    return splitsomething;
}

static typecorecrum *
findsontoinsertundernd(typecuc *father, typedsp *grasp, typewid *origin, typewid *width, int index)
{
    typecorecrum *ptr, *nearestonleft;
    Tumbler spanend, sonstart;

    if (iszerotumbler(&width->dsas[index]))
        assert(0); // width is zero in findsontoinsertundernd

    tumbleradd(&origin->dsas[index], &width->dsas[index], &spanend);

    ptr = nearestonleft = findleftson(father);

    for (; ptr; ptr = findrightbro(ptr)) {
        tumbleradd(&grasp->dsas[index], &ptr->cdsp.dsas[index], &sonstart);
        if (tumblercmp(&sonstart, &origin->dsas[index]) != GREATER
            && tumblercmp(&ptr->cdsp.dsas[index], &nearestonleft->cdsp.dsas[index]) != LESS) {
            nearestonleft = ptr;
        }

        if (whereoncrum(ptr, grasp, &origin->dsas[index], index) >= ONMYLEFTBORDER
            && whereoncrum(ptr, grasp, &spanend, index) <= ONMYRIGHTBORDER)
            return ptr;
    }
    return nearestonleft;
}

static int
insertmorend(typecuc *father, typedsp *offset, typewid *origin, typewid *width, type2dbottomcruminfo *infoptr, int index)
{
    typedsp grasp;

    if (iszerotumbler(&width->dsas[index]))
        assert(0); // zero width in insertmorend

    makeroomonleftnd(father, offset, origin, &grasp);
    if (father->height == 1)
        return insertcbcnd(father, &grasp, origin, width, infoptr);

    typecorecrum *ptr = findsontoinsertundernd(father, &grasp, origin, width, index);
    int temp = insertmorend((typecuc *) ptr, &grasp, origin, width, infoptr, index);

/* setwispupwards(ptr,1); *//* was done in insertcbcnd */
    setwispupwards(father, 1);

    ivemodified(ptr);                  /* zzz possibly redundant with setwispupwards */
    return temp;
}

static int
doinsertnd(typecuc *father, typewid *origin, typewid *width, type2dbottomcruminfo *infoptr, int index)
{
    typedsp offset;

    if (iszerotumbler(&width->dsas[index]))
        assert(0); // zero width in doinsertnd

    if (isemptyenfilade(father)) {
        firstinsertionnd(father, origin, width, infoptr);
        return false;
    }
    clear(&offset, sizeof(typedsp));
    return insertmorend(father, &offset, origin, width, infoptr, index);
}

void
insertnd(Session *sess, typecuc *fullcrumptr, typewid *origin, typewid *width, type2dbottomcruminfo *infoptr, int index)
/* origin is vsa fo crum *//* note that here they're wids, */
/* and in deletend they're single tumblers */
{
    int bothertorecombine = 0;
    int oldheight;
    int olddiff, newdiff;
    Tumbler oldwid;

#ifdef UndEfInEd
    foo("insertnd\n");
    if ((nsessorcommand % 100) == 0) { /* do only 1/n of the time */
        fprintf(stderr, "entering insertnd\n");
        asserttreeisok(fullcrumptr);
    }
#endif

#ifdef UNdeFINed
     /**/ fixincoresubtreewids(fullcrumptr);    /* 1999 // a temp kluge zzz till we find where setwisp * isnt called// 
 *//* this is a brute  force kluge, if this fixes anything it means that the wids aren't being set properly somplace else probably near here */
    fprintf(stderr, "entering insertnd \n");
    switch (fullcrumptr->cenftype) {
    case POOM:
        fprintf(stderr, "in insertnd  dumppoomwisps\n");
        dumppoomwisps(fullcrumptr);
        break;
    case SPAN:
        fprintf(stderr, "in insertnd  showspanf\n");
        showspanf(fullcrumptr);
        break;
    }
#endif

    olddiff = widdiffs(fullcrumptr);
    oldheight = fullcrumptr->height;
    if (iszerotumbler(&width->dsas[index]))
        assert(0); // zero width in insertnd
    tumblercopy(&fullcrumptr->cwid.dsas[V], &oldwid);
    switch (fullcrumptr->cenftype) {

    case POOM:
        makegappm(sess, fullcrumptr, origin, width);
        checkspecandstringbefore();
        setwispupwards(fullcrumptr, 0);
        bothertorecombine = doinsertnd(fullcrumptr, origin, width, infoptr, index);
        setwispupwards(fullcrumptr, 1);
/* fixincoresubtreewids(fullcrumptr);//1999 // a temp kluge zzz till we find where setwisp isnt called// this is a
 * brute force kluge, if this fixes anything it means that the wids aren't being set properly somplace else probably
 * near here */

        break;
    case SPAN:
        bothertorecombine = doinsertnd(fullcrumptr, origin, width, infoptr, index);
        setwispupwards(fullcrumptr, 1);
/* fixincoresubtreewids(fullcrumptr);//1999 // a temp kluge zzz till we find where setwisp isnt called// this is a
 * brute force kluge, if this fixes anything it means that the wids aren't being set properly somplace else probably
 * near here */
        break;
    default:
        assert(0); // insertnd: bad enftype
    }
    if ( /* true|| */ bothertorecombine || (fullcrumptr->height != oldheight)) {
#ifndef DISTRIBUTION
        if (!bothertorecombine) {
            fprintf(stderr, "insertnd recombineing and notbothertorecombine\n");
        }
#endif
        recombine(fullcrumptr);
    }
    newdiff = widdiffs(fullcrumptr);
#ifndef DISTRIBUTION
    if (false && (fullcrumptr->cenftype == POOM) && olddiff != newdiff) {
        fprintf(stderr, "insertnd  possible error dumping widdiffs%d %d\n\r", olddiff, newdiff);
        dump /* wholesubtree */ ((typecorecrum *) fullcrumptr);
        fprintf(stderr, "insertnd not match after insert asserting \n");
        asserttreeisok((typecorecrum *) fullcrumptr);
    }
#endif
#ifndef DISTRIBUTION
    if (false && fullcrumptr->cenftype == POOM && tumblereq(&oldwid, &fullcrumptr->cwid.dsas[V])) {     /* remember
                                                                                                         * links this
                                                                                                         * code doesnt
                                                                                                         * work */
        fprintf(stderr, "insertnd no change after insert\n");
        dumptumbler(&oldwid);
        dumpwholesubtree(fullcrumptr);
        assert(0); // insertnd no change after insert
    }
#endif

#ifdef UNdeFIned
     /**/ fixincoresubtreewids(fullcrumptr);    /* 1999 // a temp kluge zzz till we find where setwisp * isnt called// 
 *//* this is a brute  force kluge, if this fixes anything it means that the wids aren't being set properly somplace else probably near here */
    fprintf(stderr, "leaving insertnd \n");
    switch (fullcrumptr->cenftype) {
    case POOM:
        fprintf(stderr, "in insertnd  dumppoomwisps\n");
        dumppoomwisps(fullcrumptr);
        break;
    case SPAN:
        fprintf(stderr, "in insertnd  showspanf\n");
        showspanf(fullcrumptr);
        break;
    }
#endif
}
