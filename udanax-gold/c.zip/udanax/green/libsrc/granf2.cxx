/**********************************************************************
 * Copyright 2002 Jeff Rush <jrush@taupro.com>
 * Original Copyright 1979-2002 Udanax.com
 *
 * This file is part of the Udanax xanalogical storage system.
 *
 * Udanax is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * Udanax is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with Udanax; if not, write to the Free Software Foundation,
 * Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 **********************************************************************/

/**
 * @file  granf2.cxx
 * @brief granfilade interface routines
 *
 * (to be defined)
 *
 **/

/* Modification History:
 * $Log: granf2.cxx,v $
 * Revision 1.12  2002/07/26 04:32:01  jrush
 * Replaced gerror() with assert()
 *
 * Revision 1.11  2002/05/28 04:22:29  jrush
 * Adjusted source files to comply with GPL licensing.
 *
 * Revision 1.10  2002/05/28 02:51:11  jrush
 * Made static any functions and global variables private to this source file
 * and commented out any unused functions.
 *
 * Revision 1.9  2002/04/12 11:56:43  jrush
 * Reorganized include file layout, renamed xanadu.h to udanax.h and
 * typecontext/typecrumcontext to C++ class Context/CrumContext.
 *
 * Revision 1.8  2002/04/10 18:01:54  jrush
 * Renamed class typeisa to IStreamAddr.
 *
 * Revision 1.7  2002/04/09 21:45:46  jrush
 * Renamed class 'tumbler' to 'Tumbler', for consistency with Python sources,
 * and changed typeisa from typedef to a subclass, in preparation for cleaning
 * up the type/class tree.
 *
 * Revision 1.6  2002/04/06 20:42:50  jrush
 * Switch from sess->alloc() style to new(sess) Object parameterized allocator.
 *
 * Revision 1.5  2002/04/06 19:51:30  jrush
 * Renamed TRUE/FALSE constant use to the C++ standard of true/false.
 *
 * Revision 1.4  2002/04/06 17:05:57  jrush
 * Switched from referring to 'task' for a client connection to 'session',
 * and converted the typetask typedef/struct into a Session C++ class.
 *
 * Revision 1.3  2002/04/06 15:01:17  jrush
 * Changed INT to just 'int'.
 *
 * Revision 1.2  2002/02/14 09:27:43  jrush
 * Cleaned up source:
 *
 * 1. ran thru the indent tool to achieve a standard look,
 * 2. added structured comments at top for use with DOxygen reporting
 *    as well as CVS keywords,
 * 3. fixed compiler warnings re ambiguous assign/compares,
 *    needed casts and unused/uninitialized variables,
 * 4. fixed funcs that didn't specify a return type,
 * 5. centralized prototypes in protos.h, removing incomplete ones,
 * 6. cleaned up use of bool/BOOLEAN type to suit C++ type,
 * 7. fixed initializer nesting in tumbler constants,
 * 8. renamed vars that conflict with C++ keywords (new, this),
 * 9. fixed global/extern confusion re some global vars.
 *
 */

#include <memory.h>
#include "udanax.h"

#ifdef DISTRIBUTION
char granf2err[] = "g2error\n";
#endif

static void findisatoinsertmolecule(typecuc * fullcrumptr, typehint * hintptr, IStreamAddr * isaptr);
static void klugefindisatoinsertnonmolecule(typecuc * fullcrumptr, typehint * hintptr, IStreamAddr * isaptr);
static void findisatoinsertnonmolecule(typecuc * fullcrumptr, typehint * hintptr, IStreamAddr * isaptr);

typeorgl
fetchorglgr(Session *sess, typegranf fullcrumptr, IStreamAddr *address)
{
    CrumContext *context;
    typecuc *ret = NULL;

#ifndef DISTRIBUTION
    if (debug) {
        fprintf(stderr, "fetchorglgr ");
        dumptumbler(address);
        fprintf(stderr, "\n");
    }
#endif

    if (tumblercmp(&((typecuc *) fullcrumptr)->cwid.dsas[WIDTH], address) == LESS)
        return NULL;

    if ((context = retrievecrums((typecuc *) fullcrumptr, address, WIDTH)) == NULL)
        return NULL;

    if (!tumblereq((Tumbler *) & context->totaloffset, address)) {
        crumcontextfree(context);
        return NULL;
    }

    if (!context->corecrum->cinfo.granstuff.orglstuff.orglptr && context->corecrum->cinfo.granstuff.orglstuff.diskorglptr.diskblocknumber == DISKPTRNULL) {
        assert(0); // No orgl core ptr when diskptr is null
    }

    assert(context->corecrum->cinfo.infotype == GRANORGL); // ERROR: I should have found an orgl in fetchorglgr

    if (!context->corecrum->cinfo.granstuff.orglstuff.orglincore) {
        if (context->corecrum->cinfo.granstuff.orglstuff.diskorglptr.diskblocknumber == DISKPTRNULL)
            assert(0); // fetchorglgr null diskorglptr
        inorgl(context->corecrum);
    }

    ret = context->corecrum->cinfo.granstuff.orglstuff.orglptr;
    if (!ret)
        assert(0); // fetchorglgr null orglptr

    crumcontextfree(context);
    rejuvinate((typecorecrum *) ret);
    return (typeorgl) ret;
}

static bool
isaexistsgr(typecuc *crumptr, IStreamAddr *isaptr)
{
    Context *context = retrieve(crumptr, isaptr, WIDTH);
    bool ret = tumblereq((Tumbler *) &context->totaloffset, isaptr);

    contextfree(context);
    return ret;
}

static bool
findisatoinsertgr(typecuc *fullcrumptr, typehint *hintptr, IStreamAddr *isaptr)
{
/* isaexistsgr (fullcrumptr, &hintptr->hintisa); */
    if (!isaexistsgr(fullcrumptr, &hintptr->hintisa)) {
        if (hintptr->subtype != ATOM) {

            klugefindisatoinsertnonmolecule(fullcrumptr, hintptr, isaptr);
            tumblerjustify(isaptr);
            return true;
        }
#ifndef DISTRIBUTION
        fprintf(stderr, "nothing at hintisa\n");
#endif
        return false;
    }

    if (hintptr->subtype == ATOM)
        findisatoinsertmolecule(fullcrumptr, hintptr, isaptr);
    else
        findisatoinsertnonmolecule(fullcrumptr, hintptr, isaptr);

    tumblerjustify(isaptr);
    return true;
}

bool
inserttextgr(Session *sess, typegranf fullcrumptr, typehint *hintptr, typetextset textset, typeispanset *ispansetptr)
{
    typegranbottomcruminfo locinfo;
    typeispan *ispanptr;

    IStreamAddr lsa;
    if (!findisatoinsertgr((typecuc *) fullcrumptr, hintptr, &lsa))
        return false;

    Tumbler spanorigin;
    movetumbler(&lsa, &spanorigin);

    for (; textset; textset = textset->next) {
        locinfo.infotype = GRANTEXT;
        locinfo.granstuff.textstuff.textlength = textset->length;
        movmem(textset->string, locinfo.granstuff.textstuff.textstring, locinfo.granstuff.textstuff.textlength);
        insertseq((typecuc *) fullcrumptr, &lsa, &locinfo);
        tumblerincrement(&lsa, 0, textset->length, &lsa);
    }

    ispanptr         = new(sess) typeispan;
//    ispanptr = (typeispan *) sess->alloc(sizeof(typeispan));
    ispanptr->itemid = ISPANID;
    ispanptr->next   = NULL;

    movetumbler(&spanorigin, &ispanptr->stream);
    tumblersub(&lsa, &spanorigin, &ispanptr->width);
    *ispansetptr = ispanptr;

    return true;
}

bool
createorglgr(Session *sess, typegranf fullcrumptr, typehint *hintptr, IStreamAddr *isaptr)
{
    typegranbottomcruminfo locinfo;

    if (!findisatoinsertgr((typecuc *) fullcrumptr, hintptr, isaptr))
        return false;

    locinfo.infotype = GRANORGL;
    locinfo.granstuff.orglstuff.orglptr = createenf(POOM);
    reserve((typecorecrum *) locinfo.granstuff.orglstuff.orglptr);

    locinfo.granstuff.orglstuff.orglincore                        = true;
    locinfo.granstuff.orglstuff.diskorglptr.diskblocknumber       = DISKPTRNULL;
    locinfo.granstuff.orglstuff.diskorglptr.insidediskblocknumber = 0;

    insertseq((typecuc *) fullcrumptr, isaptr, &locinfo);
    rejuvinate((typecorecrum *) locinfo.granstuff.orglstuff.orglptr);

    return true;
}

static void
findlastisaincbcgr(typecbc *ptr, IStreamAddr *offset)
 /* offset is last isa if non-text or one char */
{
    if (ptr->cinfo.infotype == GRANTEXT)
        tumblerincrement(offset, 0, (int) ptr->cinfo.granstuff.textstuff.textlength - 1, offset);
}

static void
findpreviousisagr(typecorecrum *crumptr, IStreamAddr *upperbound, IStreamAddr *offset)
{
    RECURSIVE                          /* findpreviousisagr */
            int tmp;

    /* zzz? if (!offset) tumblerclear (offset); */
    if (crumptr->height == 0) {
        findlastisaincbcgr((typecbc *) crumptr, offset);
        return;
    }

    typecorecrum *ptr;
    for (ptr = findleftson((typecuc *) crumptr); ptr; ptr = findrightbro(ptr)) {
        if ((tmp = whereoncrum(ptr, (typewid *) offset, upperbound, WIDTH)) == THRUME
            || tmp == /*ONMYLEFTBORDER*/ ONMYRIGHTBORDER || !ptr->rightbro) {
            findpreviousisagr(ptr, upperbound, offset);
            return;
        } else {
            tumbleradd(offset, &ptr->cwid.dsas[WIDTH], offset);
        }
    }
}

static void
findisatoinsertmolecule(typecuc *fullcrumptr, typehint *hintptr, IStreamAddr *isaptr)
{
    IStreamAddr upperbound, lowerbound;

    tumblerincrement(&hintptr->hintisa, 2, hintptr->atomtype + 1, &upperbound);
    clear(&lowerbound, sizeof(lowerbound));

    findpreviousisagr((typecorecrum *) fullcrumptr, &upperbound, &lowerbound);
    if (tumblerlength(&hintptr->hintisa) == tumblerlength(&lowerbound)) {
        tumblerincrement(&lowerbound, 2, hintptr->atomtype, isaptr);
        tumblerincrement(isaptr, 1, 1, isaptr);
    } else if (hintptr->atomtype == TEXTATOM) {
        tumblerincrement(&lowerbound, 0, 1, isaptr);
    } else if (hintptr->atomtype == LINKATOM) {
        tumblerincrement(&hintptr->hintisa, 2, 2, isaptr);
        if (tumblercmp(&lowerbound, isaptr) == LESS)
            tumblerincrement(isaptr, 1, 1, isaptr);
        else
            tumblerincrement(&lowerbound, 0, 1, isaptr);
    } else
        assert(0); // findisatoinsertmoleculegr
}

static void
klugefindisatoinsertnonmolecule(typecuc *fullcrumptr, typehint *hintptr, IStreamAddr *isaptr)
{
/* IStreamAddr upperbound, lowerbound; int depth, hintlength; depth = hintptr->supertype == hintptr->subtype ? 1 : 2;
 * hintlength = tumblerlength (&hintptr->hintisa); tumblerincrement (&hintptr->hintisa, depth - 1, 1, &upperbound);
 * clear (&lowerbound, sizeof(lowerbound)); findpreviousisagr (fullcrumptr, &upperbound, &lowerbound); tumblertruncate
 * (&lowerbound, hintlength + depth, isaptr);
 * tumblerincrement(isaptr,tumblerlength(isaptr)==hintlength?depth:0,1,isaptr); */
#ifdef UnDeFIned

    tumblercopy( /* & */ hintptr /*->hintisa*/ , isaptr);       /* ECH 8-30-88 was hintptr, not &hintptr->hintisa */
#endif
    tumblercopy(&hintptr->hintisa, isaptr);

}

static void
findisatoinsertnonmolecule(typecuc *fullcrumptr, typehint *hintptr, IStreamAddr *isaptr)
{
    int depth      = (hintptr->supertype == hintptr->subtype) ? 1 : 2;
    int hintlength = tumblerlength(&hintptr->hintisa);

    IStreamAddr upperbound;
    tumblerincrement(&hintptr->hintisa, depth - 1, 1, &upperbound);

    IStreamAddr lowerbound;
    clear(&lowerbound, sizeof(lowerbound));

    findpreviousisagr((typecorecrum *) fullcrumptr, &upperbound, &lowerbound);

    tumblertruncate(&lowerbound, hintlength + depth, isaptr);
    tumblerincrement(isaptr, (tumblerlength(isaptr) == hintlength) ? depth : 0, 1, isaptr);
}

typevstuffset *
ispan2vstuffset(Session *sess, typegranf fullcrumptr, typeispan *ispanptr, typevstuffset *vstuffsetptr)
{
    typevstuffset vstuffset;
    Context *temp;

    *vstuffsetptr = NULL;

    IStreamAddr lowerbound;
    movetumbler(&ispanptr->stream, &lowerbound);

    IStreamAddr upperbound;
    tumbleradd(&lowerbound, &ispanptr->width, &upperbound);

    Context *context = retrieveinspan((typecuc *) fullcrumptr, &lowerbound, &upperbound, WIDTH);

#ifndef DISTRIBUTION
    foocontextlist("retrieveinspan returning\n", context);
#endif

    for (temp = context; temp; temp = (Context *) temp->nextcontext) {
#ifndef DISTRIBUTION
        foocontext("passing context temp =", temp);
#endif
        if (context2vstuff(sess, temp, ispanptr, &vstuffset)) {
#ifndef DISTRIBUTION
            foohex("vstuffsetptr = ", (int) vstuffsetptr);
            foohex("vstuffset = ", (int) vstuffset);
            foohex("&vstuffset->next = ", (int) &((typeitemheader *) vstuffset)->next);
#endif
            *vstuffsetptr = vstuffset;
            vstuffsetptr = (typevstuffset *) & ((typeitemheader *) vstuffset)->next;
        }
    }

    contextfree(context);
    return vstuffsetptr;
}
