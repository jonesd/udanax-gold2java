/**********************************************************************
 * Copyright 2002 Jeff Rush <jrush@taupro.com>
 * Original Copyright 1979-2002 Udanax.com
 *
 * This file is part of the Udanax xanalogical storage system.
 *
 * Udanax is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * Udanax is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with Udanax; if not, write to the Free Software Foundation,
 * Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 **********************************************************************/

/**
 * @file  sporgl.cxx
 * @brief Udanax Back-end routines to handle sporgls
 *
 * (to be defined)
 *
 **/

/* Modification History:
 * $Log: sporgl.cxx,v $
 * Revision 1.12  2002/07/14 08:35:23  jrush
 * Replace gerror(), qerror() with assert()
 *
 * Revision 1.11  2002/05/28 04:22:29  jrush
 * Adjusted source files to comply with GPL licensing.
 *
 * Revision 1.10  2002/05/28 02:52:23  jrush
 * Made static any functions and global variables private to this source file
 * and commented out any unused functions.
 *
 * Revision 1.9  2002/04/12 11:56:43  jrush
 * Reorganized include file layout, renamed xanadu.h to udanax.h and
 * typecontext/typecrumcontext to C++ class Context/CrumContext.
 *
 * Revision 1.8  2002/04/10 18:01:54  jrush
 * Renamed class typeisa to IStreamAddr.
 *
 * Revision 1.7  2002/04/09 21:45:46  jrush
 * Renamed class 'tumbler' to 'Tumbler', for consistency with Python sources,
 * and changed typeisa from typedef to a subclass, in preparation for cleaning
 * up the type/class tree.
 *
 * Revision 1.6  2002/04/06 20:42:50  jrush
 * Switch from sess->alloc() style to new(sess) Object parameterized allocator.
 *
 * Revision 1.5  2002/04/06 19:51:30  jrush
 * Renamed TRUE/FALSE constant use to the C++ standard of true/false.
 *
 * Revision 1.4  2002/04/06 17:05:57  jrush
 * Switched from referring to 'task' for a client connection to 'session',
 * and converted the typetask typedef/struct into a Session C++ class.
 *
 * Revision 1.3  2002/04/06 15:01:17  jrush
 * Changed INT to just 'int'.
 *
 * Revision 1.2  2002/02/14 09:27:43  jrush
 * Cleaned up source:
 *
 * 1. ran thru the indent tool to achieve a standard look,
 * 2. added structured comments at top for use with DOxygen reporting
 *    as well as CVS keywords,
 * 3. fixed compiler warnings re ambiguous assign/compares,
 *    needed casts and unused/uninitialized variables,
 * 4. fixed funcs that didn't specify a return type,
 * 5. centralized prototypes in protos.h, removing incomplete ones,
 * 6. cleaned up use of bool/BOOLEAN type to suit C++ type,
 * 7. fixed initializer nesting in tumbler constants,
 * 8. renamed vars that conflict with C++ keywords (new, this),
 * 9. fixed global/extern confusion re some global vars.
 *
 */

#include "udanax.h"

static typesporglset *
vspanset2sporglset(Session *sess, IStreamAddr *docisa, typevspanset vspanset, typesporglset *sporglsetptr, int type)
{
    typeorgl orgl;
    typesporgl *sporglset;
    typeispanset ispanset;

    ispanset = NULL;
    if (!findorgl(sess, granf, docisa, &orgl, type))
        return NULL;

    for (; vspanset; vspanset = vspanset->next) {
        (void)vspanset2ispanset(sess, orgl, vspanset, &ispanset);
        for (; ispanset; ispanset = ispanset->next) {
            sporglset = new(sess) typesporgl;
            sporglset->itemid = SPORGLID;
            sporglset->next   = NULL;

            movetumbler(docisa,            &sporglset->sporgladdress);
            movetumbler(&ispanset->stream, &sporglset->sporglorigin);
            movetumbler(&ispanset->width,  &sporglset->sporglwidth);

            *sporglsetptr = (typesporglset) sporglset;
            sporglsetptr  = (typesporglset *) & sporglset->next;
        }
    }
/* note that this returns the LAST sporgl alloced this is ok the returned value gets passed back to here to be used for 
 * a linked list */
    return sporglsetptr;
}

bool
specset2sporglset(Session *sess, typespecset specset, typesporglset *sporglsetptr, int type)
{
    *sporglsetptr = NULL;
    for (; specset; specset = (typespecset) ((typeitemheader *) specset)->next) {
        if (((typeitemheader *) specset)->itemid == ISPANID) {
            *sporglsetptr = (typesporglset) specset;
            sporglsetptr = (typesporglset *) & ((typeitemheader *) specset)->next;

        } else if (((typeitemheader *) specset)->itemid == VSPECID) {

            if (!(sporglsetptr = vspanset2sporglset(sess, &((typevspec *) specset)->docisa, ((typevspec *) specset)->vspanset, sporglsetptr, type)))
                return false;
        }
    }

    *sporglsetptr = NULL;
    return true;
}

bool
link2sporglset(Session *sess, IStreamAddr *linkisa, typesporglset *sporglsetptr, int whichend, int type)
{
    typeorgl orgl;
    Tumbler zero;
    typevspan vspan;
    Context *context, *c;
    typesporgl *sporglptr;

    if (!findorgl(sess, granf, linkisa, &orgl, type))
        return false;

    tumblerclear(&zero);
    tumblerincrement(&zero, 0, whichend, &vspan.stream);
    tumblerincrement(&zero, 0 /* 1 */ , 1, &vspan.width);
    if ((context = retrieverestricted((typecuc *) orgl, &vspan, V, (typespan *) NULL, I, (IStreamAddr *) NULL)) != 0) {
        for (c = context; c; c = (Context *) c->nextcontext) {
            sporglptr = new(sess) typesporgl;
            contextintosporgl((type2dcontext *) c, (Tumbler *) NULL, sporglptr, I);

            *sporglsetptr = (typesporglset) sporglptr;
            sporglsetptr  = (typesporglset *) & sporglptr->next;
        }
        contextfree(context);
        return true;

    } else
        return false;
}

/* leaves sporglsetptr on last sporgl processed, NOT next to be processed */

static void
sporglset2vspanset(Session *sess, IStreamAddr *homedoc, typesporglset *sporglsetptr, typevspanset *vspansetptr, int type)
{
    typeorgl orgl;
    typeispan ispan;

/* Tumbler zero; */
    typesporgl *sporglptr;

    sporglptr = (typesporgl *) * sporglsetptr;
/* tumblerclear (&zero); */

    findorgl(sess, granf, homedoc /* &sporglptr->sporgladdress */, &orgl, type);
    ispan.itemid = ISPANID;
    ispan.next   = NULL;
    movetumbler(&sporglptr->sporglorigin, &ispan.stream);
    movetumbler(&sporglptr->sporglwidth, &ispan.width);
    vspansetptr = ispan2vspanset(sess, orgl, &ispan, vspansetptr);

    for (;;) {
        sporglptr = sporglptr->next;
        if (!sporglptr || !(sporglptr->itemid == SPORGLID) || !tumblereq(&((typesporgl *) sporglptr)->sporgladdress, &((typesporgl *) (*sporglsetptr))->sporgladdress))
            return;

        *sporglsetptr = (typesporglset) sporglptr;
        movetumbler(&sporglptr->sporglorigin, &ispan.stream);

        if (iszerotumbler(&sporglptr->sporglwidth))
            assert(0); // 2 sporgl ispan width 0 in sporglset2vspanset

        movetumbler(&sporglptr->sporglwidth, &ispan.width);
        vspansetptr = ispan2vspanset(sess, orgl, &ispan, vspansetptr);
    }
}

/* leaves sporglsetptr on last sporgl processed, NOT next to be processed */

static void
linksporglset2vspec(Session *sess, IStreamAddr *homedoc, typesporglset *sporglsetptr, typevspec *specptr, int type)
{
/* typesporglset sporglset; sporglset = *sporglsetptr; */
    specptr->itemid = VSPECID;
    specptr->next   = NULL;
    movetumbler(homedoc /* &sporglset->sporgladdress */ , &specptr->docisa);

    specptr->vspanset = NULL;
    sporglset2vspanset(sess, homedoc, sporglsetptr, &specptr->vspanset, type);
}

bool
linksporglset2specset(Session *sess, IStreamAddr *homedoc, typesporglset sporglset, typespecset *specsetptr, int type)
{
    typespecset specset;

    *specsetptr = NULL;
    for (; sporglset; sporglset = (typesporglset) ((typeitemheader *) sporglset)->next) {
        specset = (typespecset) new(sess) typevspec;
//        specset = (typespecset) sess->alloc(sizeof(typevspec));
        if (iszerotumbler(&((typesporgl *) sporglset)->sporgladdress)) {
            if (iszerotumbler(&((typesporgl *) sporglset)->sporglwidth))
                assert(0); // zero wid I span in linksporglset2specset

            ((typeitemheader *) specset)->itemid = ISPANID;
            movetumbler(&((typesporgl *) sporglset)->sporglorigin, &((typeispan *) specset)->stream);
            movetumbler(&((typesporgl *) sporglset)->sporglwidth, &((typeispan *) specset)->width);
        } else
            linksporglset2vspec(sess, homedoc, &sporglset, (typevspec *) specset, type);

        ((typeitemheader *) specset)->next = NULL;
        *specsetptr = specset;
        specsetptr = (typespecset *) & ((typeitemheader *) specset)->next;
    }
    return true;
}

void
unpacksporgl(typesporglset sporglptr, Tumbler *streamptr, Tumbler *widthptr, type2dbottomcruminfo *infoptr)
{
    if (((typeitemheader *) sporglptr)->itemid == ISPANID) {
        movetumbler(&((typeispan *) sporglptr)->stream, streamptr);
        movetumbler(&((typeispan *) sporglptr)->width, widthptr);
        tumblerclear(&infoptr->homedoc);

    } else if (((typeitemheader *) sporglptr)->itemid == SPORGLID) {
        movetumbler(&((typesporgl *) sporglptr)->sporglorigin, streamptr);
        movetumbler(&((typesporgl *) sporglptr)->sporglwidth, widthptr);
        movetumbler(&((typesporgl *) sporglptr)->sporgladdress, &infoptr->homedoc /* should be sourcedoc */ );

    } else
        fprintf(stderr, "unpacksporgl - bad itemid\n");

    assert(!iszerotumbler(widthptr));  // ERROR: zero width in unpacksporgl
}

void
contextintosporgl(type2dcontext *context, Tumbler *linkid, typesporgl *sporglptr, int index)
{
    sporglptr->itemid = SPORGLID;
    sporglptr->next   = NULL;
    movetumbler(/* linkid */ &context->context2dinfo.homedoc, &sporglptr->sporgladdress);

/* ^^^^^ zzz foo kluge 11/23/84 ^^^^^ */

    movetumbler(&context->totaloffset.dsas[index], &sporglptr->sporglorigin);

    if (iszerotumbler(&context->contextwid.dsas[index]))
        assert(0); // zero wid in contextintosporgl

    movetumbler(&context->contextwid.dsas[index], &sporglptr->sporglwidth);
}

static void
sporglset2linksetinrange(Session *sess, typecuc *spanfptr, typesporglset sporglset, typelinkset *linksetptr,
                         typeispan *orglrange, int spantype)
{
    typespan range;
    Context *context, *c;
    IStreamAddr linksa;

    type2dbottomcruminfo linfo;
    type2dbottomcruminfo *infoptr = &linfo;
    for (; sporglset; sporglset = (typesporglset) ((typeitemheader *) sporglset)->next) {
        if (false /* trying to kluge links followable thru versions */
            && ((typeitemheader *) sporglset)->itemid == SPORGLID) {
            infoptr = &linfo;
            movetumbler(&((typesporgl *) sporglset)->sporgladdress, &linfo.homedoc);
        } else
            infoptr = NULL;

        if (orglrange) {
            prefixtumbler(&orglrange->stream, spantype, &range.stream);
            prefixtumbler(&orglrange->width, 0, &range.width);
            context = retrieverestricted(spanfptr, (typespan *) sporglset, SPANRANGE, &range, ORGLRANGE, (IStreamAddr *) infoptr);
        } else
            context = retrieverestricted(spanfptr, (typespan *) sporglset, SPANRANGE, (typespan *) NULL, ORGLRANGE, (IStreamAddr *) infoptr);

        for (c = context; c; c = (Context *) c->nextcontext) {
            beheadtumbler(&c->totaloffset.dsas[ORGLRANGE], &linksa);
            onlinklist(sess, linksetptr, &linksa);
        }

        contextfree(context);
    }
}

void
sporglset2linkset(Session *sess, typecuc *spanfptr, typesporglset sporglset, typelinkset *linksetptr, typeispan *homeset, int spantype)
{
    typeispan nullhomeset;

    *linksetptr = NULL;

    if (true || !homeset) {
        tumblerclear(&nullhomeset.stream);
        tumblerclear(&nullhomeset.width);
        nullhomeset.width.mantissa[0] = 100;
        nullhomeset.next = NULL;
        homeset = &nullhomeset;
    }

    for (; homeset; homeset = homeset->next)
        sporglset2linksetinrange(sess, spanfptr, sporglset, linksetptr, homeset, spantype);
}
