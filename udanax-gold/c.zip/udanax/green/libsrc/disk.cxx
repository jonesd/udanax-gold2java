/**********************************************************************
 * Copyright 2002 Jeff Rush <jrush@taupro.com>
 * Original Copyright 1979-2002 Udanax.com
 *
 * This file is part of the Udanax xanalogical storage system.
 *
 * Udanax is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * Udanax is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with Udanax; if not, write to the Free Software Foundation,
 * Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 **********************************************************************/

/**
 * @file  disk.cxx
 * @brief Udanax lower-level disk routines
 *
 * (to be defined)
 *
 **/

/* Modification History:
 * $Log: disk.cxx,v $
 * Revision 1.8  2002/07/26 04:30:29  jrush
 * Replaced gerror() with assert()
 *
 * Revision 1.7  2002/05/28 04:22:29  jrush
 * Adjusted source files to comply with GPL licensing.
 *
 * Revision 1.6  2002/05/28 02:49:42  jrush
 * Made static any functions and global variables private to this source file
 * and commented out any unused functions.
 *
 * Revision 1.5  2002/04/12 11:56:42  jrush
 * Reorganized include file layout, renamed xanadu.h to udanax.h and
 * typecontext/typecrumcontext to C++ class Context/CrumContext.
 *
 * Revision 1.4  2002/04/06 19:51:30  jrush
 * Renamed TRUE/FALSE constant use to the C++ standard of true/false.
 *
 * Revision 1.3  2002/04/06 15:01:17  jrush
 * Changed INT to just 'int'.
 *
 * Revision 1.2  2002/02/14 09:27:43  jrush
 * Cleaned up source:
 *
 * 1. ran thru the indent tool to achieve a standard look,
 * 2. added structured comments at top for use with DOxygen reporting
 *    as well as CVS keywords,
 * 3. fixed compiler warnings re ambiguous assign/compares,
 *    needed casts and unused/uninitialized variables,
 * 4. fixed funcs that didn't specify a return type,
 * 5. centralized prototypes in protos.h, removing incomplete ones,
 * 6. cleaned up use of bool/BOOLEAN type to suit C++ type,
 * 7. fixed initializer nesting in tumbler constants,
 * 8. renamed vars that conflict with C++ keywords (new, this),
 * 9. fixed global/extern confusion re some global vars.
 *
 */

#include <stdio.h>
#include <memory.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <netinet/in.h>
#include <errno.h>

#include "udanax.h"

int nolread = 0 /* number of blocks read from disk in session */ ;
int nolwrote = 0 /* same for writes */ ;

int enffiledes; /* enfilade file descriptor where disk stuff is */
bool enffileread;       /* yeah another external */

int
findnumberofdamnsons(typediskloafptr diskptr)
{
    if (diskptr.diskblocknumber == DISKPTRNULL)
        assert(0); // null diskptr in changerefcount

    typeuberrawdiskloaf loaf;
    actuallyreadrawloaf(&loaf, diskptr.diskblocknumber);

    char *loafp = findinsideloaf((typeuberdiskloaf *) &loaf, diskptr.insidediskblocknumber);

    int size;
    hgetfromloaf(&size, loafp);

    int isapex;
    hgetfromloaf(&isapex, loafp);

    int height;
    hgetfromloaf(&height, loafp);

    int enftype;
    hgetfromloaf(&enftype, loafp);

    int numberofsons;
    hgetfromloaf(&numberofsons, loafp);

    return numberofsons;
}

static int
changeunterrefcount(typediskloaf *wholeloafp, char *originalloafp, int delta)
{
    int ret;
    int numberofsons;
    char *loafp;
    int height, enftype;
    int isapex;
    unsigned int refcount;
    int foo;
    unsigned int oldlength, newlength, dummylength, dummy;
    int lengthdif;
    int size;
    char *refcountloafp;

    loafp = (char *)originalloafp;
/* loafp += 3; */
    hgetfromloaf(&size, loafp);
    hgetfromloaf(&isapex, loafp);
// if (isapex) { assert(0); /* attempt to read apex in chengerefcount */); }
    hgetfromloaf(&height, loafp);
    hgetfromloaf(&enftype, loafp);
    hgetfromloaf(&numberofsons, loafp);
    refcountloafp = loafp;
    hgetfromloaf((int *) &refcount, loafp);
    foo = loafp - (char *)wholeloafp;

    oldlength = intlengthoflength(refcount);
    refcount += delta;
    ret = refcount;
    newlength = intlengthoflength(refcount);
/* fprintf(stderr,"changeunterrefcount A \n"); */
    if ((int) refcount > 0) {
/* fprintf(stderr,"changeunterrefcount B \n"); */
        if (oldlength == newlength) {
/* (void)humberput(refcount, loafp-oldlength, &dummylength); */
        } else {
/* fprintf(stderr,"changeunterrefcount C \n"); */
/* fprintf(stderr,"changeunterrefcoun bt oldlength = %d newlength = %d\n",oldlength,newlength); */
            lengthdif = newlength - oldlength;
            if (newlength > oldlength) {
/* fprintf(stderr,"changeunterrefcount D \n"); */
                movmem(loafp, loafp - oldlength + newlength, sizeof(typeuberrawdiskloaf) - foo - newlength);
            } else if (newlength > oldlength) {
/* fprintf(stderr,"changeunterrefcount E \n"); */
                movmem(loafp, loafp - oldlength + newlength, sizeof(typeuberrawdiskloaf) - foo - oldlength);
            }
/* fprintf(stderr,"changeunterrefcount F \n"); */
            size = size + oldlength - newlength;
            (void)humber3put(size, (humber) originalloafp, &dummy);
/* fprintf(stderr,"changeunterrefcount G \n"); */
        }
/* fprintf(stderr,"changeunterrefcount H \n"); */

        (void)humberput((int) refcount, (humber) refcountloafp /*-oldlength*/ , &dummylength);
/* fprintf(stderr,"changeunterrefcount I \n"); */
/* dumphexstuff(originalloafp); */
/* fprintf(stderr,"changeunterrefcount J \n"); */
    } else {
/* fprintf(stderr,"changeunterrefcount K \n"); */
        movmem(originalloafp + size, originalloafp + 1, sizeof(typeuberrawdiskloaf) - foo - size + 3);
/* fprintf(stderr,"changeunterrefcount L \n"); */
        *originalloafp = 1;
/* diskfree (diskptr.diskblocknumber); */
    }
/* fprintf(stderr,"leaving changeunterrefoount \n"); */
    return ret;
}

int
changerefcount(typediskloafptr diskptr, int delta)
{
    if (diskptr.diskblocknumber == DISKPTRNULL)
        assert(0); // null diskptr in changerefcount

    typeuberrawdiskloaf loaf;
    actuallyreadrawloaf(&loaf, diskptr.diskblocknumber);

    char *loafp            = findinsideloaf((typeuberdiskloaf *) &loaf, diskptr.insidediskblocknumber);
    int refcount           = changeunterrefcount((typediskloaf *) &loaf, loafp, delta);
    int numberofunterloafs = numberofliveunterloafs((typeuberdiskloaf *) &loaf);

    if (refcount > 0 && numberofunterloafs > 0)
        actuallywriteloaf( /* sizeof(typediskloaf), */ &loaf, diskptr.diskblocknumber);
    else
        diskfree(diskptr.diskblocknumber);

    return refcount;
}

/* Reads whats on disk at place named by loafptr in * place pointed to by loaf */
void
readloaf(typediskloaf *loafptr, typediskloafptr diskptr)
{
    typeuberrawdiskloaf uberrawloaf;
    humber temp;

/* fprintf(stderr,"entering readloaf diskblocknumber = %d insdiediskblocknumber =
 * %d\n",diskptr.diskblocknumber,diskptr.insidediskblocknumber); */
    actuallyreadrawloaf(&uberrawloaf, diskptr.diskblocknumber);
/* fprintf(stderr,"in readloaf dumping loaf\n"); */
/* dumphexstuff(&uberrawloaf); */
    temp = (humber) findinsideloaf((typeuberdiskloaf *) & uberrawloaf, diskptr.insidediskblocknumber);
    if (!temp) {
        temp = (humber) (((char *)&uberrawloaf) + 6);
    }
    movmem(temp, loafptr, intof(temp)); /* humber at temp is length of loaf */
}

void
actuallyreadrawloaf(typeuberrawdiskloaf *loafptr, int blocknumber)
{
/* fprintf(stderr,"entering actuallyreadloaf diskblocknumber = %d\n",blocknumber); */
    if (!loafptr || blocknumber == DISKPTRNULL) {
#ifndef DISTRIBUTION
        fprintf(stderr, "loafptr = %d\n", blocknumber);
        if (loafptr)
            dumpsubtree((typecuc *) loafptr);
        assert(0); // bad readloaf call
#else
        assert(0); // bad call
#endif
    }

    if (!enffileread) {
        if (close(enffiledes) != 0)
            perror("close failed in readloaf");

        if ((enffiledes = open("enf.enf",  O_RDWR, 0)) == -1) {
            perror("open");
            assert(0); // open
        }
        enffileread = true;
    }

    if (!goodblock(blocknumber)) {
#ifndef DISTRIBUTION
        fprintf(stderr, "loaf = %x\n", blocknumber);
        fprintf(stderr, "unallocated block in readloaf.\n");
#endif
        abort();
    }

    if (lseek(enffiledes, (long)blocknumber * NUMBYTESINLOAF, 0) < 0) {
#ifndef DISTRIBUTION
        perror("lseek in readloaf");
#endif
        assert(0); // lseek failed
    }

    int nbytes = read(enffiledes, (char *) loafptr, sizeof(*loafptr));
    assert(nbytes > 0); // Incorrect Usage of Assertion

    // dumphexstuff(loafptr);
    // if ((int) loafptr->xdbcloaf.xdbchedr.refcount < 0) {
    //     assert(0); // readloaf read a loaf with refcount < 0
    // }
    ++nolread;

    // return true;
}

/* Writes stuff at loaf onto piece of disk named by loafptr */
void
writeloaf(typediskloaf *loafptr, typediskloafptr diskptr, int newloaf)
{
/* typeuberdiskloaf loaf; */
    typeuberrawdiskloaf loaf;
    char *temp;
    char *last, *end;
    int s;
    short loaftemp;

/* fprintf(stderr,"entering writeloaf newloaf flag = %d diskblocknumber = %d insdiediskblocknumber =
 * %d\n",newloaf,diskptr.diskblocknumber,diskptr.insidediskblocknumber); */
    if (diskptr.insidediskblocknumber > 100) {
#ifndef DISTRIBUTION
        assert(0); // in write laof large diskblocknumber
#else
        assert(0); // bad
#endif
    }
/* dumphexstuff(loafptr); */
    (void)intof((humber) loafptr);     /* test it to see if it starts with length */

/* test diskalloc if alloced read in else do as old version */

    if (!newloaf) {
/* fprintf(stderr,"writeloaf 1\n"); */
        actuallyreadrawloaf(&loaf, diskptr.diskblocknumber);
/* dumphexstuff(&loaf); */
/* fprintf(stderr,"writeloaf 2\n"); */
        temp = findinsideloaf((typeuberdiskloaf *) & loaf, diskptr.insidediskblocknumber);
/* fprintf(stderr,"numberofunterloafs = %d\n",loaf.xuberdiskloaf.numberofunterloafs); */
        if (diskptr.insidediskblocknumber == loaf.xuberdiskloaf.numberofunterloafs) {
            end = temp + intof((humber) temp);
        } else {
            last = findinsideloaf((typeuberdiskloaf *) & loaf, (int) ntohs(loaf.xuberdiskloaf.numberofunterloafs) - 1);
/* dumphexstuff(last); */
/* fprintf(stderr,"last = %x\n",last); */
            end = last + intof((humber) last);
        }
        s = sizeof(typeuberrawdiskloaf) - (end - (char *)&loaf) - SIZEOFUBERDISKHEADER;
/* fprintf(stderr,"s = %d\n",s); */
        movmem(loafptr, /* ((char*)&loaf)+6 */ temp, s);
        loaf.xuberdiskloaf.versiondisknumber = 1;
        loaftemp = ntohs(loaf.xuberdiskloaf.numberofunterloafs) + 1;
        loaf.xuberdiskloaf.numberofunterloafs = htons(loaftemp);
    } else {
/* fprintf(stderr,"writeloaf A\n"); */
        movmem(loafptr, ((char *)&loaf) + 6, sizeof(typeuberrawdiskloaf) - SIZEOFUBERDISKHEADER);
/* fprintf(stderr,"writeloaf B\n"); */
        loaf.xuberdiskloaf.versiondisknumber = htonl(1);
        loaf.xuberdiskloaf.numberofunterloafs = htons(1);

    }
/* dumphexstuff(&loaf); */
    actuallywriteloaf( /* size, */ &loaf, diskptr.diskblocknumber);
/* fprintf(stderr,"leaving wrietloaf\n"); */
}

void
actuallywriteloaf( /* int size, */ typeuberrawdiskloaf *loafptr, int diskblocknumber)
{
    if (!loafptr || diskblocknumber == DISKPTRNULL /* || (int) loafptr->xdbcloaf.xdbchedr.refcount < 0 */ )
        assert(0); // bad call

    assert(goodblock(diskblocknumber)); // ERROR: unallocated block

    if (lseek(enffiledes, (long)diskblocknumber * NUMBYTESINLOAF, 0) < 0) {
        perror("lseek");
        assert(0); // lseek failed
    }

    int nbytes = write(enffiledes, (char *)loafptr, sizeof(*loafptr));
    assert(nbytes >= 0); // Incorrect Usage of Assert

    ++nolwrote;
}

bool                                   /* return false if new file */
initenffile(char *filename)
{
    //    static long times = 0;
    //    assert(times == 0); // too many inits
    //    ++times;

    initincorealloctables();
    bool ret = true;

    int fd = open(filename, O_RDWR, 0);
    if (fd == -1) {
        errno = 0;
        if ((fd = creat(filename, 0660)) == -1) {
            perror("initenffile");
            assert(0); // cant open enf.enf or creatit
        }
        initheader();
        enffileread = false;
        ret = false;

    } else {
        ret = readallocinfo(fd);
        enffileread = true;
    }

    if (!ret)
        writeallocinfo(fd);

    enffiledes = fd;
    return ret;
}

void
closediskfile()
{
    diskallocexit(enffiledes);
    if (close(enffiledes) != 0) {
        perror("close in closediskfile");
        assert(0); // close failed
    }
}

//UNUSED static void // UNUSED
//UNUSED dieandclosefiles()
//UNUSED {
//UNUSED     abort();
//UNUSED }

//UNUSED static void // UNUSED
//UNUSED warning(char *message)
//UNUSED {
//UNUSED     fprintf(stderr, "Warning: %s", message);
//UNUSED }
