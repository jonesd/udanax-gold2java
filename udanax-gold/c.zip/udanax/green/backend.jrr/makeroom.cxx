/**
 * @file  makeroom.cxx
 * @brief ???
 *
 * (to be defined)
 *
 **/

#include <nana/nana.h>  // GNU Assertion/Logging Tool

#include "xanadu.h"
#include "enf.h"
#include "ndenf.h"

/**********************************************************************
 *
 **********************************************************************/
    static void
expandcrumleftward(CoreUpperCrum *crumptr, StreamAddr *newdsp, StreamAddr *base, int index)
{
    crumptr->cdsp[index] = *newdsp;
    crumptr->cwid[index] = *base + crumptr->cwid[index];

    CoreUpperCrum *ptr = (CoreUpperCrum *) crumptr->leftSon();

    for (; ptr; ptr = (CoreUpperCrum *) ptr->rightBrother()) {

////////////////////////////////////////////////FIXME
//        ptr->cdsp[index] = *base + ptr->cdsp[index]; // adding two addresses is illegal!
        ptr->cdsp[index] = *base;
////////////////////////////////////////////////FIXME

        ptr->ivemodified();
    }
}

/**********************************************************************
 *
 **********************************************************************/
    void
makeroomonleftnd(CoreUpperCrum *father, Displacer *offset, Displacer *origin, Displacer *grasp)
{
    prologuend(father, offset, grasp, NULL);

    int i;
    for (i = 0; i < widsize(father->cenftype); ++i) {
        if ((*origin)[i] < (*grasp)[i]) {

//            tumblersub(&(*grasp)[i], &(*origin)[i], &base);
            StreamAddr base = (*grasp)[i] - (*origin)[i];

//            tumblersub(&(*origin)[i], &(*offset)[i], &newdsp);
            StreamAddr newdsp = (*origin)[i] - (*offset)[i];

            expandcrumleftward(father, &newdsp, &base, i);
            prologuend(father, offset, grasp, NULL);
        }
    }
}

/**********************************************************************
 *  Original Copyright � 1979-1999 Udanax.com.   All Rights Reserved
 **********************************************************************/
