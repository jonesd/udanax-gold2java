/**
 * @file  correspond.cxx
 * @brief Routines for Comparing Versions -- Lower Level
 *
 * (to be defined)
 *
 **/

#include <nana/nana.h>  // GNU Assertion/Logging Tool

#include "xanadu.h"
#include "enf.h"

extern typevspanset *ispan2vspanset(Session *sess, typeorgl orgl, typeispan *ispanptr, typevspanset *vspansetptr);

/**********************************************************************
 *
 **********************************************************************/
    void
restrictspecsetsaccordingtoispans(Session *sess, typeispanset ispanset, typespecset *specset1, typespecset *specset2)
{
    typespecset s1, s2;

    restrictvspecsetovercommonispans(sess, ispanset, *specset1, &s1);

    /* removespansnotinoriginal(sess, *specset1, &s1); */

    removespansnotinoriginal(sess, s1, specset1);
    tfreeitemset(sess, /* *specset1 */ (typeitemset) s1);

    /* *specset1 = s1; */

    restrictvspecsetovercommonispans(sess, ispanset, *specset2, &s2);

    /* removespansnotinoriginal(sess, *specset2, &s2); */

    removespansnotinoriginal(sess, s2, specset2);
    tfreeitemset(sess, /* *specset2 */ (typeitemset) s2);

    /* *specset2 = s2; */
}

/**********************************************************************
 *
 **********************************************************************/
    void
restrictvspecsetovercommonispans(Session *sess, typeispanset ispanset, typespecset specset, typespecset *newspecsetptr)
{
    *newspecsetptr = NULL;
    for (; ispanset; ispanset = ispanset->next) {
        for (; specset; specset = (typespecset) ((typeitemheader *) specset)->next) {

            typeorgl versionorgl;
            I(findorgl(sess, granf, &((typevspec *) specset)->docisa, &versionorgl, READBERT));

            typevspanset docvspanset = NULL;
            if (ispan2vspanset(sess, versionorgl, ispanset, &docvspanset)) {
                typevspec *s1 = (typevspec *) taskalloc(sess, sizeof(typevspec ));
                s1->itemid = VSPECID;

                *newspecsetptr = (typespecset) s1;
                s1->docisa     = ((typevspec *) specset)->docisa;
                s1->vspanset   = docvspanset;
                newspecsetptr  = (typespecset *) &s1->next;
            }
        }
    }

    *newspecsetptr = NULL;
}

/**********************************************************************
 *
 **********************************************************************/
    void
removespansnotinoriginal(Session *sess, typespecset original, typespecset *newptr)
{
    I(newptr && *newptr && original);

    typevspec *first = NULL;
    typevspec **nextptr = NULL;

    typespecset newspecset;
    for (newspecset = *newptr; newspecset; newspecset = (typespecset) ((typeitemheader *) newspecset)->next) {

        typespecset oldspecset;
        for (oldspecset = original; oldspecset; oldspecset = (typespecset) ((typeitemheader *) oldspecset)->next) {

            if (((typevspec *) newspecset)->docisa != ((typevspec *) oldspecset)->docisa)
                continue;

            typevspanset newspanset;
            if (intersectspansets(sess, ((typevspec *) newspecset)->vspanset, ((typevspec *) oldspecset)->vspanset, &newspanset, VSPANID)) {

                typevspec *okspec = (typevspec *) taskalloc(sess, sizeof(typevspec));
                okspec->itemid = VSPECID;

                okspec->docisa = ((typevspec *) newspecset)->docisa;
                okspec->vspanset = newspanset;

                if (!first)
                    first = okspec;
                else
                    *nextptr = okspec;

                nextptr = &okspec->next;
            }
        }
    }

    tfreeitemset(sess, (typeitemset) *newptr);
    *nextptr = NULL;
    *newptr = (typespecset) first;
}

/**********************************************************************
 *
 **********************************************************************/
    bool
intersectspansets(Session *sess, typespanset set1, typespanset set2, typespanset *set3, int spantype)
{
    I(set1 && set2 && set3);

    *set3 = NULL;
    for (; set1; set1 = set1->next) {
        typespan *p;
        for (p = set2; p; p = p->next) {
            if (comparespans(sess, set1, p, set3, spantype))
                set3 = &(*set3)->next;
        }
    }

    return true;
}

/**********************************************************************
 *
 **********************************************************************/
    bool
comparespans(Session *sess, typespan *span1, typespan *span2, typespan **span3, int spantype)
{
    if (span1->width.iszero() || span2->width.iszero())
        return false;

    *span3 = (typespan *) taskalloc(sess, sizeof(typespan));
    (*span3)->itemid = spantype;
    (*span3)->next = NULL;

    if (spanintersection(span1, span2, *span3))
        return true;

    else {
        tfreeexplicit(sess, (char *) *span3);
        *span3 = NULL;
        return false;
    }
}

/**********************************************************************
 *
 **********************************************************************/
    bool
spanintersection(typespan *aptr, typespan *bptr, typespan *cptr)
{
    cptr->stream.clear();
    cptr->width.clear();

    StreamAddr bend = bptr->stream + bptr->width;

    if (aptr->stream >= bend)
        return false;

    StreamAddr aend = aptr->stream + aptr->width;

    if (bptr->stream >= aend)
        return false;

    /* these following assignments are clearly wrong 12/4/84 */

    if (aptr->stream > bptr->stream) {
        cptr->stream = aptr->stream;

        if (aend > bend)
//            tumblersub(&bend, &aptr->stream, &cptr->width);
            cptr->width = bend - aptr->stream;

        else
            cptr->width = aptr->width;

    } else if (aptr->stream < bptr->stream) {
        cptr->stream = bptr->stream;

        if (aend < bend)
//            tumblersub(&aend, &bptr->stream, &cptr->width);
            cptr->width = aend - bptr->stream;

        else
            cptr->width = bptr->width;

    } else { /* this ones probably ok*/
        cptr->stream = aptr->stream;

        if (aend > bend)
            cptr->width = bptr->width;
        else
            cptr->width = aptr->width;
    }

    return true;
}

/**********************************************************************
 *
 **********************************************************************/
    void
makespanpairset(Session *sess, typeispanset ispanset, typespecset specset1, typespecset specset2, typespanpairset *pairsetptr)
{
    *pairsetptr = NULL;

    for (; ispanset; ispanset = ispanset->next) {
        StreamDiff iwidth = ispanset->width;

        typespanpairset pairset;
        makespanpairsforispan(sess, &iwidth, &specset1, &specset2, &pairset);
        *pairsetptr = pairset;
        pairsetptr = &pairset->nextspanpair;
    }

    *pairsetptr = NULL;
}

/**********************************************************************
 *
 **********************************************************************/
    void
makespanpairsforispan(Session *sess, Tumbler *iwidth, typespecset *specset1ptr, typespecset *specset2ptr, typespanpairset *pairsetptr)
{
//    int cmp;

    *pairsetptr = NULL;
    StreamAddr sum;
    sum.clear();

    typevspec *spec1 = (typevspec *) *specset1ptr;
    typespan *span1 = spec1->vspanset;
    typevspec *spec2 = (typevspec *) *specset2ptr;
    typespan *span2 = spec2->vspanset;

    while (span1 && span2 && *iwidth > sum) {
//        cmp = span1->width.compareTo(span2->width);

        if (span1->width > span2->width) {
            *pairsetptr = makespanpair(sess, &spec1->docisa, &span1->stream, &spec2->docisa, &span2->stream, &span2->width);

            sum = sum + span2->width;

            span1->stream = span1->stream + span2->width;

//            tumblersub(&span1->width, &span2->width, &span1->width);
            span1->width = span1->width - span2->width;

            span2 = span2->next;

	} else if (span1->width < span2->width) {
            *pairsetptr = makespanpair(sess, &spec1->docisa, &span1->stream, &spec2->docisa, &span2->stream, &span1->width);
            sum = sum + span1->width;

            span2->stream = span2->stream + span1->width;

//            tumblersub(&span2->width, &span1->width, &span2->width);
            span2->width = span2->width - span1->width;

            span1 = span1->next;

	} else {
            *pairsetptr = makespanpair(sess, &spec1->docisa, &span1->stream, &spec2->docisa, &span2->stream, &span1->width);
            sum = sum + span1->width;

            span2 = span2->next;
            span1 = span1->next;
	}

        spec1->vspanset = span1;
        spec2->vspanset = span2;

        if (!span1) {
            spec1 = spec1->next;
            *specset1ptr = (typespecset) spec1;
            if (spec1)
                span1 = spec1->vspanset;
        }

        if (!span2) {
            spec2 = spec2->next;
            *specset2ptr = (typespecset) spec2 ;
            if (spec2)
                span2 = spec2->vspanset;
        }

        pairsetptr = &(*pairsetptr)->nextspanpair;
    }
}

/**********************************************************************
 *
 **********************************************************************/
    typespanpair *
makespanpair(Session *sess, Tumbler *doc1, Tumbler *start1, Tumbler *doc2, Tumbler *start2, StreamDiff *width)
{
    typespanpair *spanpair = (typespanpair *) taskalloc(sess, sizeof(typespanpair));
    docidandvstream2tumbler(doc1, start1, &spanpair->stream1);
    docidandvstream2tumbler(doc2, start2, &spanpair->stream2);

    spanpair->widthofspan = *width;

    return spanpair;
}

/**********************************************************************
 *
 **********************************************************************/
    int   /* return LESS, EQUAL or GREATER */
spansubtract(typespan *aptr, typespan *bptr, typespan *cptr) /* no negative spans (whatever they may be) */
  /* all returned tumbler values are positive */
{
    if (aptr->width > bptr->width) {
        cptr->stream = aptr->stream + bptr->width;

//        tumblersub(&aptr->width, &bptr->width, &cptr->width);
        cptr->width = aptr->width - bptr->width;

        return +1;

    } else if (aptr->width < bptr->width) {
        cptr->stream = bptr->stream + aptr->width;

//        tumblersub(&bptr->width, &aptr->width, &cptr->width);
        cptr->width = bptr->width - aptr->width;

        return -1;

    } else {
        cptr->stream.clear();
        cptr->width.clear();
        return 0;
    }
}

/**********************************************************************
 *  Original Copyright � 1979-1999 Udanax.com.   All Rights Reserved
 **********************************************************************/
