/**
 * @file  split.cxx
 * @brief Routines to Split Overfull Loaves
 *
 * (to be defined)
 *
 **/

#include <nana/nana.h>  // GNU Assertion/Logging Tool

#include "xanadu.h"
#include "enf.h"

/**********************************************************************
 *
 **********************************************************************/
/* Should be called whenever a crum may have too many sons
**  if it does, it is split, and its father is checked, etc...
*/
    bool
splitcrumupwards(CoreUpperCrum *father)
{
    bool splitsomething;

    splitsomething = false;
    if (father->height <= 0)
        gerror("splitcrumupwards on bottom crum\n");

    for (; father->toomanysons(); father = father->father()) {
        if (father->isTopmost()) {
            levelpush(father);
            splitcrum((CoreUpperCrum *) father->leftSon());

#ifndef DISTRIBUTION
            cerr << "splitcrumupwards split something" << endl;
            asserttreeisok((CoreCrum *) father);
#endif
            return true;
        }
        splitcrum(father);
        splitsomething = true;
    }

    return splitsomething;
}

/**********************************************************************
 *
 **********************************************************************/
/* splits an individual crum */
    void
splitcrum(CoreUpperCrum *father)
{
    switch (father->cenftype) {
    case GRAN:  splitcrumseq(father);  break;
    case POOM:  splitcrumpm(father);   break;
    case SPAN:  splitcrumsp(father);   break;
    default:
        I(false); // Invalid Type of Enfilade
    }

    setwispupwards(father, 0);
}

/**********************************************************************
 *
 **********************************************************************/
    /* splits a crum for sequential enfilades */
    void
splitcrumseq(CoreUpperCrum *father)
{
    CoreCrum *newcrum, *ptr, *next;
    int i, halfsons;

    father->ivemodified();
    newcrum = ((Enfilade *) father)->createCrum(father->height, father->cenftype);
    newcrum->reserve();
    father->adoptAsRightBrother(newcrum);
    newcrum->rejuvinate();
    newcrum->ivemodified();

    halfsons = father->numberofsons / 2;

    for (i = 0, ptr = father->rightmostSon(); i < halfsons && ptr; ++i, ptr = next) {
        next = ptr->leftBrother();
        ptr->disown();
        newcrum->adoptAsLeftmostSon(ptr);
        ptr->rejuvinate();
        ptr->ivemodified(); /* zzz */
    }

     setwispupwards(father, 0);
    setwispupwards((CoreUpperCrum *) newcrum, 0);
}

/**********************************************************************
 *
 **********************************************************************/
    void
splitcrumsp(CoreUpperCrum *father)
{
    CoreCrum *ptr, *correctone;

    for (correctone = ptr = father->leftSon(); ptr; ptr = ptr->rightBrother()) {
        /* if (ptr->cdsp[SPANRANGE] > correctone->cdsp[SPANRANGE]) */
        if (comparecrumsdiagonally(ptr, correctone) == Tumbler::GREATER)
            correctone = ptr;
    }

    peelcrumoffnd(correctone);
}

/**********************************************************************
 *
 **********************************************************************/
    void
splitcrumpminthiscrum(CoreUpperCrum *father)
{
    for(; father; father = (CoreUpperCrum *) father->rightBrother()) {
        while (father->toomanysons())
            splitcrumpm(father);
    }
}

/**********************************************************************
 *
 **********************************************************************/
    void
splitcrumpm(CoreUpperCrum *father)
{
    CoreCrum *ptr, *correctone;

    for (correctone = ptr = father->leftSon(); ptr; ptr = (CoreUpperCrum *) ptr->rightBrother()) {
        if (ptr->cdsp[SPANRANGE] > correctone->cdsp[SPANRANGE])
            /* if (comparecrumsdiagonally(ptr, correctone) == LESS) */
            correctone = ptr;
    }

    peelcrumoffnd(correctone);
}

/**********************************************************************
 *
 **********************************************************************/
    void
peelcrumoffnd(CoreCrum *ptr)
{
    CoreUpperCrum *father;
    CoreCrum *newcrum;
    int ofatherage, optrage;

    I(!ptr->isTopmost());

    father       = ptr->father();
    ofatherage   = father->age;
    optrage      = ptr->age;
    father->age  = NEW;
    ptr->age     = NEW;

    father->reserve();

    father->modified = true; /* an uncle will get ivemodified shortly in 10 lines */
    ptr->reserve();
    ptr->disown();

    newcrum = ((Enfilade *) father)->createCrum(father->height, father->cenftype);
    father->adoptAsRightBrother(newcrum);

//    movedsp(&father->cdsp, &newcrum->cdsp); // Move a DSP/WISP
    newcrum->cdsp = father->cdsp; // Move a DSP/WISP

    newcrum->adoptAsLeftmostSon(ptr);
    newcrum->rejuvinate();
    ptr->rejuvinate();
    father->rejuvinate();

    if (ofatherage == RESERVED)
        father->age = RESERVED;

    if (optrage == RESERVED)
        ptr->age = RESERVED;

    ptr->ivemodified();
    setwispupwards(father, 0);
    setwispupwards((CoreUpperCrum *) newcrum, 0);
    setwispupwards((CoreUpperCrum *) ptr, 1);
}

/**********************************************************************
 *  Original Copyright � 1979-1999 Udanax.com.   All Rights Reserved
 **********************************************************************/
