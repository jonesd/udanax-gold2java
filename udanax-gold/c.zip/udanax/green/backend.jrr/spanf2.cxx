/**
 * @file  spanf2.cxx
 * @brief Lower-Level Spanfilade Calls
 *
 * (to be defined)
 *
 **/

#include <nana/nana.h>  // GNU Assertion/Logging Tool

#include "xanadu.h"
#include "enf.h"

/**********************************************************************
 *
 **********************************************************************/
    bool
isinlinklist(typelinkset linkset, IStreamAddr *linkisaptr)
{
    for (; linkset; linkset = linkset->next) {
        if (linkset->address == *linkisaptr)
            return true;
    }

    return false;
}

/**********************************************************************
 *
 **********************************************************************/
    void
onlinklist(Session *sess, typelinkset *linksetptr, IStreamAddr *linkisaptr)
{
    typelink *linkset, *temp, *nextlink;

    linkset = makelinkitem(sess, linkisaptr);

    if (*linksetptr == NULL) {
        *linksetptr = linkset;
        return;
    }

    for (temp = *linksetptr; (nextlink = temp->next) != NULL; temp = nextlink) {
        if (temp->address == *linkisaptr)
            return;
    }

    temp->next = linkset;
}

/**********************************************************************
 *
 **********************************************************************/
    void
intersectlinksets(Session *sess, typelinkset linkset1, typelinkset linkset2, typelinkset linkset3, typelinkset *linkset4ptr)
{
    typelinkset linkset4;
    typelinkset temp2;
    typelinkset temp3;
    bool olddebug = debug;

    /* If only one linkset is non-null, then just use it */

    if (linkset1 && !linkset2 && !linkset3)
        *linkset4ptr = linkset1;
    else if (!linkset1 && linkset2 && !linkset3)
        *linkset4ptr = linkset2;
    else if (!linkset1 && !linkset2 && linkset3)
        *linkset4ptr = linkset3;
    else
        *linkset4ptr = NULL;

    if (*linkset4ptr) {
        debug = olddebug;
        return;
    }

    /* At least two linksets aren't null */
    /* If only two are, put them in temp1 and linkset2 */

    typelinkset temp1 = NULL;

    if (linkset1)
        temp1 = linkset1;

    if (linkset1 && !linkset2 && linkset3) {
        linkset2 = linkset3;
        linkset3 = NULL;

    } else if (!linkset1 && linkset2 && linkset3) {
        temp1 = linkset3;
        linkset3 = NULL;
    }

    if (!linkset3) {
        for (; temp1; temp1 = temp1->next) {
            for (temp2 = linkset2; temp2; temp2 = temp2->next) {
                if (temp1->address == temp2->address) {
                    linkset4 = makelinkitem(sess, &temp1->address);
                    *linkset4ptr = linkset4;
                    linkset4ptr = &linkset4->next;
                }
            }
        }
    } else {
        for (; temp1; temp1 = temp1->next) {
            for (temp2 = linkset2; temp2; temp2 = temp2->next) {
                for (temp3 = linkset3; temp3; temp3 = temp3->next) {
                    if (temp1->address == temp2->address && temp2->address == temp3->address) {
                        linkset4     = makelinkitem(sess, &temp1->address);
                        *linkset4ptr = linkset4;
                        linkset4ptr  = &linkset4->next;
                    }
                }
            }
        }
    }

    debug = olddebug;
}

/**********************************************************************
 *
 **********************************************************************/
    typelink *
makelinkitem(Session *sess, IStreamAddr *linkisa)
{
    typelink *link;

#ifndef DISTRIBUTION
    cerr << "makelinkitem" << *linkisa;
#endif

    link = (typelink *) taskalloc(sess, sizeof(typelink));

//    movetumbler(linkisa, &link->address);
    link->address = *linkisa;

    link->itemid = LINKID;
    link->next = NULL;

    return link;
}

/**********************************************************************
 *  Original Copyright � 1979-1999 Udanax.com.   All Rights Reserved
 **********************************************************************/
