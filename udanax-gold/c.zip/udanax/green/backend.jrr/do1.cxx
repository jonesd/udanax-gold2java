/**
 * @file  do1.cxx
 * @brief Document Handling Routines
 *
 * (to be defined)
 *
 **/

#include <nana/nana.h>  // GNU Assertion/Logging Tool

#include "xanadu.h"
#include "enf.h"
#include "players.h"

/**********************************************************************
 *
 **********************************************************************/
    bool
dofinddocscontaining(Session *sess, typespecset specset, typelinkset *addresssetptr)
{
    typeispanset ispanset;

    return specset2ispanset(sess, specset, &ispanset, NOBERTREQUIRED)
        && finddocscontainingsp(sess, ispanset, addresssetptr);
}

/**********************************************************************
 *
 **********************************************************************/
    bool
doappend(Session *sess, IStreamAddr *docptr, typetextset textset)
{
    return appendpm(sess, docptr, textset)/*&&
       appendpm includes insertspanf!	 insertspanf(sess,spanf,docptr,textset,DOCISPAN)*/
	;
}

/**********************************************************************
 *
 **********************************************************************/
    bool
dorearrange(Session *sess, IStreamAddr *docisaptr, typecutseq *cutseqptr)
{
    typeorgl docorgl;

    return findorgl(sess, granf, docisaptr, &docorgl, WRITEBERT)
	&& rearrangepm (sess, docisaptr, docorgl, cutseqptr)
	/*&& true*/ /* ht stuff */ ;
}

/**********************************************************************
 *
 **********************************************************************/
    bool
docopy(Session *sess, IStreamAddr *docisaptr, VStreamAddr *vsaptr, typespecset specset)
{
    typeispanset ispanset;
    /* IStreamAddr htisa; */
    typeorgl docorgl;

    return specset2ispanset(sess, specset, &ispanset, NOBERTREQUIRED)
	&& findorgl(sess, granf, docisaptr, &docorgl, WRITEBERT)
	&& acceptablevsa(vsaptr, docorgl)
	&& asserttreeisok((CoreCrum *) docorgl)

	/* the meat of docopy: */
        && insertpm(sess, docisaptr, docorgl, vsaptr, (typesporglitem *) ispanset)

	&&  insertspanf(sess, spanf, docisaptr, (typesporglitem *) ispanset, DOCISPAN)
	&& asserttreeisok((CoreCrum *) docorgl)
        /* &&  ht stuff */ ;
}

/**********************************************************************
 *
 **********************************************************************/
    bool
docopyinternal(Session *sess, IStreamAddr *docisaptr, VStreamAddr *vsaptr, typespecset specset)
{
    typeispanset ispanset;
    /*  IStreamAddr htisa;      */
    typeorgl docorgl;

    return specset2ispanset (sess, specset, &ispanset, NOBERTREQUIRED)
	&& findorgl (sess, granf, docisaptr, &docorgl, NOBERTREQUIRED)
	&& acceptablevsa (vsaptr, docorgl)
	&& asserttreeisok((CoreCrum *) docorgl)

	/* the meat of docopy: */
	&& insertpm (sess, docisaptr, docorgl, vsaptr, (typesporglitem *) ispanset)

	&&  insertspanf (sess, spanf, docisaptr, (typesporglitem *) ispanset, DOCISPAN)
	&& asserttreeisok((CoreCrum *) docorgl)
/*      &&  ht stuff */ ;
}

/**********************************************************************
 *
 **********************************************************************/
typespec      spec,spec2,spec3;
typevstuffset uppervstuffset;

//Tumbler fivetumbler = { 0,0,  0,0,0,500/*100*/,0,0,0,0,0,0,0 };

    bool
doinsert(Session *sess, IStreamAddr *docisaptr, VStreamAddr *vsaptr, typetextset textset)
{
    typespanset ispanset;
/* these defs for debug*/
/*  typespan thisspan;*/
  int ret;
/*  int temp;*/

/*if(debug){ 
debug = false;
spec.docisa = *docisaptr;
((typeitemheader)spec).next = NULL;
spec.itemid = VSPECID;
spec.vspanset = &thisspan;
thisspan.itemid = VSPANID;
thisspan.next = NULL;
temp = vsaptr->mantissa[1];
thisspan.stream = *vsaptr;
thisspan.width = fivetumbler;
spec.vspanset->stream.mantissa[1] =1// +=5//;
copyspecset(sess,&spec,&spec2);
copyspecset(sess,&spec,&spec3);
spec3.vspanset->stream.mantissa[1] += textset->length;
doretrievev(sess,&spec2,&uppervstuffset);
vsaptr->mantissa[1] = temp;
debug = true;
}*/

        Hint hint(DOCUMENT, ATOM, TEXTATOM, docisaptr);
	ret = (inserttextingranf(sess, granf, &hint, textset, &ispanset)
		&& docopy(sess, docisaptr, vsaptr, (typespec *) ispanset)
	/* no ht stuff here, 'cause it's taken care of in */
	/*   docopy */ );

    return ret;
}

/**********************************************************************
 *
 **********************************************************************/
    void
checkspecandstringbefore()
{
    return;
    /*if(debug){ assertspecisstring(&spec2,uppervstuffset->xxtest.string); }*/
}

/**********************************************************************
 *
 **********************************************************************/
    void
copyspecset(Session *sess, typespec *specptr, typespec *newptr)
{
    if (specptr == NULL)
        return;

    typespec  *thisspec = newptr;
    for ( ; specptr; specptr = (typespec *) ((typeitemheader *) specptr)->next, thisspec = (typespec *) talloc(sess, sizeof(typespec))) {
        *thisspec = *specptr;
        copyspanset(sess, ((typevspec *) specptr)->vspanset, &((typevspec *) thisspec)->vspanset);
    }

    ((typeitemheader *) thisspec) -> next = NULL;
}

/**********************************************************************
 *
 **********************************************************************/
    void
copyspanset(Session *sess, typespan *spanptr, typespan **newptrptr)
{
    typespan  *thisspan = (typespan *) talloc(sess, sizeof(typespan));

    *newptrptr = thisspan;
    for (; spanptr; spanptr = spanptr->next, thisspan->next = (typespan *) talloc(sess, sizeof(typespan)))
        *thisspan = *spanptr;

    thisspan->next = NULL;
}
 
/**********************************************************************
 *
 **********************************************************************/
    bool
dodeletevspan(Session *sess, IStreamAddr *docisaptr, typevspan *vspanptr)
{
  typeorgl docorgl;

	return (
	   findorgl (sess, granf, docisaptr, &docorgl, WRITEBERT)
	&& deletevspanpm (sess, docisaptr, docorgl, vspanptr)
	/*&& true*/ /* ht stuff */ );
}

/**********************************************************************
 *
 **********************************************************************/
    bool
domakelink (Session *sess, IStreamAddr *docisaptr, typespecset fromspecset, typespecset tospecset, IStreamAddr *linkisaptr)
{
    VStreamAddr linkvsa, fromvsa, tovsa;
    typespanset ispanset;
    typesporglset fromsporglset;
    typesporglset tosporglset;
    typeorgl link;

    Hint hint(DOCUMENT, ATOM, LINKATOM, docisaptr);

    return   createorglingranf(sess, granf, &hint, linkisaptr)
	  && tumbler2spanset(sess, linkisaptr, &ispanset)
	  && findnextlinkvsa(sess, docisaptr, &linkvsa)
	  && docopy(sess, docisaptr, &linkvsa, (typespec *) ispanset)
	  && findorgl(sess, granf, linkisaptr, &link, WRITEBERT)
	  && specset2sporglset(sess, fromspecset, &fromsporglset, NOBERTREQUIRED)
	  && specset2sporglset(sess, tospecset, &tosporglset, NOBERTREQUIRED)
	  && setlinkvsas(&fromvsa, &tovsa, NULL)
	  && insertendsetsinorgl(sess, linkisaptr, link, &fromvsa, fromsporglset, &tovsa, tosporglset, NULL, NULL)
	  && insertendsetsinspanf(sess, spanf, linkisaptr, fromsporglset, tosporglset, NULL);
}

/**********************************************************************
 *
 **********************************************************************/
    bool
docreatelink(Session *sess, IStreamAddr *docisaptr, typespecset fromspecset, typespecset tospecset, typespecset threespecset, IStreamAddr *linkisaptr)
{
    VStreamAddr linkvsa, fromvsa, tovsa, threevsa;
    typespanset ispanset;
    typesporglset fromsporglset;
    typesporglset tosporglset;
    typesporglset threesporglset;
    typeorgl link;

    Hint hint(DOCUMENT, ATOM, LINKATOM, docisaptr);

    return   createorglingranf(sess, granf, &hint, linkisaptr)
	  && tumbler2spanset(sess, linkisaptr, &ispanset)
	  && findnextlinkvsa(sess, docisaptr, &linkvsa)
	  && docopy(sess, docisaptr, &linkvsa, (typespec *) ispanset)
	  && findorgl(sess, granf, linkisaptr, &link,/*WRITEBERT ECH 7-1*/NOBERTREQUIRED)
	  && specset2sporglset(sess, fromspecset, &fromsporglset,NOBERTREQUIRED)
	  && specset2sporglset(sess, tospecset, &tosporglset,NOBERTREQUIRED)
	  && specset2sporglset(sess, threespecset, &threesporglset,NOBERTREQUIRED)
	  && setlinkvsas(&fromvsa, &tovsa, &threevsa)
	  && insertendsetsinorgl(sess, linkisaptr, link, &fromvsa, fromsporglset, &tovsa, tosporglset, &threevsa, threesporglset)
	  && insertendsetsinspanf(sess, spanf, linkisaptr, fromsporglset, tosporglset, threesporglset);
}

/**********************************************************************
 *
 **********************************************************************/
    bool
dofollowlink(Session *sess, IStreamAddr *linkisaptr, typespecset *specsetptr, int whichend)
{
  typesporglset sporglset;

	return (
	   link2sporglset (sess, linkisaptr, &sporglset, whichend,NOBERTREQUIRED)
	&& linksporglset2specset (sess,&((typesporgl *)sporglset)->sporgladdress, sporglset, specsetptr,/* ECH 6-29 READBERT */NOBERTREQUIRED));

}

/**********************************************************************
 *
 * Create a new document under the account and node of the user who
 * issued the request.  Return the global identifier for the document.
 *
 * This request creates the document but does not open it for access;
 * you must issue an open request (see below) to access the data in
 * the new document.
 **********************************************************************/
    bool
docreatenewdocument(Session *sess, IStreamAddr *isaptr)
{
    Hint hint(ACCOUNT, DOCUMENT, 0, &sess->account);
    return createorglingranf(sess, granf, &hint, isaptr);
}

/**********************************************************************
 *
 * Declare that id-account is a legal account or node. If id-account
 * is an account tumbler, then the backend creates the account.  If
 * it is a node tumbler, then the backend reassigns its own address
 * to id-account.
 **********************************************************************/
    bool
docreatenode_or_account(Session *sess, IStreamAddr *isaptr)
{
    IStreamAddr isa;

//    tumblercopy(isaptr, &isa);
    isa = *isaptr;

    Hint hint(NODE, NODE, 0, /*&sess->account*/ &isa);
    return createorglingranf(sess, granf, &hint, &isa);
}

/**********************************************************************
 *
 **********************************************************************/
    bool
docreatenewversion(Session *sess, IStreamAddr *isaptr, IStreamAddr *wheretoputit, IStreamAddr *newisaptr)
{
    typevspan  vspan;
    typevspec  vspec;
    IStreamAddr newtp; /* for internal open */

    /* ECH 7-13 introduced test for ownership to do right thing for explicit creation
     * of new version of someone else's document
     */

    if (tumbleraccounteq(isaptr, wheretoputit) && isthisusersdocument(isaptr)) {
        Hint hint(DOCUMENT, DOCUMENT, 0, isaptr/*wheretoputit*/);
        if (!createorglingranf(sess, granf, &hint, newisaptr))
            return false;

    } else {
        /* This does the right thing for new version of someone else's document, as
         * it duplicates the behavior of docreatenewdocument
         */

        Hint hint(ACCOUNT, DOCUMENT, 0, wheretoputit);
        if (!createorglingranf(sess, granf, &hint, newisaptr))
            return false;
    }

    if (!doretrievedocvspanfoo(sess, isaptr, &vspan))
        return false;

    vspec.next = NULL;
    vspec.itemid = VSPECID;

//    movetumbler(isaptr, &vspec.docisa);
    vspec.docisa = *isaptr;

    vspec.vspanset = &vspan;

    /* BERTMODEONLY to prevent recursive createnewversions */
    if (!doopen(sess, newisaptr, &newtp, WRITEBERT, BERTMODEONLY, user)) {
#ifndef DISTRIBUTION
        cerr << endl << "isaptr-> "       << *isaptr
             << endl << "wheretoputit-> " << *wheretoputit
             << endl << "newisaptr-> "    << *newisaptr
             << endl << "newtp: "         << newtp << endl;

        gerror("Couldn't do internal doopen for new doc in docreatenewversion\n");
#else
        gerror("");
#endif
    }

    docopyinternal(sess, newisaptr, (VStreamAddr *) &vspan.stream, (typespec *) &vspec);
    doclose(sess, newisaptr, user);

    return true;
}

/**********************************************************************
 *
 **********************************************************************/
    bool
doretrievedocvspanfoo(Session *sess, IStreamAddr *docisaptr, typevspan *vspanptr) /* Internal routine, no open required */
{/* this routine is a kluge not yet kluged*/
  typeorgl docorgl;

	return (
	   findorgl (sess, granf, docisaptr, &docorgl, NOBERTREQUIRED)
	&& retrievedocumentpartofvspanpm (sess, docorgl, vspanptr) );
}

/**********************************************************************
 *
 **********************************************************************/
    bool
doretrievedocvspan(Session *sess, IStreamAddr *docisaptr, typevspan *vspanptr)
{
    typeorgl docorgl;

    return findorgl(sess, granf, docisaptr, &docorgl, READBERT)
        && retrievevspanpm(sess, docorgl, vspanptr);
}

/**********************************************************************
 *
 **********************************************************************/
    bool
doretrievedocvspanset(Session *sess, IStreamAddr *docisaptr, typevspanset *vspansetptr)
{
  typeorgl docorgl;

	return
	   findorgl (sess, granf, docisaptr, &docorgl, READBERT)
	&& !isemptyorgl (docorgl)
	&& retrievevspansetpm (sess, docorgl, vspansetptr);
}

/**********************************************************************
 *
 **********************************************************************/
    bool
doretrievev(Session *sess, typespecset specset, typevstuffset *vstuffsetptr)
{
  typeispanset ispanset;

	return
	   specset2ispanset (sess, specset, &ispanset,READBERT)
	&& ispanset2vstuffset (sess, granf, ispanset, vstuffsetptr);
}

/**********************************************************************
 *
 **********************************************************************/
    bool
dofindlinksfromtothree(Session *sess, typespecset fromvspecset, typespecset tovspecset, typespecset threevspecset, typeispan *orglrangeptr, typelinkset *linksetptr)
{
    return findlinksfromtothreesp(sess, spanf, fromvspecset, tovspecset, threevspecset, orglrangeptr, linksetptr);
}

/**********************************************************************
 *
 **********************************************************************/
    bool
dofindnumoflinksfromtothree(Session *sess, typespecset *fromvspecset, typespecset *tovspecset, typespecset *threevspecset, typeispan *orglrangeptr, int *numptr)
{
    return findnumoflinksfromtothreesp(sess, spanf, *fromvspecset, *tovspecset, *threevspecset, orglrangeptr, numptr);
    //jrr: something is wierd here re the vspecsets.  The code had to be modified to compile w/protos.
}

/**********************************************************************
 *
 **********************************************************************/
    bool
dofindnextnlinksfromtothree(Session *sess, typevspec *fromvspecptr, typevspec *tovspecptr, typevspec *threevspecptr,
      typeispan *orglrangeptr, IStreamAddr *lastlinkisaptr, typelinkset *nextlinksetptr, int *nptr)
{
    return findnextnlinksfromtothreesp(sess, (typespec *) fromvspecptr, (typespec *) tovspecptr, (typespec *) threevspecptr, orglrangeptr, lastlinkisaptr, nextlinksetptr, nptr);
}

/**********************************************************************
 *
 **********************************************************************/
    bool
doretrieveendsets(Session *sess, typespecset specset, typespecset *fromsetptr, typespecset *tosetptr, typespecset *threesetptr)
{
    return retrieveendsetsfromspanf(sess, specset, fromsetptr, tosetptr, threesetptr);
}

/**********************************************************************
 *
 **********************************************************************/
    bool
doshowrelationof2versions(Session *sess, typespecset version1, typespecset version2, typespanpairset *relation)
{
    typeispanset version1ispans = NULL;
    typeispanset version2ispans = NULL;
    typeispanset commonispans = NULL;

    return
		specset2ispanset(sess, version1, &version1ispans, READBERT)
	  &&    specset2ispanset(sess, version2, &version2ispans, READBERT)
	  &&    intersectspansets(sess, version1ispans, version2ispans, &commonispans, ISPANID)
	  &&    ispansetandspecsets2spanpairset(sess, commonispans, version1, version2, relation)
	;
}

 
/* --------------- punt line ----------------- */

/* donavigateonht */

/**********************************************************************
 *  Original Copyright � 1979-1999 Udanax.com.   All Rights Reserved
 **********************************************************************/
