/**
 * @file  be.cxx
 * @brief Main -- Single-User Backend
 *
 * (to be defined)
 *
 **/
 
#include <time.h>
#include <iostream>
#include <fstream>

#include <nana/nana.h>  // GNU Assertion/Logging Tool

#include "xanadu.h"
#include "requests.h"
#include "players.h"
#include "allocio.h"
#include "cacheio.h"

#define MAX_PLAYERS 5

extern BitmapAllocIO *aio;
extern MMapCacheIO   *cio;

int user = 0;
PLAYER player[MAX_PLAYERS];

FILE   *logfile = NULL;
FILE   *nulllog = NULL;
FILE   *reallog = NULL;
bool    isxumain = false;
char    outputbuffer[BUFSIZ];
char    inputbuffer[BUFSIZ];
bool    logstuff;

//FILE   *interfaceinput = NULL;
ifstream interfaceinput;

FILE   *febelog = NULL;
extern bool firstputforrequest;
Session *taskptrx;
IStreamAddr defaultaccount("1.1.0.1");
long ntaskorcommand; // Part of Main
int debug; // Part of Main

static void xanadu(Session *taskptr);
static bool establishprotocol(FILE *inp, FILE *outp);

/**********************************************************************
 *
 **********************************************************************/
    int
main(int argc, char *argv[])
{
    cout << "Hello" << endl;

    MMapCacheIO    *cio = new MMapCacheIO(4096);
    BitmapAllocIO  *aio = NULL;

    CacheIO::OpenStatus ostat = cio->open("enf.enf");
    switch (ostat) {
    case BlockIO::OS_CREATED:
        aio = new BitmapAllocIO(*cio);
//        granf = Enfilade1d::create();
//        spanf = Enfilade2d::create(SPAN);
        break;

    case BlockIO::OS_OPENED:
        aio = new BitmapAllocIO(*cio);
//        initkluge((CoreUpperCrum **) &granf, (CoreUpperCrum **) &spanf);
        break;

    case BlockIO::OS_FAILED:
        perror("initenffile");
//        gerror("cant open enf.enf or creatit");
        break;
    }

    cout << "Block Stats: " << aio->blocksFree() << " Free of " << aio->blocksTotal() << endl;

    BlockNum b1 = aio->allocBlock();
    void *p = cio->grabBlock(b1);
    strcpy((char *)p, "Block1");
    cio->ungrabBlock(b1, CacheIO::DIRTY);

    int x;
    for (x = 8; x < 16; x++) {
        void *q = cio->grabBlock(x);
        cout << "    Data: " << (char *) q << endl;
        cio->ungrabBlock(x);
    }

    for (x = 8; x < 16; x++)
        aio->freeBlock(x);

//    aio->isBlockFree(blocknum);
//    aio->validDataBlockNum(blocknum);
//
//    aio->freeBlock(blocknum);

//    cio->ungrabBlock(blocknum, BlockState state=CLEAN);
//    cio->ungrabBlock(void *buf, BlockState state=CLEAN);


    delete aio;
    cio->close();
    delete cio;

    return 0;



    struct tm *local;

    Session task;
    taskptrx = &task;

    interfaceinput.open("/dev/null", ios::in);

    febelog = reallog = logfile = nulllog = fopen("/dev/null", "a");

    long clock = time(0);
    local = localtime(&clock);
    char buf[100];
    sprintf(buf, "ln%d.%d.%d:%d", local->tm_mon+1, local->tm_mday, local->tm_hour, local->tm_min);

/*
#ifndef DISTRIBUTION
    sprintf(buf, "febe%d.%d.%d:%d", local->tm_mon+1, local->tm_mday, local->tm_hour, local->tm_min);
    febelog = fopen(buf, "w");
#endif
*/

    freopen("backenderror", "w", stderr);               /* CHANGE THIS ?? */
    setbuf(stderr, NULL);
    processrcfile();

    setbuf(stdin, inputbuffer);
    setbuf(stdout, outputbuffer);

    if (!establishprotocol(stdin, stdout))
        exit(1);

    debug = false;

    init(1);
    inittask(&task);

    initmagicktricks();

//    movetumbler(&defaultaccount, &task.account);
    task.account = defaultaccount;

    for (;;) {
        ntaskorcommand++;
        xanadu(&task);
        /* testforreservedness("main"); */
        logfile = nulllog;
    }

    /* lookatalloc(); */
}

/**********************************************************************
 *
 **********************************************************************/
    static void
xanadu(Session *taskptr)
{
    typerequest request;

    if (febelog && febelog != nulllog)
        fprintf(febelog, "\nfe:\n");

    firstputforrequest = true;
    logstuff = false;

    if (getrequest(taskptr, &request)) {
        (*requestfns[request])(taskptr);
        sendresultoutput(taskptr);
    } else
        taskptr->inp = cin;

    tfree(taskptr);

    /* lookatalloc(); */

//    if (interfaceinput.good() /* && interfaceinput.filedesc() != nulllog */)
//        interfaceinput << flush;

    logstuff = false;
}

/**********************************************************************
 *
 **********************************************************************/
    static bool
establishprotocol(FILE *inp, FILE *outp)
{
    char      ch;
    Session  temptask;

    if (febelog && febelog != nulllog)
        fprintf(febelog, "fe:\n");

    firstputforrequest = true;

    /* This is the metaprotocol for the time being */

    temptask.inp  = cin;
    temptask.outp = cout;
    temptask.errp = cerr;

    while ((ch = pullc(&temptask)) != '\n')
        ;

    while ((ch = pullc(&temptask)) == '\n')
        ;

    if (ch == 'P' && pullc(&temptask) == '0' && pullc(&temptask) == '~') {
        temptask.outp << endl << "P0~";
        sendresultoutput(&temptask);
        return true;
    } else {
        temptask.outp << endl << "P?~";
        sendresultoutput(&temptask);
        return false;
    }
}

/**********************************************************************
 *
 **********************************************************************/
    void
frontenddied()
{
    cerr << "The frontend apparently has died." << endl;
    diskexit();
    gerror("The frontend died");
}


/**********************************************************************
 *
 **********************************************************************/
/* for  linker until we get this cleaned up */
    bool
setmaximumsetupsize(Session *taskptr)
{
    return false;
}

/**********************************************************************
 *
 **********************************************************************/
    void
sourceunixcommand(Session *taskptr)
{
}

/**********************************************************************
 *
 **********************************************************************/
    bool
decrementusers()
{
    return false;
}

/**********************************************************************
 *
 **********************************************************************/
    bool
isthisusersdocument(Tumbler *tp)
{
    bool result = tumbleraccounteq(tp, &taskptrx->account);
    //jrr: logic seems reversed here -- double check it !!

    return result;
}

/**********************************************************************
 *  Original Copyright � 1979-1999 Udanax.com.   All Rights Reserved
 **********************************************************************/
