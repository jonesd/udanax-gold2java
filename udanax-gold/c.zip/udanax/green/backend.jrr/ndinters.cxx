/**
 * @file  ndinters.cxx
 * @brief ???
 *
 * (to be defined)
 *
 **/

#include <nana/nana.h>  // GNU Assertion/Logging Tool

/* ndinters.d - nd enfilade cut routines - file #2 */

#include "xanadu.h"
#include "enf.h"
#include "ndenf.h"
#include "knives.h"

/**********************************************************************
 *
 **********************************************************************/
 /* given fullcrumptr & knives
** sets *ptrptr & *offset to be cuc which contains all
**   space between the cuts
*/

/*
 *    void
 *findintersectionnd(CoreUpperCrum *fullcrumptr, Knives *knives, CoreUpperCrum **ptrptr, Widener *offset)
 *{
 *    CoreCrum *ptr, *next;
 *
 *    CoreCrum *findthecutsonnd();
 *
 *    memset(offset, 0, sizeof(*offset));
 *    ptr = fullcrumptr;
 *
 *    for (;;) { // descend down the generations //
 *        if ((next = findthecutsonnd(ptr, offset, knives)) == NULL)
 *            break;
 *
 *        lockadd(offset, &ptr->cdsp, offset, dspsize(ptr->cenftype));
 *        ptr = next;
 *    }
 *
 *    *ptrptr = ptr;
 *    // offset is already set appropriately //
 *}
 */

/**********************************************************************
 *
 **********************************************************************/
    void
newfindintersectionnd(CoreUpperCrum *fullcrumptr, Knives *knives, CoreUpperCrum **ptrptr, Displacer *offset)
{
    *ptrptr = fullcrumptr;

    memset(offset, 0, sizeof(*offset));
}

/**********************************************************************
 *
 **********************************************************************/

/*
 *    CoreCrum *
 *findthecutsonnd(CoreCrum *father, Widener *offset, Knives *knives)
 *{
 *    Displacer  grasp;
 *    CoreCrum  *ptr, *cutcrum;
 *
 *    // note that intersection can't be bottom crum //
 *    if (father->height == 1 || (ptr = findleftson(father)) == NULL)
 *        return NULL;
 *
 *    prologuend(father, offset, &grasp, NULL);
 *    cutcrum = NULL;
 *
 *    for (; ptr; ptr = ptr->rightBrother()) {
 *        if (cutinthiscrumnd(ptr, &grasp, knives)) {
 *            if (cutcrum) // cuts thru > 1 //
 *                return NULL;
 *            else  // first that cuts thru //
 *                cutcrum = ptr;
 *        }
 *    }
 *
 *    if (!cutcrum) // cuts thru none of them //
 *        return NULL;
 *
 *    if (!allcutswiththiscrumnd(cutcrum, &grasp, knives))
 *        return NULL; // missed some somehow //
 *
 *    return cutcrum;
 *}
 */

/**********************************************************************
 *
 **********************************************************************/
/* is true if satisfied on ANY cuts
** is ONLY satisfied by cuts within
*/
    bool
cutinthiscrumnd(CoreCrum *ptr, Displacer *offset, Knives *knives)
{
    int i;

    for (i = 0; i < knives->nblades; ++i) {
        if (whereoncrum(ptr, offset, &knives->blade[i], knives->dimension) == THRUME)
            return true;
    }

    return false;
}

/**********************************************************************
 *
 **********************************************************************/
/* is true only if satisfied on ALL cuts.
** is satisfied by cut at edge as well as within.
*/

/*
 *    //new version//  bool
 *allcutswiththiscrumnd(CoreCrum *ptr, Widener *offset, Knives *knives)
 *{
 *    int i, cmp;
 *
 *    for (i = 0; i < knives->nblades; ++i) {
 *        cmp = whereoncrum(ptr, offset, &knives->blade[i], knives->dimension);
 *
 *        if (cmp == TOMYLEFT || cmp == TOMYRIGHT)
 *            return false;
 *    }
 *
 *    return true;
 *}
 */

/**********************************************************************
 *
 **********************************************************************/
    bool     /* old version*/
allcutswiththiscrumnd(CoreCrum *ptr, Displacer *offset, Knives *knives)
{
    Tumbler  cut;
    int      i, cmp;

    for (i = 0; i < knives->nblades; ++i) {
//        tumblercopy(&knives->blade[i], &cut);
        cut = knives->blade[i];

        cmp = whereoncrum(ptr, offset, &cut, knives->dimension);
        if (cmp == TOMYLEFT || cmp == TOMYRIGHT)
            return false;

    }

    return true;
}

/**********************************************************************
 *  Original Copyright � 1979-1999 Udanax.com.   All Rights Reserved
 **********************************************************************/
