/**
 * @file  granf.cxx
 * @brief Granfilade Calls
 *
 * (to be defined)
 *
 **/

#include <nana/nana.h>  // GNU Assertion/Logging Tool

#include "xanadu.h"
#include "enf.h"
#include "players.h"

int backenddaemon = 0;

//extern bool isxumain;

/**********************************************************************
 *  Find ORGL within Enfilade1d Tree
 **********************************************************************/
    bool
findorgl(Session *sess, Enfilade1d *granfptr, IStreamAddr *isaptr, typeorgl *orglptr, int type)/*BERT*/
{
    int temp;

    if (/*backenddaemon &&*/ (temp = checkforopen(isaptr, type, user)) <= 0) {
        cerr << "orgl for " << *isaptr;
        cerr << " not open in findorgl temp = " << temp << endl;
        return false;
        /*gerror("Temporary crash in findorgl\n");*/
        /* ECH ?? or should I simply return false? */
    }

    *orglptr = fetchorglgr(sess, granfptr, isaptr);
    return *orglptr ? true : false;
}

/**********************************************************************
 *
 **********************************************************************/
    bool
inserttextingranf(Session *sess, Enfilade1d *granfptr, Hint *hintptr, typetextset textset, typeispanset *ispansetptr)
{
    return inserttextgr(sess, granfptr, hintptr, textset, ispansetptr);
}

/**********************************************************************
 *
 **********************************************************************/
    bool
createorglingranf(Session *sess, Enfilade1d *granfptr, Hint *hintptr, IStreamAddr *isaptr)
{
    return createorglgr(sess, /*GRR not defd (CoreUpperCrum*)*/ granfptr, hintptr, isaptr);
}

/**********************************************************************
 *
 **********************************************************************/
    bool
ispanset2vstuffset(Session *sess, Enfilade1d *granfptr, typeispanset ispanset, typevstuffset *vstuffsetptr)
{
    for (*vstuffsetptr = NULL; ispanset; ispanset = ispanset->next)
        vstuffsetptr = ispan2vstuffset(sess, granfptr, ispanset, vstuffsetptr);

    return true;
}

/**********************************************************************
 *
 **********************************************************************/
    typeorgl
fetchorglgr(Session *sess, Enfilade1d *fullcrumptr, IStreamAddr *address)
{
    CrumContext *context;

    if (fullcrumptr->cwid[WIDTH] < *address)
        return NULL;

    if ((context = fullcrumptr->locate(address)) == NULL)
        return NULL;

    if (context->totaloffset[0] != *address) {
        delete context;
        return NULL;
    }

    if (!context->corecrum->cinfo.granstuff.orglstuff.orglptr
    && context->corecrum->cinfo.granstuff.orglstuff.diskorglptr.diskblocknumber == NULLBLOCKNUM) {
        gerror("No orgl core ptr when diskptr is null.\n");
    }

    CoreUpperCrum *ret;
    if (context->corecrum->cinfo.infotype == CoreBottomCrum::GRANORGL) {
        if (!context->corecrum->cinfo.granstuff.orglstuff.orglincore) {
            if (context->corecrum->cinfo.granstuff.orglstuff.diskorglptr.diskblocknumber == NULLBLOCKNUM) {
                gerror("fetchorglgr null diskorglptr\n");
            }
            inorgl(context->corecrum);
        }

        ret = context->corecrum->cinfo.granstuff.orglstuff.orglptr;

        if (!ret) {
            gerror("fetchorglgr null orglptr\n");
        }
    } else {
        dump((CoreCrum *) context->corecrum);
        qerror("I should have found an orgl in fetchorglgr\n");
        return NULL;
    }

    delete context;
    ret->rejuvinate();

    return (typeorgl) ret;
}

/**********************************************************************
 *  Insert Invariant-Bytes into the IStream, via the Grand Enfilade
 **********************************************************************/
    bool
inserttextgr(Session *sess, Enfilade1d *fullcrumptr, Hint *hintptr, typetextset textset, typeispanset *ispansetptr)
{
    typeispan *ispanptr;

    // Identify an IStreamAddr at which to Insert the New DocBytes
    IStreamAddr lsa;
    if (!fullcrumptr->findAddrToInsertAt(hintptr, &lsa))
        return false; // Error: No Acceptable IStreamAddr was Found

    IStreamAddr spanorigin = lsa; // Origin of New Span of DocBytes

    for (; textset; textset = textset->next) { // For Each Piece of the DocBytes Sequence,
        CoreBottomCrum::typegranbottomcruminfo locinfo;

        locinfo.infotype = CoreBottomCrum::GRANTEXT;
        locinfo.granstuff.textstuff.textlength = textset->length;

        memmove(locinfo.granstuff.textstuff.textstring, textset->string, locinfo.granstuff.textstuff.textlength);

        fullcrumptr->insert(&lsa, &locinfo);

        lsa = lsa.increment(0, textset->length); // Increment to the Place to Put the Next Piece of the DocBytes
    }

    // Return a Memory-Resident Tracking Object (ISpan) that is Tied to the new DocBytes
    ispanptr         = (typeispan *) taskalloc(sess, sizeof(typeispan));
    ispanptr->itemid = ISPANID;
    ispanptr->next   = NULL;
    ispanptr->stream = spanorigin;
    ispanptr->width  = lsa - spanorigin;

    *ispansetptr = ispanptr;

    return true;
}

/**********************************************************************
 *      (invoked when creating a new document or a new link)
 **********************************************************************/
    bool
createorglgr(Session *sess, Enfilade1d *fullcrumptr, Hint *hintptr, IStreamAddr *isaptr)
{
    // Find IStreamAddr to Insert
    if (!fullcrumptr->findAddrToInsertAt(hintptr, isaptr))
        return false;

    CoreBottomCrum::typegranbottomcruminfo locinfo;
    locinfo.infotype                    = CoreBottomCrum::GRANORGL;
    locinfo.granstuff.orglstuff.orglptr = Enfilade2d::create(POOM);

    locinfo.granstuff.orglstuff.orglptr->reserve();

    locinfo.granstuff.orglstuff.orglincore = true;
    locinfo.granstuff.orglstuff.diskorglptr.diskblocknumber = NULLBLOCKNUM;
    locinfo.granstuff.orglstuff.diskorglptr.insidediskblocknumber = 0;

    fullcrumptr->insert(isaptr, &locinfo);
    locinfo.granstuff.orglstuff.orglptr->rejuvinate();

    return true;
}

/**********************************************************************
 *
 **********************************************************************/
    typevstuffset *
ispan2vstuffset(Session *sess, Enfilade1d *fullcrumptr, typeispan *ispanptr, typevstuffset *vstuffsetptr)
{
    *vstuffsetptr = NULL;

    IStreamAddr lowerbound = ispanptr->stream;
    IStreamAddr upperbound = lowerbound + ispanptr->width;

    Context *context = retrieveinspan(fullcrumptr, &lowerbound, &upperbound, WIDTH);

    Context *temp;
    for (temp = context; temp; temp = temp->nextcontext) {
        typevstuffset  vstuffset;
        if (context2vstuff(sess, temp, ispanptr, &vstuffset)) {
            *vstuffsetptr = vstuffset;
            vstuffsetptr = (typevstuffset *) &((typeitemheader *) vstuffset)->next;
        }
    }

    contextfree(context);
    return vstuffsetptr;
}

/**********************************************************************
 *  Original Copyright � 1979-1999 Udanax.com.   All Rights Reserved
 **********************************************************************/
