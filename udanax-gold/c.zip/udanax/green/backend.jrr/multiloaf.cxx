/**
 * @file  multiloaf.cxx
 * @brief ???
 *
 * (to be defined)
 *
 **/

#include <stdio.h>
#include <sys/types.h>
#include <netinet/in.h>

#include <nana/nana.h>  // GNU Assertion/Logging Tool

#include "xanadu.h"
#include "enf.h"
#include "coredisk.h"
#include "allocio.h"

extern BitmapAllocIO *aio;

struct freediskconscell {
    freediskconscell  *next;
    freediskentry     *stuff;
};

freediskconscell *hashfromdiskblock(int diskblocknumber);

#define SIZEOFFREEDISKBUCKET 50
#define NUMBEROFFREEDISKBUCKETS (NUMBYTESINLOAF/SIZEOFFREEDISKBUCKET+1)
static freediskconscell *fdorderedtable[NUMBEROFFREEDISKBUCKETS];
#define FDHASHTABLESIZE 10000

  /* a random prime */
#define FDHASHMULT 723754349

static freediskconscell *fdhashtable[FDHASHTABLESIZE];

/**********************************************************************
 *
 **********************************************************************/
    void
dumpincoretables()
{
#ifndef DISTRIBUTION
    dumpfdorderedtable();
    dumpfdhashtable();
#endif
}

extern void actuallywriteloaf();

/**********************************************************************
 *
 **********************************************************************/
    void
dumpfdhashtable()
{
#ifndef DISTRIBUTION
    int i;
    freediskconscell *ptr;
    cerr << "dumping fdhashtable" << endl;

    for (i = 0; i <FDHASHTABLESIZE; i++) {
        if (fdhashtable[i]) {
            cerr << "hashtable[" << i << ']' << endl << ' ';

            for (ptr = fdhashtable[i]; ptr; ptr = ptr->next)
                dumpfreediskentry(ptr->stuff);
        }
    }

    cerr << "exiting dumping fdhashtable" << endl;
#endif
}

/**********************************************************************
 *
 **********************************************************************/
    void
dumpfdorderedtable()
{
#ifndef DISTRIBUTION
    int i;
    freediskconscell *ptr;

    cerr << "dumping fdorderedtable" << endl;
    for (i = 0; i <NUMBEROFFREEDISKBUCKETS; i++) {
        if (fdorderedtable[i]) {
            cerr << "fdorderedtable[" << i << "] s = " << (i + 1) * SIZEOFFREEDISKBUCKET << endl;

            for (ptr = fdorderedtable[i]; ptr; ptr = ptr->next)
                dumpfreediskentry(ptr->stuff);
        }
    }

    cerr << "exiting dumping fdorderedtable" << endl;
#endif
}

/**********************************************************************
 *
 **********************************************************************/
    void
dumpfreediskentry(freediskentry *ptr)
{
#ifndef DISTRIBUTION
    cerr << "partialdiskblocknumber = " << ntohl(ptr->partialdiskblocknumber)
         << " freespaceinloaf = " << ntohs(ptr->freespaceinloaf) << endl;
#endif
}

/**********************************************************************
 *
 **********************************************************************/
    void
initincorealloctables()/* since these tables are extern i.e. initialized, this
                                routine is just a start at restartability */
{
    int i;

    for (i = 0; i < NUMBEROFFREEDISKBUCKETS; i++)
        fdorderedtable[i] = NULL;

    for (i = 0; i <FDHASHTABLESIZE; i++)
        fdhashtable[i] = NULL;
}

/**********************************************************************
 *
 **********************************************************************/
    void
savepartialdiskalloctabletodisk()
{
    DiskLoafAddr dl;

    int bucket = 0;
    freediskconscell *ptr = fdorderedtable[bucket];
    int blocknumber = PARTIALFREEDISKLOCATION;

    unsigned i;
    for (i = 0; ; i++, ptr = ptr->next) {
        freediskarray loaf;

        for ( ; ptr == 0; ) {
            bucket++;
            if (bucket >= NUMBEROFFREEDISKBUCKETS) {
                /* goto endofbuckets; */
                loaf.numberofentrysinthisblock = htonl(i);
                loaf.nextdiskblocknumber = 0;
                actuallywriteloaf((typeuberrawdiskloaf *) &loaf, blocknumber);
                return;
            }

            ptr = fdorderedtable[bucket];
        }

        loaf.freeentryarray[i] = *(ptr->stuff);

        if (i >= NFREEENTRYS - 1) {
//            dl = diskalloc();
            dl.diskblocknumber = aio->allocBlock();
	    dl.insidediskblocknumber = 0/*1*/;

            loaf.nextdiskblocknumber = htonl(dl.diskblocknumber);
            loaf.numberofentrysinthisblock = htonl(NFREEENTRYS);
            actuallywriteloaf((typeuberrawdiskloaf *) &loaf, blocknumber);
            i = 0;
            blocknumber = dl.diskblocknumber;
        }
    }
}

/**********************************************************************
 *
 **********************************************************************/
    void
readpartialdiskalloctablefromdisk()
{
    freediskarray loaf;
    int blocknumber;
    int first;

    /* return; */

    first = true;
    for (blocknumber = PARTIALFREEDISKLOCATION; blocknumber; blocknumber = ntohl(loaf.nextdiskblocknumber)) {
        actuallyreadrawloaf((typeuberrawdiskloaf *) &loaf, blocknumber);

        if (!first)
//            diskfree(blocknumber);
            aio->freeBlock(blocknumber);

        first = false;

        if (ntohl(loaf.numberofentrysinthisblock) > NFREEENTRYS)
            gerror("numberofentrysinthisblock too big!\n");

        unsigned i;
        for (i = 0 ; i < ntohl(loaf.numberofentrysinthisblock); i++)
            addtofreediskstructures( &loaf.freeentryarray[i] );
    }
}

/**********************************************************************
 *
 **********************************************************************/
    void
addtofreediskstructures(freediskentry *diskentry)
{
    freediskconscell *newcons;
    freediskentry *newde;
    int i;

    newde          = new freediskentry;
//    newde          = (freediskentry *) malloc( sizeof(freediskentry) );
    newcons        = new freediskconscell;
//    newcons        = (freediskconscell *) malloc( sizeof(freediskconscell) );
    newcons->stuff = newde;
    *newde         = *diskentry;
    i              = ntohs(diskentry->freespaceinloaf) / SIZEOFFREEDISKBUCKET;

    newcons->next     = fdorderedtable[i];
    fdorderedtable[i] = newcons;

    newcons = new freediskconscell;
//    newcons = (freediskconscell *) malloc( sizeof(freediskconscell) );
    newcons->stuff = newde;
    i = fdhash( ntohl(diskentry->partialdiskblocknumber) );

    newcons->next  = fdhashtable[i];
    fdhashtable[i] = newcons;
}

/**********************************************************************
 *
 **********************************************************************/
    void
addallocatedloaftopartialallocedtables(DiskLoafAddr dp, int size)
{
    freediskentry stuff;

    stuff.partialdiskblocknumber = htonl(dp.diskblocknumber);
    stuff.freespaceinloaf        = htons(sizeof(typeuberrawdiskloaf) - size - SIZEOFUBERDISKHEADER);
    addtofreediskstructures(&stuff);
}

/**********************************************************************
 *
 **********************************************************************/
    void
changefreediskstructures(freediskentry *diskentry, int newsize)
{
    freediskconscell *newptr = NULL;

    /* first change hash table */

    int temp = fdhash( ntohl(diskentry->partialdiskblocknumber) );
    freediskconscell *oldptr = 0;

    freediskconscell *ptr;
    for (ptr = fdhashtable[temp]; ptr; ptr = ptr->next) {
        if (ptr->stuff->partialdiskblocknumber == diskentry->partialdiskblocknumber) {
            newptr = ptr;
            break;
        }
        oldptr = ptr;
    }
    I(newptr != NULL); // Invariant Assertion

    if (oldptr == newptr) {
#ifndef DISTRIBUTION
        gerror("in hashfromdiskblock not found\n");
#else
        gerror("FOO");
#endif
    }

    if (oldptr == 0)
        fdhashtable[temp] = newptr->next;
    else
        oldptr->next = newptr->next;

    /* next change ordered table */

    temp = ntohs(diskentry->freespaceinloaf) / SIZEOFFREEDISKBUCKET;
    oldptr = 0;

    for (ptr = fdorderedtable[temp]; ptr; ptr = ptr->next) {
        if (ptr->stuff->partialdiskblocknumber == diskentry->partialdiskblocknumber) {
            newptr = ptr;
            break;
        }

        oldptr = ptr;
    }

    if (oldptr == 0)
        fdorderedtable[temp] = newptr->next;
    else
        oldptr->next = newptr->next;

    /* last change size in entry */
    newptr->stuff->freespaceinloaf = htons(newsize);
    addtofreediskstructures(newptr->stuff); /* just call standard routine */

    /* then delete stuff left lying around  do this more efficiently later */
    delete newptr->stuff;
    delete newptr;

//    free((char *) newptr->stuff);
//    free((char *) newptr);
}

/**********************************************************************
 *
 **********************************************************************/
    freediskconscell *
hashfromdiskblock(BlockNum diskblocknumber)
{
    int temp;
    freediskconscell *ptr;

    temp = fdhash(diskblocknumber);
    for (ptr = fdhashtable[temp]; ptr; ptr = ptr->next) {
        if (ntohl(ptr->stuff->partialdiskblocknumber) == diskblocknumber)
            return ptr;
    }

    gerror("in hashfromdiskblock not found\n");

    return NULL;  /* keep lint quiet */
}

/**********************************************************************
 *
 **********************************************************************/
    int
fdhash(int diskblocknumber)
{
    return abs(diskblocknumber * FDHASHMULT) % FDHASHTABLESIZE;
}

/**********************************************************************
 *
 **********************************************************************/
#define BESTFIT
#ifdef BESTFIT
    freediskentry *
findfreeenoughloafinbucket(int size)
{
    int i;
    for (i = size / SIZEOFFREEDISKBUCKET + 1; i < NUMBEROFFREEDISKBUCKETS; i++) {

        freediskconscell *ptr;
        for (ptr = fdorderedtable[i]; ptr != NULL; ptr->next)
            if (ntohs(ptr->stuff->freespaceinloaf) >= size)
                return ptr->stuff;
    }

    return NULL;
}

/**********************************************************************
 *
 **********************************************************************/
#else  /*worst fit*/
    freediskentry *
findfreeenoughloafinbucket(int size)
{
    int i;
    freediskconscell *ptr;

    for (i = NUMBEROFFREEDISKBUCKETS - 1; i >= size / SIZEOFFREEDISKBUCKET; i--) {
        for (ptr = fdorderedtable[i]; ptr; ptr = ptr->next) {
            if (ntohs(ptr->stuff->freespaceinloaf) >= size)
                return ptr->stuff;
        }
    }

    return NULL;
}
#endif

/**********************************************************************
 *
 **********************************************************************/
    DiskLoafAddr
partialdiskalloc(int size, int *newloafp)
{
    freediskentry     diskentry;
    typeuberdiskloaf  loaf;
    DiskLoafAddr   dlp;

#ifndef DISTRIBUTION
    if (size != 1010 && size > 990)
        cerr << "partialdiskalloc size = " << size << endl;
#endif

    freediskentry *freeentry = findfreeenoughloafinbucket(size);

    if (!freeentry) {
//        DiskLoafAddr dlp = diskalloc();
        dlp.diskblocknumber = aio->allocBlock();
        dlp.insidediskblocknumber = 0/*1*/;

        diskentry.partialdiskblocknumber = htonl(dlp.diskblocknumber);
        diskentry.freespaceinloaf = htons(NUMBYTESINLOAF - size - SIZEOFUBERDISKHEADER) ;

        addtofreediskstructures(&diskentry);

        *newloafp = true;
        return dlp;

    } else {
        if (size >= ntohs(freeentry->freespaceinloaf)) {
            dumpincoretables();
#ifndef DISTRIBUTION
            gerror("partialdiskalloc  found loaf too small\n");
#else
            gerror("");
#endif
        }

        dlp.diskblocknumber = ntohl(freeentry->partialdiskblocknumber);

        actuallyreadrawloaf((typeuberrawdiskloaf *) &loaf, ntohl(freeentry->partialdiskblocknumber));

        dlp.insidediskblocknumber = findandallocateinsidediskblocknumber(dlp.diskblocknumber, size, &loaf);

        if (dlp.insidediskblocknumber > 100) {
#ifndef DISTRIBUTION
            gerror("partialdiskalloc insidediskblocknumber >100\n");
#else
            gerror("");
#endif
        }

        changefreediskstructures(freeentry, (int) (ntohs(freeentry->freespaceinloaf) - size));
        *newloafp = false;

        return dlp;
    }
}

/**********************************************************************
 *
 **********************************************************************/
    void
deletefromfreediskstructures(freediskentry *diskentry)
{
    freediskconscell *newptr = NULL;

    /* first change hash table */

    int temp = fdhash( ntohl(diskentry->partialdiskblocknumber) );
    freediskconscell *oldptr = 0;

    freediskconscell *ptr;
    for (ptr = fdhashtable[temp]; ptr; ptr = ptr->next) {
        if (ptr->stuff->partialdiskblocknumber == diskentry->partialdiskblocknumber) {
            newptr = ptr;
            break;
        }
        oldptr = ptr;
    }
    I(newptr != NULL); // Invariant Assertion

    if (oldptr == newptr) {
#ifndef DISTRIBUTION
        gerror("in hashfromdiskblock not found\n");
#else
        gerror("");
#endif
    }

    if (oldptr == 0)
        fdhashtable[temp] = newptr->next;
    else
        oldptr->next = newptr->next;

    /* next change ordered table */

    temp = ntohs(diskentry->freespaceinloaf) / SIZEOFFREEDISKBUCKET;
    oldptr = 0;

    for (ptr = fdorderedtable[temp]; ptr; ptr = ptr->next) {
        if (ptr->stuff->partialdiskblocknumber == diskentry->partialdiskblocknumber) {
            newptr = ptr;
            break;
        }
        oldptr = ptr;
    }

    if (oldptr == 0)
        fdorderedtable[temp] = newptr->next;
    else
        oldptr->next = newptr->next;

    /* then delete stuff left lying around  do this more efficiently later */

    delete newptr->stuff;
    delete newptr;

//    free((char *) newptr->stuff);
//    free((char *) newptr);
}

/**********************************************************************
 *
 **********************************************************************/
#ifdef UnDEfiNed
    void
newpartialdiskfree(DiskLoafAddr diskloaf)
{
    typeuberdiskloaf loaf;
    freediskconscell *ptr;
    int number;
    int temp;

    actuallyreadrawloaf((typeuberrawdiskloaf *) &loaf, diskloaf.diskblocknumber);
    number = numberofliveunterloafs(&loaf);

    if (number == 1) {
        ptr = hashfromdiskblock(diskloaf.diskblocknumber);

//        diskfree(diskloaf.diskblocknumber); was just diskloaf ECH
        aio->freeBlock(diskloaf.diskblocknumber);

        deletefromfreediskstructures(ptr->stuff);

    } else {
        ptr = hashfromdiskblock(diskloaf.diskblocknumber);
        temp = deallocateinloaf(&loaf,diskloaf.insidediskblocknumber);
        changefreediskstructures(ptr->stuff /* ECH 8-26-88 BAD BUG (no->stuff) */, (int) ntohs(ptr->stuff->freespaceinloaf) + temp);
        actuallywriteloaf( /* 3377, */ (typeuberrawdiskloaf *) &loaf, diskloaf.diskblocknumber);
    }
}
#endif

/**********************************************************************
 *
 **********************************************************************/
    int
deallocateinloaf(typeuberdiskloaf *loafp, BlockNum insidediskblocknumber)
{
    char *lp;
    unsigned int number, n, temp;

    /* lp = (char *) &loafp->fakepartialuberloaf; */ lp = (char *) loafp + 6;

    number = ntohs(loafp->numberofunterloafs);
    unsigned i;
    for (i = 0; i < number; i++) {
        n    = lengthof((humber) lp);
        temp = intof((humber) lp);

        if (i == insidediskblocknumber) {
            memmove(lp + 1, lp + temp, sizeof(typeuberrawdiskloaf) - (lp - (char *) loafp) - 1);
            *lp = 1;
            return temp - 1;
        }

        if (n >= temp)
            lp += n;
        else
            lp += temp;
    }

    gerror("in deallocateinloaf couldnt deallocate\n");

    return 0;
}

/**********************************************************************
 *
 **********************************************************************/
    int
findandallocateinsidediskblocknumber(BlockNum diskblocknumber, int size, typeuberdiskloaf *loafp)
{
    int temp;
    short loaftemp;

    char *lp = /* (char *) &loafp->fakepartialuberloaf; */ (char *) loafp + 6; /* zzz 1999** */
    int number = ntohs(loafp->numberofunterloafs);
    int i;
    for (i = 0; i < number; i++) {
        temp = intof((humber) lp);
        lp += temp;
    }

    loaftemp                  = ntohs(loafp->numberofunterloafs) + 1;
    loafp->numberofunterloafs = htons(loaftemp);
    temp                      = sizeof(typeuberrawdiskloaf) - (lp - (char *) loafp) - size;

    I(temp >= 0); // Expression Must Be Positive

    memmove(lp + size, lp, sizeof(typeuberrawdiskloaf) - (lp - (char *) loafp) - size);

    return i;
}

/**********************************************************************
 *
 **********************************************************************/
    int
numberofliveunterloafs(typeuberdiskloaf *loafp)
{
    int ret = 0;
    char *lp = /* (char *) &loafp->fakepartialuberloaf; */ (char *) loafp + 6;

    unsigned number = ntohs(loafp->numberofunterloafs);
    unsigned i;
    for (i = 0; i < number; i++) {
        unsigned n = lengthof((humber) /* loafp */ lp); /* ECH 8-29-88 */
        unsigned temp = intof((humber) lp);

        if (n >= temp)
            lp += n;
        else
            lp += temp;

        if (n != temp)
            ret++;
    }

    return ret;
}

/**********************************************************************
 *
 **********************************************************************/
    char *
findinsideloaf(typeuberdiskloaf *loafp, unsigned ninsideloaf)
{
    unsigned int n;
    unsigned int temp;

    char *lp = /* (char *) &loafp->fakepartialuberloaf; */ (char *) loafp + 6;

    unsigned number = ntohs(loafp->numberofunterloafs);

    unsigned i;
    for (i = 0; i < number; i++) {
        n = lengthof((humber) loafp);

    if (i == ninsideloaf)
        return lp;

    temp = intof((humber) lp);
    if (n >= temp)
        lp += n;
    else
        lp += temp;

    }

    return lp;
}

/**********************************************************************
 *  Original Copyright � 1979-1999 Udanax.com.   All Rights Reserved
 **********************************************************************/
