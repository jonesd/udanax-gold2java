/**
 * @file  x88protocol.cxx
 * @brief Protocol-to-CallAPI Interface Functions
 *
 * The functions in this file generally unpack their arguments from
 * a task object, invoke the call API functions and bundle up the
 * results into the task object for transmission back to the invoker.
 *
 * The FeBe Protocol uses 8 bit ASCII characters without parity.  Commands
 * that transfer data-bytes transfer count delimited sequences of bytes. The
 * protocol does not reserve any escape codes within data transmissions.
 *
 * Errors:
 *
 * error ::= `?'
 *
 * Calls to the backend that succeed return their command number followed by
 * any return values.  Calls that fail for any reason return only the single
 * character `?'.
 *
 * Tumblers:
 *
 * number ::= [ digit ]+ delim
 * exponent ::= [ digit ]+
 * tumbler ::= exponent [ `.' [ digit ]+ ]* delim
 *
 * A tumbler is an ordered sequence of numbers; for example, "123.45.0.89.1"
 * or "32.17".
 *
 * Each number within a tumbler is called a "tumbler digit".
 *
 * In the tumbler "123.45.0.89.1" the underlined parts of the tumbler are
 * "tumbler digits".  The zero (`.0.') tumbler digit (when not in the
 * exponent position) is only used as a separator in address tumblers.
 *
 * + In the 88.1x implementation of the FeBe protocol each tumbler digit
 *   has to be in the range of 0 to 4,294,967,295 (2**32-1).
 *
 * Comparison and arithmetic operations on tumblers align tumbler-digits from
 * the left.  Since tumblers used as widths for spans often start with many
 * zeroes, FeBe uses a compact representation for tumblers.  The first
 * tumbler digit in the representation is the number of zero tumbler digits
 * at the beginning of the tumbler.  Thus, the tumblers "32.2" and
 * "0.0.0.14.5" are represented by "0.32.2" and "3.14.5".  This leading
 * tumbler digit is referred to as the exponent of the tumbler.
 *
 * + In the 88.1x implementation of the FeBe protocol there may be a maximum
 *   of 11 non-zero tumbler digits plus exponent in any one tumbler.  This
 *   restriction will be eliminated in a later release.
 *
 * id ::= tumbler
 *
 * These tumblers are global identifiers.  IDs can refer to any Udanax Green
 * objects.  (See the chapter "Addressing" for more details.)
 *
 * vaddr ::= exponent `.' [ digit ]+ [ `.' [ digit ]+ ]? delim
 *
 * These tumblers are relative to a given document, so they only have one or
 * two digits.  The first digit determines the space (1=text, 2=link). The
 * second digit determines the location within that space.
 *
 * Groups:
 *
 * span ::= tumbler-start tumbler-width
 *
 * A span specifies a range of Udanax Green objects in the global address
 * space.  Spans include all objects between tumbler-start inclusive and
 * tumbler-start plus tumbler-width exclusive.  (See the chapters "Tumbler
 * Arithmetic" and "Addressing".)
 *
 * vspan ::= vaddr-start vaddr-width
 *
 * A vspan specifies a range of data-bytes and/or links within a given
 * document.
 *
 * spec ::= `s' delim span
 *        | `v' delim doc-id number * [ vspan ]
 *
 * spec-set ::= number * [ spec ]
 *
 * A spec-set specifies a possibly discontinuous set of Udanax Green
 * objects.
 *
 * shared-span ::= tumbler-start-1 tumbler-start-2 tumbler-width
 *
 * A shared-span indicates that the span specified by tumbler-start-1
 * and tumbler-width represents the same Udanax Green objects as the
 * span specified by tumbler-start-2 and tumbler-width.  Only the
 * version comparison operation returns shared-spans.
 *
 * Document Contents:
 *
 * string ::= `t' number * [ byte ]
 *
 * Strings wrap data-bytes for transmission between the frontend and
 * the backend.
 *
 * + In the current implementation (88.1x) there is a maximum of 950
 *   data-bytes in a single string.  This limitation will be removed
 *   in future releases.  It is not recommended to even try to write
 *   longer strings to the backend.
 *
 * contents ::= string
 *            | id-link
 *
 * Documents contain data-bytes and links.  A frontend can retrieve
 * a span that contains both.
 *
 **/

#include <iostream>
#include <nana/nana.h>  // GNU Assertion/Logging Tool

#include "xanadu.h"
#include "enf.h"
#include "players.h"
#include "requests.h"
#include "knives.h"

//extern FILE *interfaceinput;
extern _IO_istream_withassign interfaceinput;

extern int backenddaemon;

extern void diskexit();

//#define SOURCEUNIXCOMMAND 21

/**********************************************************************
 * #29: FINDNUMOFLINKSFROMTOTHREE
 **********************************************************************/
    void
findnumoflinksfromtothree(Session *sess)
{
    typespecset fromvspecset, tovspecset, threevspecset;
    typeispanset homeset;
    int numberoflinks;

    if (getfindnumoflinksfromtothree(sess, &fromvspecset, &tovspecset, &threevspecset, &homeset)
    && dofindnumoflinksfromtothree(sess, &fromvspecset, &tovspecset, &threevspecset, homeset, &numberoflinks))
    //jrr: something wierd here -- I had to modify the code to compile w/protos

        putfindnumoflinksfromtothree(sess, numberoflinks);

    else
        putrequestfailed(sess);
}

/**********************************************************************
 * #31: FINDNEXTNLINKSFROMTOTHREE
 **********************************************************************/
    void
findnextnlinksfromtothree(Session *sess)
{
    typespecset fromvspecset, tovspecset, threevspecset;
    typeispanset homeset;
    IStreamAddr lastlink;
    typelinkset nextlinkset;
    int n;

    if (getfindnextnlinksfromtothree(sess, &fromvspecset, &tovspecset, &threevspecset, &homeset, &lastlink, &n)
        && dofindnextnlinksfromtothree(sess, (typevspec *) &fromvspecset, (typevspec *) &tovspecset, (typevspec *) &threevspecset, homeset, &lastlink, &nextlinkset, &n))

        putfindnextnlinksfromtothree(sess, n, nextlinkset);
    else
        putrequestfailed(sess);
}

/**********************************************************************
 * #9: NAVIGATEONHT
 **********************************************************************/
    void
navigateonht(Session *sess)
{
#ifndef DISTRIBUTION
    error(sess, "GACK !  (historical trace)\n");
#endif

    /*
     * IStreamAddr docisa, htisa;
     * typehtpath turninginstructions;
     * bool getnavigateonht();
     * if (getnavigateonht(sess, &docisa, &htisa, &turninginstructions))
     *     donavigateonht(sess, &docisa, &htisa, &turninginstructions);
     */
}

/**********************************************************************
 * #0: INSERT
 *
 * Cmd: insert id-doc vaddr number * [ string> ]
 * Rsp: insert
 *    | error
 *
 * Insert text at vaddr in id-doc.  id-doc must be open for writing.
 **********************************************************************/
    void
insert(Session *sess)/* cheating version for unix zzz */
{
    IStreamAddr docisa;
    typetextset textset;
    VStreamAddr vsa;

    getinsert(sess, &docisa, &vsa, &textset);
    putinsert(sess);

    if (!doinsert(sess, &docisa, &vsa, textset))
        cerr << "requestfailed in insert" << endl;
}

/*
 *    void
 *insert(Session *sess)
 *{
 *    IStreamAddr docisa, vsa;
 *    typetextset textset;
 *    bool getinsert(), doinsert();
 *
 *    if (getinsert(sess, &docisa, &vsa, &textset) && doinsert(sess, &docisa, &vsa, textset))
 *        putinsert(sess);
 *    else
 *        putrequestfailed(sess);
 *}
 */

/**********************************************************************
 * #1: RETRIEVEDOCVSPANSET
 *
 * Cmd: retrieve-doc-vspanset id-doc
 * Rsp: retrieve-doc-vspanset number * [ vspan ]
 *    | error
 *
 * Return a vspan describing each space in id-doc.  If either the data
 * or link space is empty, its vspan is left out.  id-doc must already
 * be open for writing.
 **********************************************************************/
    void
retrievedocvspanset(Session *sess)
{
    IStreamAddr docisa;
    typevspanset vspanset;

    if (getretrievedocvspanset(sess, &docisa) && doretrievedocvspanset(sess, &docisa, &vspanset))
        putretrievedocvspanset(sess, &vspanset);
    else
        putrequestfailed(sess);
}

/**********************************************************************
 * #2: COPY
 *
 * Cmd: copy id-doc vaddr spec-set
 * Rsp: copy
 *    | error
 *
 * Virtually copy the contents specified by the spec-set to vaddr in
 * id-doc.  id-doc must be open for writing.  All documents with
 * contents in spec-set must be open for reading.
 **********************************************************************/
    void
copy(Session *sess)
{
    IStreamAddr docisa;
    VStreamAddr vsa;
    typespecset localspecset;

    if (getcopy(sess, &docisa, &vsa, &localspecset)
    &&   docopy(sess, &docisa, &vsa, localspecset))
        putcopy(sess);
    else
        putrequestfailed(sess);
}

#ifdef UnDEfined
    void
copy(Session *sess) /* kluged unix version for speed */
{
    IStreamAddr docisa, vsa;
    typespecset localspecset;

    (void) getcopy(sess, &docisa, &vsa, &localspecset);
    (void) putcopy(sess);

    if (!docopy(sess, &docisa, &vsa, /* & ECH according to lint*/ &localspecset)) /* zzz aug 21 1999 reg ? this may cause trouble **/
#ifndef DISTRIBUTION
        cerr << "copy failed" << endl;
#else
        ;
#endif

}
#endif

/**********************************************************************
 * #3: REARRANGE
 *
 * cut-count ::= `2' delim
 *             | `3' delim
 *             | `4' delim
 *
 * Cmd: rearrange id-doc cut-count * [ vaddr ]
 * Rsp: rearrange
 *    | error
 *
 * Transpose large blocks of characters within doc.  The number of vaddrs
 * (cut-count) determines the operation.  If cut-count equals 2, delete
 * the contents from vaddr1 to vaddr2.  If cut-count equals 3, swap the
 * contents from vaddr1 to vaddr2 with the contents from vaddr2 to vaddr3.
 * If cut-count equals 4, swap the contents from vaddr1 to vaddr2 with
 * the contents from vaddr3 to vaddr4.  The first vaddr specifying a range
 * must be less than or equal to the second vaddr for that range. id-doc
 * must be open for writing.
 **********************************************************************/
    void
rearrange(Session *sess) /* speed hack for unix */
{
    IStreamAddr docisa;
    typecutseq cutseq;

    getrearrange(sess, &docisa, &cutseq);
    putrearrange(sess);

    if (!dorearrange(sess, &docisa, &cutseq))
        cerr << "rearrange failed" << endl;
}

/*
 *    void
 *rearrange(Session *sess)
 *{
 *    IStreamAddr docisa;
 *    typecutseq cutseq;
 *    bool getrearrange(), dorearrange();
 *
 *    if (getrearrange(sess, &docisa, &cutseq) && dorearrange(sess, &docisa, &cutseq))
 *        putrearrange(sess);
 *    else
 *        putrequestfailed(sess);
 *}
 */

/**********************************************************************
 * #5: RETRIEVEV
 *
 * Cmd: retrieve-v spec-set
 * Rsp: retrieve-v number * [ contents ]
 *    | error
 *
 * Retrieve data and links from the backend.  The spec-set can include
 * document identifiers, text ranges, and link identifiers. The
 * information returned follows the order of the spec-set.  All the
 * documents in spec-set must be open for reading.
 **********************************************************************/
    void
retrievev(Session *sess)
{
    typespecset specset;
    typevstuffset vstuffset;

    if (getretrievev(sess, &specset) && doretrievev(sess, specset, &vstuffset))
        putretrievev(sess, &vstuffset);
    else
        putrequestfailed(sess);
}

/**********************************************************************
 * #10: SHOWRELATIONOF2VERSIONS
 *
 * Cmd: show-relations-of-2-versions spec-set-1 spec-set-2
 * Rsp: show-relations-of-2-versions number * [ shared-span ]
 *    | error
 *
 * Structurally compare the two sets of contents.  Return a list
 * describing the shared contents; i.e., contents derived from the
 * same source through versioning or edit operations.  Identical
 * sections entered independently are not considered shared because
 * they came from different sources.  (See the chapter "Versions".)
 * All documents mentioned in the spec-sets must be open for reading.
 **********************************************************************/
    void
showrelationof2versions(Session *sess)
{
    typespecset version1, version2;
    typespanpairset relation;

    if (getshowrelationof2versions(sess, &version1, &version2) && doshowrelationof2versions(sess, version1, version2, &relation))
        putshowrelationof2versions (sess, relation);
    else
        putrequestfailed(sess);
}

/*
 *    void
 *showrelationof2versions(Session *sess)
 *{
 *    IStreamAddr doc1, doc2;
 *    int relation; // temp //
 *
 *    if (getshowrelationof2versions(sess, &doc1, &doc2))
 *        if (doshowrelationof2versions(sess, &doc1, &doc2,  &relation))
 *            putshowrelationof2versions(sess, &relation);
 *}
 */

/**********************************************************************
 * #11: CREATENEWDOCUMENT
 *
 * Cmd: create-new-document
 * Rsp: create-new-document id-doc
 *    | error
 *
 * Create a new document under the account and node of the user who
 * issued the request.  Return the global identifier for the document.
 *
 * This request creates the document but does not open it for access;
 * you must issue an open request (see below) to access the data in
 * the new document.
 **********************************************************************/
    void
createnewdocument(Session *sess)
{
    IStreamAddr newdocisa;

    getcreatenewdocument();
    if (docreatenewdocument(sess, &newdocisa))
        putcreatenewdocument(sess, &newdocisa);
    else
        putrequestfailed(sess);
}

/**********************************************************************
 * #12: DELETEVSPAN
 *
 * Cmd: delete-vspan id-doc vspan
 * Rsp: delete-vspan
 *    | error
 *
 * Remove the bytes specified by vspan from id-doc. id-doc must be open
 * for writing.
 **********************************************************************/
    void
deletevspan(Session *sess) /* kluged unix version for speed */
{
    IStreamAddr docisa;
    typespan vspan;

    getdeletevspan(sess, &docisa, (typevspan *) &vspan);
    putdeletevspan(sess);

    if (!dodeletevspan(sess, &docisa, &vspan))
        cerr << "deletevspan failed" << endl;
}

/*
 *    void
 *deletevspan(Session *sess)
 *{
 *    IStreamAddr docisa;
 *    typespan vspan;
 *    bool getdeletevspan(), dodeletevspan();
 *
 *    if (getdeletevspan(sess, &docisa, &vspan) && dodeletevspan(sess, &docisa, &vspan))
 *        putdeletevspan(sess);
 *    else
 *        putrequestfailed (sess);
 *}
 */

/**********************************************************************
 * #13: CREATENEWVERSION
 *
 * Cmd: create-new-version id-old-doc
 * Rsp: create-new-version id-new-doc
 *    | error
 *
 * Return the identifier of a new copy of id-old-doc.  id-new-doc
 * contains the same data and links as id-old-doc.  Links to those
 * contents are visible from either document.
 *
 * This request creates the document but does not open it for access;
 * you must issue an open request (see below) to access the data in
 * the new document.
 **********************************************************************/
    void
createnewversion(Session *sess)
{
    IStreamAddr originaldocisa, newdocisa;

    if (getcreatenewversion(sess, &originaldocisa) && docreatenewversion(sess, &originaldocisa, &originaldocisa, &newdocisa))
        putcreatenewversion(sess, &newdocisa);
    else
        putrequestfailed(sess);
}

/**********************************************************************
 * #14: RETRIEVEDOCVSPAN
 *
 * Cmd: retrieve-doc-vspan id-doc
 * Rsp: retrieve-doc-vspan vspan
 *    | error
 *
 * Return the vspan describing the contents of id-doc, including its
 * links.  The width of the span reflects either the number of links
 * or the number of data-bytes if there are no links. id-doc must
 * already be open for reading.
 **********************************************************************/
    void
retrievedocvspan(Session *sess)
{
    IStreamAddr docisa;
    typevspan vspan;

    if (getretrievedocvspan(sess, &docisa) && doretrievedocvspan(sess, &docisa, &vspan))
        putretrievedocvspan(sess, &vspan);
    else
        putrequestfailed(sess);
}

/**********************************************************************
 * #16: QUIT
 *
 * Cmd: quit
 * Rsp: quit
 *
 * Terminate the connection between the frontend and the backend. If
 * appropriate, the backend saves and terminates. Quit never returns
 * an error.
 **********************************************************************/
    void
quitxanadu(Session *sess)
{
    putquitxanadu(sess);

    if (!backenddaemon) {
//        if (interfaceinput.good()) {
//            interfaceinput << QUIT << '~' << endl;
//            interfaceinput.close();
//        }

        diskexit();

    } else
        dobertexit(user); /* Close all of the user's outstanding opens */
}

/**********************************************************************
 * #18: FOLLOWLINK
 *
 * end-switch ::= `1' from delim
 *              | `2' to delim
 *              | `3' three delim
 *
 * Cmd: follow-link end-switch id-link
 * Rsp: follow-link spec-set-end
 *    | error
 *
 * Return an end-set of id-link.  end-switch determines the end-set
 * returned.
 **********************************************************************/
    void
followlink(Session *sess)
{
    IStreamAddr linkisa;
    typespecset specset;
    int whichend;

    if (getfollowlink(sess, &linkisa, &whichend)
    && dofollowlink(sess, &linkisa, &specset, whichend))
        putfollowlink(sess, specset);
    else
        putrequestfailed(sess);
}

/**********************************************************************
 * #22: FINDDOCSCONTAINING
 *
 * Cmd: find-docs-containing spec-set
 * Rsp: find-docs-containing number * [ id-doc ]
 *    | error
 *
 * Return identifiers for all documents that include any of the
 * contents specified by the argument.  All documents with contents
 * in spec-set must be open for reading.
 **********************************************************************/
    void
finddocscontaining(Session *sess)
{
    typespecset specset;
    typelinkset addressset;

    if (getfinddocscontaining(sess, &specset)
    && dofinddocscontaining(sess, specset, &addressset))

        putfinddocscontaining(sess, (typeitemset) addressset);

    else
        putrequestfailed(sess);
}

/**********************************************************************
 * #27: CREATELINK
 *
 * Cmd: create-link id-doc spec-set-from spec-set-to spec-set-three
 * Rsp: create-link id-link
 *    | error
 *
 * Create a link with the specified end-sets and return its identifier.
 * The new link is appended to the link space of id-doc.  id-doc is
 * the home for the id-link.  id-doc must already be open for writing.
 **********************************************************************/
    void
createlink(Session *sess)
{
    IStreamAddr docisa, linkisa;
    typespecset fromspecset, tospecset, threespecset;

    if (getcreatelink(sess, &docisa, &fromspecset, &tospecset, &threespecset)
    &&   docreatelink(sess, &docisa, fromspecset, tospecset, threespecset, &linkisa))

        putcreatelink(sess, &linkisa);
    else
        putrequestfailed(sess);
}

/**********************************************************************
 * #28: RETRIEVEENDSETS
 *
 * Cmd: retrieve-endsets spec-set-contents
 * Rsp: retrieve-endsets spec-set-from spec-set-to spec-set-three
 *    | error
 *
 * Describes where links attach to contents.  Each returned spec-set
 * describes the union of all end-sets of the given type that attach
 * to the supplied spec-set-contents.
 **********************************************************************/
    void
retrieveendsets(Session *sess)
{
    typespecset specset, fromset, toset, threeset;

    if (getretrieveendsets(sess, &specset) && doretrieveendsets(sess, specset, &fromset, &toset, &threeset))
        putretrieveendsets(sess, fromset, toset, threeset);
    else
        putrequestfailed(sess);
}

/**********************************************************************
 * 30: FINDLINKSFROMTOTHREE
 *
 * home-spec ::= number * [ id-doc ]
 *
 * Cmd: find-links-from-to-three spec-set-from spec-set-to spec-set-three home-spec
 * Rsp: find-links-from-to-three number * [ id-link ]
 *    | error
 *
 * Return the IDs of all links whose end-sets overlap the given from,
 * to, three, and home set restrictions.  All end-sets must satisfy
 * their respective constraints.  A set containing the entire
 * docuverse places no restriction.
 **********************************************************************/
    void
findlinksfromtothree(Session *sess)
{
    typespecset fromvspecset, tovspecset, threevspecset;
    typeispanset homeset;
    typelinkset linkset;

    if (getfindlinksfromtothree(sess, &fromvspecset, &tovspecset, &threevspecset, &homeset)
    && dofindlinksfromtothree(sess, fromvspecset, tovspecset, threevspecset, (typeispan *) NULL /*homeset*/, &linkset))

        putfindlinksfromtothree(sess, linkset);

    else
        putrequestfailed(sess);
}

/**********************************************************************
 * #34: XACCOUNT
 *
 * Cmd: x-account id-account
 * Rsp: x-account
 *    | error
 *
 * The backend associates id-account with the current connection and
 * frontend.  It causes the current user to be considered the owner
 * of id-account.  The multi-user backend requires that this command
 * be sent from within the standard login sequence.  You can only
 * login once per session.
 **********************************************************************/
    void
xaccount(Session *sess)
{
    if (getxaccount(sess, &(player[user].account)))
        putxaccount(sess);
    else
        putrequestfailed(sess);
}

/**********************************************************************
 * #35: OPEN
 *
 * mode ::= `1' read-only delim
 *        | `2' read-write delim
 *
 * copy-switch ::= `1' fail-on-conflict delim
 *               | `2' copy-on-conflict delim
 *               | `3' always-copy delim
 *
 * Cmd: open id-doc mode copy-switch
 * Rsp: open id-new-doc
 *    | error
 *
 * Open id-doc for access using mode.  Mode can be read-only or
 * read-write.  Read-only capability for a document can be shared.
 * Read-write capability is exclusive.  Two situations cause conflict:
 * a request for write access on an already open document, or a request
 * for read access to a document already open read-write.  When
 * contention arises, the backend can return a copy of the document or
 * fail.  The copy-switch determines the circumstances in which the
 * backend makes a copy.  id-doc and id-new-doc differ only if open
 * makes a copy.  Command descriptions which require already open
 * documents for their arguments will be so noted.  Open for
 * read-write satisfies the requirement "Must be open for reading".
 **********************************************************************/
    void
myopen(Session *sess)
{
    IStreamAddr t, newt;
    int type, mode;

    if (getopen(sess, &t, &type, &mode) && doopen(sess, &t, &newt, type, mode, user))
        putopen(sess, &newt);
    else
        putrequestfailed(sess);
}

/**********************************************************************
 * #36: CLOSE
 *
 * Cmd: close id-doc
 * Rsp: close
 *    | error
 *
 * Close id-doc.  All opened documents must be closed.  Multiple opens
 * of a document must balanced by the same number of close calls.  A
 * loss of connection between the frontend and backend or a quit
 * command is the same as closing all documents and then doing a
 * quit.
 **********************************************************************/
    void
myclose(Session *sess)
{
    Tumbler t;

    if (getclose(sess, &t) && doclose(sess, &t, user))
        putclose(sess);
    else
        putrequestfailed(sess);
}

/**********************************************************************
 * #38: CREATENODE_OR_ACCOUNT
 *
 * Cmd: create-node-or-account id-account
 * Rsp: create-node-or-account id-account
 *    | error
 *
 * Declare that id-account is a legal account or node. If id-account
 * is an account tumbler, then the backend creates the account.  If
 * it is a node tumbler, then the backend reassigns its own address
 * to id-account.
 **********************************************************************/
    void
createnode_or_account(Session *sess)
{
    IStreamAddr t;

    if (getcreatenode_or_account(sess, &t)
    &&   docreatenode_or_account(sess, &t))
        putcreatenode_or_account(sess, &t);
    else
        putrequestfailed(sess);
}

/**********************************************************************
 *  Original Copyright � 1979-1999 Udanax.com.   All Rights Reserved
 **********************************************************************/
