/**
 * @file  get1.cxx
 * @brief Top-Level Input Routines
 *
 * (to be defined)
 *
 **/

#include <nana/nana.h>  // GNU Assertion/Logging Tool

#include "xanadu.h"
#include "alloc.h"

/**********************************************************************
 *
 **********************************************************************/
    bool
getfinddocscontaining(Session *sess, typespecset *specsetptr)
{
    return getspecset(sess, specsetptr);
}

/**********************************************************************
 *
 **********************************************************************/
    bool
getcopy(Session *sess, IStreamAddr *docisaptr, VStreamAddr *vsaptr, typespecset *localspecsetptr)
{
    prompt(sess, "copy to this document=> ");

    if (!getisa(sess, docisaptr))
        return false;

    prompt(sess, "at this address=> ");

    if (!(getvsa(sess, vsaptr) && getspecset(sess, localspecsetptr)))
        return false;

    return true;
}

/**********************************************************************
 *
 **********************************************************************/
    bool
getinsert(Session *sess, IStreamAddr *docisaptr, VStreamAddr *vsaptr, typetextset *textsetptr)
{
    prompt(sess, "text=>\n\n");

    if (!gettextset(sess, textsetptr))
        return false;

    prompt(sess, "document=> " );

    if (!getisa(sess, docisaptr))
        return false;

    prompt(sess, "address=> ");

    if (!getvsa(sess, vsaptr))
        return false;

    return true;
}

/**********************************************************************
 *
 **********************************************************************/
    bool
getcreatelink(Session *sess, IStreamAddr *docisaptr, typespecset *fromspecsetptr, typespecset *tospecsetptr, typespecset *threespecsetptr)
{
    prompt(sess, "home document=> ");

    if (!getisa(sess, docisaptr))
        return false;

    prompt(sess, "fromset\n");

    if (!getspecset(sess, fromspecsetptr))
        return false;

    prompt(sess, "toset\n");

    if (!getspecset(sess, tospecsetptr))
        return false;

    prompt(sess, "threeset\n");

    if (!getspecset(sess, threespecsetptr))
        return false;

    return true;
}

/**********************************************************************
 *
 **********************************************************************/
    bool
getfollowlink(Session *sess, IStreamAddr *linkisaptr, int *whichendptr)
{
    prompt(sess, "enter link=> ");

    if (!getisa(sess, linkisaptr))
        return false;

    prompt(sess, "enter endset=> ");

    if (!(getnumber(sess, whichendptr)
    && (*whichendptr == 1 || *whichendptr == 2 || *whichendptr == 3)))
        return false;

    return true;
}

/**********************************************************************
 *
 **********************************************************************/
    bool
getcreatenewversion(Session *sess, IStreamAddr *docisaptr)
{
    prompt(sess, "enter document=> ");

    return getisa(sess, docisaptr);
}

/**********************************************************************
 *
 **********************************************************************/
    bool
getretrievedocvspanset(Session *sess, IStreamAddr *docisaptr)
{
    prompt(sess, "enter document=> ");

    return getisa(sess, docisaptr);
}

/**********************************************************************
 *
 **********************************************************************/
    bool
getretrievedocvspan(Session *sess, IStreamAddr *docisaptr)
{
    prompt(sess, "enter document=> ");

    return getisa(sess, docisaptr);
}

/**********************************************************************
 *
 **********************************************************************/
    bool
getrearrange(Session *sess, IStreamAddr *docisaptr, typecutseq *cutseqptr)
{
    prompt(sess, "enter document=> ");

    if (!getisa(sess, docisaptr))
        return false;

    prompt(sess, "enter cutseq=>\n");

    if (!getcutseq(sess, cutseqptr))
        return false;

    return true;
}

/**********************************************************************
 *
 **********************************************************************/
    bool
getretrievev(Session *sess, typespecset *specsetptr)
{
    return getspecset(sess, specsetptr);
}

/**********************************************************************
 *
 **********************************************************************/
    bool
getfindlinksfromtothree(Session *sess, typespecset *fromvspecsetptr, typespecset *tovspecsetptr,
            typespecset *threevspecsetptr, typeispanset *homesetptr)
{
    prompt(sess, "fromset\n");

    if (!getspecset(sess, fromvspecsetptr))
        return false;

    prompt(sess, "toset\n");

    if (!getspecset(sess, tovspecsetptr))
        return false;

    prompt(sess, "threeset\n");

    if (!getspecset(sess, threevspecsetptr))
        return false;

    prompt(sess, "home documents\n");

    if (!getspanset(sess, homesetptr, ISPANID))
        return false;

    return true;
}

/**********************************************************************
 *
 **********************************************************************/
    bool
getfindnumoflinksfromtothree(Session *sess, typespecset *fromvspecsetptr, typespecset *tovspecsetptr,
    typespecset *threevspecsetptr, typeispanset *homesetptr)
{
    return getfindlinksfromtothree(sess, fromvspecsetptr, tovspecsetptr, threevspecsetptr, homesetptr);
}

/**********************************************************************
 *
 **********************************************************************/
    bool
getfindnextnlinksfromtothree(Session *sess, typespecset *fromvspecsetptr, typespecset *tovspecsetptr,
   typespecset *threevspecsetptr, typeispanset *homesetptr, IStreamAddr *lastlinkptr, int *nptr)
{
    if (!getfindlinksfromtothree(sess, fromvspecsetptr, tovspecsetptr, threevspecsetptr, homesetptr))
        return false;

    prompt(sess, "last link=> ");

    if (!getisa(sess, lastlinkptr))
        return false;

    prompt(sess, "number of links => ");

    if (!getnumber(sess, nptr))
        return false;

    return true;
}

/* getnavigateonht */

/**********************************************************************
 *
 **********************************************************************/
    bool
getshowrelationof2versions(Session *sess, typespecset *version1ptr, typespecset *version2ptr)
{
    prompt(sess, "version1\n");

    if (!getspecset(sess, version1ptr))
        return false;

    prompt(sess, "version2\n");

    if (!getspecset(sess, version2ptr))
        return false;

    return true;
}

/**********************************************************************
 *
 **********************************************************************/
    void
getcreatenewdocument()
{
}

/**********************************************************************
 *
 **********************************************************************/
    bool
getdeletevspan(Session *sess, IStreamAddr *docisaptr, typevspan *vspanptr)
{
    prompt(sess, "document=> ");

    if (!getisa(sess, docisaptr))
        return false;

    prompt(sess, "delete this part\n");

    if (!getspan(sess, vspanptr, VSPANID /*zzz*/))
        return false;

    return true;
}

/**********************************************************************
 *
 **********************************************************************/
    bool
setdebug(Session *sess)
{
    prompt(sess, "set debug => ");
    getnumber(sess, &debug);
    return debug;
}

/**********************************************************************
 *
 **********************************************************************/
    void
playwithalloc(Session *sess)
{
    prompt(sess, "playwithalloc\n");
    lookatalloc();
}

/**********************************************************************
 *
 **********************************************************************/
    bool
getretrieveendsets(Session *sess, typespecset *specsetptr)
{
    return getspecset(sess, specsetptr);
}

/**********************************************************************
 *
 **********************************************************************/
    bool
getxaccount(Session *sess, IStreamAddr *accountptr)
{
    /*
     * accountptr->clear();
     * return true;
     */

    /* prompt(sess, "account? "); */

    gettumbler(sess, accountptr) && validaccount(sess, accountptr);

    sess->account = *accountptr;

    cerr << "in get xaccount" << endl;

    return true;
}

/**********************************************************************
 *
 **********************************************************************/
    bool
getcreatenode_or_account(Session *sess, Tumbler *tp)
{
    gettumbler(sess, tp);

    return true;
}

/**********************************************************************
 *
 **********************************************************************/
    bool
getopen(Session *sess, Tumbler *tp, int *typep, int *modep)
{
    gettumbler(sess, tp);
    getnumber(sess, typep);
    getnumber(sess, modep);

    return true;
}

/**********************************************************************
 *
 **********************************************************************/
    bool
getclose(Session *sess, Tumbler *tp)
{
    gettumbler(sess, tp);

    return true;
}

/**********************************************************************
 *  Original Copyright � 1979-1999 Udanax.com.   All Rights Reserved
 **********************************************************************/
