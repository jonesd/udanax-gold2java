/**
 * @file  knives.cxx
 * @brief Crum Rearrange and Deletion Routines
 *
 * (to be defined)
 *
 **/

#include <nana/nana.h>  // GNU Assertion/Logging Tool

#include "knives.h"

/**********************************************************************
 *
 **********************************************************************/
    void
Knives::sort()
{
    int i;
    for (i = 0; i < nblades - 1; ++i) {
        if (blade[i] > blade[i+1]) {

            StreamAddr temp = blade[i+1];
            blade[i+1]      = blade[i];
            blade[i]        = temp;

            --i;
        }
    }
}

/**********************************************************************
 *  Original Copyright � 1979-1999 Udanax.com.   All Rights Reserved
 **********************************************************************/

