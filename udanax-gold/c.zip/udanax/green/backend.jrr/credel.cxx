/**
 * @file  credel.cxx
 * @brief Enfilade Creation and Deletion Routines
 *
 * (to be defined)
 *
 **/

#include <memory.h>
#include <unistd.h>

#include <nana/nana.h>  // GNU Assertion/Logging Tool

#define NEWALLOC
#include "common.h"
#include "xanadu.h"
#include "enf.h"
#include "reap.h"
#include "coredisk.h"
#include "queues.h"
#include "alloc.h"

#define MAXALLOCQUEUEARRAY 500
struct queue allocqueuearray[MAXALLOCQUEUEARRAY];

bool           ingrimreaper      = false;
int            reaplevel         = 0;
int            timesaroundreaper = 0;
int            reapnumber        = 0;
int            nreapings         = 0;
int            reservnumber      = 0;

/**********************************************************************
 *
 **********************************************************************/
/*
 *    void
 *etag(char *ptr, tagtype tag)
 *{
 *    *(ptr - sizeof(tagtype)) = tag;
 *}
 */

/**********************************************************************
 *
 **********************************************************************/
    int *
eallocwithtag(unsigned nbytes, tagtype tag)
{
    char * ret;

    if (tag == CBCTAG || tag== CUCTAG)
        ret = (char *) ealloc(nbytes);
    else {
//        ret = (char *) malloc(nbytes + sizeof(tagtype));
        ret = new char[nbytes + sizeof(tagtype)];
        ret += sizeof(tagtype);
    }

    /* etag((char *) ret, tag) ;*/

    *(ret - sizeof(tagtype)) = tag;
    return (int *) ret;
}

/**********************************************************************
 *
 **********************************************************************/
    int *
ealloc(unsigned nbytes)   /* with tag*/
{
    char *ret;

    for (;;) {
        if ((ret = allocfromqueue(nbytes + sizeof(tagtype))) != NULL) {
            ret += sizeof(tagtype);
            return (int *) ret;
        }
        ret = (char *) falloc(nbytes + sizeof(tagtype));

        if (ret) {
            /* setmem(ret + sizeof(tagtype), nbytes, 0xf9); */
            *(tagtype *) ret = false;
            return (int *) (ret + sizeof(tagtype));
        }

        if (Enfilade::grimreaper == NULL) {
            xgrabmorecore();
            /* qerror("Why am I out of room?\n"); */
        }

        grimlyreap();
    }
}

/**********************************************************************
 *
 **********************************************************************/
    void
efree(char *ptr)  /* with tag */
{
    /* ffree(ptr); */

    if (*(ptr - sizeof(tagtype)) == CBCTAG || *(ptr - sizeof(tagtype)) == CUCTAG) {
#ifdef NEWALLOC
        freetoqueue(ptr - sizeof(tagtype));
#else
        ffree(ptr - sizeof(tagtype));
#endif
    } else
        delete (char *) (ptr - sizeof(tagtype));
}

/**********************************************************************
 *
 **********************************************************************/
/*
 *    void
 *efreewithtag(char *ptr)
 *{
 *    ffree(ptr - sizeof(tagtype));
 *}
 */

/**********************************************************************
 *
 **********************************************************************/
    void
initgrimreaper()
{
    Enfilade::grimreaper = NULL;
}

/**********************************************************************
 *
 **********************************************************************/
    void
grimlyreap()
{
    CoreCrum *ptr;
    int eh;

    ingrimreaper = true;
    if (reaplevel++) /*-------------- BUG HERE ------------------*/
#ifndef DISTRIBUTION
        if (reaplevel == 1)
            cerr << "Recursive grimreaper call." << endl;
#endif

    if (!Enfilade::grimreaper)
        gerror("nothing to reap!\n");

    reapnumber = 0;
    timesaroundreaper = 0;

    for (ptr = Enfilade::grimreaper; Enfilade::grimreaper; Enfilade::grimreaper = (CoreCrum *) Enfilade::grimreaper->nextcrum) {
        if (Enfilade::grimreaper == ptr)
            ++timesaroundreaper;

        if (timesaroundreaper > 10) {
            cerr << "urk in grimlyreap" << endl;
            /* lookatalloc(); */
            xgrabmorecore();
            break;
        }

        if (Enfilade::grimreaper->age == RESERVED)
            continue;

        if (isreapable(&eh, Enfilade::grimreaper)) {
            reap(Enfilade::grimreaper);
            reapnumber = 0;
            timesaroundreaper = 0;
            --reaplevel;
            break;
        }

        ++reapnumber;
        Enfilade::grimreaper->age++;
    }

    ingrimreaper = false;
}

/**********************************************************************
 *
 **********************************************************************/
    bool
isreapable(int *fuckinap, CoreCrum *localreaper)
{
    CoreCrum *p;
    CoreUpperCrum *father;

    *fuckinap = 0;
    if (!localreaper)
        gerror("localreaper NULL\n");

    if (localreaper->age < OLD || localreaper-> age == RESERVED) {
        *fuckinap = 1;
        return false;
    }

    if (localreaper->isapex) {
        if (localreaper->cenftype != POOM)
            return false;

        if (localreaper->modified) {
            if (!((CoreUpperCrum *) localreaper)->leftson) {
                dump(localreaper);
                cerr << "in isreapable modified and no son in apex" << endl;
                return false;
            }

            for (p = ((CoreUpperCrum *) localreaper)->leftson; p; p = p->rightbro) {
                if (p->modified)
                    return false;

                if (p ->age < OLD || p-> age == RESERVED)
                    return false;

                if (p->height > 0 && ((CoreUpperCrum *) p)->leftson)
                    return false;

                if (p->height == 0 && p->cenftype == GRAN && ((CoreBottomCrum *) p)->cinfo.infotype == CoreBottomCrum::GRANORGL
                && ((CoreBottomCrum *) p)->cinfo.granstuff.orglstuff.orglincore)

                    return false;
            }
            return(true);

        } else {
            for (p = ((CoreUpperCrum *) localreaper)->leftson; p; p = p->rightbro) {
                if (p->modified)
                    return false;

                if (p->age < OLD || p-> age == RESERVED)
                    return false;

                if (p->height > 0 && ((CoreUpperCrum *) p)->leftson)
                    return false;

                if (p->height == 0 && p->cenftype == GRAN && ((CoreBottomCrum *) p)->cinfo.infotype == CoreBottomCrum::GRANORGL
                && ((CoreBottomCrum *) p)->cinfo.granstuff.orglstuff.orglincore)

                    return false;
            }
            return true;
        }
    }

    /* if height == 0 and not cinfo.orglincore return true */
    if (!localreaper)
        gerror("in isreapable localreaper is NULL\n");

    father = localreaper->weakFather();
    if (!father) {
        cerr << "in isreapable no father !!" << endl;
        return false;
    }

    if (localreaper->height == 0) {
        if (localreaper->cenftype == GRAN) {
            if (((CoreBottomCrum *) localreaper)->cinfo.infotype == CoreBottomCrum::GRANORGL) {
                if (((CoreBottomCrum *) localreaper)->cinfo.granstuff.orglstuff.orglincore)
                    return false;
            }
        }

        for (p = localreaper->weakLeftmostBrother(); p; p = p->rightbro) {
            if (p ->age < OLD || p-> age == RESERVED)
                return false;

            if (p->height == 0 && p->cenftype == GRAN && ((CoreBottomCrum *) p)->cinfo.infotype == CoreBottomCrum::GRANORGL
            && ((CoreBottomCrum *) p)->cinfo.granstuff.orglstuff.orglincore)

                return false;
        }
        return true;

    } else { /* != 0 */
        if (father->modified) {
            for (p = localreaper->weakLeftmostBrother(); p; p = p->rightbro) {
                if (p->modified)
                    return false;

                if (p ->age < OLD || p-> age == RESERVED)
                    return false;

                if (p->height > 0 && ((CoreUpperCrum *) p)->leftson)
                    return false;
            }
            return true;

        } else { /* if (!father->modified) */
            for (p = localreaper->weakLeftmostBrother(); p; p = p->rightbro) {
                if (p->modified)
                    return false;

                if (p->age < OLD || p-> age == RESERVED)
                    return false;

                if (p->height > 0 && ((CoreUpperCrum *) p)->leftson)
                    return false;
            }
            return true;
        }
    }
}

/**********************************************************************
 *
 **********************************************************************/
    void
reap(CoreCrum *localreaper)
{
    I(localreaper != NULL);

    ++nreapings;

    CoreUpperCrum *temp;

    if (localreaper->isapex) {
        temp = (CoreUpperCrum *) localreaper->leftbroorfather;
        Enfilade::grimreaper = Enfilade::grimreaper->nextcrum;

        if (!temp)
            return;

        orglwrite((CoreBottomCrum *) temp);

        if (!localreaper)
            gerror("localreaper NULL2\n");

        return;
    }

    temp = localreaper->weakFather();
    if (!temp)
        gerror("localreaper doesn't have a father\n");

    if (!temp->leftson) {
        Enfilade::grimreaper = Enfilade::grimreaper->nextcrum;
        return;
    }

    subtreewrite(temp);
}

/**********************************************************************
 *
 * test to see if any reserved flags linger in the memory.  if they do is a gross error in crum stuff
 **********************************************************************/
    void
testforreservedness(char */*msg*/)
{
    int numreserved = 0;
    bool first;

    CoreCrum *ptr;
    for (ptr = Enfilade::grimreaper, first = true; ptr && (first ? true : ptr != Enfilade::grimreaper); ptr = ptr->nextcrum, first = false) {
        if (ptr->age == RESERVED) {
            ++numreserved;
            if (true || debug)
                dump(ptr);
        }
    }

    I(numreserved == 0); // There should be no lingering Reserves
    I(reservnumber == 0);
}

/**********************************************************************
 *
 **********************************************************************/
/* assumes crum is disowned */
    void
subtreefree(CoreCrum *ptr)
{
    CoreCrum *p, *right;

    if (!ptr)
        gerror("boom in subtreefree called with ptr == NULL");

    if (ptr->height > 0) {
        for (p = ((CoreUpperCrum *) ptr)->leftson; p; p = right) {
            right = p->rightbro;
            p->disown();
            subtreefree(p);
        }

    } else if (ptr->cenftype == GRAN && ((CoreBottomCrum *) ptr)->cinfo.infotype == CoreBottomCrum::GRANORGL
           && ((CoreBottomCrum *) ptr)->cinfo.granstuff.orglstuff.orglincore)

        orglfree(((CoreBottomCrum *)ptr)->cinfo.granstuff.orglstuff.orglptr);

    ((Enfilade *) ptr)->destroyCrum(ptr);
}

/**********************************************************************
 *
 **********************************************************************/
    void
loaffree(CoreUpperCrum *father)
{
    CoreCrum *ptr, *next;

    if (father->height <= 0 /* || !father->leftson */)
        gerror ("bad call\n");

    for (ptr = father->leftson; ptr; ptr = next) {
        next = ptr->rightbro;
        ptr->disownnomodify();
        subtreefree(ptr);
    }

    father->modified = false;
}

/**********************************************************************
 *
 **********************************************************************/
    void
orglfree(CoreUpperCrum *ptr)
{
    if (!ptr)
        qerror("orglfree called with no orglptr.\n");

    if (!ptr->isapex)
        gerror("Orglfree called with non-fullcrum.\n");

    if (((CoreBottomCrum *) ptr->leftbroorfather)->cinfo.granstuff.orglstuff.diskorglptr.diskblocknumber == NULLBLOCKNUM)
        qerror("orglfree called with unwritten-out orgl.\n");

    ((CoreBottomCrum *) ptr->leftbroorfather)->cinfo.granstuff.orglstuff.orglincore = false;
    ((CoreBottomCrum *) ptr->leftbroorfather)->cinfo.granstuff.orglstuff.orglptr = NULL;

    subtreefree((CoreCrum *) ptr);
}

/**********************************************************************
 *
 **********************************************************************/
    void
initcrum(int crumheight, int enftype, CoreCrum *ptr)
{
//fixme    Enfilade::createCrumInternal(crumheight, enftype, ptr);
}

/**********************************************************************
 *
 **********************************************************************/
    void
initqueues()
{
    int i, j, num;

    for (i = 0; i < MAXALLOCQUEUEARRAY; i++)
        qinit(&allocqueuearray[i]);

#ifdef NEWALLOC
    num = allocsize / 3;
#else
    num = 0;
#endif

    for(j = 0; j < num; j += sizeof(CoreUpperCrum) + sizeof(CoreBottomCrum)+ sizeof(Core2dBottomCrum) + 3 * sizeof(tagtype)) {
        qpush(&allocqueuearray[ (sizeof(CoreUpperCrum) + sizeof(tagtype) + sizeof(HEADER) - 1) / sizeof(HEADER) ], (queue *) falloc(sizeof(CoreUpperCrum) + sizeof(tagtype)));
        qpush(&allocqueuearray[ (sizeof(CoreBottomCrum) + sizeof(tagtype) + sizeof(HEADER) - 1) / sizeof(HEADER) ], (queue *) falloc(sizeof(CoreBottomCrum) + sizeof(tagtype)));
        qpush(&allocqueuearray[ (sizeof(Core2dBottomCrum) + sizeof(tagtype) + sizeof(HEADER) - 1) / sizeof(HEADER) ], (queue *) falloc(sizeof(Core2dBottomCrum) + sizeof(tagtype)));
    }
}

/**********************************************************************
 *
 **********************************************************************/
    void
dumptable()
{
    int i, tmp;

    cerr << "dumptable" << endl;

    for(i = 0; i < MAXALLOCQUEUEARRAY; i++) {
        if ((tmp = qlength(&allocqueuearray[i])) != 0)
            cerr << "len of " << i << " = " << tmp << endl;
    }
}

/**********************************************************************
 *
 **********************************************************************/
    char *
allocfromqueue(int n)
{
    // cerr << "allocfromqueue called with " hex << n << dec << ' ' << ((n + sizeof(HEADER) - 1) / sizeof(HEADER)) << endl;

    return (char *) qremove(&allocqueuearray[ ((n + sizeof(HEADER) - 1) / sizeof(HEADER)) ]);
}

/**********************************************************************
 *
 **********************************************************************/
    void
freetoqueue(char *ptr)
{
    int n;

    /* back before the tag is the sizeof the block in align uints including the header */

    // dumptable();

    n = ((HEADER *) (ptr - sizeof(HEADER)))->s.size - 1;

    // cerr << "freetoqueue called with " << hex << ptr << "n = " << n << endl;

    qpush(&allocqueuearray[n], (queue *) ptr);

    // dumptable();
}

/**********************************************************************
 *
 **********************************************************************/
    void
xgrabmorecore()
{
    char *tmp = (char *) sbrk(incrementalallocsize);
    if (!tmp)
        gerror("no more memory in xgrabmorecore\n");

    ((HEADER *) tmp)->s.size = (incrementalallocsize + sizeof(HEADER) - 1) / sizeof(HEADER);
    ffree(tmp + sizeof(HEADER));

    cerr << "xgrabmorecore got another " << incrementalallocsize << endl;
}

/**********************************************************************
 *  Original Copyright � 1979-1999 Udanax.com.   All Rights Reserved
 **********************************************************************/
