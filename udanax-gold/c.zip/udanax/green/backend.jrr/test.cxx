/**
 * @file  test.cxx
 * @brief Enfilade Testing Routines
 *
 * Written to test Two dimensional enfilades; modified to test 2d, Span and Gran enfilades.
 *
 **/

#include <unistd.h>

#include <nana/nana.h>  // GNU Assertion/Logging Tool

#include "xanadu.h"
#include "enf.h"
#include "ndenf.h"
#include "coredisk.h"
#include "blockio.h"
#include "knives.h"

//extern bool gettumbler();

extern CoreCrum *grimreaper;
extern int reservnumber;
int numfoo = NUMDISKBLOCKSINLOAF;

extern char end;        /* lower limit (pointers should be into alloc space */
extern char etext;   /* as another lower limit on valid pointers */

//extern long nolread;
//extern long nolwrote;

void foo(char *msg);
void foospan(char *msg, typespan *span);
void foospanset(char *msg, typespan *spanset);
void dumpspanset(typespan *spanset);
void foocrum(char *msg, CoreCrum *crumptr);
void foohex(char *msg, int num);
void foodec(char *msg, int num);
void foocontext(char *msg, Context *context);
void foocontextlist(char *msg, Context *context);
void fooitemset(char *msg, typeitemset iptr);
void fooitem(char *msg, typeitem *iptr);
void foodsp(char *msg, Displacer *dptr, int enftype);
void foowid(char *msg, Widener *wptr, int enftype);
void dumpsubtree(CoreUpperCrum *father);
void dumpwholesubtree(CoreUpperCrum *father);
void assertspecisstring(typespecset specptr, char *string);
void assertsubtreeisok(CoreUpperCrum *ptr);
void assertsonswispmatchesfather(CoreUpperCrum *father);
void assertwidsarepositive(CoreCrum *ptr);
void dumpwholetree(CoreCrum *ptr);
bool checkwholesubtree(CoreUpperCrum *father);
bool check(CoreUpperCrum *ptr);
void dump(CoreCrum *ptr);
void yesdump(CoreCrum *ptr);
void dumphedr(CoreCrum *ptr);
void dumpwid(Widener *widptr, int enftype);
void dumpdsp(Displacer *dspptr, int enftype);
void dumpinfo(CoreBottomCrum::typegranbottomcruminfo *infoptr, int enftype);
void displaycutspm(Knives *knivesptr);
void examine(Session *sess);
void showorgl(Session *sess);
void showsubtree(CoreCrum *father);
void showistream(CoreUpperCrum *granfptr);
void showspanf(CoreUpperCrum *spanfptr);
void doshowspanf(CoreCrum *crumptr, Displacer *offsetptr, int enfheight);
void showspanfcrum(CoreCrum *crumptr, Displacer *offsetptr, int enfheight);
void dumpmem(char *loc, unsigned count);
bool dumpgranfwids(Session *sess);
void showgranwids(CoreCrum *crum, int down, StreamAddr *retptr);        /* down is distance from top */
void dumppoomwisps(CoreCrum *orgl);
void showpoomwisps(CoreUpperCrum *crum, int down)        /* down is distance from top */;
void dumpistreamgr(CoreUpperCrum *crumptr);
void dodumpistreamgr(CoreUpperCrum *crumptr, IStreamAddr *offsetptr);
void dumpmoleculegr(Tumbler *offsetptr, CoreBottomCrum *cbcptr);
void dumpisagr(Tumbler *offsetptr);
CoreCrum *checkenftypes(CoreUpperCrum *father, char *message);
CoreCrum *checkthebleedingcrum(CoreCrum *crumptr);
void teststack();
CoreCrum *sonoriginok(CoreCrum *father);
void dumpcontextlist(Context *context);
void dumpcontext(Context *context);
void dumpitemset(typeitemset itemset);
void dumpitem(typeitem *itemptr);
void dumpspan(typespan *spanptr);
void dumptext(typetext *textptr);
bool ioinfo(Session *sess);
bool showenfilades(Session *sess);
char *itemidstring(typeitem *item);
void checkitem(char *msg, typeitem *ptr);
void checkpointer(char *msg, char *ptr);
void dumpspanpairset(typespanpairset spanpairset);
void dumpspanpair(typespanpair *spanpair);
void dumphexstuff(char *ptr);
void checknumofsons(CoreUpperCrum *ptr);
void nchecknumofsons(CoreUpperCrum *ptr);

//void assertsonswispmatchesfather(CoreUpperCrum *father);
//void assertwidsarepositive(CoreCrum *ptr);
//void dumpwholetree(CoreCrum *ptr);

static void doshowspanf(CoreUpperCrum *crumptr, Displacer *offsetptr, int enfheight);

/**********************************************************************
 *
 **********************************************************************/
    void
foo(char *msg)
{
#ifndef DISTRIBUTION
    if (debug)
        cerr << msg;
#endif
}

/**********************************************************************
 *
 **********************************************************************/
    void
foospan(char *msg, typespan *span)
{
#ifndef DISTRIBUTION
    if (debug) {
        cerr << msg;
        dumpspan(span);
    }
#endif
}

/**********************************************************************
 *
 **********************************************************************/
    void
foospanset(char *msg, typespan *spanset)
{
#ifndef DISTRIBUTION
    if (debug) {
        cerr << msg;

        if (!spanset)
            cerr << "null spanset" << endl;

        else {
            for ( ; spanset; spanset = spanset->next)
                dumpspan(spanset);
        }
    }
#endif
}

/**********************************************************************
 *
 **********************************************************************/
    void
dumpspanset(typespan *spanset)
{
#ifndef DISTRIBUTION
    if (!spanset)
        cerr << "null spanset" << endl;

    else {
        for ( ; spanset; spanset = spanset->next)
            dumpspan(spanset);
    }
#endif
}

/**********************************************************************
 *
 **********************************************************************/
    void
foocrum(char *msg, CoreCrum *crumptr)
{
#ifndef DISTRIBUTION
    if (debug) {
        cerr << msg;
        dump(crumptr);
    }
#endif
}

/**********************************************************************
 *
 **********************************************************************/
    void
foohex(char *msg, int num)
{
#ifndef DISTRIBUTION
    if (debug)
        cerr << msg << ' ' << hex << num << dec << endl;
#endif
}

/**********************************************************************
 *
 **********************************************************************/
    void
foodec(char *msg, int num)
{
#ifndef DISTRIBUTION
    if (debug)
        cerr << msg << ' ' << dec << num << endl;
#endif
}

/**********************************************************************
 *
 **********************************************************************/
    void
foocontext(char *msg, Context *context)
{
#ifndef DISTRIBUTION
    if (debug) {
        cerr << msg;
        dumpcontext(context);
    }
#endif
}

/**********************************************************************
 *
 **********************************************************************/
    void
foocontextlist(char *msg, Context *context)
{
#ifndef DISTRIBUTION
    if (debug) {
        cerr << msg;
        dumpcontextlist(context);
    }
#endif
}

/**********************************************************************
 *
 **********************************************************************/
    void
fooitemset(char *msg, typeitemset iptr)
{
#ifndef DISTRIBUTION
    if (debug) {
        cerr << msg;
        dumpitemset(iptr);
    }
#endif
}

/**********************************************************************
 *
 **********************************************************************/
    void
fooitem(char *msg, typeitem *iptr)
{
#ifndef DISTRIBUTION
    if (debug) {
        cerr << msg;
        dumpitem(iptr);
        cerr << endl;
    }
#endif
}

/**********************************************************************
 *
 **********************************************************************/
    void
foodsp(char *msg, Displacer *dptr, int enftype)
{
#ifndef DISTRIBUTION
    if (debug) {
        cerr << msg;

        if (dptr)
            dumpdsp(dptr, enftype);
        else
            cerr << "NULL";

        cerr << endl;
    }
#endif
}

/**********************************************************************
 *
 **********************************************************************/
    void
foowid(char *msg, Widener *wptr, int enftype)
{
#ifndef DISTRIBUTION
    if (debug) {
        cerr << msg;

        if (wptr)
            dumpwid(wptr, enftype);
        else
            cerr << "NULL";

        cerr << endl;
    }
#endif
}

/**********************************************************************
 *
 **********************************************************************/
/* pass this the fullcrum to dump the entire (incore) enfilade */
    void
dumpsubtree(CoreUpperCrum *father)
{
#ifndef DISTRIBUTION
    CoreCrum *ptr;

    if (father->cenftype == POOM) {
        dumppoomwisps((CoreCrum *) father);
        return;
    }

    dump((CoreCrum *) father);

    if (father->height <= 0)
        return;

    for (ptr = father->leftson; ptr; ptr = ptr->rightbro)
        dumpsubtree((CoreUpperCrum *) ptr);
#endif
}

/**********************************************************************
 *
 **********************************************************************/
    void
dumpwholesubtree(CoreUpperCrum *father)
{
#ifndef DISTRIBUTION
    CoreCrum *ptr;

    cerr << "dump whole subtree";

    if (father->cenftype == POOM) {
        dumppoomwisps((CoreCrum *) father);
        return;
    }

    dump((CoreCrum *) father);

    if (father->height <= 0)
        return;

    for (ptr = father->leftSon(); ptr; ptr = ptr->rightBrother())
        dumpwholesubtree((CoreUpperCrum *) ptr);
#endif
}

/**********************************************************************
 *
 **********************************************************************/
    void
assertspecisstring(typespecset specptr, char *string)
{
#ifndef DISTRIBUTION
    Session taskfoo;
    typevstuffset vstuffset;
    int savedebug;

    savedebug = debug;

    /* debug = false; */

    inittask(&taskfoo);
    doretrievev(&taskfoo, specptr, &vstuffset);

    /*
     * for (i = 0; (i < vstuffset->length) && (string[i] == vstuffset->string[i]); i++)
     *     ;
     *
     * if (i != vstuffset->length) {
     *     fprintf(stderr, "in assertspecisstring failedstring1 =%s string2 =%s %d\n",
     *         string, vstuffset->string, vstuffset->length);
     *     debug = true;
     *     fooitem("spec is ", specptr);
     *     fooitem("\nvstuff is ", vstuffset);
     *     // crash bang boom //
     *     gerror("assertspecisstring asserton failed \n");
     * }
     *
     * fprintf(stderr, "in assertspecisstring succeeded %s \n", string);
     */

    tfree(&taskfoo);
    debug = savedebug;
#endif
}

/**********************************************************************
 *
 **********************************************************************/
    bool
asserttreeisok(CoreCrum *ptr)
{
    return true;

    /*
     * for ( ; !ptr->isTopmost(); ptr = ptr->father())
     *     ;
     *
     * assertsubtreeisok(ptr);
     * return true;
     */
}

/**********************************************************************
 *
 **********************************************************************/
    void
assertsubtreeisok(CoreUpperCrum *ptr)
{
#ifndef DISTRIBUTION
    CoreCrum *son;

    if (!ptr)
        gerror("assertsubtreeok failed null ptr\n");

    assertwidsarepositive(ptr);
    if (!reservnumber) {
        if (ptr->age == RESERVED) {
            dump(ptr);
            gerror("incorrect reserved in assertsubtreeisok");
        }
    }

    if (ptr->height == 0)
        return;

    I(!ptr->toomanysons());

    assertsonswispmatchesfather((CoreUpperCrum *) ptr);

    for (son = ((CoreUpperCrum *) ptr)->leftson; son; son = son->rightbro)
        assertsubtreeisok((CoreUpperCrum *) son);
#endif
}

/**********************************************************************
 *
 **********************************************************************/
    void
assertsonswispmatchesfather(CoreUpperCrum *father)
{
#ifndef DISTRIBUTION
    if (father->numberofsons == 0) {
        if (father->sonorigin.diskblocknumber != NULLBLOCKNUM)
            return;

        cerr << "zerosons in assert" << endl;
        return;
    }

    if (setwisp((CoreCrum *) father)) {
        cerr << "assert wisp matched father failed" << endl;
        dump((CoreCrum *) father);
        dumpwholetree((CoreCrum *) father);
    }
#endif
}

/**********************************************************************
 *
 **********************************************************************/
    void
assertwidsarepositive(CoreCrum *ptr)
{
#ifndef DISTRIBUTION
    int nstreams, i, enftype;

    enftype = ptr->cenftype;

    if (enftype == GRAN)
        return;

    nstreams = widsize(enftype);
    for (i = 0; i < nstreams; ++i)
        tumblercheckptr(&(ptr->cwid[i]), (int *) ptr);

    nstreams = dspsize(enftype);
    for (i = 0; i < nstreams; ++i)
        tumblercheckptr(&(ptr->cdsp[i]), (int *) ptr);
#endif
}

/**********************************************************************
 *
 **********************************************************************/
    void
dumpwholetree(CoreCrum *ptr)
{
#ifndef DISTRIBUTION
    cerr << "dump whole tree" << endl;

    for( ; !ptr->isTopmost(); ptr = ptr->father())
        ;

    dumpwholesubtree((CoreUpperCrum *) ptr);
#endif
}

/**********************************************************************
 *
 **********************************************************************/
    bool
checkwholesubtree(CoreUpperCrum *father)
{
#ifndef DISTRIBUTION
//    CoreCrum *ptr;
    return 0;

#ifdef UndEfIneD
    if (!father)
        return(0);

    if (check(father)) {
        cerr << "found something bad in checkwholesubtree" << endl;
        dumpsubtree(father);
        /* gerror("in checkwholesubtree"); */

        return 1;
    }

    if (father->height <= 0)
        return 0;

    for (ptr = father->leftson; ptr; ptr = ptr->rightbro)
        if (checkwholesubtree(ptr))
            return 1;

    return 0;
#endif
#endif
}

/**********************************************************************
 *
 **********************************************************************/
    bool
check(CoreUpperCrum *ptr)
{
    return 0;

#ifdef UnDeeFiNeD
   if (ptr->height == 0)
       return 0;

    if (ptr->leftson == NULL /* && ptr->sonorigin.diskblocknumber == -1 */ && ptr->modified) {
        dump(ptr);
        gerror("in check\n");

    } else
        return 0;

    gerror("check: can't get ther\n");
    return 0;
#endif
}

/**********************************************************************
 *
 **********************************************************************/
/* dump a core crum */
    void
dump(CoreCrum *ptr)
{
#ifndef DISTRIBUTION
    cerr << endl;
    dumphedr(ptr);

    if (ptr->height) {
//        fprintf(stderr, "sonorigin = %x insideloaf %x  leftson = %x  #sons = %x\n",
//            ((CoreUpperCrum *) ptr)->sonorigin.diskblocknumber,
//            ((CoreUpperCrum *) ptr)->sonorigin.insidediskblocknumber,
//            (int) ((CoreUpperCrum *) ptr)->leftson,
//            ((CoreUpperCrum *) ptr)->numberofsons);
//
    } else
        dumpinfo(&((CoreBottomCrum *) ptr)->cinfo, ptr->cenftype);
#endif
}

/**********************************************************************
 *
 **********************************************************************/
    void
yesdump(CoreCrum *ptr)   /* because dbx has a builtin dump   name conflict*/
{
#ifndef DISTRIBUTION
    dump(ptr);
#endif
}

/**********************************************************************
 *
 **********************************************************************/
/* dump a corecrumhedr */
    void
dumphedr(CoreCrum *ptr)
{
#ifndef DISTRIBUTION
    char *temp;
    char *full;

    switch (ptr->cenftype) {
    case GRAN:  temp = "GRAN";         break;
    case SPAN:  temp = "SPAN";         break;
    case POOM:  temp = "POOM";         break;
    default:    temp = "bad enftype";  cerr << ptr->cenftype; break;
    }

    full = (ptr->isapex ? "full" : "");

//    fprintf(stderr, "%s %scrum core location = %x\n", temp, full, (int) ptr);

//    fprintf(stderr, "height = %x nextcrum = %x  modified = %x\n",
//            ptr->height, (int) ptr->nextcrum, ptr->modified);

//    fprintf(stderr, " age = %x ", ptr->age);

//    fprintf(stderr, "isleftmost = %x leftbro = %x rightbro = %x\n",
//        ptr->isleftmost, (int) ptr->leftbroorfather, (int) ptr->rightbro);

    dumpdsp(&ptr->cdsp, ptr->cenftype);
    dumpwid(&ptr->cwid, ptr->cenftype);
#endif
}

/**********************************************************************
 *
 **********************************************************************/
    void
dumpwid(Widener *widptr, int enftype)
{
#ifndef DISTRIBUTION
    int i, nstreams;

    nstreams = widsize(enftype);
    cerr << "wid = < ";
    for (i = 0; i < nstreams; ++i) {
        if (i > 0)
            cerr << " , ";

        cerr << (*widptr)[i];
    }

    cerr << " >\n";
#endif
}

/**********************************************************************
 *
 **********************************************************************/
    void
dumpdsp(Displacer *dspptr, int enftype)
{
#ifndef DISTRIBUTION
    int i, nstreams;

    /* if (enftype == GRAN) return; */

    nstreams = dspsize(enftype);
    cerr << "dsp = < ";

    for (i = 0; i < nstreams; ++i) {
        if (i > 0)
            cerr << " , ";

        cerr << (*dspptr)[i];
    }

    cerr << " >\n";
#endif
}

/**********************************************************************
 *
 **********************************************************************/
    void
dumpinfo(CoreBottomCrum::typegranbottomcruminfo *infoptr, int enftype)
{
#ifndef DISTRIBUTION
    if (enftype == GRAN) {
        switch (infoptr->infotype) {
        case CoreBottomCrum::GRANTEXT:
//            fprintf(stderr, "text:  %s\n", infoptr->granstuff.textstuff.textstring);
            break;

        case CoreBottomCrum::GRANORGL:
//            fprintf(stderr, " diskorgl %x, ", (int) &infoptr->granstuff.orglstuff.diskorglptr);
//            fprintf(stderr, "orgl %x\n ", (int) &infoptr->granstuff.orglstuff.orglptr);
            break;

        case CoreBottomCrum::GRANNULL:
//            fprintf(stderr, "GRANNULL info\n");
            break;

        default:
//            fprintf(stderr, "empty infotype: %d\n", infoptr->infotype);
            gerror("bad in dumpinfo \n");
            break;
        }

    } else {
        cerr << "home document: ";
        cerr << ((Core2dBottomCrum::type2dbottomcruminfo *) infoptr)->homedoc;
        cerr << endl;
    }
#endif
}

/**********************************************************************
 *
 **********************************************************************/
    void
displaycutspm(Knives *knivesptr)
{
#ifndef DISTRIBUTION
    int i;

    cerr << hex << knivesptr->nblades << " cuts:";
    for (i = 0; i < knivesptr->nblades; ++i) {
        cerr << "\n       ";
        cerr << knivesptr->blade[i];
    }

    cerr << endl;
#endif
}

/**********************************************************************
 *
 **********************************************************************/
//    void
//dumphint(typehint *hintptr)
//{
//#ifndef DISTRIBUTION
//    fprintf(stderr, "\nHINT\n");
//    fprintf(stderr, "  supertype: %d\n", hintptr->supertype);
//    fprintf(stderr, "  subtype:   %d\n", hintptr->subtype);
//    fprintf(stderr, "  atomtype:  %d\n", hintptr->atomtype);
//    fprintf(stderr, "  isa:       ");
//    cerr << hintptr->hintisa;
//    fprintf(stderr, "\n");
//#endif
//}

/**********************************************************************
 *
 **********************************************************************/
    void
examine(Session *sess)
{
#ifndef DISTRIBUTION
    char c;
//    IStreamAddr orglisa;
//    typeorgl orgl;

    prompt(sess, "\nspanf (s), orgl (o) or istream (i) ? ");
    sess->inp >> c;
    if (c != '\n')
        sess->inp.ignore();

//    fprintf(stderr, "\n");

    switch (c) {
    case 'i':
        showistream((CoreUpperCrum *) granf);
        break;

    case 's':
        showspanf((CoreUpperCrum *) spanf);
        break;

    case 'o':
        /*
         * prompt(sess, "orgl isa => ");
         * if (!(gettumbler(sess, &orglisa)
         * && findorgl(sess, granf, &orglisa, &orgl, READBERT))) {
         *     fprintf(stderr, sess->errp, "\nnot found\n");
         *
         * } else
         *     showspanf(orgl);
         */

        showorgl(sess);
        break;
    }
#endif
}

/**********************************************************************
 *
 **********************************************************************/
    void
showorgl(Session *sess)
{
#ifndef DISTRIBUTION
    typeorgl  orgl;
    IStreamAddr   orglisa;

    prompt(sess, "orgl isa => ");

    if (!(gettumbler(sess, &orglisa)
    && findorgl(sess, granf, &orglisa, &orgl, READBERT))) {
//        fprintf(stderr, "\nnot found\n");

    } else
        showsubtree((CoreCrum *) orgl);
#endif
}

/**********************************************************************
 *
 **********************************************************************/
    void
showsubtree(CoreCrum *father)
{
#ifndef DISTRIBUTION
//    int temp;

    /*
     * temp = debug;
     * debug = 5;
     */

    dumpwholesubtree((CoreUpperCrum *) father);

    /* debug = temp; */
#endif
}

/**********************************************************************
 *
 **********************************************************************/
    void
showistream(CoreUpperCrum *granfptr)
{
#ifndef DISTRIBUTION
//    int temp;

    /*
     * temp = debug;
     * debug = 5;
     */

    dumpistreamgr(granfptr);

    /* debug = temp; */
#endif
}

/**********************************************************************
 *
 **********************************************************************/
    void
showspanf(CoreUpperCrum *spanfptr)
{
#ifndef DISTRIBUTION
    Displacer offset;
    int enfheight;

    memset(&offset, 0, sizeof(offset));
    enfheight = spanfptr->height;

    cerr << endl;
    doshowspanf(spanfptr, &offset, enfheight);
#endif
}

/**********************************************************************
 *
 **********************************************************************/
    static void
doshowspanf(CoreUpperCrum *crumptr, Displacer *offsetptr, int enfheight)
{
#ifndef DISTRIBUTION
    CoreCrum *ptr;
    Displacer loffset;

    showspanfcrum(crumptr, offsetptr, enfheight);

    if (crumptr->height <= 0)
        return;

//    dspadd(offsetptr, &crumptr->cdsp, &loffset, crumptr->cenftype);
    loffset = add(*offsetptr, crumptr->cdsp, crumptr->cenftype);

    for (ptr = crumptr->leftSon(); ptr; ptr = ptr->rightbro)
        doshowspanf((CoreUpperCrum *) ptr, &loffset, enfheight);
#endif
}

/**********************************************************************
 *
 **********************************************************************/
    void
showspanfcrum(CoreCrum *crumptr, Displacer *offsetptr, int enfheight)
{
#ifndef DISTRIBUTION
    int depth;
    Displacer lstream;

    for (depth = enfheight - crumptr->height; depth--; )
        cerr << "  ";

    cerr << "[spandsp";

//    dspadd(offsetptr, &crumptr->cdsp, &lstream, crumptr->cenftype);
    lstream = add(*offsetptr, crumptr->cdsp, crumptr->cenftype);

    cerr << lstream[SPANRANGE];

    cerr << " ,spanwid  ";
    cerr << crumptr->cwid[SPANRANGE];
    cerr << "]" << endl;

    for (depth = enfheight - crumptr->height; depth--; )
        cerr << "  ";

    cerr << "[orgldsp ";
    cerr << lstream[ORGLRANGE];
    cerr << " ,orglwid  ";
    cerr << crumptr->cwid[ORGLRANGE];
    cerr << "]   ";

    if (crumptr->height == 0)
        cerr << ((Core2dBottomCrum *) crumptr)->c2dinfo.homedoc;

    cerr << endl << endl;
#endif
}

/**********************************************************************
 *
 **********************************************************************/
    void
dumpmem(char *loc, unsigned count)
{
#ifndef DISTRIBUTION
//    int i;

//    cerr << " loc = %x\n", (int) loc);

//    for (i = 0; count--; ++loc, (i+1 < 64 ? ++i : (i = 0))) {
//        if ((*loc & 0x7f) < ' ')
//            fprintf(stderr, "%c", '.');
//        else
//            fprintf(stderr, "%c", *loc);
//
//        if (i == 63)
//            fprintf(stderr, "\n");
//    }
//
//    fprintf(stderr, "\n");
#endif
}

/**********************************************************************
 *
 **********************************************************************/
    bool
dumpgranfwids(Session *sess)
{
#ifndef DISTRIBUTION
    StreamAddr subtreewid;
//    int fullheight;

    /* fullheight = ((CoreCrum *) granf)->height; */

    showgranwids((CoreCrum *) granf, 0, &subtreewid);

    if (subtreewid != ((CoreCrum *) granf)->cwid[WIDTH]) {
//        fprintf(stderr, "Granfilade fullcrum wid and widded enfilade don\'t match.\n");
//        fprintf(stderr, "gran fullcrum wid ");
//        puttumbler(stderr, &((CoreCrum *) granf)->cwid[WIDTH]);
//
//        fprintf(stderr, "\nreturned wid from subtree ");
//        puttumbler(stderr, &subtreewid);
//
//        fprintf(stderr, "\nHit \"<return>\" to continue, \"a<return>\" to abort ");
//        if (getc(sess->inp) == 'a')
//            abort ();
    }

//    fprintf(stderr, "\n");
#endif

    return true;
}

/**********************************************************************
 *
 **********************************************************************/
    void
showgranwids(CoreCrum *crum, int down, StreamAddr *retptr)        /* down is distance from top */
{
#ifndef DISTRIBUTION
    CoreCrum *ptr;
    StreamAddr subtreewid;

    cerr << endl;

    memset(retptr, 0, sizeof(*retptr));

    int i;
    for (i = 0; i < down; i++)
        cerr << "        ";

//    fprintf(stderr, "%x (%d%c) < ", (int) crum, crum->height, (crum->modified ? 'M' : '-'));
    cerr << crum->cwid[WIDTH];
    cerr << " >";

    if (crum->height != 0) {
        if (((CoreUpperCrum *) crum)->leftson) {
            for (ptr = ((CoreUpperCrum *) crum)->leftson; ptr; ptr = ptr->rightbro) {
                *retptr = *retptr + ptr->cwid[WIDTH];

                showgranwids(ptr, down+1, &subtreewid);
                if (subtreewid != ptr->cwid[WIDTH]) {
//                    fprintf(stderr, "\n%d level crum\'s wid and result from subtree don\'t match\n", crum->height);
                    cerr << "father wid ";
                    cerr << ptr->cwid[WIDTH];
                    cerr << endl << "returned wid ";
                    cerr << subtreewid;
                    cerr << endl;
                }
            }
        } else {
//            fprintf(stderr, " disksonloaf = %x ", ((CoreUpperCrum *) crum)->sonorigin.diskblocknumber);

//FIXME            *retptr = crum->cwid[WIDTH];

            /* so that lacking incore sons will not cause error */
        }

    } else if (((CoreBottomCrum *) crum)->cinfo.infotype == CoreBottomCrum::GRANORGL) {
//        if (((CoreBottomCrum *) crum)->cinfo.granstuff.orglstuff.orglincore)
//            fprintf(stderr, " orgl %x ", (int) ((CoreBottomCrum *) crum)->cinfo.granstuff.orglstuff.orglptr);
//        else
//            fprintf(stderr, " diskorgl %x", (int) &((CoreBottomCrum *) crum)->cinfo.granstuff.orglstuff.diskorglptr);

//FIXME        *retptr = crum->cwid[WIDTH];

    }
//FIXME   else     *retptr = crum->cwid[WIDTH];
#endif
}

/**********************************************************************
 *
 **********************************************************************/
    void
dumppoomwisps(CoreCrum *orgl)
{
#ifndef DISTRIBUTION
    /* int fullheight = orgl->height; */

    showpoomwisps((CoreUpperCrum *) orgl, 0);
    cerr << endl;
#endif
}

/**********************************************************************
 *
 **********************************************************************/
    void
showpoomwisps(CoreUpperCrum *crum, int down)        /* down is distance from top */
{
#ifndef DISTRIBUTION
//    CoreCrum *ptr;
//    int i;

    cerr << endl;
//    for (i = 0; i < down; ++i)
//        fprintf(stderr, "   ");
//
//    fprintf(stderr, "%x (%d%c) <Idsp ", (int) crum, crum->height, (crum->modified ? 'M' : '-'));
//    puttumbler(stderr, &crum->cdsp[I_BASIS]);
//
//    fprintf(stderr, ", Vdsp ");
//    puttumbler(stderr, &crum->cdsp[V_BASIS]);
//
//    fprintf(stderr, " > <Iwid ");
//    puttumbler(stderr, &crum->cwid[I_BASIS]);
//
//    fprintf(stderr, ", Vwid ");
//    puttumbler(stderr, &crum->cwid[V_BASIS]);
//
//    fprintf (stderr," >");
//    if (crum->height != 0) {
//        if (crum->leftson) {
//            for (ptr = crum->leftSon(); ptr; ptr = ptr->rightbro) {
//                showpoomwisps((CoreUpperCrum *) ptr, down+1);
//            }
//        } else {
//            fprintf(stderr, " disksonloaf = %x ", crum->sonorigin.diskblocknumber);
//        }
//    }
#endif
}

/**********************************************************************
 *
 **********************************************************************/
#define TABSTOP 20

    void
dumpistreamgr(CoreUpperCrum *crumptr)
{
#ifndef DISTRIBUTION
    IStreamAddr offset;

    if (debug < 5)
        return;

    offset.clear();
    dodumpistreamgr(crumptr, &offset);
#endif
}

/**********************************************************************
 *
 **********************************************************************/
    void
dodumpistreamgr(CoreUpperCrum *crumptr, IStreamAddr *offsetptr)
{
#ifndef DISTRIBUTION
    if (crumptr->height == 0) {
        dumpmoleculegr(offsetptr, (CoreBottomCrum *) crumptr);
        *offsetptr = *offsetptr + crumptr->cwid[WIDTH];
        return;
    }

    CoreCrum *ptr;
    for (ptr = crumptr->leftSon(); ptr; ptr = ptr->rightbro)
        dodumpistreamgr((CoreUpperCrum *) ptr, offsetptr);
#endif
}

/**********************************************************************
 *
 **********************************************************************/
    void
dumpmoleculegr(Tumbler *offsetptr, CoreBottomCrum *cbcptr)
{
#ifndef DISTRIBUTION
//    int i;
//    Tumbler localoffset;

    /*
     * cerr << endl;
     * dumpisagr(offsetptr);
     *
     * if (cbcptr->cinfo.infotype == CoreBottomCrum::GRANTEXT) {
     *     if (cbcptr->cinfo.textstring[0] == '\n')
     *         fprintf(stderr, "\\n");
     *     else if (cbcptr->cinfo.textstring[0] == '\t')
     *         fprintf(stderr, "\\t");
     *     else
     *         fprintf(stderr, "%c ", cbcptr->cinfo.textstring[0]);
     *
     *     fprintf(stderr, "    | %x  ", cbcptr);
     *     dumpwid(&cbcptr->cwid, GRAN);
     *  //   movetumbler(offsetptr, &localoffset);
     *     localoffset = *offsetptr;
     *
     *     for (i = 1; i < cbcptr->cinfo.textlength; ++i) {
     *         tumblerincrement(&localoffset, 0, 1, &localoffset);
     *         dumpisagr(&localoffset);
     *
     *         if (cbcptr->cinfo.textstring[i] == '\n')
     *             fprintf(stderr, "\\n");
     *         else if (cbcptr->cinfo.textstring[i] == '\t')
     *             fprintf(stderr, "\\t");
     *         else
     *             fprintf(stderr, "%c ", cbcptr->cinfo.textstring[i]);
     *
     *         fprintf(stderr, "    |\n");
     *     }
     * } else if (cbcptr->cinfo.infotype == CoreBottomCrum::GRANORGL) {
     *     fprintf(stderr, "%x", cbcptr->cinfo.orglptr);
     *     fprintf(stderr, "  | %x  ", cbcptr);
     *     dumpwid(&cbcptr->cwid, GRAN);
     * } else {
     *     fprintf(stderr, "      | %x  ", cbcptr);
     *     dumpwid(&cbcptr->cwid, GRAN);
     * }
     */
#endif
}

/**********************************************************************
 *
 **********************************************************************/
    void
dumpisagr(Tumbler *offsetptr)
{
#ifndef DISTRIBUTION
    Tumbler offset = *offsetptr;

    int i = nstories(&offset) - offset.exp;
    i += i - 1;

    int j, k;
    for (j = 0; j < Tumbler::NPLACES; ++j)
        for (k = offset.mantissa[j]; k /= 10; ++i)
            ;

    i = TABSTOP - i;
    if (i < 2) {
//        fprintf(stderr, "too long");
        i = 8;
    } else
        cerr << offset;

    while (i--)
        cerr << ' ';
#endif
}

/**********************************************************************
 *
 **********************************************************************/
    CoreCrum *
checkenftypes(CoreUpperCrum *father, char *message)
{
#ifndef DISTRIBUTION
//    CoreCrum *ptr;

    if (Enfilade::grimreaper == NULL)
        cerr << "grimreaper tests null";

    return (CoreCrum *) father;

    /*
     * if (!father) {
     *     fputs(stderr, message);
     *     qerror("ARGH!! null father ptr");
     * }
     *
     * if (!father->height)
     *     return father;
     *
     * if (father->cenftype == SPAN) {
     *     if (father->cwid[ORGLRANGE].exp == 0 && father->cwid[ORGLRANGE].mantissa[0] > 2) {
     *         dumpsubtree(father);
     *         fputs(stderr, message);
     *         qerror("I think the wid is too big.");
     *     }
     * }
     *
     * for (ptr = father->leftson; ptr; ptr = ptr->rightbro) {
     *     if (ptr->cenftype != GRAN && ptr->cenftype != POOM && ptr->cenftype != SPAN) {
     *         fputs(stderr, message);
     *         qerror("bad enftype");
     *     }
     *
     *     if (ptr->cenftype != father->cenftype) {
     *         fputs(stderr, message);
     *         qerror("enftype mismatch");
     *     }
     *
     *     checkenftypes(ptr, message);
     * }
     * return father;
     */
#endif
}

/**********************************************************************
 *
 **********************************************************************/
    CoreCrum *
checkthebleedingcrum(CoreCrum *crumptr)
{
#ifndef DISTRIBUTION
    if (Enfilade::grimreaper == NULL)
        cerr << "grimreaper tests null";

    return crumptr;

    /*
     * if (!crumptr)
     *     qerror("checkbleeding NULL crum");
     *
     * if (crumptr->cenftype != GRAN && crumptr->cenftype != SPAN && crumptr->cenftype != POOM) {
     *     fprintf(stderr, "Bad enftype in check the bleeding crum\n\n\n");
     *     dump(crumptr);
     *     qerror("Bad enftype\n");
     * }
     *
     * if (!crumptr->isapex && crumptr->leftbroorfather..disowned.. && crumptr->cenftype != crumptr->leftbroorfather->cenftype) {
     *     dump(crumptr);
     *     fprintf(stderr, "\n\n\n  and here comes the spanf \n");
     *     dumpsubtree(spanf);
     *     dump(crumptr);
     *     qerror("Enftype mismatch.\n");
     * }
     *
     * if (crumptr->cenftype != GRAN) {
     *     if (!tumblercheck(&crumptr->cdsp[V]))
     *         qerror("cleckbleeding disp V");
     *
     *     if (!tumblercheck(&crumptr->cdsp[I]))
     *         qerror("cleckbleeding disp I");
     * }
     *
     * return crumptr;
     */
#endif
}

/**********************************************************************
 *
 **********************************************************************/
//    void
//teststack()
//{
//}

/**********************************************************************
 *
 **********************************************************************/
    char *
enftypestring(int type)
{
#ifndef DISTRIBUTION
    static char errbuf[60];

    switch (type) {
    case GRAN:  return "GRAN";
    case POOM:  return "POOM";
    case SPAN:  return "SPAN";
    default:
        sprintf(errbuf, "bad enftype %d", type);
        return (char *) errbuf;
    }
#endif
}

/**********************************************************************
 *
 **********************************************************************/
    CoreCrum *
sonoriginok(CoreCrum *father)
{
    return father;

    /*
     * if (!father)
     *     return father;
     *
     * if (father->height == 0)
     *     return father;
     *
     * if (father->sonorigin.diskblocknumber == -1)
     *     return father;
     *
     * if (goodblock(father->sonorigin.diskblocknumber))
     *     return father;
     *
     * dumpsubtree(father);
     * fprintf(stderr, "enter y to procede\n");
     * if (getchar() == 'y') {
     *     getchar();
     *     return father;
     * }
     *
     * gerror("Bad Sonorigin.\n");
     * return NULL; // for lint//
     */
}

/**********************************************************************
 *
 **********************************************************************/
    void
dumpcontextlist(Context *context)
{
#ifndef DISTRIBUTION
    cerr << "contextlist :" << endl;

    if (!context) {
        cerr << "  contextlist NULL" << endl;
        return;
    }

    for ( ; context; context = context->nextcontext)
        dumpcontext(context);
#endif
}

/**********************************************************************
 *
 **********************************************************************/
    void
dumpcontext(Context *context)
{
#ifndef DISTRIBUTION
//    fprintf(stderr, "  context %x:\n", (int) context);
//
//    if (context == NULL) {
//        fprintf(stderr, "NULL context\n");
//        return;
//    }
//
//    fprintf(stderr, "    contexttype %s\n", enftypestring(context->contexttype));
//    fprintf(stderr, "    totaloffset ");
//    dumpdsp(&context->totaloffset, context->contexttype);
//
//    fprintf(stderr, "    contextwid ");
//    dumpwid(&context->contextwid, context->contexttype);
//
//    if (debug > 1) {
//        fprintf(stderr, "    contextinfo ");
//        dumpinfo((CoreBottomCrum::typegranbottomcruminfo *) &context->contextinfo, context->contexttype);
//    }
#endif
}

/**********************************************************************
 *
 **********************************************************************/
    void
dumpitemset(typeitemset itemset)
{
#ifndef DISTRIBUTION
//    if (itemset == NULL)
//        fprintf(stderr, "  \nitemset empty\n");
//
//    for (; itemset; itemset = (typeitemset) ((typeitemheader *) itemset)->next) {
//        dumpitem(itemset);
//
//        if (!(((typeitemheader *) itemset)->next && ((typeitemheader *) itemset)->itemid == TEXTID && ((typeitemheader *) itemset)->next->itemid == TEXTID))
//            putc('\n', stderr);
//    }
#endif
}

/**********************************************************************
 *
 **********************************************************************/
    void
dumpitem(typeitem *itemptr)
{
#ifndef DISTRIBUTION
//    int bugger = debug;
//
//    debug = 0;
//
//    /* checkitem("dumpitem: ", itemptr); */
//
//    fprintf(stderr, "%x ->%x:", (int) itemptr, (int) ((typeitemheader *) itemptr)->next);
//
//    switch (((typeitemheader *) itemptr)->itemid) {
//    case ISPANID:
//        fprintf(stderr, "  ispan\n");
//        dumpspan((typespan *) itemptr);
//        break;
//
//    case VSPANID:
//        fprintf(stderr, "  vspan\n");
//        dumpspan((typespan *) itemptr);
//        break;
//
//    case VSPECID:
//        fprintf(stderr, "document: ");
//        puttumbler(stderr, &((typevspec *) itemptr)->docisa);
//        fprintf(stderr, "\nspans");
//        dumpitemset((typeitemset) ((typevspec *) itemptr)->vspanset);
//        break;
//
//    case TEXTID:
//        dumptext((typetext *) itemptr);
//        break;
//
//    case LINKID:
//        puttumbler(stderr, &((typelink *) itemptr)->address);
//        break;
//
//    case SPORGLID:
//        fprintf(stderr, "sporgl address: ");
//        puttumbler(stderr, &((typesporgl *) itemptr)->sporgladdress);
//
//        fprintf(stderr, "\n   sporgl origin: ");
//        puttumbler(stderr, &((typesporgl *) itemptr)->sporglorigin);
//
//        fprintf(stderr, "\n   sporgl width: ");
//        puttumbler(stderr, &((typesporgl *) itemptr)->sporglwidth);
//
//        fprintf (stderr, "\n");
//        break;
//
//    default:
//        fprintf(stderr, "illegal item id for dumpitem ");
//        fprintf(stderr, "%x  %d\nd", (int) itemptr, ((typeitemheader *) itemptr)->itemid);
//        gerror("Illegal item in dumpitem!\n");
//    }
//
//    debug = bugger;
#endif
}

/**********************************************************************
 *
 **********************************************************************/
    void
dumpspan(typespan *spanptr)
{
#ifndef DISTRIBUTION
//    if (!spanptr) {
//        fprintf(stderr, "null span ptr\n");
//        return;
//    }
//
//    fprintf(stderr, "   span address: ");
//    puttumbler(stderr, &spanptr->stream);
//
//    fprintf(stderr, "   span width: ");
//    puttumbler(stderr, &spanptr->width);
//
//    fprintf(stderr, "\n");
#endif
}

/**********************************************************************
 *
 **********************************************************************/
    void
dumptext(typetext *textptr)
{
#ifndef DISTRIBUTION
    write(2, textptr->string, textptr->length);
#endif
}

/**********************************************************************
 *
 **********************************************************************/
    bool
ioinfo(Session *sess)
{
#ifndef DISTRIBUTION
//fixme    fprintf(stderr, "Total reads = %ld,  total writes = %ld\n", bio.blocksRead(), bio.blocksWritten());
#endif

    return true;
}

/**********************************************************************
 *
 **********************************************************************/
    bool
showenfilades(Session *sess)
{
#ifndef DISTRIBUTION
    char c;

    prompt(sess, "\ngranf (g), spanf (s) or orgl (o) ? ");
    sess->inp >> c;
    if (c != '\n')
        sess->inp.ignore();

    cerr << endl;

    switch (c) {
    case 'o':  showorgl(sess);                    break;
    case 'g':  showsubtree((CoreCrum *) granf);  break;
    case 's':  showsubtree((CoreCrum *) spanf);  break;
    default:                                         break;
    }
#endif
    return true; //fixme: what should I return ?!?!?
}

/**********************************************************************
 *
 **********************************************************************/
    char *
itemidstring(typeitem *item)
{
#ifndef DISTRIBUTION
    switch (((typeitemheader *) item)->itemid) {
    case TEXTID:     return "TEXTID";
    case ISPANID:    return "ISPANID";
    case VSPANID:    return "VSPANID";
    case VSPECID:    return "VSPECID";
    case NODEID:     return "NODEID";
    case ADDRESSID:  return "ADDRESSID";
    case SPORGLID:   return "SPORGLID";
    }
#endif

    return NULL; /* for lint ?*/
}

/**********************************************************************
 *
 **********************************************************************/
    void
checkitem(char *msg, typeitem *ptr)
{
#ifndef DISTRIBUTION
//    char buf[100];

    checkpointer(msg, (char *) ptr);

    if (!ptr)
        return;

    if (debug) {
        cerr << msg;
        dumpitem(ptr);
    }

    if (((typeitemheader *) ptr)->itemid < TEXTID || ((typeitemheader *) ptr)->itemid > SPORGLID) {
        cerr << msg;
        gerror("Bad itemtype\n");
    }

    /* checkpointer(sprintf(buf, "%s ptr->next: ", msg), ((typeitemheader *) ptr)->next); */

    if (((typeitemheader *) ptr)->itemid == VSPANID) {
        if (((typevspan *) ptr)->stream.mantissa[0] != 1 && ((typevspan *) ptr)->stream.mantissa[0] != 2) {
            cerr << msg;
            cerr << ((typevspan *) ptr)->stream;
            cerr << "  ";
            gerror("Bad span stream address.\n");
        }
    }

    if (((typeitemheader *) ptr)->itemid == VSPECID) {
        checkitem(msg, (typeitem *) ((typevspec *) ptr)->vspanset);
        if (((typevspec *) ptr)->vspanset->itemid != VSPANID)
            gerror("vspanset doesn't have proper itemid.\n");
    }
#endif
}

/**********************************************************************
 *
 **********************************************************************/
    void
checkpointer(char *msg, char *ptr)
{
    return;

    /*
     * if (!ptr) {
     *     if (debug) {
     *         fprintf(stderr, msg);
     *         fprintf(stderr, "NULL pointer\n");
     *     }
     *     return;
     * }
     *
     * if (((unsigned) ptr) & 1) {
     *     fprintf(stderr, msg);
     *     gerror("Pointer non-aligned.\n");
     * }
     *
     * if (ptr > (char *) 0x1bffff) {
     *     fprintf(stderr, msg);
     *     if (ptr < (char *) 0x1e0000)
     *         fprintf(stderr, "Pointer in framebuffer\n");
     *
     *     gerror("Pointer in high-mem\n");
     * }
     *
     * if (ptr < (char *) 0x40000) {
     *     fprintf(stderr, msg);
     *     gerror("Pointer to hardware protected low memory.\n");
     * }
     *
     * if (ptr < &end //etext//) {
     *     fprintf(stderr, msg);
     *     gerror("Pointer below end\n");
     * }
     */
}

/**********************************************************************
 *
 **********************************************************************/
    void
dumpspanpairset(typespanpairset spanpairset)
{
#ifndef DISTRIBUTION
    for (; spanpairset; spanpairset = spanpairset->nextspanpair)
        dumpspanpair(spanpairset);
#endif
}

/**********************************************************************
 *
 **********************************************************************/
    void
dumpspanpair(typespanpair *spanpair)
{
#ifndef DISTRIBUTION
    cerr << "stream1:  " << spanpair->stream1     << endl;
    cerr << "stream2:  " << spanpair->stream2     << endl;
    cerr << "width:  "   << spanpair->widthofspan << endl;
#endif
}

/**********************************************************************
 *
 **********************************************************************/
    void
dumphexstuff(char *ptr)
{
#ifndef DISTRIBUTION
//    int i;

    cerr << endl;

//    for (i = 0; i < 120; i++)
//        fprintf(stderr, "%x ", *(ptr + i) & 0xff);

    cerr << endl;
#endif
}

/**********************************************************************
 *
 **********************************************************************/
    void
checknumofsons(CoreUpperCrum *ptr)
{
#ifndef DISTRIBUTION
    int i;
    CoreUpperCrum *np;

    i = 0;
    if (!ptr || !ptr->height)
        return;

    for (np = (CoreUpperCrum *) ptr->leftson; np; np = (CoreUpperCrum *) np->rightbro, i++)
        ;

    if (i != ptr->numberofsons) {
        dumpsubtree(ptr);
//        fprintf(stderr, "i = %d numberofsons = %d\n", i, ptr->numberofsons);
        for (np = (CoreUpperCrum *) ptr->leftson; np; np = (CoreUpperCrum *) np->rightbro, i++) {
            /* dump(np) */;
        }
//        /* gerror(*/ fprintf(stderr, "numberofson mismach in checknumofsons\n");
    }
#endif
}

/**********************************************************************
 *
 **********************************************************************/
    void
nchecknumofsons(CoreUpperCrum *ptr)
{
#ifndef DISTRIBUTION
    int i;
    CoreUpperCrum *np;

    i = 0;
    if (!ptr || !ptr->height)
        return;

    for (np = (CoreUpperCrum *) ptr->leftson; np; np = (CoreUpperCrum *) np->rightbro, i++)
        ;

    if (i != ptr->numberofsons) {
        dumpsubtree(ptr);
//        fprintf(stderr, "i = %d numberofsons = %d\n", i, ptr->numberofsons);
        for (np = (CoreUpperCrum *) ptr->leftson; np; np = (CoreUpperCrum *) np->rightbro, i++) {
            /* dump(np) */;
        }

//        /* gerror( */ fprintf(stderr, "numberofson mismach in nchecknumofsons\n");
    }
#endif
}

/**********************************************************************
 *  Original Copyright � 1979-1999 Udanax.com.   All Rights Reserved
 **********************************************************************/
