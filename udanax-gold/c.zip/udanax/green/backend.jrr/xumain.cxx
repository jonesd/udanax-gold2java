/**
 * @file  xumain.cxx
 * @brief ???
 *
 * (to be defined)
 *
 **/

#include <unistd.h>
#include <stdlib.h>
#include <fstream>

#include <nana/nana.h>  // GNU Assertion/Logging Tool
 
#include <errno.h>
#include "xanadu.h"
#include "enf.h"
#include "requests.h"

#include "players.h"

#define MAX_PLAYERS 5

int        user = 0;
PLAYER     player[MAX_PLAYERS];

extern int errno;

FILE      *febelog = NULL;
bool       isxumain = true;
//extern bool       maximumsetupsizehasbeenhit;
//extern int        maximumsetupsize;
bool       logstuff;
Session  *sessx;
//FILE      *interfaceinput = NULL;
_IO_istream_withassign interfaceinput;

long       ntaskorcommand = 0; // Part of Main
int        debug = 0; // Part of Main

//diskheader
//varcrums
//ingrimreaper
//nolread
//nolwrote
//noishouldbother
//notakenephewnd
//noeatbrosnd
//logfile
//nulllog
//reallog

static void xanadu(Session *sess);
static bool getmuchtext(Session *sess, typetext *textptr);

/**********************************************************************
 *
 **********************************************************************/
    int
main(int argc, char *argv[])  /* inside temporary */
{
    Session task;

    setbuf(stderr, NULL);
    debug = false;
    processrcfile();
    init(0);
    inittask(&task);

    /*
     * if (fd = fopen("xusetup", "r"))
     *     task.inp = fd;
     *     errno = 0;
     */

    initmagicktricks();
    sessx = &task;
    getaccount(&task, &task.account);

    for (;;) {
        ntaskorcommand++;

        xanadu(&task);
        testforreservedness("main");
    }
}

/**********************************************************************
 *                Back-End Request Dispatcher
 **********************************************************************/
    static void
xanadu(Session *sess)
{
    typerequest request;

    logstuff = false;
    if (getrequest(sess, &request))
        (*requestfns[request])(sess);

    /*
     * else
     *     sess->inp = stdin;
     */

    logstuff = false;
    tfree(sess);
}

/**********************************************************************
 *
 **********************************************************************/
//    bool
//setmaximumsetupsize(Session *sess)
//{
//    char buff[100];
//
//    fprintf(sess->outp, "maximumsetupsize = ? ");
//    maximumsetupsize = atoi(fgets(buff, 100, sess->inp));
//
//    return true;
//}

/**********************************************************************
 *
 **********************************************************************/
    void
sourceunixcommand(Session *sess)
{
    char unixcommand[132];
    char file[64];
    IStreamAddr docisa;
    typetext *textsetptr;

    int count, lines, bugger;
    int status;

    count  = 0;
    lines  = 0;
    bugger = debug;

    sprintf(file, "xum%d", getpid());
    prompt(sess, " Enter unix command : ");
    sess->inp.getline(unixcommand, sizeof(unixcommand), '\n');
    if (unixcommand[ strlen(unixcommand)-1 ] == '\n')
        unixcommand[ strlen(unixcommand)-1 ] = '\0';

    strcat(unixcommand, " >");
    strcat(unixcommand, file);
    if ((status = system(unixcommand)) != 0) {
        cerr << "Exit status = " << status << endl;
        perror("Udanax(system call 0)");
        /* return  false; */
    }

    if (debug) {
        prompt(sess, "lines until debug : ");
        sess->inp.getline(unixcommand, sizeof(unixcommand), '\n');
        count = atoi(unixcommand);
        if (count)
            debug = 0;
    }

    docreatenewdocument(sess, &docisa);
    /* testforreservedness("eatunixcommand createdoc"); */
    putcreatenewdocument(sess, &docisa);

    _IO_istream_withassign infile;
    infile = sess->inp;

    ifstream altinput;
    altinput.open(file, ios::in);
    if (!(sess->inp = altinput)) {
//    if (!(sess->inp = fopen(file, "r"))) {
        perror("xanadu");
        cerr << "Couldn't open " << file << endl;
        gerror("Awful badness in sourceunixfile.\n");
    }

    while ((textsetptr = (typetext *) taskalloc(sess, sizeof(typetext)))
          && (getmuchtext(sess, textsetptr) || (textsetptr->length > 0))) {

        if (debug)
            cerr << "line # " << lines << endl;

        textsetptr->next   = NULL;
        textsetptr->itemid = TEXTID;
        textsetptr->length = strlen(textsetptr->string);

        doappend(sess, &docisa, textsetptr);
        /* testforreservedness("eatunixcommand loop"); */
        ++lines;
        tfree(sess);
        if (count && --count == 0)
            debug = bugger;
    }

//fixme    ((ifstream *) sess->inp).close();
//    fclose(sess->inp);
    unlink(file);
    sess->inp = infile;
}

/**********************************************************************
 *
 **********************************************************************/
    static bool
getmuchtext(Session *sess, typetext *textptr)
/* this code stolen from get2.d which could use some improvement but be careful */
{
    int temp, numinstring = 0;

    numinstring = temp = 0;
    for (;;) {
        if (!sess->inp.getline(textptr->string + numinstring, GRANTEXTLENGTH - numinstring)) {
            temp = 0;
            break;
        }

        temp = strlen(textptr->string + numinstring);
        if (temp < 1)
            break;

        numinstring += temp;
        if (numinstring >= GRANTEXTLENGTH)
            break;
    }

    if (numinstring > GRANTEXTLENGTH)
        gerror(" got too much in getmuchtext");

    if (numinstring == 0) {
        textptr->length = 0;
        return false;
    }

    textptr->length = numinstring;
    textptr->itemid = TEXTID;

    return true;
}

/**********************************************************************
 *
 **********************************************************************/
    bool
decrementusers()
{
    return false;
}

/**********************************************************************
 *
 **********************************************************************/
    bool
isthisusersdocument(Tumbler *tp)
{
    return tumbleraccounteq(tp, &sessx->account);
}

/**********************************************************************
 *  Original Copyright � 1979-1999 Udanax.com.   All Rights Reserved
 **********************************************************************/
