/**
 * @file  alloc.cxx
 * @brief ???
 *
 * (to be defined)
 *
 **/

#include <unistd.h>
//#include <sys/errno.h>

#include <nana/nana.h>  // GNU Assertion/Logging Tool

#include "common.h"
#include "alloc.h"

extern bool     ingrimreaper;

static HEADER   base;
static HEADER  *allocp = NULL;
static HEADER   baseallocated;
static HEADER  *weresurethatthisisourmorecore();

static int      flag = 0;
static char    *zzalloctop = 0, *zzallocbot = 0;
static int      alloccount = 0;

static void statusofalloc();

/**********************************************************************
 *
 **********************************************************************/
    int
lookatalloc()
{
    lookatalloc2(&baseallocated);
    return 0; //fixme: what should I return ???
}

/**********************************************************************
 *
 **********************************************************************/
    int
checkalloc(char *c)
{
    HEADER   *r, *oldr;
    unsigned size;

    if (!flag)
        return true;

    if (debug && *c)
        fprintf(stderr, "%s", c);

    unsigned oldsize = 0;
    for (oldr = r = base.s.ptr; flag && (r != &base) && (r != (HEADER *) zzalloctop); r = r + r->s.size) {
        size = r->s.size;
        validallocthinge(r);
        if (r->s.size == 0 && r != (HEADER *) zzalloctop) {
            L("checkalloc glorphed with ptr = %x bottom = %x top = %x\n", (int) r, (int) zzallocbot, (int) zzalloctop);
            statusofalloc();
            I(false /*"Invariant: found zero size in alloced stuff"*/);
            return 1;
        }
        oldr = r;
        oldsize = size;
    }
    return true;
}

/**********************************************************************
 *
 **********************************************************************/
    void
checkallocedptr(char *ptr, char *string)
{
    if (((HEADER *) (ptr - sizeof(HEADER) - sizeof(tagtype)))->s.size == 0) {
        fprintf(stderr, "checkallocedptr %s \n", string);
        gerror("found null size\n");
    }
}

/**********************************************************************
 *
 **********************************************************************/
    int
validallocthinge(HEADER *ptr)
{
    return 1;

/*
 *   if (!flag)
 *       return true;
 *
 *   HEADER *p = (HEADER *) ptr;
 *   if (p->s.size == 0 && p != (HEADER *) zzalloctop) {
 *       fprintf(stderr, "validallocthinge called with ptr = %x bottom = %x top = %x\n", ptr, zzallocbot, zzalloctop);
 *       statusofalloc();
 *       gerror("attempt to free zero size thing \n");
 *   }
 *
 *   if (flag && (unsigned) ptr > (unsigned) zzalloctop || (unsigned) ptr < (unsigned) zzallocbot) {
 *       fprintf(stderr, "validallocthinge called with ptr = %x bottom = %x top = %xn", ptr, zzallocbot, zzalloctop);
 *       qerror("bad validity check in alloc");
 *       return 0;
 *   }
 *
 *   return true;
*/
}

/**********************************************************************
 *
 **********************************************************************/
    int *
falloc(unsigned nbytes)
{
    HEADER *p, *q;
    unsigned nunits;

    if (ingrimreaper) {
#ifndef DISTRIBUTION
        fprintf(stderr, "really error in falloc called from under grimreaper\n");
        gerror("falloc called from under grimreaper\n");
#else
        gerror("bad alloc");
#endif
    }

    if (!nbytes)
        gerror("falloc called with nbytes = 0\n");

    /* fprintf(stderr, "falloc called with %d\n", nbytes); */

    alloccount++;
    nunits = 1 + (nbytes + sizeof(HEADER) - 1) / sizeof(HEADER);
    if ((q = allocp) == NULL) {
        base.s.ptr = allocp = q = &base;
        base.s.size = 0;
    } else {
        /* checkalloc(""); */
    }

    for (p = q->s.ptr; ; q = p, p = p->s.ptr) {
        if (p->s.size >= nunits) {
            if (p-> s.size == nunits)
                q->s.ptr = p->s.ptr;
            else {
                p->s.size -= nunits;
                p += p->s.size;
                p->s.size = nunits;
            }
            p->s.ptr = NULL;
            allocp = q;
            return (int *) (p + 1);
        }
        if (p == allocp)
            if ((p = weresurethatthisisourmorecore()) == NULL)
                return NULL;
    }
}

/**********************************************************************
 *
 **********************************************************************/
    static HEADER *
weresurethatthisisourmorecore()
{
    char    *cp;
    HEADER  *up;
//    char    *sbrk();
    int      temp;

    if (flag)
        return NULL;

    cp         = (char *) sbrk(allocsize);
    zzalloctop = (char *) cp + allocsize;
    zzallocbot = (char *) cp;

    if ((int) cp == -1) {
        flag = 1;
        return NULL;
    }

    up = (HEADER *) cp;

    temp = up->s.size = ((unsigned) allocsize) / sizeof(HEADER);

    if ( temp == 0) {
#ifndef DISTRIBUTION
        gerror("this dumb fucker doesnt do arithmetic right");
#else
        gerror("temp == 0");
#endif
    }

    baseallocated.s.ptr = (HEADER *)cp;
    baseallocated.s.size = temp;

    ffree((char *) (cp + sizeof(HEADER) /* up + 1 */ ));
    flag = 1;

    return allocp;
}

/**********************************************************************
 *
 **********************************************************************/
    void
ffree(char *ap)
{
    HEADER *p = (HEADER *) ap -1;

    if (flag) {
        if (!validallocthinge(p))
            gerror("wierd free in alloc\n");
    }

    /* setmem(ap, (p->s.size - 1) * sizeof(HEADER), 0); */

    HEADER *q;
    for (q = allocp; !(p > q && p < q->s.ptr); q = q->s.ptr) {
        if (q >= q-> s.ptr && (p > q || p < q->s.ptr))
            break;
    }

    if (p + p->s.size == q->s.ptr) {
        p->s.size += q->s.ptr->s.size;
        p->s.ptr = q->s.ptr->s.ptr;
    } else {
        p->s.ptr = q->s.ptr;
    }

    if (q + q->s.size == p) {
        q->s.size += p->s.size;
        q->s.ptr = p->s.ptr;
    } else {
        q->s.ptr = p;
    }

    allocp = q;

    /* checkalloc(""); */
}

/**********************************************************************
 *
 **********************************************************************/
    static void
statusofalloc()
{
    HEADER *r;

/*    checkalloc(c); */

    unsigned number = 0;
    unsigned maxsize = 0;
    unsigned cumsize = 0;
    for (r = base.s.ptr; flag && (r != &base); r = r->s.ptr) {
        maxsize = (maxsize > r->s.size ? maxsize : r->s.size);
        cumsize += r->s.size;
        number++;
    }

    fprintf(stderr, "%d free hunks %d maxsize %d total free\n", number, maxsize, cumsize);
}

/**********************************************************************
 *  Original Copyright � 1979-1999 Udanax.com.   All Rights Reserved
 **********************************************************************/
