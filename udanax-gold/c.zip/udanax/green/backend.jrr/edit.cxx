/**
 * @file  edit.cxx
 * @brief Crum Rearrange and Deletion Routines
 *
 * (to be defined)
 *
 **/

#include <nana/nana.h>  // GNU Assertion/Logging Tool

#include "xanadu.h"
#include "common.h"
#include "enf.h"
#include "ndenf.h"
#include "knives.h"

/**********************************************************************
 *
 **********************************************************************/
/* use with SPAN and POOM */
    void
deletend(CoreUpperCrum *fullcrumptr, StreamAddr *origin, StreamDiff *width, int index)
{
    Displacer offset;
    memset(&offset, 0, sizeof(offset)); /* fullcrum alway has zero offset */

    Displacer grasp, reach;
    prologuend(fullcrumptr, &offset, &grasp, &reach);

    Knives knives;
    knives.blade[0]  = *origin;
    knives.blade[1]  = *origin + *width;
    knives.nblades   = 2;
    knives.dimension = index;

    makecutsnd(fullcrumptr, &knives);

    CoreUpperCrum *father;
    Displacer foffset;
    newfindintersectionnd(fullcrumptr, &knives, &father, &foffset);

    Displacer fgrasp;
    prologuend(father, &foffset, &fgrasp, NULL);

    CoreUpperCrum *ptr, *next;
    for (ptr = (CoreUpperCrum *) father->leftSon(); ptr; ptr = next) {
        next = (CoreUpperCrum *) ptr->rightBrother();
        switch (deletecutsectionnd(ptr, &fgrasp, &knives)) {
        case -1:
            gerror("deletend can't classify crum\n");
        case 0:
            break;
        case 1:
            ptr->disown();
            subtreefree((CoreCrum *) ptr);
            break;
        case 2:
//            tumblersub(&ptr->cdsp[index], width, &ptr->cdsp[index]);
            ptr->cdsp[index] = ptr->cdsp[index] - *width;

            /* This will get set to modified in setwisp */
            break;
        default:
            gerror("unexpected cutsection\n");
        }
    }

    setwispupwards(father, 1);
    recombine(father);
}

/**********************************************************************
 *
 **********************************************************************/
    void
rearrangend(CoreUpperCrum *fullcrumptr, typecutseq *cutseqptr, int index)
{
#ifdef UNdeFined
    cerr << "entering rearrangend" << endl;

    /**/ fixincoresubtreewids(fullcrumptr); /*1999 a temp kluge zzz till we find where setwisp isnt called */
         /* this is a brute  force kluge, if this fixes anything it means that the wids aren't being set properly
            someplace else probably near here */

    cerr << "in rearrangend" << endl;

    switch (fullcrumptr->cenftype) {
    case POOM:
        cerr << "in rearrangend  dumppoomwisps" << endl;
        dumppoomwisps(fullcrumptr);
        break;

    case SPAN:
        cerr << "in rearrangend  showspanf" << endl;
        showspanf(fullcrumptr);
        break;
    }
#endif

    Knives knives;
    knives.dimension = index;
    knives.nblades   = cutseqptr->numberofcuts;

    int i;
    for (i = 0; i < knives.nblades; i++)
        knives.blade[i] = cutseqptr->cutsarray[i];

    knives.sort();

    StreamDiff diff[4];
    makeoffsetsfor3or4cuts(&knives, diff);

    /* for(i = 1; i <= knives.nblades; i++)
     *     cerr << endl << "offset for cut " << i << " = " << diff[i];
     */

    makecutsnd(fullcrumptr, &knives);

    Displacer foffset, fgrasp;
    CoreUpperCrum *father;
    newfindintersectionnd(fullcrumptr, &knives, &father, &foffset);
    prologuend((CoreCrum *) father, &foffset, &fgrasp, NULL);

    CoreUpperCrum *ptr;
    for (ptr = (CoreUpperCrum *) father->leftSon(); ptr; ptr = (CoreUpperCrum *) ptr->rightBrother()) {
        i = rearrangecutsectionnd(ptr, &fgrasp, &knives);
        switch (i) {
        case -1:
            I(false); // can't classify crum

        case 0:  case 4: /* these never move */
            break;

        case 1:  case 2:  case 3: /* 3 only moves in 4 cuts */
            ptr->cdsp[index] = ptr->cdsp[index] + diff[i];
            ptr->ivemodified();
            break;

        default:
            I(false); // unexpected cutsection
        }
    }

    setwispupwards(father, 1); /* should do nothing, but, just on general principles.. */
    recombine(fullcrumptr);

    splitcrumupwards(fullcrumptr); /* can we move this before recombine ? */

#ifdef UnDEfINed
    cerr << "leaving rearrangend" << endl;

    /**/ fixincoresubtreewids(fullcrumptr); /*1999 a temp kluge zzz till we find where setwisp isnt called */
      /* this is a brute  force kluge, if this fixes anything it means that the wids aren't being set properly
         someplace else probably near here */

    cerr << "in rearrangend" << endl;

    switch (fullcrumptr->cenftype) {
    case POOM:
        cerr << "in rearrangend  dumppoomwisps" << endl;
        dumppoomwisps(fullcrumptr);
        break;

    case SPAN:
        cerr << "in rearrangend  showspanf" << endl;
        showspanf(fullcrumptr);
        break;
    }
#endif

}

/**********************************************************************
 *
 **********************************************************************/
/* Prepares offsets for both 3 and 4 cut rearranges */
    void
makeoffsetsfor3or4cuts(Knives *knives, Tumbler diff[])
{
    /* diff[0] is simply ignored */

    if (knives->nblades == 4) {
//        tumblersub(&knives->blade[2], &knives->blade[0], &(diff[1]));
        diff[1] = knives->blade[2] - knives->blade[0];

//        tumblersub(&knives->blade[1], &knives->blade[0], &a);
        Tumbler a = knives->blade[1] - knives->blade[0];

//        tumblersub(&knives->blade[3], &knives->blade[2], &b);
        Tumbler b = knives->blade[3] - knives->blade[2];

//        tumblersub(&b, &a, &(diff[2]));
        diff[2] = b - a;

        /* tumblersub(&knives->blade[0], &knives->blade[2], &(diff[3])); */ /* should be < 0 */

        diff[3] = diff[1];
        diff[3].negsign = !diff[1].negsign;

    } else if (knives->nblades == 3) {
//        tumblersub(&knives->blade[2], &knives->blade[1], &diff[1]);
        diff[1] = knives->blade[2] - knives->blade[1];

//        tumblersub(&knives->blade[1], &knives->blade[0], &diff[2]); /* should be negative */
        diff[2] = knives->blade[1] - knives->blade[0];

        diff[2].negsign = !diff[2].negsign;
        diff[3].clear();

    } else
        gerror("Wrong number of cuts.");
}

/**********************************************************************
 *
 **********************************************************************/
 /* Returns which between-cut slice the crum is in. Does this
**   by finding the first cut to the right of the crum
** Each editting routine requires a slightly different version of
**   this function.
*/
    int
rearrangecutsectionnd(CoreCrum *ptr, Displacer *offset, Knives *knives)
{
    int i;
    for (i = knives->nblades - 1; i >= 0 ; --i) {
        int cmp = whereoncrum(ptr, offset, &knives->blade[i], knives->dimension);

        if (cmp == THRUME)
            return -1;
        else if (cmp <= ONMYLEFTBORDER)
            return i + 1;
    }

    return 0;
}

/**********************************************************************
 *
 **********************************************************************/
    int
insertcutsectionnd(CoreCrum *ptr, Displacer *offset, Knives *knives)
{
    int i, cmp;     /* hacked from delete */

    if (knives->nblades == 2) {
        i = 1;
        cmp = whereoncrum(ptr, offset, &knives->blade[i], knives->dimension);

        if ( /*false && */ cmp == THRUME) {
//fixme            dumpwid((Widener *) &ptr->cwid[i], ptr->cenftype);
            return -1;

        } else if (cmp <= ONMYLEFTBORDER) /* compare last to first */
            return 2;
    }

    i = 0;
    cmp = whereoncrum(ptr, offset, &knives->blade[i], knives->dimension);

    if (cmp == THRUME) {
//fixme        dumpwid((Widener *) &ptr->cwid[i], ptr->cenftype);
        return -1;

    } else if (cmp <= ONMYLEFTBORDER) /* compare last to first */
        return 1;

    return 0;
}

/**********************************************************************
 *
 **********************************************************************/
    int
deletecutsectionnd(CoreCrum *ptr, Displacer *offset, Knives *knives)
{
    int i;
    for (i = knives->nblades - 1; i >= 0; --i) { /* unique to delete */
        int cmp = whereoncrum(ptr, offset, &knives->blade[i], knives->dimension);

        if (cmp == THRUME)
            return -1;

        else if (cmp <= ONMYLEFTBORDER) /* compare last to first */
            return i + 1;
    }

    return 0;
}

/**********************************************************************
 *
 **********************************************************************/
    void
sortknives(Knives *knifeptr)
{
    int i;
    for (i = 0; i < knifeptr->nblades - 1; ++i) {
        if (knifeptr->blade[i] > knifeptr->blade[i+1]) {

            StreamAddr temp         = knifeptr->blade[i+1];
            knifeptr->blade[i+1] = knifeptr->blade[i];
            knifeptr->blade[i]   = temp;

            --i;
        }
    }
}

/**********************************************************************
 *  Original Copyright � 1979-1999 Udanax.com.   All Rights Reserved
 **********************************************************************/
