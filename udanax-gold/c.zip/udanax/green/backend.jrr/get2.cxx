/**
 * @file  get2.cxx
 * @brief Input Routines -- No Front-End Version
 *
 * (to be defined)
 *
 **/

#include <stdlib.h>
#include <iostream>

#include <nana/nana.h>  // GNU Assertion/Logging Tool

#include "xanadu.h"
#include "knives.h"

/**********************************************************************
 *
 **********************************************************************/
    bool
getnum(Session *sess, int *numptr)  /* inside temporary */
{
    metachar c;
    int num;

    bool flag = false;   /* should check for minus */
    for (num = 0; !sess->inp.eof() && isdigit(c);) {
        sess->inp >> c;
        num = num * 10 + c - '0';
        flag = true;
    }

    if (!flag) {
        sess->errp << "no number" << endl;
#ifndef DISTRIBUTION
        if (c == '?' || c == 'h')
            system("cat /usr3/xu/requests.j");
        else if (c == '!')
            system("csh");
#endif

    } else {
        sess->inp.unget();
        *numptr = num;
    }

    return flag;
}

/**********************************************************************
 *
 **********************************************************************/
    bool
eatchar(Session *sess, char c)
{
    metachar m;

    sess->inp >> m;
    if (m != c) {
        sess->inp.unget();
        return false;

    } else
        return true;
}

/**********************************************************************
 *
 **********************************************************************/
    bool
needchar(Session *sess, char c)
{
    if (!eatchar(sess, c)) {
        sess->errp << "needed a ";
        if (c == '\n')
            sess->errp << "newline" << endl;
        else
            sess->errp << c << endl;

        return false;
    }

    return true;
}

/**********************************************************************
 *
 **********************************************************************/
    bool
getnumber(Session *sess, int *numptr)
{
    return getnum(sess, numptr) && needchar(sess, '\n');
}

/**********************************************************************
 *
 **********************************************************************/
    bool
gettumbler(Session *sess, Tumbler *tumblerptr)
{
    int i;

    tumblerptr->clear();

    if (eatchar(sess, '-'))
        tumblerptr->negsign = true;

    for (i = 0; i < Tumbler::NPLACES; ++i) {
        if (!getnum(sess, (int *) &tumblerptr->mantissa[i]))
            return false;

        if (tumblerptr->mantissa[i] == 0 && i == 0) {
            --tumblerptr->exp;
            --i;
        }

        if (!eatchar(sess, '.'))
            break;
    }

    if (eatchar(sess, '.')) {
        sess->errp << "tumbler overflow" << endl;
        return false;
    }

    for (i = 0; i < Tumbler::NPLACES && tumblerptr->mantissa[i] == 0; ++i)
        ;

    if (i == Tumbler::NPLACES)
        tumblerptr->exp = 0;

    return needchar (sess, '\n');
}

/**********************************************************************
 *
 **********************************************************************/
    bool
getbool(Session *sess, bool *boolptr)
{
    int c;

    prompt(sess, "(y/n) ");
    sess->inp >> c;

    if (isupper(c))
        c = tolower(c);

    eatchar(sess, '\n');

    if (c == 'y') {
        *boolptr = true;
        return true;

    } else if (c == 'n') {
        *boolptr = false;
        return true;

    } else {
        error(sess, "need 'y' or 'n'");
        return false;
    }
}

/**********************************************************************
 *
 **********************************************************************/
    bool
getisa(Session *sess, IStreamAddr *isaptr)
{
    return gettumbler(sess, isaptr);
}

/**********************************************************************
 *
 **********************************************************************/
    bool
getvsa(Session *sess, Tumbler *vsaptr)
{
    return gettumbler(sess, vsaptr);
}

/**********************************************************************
 *
 **********************************************************************/
    bool
getrequest(Session *sess, typerequest *requestptr)
{
    int c;

    prompt(sess, "\nrequest? ");
    sess->inp >> c;

    if (sess->inp.eof()) {
        cerr << "endfile" << endl;
        sess->inp = cin;
    }
    /*
     * else if (c == ':') {
     *     while ((c = getc(sess->inp)) != '\n')
     *         ;
     *     return false;
     * }
     */

    sess->inp.unget();

    return getnumber(sess, requestptr) && validrequest(sess, *requestptr);
}

/**********************************************************************
 *
 **********************************************************************/
    bool
validrequest(Session *sess, typerequest request)
{
    if (request >= 0 && request < NREQUESTS && requestfns[request] != NULL)
        return true;

    sess->errp << "invalid request: " << request << endl;
    return false;
}

/**********************************************************************
 *
 **********************************************************************/
    bool
validaccount(Session *sess, IStreamAddr *accountptr)
{
    return true;
}

/**********************************************************************
 *
 **********************************************************************/
    bool
getspecset(Session *sess, typespecset *specsetptr)
{
    bool any, type;
    typespec *specset;

    for (;;) {
        prompt(sess, "any spans or vspecs? ");
        if (!getbool(sess, &any))
            return false;

        if (!any) {
            *specsetptr = NULL;
            return true;
        }

        prompt(sess,"a span? ");
        if (!getbool(sess, &type))
            return false;

        if (type) {
            specset = (typespec *) taskalloc(sess, sizeof(typespan));
            if (!getspan(sess, (typespan *) specset, ISPANID))
                return false;

            else {
                specset = (typespec *) taskalloc(sess, sizeof(typevspec));
                if (!getvspec(sess, (typevspec *) specset))
                    return false;
            }

            *specsetptr = specset;
            specsetptr = (typespecset *) &(((typevspec *) specset)->next);
        }
    }
}

/**********************************************************************
 *
 **********************************************************************/
    bool
getvspec(Session *sess, typevspec *vspecptr)
{
    vspecptr->itemid = VSPECID;
    vspecptr->next = NULL;

    prompt(sess, "document=> ");
    if (!(getisa(sess, &vspecptr->docisa) && getspanset(sess, &vspecptr->vspanset, VSPANID)))
        return false;

    return true;
}

/**********************************************************************
 *
 **********************************************************************/
    bool
getspanset(Session *sess, typespanset *spansetptr, char id)
{
    bool any;
    typespan *spanset;

    for (;;) {
        prompt(sess, "any spans? ");
        if (!getbool(sess, &any))
            return false;

        if (!any) {
            *spansetptr = NULL;
            return true;
        }

        spanset = (typespan *) taskalloc(sess, sizeof(typespan));
        if (!getspan(sess, spanset, id))
            return false;

        *spansetptr = spanset;
        spansetptr = &spanset->next;
    }
}

/**********************************************************************
 *
 **********************************************************************/
    bool
getspan(Session *sess, typespan *spanptr, char id)
{
    prompt(sess, "enter span\n       start=> ");

    if (!getisa(sess, static_cast<IStreamAddr*>(&spanptr->stream)))
        return false;

    spanptr->itemid = id;

    prompt(sess, "   width=> ");
    if (!(getisa(sess, static_cast<IStreamAddr*>(static_cast<Tumbler*>(&spanptr->width)))))
        return false;

    return true;
}

/**********************************************************************
 *
 **********************************************************************/
    bool
gettextset(Session *sess, typetextset *textsetptr)
{
    typetext *textset;

    for (;;) {
        textset = (typetext *) taskalloc(sess, sizeof(typetext));
        if (!gettext(sess, textset)) {
            *textsetptr = NULL;
            break;
        }

        *textsetptr = textset;
        textsetptr = &textset->next;
    }

    return true;
}

/**********************************************************************
 *
 **********************************************************************/
    bool
gettext(Session *sess, typetext *textptr)
{
    sess->inp.getline(textptr->string, GRANTEXTLENGTH);

    if (!sess->inp.good()) {
        textptr->length = 0;
        return false;
    }

    textptr->length = strlen(textptr->string);
    if (textptr->length <= 1)
        return false;

    /* remove newlines */
    /*
     * if (textptr->string[textptr->length - 1] == '\n')
     *     textptr->string[--textptr->length] = '\0';
     */

    textptr->itemid = TEXTID;
    return true;
}

/**********************************************************************
 *
 **********************************************************************/
    bool
getcutseq(Session *sess, typecutseq *cutseqptr)
{
    int i;
    bool anycuts;
//    Tumbler cutaddress;

    i = 0;
    for (;;) {
        prompt(sess, "any cuts? ");
        if (!getbool(sess, &anycuts))
            return false;

        if (!anycuts)
            break;

        prompt(sess, "cut address=> ");
        if (!getvsa(sess, &cutseqptr->cutsarray[i]))
            return false;

        if (++i > MAXCUTS)
            break;

        cutseqptr->numberofcuts = i;
    }

    return true;
}

/**********************************************************************
 *
 **********************************************************************/
    bool
getboolset(Session *sess, typeboolsetnode **boolsetptr)
{
    bool disjunct;
    typeboolsetnode * boolset;

    for (;;) {
        prompt(sess, "any disjunctions? ");
        if (!getbool(sess, &disjunct))
            return false;

        if (!disjunct) {
            *boolsetptr = NULL;
            return true;
        }

        boolset = (typeboolsetnode *) taskalloc(sess, sizeof(typeboolsetnode));
        prompt(sess, "enter disjunction=> ");

        if (!getspanset(sess, &boolset->val, ISPANID))
            return false;

/*zzz  &  zzz*/
        boolset->itemid = NODEID;
        *boolsetptr = boolset;
        boolsetptr = &boolset->next;
    }
}

/**********************************************************************
 *  Original Copyright � 1979-1999 Udanax.com.   All Rights Reserved
 **********************************************************************/
