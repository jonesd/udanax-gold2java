/**
 * @file  allocdebug.cxx
 * @brief ???
 *
 * (to be defined)
 *
 **/

#include <nana/nana.h>  // GNU Assertion/Logging Tool

#include "xanadu.h"
#include "alloc.h"
//#include "enf.h"

void analyzeanddebug(char *ptr); /* ptr to thing with alloc header and tag header */

void dumpitem(typeitem *itemptr);
void dumpcontext(Context *context);
void dumpspan(typespan *spanptr);

#ifndef max
#define max(a,b)        (((a) > (b)) ? (a) : (b))
#endif

/**********************************************************************
 *
 **********************************************************************/
    void
lookatalloc2(HEADER *abaseallocated) /* baseallocated is a static in alloc.c */
{
#ifndef DISTRIBUTION
    register HEADER *p;

    unsigned allocated = 0, unallocated = 0, maxunallocatedblock = 0; /*in header units*/
    p = abaseallocated->s.ptr;
    for (; p < abaseallocated->s.ptr + abaseallocated->s.size; ) {
        if (!p->s.ptr) { /* allocated*/
            analyzeanddebug((char *)p);
            allocated += p->s.size;
        } else { /*unallocated*/
            unallocated += p->s.size;
            maxunallocatedblock = max(p->s.size, maxunallocatedblock);
        }
        /* step past current one */
        p = p + p->s.size;
    }

    cerr << " allocated = " << (allocated * sizeof(HEADER))
         << " unallocated = " << (unallocated * sizeof(HEADER))
         << "maxunallocatedblock = " << (maxunallocatedblock * sizeof(HEADER));
#endif
}

/**********************************************************************
 *
 **********************************************************************/
    void
analyzeanddebug(char *ptr) /* ptr to thing with alloc header and tag header */
{
#ifndef DISTRIBUTION
    tagtype   tag;
    char     *tagptr;
    HEADER   *allocptr;

    allocptr = (HEADER *) ptr;
    tagptr = ptr + sizeof(HEADER);
    tag = *tagptr;
    ptr = tagptr + sizeof(tagtype);

/*
 *  cerr << endl << " size is " <<  ((HEADER *) allocptr)->s.size * sizeof(HEADER);
 */

    if (tag == TASKEDTAG) { /* undifferientated task alloced stuff */
    } /* else if (tag & TASKEDTAG) { //tagged task alloced stuff//
        switch (tag & ~TASKEDTAG) {
        }
    } */

    else {
        switch(tag) {
        case INTTAG:
            cerr << "int  in allocspace " << endl;
            break;

        case ITEMTAG:
            cerr << "item  in allocspace " << endl;
            dumpitem((typeitem *) ptr);
            break;

        case CONTEXTTAG:
            cerr << "context " << ptr << " in allocspace" << endl;
            dumpcontext((Context *) ptr);
            break;

        case CONTEXT2DTAG:
            cerr << "context2d " << ptr << " in allocspace" << endl;
            break;

        case CRUMCONTEXTTAG:
            cerr << "crumcontext  in allocspace" << endl;
            break;

        case CUCTAG:
            break;
            /*
             *  cerr << "cuc  in allocspace";
             *  dump(ptr);
             *  break;
             */

        case CBCTAG:
            break;
            /*
             *  cerr << "cbc  in allocspace";
             *  dump(ptr);
             *  break;
             */
        case SPANTAG:
            cerr << "span  in allocspace " << endl;
            dumpspan((typespan *) ptr);
            break;

        case TUMBLERTAG:
            cerr << "tumbler  in allocspace " << endl;
            cerr << (Tumbler *) ptr;
            break;

        case ISPANTAG:
            cerr << "aspan  in allocspace" << endl;
            break;

        case VSPANTAG:
            cerr << "vspan  in allocspace" << endl;
            break;

        case SPORGLTAG:
            cerr << "sporgl  in allocspace" << endl;
            break;

        case LINKTAG:
            cerr << "link  in allocspace" << endl;
            break;

        case VSPECTAG:
            cerr << "vspec  in allocspace" << endl;
            break;

        case FREEDISKLOAFTAG:
            cerr << "freediskloaf  in allocspace" << endl;
            break;

        default:
            cerr << "randomunidentified thing  in allocspace" << endl;
            break;
        }
    }
#endif
}

/**********************************************************************
 *  Original Copyright � 1979-1999 Udanax.com.   All Rights Reserved
 **********************************************************************/
