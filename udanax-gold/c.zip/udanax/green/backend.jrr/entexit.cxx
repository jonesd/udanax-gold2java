/**
 * @file  entexit.cxx
 * @brief ???
 *
 * (to be defined)
 *
 **/

#include <nana/nana.h>  // GNU Assertion/Logging Tool

#include "xanadu.h"
#include "enf.h"
#include "coredisk.h"
#include "queues.h"
#include "allocio.h"

//FileBlockIO bio(NUMBYTESINLOAF);
MMapCacheIO    *cio;
BitmapAllocIO  *aio;

/**********************************************************************
 *
 **********************************************************************/
    void
initmagicktricks()
{
    initgrimreaper();
    initqueues();
    initincorealloctables();

    cio = new MMapCacheIO(NUMBYTESINLOAF);

    CacheIO::OpenStatus ostat = cio->open("enf.enf");
    switch (ostat) {
    case BlockIO::OS_CREATED:
        aio = new BitmapAllocIO(*cio);
        granf = Enfilade1d::create();
        spanf = Enfilade2d::create(SPAN);
        break;

    case BlockIO::OS_OPENED:
        aio = new BitmapAllocIO(*cio);
        initkluge((CoreUpperCrum **) &granf, (CoreUpperCrum **) &spanf);
        break;

    case BlockIO::OS_FAILED:
        perror("initenffile");
        gerror("cant open enf.enf or creatit");
        break;
    }
}

/**********************************************************************
 *  Original Copyright � 1979-1999 Udanax.com.   All Rights Reserved
 **********************************************************************/
