/**
 * @file  diskalloc.cxx
 * @brief ???
 *
 * (to be defined)
 *
 **/

#include <unistd.h>
#include <memory.h>

#include <nana/nana.h>  // GNU Assertion/Logging Tool

#include "xanadu.h"
#include "enf.h"
#include "coredisk.h"

//bool maximumsetupsizehasbeenhit = false;
//int maximumsetupsize = 0;

//char mask[8] = { 1, 2, 4, 8, 16, 32, 64, 128 };

//diskheader diskheader;

/**********************************************************************
 *
 **********************************************************************/
//    int
//isalloced(int n)
//{
//    return diskheader.bitmap[n/8] | mask[n%8];
//}

/**********************************************************************
 *
 **********************************************************************/
//    DiskLoafAddr
//diskalloc()
///*  Find an unallocated loaf on the the disk,
//*       allocate it (take it off the free list), and
//*       return something thru which I can deal with it.
//*/
//{
//    int j;
//    DiskLoafAddr ret;
//
//    unsigned int i;
//    for (i = 0; i < BITMAPSIZE && !diskheader.bitmap[i]; ++i)
//        ;
//
//    if (i == BITMAPSIZE)
//        gerror("Out of diskalloc bitmap space.\n");
//
//    for (j = 0; j < 8; ++j) {
//        if (diskheader.bitmap[i] & mask[j]) {
//            diskheader.bitmap[i] = diskheader.bitmap[i] & ~mask[j];
//            break;
//        }
//    }
//
//    ret.diskblocknumber       = i*8+j;
//    ret.insidediskblocknumber = 0/*1*/;
//
////    if (maximumsetupsize && ret.diskblocknumber >= maximumsetupsize)
////        maximumsetupsizehasbeenhit = true;
//
//    return ret;
//}

/**********************************************************************
 *
 **********************************************************************/
/* Return the named piece of disk to free space,
*       i.e. de-allocate it
*/
//    void
//diskfree(typediskloafptrdigit loafptr)
//{
//    if (loafptr == NULLBLOCKNUM)
//        return;
//
//    if (!goodblock(loafptr))
//        gerror("Unallocated block in diskfree.\n");
//
//    diskheader.bitmap[loafptr/8] = diskheader.bitmap[loafptr/8] | mask[loafptr%8];
//}

/**********************************************************************
 *
 **********************************************************************/
//    void
//diskset(typediskloafptrdigit loafptr)
//{
//    if (loafptr == NULLBLOCKNUM)
//        return;
//
//    if (!goodblock(loafptr))
//        gerror("Unallocated block in diskfree.\n");
//
//    diskheader.bitmap[loafptr/8] = diskheader.bitmap[loafptr/8] &~ mask[loafptr%8];
//}

/**********************************************************************
 *
 **********************************************************************/
//    bool /* false is not good enfilade file */
//readallocinfo(int fd)
//{
//    bool ret;
//
//    if (lseek(fd, 0L, 0) < 0) {
//        perror("lseek in readallocinfo");
//        gerror("lseek failed\n");
//    }
//
//    if (read(fd, (char *) &diskheader, sizeof(diskheader)) <= 0) {
//        perror("read");
//        gerror("read\n");
//    }
//
//    ret = true;
//    if (!(ret = diskheader.hasenftops)) {
//        cerr << "Old enffile invalid... re-initializing" << endl;
//        initheader ();
//        ret = false;
//
//    } else {
////fixme: variable no longer used        enffiledes = fd;
//        readpartialdiskalloctablefromdisk();
//    }
//
//    return ret;
//}

/**********************************************************************
 *
 **********************************************************************/
//    void
//initheader()
//{
//    memset(diskheader.bitmap, 0xFF, sizeof(diskheader.bitmap));   /* free all */
//    memset(diskheader.bitmap, 0, (NUMDISKLOAFSINHEADER+3)/8+1);
//
//    /* unfree bitmap and granf and spanf*/
//    /* zzzz this rounds up a byte thus may reserve
//       unused blocks  fix by clearing bits ! */
//
//    diskheader.hasenftops = false;
//    initincorealloctables();
//}

/**********************************************************************
 *
 **********************************************************************/
//    void
//diskallocexit(int fd)
//{
//    diskheader.hasenftops = true;
//    savepartialdiskalloctabletodisk();
//    writeallocinfo(fd);
//}

/**********************************************************************
 *
 **********************************************************************/
//    void
//writeallocinfo(int fd)
//{
//    if (lseek(fd, 0L, 0) < 0) {
//        perror("lseek in writeallocinfo");
//        gerror("lseek failed");
//    }
//
//    if (write(fd, (char *) &diskheader, sizeof(diskheader)) == -1) {
//        perror("write in writeallocinfo");
//        gerror("write failed");
//    }
//}

/**********************************************************************
 *
 **********************************************************************/
/*
 *    bool
 *isalloced(DiskLoafAddr loafptr)
 *{
 *    return ! (diskheader.bitmap[loafptr/8] & mask[loafptr%8]);
 *}
 */

/**********************************************************************
 *
 **********************************************************************/
//    int
//isalloced(int n)
//{
//    return diskheader.bitmap[n/8] | mask[n%8];
//}

/**********************************************************************
 *
 **********************************************************************/
//    bool
//goodblock(typediskloafptrdigit diskptr)
//{
//    if (diskptr == 0)
//        return false;
//
//    return ! (diskheader.bitmap[diskptr/8] & mask[diskptr%8]);
//}

/**********************************************************************
 *  Original Copyright � 1979-1999 Udanax.com.   All Rights Reserved
 **********************************************************************/
