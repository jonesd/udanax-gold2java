/**
 * @file  sporgl.cxx
 * @brief Back-End Routines to Handle sporgls
 *
 * (to be defined)
 *
 **/

#include <nana/nana.h>  // GNU Assertion/Logging Tool

#include "xanadu.h"
#include "enf.h"

/**********************************************************************
 *
 **********************************************************************/
    bool
specset2sporglset(Session *sess, typespecset specset, typesporglset *sporglsetptr, int type)
{
    *sporglsetptr = NULL;

    for (; specset; specset = (typespecset) ((typeitemheader *) specset)->next) {
        if (((typeitemheader *) specset)->itemid == ISPANID) {
            *sporglsetptr = (typesporglset) specset;
            sporglsetptr = (typesporglset *) &((typeitemheader *) specset)->next;

        } else if (((typeitemheader *) specset)->itemid == VSPECID) {
            if (!(sporglsetptr = vspanset2sporglset(sess, &((typevspec *) specset)->docisa, ((typevspec *) specset)->vspanset, sporglsetptr, type)))
                return false;
        }
    }

    *sporglsetptr = NULL;

    return true;
}

/**********************************************************************
 *
 **********************************************************************/
    typesporglset *
vspanset2sporglset(Session *sess, IStreamAddr *docisa, typevspanset vspanset, typesporglset *sporglsetptr, int type)
{
    typeorgl orgl;
    typesporgl *sporglset;
    typeispanset ispanset;

    ispanset = NULL;
    if (!findorgl(sess, granf, docisa, &orgl, type))
        return NULL;

    for (; vspanset; vspanset = vspanset->next) {
        (void) vspanset2ispanset(sess, orgl, vspanset, &ispanset);
        for (; ispanset; ispanset = ispanset->next) {
            sporglset         = (typesporgl *) taskalloc(sess, sizeof(typesporgl));
            sporglset->itemid = SPORGLID;
            sporglset->next   = NULL;

            sporglset->sporgladdress = *docisa;

            sporglset->sporglorigin = ispanset->stream;

            sporglset->sporglwidth = ispanset->width;

            *sporglsetptr = (typesporglset) sporglset;
            sporglsetptr  = (typesporglset *) &sporglset->next;
        }
    }

    /* note that this returns the LAST sporgl alloced this is ok
     * the returned value gets passed back to here to be used
     * for a linked list
     */

    return sporglsetptr;
}

/**********************************************************************
 *
 **********************************************************************/
    bool
link2sporglset(Session *sess, IStreamAddr *linkisa, typesporglset *sporglsetptr, int whichend, int type)
{
    typeorgl orgl;
    typevspan vspan;
    Context *c;
    typesporgl *sporglptr;

    if (!findorgl(sess, granf, linkisa, &orgl, type))
        return false;

    Tumbler zero;
    zero.clear();

//    tumblerincrement(&zero, 0, whichend, &vspan.stream);
    vspan.stream = zero.increment(0, whichend);

//    tumblerincrement(&zero, 0 /*1*/, 1, &vspan.width);
    vspan.width = zero.increment(0, 1);

    Context *context = retrieverestricted((CoreUpperCrum *) orgl, &vspan, V_BASIS, (typespan *) NULL, I_BASIS, (IStreamAddr *) NULL);
    if (context != NULL) {
        for (c = context; c; c = c->nextcontext) {
            sporglptr = (typesporgl *) taskalloc(sess, sizeof(typesporgl));
            contextintosporgl((type2dcontext *) c, (Tumbler *) NULL, sporglptr, I_BASIS);
            *sporglsetptr = (typesporglset) sporglptr;
            sporglsetptr = (typesporglset *) &sporglptr->next;
        }

        contextfree(context);
        return true;

    } else
        return false;
}

/**********************************************************************
 *
 **********************************************************************/
    bool
linksporglset2specset(Session *sess, IStreamAddr *homedoc, typesporglset sporglset, typespecset *specsetptr, int type)
{
    typespecset specset;

    *specsetptr = NULL;
    for (; sporglset; sporglset = (typesporglset) ((typeitemheader *) sporglset)->next) {
        specset = (typespecset) taskalloc(sess, sizeof(typevspec));
        if (((typesporgl *) sporglset)->sporgladdress.iszero()) {
            typesporgl *sporgl = (typesporgl *) sporglset;

            if (sporgl->sporglwidth.iszero())
                gerror("zero wid I span in linksporglset2specset\n");

            ((typeitemheader *) specset)->itemid = ISPANID;
            ((typeispan *) specset)->stream = ((typesporgl *) sporglset)->sporglorigin;
            ((typeispan *) specset)->width = ((typesporgl *) sporglset)->sporglwidth;

        } else
            linksporglset2vspec(sess, homedoc, &sporglset, (typevspec *) specset, type);

        ((typeitemheader *) specset)->next = NULL;
        *specsetptr = specset;
        specsetptr = (typespecset *) &((typeitemheader *) specset)->next;
    }

    return true;
}

/**********************************************************************
 *
 **********************************************************************/
/* leaves sporglsetptr on last sporgl processed, NOT next to be processed */
    void
linksporglset2vspec(Session *sess, IStreamAddr *homedoc,  typesporglset *sporglsetptr, typevspec *specptr, int type)
{
    /* typesporglset sporglset;
     * sporglset = *sporglsetptr;
     */

    specptr->itemid = VSPECID;
    specptr->next   = NULL;

    specptr->docisa = *homedoc;

    specptr->vspanset = NULL;
    sporglset2vspanset(sess, homedoc, sporglsetptr, &specptr->vspanset, type);
}

/**********************************************************************
 *
 **********************************************************************/
/* leaves sporglsetptr on last sporgl processed, NOT next to be processed */
    void
sporglset2vspanset(Session *sess, IStreamAddr *homedoc, typesporglset *sporglsetptr, typevspanset *vspansetptr, int type)
{
    typeorgl orgl;
    typeispan ispan;
    typesporgl *sporglptr;

    sporglptr = (typesporgl *) *sporglsetptr;
    findorgl(sess, granf, homedoc /* & sporglptr->sporgladdress*/, &orgl,type);
    ispan.itemid = ISPANID;
    ispan.next = NULL;

    ispan.stream = sporglptr->sporglorigin;

    ispan.width = sporglptr->sporglwidth;

    vspansetptr = ispan2vspanset(sess, orgl, &ispan, vspansetptr);

    for (;;) {
        sporglptr = sporglptr->next;
        if (!sporglptr || sporglptr->itemid != SPORGLID
        || ((typesporgl *)sporglptr)->sporgladdress != ((typesporgl *)(*sporglsetptr))->sporgladdress)
            return;

        *sporglsetptr = (typesporglset) sporglptr;

        ispan.stream = sporglptr->sporglorigin;

        if (sporglptr->sporglwidth.iszero())
            gerror("2 sporgl ispan width 0 in sporglset2vspanset\n");

        ispan.width = sporglptr->sporglwidth;

        vspansetptr = ispan2vspanset(sess, orgl, &ispan, vspansetptr);
    }
}

/**********************************************************************
 *
 **********************************************************************/
    void
unpacksporgl(typesporglset sporglptr, Tumbler *streamptr, Tumbler *widthptr, Core2dBottomCrum::type2dbottomcruminfo *infoptr)
{
    if (((typeitemheader *) sporglptr)->itemid == ISPANID) {
        *streamptr = ((typeispan *) sporglptr)->stream;

        *widthptr = ((typeispan *) sporglptr)->width;

        infoptr->homedoc.clear();

    } else if (((typeitemheader *) sporglptr)->itemid == SPORGLID) {
        *streamptr = ((typesporgl *) sporglptr)->sporglorigin;
        *widthptr = ((typesporgl *) sporglptr)->sporglwidth;

        infoptr->homedoc /* should be sourcedoc */ = ((typesporgl *) sporglptr)->sporgladdress;

    } else {
#ifndef DISTRIBUTION
        cerr << "unpacksporgl - bad itemid" << endl;
#endif
    }

    if (widthptr->iszero())
        qerror("zero width in unpacksporgl\n");
}

/**********************************************************************
 *
 **********************************************************************/
    void
contextintosporgl(type2dcontext *context, Tumbler *linkid, typesporgl *sporglptr, int index)
{
    sporglptr->itemid = SPORGLID;
    sporglptr->next = NULL;

    sporglptr->sporgladdress = /* linkid */ context->context2dinfo.homedoc;

    /* ^^^^^ zzz foo kluge 11/23/84 ^^^^^ */
    sporglptr->sporglorigin = context->totaloffset[index];

    if (context->contextwid[index].iszero())
        gerror("zero wid in contextintosporgl");

    sporglptr->sporglwidth = context->contextwid[index];
}

/**********************************************************************
 *
 **********************************************************************/
    void
sporglset2linkset(Session *sess, CoreUpperCrum *spanfptr, typesporglset sporglset, typelinkset *linksetptr, typeispan *homeset, int spantype)
{
    typeispan nullhomeset;

    *linksetptr = NULL;
    if (true || !homeset) {
        nullhomeset.stream.clear();
        nullhomeset.width.clear();
        nullhomeset.width.mantissa[0] = 100;
        nullhomeset.next = NULL;
        homeset = &nullhomeset;
    }

    for (; homeset; homeset = homeset->next)
        sporglset2linksetinrange(sess, spanfptr, sporglset, linksetptr, homeset, spantype);
}

/**********************************************************************
 *
 **********************************************************************/
    void
sporglset2linksetinrange(Session *sess, CoreUpperCrum *spanfptr, typesporglset sporglset, typelinkset *linksetptr,
             typeispan *orglrange, int spantype)
{
    typespan range;
    Core2dBottomCrum::type2dbottomcruminfo linfo;
    Context *context, *c;
    IStreamAddr linksa;

    Core2dBottomCrum::type2dbottomcruminfo *infoptr = &linfo;
    for (; sporglset; sporglset = (typesporglset) ((typeitemheader *) sporglset)->next) {

        if (false /* trying to kluge links followable thru versions */ && ((typeitemheader *) sporglset)->itemid == SPORGLID) {
            infoptr = &linfo;

            linfo.homedoc = ((typesporgl *) sporglset)->sporgladdress;
        } else
            infoptr = NULL;

        if (orglrange) {
            prefixtumbler(&orglrange->stream,spantype,&range.stream);
            prefixtumbler (&orglrange->width, 0, &range.width);
            context = retrieverestricted(spanfptr, (typespan *) sporglset, SPANRANGE, &range, ORGLRANGE, (IStreamAddr *) infoptr);

        } else
            context = retrieverestricted(spanfptr, (typespan *) sporglset, SPANRANGE, (typespan *) NULL, ORGLRANGE, (IStreamAddr *) infoptr);

        for (c = context; c; c = c->nextcontext) {
            beheadtumbler(&c->totaloffset[ORGLRANGE], &linksa);
            onlinklist(sess, linksetptr, &linksa);
        }

        contextfree(context);
    }
}

/**********************************************************************
 *  Original Copyright � 1979-1999 Udanax.com.   All Rights Reserved
 **********************************************************************/
