/**
 * @file  get2fe.cxx
 * @brief Bottom-Level Input Routines -- Front-End Version
 *
 * (to be defined)
 *
 **/

#include <fstream>
#include <iostream>
#include <nana/nana.h>  // GNU Assertion/Logging Tool

#include "xanadu.h"
#include "players.h"
#include "knives.h"

#define WORDELIM '~'
#define TUMDELIM '.'
#define SPANFLAG 's'
#define VSPECFLAG 'v'
#define TEXTFLAG 't'

extern FILE *logfile;
extern FILE *nulllog;
extern FILE *reallog;

extern bool logstuff;

//extern FILE *interfaceinput;
extern ifstream interfaceinput;

extern FILE *febelog;

static bool gettdigit(Session *sess, int *valueptr);

/**********************************************************************
 *
 **********************************************************************/
    void
pushc(Session *sess, char c)
{
    if (sess->charinbuff)
        error(sess, "charbuff occupied\n");

    else {
        sess->charinbuff = true;
        sess->charbuff = c;
    }
}

/**********************************************************************
 *
 **********************************************************************/
    char
pullc(Session *sess)
{
    int temp;

    if (sess->charinbuff) {
        sess->charinbuff = false;
        return sess->charbuff;

    } else {
        char c;
        sess->inp.get(c);
        temp = c;
        if (sess->inp.eof()) {
            cerr << "EOF on user " << user << " in pullc" << endl;
            frontenddied();
            /* does longjmp in backenddaemon, exit in backend */

            /*
             * fprintf(stderr, "Premature end-of-file in backend\n");
             * diskexit (); // try to avoid screwing enf.enf //
             * gerror("pullc");
             */
        }

        temp &= 0x7f;
//        if (logstuff && interfaceinput.good() && interfaceinput != nulllog) {
//            if (temp == WORDELIM)
//                interfaceinput << endl;
//            else
//                interfaceinput << temp;
//        }

        if (febelog && febelog != nulllog)
            putc(temp, febelog);

        return temp;
    }
}

/**********************************************************************
 *
 **********************************************************************/
    bool
gettumbler(Session *sess, Tumbler *tumblerptr)
{
    char c;
    int i, num, value;

    /* fprintf(sess->errp, "X gettumbler\n"); */

    tumblerptr->clear();
    getnum(sess, &num);
    tumblerptr->exp = -num;

    for (i = 0; gettdigit(sess, &value); i++) {
        if (i > Tumbler::NPLACES) {
            error(sess, "gettumbler overflow\n");
            return false;
        }

        tumblerptr->mantissa[i] = value;
    }

    /*
     * fprintf(logfile, " ");
     * puttumbler(logfile, tumblerptr);
     */

    return (c = pullc(sess)) == WORDELIM || c == '\n';
}

/**********************************************************************
 *
 **********************************************************************/
    static bool
gettdigit(Session *sess, int *valueptr)
{
    char c;

    if ((c = pullc(sess)) != TUMDELIM) {
        pushc(sess, c);
        return false;
    }

    return getnum(sess, valueptr);
}

/**********************************************************************
 *
 **********************************************************************/
    bool
getnum(Session *sess, int *numptr)
{
    char c;
    int num;
    bool flag;

    /* fprintf(sess->errp, "X getnum\n"); */

    num = 0;
    flag = false;

    while ((c = pullc(sess)) /* && putc(c,sess->errp) */ && isdigit(c)) {
        num = num * 10 + c - '0';
        flag = true;
    }

    /* fprintf(sess->errp, "\n"); */

    pushc(sess, c);
    *numptr = num;

    return flag;
}

/**********************************************************************
 *
 **********************************************************************/
    bool
getnumber(Session *sess, int *numptr)
{
    char c;
    int num;
    bool flag;

    num = 0;
    flag = false;

    while ((c = pullc(sess)) && isdigit(c)) {
        num = num * 10 + c - '0';
        flag = true;
    }

    *numptr = num;

    /* fprintf(logfile, " %d", *numptr); */

    return flag && (c == WORDELIM || c == '\n');
}

/**********************************************************************
 *
 **********************************************************************/
    bool
eatchar(Session *sess, char c)
{
    metachar m;

    if ((m = pullc(sess)) != c) {
        pushc(sess, m);
        return false;

    } else
        return true;
}

/**********************************************************************
 *
 **********************************************************************/
    bool
getspecset(Session *sess, typespecset *specsetptr)
{
    int num;
    char c, c1;
    typespecset specset;

    *specsetptr = NULL;
    if (!getnumber(sess, &num))
        return false;

    if (num == 0)
        return true;

    while (num--) {
        c = pullc(sess);
        if ((c != SPANFLAG) && (c != VSPECFLAG))
            return false;

        /*mightn't work*/
        if ((c1 = pullc(sess)) != WORDELIM && c1 != '\n')
            return false;

        if (c == SPANFLAG) {
            specset = (typespecset) taskalloc(sess, sizeof(typespan));
            if (!getspan(sess, (typespan *) specset, ISPANID))
                return false;

        } else {
            specset = (typespecset) taskalloc(sess, sizeof(typevspec));
            if (!getvspec(sess, (typevspec *) specset))
                return false;
        }

        *specsetptr = specset;
        specsetptr = (typespecset *) &((typeitemheader *) specset)->next;
    }

    return true;
}

/**********************************************************************
 *
 **********************************************************************/
    bool
getvspec(Session *sess, typevspec *vspecptr)
{
    /* fprintf(logfile, " vspec"); fprintf (sess->errp, "X getvspec\n"); */

    vspecptr->itemid = VSPECID;
    vspecptr->next = NULL;

    return gettumbler(sess, &vspecptr->docisa) && getspanset(sess, &vspecptr->vspanset, VSPANID);
}

/**********************************************************************
 *
 **********************************************************************/
    bool
getspanset(Session *sess, typespanset *spansetptr, char id)
{
    typespanset spanset;
    int num;

    /* fprintf(logfile, " spanset"); fprintf (sess->errp, "X getspanset\n"); */

    *spansetptr = NULL;
    if (!getnumber(sess, &num))
        return false;

    /* fprintf(sess->errp, "X nspans %d\n", num); fprintf (logfile, " {"); */

    while (num--) {
        spanset = (typespanset) taskalloc(sess, sizeof(typespan));
        if (!getspan(sess, spanset, id))
            return false;

        *spansetptr = spanset;
        spansetptr = &spanset->next;
    }

    /* fprintf(logfile, " }"); */

    return true;
}

/**********************************************************************
 *
 **********************************************************************/
    bool
getspan(Session *sess, typespan *spanptr, char id)
{
    /* fprintf(logfile, " span"); fprintf(sess->errp, "X getspan\n"); */

    spanptr->itemid = id;
    spanptr->next = NULL;

    return gettumbler(sess, &spanptr->stream) && gettumbler (sess, &spanptr->width);
}

/**********************************************************************
 *
 **********************************************************************/
    bool
getcutseq(Session *sess, typecutseq *cutseqptr)
{
    int ncuts, i;
//    Tumbler cutaddress;

    /* fprintf(logfile, " cutseq"); */

    if (!(getnumber(sess, &ncuts) && (ncuts == 3 || ncuts == 4)))
        return false;

    /* fprintf (logfile, " {"); */

    cutseqptr->numberofcuts = ncuts;
    for (i = 0; i < ncuts; ++i) {
        if (!gettumbler(sess, &cutseqptr->cutsarray[i]))
            return false;
    }

    /* fprintf (logfile, " }"); */

    return true;
}

/**********************************************************************
 *
 **********************************************************************/
    bool
gettextset(Session *sess, typetextset *textsetptr)
{
    typetextset textset;
    int num;

    /* fprintf(logfile, " textset"); fprintf (sess->errp, "X gettextset\n"); */

    *textsetptr = NULL;

    if (!getnumber(sess, &num))
        return false;

    /* fprintf(sess->errp, "X number of texts is %d\n", num); fprintf(logfile, " {"); */

    while (num--) {
        textset = (typetextset) taskalloc(sess, sizeof(typetext));
        if (!gettext(sess, textset))
            return false;

        *textsetptr = textset;
        textsetptr = &textset->next;
    }

    /* fprintf(logfile, " }"); */

    return true;
}

/**********************************************************************
 *
 **********************************************************************/
    bool
gettext(Session *sess, typetext *textptr)
{
    int i;

    /* fprintf(sess->errp, "X gettext\n"); */

    if (!(eatchar(sess, TEXTFLAG) && getnumber(sess, &textptr->length))) {
        sess->errp << "\33[55;1fBackend receiving nothing in insert request.\n";
        return false;
    }

    textptr->itemid = TEXTID;
    textptr->next = NULL;

    /* fprintf(logfile, " \""); */

    for (i = 0; i < textptr->length; ++i) {
        textptr->string[i] = pullc(sess);
        /* fprintf(logfile, "%c", textptr->string[i]); */
    }

    /*
     * if (i != -1 && i != 0) {
     *     write(fileno(sess->errp), textptr->string, textptr->length);
     *     fprintf(sess->errp, "FINIS\n");
     * } else
     *     fprintf(sess->errp, "read failed\n");
     */

    /*
     * if (!(eatchar(sess, WORDELIM) || eatchar(sess, '\n')))
     *     return false;   REDUNDANT
     */

    /* fprintf(logfile, "\""); */

    return i != -1 && i != 0;
}

/**********************************************************************
 *
 **********************************************************************/
    bool
getrequest(Session *sess, typerequest *requestptr)
{
    char c;
    int num;
    bool flag;

    /* fprintf(logfile, "\nrequest "); */
    sess->charinbuff = false;

    /*
     * return getnumber(sess, requestptr) && validrequest(sess, *requestptr);
     */

    num = 0;
    flag = false;
    while ((c = pullc(sess)) != 0) {
        fprintf(logfile, "%c", c);
        if (!isdigit(c))
            break;

        num = num * 10 + c - '0';
        flag = true;
    }

    *requestptr = num;
    return flag && (c == WORDELIM || c == '\n') && validrequest(sess, *requestptr);
}

/**********************************************************************
 *
 **********************************************************************/
    bool
validrequest(Session *sess, typerequest request)
{
    if (request >= 0 && request < NREQUESTS && requestfns[request] != NULL)
        return true;

    else {
        sess->errp << "invalid request: " << request << endl;
        return false;
    }
}

/**********************************************************************
 *
 **********************************************************************/
    bool
validaccount(Session *sess, IStreamAddr *accountptr)
{
    return true;
}

/**********************************************************************
 *  Original Copyright � 1979-1999 Udanax.com.   All Rights Reserved
 **********************************************************************/
