/**
 * @file  corediskin.cxx
 * @brief ???
 *
 * (to be defined)
 *
 **/

#include <nana/nana.h>  // GNU Assertion/Logging Tool

#include "xanadu.h"
#include "enf.h"
#include "coredisk.h"

static void unpackloaf(int insidediskblocknumber, DiskLoaf *uloafptr, CoreUpperCrum *father);
static void varunpackloaf(int insidediskblocknumber, DiskLoaf *uloafptr, CoreUpperCrum *father);
static void hgetwiddsp(CoreUpperCrum *ptr, char **loafptrptr);

/**********************************************************************
 *
 **********************************************************************/
 /* Initialize thing from old enf.enf */
    void
initkluge(CoreUpperCrum **granfptr, CoreUpperCrum **spanfptr)
{
    CoreBottomCrum tempcbc;

    /* kluge up a bottum crum, use it to read in granf, similarly for spanf */

//    tempcbc = (CoreBottomCrum *) createcrum(0, GRAN);
    tempcbc.cinfo.infotype = CoreBottomCrum::GRANORGL;
    tempcbc.cinfo.granstuff.orglstuff.diskorglptr.diskblocknumber = GRANFDISKLOCATION;
    tempcbc.cinfo.granstuff.orglstuff.diskorglptr.insidediskblocknumber = 0 /*1*/;

    inorgl(&tempcbc);

    tempcbc.cinfo.granstuff.orglstuff.orglptr->leftbroorfather = NULL;
    *granfptr = tempcbc.cinfo.granstuff.orglstuff.orglptr;
    (*granfptr)->numberofsons = 0; /* hack to make number of sons in granf be correct*/

    /* this is a hack to read in the spanf like an orgl! */
    tempcbc.cinfo.granstuff.orglstuff.diskorglptr.diskblocknumber = SPANFDISKLOCATION;
    tempcbc.cinfo.granstuff.orglstuff.diskorglptr.insidediskblocknumber = 0 /*1*/;

    inorgl(&tempcbc);

    tempcbc.cinfo.granstuff.orglstuff.orglptr->leftbroorfather = NULL;
    *spanfptr = tempcbc.cinfo.granstuff.orglstuff.orglptr;
    (*spanfptr)->numberofsons = 0;

//    destroyCrum((CoreCrum *) tempcbc);
}

/**********************************************************************
 *
 **********************************************************************/
    DiskLoaf *
lookinsideloaffor(int insidenumber, DiskLoaf *uloafptr)
{
    return uloafptr;
}

/**********************************************************************
 *
 **********************************************************************/
   static void
unpackloaf(int insidediskblocknumber, DiskLoaf *uloafptr, CoreUpperCrum *father)
{
    varunpackloaf(insidediskblocknumber, uloafptr, father);
}

/*
 * #define hgetfromloaf(ip,lp) (*(ip)=intof(lp),fprintf(stderr,"hgetfromloaf gets %d\n",*(ip)),(lp)=((char*)lp)+lengthof(lp))
 */

/**********************************************************************
 *
 **********************************************************************/
    static void
varunpackloaf(int insidediskblocknumber, DiskLoaf *uloafptr, CoreUpperCrum *father)
{
    CoreUpperCrum *ptr;
    int            numberofsonstoread, enftype, refcount;

    if (!uloafptr || !father || father->height <= 0)
        gerror("bad varunpackloaf call\n");

    DiskLoaf *xloafptr = lookinsideloaffor(insidediskblocknumber, uloafptr);
    char *loafp = (char *) xloafptr;

    /* loafp += 3; */

    int size;
    hgetfromloaf(&size, loafp);

    int isapex;
    hgetfromloaf(&isapex, loafp);

    I(isapex == false); // Attempt to Read Apex

    int height;
    hgetfromloaf(&height, loafp);

    I(height == father->height - 1);

#ifdef glurg
    father->modified = false;
#endif glurg

    hgetfromloaf(&enftype, loafp);

    I(enftype == father->cenftype);

    hgetfromloaf(&numberofsonstoread, loafp);
    hgetfromloaf(&refcount, loafp);
    father->numberofsons = 0;

    while (numberofsonstoread--) {
        ptr = (CoreUpperCrum *) ((Enfilade *) father)->createCrum(height, enftype);
        father->adoptAsRightmostSon(ptr);
        hgetwiddsp(ptr, &loafp);

        if (height != 0) {
            ptr->isapex = isapex;
            hgetfromloaf(&ptr->sonorigin.diskblocknumber, loafp);
            hgetfromloaf(&ptr->sonorigin.insidediskblocknumber, loafp);

            if (ptr->sonorigin.diskblocknumber == 0) {
#ifndef DISTRIBUTION
                dumphexstuff(loafp);
                dump((CoreCrum *) ptr);
                dumphexstuff((char *) uloafptr);
                gerror("trying to read 0 block\n");
#else
                gerror("");
#endif
            }

            I(ptr->sonorigin.diskblocknumber != NULLBLOCKNUM);

        } else {
            ptr->isapex = false;
            hgetinfo((CoreBottomCrum *) ptr, &loafp);
        }

        ptr->modified = false;
    }
}

/**********************************************************************
 *
 **********************************************************************/
    void
inloaf(CoreUpperCrum *father)
{
    I(father->height != 0); // Attempted Use of inloaf() on a Bottom Crum
    I(father->leftson == NULL); // "Its already got sons, and we aren't going to use pseudo-crums!"

    DiskLoaf loaf;
    readloaf(&loaf, father->sonorigin);
    unpackloaf(father->sonorigin.insidediskblocknumber, &loaf, father);
}

/**********************************************************************
 *
 **********************************************************************/
    void
inorgl(CoreBottomCrum *granorglptr)
{
    inorglinternal(granorglptr, (typeuberrawdiskloaf *) NULL);
}

/**********************************************************************
 *
 **********************************************************************/
    void
inorglinternal(CoreBottomCrum *granorglptr, typeuberrawdiskloaf *crumptr)
{
    DiskLoaf  loaf;
    readloaf(&loaf, granorglptr->cinfo.granstuff.orglstuff.diskorglptr);

    char *loafp = (char *) &loaf;

    int size;
    hgetfromloaf(&size,  loafp);

    unsigned int temp;
    hgetfromloaf(&temp,  loafp); /* isapex */
    hgetfromloaf(&temp,  loafp);

    unsigned int temp2;
    hgetfromloaf(&temp2, loafp);

    CoreUpperCrum *ptr;
    if ( /* false && */ crumptr)
        ptr = (CoreUpperCrum *) crumptr; /* ECH I DON'T LIKE THIS!!! */
    else
        ptr = (CoreUpperCrum *) NULL /*fixme createCrum(temp, temp2) */ ;

    ptr->cenftype   = temp2;
    ptr->isapex     = true;
    ptr->isleftmost = true;

    hgetfromloaf(&temp, loafp);
    ptr->numberofsons = temp;
    hgetfromloaf(&temp, loafp);
    /* ptr->refcount = temp; */

    hgetwiddsp(ptr, &loafp);
    hgetfromloaf(&temp, loafp);
    ptr->sonorigin.diskblocknumber = temp;

    I(ptr->sonorigin.diskblocknumber != 0);
    I(ptr->sonorigin.diskblocknumber != NULLBLOCKNUM);

    hgetfromloaf(&temp, loafp);

    ptr->sonorigin.insidediskblocknumber = temp;
    ptr->modified                        = false;
    ptr->leftbroorfather                 = (CoreCrum *) granorglptr;

    granorglptr->cinfo.granstuff.orglstuff.orglptr = (CoreUpperCrum *) ptr;
    granorglptr->cinfo.granstuff.orglstuff.orglincore = true;

    ptr->rejuvinate();
}

/**********************************************************************
 *
 **********************************************************************/
    static void
hgetwiddsp(CoreUpperCrum *ptr, char **loafptrptr)
{
    int nstreams  = widsize(ptr->cenftype);
//    Displacer *dptr = &ptr->cdsp;

    int i;
    unsigned int temp;
    for (i = 0; i < nstreams; ++i) {
        temp = tumblerptrtofixed((humber) *loafptrptr, &ptr->cdsp[i]);
        *loafptrptr += temp;
    }

    for (i = 0; i < nstreams; ++i) {
        temp = tumblerptrtofixed((humber) *loafptrptr, &ptr->cwid[i]);
        *loafptrptr += temp;
    }
}

/**********************************************************************
 *
 **********************************************************************/
    void
hgetinfo(CoreBottomCrum *ptr, char **loafptrptr) /* this assumes ptr crum is ok except for info */
{
    unsigned int temp;

    if (!ptr->is2dcrum()) {
        hgetfromloaf(&ptr->cinfo.infotype, *loafptrptr);

        if (ptr->cinfo.infotype == CoreBottomCrum::GRANTEXT) {
            ptr->cinfo.granstuff.textstuff.textlength = intof((humber) *loafptrptr);
            (*loafptrptr) += lengthof((humber) * loafptrptr);
            memmove(ptr->cinfo.granstuff.textstuff.textstring, *loafptrptr, ptr->cinfo.granstuff.textstuff.textlength);
            (*loafptrptr) += ptr->cinfo.granstuff.textstuff.textlength;

        } else if (ptr->cinfo.infotype == CoreBottomCrum::GRANORGL) {
            ptr->cinfo.granstuff.orglstuff.diskorglptr.diskblocknumber = intof((humber) *loafptrptr);
/*
 *          if (temp == 0 || temp == -1) {
 *              cerr << "bad diskblocknumber = " << temp << endl;
 *              gerror("boo in hgetinfo");
 *          }
 */

            (*loafptrptr) += lengthof((humber) *loafptrptr);
            ptr->cinfo.granstuff.orglstuff.diskorglptr.insidediskblocknumber = intof((humber) *loafptrptr);
            (*loafptrptr) += lengthof((humber) *loafptrptr);
        }

    } else {
        if (ptr ->height) {
            // looks like we got this all
        } else {
            temp = tumblerptrtofixed((humber) *loafptrptr, &((Core2dBottomCrum *) ptr)->c2dinfo.homedoc);
            (*loafptrptr) += temp;
        }
    }
}

/**********************************************************************
 *  Original Copyright � 1979-1999 Udanax.com.   All Rights Reserved
 **********************************************************************/
