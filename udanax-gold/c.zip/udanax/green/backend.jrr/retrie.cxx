/**
 * @file  retrie.cxx
 * @brief Integrated Enfilade Retrieve Routines
 *
 * (to be defined)
 *
 **/

#include <nana/nana.h>  // GNU Assertion/Logging Tool

#include "xanadu.h"
#include "enf.h"

static void findcbcinarea2d(CoreCrum *crumptr, Displacer *offsetptr, Tumbler *span1start, Tumbler *span1end, int index1,
    Tumbler *span2start, Tumbler *span2end, int index2, Context **headptr, Core2dBottomCrum::type2dbottomcruminfo *infoptr);

static Context *
retrieveinarea(CoreUpperCrum *fullcrumptr, Tumbler *span1start, Tumbler *span1end, int index1,
    Tumbler *span2start, Tumbler *span2end, int index2, Core2dBottomCrum::type2dbottomcruminfo *infoptr);

void findcbcinspanseq(CoreCrum *crumptr, Displacer *offsetptr, Tumbler *spanstart, Tumbler *spanend, Context **headptr);
void prologuend(CoreCrum *ptr, Displacer *offset, Displacer *grasp, Displacer *reach);

static Context *findlastcbcseq(CoreUpperCrum *fullcrumptr);
static Context *findcbcseq(CoreUpperCrum *ptr, Displacer *offsetptr, Tumbler *address);
static Context *findcbcnd(CoreUpperCrum *father, Displacer *offsetptr, Tumbler *address, int index);

/**********************************************************************
 *
 **********************************************************************/
    Context *
retrieve(CoreUpperCrum *fullcrumptr, Tumbler *address, int index)
  /* index:: used when enftype == SPAN or POOM */
{
    Displacer offset;
    memset(&offset, 0, sizeof(Displacer));

    switch (fullcrumptr->cenftype) {
    case GRAN:
        return findcbcseq(fullcrumptr, &offset, address);

    case SPAN:
    case POOM:
        return findcbcnd(fullcrumptr, &offset, address, index);

    default:
        gerror("retrieve - bad enftype\n");
        return NULL;
    }
}

/**********************************************************************
 *
 **********************************************************************/
    Context *
retrieverestricted(CoreUpperCrum *fullcrumptr, typespan *span1ptr, int index1, typespan *span2ptr, int index2, IStreamAddr *docisaptr)
{
    Core2dBottomCrum::type2dbottomcruminfo info, *infoptr;

    StreamAddr span1start, span1end, span2start, span2end;

    if (span1ptr) {
        span1start = span1ptr->stream;
        span1end   = span1start + span1ptr->width;

    } else {
        span1start.clear();
        span1end.clear();
    }

    if (span2ptr) {
        span2start = span2ptr->stream;
        span2end   = span2start + span2ptr->width;

    } else {
        span2start.clear();
        span2end.clear();
    }

    if (docisaptr) {
        info.homedoc /* shouldberestrictiondoc */ = *docisaptr;

        infoptr = &info;
    } else
        infoptr = NULL;

    Context *temp = retrieveinarea(fullcrumptr, &span1start, &span1end, index1, &span2start, &span2end, index2, infoptr);
    return temp;
}

/**********************************************************************
 *
 **********************************************************************/
    static Context *
retrieveinarea(CoreUpperCrum *fullcrumptr, Tumbler *span1start, Tumbler *span1end, int index1, Tumbler *span2start, Tumbler *span2end,
        int index2, Core2dBottomCrum::type2dbottomcruminfo *infoptr)
{
    Displacer offset;
    memset(&offset, 0, sizeof(offset));

    Context *context = NULL;

    switch (fullcrumptr->cenftype) {
    case SPAN:
    case POOM:
        findcbcinarea2d((CoreCrum *) fullcrumptr, &offset, span1start, span1end, index1, span2start, span2end, index2, &context, infoptr);
        break;

    default:
        I(false); // wrong enftype
        return NULL;
    }

    return context;
}

/**********************************************************************
 *
 **********************************************************************/
    Context *
retrieveinspan(CoreUpperCrum *fullcrumptr, Tumbler *spanstart, Tumbler *spanend, int index)
{
    Displacer offset;
    Context *context, *c;

    memset(&offset, 0, sizeof(offset));
    context = NULL;

    switch (fullcrumptr->cenftype) {
    case GRAN:
        findcbcinspanseq((CoreCrum *) fullcrumptr, &offset, spanstart, spanend, &context);
        if (*spanend > fullcrumptr->cwid[WIDTH]) {
            c = findlastcbcseq(fullcrumptr);
            oncontextlistseq(&context, c);
        }

        return context;

    default:
#ifndef DISTRIBUTION
        gerror("retrieveinspan - wrong enftype\n");
#else
        gerror("");
#endif
        return NULL;
    }
}

/**********************************************************************
 *
 **********************************************************************/
    static Context *
findlastcbcseq(CoreUpperCrum *fullcrumptr)
{
    StreamAddr offset;
    offset.clear();

    CoreUpperCrum *ptr;
    for (ptr = fullcrumptr; ptr; ptr = (CoreUpperCrum *) ptr->leftSon()) {

        for (; ptr->rightBrother(); ptr = (CoreUpperCrum *) ptr->rightbro)
            offset = offset + ptr->cwid[WIDTH];

        if (ptr->height == 0) {
            Displacer dsp;
            dsp[0] = offset;

            Context *c = makecontextfromcbc((CoreBottomCrum *) ptr, &dsp);
            return c;
        }
    }

    I(false); // in findlastcbcseq couldn't find anything
    return NULL;  /* for lint */
}

/**********************************************************************
 *
 **********************************************************************/
    static Context *
findcbcseq(CoreUpperCrum *ptr, Displacer *offsetptr, Tumbler *address)
{
    for (; ptr->rightBrother(); ptr = (CoreUpperCrum *) ptr->rightbro) {
        if (whereoncrum(ptr, offsetptr, address, WIDTH) <= THRUME)
            break;

//        dspadd(offsetptr, static_cast<Displacer*>(static_cast<Wisp*>(&ptr->cwid)), offsetptr, (int) ptr->cenftype);
        *offsetptr = add(*offsetptr, ptr->cwid, ptr->cenftype);
    }

    if (ptr->height != 0) {
        ptr = (CoreUpperCrum *) ptr->leftSon();
        return findcbcseq(ptr, offsetptr, address);

    } else
        return makecontextfromcbc((CoreBottomCrum *) ptr, offsetptr);
}

/**********************************************************************
 *
 **********************************************************************/
    static Context *
findcbcnd(CoreUpperCrum *father, Displacer *offsetptr, Tumbler *address, int index)
{
    CoreCrum *ptr;
    Displacer grasp;

    int cmp;
    if ((cmp = whereoncrum(father, offsetptr, address, index)) < ONMYLEFTBORDER || cmp > THRUME)
        return NULL;

    Context *retr = NULL;

    if (father->height != 0) {
        prologuend(father, offsetptr, &grasp, (Displacer *) NULL);
        for (ptr = father->leftSon(); ptr; ptr = ptr->rightBrother())
            if ((retr = findcbcnd((CoreUpperCrum *) ptr, &grasp, address, index)) != 0)
                break;

    } else /* FOUND IT! */
        retr = makecontextfromcbc((CoreBottomCrum *) father, offsetptr);

    return retr;
}

/**********************************************************************
 *
 **********************************************************************/
    static void
findcbcinarea2d(CoreCrum *crumptr, Displacer *offsetptr, Tumbler *span1start, Tumbler *span1end, int index1,
     Tumbler *span2start, Tumbler *span2end, int index2, Context **headptr, Core2dBottomCrum::type2dbottomcruminfo *infoptr)
{
    Displacer localoffset;
    Context *context;

    I(infoptr == NULL); // not NULL infoptr versions mumble specialcase 11/27/84 shouldn't happen till we try something fancier

    for (; crumptr; crumptr = crumptr->rightBrother()) {
        if (!crumqualifies2d(crumptr, offsetptr, span1start, span1end, index1, span2start, span2end, index2, (Core2dBottomCrum::type2dbottomcruminfo *) infoptr))
            continue;

        if (crumptr->height != 0) {
            localoffset = add(*offsetptr, crumptr->cdsp, crumptr->cenftype);

            findcbcinarea2d(((CoreUpperCrum *) crumptr)->leftSon(), &localoffset, span1start, span1end, index1, span2start, span2end, index2, headptr, infoptr);

        } else {
            context = makecontextfromcbc((CoreBottomCrum *) crumptr, offsetptr);
            incontextlistnd(headptr, context, index1);
        }
    }
}

/**********************************************************************
 *
 **********************************************************************/
    bool                  /* 6-28-84 old code*/
crumqualifies2d(CoreCrum *crumptr, Displacer *offset, Tumbler *span1start, Tumbler *span1end, int index1,
   Tumbler *span2start, Tumbler *span2end, int index2, Core2dBottomCrum::type2dbottomcruminfo *infoptr)
{
    if (crumptr->height == 0 && infoptr && infoptr->homedoc != (((Core2dBottomCrum *) crumptr)->c2dinfo.homedoc))
        return false;

    int endcmp = span1end->iszero() ? TOMYRIGHT : whereoncrum(crumptr, offset, span1end, index1);
    if (endcmp <= /*=*/ ONMYLEFTBORDER)
        return false;

    int startcmp = whereoncrum(crumptr, offset, span1start, index1);
    if ((startcmp > THRUME /* && endcmp > THRUME */)) {
        /* foo("returningfalse case d"); */
        return false;
    }

    endcmp = span2end->iszero() ? TOMYRIGHT : whereoncrum(crumptr, offset, span2end, index2);
    if (endcmp < ONMYLEFTBORDER) /* <= was < 12/20/84 */ {
        /* foo("returningfalse case e"); */
        return false;
    }

    startcmp = whereoncrum(crumptr, offset, span2start, index2);
    if ((startcmp > THRUME /* && endcmp > THRUME*/)) {
        /* foo("returningfalse case f"); */
        return false;
    }

    /* foo("crumqualifies2d returning true\n"); */
    return true;
}

/**********************************************************************
 *
 **********************************************************************/
    void
findcbcinspanseq(CoreCrum *crumptr, Displacer *offsetptr, Tumbler *spanstart, Tumbler *spanend, Context **headptr)
{
    Context *context;

//    movewid(offsetptr, &localoffset); // Move a WISP
    Displacer localoffset = *offsetptr;

    for (; crumptr; crumptr = crumptr->rightBrother()) {

        if (!crumintersectsspanseq(crumptr, &localoffset[0], spanstart, spanend)) {

//            dspadd(&localoffset, static_cast<Displacer*>(static_cast<Wisp*>(&crumptr->cwid)), &localoffset, (int) crumptr->cenftype);
            localoffset = add(localoffset, crumptr->cwid, crumptr->cenftype);

            continue;
        }

        if (crumptr->height == 0) {
            context = makecontextfromcbc((CoreBottomCrum *) crumptr, offsetptr);
            oncontextlistseq(headptr, context);

        } else
            findcbcinspanseq(((CoreUpperCrum *) crumptr)->leftSon(), &localoffset, spanstart, spanend, headptr);

//        dspadd(&localoffset, static_cast<Displacer*>(static_cast<Wisp*>(&crumptr->cwid)), &localoffset, (int) crumptr->cenftype);
        localoffset = add(localoffset, crumptr->cwid, crumptr->cenftype);
    }
}

/**********************************************************************
 *
 **********************************************************************/
/* sets grasp & reach from ptr & offset */
/*  reach may be NULL so that we won't set it */
    void
prologuend(CoreCrum *ptr, Displacer *offset, Displacer *grasp, Displacer *reach)
{
//    dspadd(offset, &ptr->cdsp, grasp, (int) ptr->cenftype);
    *grasp = add(*offset, ptr->cdsp, ptr->cenftype);

    if (reach)
//        dspadd(grasp, static_cast<Displacer*>(static_cast<Wisp*>(&ptr->cwid)), reach, (int) ptr->cenftype);
        *reach = add(*grasp, ptr->cwid, ptr->cenftype);
}

/**********************************************************************
 *
 **********************************************************************/
//#define intervalcmppart1(left, address) 
//    cmp = tumblercmp((address), (left)); 
//    if (cmp == LESS) return TOMYLEFT;
//    else if (cmp == EQUAL) return ONMYLEFTBORDER;

//#define intervalcmppart2(right, address) 
//    cmp = tumblercmp((address), (right)); 
//    if (cmp == LESS) return THRUME; 
//    else if (cmp == EQUAL) return ONMYRIGHTBORDER; 
//    else return TOMYRIGHT;

/**********************************************************************
 *
 **********************************************************************/
    int
whereoncrum(CoreCrum *ptr, Displacer *offset, Tumbler *address, int index) /* speed up by subsuming intervalcmp */
  /* index:: used when enftype == SPAN or POOM */
{
    switch (ptr->cenftype) {
    case GRAN:
      {
        // Compute the Right Side of the Crum's Address Space
        StreamAddr right = (*offset)[WIDTH] + ptr->cwid[WIDTH];

        // Return the Position of the Passed-In Address Relative to that Crum Space
        return intervalcmp(&(*offset)[WIDTH], &right, address);
      }

    case SPAN:
    case POOM:
      {
///////////////////////////////////////////FIXME !!
//        StreamAddr left = (*offset)[index] + ptr->cdsp[index];   appears to add two addresses, which is illegal !
        StreamAddr left = ptr->cdsp[index];
///////////////////////////////////////////FIXME !!

        switch (address->compareTo(left)) {
        case Tumbler::LESS:   return TOMYLEFT;
        case Tumbler::EQUAL:  return ONMYLEFTBORDER;
        } // Fall-Thru Intentional

        StreamAddr right = left + ptr->cwid[index];

        switch (address->compareTo(right)) {
        case Tumbler::LESS:   return THRUME;
        case Tumbler::EQUAL:  return ONMYRIGHTBORDER;
        default:              return TOMYRIGHT;
        }
      }

    default:
        I(false); // Invalid Type of Enfilade
    }

    return 0; /* for lint */
}

/**********************************************************************
 *
 **********************************************************************/
/*
 *    int
 *intervalcmp(Tumbler *left, Tumbler *right, Tumbler *address)
 *{
 *    register int cmp;
 *
 *    cmp = tumblercmp(address, left);
 *
 *    if (cmp == LESS)
 *        return TOMYLEFT;
 *    else if (cmp == EQUAL)
 *        return ONMYLEFTBORDER;
 *
 *    cmp = tumblercmp(address, right);
 *    if (cmp == LESS)
 *        return THRUME;
 *
 *    else if (cmp == EQUAL)
 *        return ONMYRIGHTBORDER;
 *    else
 *        return TOMYRIGHT;
 *}
 */

/**********************************************************************
 *
 **********************************************************************/
    bool
crumintersectsspanseq(CoreCrum *crumptr, Tumbler *offsetptr, Tumbler *spanstart, Tumbler *spanend)
{
    if (crumptr->cwid[WIDTH].iszero())
        return false;

    return (whereoncrum(crumptr, (Displacer *) offsetptr, spanstart, WIDTH) < ONMYRIGHTBORDER)
        && (whereoncrum(crumptr, (Displacer *) offsetptr, spanend, WIDTH) > /*=*/ ONMYLEFTBORDER);
}

/**********************************************************************
 *  Original Copyright � 1979-1999 Udanax.com.   All Rights Reserved
 **********************************************************************/
