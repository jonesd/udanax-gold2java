/**
 * @file  bed.cxx
 * @brief Main -- Multiuser Backend
 *
 * (to be defined)
 *
 * \todo
 *   Much more work needed in here.
 **/

#include <fstream>
#include <iostream>
#include <signal.h>
#include <errno.h>
#include <setjmp.h>     /* an easy way to deal with unexpected EOF on frontend input */
#include <time.h>
#include <sys/select.h>
#include <sys/time.h>

#include <nana/nana.h>  // GNU Assertion/Logging Tool

#include "xanadu.h"
#include "requests.h"
#include "players.h"
#include "allocio.h"

extern int  backenddaemon; /* backend version */
extern int  main_socket;

extern BitmapAllocIO *aio;
extern MMapCacheIO   *cio;

jmp_buf frontendeof;

int user = 0;           /* Global current user ID */

FILE   *logfile;
FILE   *nulllog;
FILE   *reallog;
bool    isxumain = false;
char    outputbuffer[BUFSIZ];
char    inputbuffer[BUFSIZ];
bool    logstuff;

//FILE   *interfaceinput = NULL;
ifstream interfaceinput;

FILE   *febelog = NULL;
struct  timeval timeout;
bool    quitafteruser = false;
bool    mightbeblocked = false;
long    ntaskorcommand; // Part of Main
int     debug; // Part of Main

static Tumbler currentaccount;

//diskheader
//varcrums
//ingrimreaper
//nolread
//nolwrote
//noishouldbother
//notakenephewnd
//noeatbrosnd
//isxumain
//logfile
//nulllog
//reallog
//interfaceinput
//febelog

static void xanadu(Session *sess);
bool establishprotocol(ifstream inp, ofstream outp);
static void flagquitting(int);

// socketbe.cpp
extern void new_players(PLAYER player[], int *n_playersp, int block, Session *sess);
extern void leave(PLAYER player[], int *xn_players);
extern int   open_sock();
extern void *crash(int);
extern bool isthisusersdocument(Tumbler *tp);

/**
 * Back-End Daemon -- TCP Socket Listener
 **/
     int
main(int argc, char *argv[])
{
    backenddaemon = 1;
    debug = 0;

    signal(SIGPIPE, (__sighandler_t) crash);
    signal(SIGHUP,  (__sighandler_t) crash);
    signal(SIGXCPU, SIG_IGN);
    signal(SIGINT,  flagquitting);

    long clock = time(0);
    struct tm *local = localtime(&clock); // Note Time of Startup

    // Redirect stderr into file ./backenderror
//    freopen("udanax.log", "w", stderr);
    setbuf(stderr, NULL);

    // Insure We Have Enough stdin/stdout Buffering
    setbuf(stdin, inputbuffer);
    setbuf(stdout, outputbuffer);

    // Create Uniquely-Named File to Log Interface Input
    char buf[100];
    sprintf(buf, "ln%d.%d.%d:%d", local->tm_mon+1, local->tm_mday, local->tm_hour, local->tm_min);
    interfaceinput.open(buf, ios::in);

#ifndef DISTRIBUTION
    // Create Uniquely-Named File to Log FEBE Traffic
    sprintf(buf, "febe%d.%d.%d:%d", local->tm_mon+1, local->tm_mday, local->tm_hour, local->tm_min);
    febelog = fopen(buf, "w");
    setbuf(febelog, NULL);
#endif

    fprintf(stderr, "Processing rc File\n");
    processrcfile();

    timeout.tv_sec = 2; /* wait 2 seconds on a select, then look for a new user */

    reallog = logfile = nulllog = fopen("/dev/null", "a");

    cerr << "Calling init(1)" << endl;
    init(1);

    cerr << "Calling inittask(&task)" << endl;
    Session task;
    inittask(&task);

    errno = 0;
    cerr << "Calling initmagicktricks()" << endl;
    initmagicktricks();

    cerr << "Calling open_sock()" << endl;
    main_socket = open_sock();

    if (n_players < 1) {
        cerr << "No Front-Ends, Sleeping until One Arrives" << endl;

        mightbeblocked = true;
        new_players(player, &n_players, true, &task); /* wait for fe to talk to */
        mightbeblocked = false;

    } else
        cerr << n_players << " Front-Ends Found, Starting Service Immediately" << endl;

    for (;;) {
        if (n_players < 1) {
            diskflush(); /* Write out everything when no one around */
            mightbeblocked = true;
            new_players(player, &n_players, true, &task);  /* wait for fe to talk to */
            mightbeblocked = false;
        }

        fd_set inputfds2 = inputfds;
//        cerr << "Calling select()" << endl;

        if (select(nfds+1, &inputfds2, 0, 0, &timeout) < 0) {
            if (errno == EINTR)
                continue;

            perror("select");
            gerror("select in main");

        } else {
//            cerr << "Finished select()" << endl;

            int i;
            for (i = 0; i <= nfds; i++) {
                if (FD_ISSET(i, &inputfds2)) {
                    user         = fdtoplayer[i];
                    task.inp     = player[user].inp;
                    task.outp    = player[user].outp;
                    task.account = player[user].account;

                    if (currentaccount != task.account) {
                        currentaccount = task.account;
                        logaccount(&task.account);
                    }

                    xanadu(&task);

                    if (quitafteruser) {
//                        if (interfaceinput.good()) {
//                            interfaceinput << QUIT << '~' << endl;
//                            interfaceinput.close();
//                        }
                        writeenfilades();
//                        closediskfile();
                        aio->sync();
                        cio->close();
                        exit(0);
                    }

                    /* testforreservedness("main"); */
                    /* logfile = nulllog; */
                    ntaskorcommand++;
                }
            }
        }

        leave(player, &n_players);
        mightbeblocked = true;
        new_players(player, &n_players, false ,&task);
        mightbeblocked = false;
    }
}

/**********************************************************************
 *
 **********************************************************************/
    static void
xanadu(Session *sess)
{
    typerequest request;

    logstuff = false;
    if (setjmp(frontendeof)) {
        cerr << "---------- End of Session ----------" << endl;
        dobertexit(user);
        player[user].wantsout = true;

    } else if (getrequest(sess, &request)) {
        (*requestfns[request])(sess);
        sendresultoutput(sess);
        if (request == QUIT)
            player[user].wantsout = true;
    }

    tfree(sess);
//    if (interfaceinput.good() && interfaceinput.filedesc() != nulllog)
//        interfaceinput.flush();

    logstuff = false;
}

/**********************************************************************
 *            Signal Handler
 **********************************************************************/
    static void
flagquitting(int)
{
    signal(SIGINT, SIG_IGN);    /* Don't die too early */

    if (mightbeblocked) {
//        if (interfaceinput.good()) {
//            interfaceinput << QUIT << '~' << endl;
//            interfaceinput.close();
//        }

        writeenfilades();

//        closediskfile ();
        aio->sync();
        cio->close();

        exit(0);

    } else
        quitafteruser = true;   /* Flag to stop backend after current request */
}

/**********************************************************************
 *
 **********************************************************************/
    bool
establishprotocol(ifstream inp, ofstream outp)
{
//    metachar ch;
//
//    /* This is the metaprotocol for the time being */
//    while ((ch = getc(inp)) != '\n')
//        cerr << (ch > ' ' ? ch : '.');
//
//    while ((ch = getc(inp)) == '\n')
//        cerr << ch;
//
//    if (ch == 'P' && getc(inp) == '0' && getc(inp) == '~') {
//        if (!feof(inp)) { /* Don't send to a dead pipe */
//            xuputstring("\nP0~", outp);
//            fflush(outp);
//            return true;
//        }
//
//    } else {
//        if (!inp.eof()) // Don't send to a dead pipe
//            outp << endl << "P?~" << flush;
//    }

    return false;
}


/**********************************************************************
 *
 **********************************************************************/
    void
frontenddied()
{
    longjmp(frontendeof, 1);
}

/**********************************************************************
 *
 **********************************************************************/
/* for  linker until we get this cleaned up */
    bool
setmaximumsetupsize(Session *sess)
{
    return true; //fixme: what do I return ?!?!?
}

/**********************************************************************
 *
 **********************************************************************/
    void
sourceunixcommand(Session *sess)
{
}

/**********************************************************************
 *
 **********************************************************************/
    bool
decrementusers()
{
    if (n_players > 1)
        player[user].wantsout = 1;

    return n_players > 1;
}

/**********************************************************************
 *  Original Copyright � 1979-1999 Udanax.com.   All Rights Reserved
 **********************************************************************/
