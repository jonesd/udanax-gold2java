/**
 * @file  putfe.cxx
 * @brief Output Routines -- Front-End Version
 *
 * (to be defined)
 *
 **/

#include <nana/nana.h>  // GNU Assertion/Logging Tool

#include "xanadu.h"
#include "requests.h"

extern FILE *logfile;
extern FILE *nulllog;
extern FILE *reallog;

extern FILE *febelog;
bool firstputforrequest;

#define WORDELIM '~'
#define TUMDELIM '.'
#define SPANFLAG 's'
#define VSPECFLAG 'v'
#define TEXTFLAG 't'
#define FAILFLAG '?'

/*#define xuputc(c,fd) putc ((c), (fd))*/

void putitem(Session *sess, typeitem *itemptr);
void putspan(Session *sess, typespan *spanptr);
void puttextset(Session *sess, typetext **textptrptr);
void puttext(Session *sess, typetext *textptr);
void putspanpair(Session *sess, typespanpair *spanpair);

/**********************************************************************
 *
 **********************************************************************/
    void
xuputc(char c, FILE *fd)
{
    if (putc(c, fd) == EOF) {
        perror("xuputc");
        frontenddied();

    } else if (febelog && febelog != nulllog) {
        if (firstputforrequest)
            fprintf(febelog, "\nbe:\n");

        firstputforrequest = false;
        putc(c, febelog);
    }
}

/**********************************************************************
 *
 **********************************************************************/
    void
xuputstring(char *string, FILE *fd)
{
    /* while (*string)
     *     xuputc(*string++, fd);
     */

    fwrite(string, 1, strlen(string), fd);
}

/**********************************************************************
 *
 **********************************************************************/
//    void
//putnum(FILE *outfile, int num)
//{
//    char digits[32];
//    int i;
//
//    if (num == 0)
//        xuputc('0', outfile);
//
//    else {
//        if (num < 0) {
//            num = -num;
//            xuputc('-', outfile);
//        }
//
//        for (i = 0; num != 0; ) {
//            digits[i++] = (char) (num % 10 +  (int) '0');
//            num /= 10;
//        }
//
//        while (i > 0)
//            xuputc(digits[--i], outfile);
//    }
//}

/**********************************************************************
 *
 **********************************************************************/
    void
sendresultoutput(Session *sess)
{
    /*
     * FILE *fd;
     *
     * fd = sess->outp;
     * write(fd->_file, fd->_base, (int) (fd->_ptr - fd->_base));
     * fd->_ptr = fd->_base;
     * fd->_cnt = BUFSIZ;
     */

    sess->outp.flush();
}

/**********************************************************************
 *
 **********************************************************************/
    void
error(Session *sess, char *string)
{
    sess->errp << string;
}

/**********************************************************************
 *
 **********************************************************************/
    void
prompt(Session *sess, char *string)
{
    sess->outp << string;
}

/**********************************************************************
 *
 **********************************************************************/
//    void
//putnumber(FILE *outfile, int num)
//{
//    outfile << num << (char) WORDELIM;
//}

/**********************************************************************
 *
 **********************************************************************/
    void
putisa(Session *sess, IStreamAddr *isaptr)
{
    sess->outp << *isaptr;
}

/**********************************************************************
 *
 **********************************************************************/
    void
putitemset(Session *sess, typeitemset itemset)
{
    int i;
    typeitemset temp;

    for (temp = itemset, i = 0; temp; temp = (typeitemset) ((typeitemheader *) temp)->next, ++i) {
        while (((typeitemheader *) temp)->itemid == TEXTID && ((typeitemheader *) temp)->next && ((typeitemheader *) temp)->next->itemid == TEXTID)
            temp = (typeitemset) ((typeitemheader *) temp)->next; /* count lots of textitems as one item */
    }

    sess->outp << i << (char) WORDELIM;

    /* fprintf(sess->errp, "X putitemset  nitems is %d\n", i); */

    for (; itemset; itemset = (typeitemset) ((typeitemheader *) itemset)->next) {
        if (((typeitemheader *) itemset)->itemid == TEXTID)
            puttextset(sess, (typetext**) &itemset);
        else
            putitem(sess, itemset);
    }
}

/**********************************************************************
 *
 **********************************************************************/
    void
putitem(Session *sess, typeitem *itemptr)
{
    switch (((typeitemheader *) itemptr)->itemid) {
    case ISPANID:
        sess->outp << (char) SPANFLAG;
        sess->outp << (char) WORDELIM;
        putspan(sess, (typespan *) itemptr);
        break;

    case VSPANID:
        putspan(sess, (typespan *) itemptr);
        break;

    case VSPECID:
        sess->outp << (char) VSPECFLAG;
        sess->outp << (char) WORDELIM;
        sess->outp << ((typevspec *) itemptr)->docisa;
        putitemset(sess, (typeitemset) ((typevspec *) itemptr)->vspanset);
        break;

    case TEXTID:
        /* fprintf(sess->errp, "X put text %d characters\n", itemptr->length); */
        puttext(sess, (typetext *) itemptr);
        break;

    case ADDRESSID:
        /*
         * fprintf(sess->errp, "X put address ");
         * puttumbler(sess->errp, &itemptr->address);
         * fprintf(sess->errp, "\n");
         */

        sess->outp << ((typeaddress *) itemptr)->address;
        break;

    default:
        error(sess, "illegal item id for senditem");
        return;
    }
}

/**********************************************************************
 *
 **********************************************************************/
    void
putspan(Session *sess, typespan *spanptr)
{
    fprintf(logfile, "putspan\n");

    sess->outp << spanptr->stream;
    sess->outp << spanptr->width;
}

/**********************************************************************
 *
 **********************************************************************/
    void
puttextset(Session *sess, typetext **textptrptr)
{
    typetext *textptr, *last;
    int i;

    for (i = 0, textptr = *textptrptr; textptr && textptr->itemid == TEXTID; textptr = textptr->next)
        i += textptr->length;

    sess->outp << (char) TEXTFLAG;
    sess->outp << i << (char) WORDELIM;
    last = NULL;

    for (textptr = *textptrptr; textptr && textptr->itemid == TEXTID; textptr = textptr->next) {
        for (i = 0; i < textptr->length; ++i)
            sess->outp << textptr->string[i];

        last = textptr;
    }

    *textptrptr = last;
}

/**********************************************************************
 *
 **********************************************************************/
    void
puttext(Session *sess, typetext *textptr)
{
    int i;

    fprintf(logfile, "puttext\n");

    /* fprintf(sess->errp, "X puttext %d characters\n", textptr->length); */

    sess->outp << (char) TEXTFLAG;
    sess->outp << textptr->length << (char) WORDELIM;

    /* write(fileno(sess->outp), textptr->string, textptr->length); */

    for (i = 0; i < textptr->length; ++i)
        sess->outp << textptr->string[i];
}

/**********************************************************************
 *
 **********************************************************************/
    void
putspanpairset(Session *sess, typespanpairset spanpairset)
{
    typespanpair *ptr;
    int n;

    for (n = 0, ptr = spanpairset; ptr; ++n, ptr = ptr->nextspanpair)
        ;

    sess->outp << n << (char) WORDELIM;

    for (; spanpairset; spanpairset = spanpairset->nextspanpair)
        putspanpair(sess, spanpairset);
}

/**********************************************************************
 *
 **********************************************************************/
    void
putspanpair(Session *sess, typespanpair *spanpair)
{
    sess->outp << spanpair->stream1
               << spanpair->stream2
               << spanpair->widthofspan;
}


/* ---------------- top level put routines --------------- */

/**********************************************************************
 *
 **********************************************************************/
    void
putinsert(Session *sess)
{
    sess->outp << INSERT << (char) WORDELIM;
}

/**********************************************************************
 *
 **********************************************************************/
    void
putretrievedocvspanset(Session *sess, typespanset *spansetptr)
{
    sess->outp << RETRIEVEDOCVSPANSET << (char) WORDELIM;
    putitemset(sess, (typeitemset) *spansetptr);
}

/**********************************************************************
 *
 **********************************************************************/
    void
putcopy(Session *sess)
{
    sess->outp << COPY << (char) WORDELIM;
}

/**********************************************************************
 *
 **********************************************************************/
    void
putrearrange(Session *sess)
{
    sess->outp << REARRANGE << (char) WORDELIM;
}

/**********************************************************************
 *
 **********************************************************************/
    void
putcreatelink(Session *sess, IStreamAddr *istreamptr)
{
    sess->outp << CREATELINK << (char) WORDELIM;
    putisa(sess, istreamptr);
}

/**********************************************************************
 *
 **********************************************************************/
    void
putretrievev(Session *sess, typevstuffset *vstuffsetptr)
{
    /* fprintf(sess->errp, "X putretrievev\n"); */

    sess->outp << RETRIEVEV << (char) WORDELIM;
    putitemset(sess, (typeitemset) *vstuffsetptr);
}

/**********************************************************************
 *
 **********************************************************************/
    void
putfindnumoflinksfromtothree(Session *sess, int num)
{
    sess->outp << FINDNUMOFLINKSFROMTOTHREE << (char) WORDELIM;
    sess->outp << num << (char) WORDELIM;
}

/**********************************************************************
 *
 **********************************************************************/
    void
putfindlinksfromtothree(Session *sess, typelinkset linkset)
{
    fprintf(logfile, "putfindlinksfromtothree\n");

    sess->outp << FINDLINKSFROMTOTHREE << (char) WORDELIM;
    putitemset(sess, (typeitemset) linkset);
}

/**********************************************************************
 *
 **********************************************************************/
    void
putfindnextnlinksfromtothree(Session *sess, int n, typelinkset nextlinkset)
{
    /* fprintf(sess->errp, "X putfindnextnlinksfromtothree\n"); */

    sess->outp << FINDNEXTNLINKSFROMTOTHREE << (char) WORDELIM;
    putitemset(sess, (typeitemset) nextlinkset);
}

/* historical trace */

/**********************************************************************
 *
 **********************************************************************/
    void
putshowrelationof2versions(Session *sess, typespanpairset relation)
{
    sess->outp << SHOWRELATIONOF2VERSIONS << (char) WORDELIM;
    putspanpairset(sess, relation);
}

/**********************************************************************
 *
 **********************************************************************/
    void
putcreatenewdocument(Session *sess, IStreamAddr *newdocisaptr)
{
    /*
     * fprintf(sess->errp, "X new document created ");
     * puttumbler(sess->errp, newdocisaptr);
     * fprintf(sess->errp, "\n");
     */

    sess->outp << CREATENEWDOCUMENT << (char) WORDELIM;
    putisa(sess, newdocisaptr);
}

/**********************************************************************
 *
 **********************************************************************/
    void
putdeletevspan(Session *sess)
{
    sess->outp << DELETEVSPAN << (char) WORDELIM;
}

/**********************************************************************
 *
 **********************************************************************/
    void
putcreatenewversion(Session *sess, IStreamAddr *newdocisaptr)
{
    sess->outp << CREATENEWVERSION << (char) WORDELIM;
    putisa(sess, newdocisaptr);
}

/**********************************************************************
 *
 **********************************************************************/
    void
putretrievedocvspan(Session *sess, typespan *vspanptr)
{
    sess->outp << RETRIEVEDOCVSPAN << (char) WORDELIM;
    putspan(sess, vspanptr);
}

/* set debug */

/* disk exit */

/* show enfilades */

/**********************************************************************
 *
 **********************************************************************/
    void
putfollowlink(Session *sess, typespecset specset)
{
    sess->outp << FOLLOWLINK << (char) WORDELIM;
    putitemset(sess, (typeitemset) specset);
}

/* examine */

/* source unix command */

/**********************************************************************
 *
 **********************************************************************/
    void
putfinddocscontaining(Session *sess, typeitemset addressset)
{
    /* fprintf(sess->errp, "X putfinddocscontaining\n"); */

    sess->outp << FINDDOCSCONTAINING << (char) WORDELIM;
    putitemset(sess, addressset);
}

/**********************************************************************
 *
 **********************************************************************/
    void
putretrieveendsets(Session *sess, typespecset fromset, typespecset toset, typespecset threeset)
{
    sess->outp << RETRIEVEENDSETS << (char) WORDELIM;
    putitemset(sess, (typeitemset) fromset);
    putitemset(sess, (typeitemset) toset);
    putitemset(sess, (typeitemset) threeset);
}

/**********************************************************************
 *
 **********************************************************************/
    void
putrequestfailed(Session *sess)
{
    /* gerror("putrequestfailed \n"); */

    sess->outp << (char) FAILFLAG;
}

/**********************************************************************
 *
 **********************************************************************/
    bool
putxaccount(Session *sess)
{
    sess->outp << XACCOUNT << (char) WORDELIM;
    return true;
}

/**********************************************************************
 *
 **********************************************************************/
    bool
putcreatenode_or_account(Session *sess, Tumbler *tp)
{
    sess->outp << CREATENODE_OR_ACCOUNT << (char) WORDELIM;
    sess->outp << *tp;
    return true;
}

/**********************************************************************
 *
 **********************************************************************/
    bool
putopen(Session *sess, Tumbler *tp)
{
    sess->outp << OPEN << (char) WORDELIM;
    sess->outp << *tp;
    return true;
}

/**********************************************************************
 *
 **********************************************************************/
    bool
putclose(Session *sess)
{
    sess->outp << CLOSE << (char) WORDELIM;
    return true;
}

/**********************************************************************
 *
 **********************************************************************/
    bool
putquitxanadu(Session *sess)
{
    sess->outp << QUIT << (char) WORDELIM;
    return true;
}

/**********************************************************************
 *  Original Copyright � 1979-1999 Udanax.com.   All Rights Reserved
 **********************************************************************/
