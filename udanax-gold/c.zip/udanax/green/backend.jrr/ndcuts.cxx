/**
 * @file  ndcuts.cxx
 * @brief ???
 *
 * (to be defined)
 *
 **/

#include <nana/nana.h>  // GNU Assertion/Logging Tool

#include "xanadu.h"
#include "enf.h"
#include "ndenf.h"
#include "players.h"
#include "knives.h"

static void peeloffcorrectson(CoreUpperCrum *ptr, Knives *knives);
static void newpeelcrumoffnd(CoreCrum *ptr, CoreUpperCrum *newuncle);
static void makeithcutonson(CoreUpperCrum *ptr, Displacer *offset, CoreCrum *son, Displacer *grasp, Knives *knives, int i);
static bool crumiscut(CoreUpperCrum *ptr, Displacer *offset, Knives *knives);
static void makecutsbackuptohere(CoreUpperCrum *ptr, Displacer *offset, Knives *knives);
static void peelsoncorrectly(CoreCrum *ptr, Displacer *offset, CoreCrum *son, Displacer *grasp, Knives *knives, int i);
static void makecutsdownnd(CoreUpperCrum *fullcrumptr, Displacer *offset, Knives *knives);
static bool crumleftofithcut(CoreCrum *ptr, Displacer *offset, Knives *knives, int i);

/**********************************************************************
 *
 **********************************************************************/
    static bool
sonsarecut(CoreUpperCrum *ptr, Displacer *offset, Knives *knives)
{
    CoreUpperCrum *son;
    Displacer grasp;

    prologuend(ptr, offset, &grasp, NULL);
    for (son = (CoreUpperCrum *) ptr->leftSon(); son; son = (CoreUpperCrum *) son->rightBrother()) {
        if (crumiscut(son, &grasp, knives))
            return true;
    }

    return false;
}

/**********************************************************************
 *
 **********************************************************************/
    static void
cutsons(CoreUpperCrum *ptr, Displacer *offset, Knives *knives)
{
    Displacer  grasp;
    CoreCrum  *son, *nextson;

    while (sonsarecut(ptr, offset, knives)) {
        /**/ setwispupwards(ptr, 1); /**/

        for (son = ptr->leftSon(); son; son = nextson) {
            nextson = son->rightBrother();
            prologuend(ptr, offset, &grasp, NULL);
            for (; crumiscut((CoreUpperCrum *) son, &grasp, knives);
                          prologuend(ptr, offset, &grasp, NULL)) {

                makecutsbackuptohere((CoreUpperCrum *) son, &grasp, knives);
            }
        }
    }
}

/**********************************************************************
 *
 **********************************************************************/
    static void
slicecbcpm(CoreCrum *ptr, Displacer *offset, CoreCrum *newcrum, Tumbler *cut, int index)
{
    Displacer grasp /*, reach */;
    Tumbler localcut;
    int i;

    int enftype = ptr->cenftype;

    prologuend(ptr, offset, &grasp, /* &reach */ NULL);
    if (whereoncrum(ptr, offset, cut, index) != THRUME)
        gerror("Why are you trying to slice me?\n");

    if (!lockis1story(&ptr->cwid[0], (unsigned) widsize(enftype)))
        gerror("Not one story in POOM wid\n");

//    tumblersub(cut, &grasp[index], &localcut);
    localcut = *cut - grasp[index];

    if (localcut.exp != ptr->cwid[index].exp) {
        dump(ptr);
        dump(newcrum);
        cerr << *cut;
        cerr << localcut;
        dumpwholetree(ptr);
        gerror("Oh well, I thought I understood this1\n");
    }

    I(is1story(&localcut));
    I(tumblerlength(cut) == tumblerlength(&ptr->cwid[index]));

//    movewid(&ptr->cwid, &newwid); // Move a WISP
    Widener newwid = ptr->cwid;

    for (i = 0; i < widsize(enftype); i++) { /* I really don't understand this loop */
        newwid[i].mantissa[0] = localcut.mantissa[0];
        tumblerjustify(&newwid[i]);
    }

    /* locksubtract(&ptr->cwid, &newwid, &new->cwid, widsize(enftype)); */

//    locksubtract((Tumbler *) &ptr->cwid, (Tumbler *) &newwid, (Tumbler *) &newcrum->cwid, (unsigned) widsize(enftype));
    newcrum->cwid = sub(ptr->cwid, newwid, enftype);


//    movewid(&newwid, &ptr->cwid); // Move a WISP
    ptr->cwid = newwid;

//    dspadd(&ptr->cdsp, static_cast<Displacer*>(static_cast<Wisp*>(&ptr->cwid)), &newcrum->cdsp, enftype);
    newcrum->cdsp = add(ptr->cdsp, ptr->cwid, enftype);

//    move2dinfo(&((Core2dBottomCrum *) ptr)->c2dinfo, &((Core2dBottomCrum *) newcrum)->c2dinfo);
    ((Core2dBottomCrum *) newcrum)->c2dinfo = ((Core2dBottomCrum *) ptr)->c2dinfo;

    ptr->adoptAsRightBrother(newcrum);
}

/**********************************************************************
 *
 **********************************************************************/
    static bool
crumiscut(CoreUpperCrum *ptr, Displacer *offset, Knives *knives)
{
    int i;

    for (i = 0; i < knives->nblades; ++i) {
        if (whereoncrum((CoreCrum *) ptr, offset, &knives->blade[i], knives->dimension) == THRUME)
            return true;
    }

    return false;
}

/**********************************************************************
 *
 **********************************************************************/
    static bool
crumiscutbyithknife(CoreUpperCrum *ptr, Displacer *offset, Knives *knives, int i)
{
    if (whereoncrum((CoreCrum *) ptr, offset, &knives->blade[i], knives->dimension) == THRUME)
        return true;

    return false;
}

/**********************************************************************
 *
 **********************************************************************/
    static void
makecutsbackuptohere(CoreUpperCrum *ptr, Displacer *offset, Knives *knives)
{
    Displacer grasp;
    int i;
    CoreUpperCrum  *son, *newcuc, *nextson;

    if (ptr->height == 0) {
        for (i = 0; i < knives->nblades; i++) {
            if (whereoncrum(ptr, offset, &knives->blade[i], knives->dimension) == THRUME) {
                newcuc = (CoreUpperCrum *) ((Enfilade *) ptr)->createCrum((int) ptr->height, (int) ptr->cenftype);

                if (ptr->cenftype == GRAN)
                    ((CoreBottomCrum *) newcuc)->cinfo.infotype = ((CoreBottomCrum *) ptr)->cinfo.infotype;

                slicecbcpm((CoreCrum *) ptr, offset, (CoreCrum *) newcuc, &knives->blade[i], knives->dimension);
                ptr->ivemodified();
                newcuc->ivemodified();
                /**/ setwisp((CoreCrum *) ptr); /**/

                /* asserttreeisok(ptr); */
            }
        }
        return;

    } else {
        for (i = 0; i < knives->nblades; ++i) {
            cutsons(ptr, offset, knives);

            if (!ptr->isTopmost()) {
                /**/ setwispupwards(ptr, 0); /**/

                if (crumiscutbyithknife(ptr, offset, knives, i)) {
                    for (son = (CoreUpperCrum *) ptr->leftSon(); son; son = nextson) {
                        nextson = (CoreUpperCrum *) son->rightBrother();
                        prologuend(ptr, offset, &grasp, NULL);

                        makeithcutonson(ptr, offset, (CoreCrum *) son, &grasp, knives, i);

                        if (!crumiscutbyithknife(ptr, offset, knives, i)) {
                            if (ptr->numberofsons == 0)
                                return;
                            break;
                        }
                    }
                }
                setwispupwards(ptr, 0);
            }
        }
    }

    if (!ptr->isTopmost()) {
        if (ptr->toomanysons()) {
            while (ptr->toomanysons()) {
                setwispupwards(ptr, 0);
                peeloffcorrectson(ptr, knives);
            }

            makecutsbackuptohere(ptr, offset, knives);
        }

    } else if (ptr->toomanysons())
        cerr << "________________toomanysons in fullcrum" << endl;

    setwispupwards(ptr, 1);
}

/**********************************************************************
 *
 **********************************************************************/
    void
makecutsnd(CoreUpperCrum *fullcrumptr, Knives *knives)
{
    logbertmodifiedforcrum(fullcrumptr, user);

    Displacer offset;
    memset(&offset, 0, sizeof(offset));

    makecutsdownnd(fullcrumptr, &offset, knives);
    memset(&offset, 0, sizeof(offset));  /* clears ARE redundant */

    for (fullcrumptr = fullcrumptr->topmost(); sonsarecut(fullcrumptr, &offset, knives); fullcrumptr = fullcrumptr->topmost()) {
        memset(&offset, 0, sizeof(offset));
        makecutsdownnd(fullcrumptr, &offset, knives);
    }
}

/**********************************************************************
 *
 **********************************************************************/
    static void
makecutsdownnd(CoreUpperCrum *fullcrumptr, Displacer *offset, Knives *knives)
{
    CoreCrum  *sonptr, *son;
    int n;

    CoreUpperCrum *ptr = fullcrumptr;
    for (; knives->nblades > 1 && false && ptr->height; ) {
        for (n = 0, son = ptr->leftSon(); son; son = son->rightBrother()) {
            if (crumiscut((CoreUpperCrum *) son, offset, knives)) {
                n++;
                sonptr = son;
            }
        }

        if (n == 1) {
            prologuend(ptr, offset, offset, NULL);
            ptr = (CoreUpperCrum *) sonptr;
        } else
            break;

    } /* now we're at intersection */

    makecutsbackuptohere(ptr, offset, knives);
    if (ptr->toomanysons()) {

        if (ptr->isTopmost())
            levelpush(ptr);

        makecutsnd(fullcrumptr, knives);
    }
}

/**********************************************************************
 *
 **********************************************************************/
    static void
makeithcutonson(CoreUpperCrum *ptr, Displacer *offset, CoreCrum *son, Displacer *grasp, Knives *knives, int i)
{
    if (!crumiscutbyithknife((CoreUpperCrum *) ptr, offset, knives, i))
        return;

    int temp;
    if ((temp = whereoncrum(son, grasp, &knives->blade[i], knives->dimension)) < THRUME) {
        peelsoncorrectly(ptr, offset, son, grasp, knives, i);

        /**/ setwispupwards((CoreUpperCrum *) ptr, 1); /**/

        if (!crumiscutbyithknife((CoreUpperCrum *) ptr, offset, knives, i )) {
            /**/ setwispupwards((CoreUpperCrum *) ptr, 1); /**/

            /* prologuend(ptr, offset, grasp, NULL); */
            if (((CoreUpperCrum *) ptr)->numberofsons == 0)
                return;
            return;
        }

        ptr->leftSon(); /* make sure its in core*/
        if (((CoreUpperCrum *) ptr)->numberofsons == 0)
            I(false); // sons went away

    } else
        I(temp != THRUME); // makecutsbackuptohere crum not cut
}

/**********************************************************************
 *
 **********************************************************************/
    static void
peelsoncorrectly(CoreCrum *ptr, Displacer *offset, CoreCrum *son, Displacer *grasp, Knives *knives, int i)
{  /* put son in leftest uncle with room that  is less than cut*/
    CoreUpperCrum *uncle = (CoreUpperCrum *) ptr->leftmostBrother();
    for (; uncle; uncle = (CoreUpperCrum *) uncle->rightBrother()) {
        if (uncle == (CoreUpperCrum *) ptr)
            continue;

        if (uncle->roomformoresons()) {
            if (crumleftofithcut((CoreCrum *) uncle, offset, knives, i)) {
                newpeelcrumoffnd(son, uncle);
                return;
            }
        }
    }

    uncle = (CoreUpperCrum *) ((Enfilade *) uncle)->createCrum(ptr->height, ptr->cenftype);
    ptr->rightmostBrother()->adoptAsRightBrother(uncle);

    uncle->cdsp = ptr->cdsp; // Move a DSP/WISP

    newpeelcrumoffnd(son, uncle);
}

/**********************************************************************
 *
 **********************************************************************/
    static bool
crumleftofithcut(CoreCrum *ptr, Displacer *offset, Knives *knives, int i)
{
    if (whereoncrum(ptr, offset, &knives->blade[i], knives->dimension) > THRUME)
        return false;
    else
        return true;
}

/**********************************************************************
 *
 **********************************************************************/
    static void
peeloffcorrectson(CoreUpperCrum *ptr, Knives *knives)
{
    CoreUpperCrum *bro, *uncle;

    if (ptr->toomanysons()) {
        for (bro = ptr->rightBrother(); bro; ptr = ptr->rightBrother()) {
            if (bro->roomformoresons()) {
                newpeelcrumoffnd(ptr->leftSon(), bro);
                return;
            }
        }

        uncle = (CoreUpperCrum *) ((Enfilade *) ptr)->createCrum(ptr->height, ptr->cenftype);
        ptr->adoptAsRightBrother(uncle);

//        movedsp(&ptr->cdsp, &uncle->cdsp); // Move a WISP
        uncle->cdsp = ptr->cdsp; // Move a DSP/WISP

        newpeelcrumoffnd( ptr->leftSon(), uncle);
    }
}

/**********************************************************************
 *
 **********************************************************************/
    static void
newpeelcrumoffnd(CoreCrum *ptr, CoreUpperCrum *newuncle)
{
    CoreUpperCrum  *father;
    Displacer   temp, grasp, offset;
    Displacer origin;

    I(newuncle->roomformoresons());
    I(!ptr->isTopmost());

    ptr->ivemodified(); /* to set father->modified */
    father = ptr->father();
    memset(&offset, 0, sizeof(offset));

//    dspadd(&father->cdsp, &ptr->cdsp, &origin, (int) father->cenftype);
    origin = add(father->cdsp, ptr->cdsp, father->cenftype);

    /* 1 ptr->cdsp */

    tumblercheckptr((Tumbler *) &origin, (int *) ptr);

    makeroomonleftnd((CoreUpperCrum *) newuncle, &offset, &origin, &grasp);
    ptr->disown();
    newuncle->adoptAsLeftmostSon(ptr);

    /*
     * // dspsub(&father->cdsp, &newuncle->cdsp, &temp, ptr->cenftype);
     * temp = sub(father->cdsp, newuncle->cdsp, ptr->cenftype);
     */

    /* 2 &temp <- father->cdsp - newuncle->cdsp check this father temp stuff4/6/85 */

//    dspadd(&father->cdsp, &ptr->cdsp, &temp, (int) ptr->cenftype);
    temp = add(father->cdsp, ptr->cdsp, ptr->cenftype);

    tumblercheckptr((Tumbler *) &temp, (int *) ptr);

    /*
     * dspadd(&ptr->cdsp, &temp, &ptr->cdsp, ptr->cenftype);
     * ptr->cdsp = add(ptr->cdsp, temp, ptr->cenftype);
     */

//    dspsub(&temp, &newuncle->cdsp, &ptr->cdsp, (int) ptr->cenftype);
    ptr->cdsp = sub(temp, newuncle->cdsp, ptr->cenftype);

    /* 3 ptr->cdsp  <- temp + ptr->cdsp */

    tumblercheckptr((Tumbler *) &ptr->cdsp, (int *) ptr);

    ptr->ivemodified();
    newuncle->ivemodified();

    /* setwispsofsons(newuncle); // to fix makeroomonleftnd // */
    setwispupwards((CoreUpperCrum *) ptr, 0);
    setwispupwards((CoreUpperCrum *) newuncle, 0);
    setwispupwards(father, 1);

    I(!newuncle->toomanysons());
}

/**********************************************************************
 *  Original Copyright � 1979-1999 Udanax.com.   All Rights Reserved
 **********************************************************************/
