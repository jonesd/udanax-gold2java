/**
 * @file  get1fe.cxx
 * @brief Top-Level Input Routines -- Front-End Version
 *
 * (to be defined)
 *
 **/

#include <fstream>
#include <iostream>
#include <nana/nana.h>  // GNU Assertion/Logging Tool

#include "xanadu.h"
#include "requests.h"
#include "alloc.h"

extern FILE *logfile;
extern FILE *nulllog;
extern FILE *reallog;
extern bool logstuff;

//extern FILE *interfaceinput;
extern ifstream interfaceinput;

/**********************************************************************
 *
 **********************************************************************/
    bool
getinsert(Session *sess, IStreamAddr *docisaptr, VStreamAddr *vsaptr, typetextset *textsetptr)
{
    /* logfile = reallog;
     * fprintf(logfile, "\nINSERT\n");
     */

    logstuff = true;
//    interfaceinput << INSERT << '~';

    return gettumbler(sess, docisaptr) && gettumbler(sess, vsaptr) && gettextset(sess, textsetptr);

    /*
     * if (!gettumbler(sess, docisaptr))
     *     return false;
     *
     * cerr << endl << "docid  " << *docisaptr;
     *
     * if (!gettumbler(sess, vsaptr))
     *     return false;
     *
     * cerr << endl << "vsa  " << *vsaptr << endl;
     *
     * if (!gettextset(sess, textsetptr))
     *     return false;
     *
     * return true;
     */
}

/**********************************************************************
 *
 **********************************************************************/
    bool
getretrievedocvspanset(Session *sess, IStreamAddr *docisaptr)
{
    /* fprintf(logfile, "\nRETRIEVEDOCVSPANSET\n"); */

    return gettumbler(sess, docisaptr);
}

/**********************************************************************
 *
 **********************************************************************/
    bool
getcopy(Session *sess, IStreamAddr *docisaptr, VStreamAddr *vsaptr, typespecset *localspecsetptr)
{
    /* logfile = reallog; fprintf(logfile, "\nCOPY\n"); */

    logstuff = true;
//    interfaceinput << COPY << '~';

    return gettumbler(sess, docisaptr) && gettumbler(sess, vsaptr) && getspecset(sess, localspecsetptr);
}

/**********************************************************************
 *
 **********************************************************************/
    bool
getrearrange(Session *sess, IStreamAddr *docisaptr, typecutseq *cutseqptr)
{
    /* logfile = reallog; fprintf(logfile, "\nREARRANGE\n"); */

    logstuff = true;
//    interfaceinput << REARRANGE << '~';

    return gettumbler(sess, docisaptr) && getcutseq(sess, cutseqptr);
}

/**********************************************************************
 *
 **********************************************************************/
    bool
getcreatelink(Session *sess, IStreamAddr *docisaptr, typespecset *fromspecsetptr, typespecset *tospecsetptr, typespecset *threespecsetptr)
{
    logstuff = true;
//    interfaceinput << CREATELINK << '~';

    return gettumbler(sess, docisaptr)
        && getspecset(sess, fromspecsetptr)
        && getspecset(sess, tospecsetptr)
        && getspecset(sess, threespecsetptr);
}

/**********************************************************************
 *
 **********************************************************************/
    bool
getretrievev(Session *sess, typespecset *specsetptr)
{
    /* fprintf(logfile, "\nRETRIEVEV\n"); */

    if (getspecset(sess, specsetptr))
        return true;
    else
        return false;
}

/**********************************************************************
 *
 **********************************************************************/
    bool
getfindnumoflinksfromtothree(Session *sess, typespecset *fromvspecsetptr, typespecset *tovspecsetptr, typespecset *threevspecsetptr, typeispanset *homesetptr)
{
    return getfindlinksfromtothree(sess, fromvspecsetptr, tovspecsetptr, threevspecsetptr, homesetptr);
}

/**********************************************************************
 *
 **********************************************************************/
    bool
getfindlinksfromtothree(Session *sess, typespecset *fromvspecsetptr, typespecset *tovspecsetptr, typespecset *threevspecsetptr, typeispanset *homesetptr)
{
    return getspecset(sess, fromvspecsetptr) && getspecset(sess, tovspecsetptr) && getspecset(sess, threevspecsetptr) && getspanset(sess, homesetptr, ISPANID) && kluge();
}

/**********************************************************************
 *
 **********************************************************************/
    bool
getfindnextnlinksfromtothree(Session *sess, typespecset *fromvspecsetptr, typespecset *tovspecsetptr,
    typespecset *threevspecsetptr, typeispanset *homesetptr, IStreamAddr *lastlinkptr, int *nptr)
{
    return getfindlinksfromtothree(sess, fromvspecsetptr, tovspecsetptr, threevspecsetptr, homesetptr)
           && gettumbler(sess, lastlinkptr) && getnumber(sess, nptr);
}

/**********************************************************************
 *
 **********************************************************************/
    bool
getshowrelationof2versions(Session *sess, typespecset *version1ptr, typespecset *version2ptr)
{
    return getspecset(sess, version1ptr) && getspecset(sess, version2ptr);
}

/**********************************************************************
 *
 **********************************************************************/
/* createnewdocument - no get routine */
    void
getcreatenewdocument()
{
    logstuff = true;
//    interfaceinput << CREATENEWDOCUMENT << '~';
}

/**********************************************************************
 *
 **********************************************************************/
    bool
getdeletevspan(Session *sess, IStreamAddr *docisaptr, typevspan *vspanptr)
{
    /* logfile = reallog; fprintf(logfile, "\nDELETEVSPAN\n"); */

    logstuff = true;
//    interfaceinput << DELETEVSPAN << '~';

    return gettumbler(sess, docisaptr) && getspan(sess, vspanptr, VSPANID);
}

/**********************************************************************
 *
 **********************************************************************/
    bool
getcreatenewversion(Session *sess, IStreamAddr *docisaptr)
{
    /* logfile = reallog; fprintf(logfile, "\nCREATENEWVERSION\n"); */

    logstuff = true;
//    interfaceinput << CREATENEWVERSION << '~';

    return gettumbler(sess, docisaptr);
}

/**********************************************************************
 *
 **********************************************************************/
    bool
getretrievedocvspan(Session *sess, IStreamAddr *docisaptr)
{
    /* fprintf(logfile, "\nRETRIEVEDOCVSPAN\n"); */

    return gettumbler(sess, docisaptr);
}

/**********************************************************************
 *
 **********************************************************************/
    bool
setdebug(Session *sess)
{
    return getnumber(sess, &debug);
}

/* disk exit */

/* show enfilades */

/**********************************************************************
 *
 **********************************************************************/
    bool
getfollowlink(Session *sess, IStreamAddr *linkisaptr, int *whichendptr)
{
    /* fprintf(logfile, "\nFOLLOWLINK\n"); */

    return getnumber(sess, whichendptr) && gettumbler(sess, linkisaptr);
}

/* examine */

/* source unix command */

/**********************************************************************
 *
 **********************************************************************/
    bool
getfinddocscontaining(Session *sess, typespecset *specsetptr)
{
    /* fprintf(logfile, "\nFINDDOCSCONTAINING\n"); */

    return getspecset(sess, specsetptr);
}

/**********************************************************************
 *
 **********************************************************************/
    bool
getretrieveendsets(Session *sess, typespecset *specsetptr)
{
    /*
     * fprintf(logfile, "\nRETRIEVEENDSETS\n");
     */

    return getspecset(sess, specsetptr);
}

/**********************************************************************
 *
 **********************************************************************/
    bool
kluge()
{
    /*
     * fclose(reallog);
     * reallog = fopen("xueditlog", "a");
     */

    return true;
}

/**********************************************************************
 *
 **********************************************************************/
    void
playwithalloc(Session *sess)
{
    prompt(sess, "playwithalloc\n");
    lookatalloc();
}

#include "players.h"

/**********************************************************************
 *
 **********************************************************************/
    bool
getxaccount(Session *sess, IStreamAddr *accountptr)
{
    logstuff = true;
//    if (interfaceinput.good())
//        interfaceinput << XACCOUNT << '~';

    gettumbler(sess, accountptr) && validaccount(sess, accountptr);

    player[user].account = *accountptr;
    sess->account = *accountptr;

    return true;
}

/**********************************************************************
 *
 **********************************************************************/
    bool
getcreatenode_or_account(Session *sess, Tumbler *tp)
{
    logstuff = true;
//    if (interfaceinput.good())
//        interfaceinput << CREATENODE_OR_ACCOUNT << '~';

    gettumbler(sess, tp);

    return true;
}

/**********************************************************************
 *
 **********************************************************************/
    void
logaccount(Tumbler *tp)
{
//    if (interfaceinput.good())
//        interfaceinput << XACCOUNT << '~' << *tp;
}

/**********************************************************************
 *
 **********************************************************************/
    bool
getclose(Session *sess, Tumbler *tp)
{
    logstuff = true;
//    if (interfaceinput.good())
//        interfaceinput << CLOSE << '~';

    gettumbler(sess, tp);
    return true;
}

/**********************************************************************
 *
 **********************************************************************/
    bool
getopen(Session *sess, Tumbler *tp, int *typep, int *modep)
{
    logstuff = true;
//    if (interfaceinput.good())
//        interfaceinput << OPEN << '~';

    gettumbler(sess, tp);
    getnumber(sess, typep);
    getnumber(sess, modep);

    return *typep != NOBERTREQUIRED;
}

/* historical trace */

/**********************************************************************
 *  Original Copyright � 1979-1999 Udanax.com.   All Rights Reserved
 **********************************************************************/
