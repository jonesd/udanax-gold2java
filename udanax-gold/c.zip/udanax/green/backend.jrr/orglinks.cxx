/**
 * @file  orglinks.cxx
 * @brief Permutation Matrix Enfilade Calls, Link-Following Included
 *
 * (to be defined)
 *
 **/

#include <nana/nana.h>  // GNU Assertion/Logging Tool

#include "xanadu.h"
#include "enf.h"
#include "players.h"
#include "ndenf.h"
#include "coredisk.h"

static void findnextaddressinvspace(CoreUpperCrum *crumptr, Displacer *offsetptr, Tumbler *nextvspacestartptr, VStreamAddr *vsaptr);
static void findvsatoappend(CoreUpperCrum *ptr, VStreamAddr *vsaptr);
static void maxtextwid(Session *sess, CoreUpperCrum *crumptr, StreamDiff *voffset, typevspanset *maxwidptr);

/**********************************************************************
 *   Append Permutation Matrix
 **********************************************************************/
    bool
appendpm(Session *sess, IStreamAddr *docisaptr, typetextset textset)
{
    typeorgl orglptr;
    if (!findorgl(sess, granf, docisaptr, &orglptr, WRITEBERT))
        return false;

    VStreamAddr vsa;
    findvsatoappend((CoreUpperCrum *) orglptr, &vsa);

    return doinsert(sess, docisaptr, &vsa, textset);
}

/**********************************************************************
 *  Find Virtual Stream Address to Append
 **********************************************************************/
    static void
findvsatoappend(CoreUpperCrum *ptr, VStreamAddr *vsaptr)
{
    Displacer offset;
    memset(&offset, 0, sizeof(offset));

    vsaptr->clear();

    Tumbler linkspacevstart(0);

//    tumblerincrement(&linkspacevstart, 0, 2, &linkspacevstart);
    linkspacevstart = linkspacevstart.increment(0, 2);

    Displacer grasp, reach;
    prologuend(ptr, &offset, &grasp, &reach);

    if (ptr->cwid.isEmpty(widsize(POOM)) || grasp[V_BASIS] < linkspacevstart) {

//        tumblerincrement(vsaptr, 0, 1, vsaptr); /* no text in doc */
        *vsaptr = vsaptr->increment(0, 1);

//        tumblerincrement(vsaptr, 1, 1, vsaptr);
        *vsaptr = vsaptr->increment(1, 1);

    } else if (reach[V_BASIS] < linkspacevstart)
        *vsaptr = reach[V_BASIS]; // no links in doc

    else
        findnextaddressinvspace(ptr, &grasp, &linkspacevstart, vsaptr);
}

/**********************************************************************
 * Find Next Address in Virtual Stream Space
 **********************************************************************/
    static void
findnextaddressinvspace(CoreUpperCrum *crumptr, Displacer *offsetptr, Tumbler *nextvspacestartptr, VStreamAddr *vsaptr)
{
    CoreUpperCrum *ptr = (CoreUpperCrum *) crumptr->leftSon();
    if (ptr == NULL)
        return;

    VStreamAddr maxt;
    maxt.clear();

    for (; ptr; ptr = ptr->rightBrother()) {
        Displacer reach, grasp;
        prologuend(ptr, offsetptr, &grasp, &reach);
        if (whereoncrum(ptr, offsetptr, nextvspacestartptr, V_BASIS) == THRUME) {
            findnextaddressinvspace(ptr, &grasp, nextvspacestartptr, vsaptr);
            return;

        } else if (grasp[V_BASIS] > *nextvspacestartptr)
            maxt = max(reach[V_BASIS], maxt);
//            tumblermax(&reach[V_BASIS], &maxt, &maxt);
    }

    *vsaptr = maxt;
}

/**********************************************************************
 * Insert Permutation Matrix
 **********************************************************************/
    bool
insertpm(Session *sess, Tumbler *orglisa, typeorgl orgl, VStreamAddr *vsaptr, typesporglset sporglset)
{
    if (vsaptr->iszero())
        return false;

    if (*vsaptr < Tumbler::zero)
        gerror("insertpm called with negative vsa.\n");

    logbertmodified(orglisa, user);
//    for (; sporglset; sporglset = (typesporglset) ((typesporgl *) sporglset)->xxxxsporgl.next) {
    for (; sporglset; sporglset = (typesporglset) ((typesporgl *) sporglset)->next) {

        StreamAddr lstream;
	StreamDiff lwidth;
        Core2dBottomCrum::type2dbottomcruminfo linfo;
        unpacksporgl(sporglset, &lstream, &lwidth, &linfo);

        Displacer crumorigin;
        crumorigin[I_BASIS] = lstream;
        crumorigin[V_BASIS] = *vsaptr;

        Widener crumwidth;
        crumwidth[I_BASIS]  = lwidth;

        /* I'm suspicious of this shift <reg> 3/1/85 zzzz */
        int shift = tumblerlength(vsaptr) - 1;
        int inc = tumblerintdiff(&lwidth, &Tumbler::zero);

//        tumblerincrement(&Tumbler::zero, shift, inc, &crumwidth[V_BASIS]);
        crumwidth[V_BASIS] = Tumbler::zero.increment(shift, inc);

        I(!crumwidth[V_BASIS].iszero());

        ((Enfilade2d *) orgl)->insertnd((Session *) sess, &crumorigin, &crumwidth, &linfo, V_BASIS);

        *vsaptr = *vsaptr + crumwidth[V_BASIS];
    }

    return true;
}

/**********************************************************************
 * Rearrange Permutation Matrix
 **********************************************************************/
    bool
rearrangepm(Session *sess, Tumbler *docisaptr, typeorgl docorgl, typecutseq *cutseqptr)
{
    rearrangend((CoreUpperCrum *) docorgl, cutseqptr, V_BASIS);
    logbertmodified(docisaptr, user);

    return true;
}

/**********************************************************************
 *
 **********************************************************************/
    bool
deletevspanpm(Session *sess, Tumbler *docisaptr, typeorgl docorgl, typevspan *vspanptr)
{
    if (vspanptr->width.iszero())
        return false;

    deletend((CoreUpperCrum *) docorgl, &vspanptr->stream, &vspanptr->width, V_BASIS);
    logbertmodified(docisaptr, user);

    return true;
}

/**********************************************************************
 *
 **********************************************************************/
    bool
retrievedocumentpartofvspanpm(Session *sess, typeorgl orgl, typevspan *vspanptr)
{ /* this is a kluge*/

    vspanptr->next = NULL;
    vspanptr->itemid = VSPANID;

//    movetumbler(&((CoreUpperCrum *) orgl)->cdsp[V_BASIS], &vspanptr->stream);
    vspanptr->stream = ((CoreUpperCrum *) orgl)->cdsp[V_BASIS];

//    movetumbler(&((CoreUpperCrum *) orgl)->cwid[V_BASIS], &vspanptr->width);
    vspanptr->width = ((CoreUpperCrum *) orgl)->cwid[V_BASIS];

    return true;
}

/**********************************************************************
 *
 **********************************************************************/
    bool
retrievevspanpm(Session *sess, typeorgl orgl, typevspan *vspanptr)
{
    vspanptr->next = NULL;
    vspanptr->itemid = VSPANID;

//    movetumbler(&((CoreUpperCrum *) orgl)->cdsp[V_BASIS], &vspanptr->stream);
    vspanptr->stream  = ((CoreUpperCrum *) orgl)->cdsp[V_BASIS];

//    movetumbler(&((CoreUpperCrum *) orgl)->cwid[V_BASIS], &vspanptr->width);
    vspanptr->width = ((CoreUpperCrum *) orgl)->cwid[V_BASIS];

    return true;
}

/**********************************************************************
 *
 **********************************************************************/
    bool
retrievevspansetpm(Session *sess, typeorgl orgl, typevspanset *vspansetptr)/* return spans  for doc and link part */
{
    StreamDiff     voffset;
    Tumbler        maxwid;
    typevspan      vspan;
    typevspan      linkvspan;
    CoreUpperCrum  *ccptr = (CoreUpperCrum *) orgl;
    voffset.clear();
    *vspansetptr = NULL;

    if (is1story(&ccptr->cwid[V_BASIS])) { /* if it is  just text return that */
        vspan.itemid = VSPANID;
//        movetumbler(&ccptr->cdsp[V_BASIS], &vspan.stream);
        vspan.stream = ccptr->cdsp[V_BASIS];

//        movetumbler(&ccptr->cwid[V_BASIS], &vspan.width);
        vspan.width = ccptr->cwid[V_BASIS];

        vspan.next = NULL;
        putvspaninlist(sess, &vspan, vspansetptr);
        return true;

    } else {
        /* the link part is simple, just grab the last  digit off the wid */
        /* the text part we get from a max function that delves into the crums*/
        /*  in both cases we have to remove the first digit of the tumbler, the 1 and hack it around a bit. */

        linkvspan.itemid = VSPANID;

//////////////////////////////FIXME
        linkvspan.stream = ccptr->cdsp[V_BASIS]; // was commented out originally
//        linkvspan.stream = ccptr->cwid[V_BASIS];    (was in program)
//////////////////////////////FIXME

        linkvspan.stream.mantissa[1] = 0;
        tumblerjustify(&linkvspan.stream);

        linkvspan.width = ccptr->cwid[V_BASIS];

        linkvspan.width.mantissa[1] = 0;
        tumblerjustify(&linkvspan.width);
        linkvspan.next = NULL;

        maxtextwid(sess, ccptr, &voffset, (typevspanset *) &maxwid);
        vspan.itemid = VSPANID;
        vspan.stream.clear();

//        movetumbler(&maxwid, &vspan.width);
        vspan.width = maxwid;

        vspan.width.mantissa[0] = 0;
        vspan.next = NULL;

        /* dumptumbler(&vspan.stream);
         * dumptumbler(&vspan.width);
         */

        putvspaninlist(sess, &vspan, vspansetptr);
        putvspaninlist(sess, &linkvspan, vspansetptr);

        return true;
    }
}

/**********************************************************************
 *
 **********************************************************************/
    static void
maxtextwid(Session *sess, CoreUpperCrum *crumptr, StreamDiff *voffset, typevspanset *maxwidptr)
{
    I(crumptr != NULL);

    if (crumptr->isTextCrum()) {
///////////////////////////////////////FIXME
//        StreamAddr tmpwid = *voffset + crumptr->cdsp[V_BASIS];  //illegal addition of two addresses
        StreamAddr tmpwid = crumptr->cdsp[V_BASIS];
///////////////////////////////////////FIXME

//        tumblermax(&tmpwid, (Tumbler *) maxwidptr, (Tumbler *) maxwidptr);
        * (Tumbler *) maxwidptr = greater(tmpwid, * (Tumbler *) maxwidptr);

    } else {
///////////////////////////////////////FIXME
//        VStreamOffset localvoffset = *voffset + crumptr->cdsp[V_BASIS]; //illegal addition of addr/off into offset
        StreamDiff localvoffset = *voffset;
///////////////////////////////////////FIXME

        CoreUpperCrum *ptr;
        for (ptr = (CoreUpperCrum *) crumptr->leftSon(); ptr; ptr = ptr->rightBrother()) {
            if (ptr && !ptr->isLinkCrum()) { /* only look for text or overlapping stuff */
                maxtextwid(sess, ptr, &localvoffset, maxwidptr);
            }
        }
    }
}

/**********************************************************************
 *
 **********************************************************************/
#ifdef UnDEFined
    bool
retrievevspansetpm(Session *sess, typeorgl orgl, typevspanset *vspansetptr) /* return spans  for doc and link part */
{
    Tumbler voffset;

    voffset.clear();

    *vspansetptr = NULL;
    walkorglonvpm(sess, (CoreCrum *) orgl, &voffset, vspansetptr);
    cleanupvspanlist(sess, vspansetptr);

    return true;
}

/**********************************************************************
 *
 **********************************************************************/
    void
walkorglonvpm(Session *sess, CoreCrum *crumptr, VStreamAddr *voffset, typevspanset *vspansetptr)
{
    if (is1story(&crumptr->cwid[V_BASIS])) {
        typevspan vspan;
	
	vspan.itemid = VSPANID;
        vspan.stream = *voffset + crumptr->cdsp[V_BASIS];

        vspan.width = crumptr->cwid[V];

        vspan.next = NULL;
        putvspaninlist(sess, &vspan, vspansetptr);

    } else {
        VStreamAddr = *voffset + crumptr->cdsp[V_BASIS];

        CoreCrum *ptr;
        for(ptr = crumptr->leftSon(); ptr; ptr = ptr->rightBrother())
            walkorglonvpm(sess, ptr, &localvoffset, vspansetptr);
    }
}

/**********************************************************************
 *
 **********************************************************************/
    void
cleanupvspanlist(Session *sess, typevspanset *vspansetptr)
{
    typevspan *ptr = *vspansetptr;

    if (!ptr)
        return;

    for (; ptr && ptr->next; ptr = ptr->next) {
        StreamAddr spanend = ptr->stream + ptr->width;

        if (spanend == ptr->next->stream)) {
            ptr->width = ptr->width + ptr->next->width;
            ptr->next  = ptr->next->next;
        }
    }
}
#endif

/**********************************************************************
 *
 **********************************************************************/
    typevspan *
makevspan(Session *sess, typevspan *spanptr, typevspan *nextspan)
{
    typevspan *ret = (typevspan *) taskalloc(sess, sizeof(typevspan));

    ret->stream = spanptr->stream;
    ret->width  = spanptr->width;

    ret->itemid = VSPANID;
    ret->next   = nextspan;

    return ret;
}

/**********************************************************************
 *
 **********************************************************************/
    void
putvspaninlist(Session *sess, typevspan *spanptr, typevspanset *spansetptr)
{
    typevspan *ptr  = *spansetptr;
    typevspan *last = NULL;

    if (!ptr) {
        *spansetptr = makevspan(sess, spanptr, (typevspan *) NULL);
        return;
    }

    for (; ptr; last = ptr, ptr = ptr->next) {
        StreamAddr newspanend = spanptr->stream + spanptr->width;
        StreamAddr oldspanend = ptr->stream + ptr->width;

        int spancmp = spanptr->stream.compareTo(oldspanend);
        if (spancmp == Tumbler::EQUAL) {
            ptr->width = ptr->width + spanptr->width;
            return;

        } else if (spancmp == Tumbler::GREATER)
            continue;

        spancmp = ptr->stream.compareTo(newspanend);
        if (spancmp == Tumbler::EQUAL) {
            ptr->stream = spanptr->stream;
            ptr->width  = spanptr->width + ptr->width;
            return;

        } else if (spancmp == Tumbler::GREATER) {
            if (ptr != *spansetptr)
                last->next = makevspan(sess, spanptr, ptr);
            else
                *spansetptr = makevspan(sess, spanptr, ptr);

            return;
        }

        int startcmp = spanptr->stream.compareTo(ptr->stream);
        int endcmp   = newspanend.compareTo(oldspanend);

        if (startcmp > Tumbler::LESS && endcmp < Tumbler::GREATER)
            return;

        switch (startcmp) {
        case Tumbler::EQUAL:
            if (endcmp == Tumbler::GREATER)
                ptr->width = spanptr->width;
            return;
        case Tumbler::LESS:
            ptr->stream = spanptr->stream;

            if (endcmp == Tumbler::GREATER)
                ptr->width = spanptr->width;
            else
//                tumblersub(&oldspanend, &spanptr->stream, &ptr->width);
                ptr->width = oldspanend - spanptr->stream;

            break;

        case Tumbler::GREATER:
            if (endcmp == Tumbler::GREATER) {
//                tumblersub(&newspanend, &ptr->stream, &ptr->width);
                ptr->width = newspanend - ptr->stream;

                return;
            }
        }
    }

    last->next = makevspan(sess, spanptr, (typevspan *) NULL);
}

/**********************************************************************
 *
 **********************************************************************/
    typevspanset *
ispan2vspanset(Session *sess, typeorgl orgl, typeispan *ispanptr, typevspanset *vspansetptr)
{
    return permute(sess, orgl, ispanptr, I_BASIS, vspansetptr, V_BASIS);
}

/**********************************************************************
 *
 **********************************************************************/
    typeispanset *
vspanset2ispanset(Session *sess, typeorgl orgl, typevspanset vspanptr, typeispanset *ispansetptr)
{
    return permute(sess, orgl, vspanptr, V_BASIS, ispansetptr, I_BASIS);
}

/**********************************************************************
 *
 **********************************************************************/
    typespanset *
permute(Session *sess, typeorgl orgl, typespanset restrictionspanset, int restrictionindex, typespanset *targspansetptr, int targindex)
{
    typespanset *save = targspansetptr;

    /*
     * consolidatespans(restrictionspanset);
     * foospanset("restrictionset after consolidation is ", restrictionspanset);
     */

    for (; restrictionspanset; restrictionspanset = restrictionspanset->next)
        targspansetptr = span2spanset(sess, orgl, restrictionspanset, restrictionindex, targspansetptr, targindex);

    return save;
}

/**********************************************************************
 *
 **********************************************************************/
    typespanset *
span2spanset(Session *sess, typeorgl orgl, typespanset restrictionspanptr, int restrictionindex, typespanset *targspansetptr, int targindex)
{
    Context *context = retrieverestricted((CoreUpperCrum *) orgl, restrictionspanptr, restrictionindex, (typespan *) NULL, targindex, (IStreamAddr *) NULL);

    typespan *nextptr;
    Context *c;
    for (c = context; c; c = c->nextcontext) {
        typespan foundspan;
        context2span(c, restrictionspanptr, restrictionindex, &foundspan, targindex);
        nextptr = (typespan *) onitemlist(sess, (typeitem *) &foundspan, (typeitemset *) targspansetptr);
    }

    if (!context)
        return targspansetptr;

    contextfree(context);

    return &nextptr->next;
}

/**********************************************************************
 *
 **********************************************************************/
/*
 *    void
 *consolidatespanset(typespan *spanset);
 *{
 *    for ( ; spanset->next; spanset = spanset->next) {
 *        if (
 *    }
 *}
 */

/**********************************************************************
 *
 **********************************************************************/
    typeitem *
onitemlist(Session *sess, typeitem *itemptr, typeitemset *itemsetptr)
{
    I(itemptr != NULL);
    I(itemsetptr != NULL);

    typeitem *temp, *newitem;

    switch (((typeitemheader *) itemptr)->itemid) {  /* allocate and copy to proper sized item */
    case TEXTID:
        newitem = (typeitem *) taskalloc(sess, sizeof(typetext));
        memmove(newitem, itemptr, sizeof(typetext));
        break;

    case ISPANID:
        newitem = (typeitem *) taskalloc(sess, sizeof(typeispan));
        memmove(newitem, itemptr, sizeof(typeispan));
        break;

    case VSPANID:
        newitem = (typeitem *) taskalloc(sess, sizeof(typevspan));
        memmove(newitem, itemptr, sizeof(typevspan));
        break;

    case VSPECID:
        newitem = (typeitem *) taskalloc(sess, sizeof(typevspec));
        memmove(newitem, itemptr, sizeof(typevspec));
        break;

    case NODEID:
        newitem = (typeitem *) taskalloc(sess, sizeof(typeboolsetnode));
        memmove(newitem, itemptr, sizeof(typeboolsetnode));
        break;

    case ADDRESSID: /* also LINKID*/
        newitem = (typeitem *) taskalloc(sess, sizeof(typeaddress));
        memmove(newitem, itemptr, sizeof(typeaddress));
        break;

    case SPORGLID: /* zzz kluge sporglitem is union sporgl is struct which should i use here i.e. how is this used and set  in fact sporgl happens to be big member in union but this is troubles me  REG 1/5/86*/
        newitem = (typeitem *) taskalloc(sess, sizeof(typesporglitem));
        memmove(newitem, itemptr, sizeof(typesporglitem));
        break;

    default:
        gerror("improper item"); //fixme: must not continue as pointer 'newitem' is NOT initialized beyond here !!!
	return NULL;
    }

    ((typeitemheader *) newitem)->next = NULL;

    if (*itemsetptr == NULL)
        *itemsetptr = newitem;
    else {
        /* this loop advances the ptr ot the end of the list */
        for (temp = *itemsetptr; temp && ((typeitemheader *) temp)->next; temp = (typeitem *) ((typeitemheader *) temp)->next)
            ((typeitemheader *) temp)->next = (typeitemheader *) newitem;
    }

    return newitem;
}

/**********************************************************************
 *
 **********************************************************************/
    bool
isemptyorgl(typeorgl fullcrumptr)
{
    return ((CoreUpperCrum *) fullcrumptr)->cwid.isEmpty(widsize(POOM))
        && ((CoreUpperCrum *) fullcrumptr)->cdsp.isEmpty(dspsize(POOM));
}

/**********************************************************************
 *  Original Copyright � 1979-1999 Udanax.com.   All Rights Reserved
 **********************************************************************/
