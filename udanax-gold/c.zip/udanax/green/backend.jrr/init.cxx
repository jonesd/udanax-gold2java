/**
 * @file  init.cxx
 * @brief ???
 *
 * (to be defined)
 *
 **/

//#include <time.h>

#include <nana/nana.h>  // GNU Assertion/Logging Tool

#include "xanadu.h"
#include "requests.h"

void         (*requestfns[NREQUESTS])(Session *);

/**********************************************************************
 *
 **********************************************************************/
    void
nullfun(Session *sess)
{
    putrequestfailed(sess);
}

/**********************************************************************
 *
 **********************************************************************/
    void
init(bool safe)
{
    int i;
    for (i = 0; i < NREQUESTS; i++)
        requestfns[i] = nullfun;

    requestfns[COPY]                      = copy;
    requestfns[INSERT]                    = insert;
    requestfns[RETRIEVEDOCVSPANSET]       = retrievedocvspanset;
    requestfns[REARRANGE]                 = rearrange;
    requestfns[RETRIEVEV]                 = retrievev;
    requestfns[NAVIGATEONHT]              = navigateonht;
    requestfns[SHOWRELATIONOF2VERSIONS]   = showrelationof2versions;
    requestfns[CREATENEWDOCUMENT]         = createnewdocument;
    requestfns[DELETEVSPAN]               = deletevspan;
    requestfns[CREATENEWVERSION]          = createnewversion;
    requestfns[RETRIEVEDOCVSPAN]          = retrievedocvspan;
    requestfns[QUIT]                      = quitxanadu;
    requestfns[SOURCEUNIXCOMMAND]         = sourceunixcommand;
    requestfns[FOLLOWLINK]                = followlink;
    requestfns[FINDDOCSCONTAINING]        = finddocscontaining;
    requestfns[CREATELINK]                = createlink;
    requestfns[RETRIEVEENDSETS]           = retrieveendsets;
    requestfns[FINDNUMOFLINKSFROMTOTHREE] = findnumoflinksfromtothree;
    requestfns[FINDLINKSFROMTOTHREE]      = findlinksfromtothree;
    requestfns[FINDNEXTNLINKSFROMTOTHREE] = findnextnlinksfromtothree;
    requestfns[CREATENODE_OR_ACCOUNT]     = createnode_or_account;
    requestfns[OPEN]                      = myopen;
    requestfns[CLOSE]                     = myclose;
    requestfns[XACCOUNT]                  = xaccount;

    if (safe) {
        requestfns[SOURCEUNIXCOMMAND]         = nullfun;
        requestfns[NAVIGATEONHT]              = nullfun;
        requestfns[FINDNUMOFLINKSFROMTOTHREE] = nullfun;
        requestfns[FINDNEXTNLINKSFROMTOTHREE] = nullfun;
    }

    ntaskorcommand = 0;
}

/**********************************************************************
 *  Original Copyright � 1979-1999 Udanax.com.   All Rights Reserved
 **********************************************************************/
