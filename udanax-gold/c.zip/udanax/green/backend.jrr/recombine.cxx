/**
 * @file  recombine.cxx
 * @brief ???
 *
 * (to be defined)
 *
 **/

#include <nana/nana.h>  // GNU Assertion/Logging Tool

#include "xanadu.h"
#include "enf.h"
#include "reap.h"

long noishouldbother = 0;
long notakenephewnd = 0;
long noeatbrosnd = 0;

static void takeovernephewsseq(CoreUpperCrum *me);

/**********************************************************************
 *
 **********************************************************************/
    void
recombine(CoreUpperCrum *father)
{
    switch (father->cenftype) {
    case GRAN:
        recombineseq(father);
        break;

    case SPAN:
        recombinend(father);
        break;

    case POOM:
        recombinend(father);
    }
}

/**********************************************************************
 *
 **********************************************************************/
/* GRANfilade recombine */

    void
recombineseq(CoreUpperCrum *father) /** zzz reg 1999 this recombines too much */
{
    CoreUpperCrum *ptr;

    if (father->height < 3 || !father->modified)
        return;

    if (!father->roomformoresons())
        return;

    for (ptr = (CoreUpperCrum *) father->leftSon(); ptr; ptr = (CoreUpperCrum *) ptr->rightBrother())
        recombineseq(ptr);

    for (ptr = (CoreUpperCrum *) father->leftSon(); ptr && ptr->rightbro; ptr = (CoreUpperCrum *) ptr->rightBrother()) {
        if (ptr->age == RESERVED)
            continue;

        if (ptr->leftson && ptr->roomformoresons()) {
            /* if (ptr->leftson && toofewsons(ptr)) { **/
            if (((CoreUpperCrum *) ptr->rightbro)->leftson) {
                if (ptr->numberofsons + ((CoreUpperCrum *) ptr->rightbro)->numberofsons <= MAXUCINLOAF) {
                    eatbrossubtreeseq(ptr);
                    break;
                } else {
                    takeovernephewsseq(ptr);
                    break;
                }
            }
        }
    }

    if (father->isapex)
        levelpull(father);
}

/**********************************************************************
 *
 **********************************************************************/
    static void
takeovernephewsseq(CoreUpperCrum *me)
{
    CoreUpperCrum *ptr;
    CoreCrum *next;

    for (ptr = (CoreUpperCrum *) me->rightBrother()->leftSon();
         ptr && me->roomformoresons();
	 ptr = (CoreUpperCrum *) next) {

        next = ptr->rightBrother();
        if (ptr->age == RESERVED)
            continue;

        ptr->disown();
        me->adoptAsRightmostSon(ptr);
        ptr->ivemodified();
    }

    setwispupwards((CoreUpperCrum *) me->rightBrother(), 0);
    setwispupwards((CoreUpperCrum *) me, 1);
}

/**********************************************************************
 *
 **********************************************************************/
    void
eatbrossubtreeseq(CoreUpperCrum *me)
{
    CoreUpperCrum *bro;

    bro = (CoreUpperCrum *) me->rightBrother();
    bro->leftSon()->leftbroorfather = me->leftSon()->rightmostBrother();
    me->leftSon()->rightmostBrother()->rightbro = bro->leftson;
    bro->leftson->isleftmost = false;

    me->numberofsons += bro->numberofsons;
    bro->disown();
    ((Enfilade *) me)->destroyCrum((CoreCrum *) bro);
    setwispupwards(me, 1);
}

/**********************************************************************
 *
 **********************************************************************/
/* 2d recombine */
    void
recombinend(CoreUpperCrum *father)
{
    CoreCrum *sons[MAXUCINLOAF];
    int i, j, n;
    bool ishouldbother();

    if (father->height < 2 || !father->modified)
        return;

    CoreCrum *ptr;
    for (ptr = father->leftSon(); ptr; ptr = ptr->rightBrother())
        recombinend((CoreUpperCrum *) ptr);

    getorderedsons(father, sons);
    n = father->numberofsons;
    for (i = 0; i < n-1; i++) {
        for (j = i+1; sons[i] && j < n; j++) {
            if (i != j && sons[j] && ishouldbother((CoreUpperCrum *) sons[i], (CoreUpperCrum *) sons[j])) {
                takeovernephewsnd((CoreUpperCrum **) &sons[i], (CoreUpperCrum **) &sons[j]);
                /* break; */
                /* break; //zzz6/16/84 reg// */
            }
        }
    }

    if (father->isapex)
        levelpull(father);
}

/**********************************************************************
 *
 **********************************************************************/
    bool
randomness(float probability)
{
    return true;

    /*
     * static float i = 0;
     * i += probability;
     * if (i >= 1.0) {
     *     while (i > 1)
     *         i -= 1.0;
     *     return true;
     *
     * } else
     *     return false;
     */
}

/**********************************************************************
 *
 **********************************************************************/
    bool
ishouldbother(CoreUpperCrum *dest, CoreUpperCrum *src)
{
    ++noishouldbother;

    if (src->numberofsons == 0) {
        if (src->sonorigin.diskblocknumber == NULLBLOCKNUM)
            check(src);
        else
            return false;
    }

    if (dest->age == RESERVED || src->age == RESERVED)
        return false;

    return dest->numberofsons + src->numberofsons <= (dest->height > 1 ? MAXUCINLOAF : MAX2DBCINLOAF) && randomness(0.3);
}

/**********************************************************************
 *
 **********************************************************************/
    bool
takeovernephewsnd(CoreUpperCrum **meptr, CoreUpperCrum **broptr)
{
    CoreCrum *sons[MAXUCINLOAF], *ptr;
    CoreUpperCrum *me, *bro;
    int i, n;
    bool ret;

    me  = *meptr;
    bro = *broptr;

    if (!me->leftson || !bro->leftson)
        return false;

    ret = false;
    if (me->numberofsons + bro->numberofsons <= MAXUCINLOAF) {
        eatbrossubtreend(me, bro);
        *broptr = NULL;
        return true;

    } else {
        getorderedsons(bro, sons);
        bro->leftSon(); /* to make sure its in core zzzz */
        n = bro->numberofsons;
        for (i = 0; i < n && me->roomformoresons(); i++) {
            ptr = sons[i];
            takenephewnd((CoreUpperCrum *) me, (CoreUpperCrum *) ptr);
            /* fixincoresubtreewids(me); */
            ret = true;
        }
    }

    if (bro->numberofsons)
        setwispupwards(bro, 0);
    else {
        bro->disown();
        ((Enfilade *) bro)->destroyCrum((CoreCrum *) bro);
        *broptr = NULL;
    }

    setwispupwards(me, 1);
    return ret;
}

/**********************************************************************
 *
 **********************************************************************/
    void
eatbrossubtreend(CoreUpperCrum *me, CoreUpperCrum *bro)
{
    Displacer offset, grasp;
    CoreUpperCrum *oldfather;
    CoreCrum *son;

    ++noeatbrosnd;
    bro->reserve();
    memset(&offset, 0, sizeof(offset));

    makeroomonleftnd(me, &offset, &bro->cdsp, &grasp);
    fixdspsofbroschildren(me, bro);

    bro->leftSon()->leftbroorfather             = me->leftSon()->rightmostBrother();
    me->leftSon()->rightmostBrother()->rightbro = bro->leftSon();
    bro->leftson->isleftmost                     = false;

    me->numberofsons += bro->numberofsons;
    for (son = me->leftSon(); son; son = son->rightBrother())
        setwisp(son);

    oldfather = (CoreUpperCrum *) bro->father();
    bro->rejuvinate();
    bro->disown();
    ((Enfilade *) bro)->destroyCrum((CoreCrum *) bro);
    setwispupwards(me, 0);

    setwispupwards(oldfather, 1);
    me->ivemodified();

    /* fixincoresubtreewids(me); */
}

/**********************************************************************
 *
 **********************************************************************/
    void
takenephewnd(CoreUpperCrum *me, CoreUpperCrum *nephew)
{
    CoreUpperCrum *bro;
    Displacer nephewsgrasp, grasp, offset;

    ++notakenephewnd;
    bro = (CoreUpperCrum *) nephew->father();
    nephew->disown();

//    dspadd(&bro->cdsp, &nephew->cdsp, &nephew->cdsp, bro->cenftype);
    nephew->cdsp = add(bro->cdsp, nephew->cdsp, bro->cenftype);

    me->adoptAsRightmostSon(nephew);
    prologuend((CoreCrum *) nephew, &bro->cdsp, &nephewsgrasp, NULL);

    makeroomonleftnd(me, &offset, &nephew->cdsp, &grasp);

//    dspsub(&nephew->cdsp, &me->cdsp, &nephew->cdsp, me->cenftype);
    nephew->cdsp = sub(nephew->cdsp, me->cdsp, me->cenftype);

    if (!bro->numberofsons) {
        bro->disown();
        ((Enfilade *) bro)->destroyCrum((CoreCrum *) bro);
    } else
        setwispupwards(bro, 0);

    nephew->ivemodified();
    setwispupwards(me, 1);
}

/**********************************************************************
 *
 **********************************************************************/
    void
fixdspsofbroschildren(CoreUpperCrum *me, CoreUpperCrum *bro)
{
    CoreCrum *nephew;

    for (nephew = bro->leftSon(); nephew; nephew = nephew->rightBrother()) {

//        dspadd(&bro->cdsp, &nephew->cdsp, &nephew->cdsp, me->cenftype);
        nephew->cdsp = add(bro->cdsp, nephew->cdsp, me->cenftype);

//        dspsub(&nephew->cdsp, &me->cdsp, &nephew->cdsp, me->cenftype);
        nephew->cdsp = sub(nephew->cdsp, me->cdsp, me->cenftype);

        nephew->ivemodified();
    }
}

/**********************************************************************
 *
 **********************************************************************/
    void
getorderedsons(CoreUpperCrum *father, CoreCrum *sons[])
{
    CoreCrum *ptr;
    int i;

    sons[0] = NULL;
    for (ptr = father->leftSon(), i = 0; ptr; ptr = ptr->rightBrother())
        sons[i++] = ptr;

    sons[i] = NULL;
    shellsort(sons, i);
}

/**********************************************************************
 *
 **********************************************************************/
    void
shellsort(CoreCrum *v[], int n)
{
    CoreCrum *temp;
    int gap, i, j;

    StreamAddr tarray[100], *tarrayp[100], *temptp;

    I(n < 100); // Insure No Excessive Recursion

    for (i = 0; i < n; i++) { /* build up a list of sumps of disp[0] and dsp[1] */
        /* for compare crums diagonally hack */

///////////////////////////////////FIXME
//        tarray[i] = v[i]->cdsp[0] + v[i]->cdsp[1];  illegal addition of two tumbler addresses!
        tarray[i] = v[i]->cdsp[0];
///////////////////////////////////FIXME

        tarrayp[i] = &tarray[i];
    }

    for (gap = n/2; gap > 0; gap /= 2) {
        for (i = gap; i < n; i++) {
            for (j = i - gap; j >= 0 && *tarrayp[j] > *tarrayp[j + gap]; j -= gap) {
                temp           = v[j];
                temptp         = tarrayp[j];
                v[j]           = v[j+gap];
                tarrayp[j]     = tarrayp[j+gap];
                v[j+gap]       = temp;
                tarrayp[j+gap] = temptp;
            }
        }
    }
}

/**********************************************************************
 *
 **********************************************************************/
    int
comparecrumsdiagonally(CoreCrum *a, CoreCrum *b)
{
////////////////////////////////FIXME
//    StreamAddr amagnitude = a->cdsp[0] + a->cdsp[1];
//    StreamAddr bmagnitude = b->cdsp[0] + b->cdsp[1];
    StreamAddr amagnitude = a->cdsp[0];
    StreamAddr bmagnitude = b->cdsp[1];
////////////////////////////////FIXME

    return amagnitude.compareTo(bmagnitude);
}

/**********************************************************************
 *
 **********************************************************************/
    void
fixincoresubtreewids(CoreUpperCrum *ptr)
{
    if (ptr->height == 0)
        return;

    CoreCrum *son;
    for (son = (CoreCrum *) ptr->leftSon(); son; son = son->rightBrother())
        fixincoresubtreewids((CoreUpperCrum *) son);

    if (setwisp((CoreCrum *) ptr)) {
#ifndef DISTRIBUTION
        cerr << "fixing " << ptr << endl;
#endif
    }
}

/**********************************************************************
 *  Original Copyright � 1979-1999 Udanax.com.   All Rights Reserved
 **********************************************************************/
