/**
 * @file  corediskout.cxx
 * @brief ???
 *
 * (to be defined)
 *
 **/

#include <stdio.h>

#include <nana/nana.h>  // GNU Assertion/Logging Tool

/*orglwrite and subtree write are called from  reap in credel.d */

#include "xanadu.h"
#include "enf.h"
#include "coredisk.h"
#include "allocio.h"

//extern bool isxumain;
//extern int nolread;
//extern int nolwrote;
//extern int noishouldbother;
//extern int notakenephewnd;
//extern int noeatbrosnd;

Enfilade1d *granf;
Enfilade2d *spanf;

//extern diskheader diskheader;
extern BitmapAllocIO *aio;
extern MMapCacheIO   *cio;

static void indiskexit();

    void
diskexit()
{
    indiskexit();
}

void diskflush();
void writeenfilades();
void hputinfo(CoreBottomCrum *ptr, char **loafptrptr);
void deletefullcrumandgarbageddescendents(DiskLoafAddr diskptr, bool deletefullcrumflag, DiskLoaf *loafp,
                                          DiskLoafAddr newdiskptr);
void deletewithgarbageddescendents(DiskLoafAddr diskptr, CoreUpperCrum *father, bool deletefullcrumflag);
void checkmodifiednotthere(CoreUpperCrum *father, char *string);

static void indiskexit();
static void hputwiddsp(CoreUpperCrum *ptr, char **loafptrptr);
static int varpackloaf(CoreUpperCrum *father, DiskLoaf *xloafptr, int refcount, int flag);
static int packloaf(CoreUpperCrum *father, DiskLoaf *loafptr, int refcount, int flag);
static void orglwritepart2(Session *sess, CoreBottomCrum *orglcbcptr);
static void subtreewriterecurs(Session *sess, CoreUpperCrum *father);
static void uniqueoutloaf(CoreUpperCrum *father, int refcount);

/**********************************************************************
 *
 **********************************************************************/
 /* make sure file is up to date when exiting program */
    static void
indiskexit()
{
    cerr << "Starting indiskexit()" << endl;

    /* FILE *record; */ bool decrementusers();

    cerr << "About to decrement users" << endl;
    if (decrementusers())
        return;

    cerr << "User decrement done, about to write enfilades..." << endl;

    writeenfilades();

    cerr << "Enfilades written, about to sync allocio..." << endl;

//    closediskfile();
    aio->sync();

    cerr << "AllocIO sync'd, about to close cio..." << endl;

    cio->close();

    cerr << "CIO closed, exiting now..." << endl;

    /*
     * record = fopen("diskiocount", "a");
     * fprintf(record, "%s:  ", (isxumain?"xumain":"backend"));
     * fprintf(record, "%5ld reads, %5ld writes, ", nolread, nolwrote);
     * fprintf(record, "%5ld isb, %5ld ebnd, %5ld tnnd\n", noishouldbother, noeatbrosnd, notakenephewnd);
     * fclose(record);
     */

    exit(0);
}

/**********************************************************************
 *
 **********************************************************************/
/* Update disk copy of all enfilades, and reset core versions for multiuser */
    void
diskflush()
{
    writeenfilades();
    initkluge((CoreUpperCrum**) &granf, (CoreUpperCrum**) &spanf);
}

/**********************************************************************
 *
 **********************************************************************/
/* Write entire granfilade and spanfilade to disk and flag as unmodified in core */
    void
writeenfilades()
{
    CoreBottomCrum temporgl;

    temporgl.leftbroorfather                                              = NULL;
    temporgl.modified                                                     = true;
    temporgl.cinfo.granstuff.orglstuff.orglincore                         = true;
    temporgl.cinfo.granstuff.orglstuff.diskorglptr.diskblocknumber        = GRANFDISKLOCATION;
    temporgl.cinfo.granstuff.orglstuff.diskorglptr.insidediskblocknumber  = 0;
    temporgl.cinfo.granstuff.orglstuff.orglptr                            = (CoreUpperCrum *) granf;
    ((CoreUpperCrum *) granf)->leftbroorfather                                  = (CoreCrum *) &temporgl;

    orglwrite(&temporgl);

    temporgl.modified                                                     = true;
    temporgl.cinfo.granstuff.orglstuff.orglincore                         = true;
    temporgl.cinfo.granstuff.orglstuff.diskorglptr.diskblocknumber        = SPANFDISKLOCATION;
    temporgl.cinfo.granstuff.orglstuff.diskorglptr.insidediskblocknumber  = 0;
    temporgl.cinfo.granstuff.orglstuff.orglptr                            = (CoreUpperCrum *) spanf;
    ((CoreUpperCrum *) spanf)->leftbroorfather                                  = (CoreCrum *) &temporgl;

    orglwrite(&temporgl);
}


#define hputinloaf(hp,lp,tp) ((void)humberput((int)(hp),(humber)(lp),(unsigned int*)(tp)),(lp)=((char*)lp)+*(tp))
/*#define hputwisp(wp,lp,tp) ((tp)=tumblerfixedtoptr((lp),&(wp.dsas[0])),((char*)lp)+=(tp),(tp)=tumblerfixedtoptr((lp),&(wp.dsas[1])),((char *)lp)+=(tp))*/

/**********************************************************************
 *
 **********************************************************************/
    static void
hputwiddsp(CoreUpperCrum *ptr, char **loafptrptr)
{
    int i;

    int nstreams = widsize(ptr->cenftype);

    for (i = 0; i < nstreams; ++i)
        *loafptrptr += tumblerfixedtoptr(&ptr->cdsp[i], (humber) *loafptrptr);

    for (i = 0; i < nstreams; ++i)
        *loafptrptr += tumblerfixedtoptr(&ptr->cwid[i], (humber) *loafptrptr);
}

/**********************************************************************
 *
 **********************************************************************/
/*
 *    void
 *hdump(int n, char *ptr)
 *{
 *#ifndef DISTRIBUTION
 *    int i;
 *
 *    for (i = 0; i < n; i++)
 *        cerr << hex << *(ptr+i) << ' ' << dec << endl;
 *#endif
 *}
 */

/**********************************************************************
 *
 **********************************************************************/
    static int
varpackloaf(CoreUpperCrum *father, DiskLoaf *xloafptr, int refcount, int flag)
{
    unsigned int temp;

    char *loafptr = (char *) xloafptr;

    loafptr += 3;   /* make room for loaflength */

    if (flag) { // Pack a TopMost Loaf but Not Children, if Any
        hputinloaf(true,                 loafptr, &temp); // Write isapex = true
        hputinloaf(father->height,       loafptr, &temp); // Height of This Crum in Tree
        hputinloaf(father->cenftype,     loafptr, &temp); // Type of Enfilade
        hputinloaf(1,                    loafptr, &temp); // Count of Crums in Loaf
        hputinloaf(refcount,             loafptr, &temp); // Count of References to This Tree

        hputwiddsp(father, &loafptr);
        hputinloaf(father->sonorigin.diskblocknumber,       loafptr, &temp);
        hputinloaf(father->sonorigin.insidediskblocknumber, loafptr, &temp);

        I(father->sonorigin.diskblocknumber != 0); // Must Not Write Block 0!
        I(father->sonorigin.diskblocknumber != NULLBLOCKNUM); // Must Not Write DISKPTR NULL

        return (int) loafptr - (int) xloafptr;

    } else { // Pack a Lower-Level Loaf and Fall-Thru to Pack the Child Too
        I(father != NULL);      // If Lower-Level Loaf Then It Must Have a Father!
	I(father->height > 0);  // But Must Not Be a Bottom Loaf Either
	I(loafptr != NULL);     // And We Must Have a Buffer into Which to Pack the Loaf
        I(!father->leftson && father->toomanysons()); // Too Many Sons in Loaf!

        hputinloaf(false,                loafptr, &temp); // Write isapex = false
        hputinloaf(father->height - 1,   loafptr, &temp);
        hputinloaf(father->cenftype,     loafptr, &temp);
        hputinloaf(father->numberofsons, loafptr, &temp);
        hputinloaf(refcount,             loafptr, &temp);
    }

    CoreCrum *ptr;
    for (ptr = (CoreCrum *) father->leftSon(); ptr; ptr = ptr->rightbro) {
        hputwiddsp((CoreUpperCrum *) ptr, (char **) &loafptr);
        if (ptr->height != 0) {
            hputinloaf(((CoreUpperCrum *) ptr)->sonorigin.diskblocknumber, loafptr, &temp);
            hputinloaf(((CoreUpperCrum *) ptr)->sonorigin.insidediskblocknumber, loafptr, &temp);

            I(((CoreUpperCrum *) ptr)->sonorigin.diskblocknumber != 0); // Must Not Write Block 0!
            I(((CoreUpperCrum *) ptr)->sonorigin.diskblocknumber == NULLBLOCKNUM); // Must Not Write DISKPTRNULL

        } else {
            hputinfo((CoreBottomCrum *) ptr, &loafptr);
        }
    }

    int ret = (int) loafptr - (int) xloafptr;
    humber3put(ret, (humber) xloafptr, &temp);

    return ret;
}

/*
#define hputinloaf(hp,lp,tp) (humberput((hp),(lp),(tp)),(lp)=((char*)lp)+*(tp))
*/

/**********************************************************************
 *
 **********************************************************************/
    void
hputinfo(CoreBottomCrum *ptr, char **loafptrptr)
{
    unsigned int temp;

    if (!ptr->is2dcrum()) {
        (void) humberput(ptr->cinfo.infotype, (humber) *loafptrptr, &temp);
        *loafptrptr += temp;

        if (ptr->cinfo.infotype == CoreBottomCrum::GRANTEXT) {
            (void) humberput((int) ptr->cinfo.granstuff.textstuff.textlength, (humber) *loafptrptr, &temp);
            *loafptrptr += temp;
            /* hputinloaf(ptr->cinfo.granstuff.textstuff.textlength, *loafptrptr, &temp); */
            memmove(*loafptrptr, ptr->cinfo.granstuff.textstuff.textstring, ptr->cinfo.granstuff.textstuff.textlength);
            *loafptrptr += ptr->cinfo.granstuff.textstuff.textlength;
            return;

        } else if (ptr->cinfo.infotype == CoreBottomCrum::GRANORGL) {
            (void) humberput(ptr->cinfo.granstuff.orglstuff.diskorglptr.diskblocknumber, (humber) *loafptrptr, &temp);
            *loafptrptr += temp;
            (void) humberput(ptr->cinfo.granstuff.orglstuff.diskorglptr.insidediskblocknumber, (humber) *loafptrptr, &temp);
            *loafptrptr += temp;

            /* hputinloaf(ptr->cinfo.granstuff.orglstuff.diskorglptr, *loafptrptr, &temp); */
            return;

        } else if (ptr->cinfo.infotype == CoreBottomCrum::GRANNULL) {
            return;
        } else {
//            cerr << "weird infotype in hputinfo " << ptr->cinfo.infotype << endl;
            gerror("weird infotype in hputinfo\n");
            return;
        }

    } else {
        if (ptr->height) {
            /* looks like we got this all*/
        } else {
            temp = tumblerfixedtoptr(&((Core2dBottomCrum *) ptr)->c2dinfo.homedoc, (humber) *loafptrptr);
            (*loafptrptr) += temp;
        }
    }
}

/**********************************************************************
 *
 **********************************************************************/
    static int
packloaf(CoreUpperCrum *father, DiskLoaf *loafptr, int refcount, int flag)
{
    return varpackloaf(father, loafptr, refcount, flag);
}

/**********************************************************************
 *
 **********************************************************************/
    void
orglwrite(CoreBottomCrum *orglcbcptr)
{
    I(orglcbcptr != NULL);

    cerr << "Entered orglwrite()" << endl;

    Session task;
    inittask(&task);

    orglwritepart2(&task, orglcbcptr);
    tfree(&task);

    cerr << "Leaving orglwrite()" << endl;
}

DiskLoaf zzzeroloaf;

/**********************************************************************
 *
 **********************************************************************/
    static void
orglwritepart2(Session *sess, CoreBottomCrum *orglcbcptr)
{
    I(orglcbcptr != NULL);

    cerr << "Entered orglwritepart2()" << endl;

    DiskLoafAddr          olddiskptr;
    DiskLoafAddr          temploaf;
    int                      size, newloaf;
    unsigned int             dummy;

    DiskLoaf                loaf    = zzzeroloaf;
    CoreBottomCrum::typegranbottomcruminfo *infoptr = &orglcbcptr->cinfo;
    CoreUpperCrum          *orglptr = infoptr->granstuff.orglstuff.orglptr;

    if (!orglcbcptr->modified && orglptr) {
        orglfree(orglptr);
        return;
    }

    if (infoptr->granstuff.orglstuff.orglincore) {
        orglcbcptr->reserve();
        olddiskptr = infoptr->granstuff.orglstuff.diskorglptr;
        subtreewriterecurs(sess, orglptr);

        /* writefullcrum(orgl); */

        size = packloaf(orglptr, &loaf, 1, 1);
        humber3put(size, (humber) &loaf, &dummy);

        if (orglptr->cenftype == POOM) {
            temploaf = partialdiskalloc(size, &newloaf);
            writeloaf(&loaf, temploaf, newloaf);
            changerefcount(temploaf, 1);
            infoptr->granstuff.orglstuff.diskorglptr = temploaf;
            deletefullcrumandgarbageddescendents(olddiskptr, true, (DiskLoaf *) NULL, olddiskptr /* olddiskptr is just a place holder */);

            /* writeloaf(&loaf, infoptr->granstuff.orglstuff.diskorglptr, true); */

        } else {
//fixme            if (diskheader.hasenftops) {
            if (false) {
                deletefullcrumandgarbageddescendents(olddiskptr, false, &loaf,
                    infoptr->granstuff.orglstuff.diskorglptr);

                /* writeloaf(&loaf, infoptr->granstuff.orglstuff.diskorglptr, true); */
            } else
                writeloaf(&loaf, infoptr->granstuff.orglstuff.diskorglptr, true);
        }

        /* NULL EFFECT HERE */

        /* ptr->modified = false; */

        orglcbcptr->rejuvinate();
        orglfree(orglptr);
    }
}

/**********************************************************************
 *
 **********************************************************************/
    void
deletefullcrumandgarbageddescendents(DiskLoafAddr diskptr, bool deletefullcrumflag, DiskLoaf *loafp, DiskLoafAddr newdiskptr)
{
    CoreBottomCrum        crum;
    typeuberrawdiskloaf   crum2;

    if (diskptr.diskblocknumber == NULLBLOCKNUM)
        return;

    /* kluge up a bottom crum, use it to read in granf, similarly for spanf */

    /* tempcbc = (CoreBottomCrum *) createcrum(0, GRAN); */

    CoreBottomCrum *tempcbc = &crum;
//fixme    initcrum(0, GRAN, (CoreCrum *) &crum);

    tempcbc->cinfo.infotype                        = CoreBottomCrum::GRANORGL;
    tempcbc->cinfo.granstuff.orglstuff.diskorglptr =  diskptr;

    if (deletefullcrumflag) {
        inorglinternal(tempcbc, &crum2);
        /* tempcbc->reserve(); */
    } else {
        inorglinternal(tempcbc, &crum2);
        /* tempcbc->reserve(); */

//fixme        diskset(newdiskptr.diskblocknumber); // Mark Block Used
//        aio->freeBlock(newdiskptr.diskblocknumber);

        writeloaf(loafp, newdiskptr, false);
    }

    tempcbc->cinfo.granstuff.orglstuff.orglptr->leftbroorfather = NULL;
    deletewithgarbageddescendents(diskptr, (CoreUpperCrum *) tempcbc, deletefullcrumflag);

    /* kluge SKIMP reserve and rejuvinate added 11-23-86 */
}

/**********************************************************************
 *
 **********************************************************************/
    void
deletewithgarbageddescendents(DiskLoafAddr diskptr, CoreUpperCrum *father, bool deletefullcrumflag)
{
    CoreBottomCrum          *ptr;
    DiskLoafAddr   ignoreddiskptr;

    if (father->height > 0)
        ptr = (CoreBottomCrum *) father->leftSon();
    else {
//        I(false); //fixme: ptr is now uninitialized, but used below !!!
        return;
    }

    /* if !flag changerefcount and then possibly recurse */
    if (!deletefullcrumflag || !changerefcount(diskptr, -1)) {
        if (father->height > 0) {
            for (; ptr; ptr = (CoreBottomCrum *) ptr->rightBrother()) {
                if (ptr->height > 0)
                    deletewithgarbageddescendents(((CoreUpperCrum *) ptr)->sonorigin, (CoreUpperCrum *) ptr, true);
            }
        } else if (father->cenftype == GRAN
               && ((CoreBottomCrum *)father)->cinfo.infotype == CoreBottomCrum::GRANORGL
               && ((CoreBottomCrum *)father)->cinfo.granstuff.orglstuff.orglincore
               && ((CoreBottomCrum *)father)->cinfo.granstuff.orglstuff.diskorglptr.diskblocknumber != GRANFDISKLOCATION
               && ((CoreBottomCrum *)father)->cinfo.granstuff.orglstuff.diskorglptr.diskblocknumber != SPANFDISKLOCATION) {

               deletefullcrumandgarbageddescendents(((CoreBottomCrum *) father)->cinfo.granstuff.orglstuff.diskorglptr,
                   true, /*ECH 8-28-88ignoreddiskptr,*/ (DiskLoaf *) NULL, ignoreddiskptr);
        }
    }

    /* subtreefree(ptr); */ /*12/04/86*/
}

/**********************************************************************
 *
 **********************************************************************/
    void
subtreewrite(CoreUpperCrum *father)
{
    Session task;

    inittask(&task);
    subtreewriterecurs(&task, father);

    /* decrementandfreedisk(top); */

    tfree(&task);
}

/**********************************************************************
 *
 **********************************************************************/
    static void
subtreewriterecurs(Session *sess, CoreUpperCrum *father)
{
    I(father != NULL);
    I(father->height != 0);

    CoreBottomCrum *ptr;

    // cerr << "entering subtreewriterecurs" << endl;

    /* this, of course, assumes modified is set right */
    if (!father->modified ) {
        if (father->sonorigin.diskblocknumber == NULLBLOCKNUM) {
#ifndef DISTRIBUTION
            cerr << "insubtreewriterecurs sonorigin == -1" << endl;
            dumpsubtree(father);
            gerror("in subtreewriterecurs");
#else
            gerror("");
#endif
        }
        cerr << "About to call loaffree() in subtreewriterecurs" << endl;
        loaffree(father);
        return;
    }

    /*
     *  if (// father->sonorigin.diskblocknumber == NULLBLOCKNUM && // !father->leftson) {
     *      cerr << " case b insubtreewriterecurs sonorigin == -1" << endl;
     *      dumpsubtree(father);
     *      gerror("in subtreewriterecurs");
     *  }
     */

    /* in order to guarantee integrity of disk, it's     */
    /*   important to write out or increment sons before */
    /*   father */

    cerr << "About to call checkmodifiednotthere-A() in subtreewriterecurs" << endl;
    checkmodifiednotthere(father, "A");

    for (ptr = (CoreBottomCrum *) father->leftson; ptr; ptr = (CoreBottomCrum *) ptr->rightbro) {
        if (ptr->height == 0 && ptr->cenftype == GRAN && ptr->cinfo.infotype != CoreBottomCrum::GRANTEXT
        &&  ptr->cinfo.infotype != CoreBottomCrum::GRANORGL && ptr->cinfo.infotype != CoreBottomCrum::GRANORGL
        &&  ptr->cinfo.infotype != CoreBottomCrum::GRANNULL) {
//            cerr << "bad infotypein subtreewriterecursive  = " << ptr->cinfo.infotype << endl;
//            dump((CoreCrum *) ptr);
            gerror("subtreewriterecurs\n");
        }

        if (ptr->height != 0) {
            cerr << "About to call ourselves in subtreewriterecurs" << endl;
            subtreewriterecurs(sess, (CoreUpperCrum *) ptr);
        } else if (ptr->cenftype == GRAN && ptr->height == 0 && ((CoreBottomCrum *) ptr)->cinfo.infotype == CoreBottomCrum::GRANORGL) {
            cerr << "About to call orglwritepart2() in subtreewriterecurs" << endl;
            orglwritepart2(sess, ptr);
        }

        ptr->modified = false;
    }

    if (father->modified) {
        cerr << "About to call checkmodifiednotthere-B() in subtreewriterecurs" << endl;
        checkmodifiednotthere(father, "B");

        for (ptr = (CoreBottomCrum *) father->leftson; ptr; ptr = (CoreBottomCrum *) ptr->rightbro) {
            if (ptr->height > 0 && ((CoreUpperCrum *)  ptr)->sonorigin.diskblocknumber != NULLBLOCKNUM) {
                cerr << "About to call changerefcount() in subtreewriterecurs" << endl;
                changerefcount(((CoreUpperCrum *) ptr)->sonorigin, 1);
            }
        }

        cerr << "About to call checkmodifiednotthere-C() in subtreewriterecurs" << endl;
        checkmodifiednotthere(father, "C");

        cerr << "About to call uniqueoutloaf() in subtreewriterecurs" << endl;
        uniqueoutloaf(father, 0);
    }

    /* father->rejuvinate(); */

    cerr << "About to call loaffree() at exit in subtreewriterecurs" << endl;
    loaffree(father);
}

/**********************************************************************
 *
 **********************************************************************/
    void
checkmodifiednotthere(CoreUpperCrum *father, char *string)
{
    return;

#ifndef DISTRIBUTION
#ifdef UnDeFineD
    if (father->modified && (!father->leftson) /* && father->sonor.diskblocknumber== NULLBLOCKNUM */) {
        dump(father);
        cerr << "in " << string << " subtreewrite");
        gerror("in   subtreewriterecurs bad crum\n");
    }
#endif
#endif
}

typeuberdiskloaf zzzerouberloaf;

/**********************************************************************
 *
 **********************************************************************/
    static void
uniqueoutloaf(CoreUpperCrum *father, int refcount)
{
    I(father->modified);

    typeuberdiskloaf loaf;
    int              size, newloaf;
    unsigned int     temp;

    loaf = zzzerouberloaf;
    if ((!father->leftson) && father->sonorigin.diskblocknumber != NULLBLOCKNUM) {
        father->leftSon(); /* get it in so we know numberof sons zzz KLUGE is this right aug 15 86*/
        /* father->numberofsons = findnumberofdamnsons(father); */
    }

    size = packloaf(father, (DiskLoaf *) &loaf, refcount, 0);

    father->sonorigin = partialdiskalloc(size, &newloaf);
//    cerr << "partialdiskalloc() gave me block# " << father->sonorigin << endl;

    /* dumphexstuff(&loaf); */

    (void) humber3put(size, (humber) &loaf, &temp);

    /* dumphexstuff(&loaf); */

    /* loaf.numberofunterloafs = 1; */

    if (false && newloaf)
        addallocatedloaftopartialallocedtables(father->sonorigin, size);

    /* dumphexstuff(&loaf); */

    // cerr << "height in uniqueoutloaf = " << father->height << endl;

    writeloaf((DiskLoaf *) &loaf, father->sonorigin, newloaf);
    father->modified = false;

    // cerr << "leaving uniqueoutloaf" << endl;
}

/**********************************************************************
 *  Original Copyright � 1979-1999 Udanax.com.   All Rights Reserved
 **********************************************************************/
