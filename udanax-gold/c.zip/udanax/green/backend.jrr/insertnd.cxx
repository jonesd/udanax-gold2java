/**
 * @file  insertnd.cxx
 * @brief ???
 *
 * (to be defined)
 *
 **/

#include <nana/nana.h>  // GNU Assertion/Logging Tool

#include "xanadu.h"
#include "enf.h"
#include "ndenf.h"
#include "knives.h"

/* use with SPAN and POOM */

/**********************************************************************
 *
 **********************************************************************/
    void
makegappm(Session *sess, CoreUpperCrum *fullcrumptr, Displacer *origin, Widener *width)
{
    Displacer offset;
    memset(&offset, 0, sizeof(offset)); /* fullcrum alway has zero offset */
    Displacer grasp, reach;
    prologuend(fullcrumptr, &offset, &grasp, &reach);

    if (fullcrumptr->cwid[V_BASIS].iszero()
    || (*origin)[V_BASIS] < grasp[V_BASIS]
    || (*origin)[V_BASIS] < reach[V_BASIS])
        return;    /* this if for extensions to bc without calling cut */

    Knives knives;
    knives.blade[0] = (*origin)[V_BASIS];

    findaddressofsecondcutforinsert(&(*origin)[V_BASIS], &knives.blade[1]);
    knives.nblades = /*1*/2;
    knives.dimension = V_BASIS;
    makecutsnd(fullcrumptr, &knives);

    Displacer foffset;
    CoreUpperCrum *father;
    newfindintersectionnd(fullcrumptr, &knives, &father, &foffset);
    Displacer fgrasp;
    prologuend((CoreCrum *) father, &foffset, &fgrasp, NULL);

    CoreCrum *ptr;
    for (ptr = father->leftSon(); ptr; ptr = ptr->rightBrother()) {
        int i = insertcutsectionnd(ptr, &fgrasp, &knives);
        switch (i) {
        case 0:
        case 2:
            break;

        case -1:      /* THRUME*/
            dump(ptr);
            gerror("makegappm can't classify crum\n");
            break;

        case 1:/*9-17-87 fix */
            ptr->cdsp[V_BASIS] = ptr->cdsp[V_BASIS] + (*width)[V_BASIS];
            ptr->ivemodified();
            break;

        default:
            I(false); // unexpected cutsection
        }
    }

    setwidnd(father);
    setwispupwards(father->father(), 1);
}

/**********************************************************************
 *
 **********************************************************************/
    void
findaddressofsecondcutforinsert(Tumbler *position, Tumbler *secondcut)
{ /* needs this to give it a place to find intersectionof for text is 2.1 */
    StreamAddr zero, intpart;

    zero.clear();

//    tumblerincrement(position, -1, 1, secondcut);
    *secondcut = position->increment(-1, 1);

    beheadtumbler(position, &intpart);

//    tumblerincrement(secondcut, 0, -tumblerintdiff(&intpart, &zero), secondcut);
    *secondcut = secondcut->increment(0, -tumblerintdiff(&intpart, &zero));

//    tumblerincrement(secondcut, 1, 1, secondcut);
    *secondcut = secondcut->increment(1, 1);
}

/**********************************************************************
 *
 **********************************************************************/
    int
doinsertnd(CoreUpperCrum *father, Displacer *origin, Widener *width, Core2dBottomCrum::type2dbottomcruminfo *infoptr, int index)
{
    if ((*width)[index].iszero())
        /*q*/ gerror("zero width in doinsertnd\n");

    if (((Enfilade *) father)->isEmpty()) {
        firstinsertionnd(father, origin, width, infoptr);
        return false;
    }

    Displacer  offset;
    memset(&offset, 0, sizeof(offset));

    return insertmorend(father, &offset, origin, width, infoptr, index);
}

/**********************************************************************
 *
 **********************************************************************/
    void
firstinsertionnd(CoreUpperCrum *father, Displacer *origin, Widener *width, Core2dBottomCrum::type2dbottomcruminfo *infoptr)
{
    CoreCrum *ptr;

    ptr = father->leftSon();

//    movewid(origin, &ptr->cdsp); // Move a WISP
    ptr->cdsp = *origin;

//    movewid(width, &ptr->cwid); // Move a WISP
    ptr->cwid = *width;

//    move2dinfo(infoptr, &((Core2dBottomCrum *) ptr)->c2dinfo);
    ((Core2dBottomCrum *) ptr)->c2dinfo = *infoptr;

    ptr->ivemodified();
    setwisp(father);
}

/**********************************************************************
 *
 **********************************************************************/
    int
insertmorend(CoreUpperCrum *father, Displacer *offset, Displacer *origin, Widener *width, Core2dBottomCrum::type2dbottomcruminfo *infoptr, int index)
{
    Displacer grasp;
    CoreCrum *ptr;
    int temp;

    if ((*width)[index].iszero())
        gerror("zero width in insertmorend\n");

    makeroomonleftnd(father, offset, origin, &grasp);
    if (father->height == 1)
        return insertcbcnd(father, &grasp, origin, width, infoptr);

    ptr = findsontoinsertundernd(father, &grasp, origin, width, index);
    temp = insertmorend((CoreUpperCrum *) ptr, &grasp, origin, width, infoptr, index);

    /* setwispupwards(ptr, 1); */ /* was done in insertcbcnd*/
    setwispupwards(father, 1);
    ptr->ivemodified(); /* zzz possibly redundant with setwispupwards */
    return temp;
}

/**********************************************************************
 *
 **********************************************************************/
    int
insertcbcnd(CoreUpperCrum *father, Displacer *grasp, Displacer *origin, Widener *width, Core2dBottomCrum::type2dbottomcruminfo *infoptr)
{
    CoreCrum *ptr, *newcrum;
    bool splitsomething;

    for (ptr = father->leftSon(); ptr; ptr = ptr->rightBrother()) {
        if (isanextensionnd((CoreBottomCrum *) ptr, grasp, origin, infoptr)) {
//            widadd(&ptr->cwid, width, &ptr->cwid, (int) father->cenftype);
            ptr->cwid = add(ptr->cwid, *width, father->cenftype);

            ptr->ivemodified();
            setwispupwards(father, 1);

            if (!father->isTopmost())
                return setwispupwards(father->father(), 1); /* was ...),1); ECH ****/

            return false;
        }
    }

    newcrum = ((Enfilade *) father)->createCrum(0, father->cenftype);
    newcrum->reserve();

    father->adoptAsSon(newcrum);

//    dspsub(origin, grasp, &newcrum->cdsp, (int) father->cenftype);
    newcrum->cdsp = sub(*origin, *grasp, father->cenftype);

    if (width->isEmpty(2))
        gerror("zero width in insertnd\n");

//    movewid(width, &newcrum->cwid); // Move a WISP
    newcrum->cwid = *width;

//    move2dinfo(infoptr, &((Core2dBottomCrum *) newcrum)->c2dinfo);
    ((Core2dBottomCrum *) newcrum)->c2dinfo = *infoptr;

    newcrum->ivemodified();

    /* setwispallthewayupwards(newcrum //father// ); */

    setwispupwards((CoreUpperCrum *) newcrum /*father*/, 0);
    setwispupwards(father, 1);
    splitsomething = splitcrumupwards(father);
    newcrum->rejuvinate();

    return splitsomething;
}

/**********************************************************************
 *
 **********************************************************************/
    CoreCrum *
findsontoinsertundernd(CoreUpperCrum *father, Displacer *grasp, Displacer *origin, Widener *width, int index)
{
    CoreCrum *nearestonleft;

    I(!(*width)[index].iszero());

    StreamAddr spanend = (*origin)[index] + (*width)[index];

    CoreCrum *ptr = nearestonleft = father->leftSon();
    for (; ptr; ptr = ptr->rightBrother()) {
///////////////////////////////// FIXME
//        StreamAddr sonstart = (*grasp)[index] + ptr->cdsp[index]; (addition of two addresses -- not legal!)
        StreamAddr sonstart = (*grasp)[index];
///////////////////////////////// FIXME

        if (sonstart > (*origin)[index] && ptr->cdsp[index] > nearestonleft->cdsp[index])
            nearestonleft = ptr;

        if (whereoncrum(ptr, grasp, &(*origin)[index], index) >= ONMYLEFTBORDER
        &&  whereoncrum(ptr, grasp, &spanend, index) <= ONMYRIGHTBORDER)

            return ptr;
    }

    return nearestonleft;
}

/**********************************************************************
 *
 **********************************************************************/
    bool
isanextensionnd(CoreBottomCrum *ptr, Displacer *offsetptr, Displacer *originptr, Core2dBottomCrum::type2dbottomcruminfo *infoptr)
{
    Displacer grasp, reach;

    if (infoptr->homedoc != ((Core2dBottomCrum *) ptr)->c2dinfo.homedoc)
        return false;

    prologuend((CoreCrum *) ptr, offsetptr, &grasp, &reach);

    return reach.isEqual(*originptr, dspsize(ptr->cenftype));
}

/**********************************************************************
 *  Original Copyright � 1979-1999 Udanax.com.   All Rights Reserved
 **********************************************************************/
