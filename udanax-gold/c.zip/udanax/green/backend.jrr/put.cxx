/**
 * @file  put.cxx
 * @brief Output Routines -- No Front-End Version
 *
 * (to be defined)
 *
 **/

#include <unistd.h>

#include <nana/nana.h>  // GNU Assertion/Logging Tool

#include "xanadu.h"

#define MINEXP  -10

/**********************************************************************
 *
 **********************************************************************/
    void
prompt(Session *sess, char *string)
{
    sess->outp << string;
}

/**********************************************************************
 *
 **********************************************************************/
    void
error(Session *sess, char *string)
{
    sess->errp << string;
}

/**********************************************************************
 *
 **********************************************************************/
//    void
//puttumbler(FILE *outfile, Tumbler *tumblerptr)
//{
//    int i, place;
//
//    if (!tumblercheck(tumblerptr) || tumblerptr->exp < MINEXP) {
//        dumptumbler(tumblerptr);
//        return;
//    }
//
//    if (tumblerptr->negsign)
//        fprintf(outfile, "-");
//
//    for(i = tumblerptr->exp; i < 0; ++i)
//        fprintf(outfile, "0.");
//
//    place = Tumbler::NPLACES;
//
//    do {
//        --place;
//    } while (place > 0 && tumblerptr->mantissa[place] == 0);
//
//    for (i = 0; i <= place; ++i) {
//        putnum(outfile, tumblerptr->mantissa[i]);
//        if (i < place)
//            putc('.', outfile);
//    }
//}

/**********************************************************************
 *
 **********************************************************************/
    void
putisa(Session *sess, IStreamAddr *isaptr)
{
    sess->outp << *isaptr;
}

/**********************************************************************
 *
 **********************************************************************/
    void
putitemset(Session *sess, typeitemset itemset)
{
    if (itemset == NULL) {
	sess->outp << "  " << endl << "itemset empty" << endl;
        return;
    }

    for (; itemset; itemset = (typeitemset) ((typeitemheader *) itemset)->next) {
        putitem(sess, itemset);
        if (!(((typeitemheader *) itemset)->next && ((typeitemheader *) itemset)->itemid == TEXTID && ((typeitemheader *) itemset)->next->itemid == TEXTID))
            sess->outp << endl;
    }
}

/**********************************************************************
 *
 **********************************************************************/
    void
putitem(Session *sess, typeitem *itemptr)
{
    switch (((typeitemheader *) itemptr)->itemid) {
    case ISPANID:
	sess->outp << "  ispan" << endl;
        putspan(sess, (typespan *) itemptr);
        break;

    case VSPANID:
        sess->outp << "  vspan" << endl;
        putspan(sess, (typespan *) itemptr);
        break;

    case VSPECID:
        sess->outp << "document: ";
        putisa(sess, &((typevspec *) itemptr)->docisa);
        sess->outp << endl << "spans";
        putitemset(sess, (typeitemset) ((typevspec *) itemptr)->vspanset);
        break;

    case TEXTID:
        puttext(sess, (typetext *) itemptr);
        break;

    case LINKID:
        putisa(sess, &((typelink *) itemptr)->/*link*/address);
        break;

#ifndef DISTRIBUTION
    case SPORGLID:
        sess->outp << "sporgl address: ";
        putisa(sess, &((typesporgl *) itemptr)->sporgladdress);

        sess->outp << endl << "   sporgl origin: ";
        putisa(sess, static_cast<IStreamAddr*>(&((typesporgl *) itemptr)->sporglorigin));

        sess->outp << endl << "   sporgl width: ";
        putisa(sess, static_cast<IStreamAddr*>(static_cast<Tumbler*>(&((typesporgl *) itemptr)->sporglwidth)));

        sess->outp << endl;
        break;
#endif

    default:
        error(sess, "illegal item id for putitem ");
        sess->outp << hex << itemptr << dec << "  " << (int) ((typeitemheader *) itemptr)->itemid << endl << 'd';
        return;
    }
}

/**********************************************************************
 *
 **********************************************************************/
    void
putspan(Session *sess, typespan *spanptr)
{
    sess->outp << "   span address: " << spanptr->stream << endl
               << "   span width: "   << spanptr->width;
}

/**********************************************************************
 *
 **********************************************************************/
    void
puttext(Session *sess, typetext *textptr)
{
    sess->outp.write(textptr->string, textptr->length);
}

/**********************************************************************
 *
 **********************************************************************/
    void
putspanpairset(Session *sess, typespanpairset spanpairset)
{
    if (!spanpairset)
        sess->outp << "NULL relationship" << endl;

    else
        for (; spanpairset; spanpairset = spanpairset->nextspanpair)
            putspanpair(sess, spanpairset);
}

/**********************************************************************
 *
 **********************************************************************/
    void
putspanpair(Session *sess, typespanpair *spanpair)
{
    sess->outp << "start1:  " << spanpair->stream1     << endl
               << "start2:  " << spanpair->stream2     << endl
               << "width:  "  << spanpair->widthofspan << endl;
}

/**********************************************************************
 *
 **********************************************************************/
    void
putcreatelink(Session *sess, IStreamAddr *istreamptr)
{
    sess->outp << endl << "link made: ";
    putisa(sess, istreamptr);

    sess->outp << endl;
}

/**********************************************************************
 *
 **********************************************************************/
    void
putfollowlink(Session *sess, typespecset specset)
{
    sess->outp << "link endset is:" << endl;
    putitemset(sess, (typeitemset) specset);
}

/**********************************************************************
 *
 **********************************************************************/
    void
putretrievedocvspanset(Session *sess, typespanset *spansetptr)
{
    sess->outp << "docvspans are:" << endl;
    putitemset(sess, (typeitemset) *spansetptr);
}

/**********************************************************************
 *
 **********************************************************************/
    void
putretrievedocvspan(Session *sess, typespan *vspanptr)
{
    sess->outp << "docvspan is:" << endl;
    putspan(sess, vspanptr);
}

/**********************************************************************
 *
 **********************************************************************/
    void
putretrievev(Session *sess, typevstuffset *vstuffsetptr)
{
    sess->outp << endl << "vstuff is:" << endl;
    putitemset(sess, (typeitemset) *vstuffsetptr);
}

/**********************************************************************
 *
 **********************************************************************/
    void
putfindlinksfromtothree(Session *sess, typelinkset linkset)
{
    sess->outp << endl << "links" << endl;
    putitemset(sess, (typeitemset) linkset);
}

/**********************************************************************
 *
 **********************************************************************/
    void
putfindnumoflinksfromtothree(Session *sess, int num)
{
    sess->outp << endl << "number of links: " << num << endl;
}

/**********************************************************************
 *
 **********************************************************************/
    void
putfindnextnlinksfromtothree(Session *sess, int n, typelinkset nextlinkset)
{
    sess->outp << "next number of links: " << n << endl;
    putitemset(sess, (typeitemset) nextlinkset);
}

/**********************************************************************
 *
 **********************************************************************/
    void
putshowrelationof2versions(Session *sess, typespanpairset relation)
{
    sess->outp << "relation between versions:" << endl;
    putspanpairset(sess, relation);
}

/**********************************************************************
 *
 **********************************************************************/
    void
putcreatenewdocument(Session *sess, IStreamAddr *newdocisaptr)
{
    sess->outp << "new document: ";
    putisa(sess, newdocisaptr);
    sess->outp << endl << endl;
}

/**********************************************************************
 *
 **********************************************************************/
    void
putcreatenewversion(Session *sess, IStreamAddr *newdocisaptr)
{
    sess->outp << "new version: ";
    putisa(sess, newdocisaptr);
    sess->outp << endl;
}

/**********************************************************************
 *
 **********************************************************************/
    void
putfinddocscontaining(Session *sess, typeitemset addressset)
{
    sess->outp << endl << "documents" << endl;
    putitemset(sess, addressset);
}

/**********************************************************************
 *
 **********************************************************************/
    void
putretrieveendsets(Session *sess, typespecset fromset, typespecset toset, typespecset threeset)
{
    sess->outp << endl << "fromset" << endl;
    putitemset(sess, (typeitemset) fromset);

    sess->outp << endl << "toset" << endl;
    putitemset(sess, (typeitemset) toset);

    sess->outp << endl << "threeset" << endl;
    putitemset(sess, (typeitemset) toset);
}

/**********************************************************************
 *
 **********************************************************************/
    void
putinsert(Session *sess)
{
}

/**********************************************************************
 *
 **********************************************************************/
    void
putcopy(Session *sess)
{
}

/**********************************************************************
 *
 **********************************************************************/
    void
putdeletevspan(Session *sess)
{
}

/**********************************************************************
 *
 **********************************************************************/
    void
putrearrange(Session *sess)
{
}

/**********************************************************************
 *
 **********************************************************************/
    void
putrequestfailed(Session *sess)
{
    sess->outp << '?' << endl;
}

/**********************************************************************
 *
 **********************************************************************/
    bool
kluge()
{
    return true;
}

/**********************************************************************
 *
 **********************************************************************/
    bool
putxaccount(Session *sess)
{
    return true;
}

/**********************************************************************
 *
 **********************************************************************/
    bool
putcreatenode_or_account(Session *sess, Tumbler *tp)
{
    sess->outp << *tp;
    return true;
}

/**********************************************************************
 *
 **********************************************************************/
    bool
putopen(Session *sess, Tumbler *tp)
{
    sess->outp << *tp;
    return true;
}

/**********************************************************************
 *
 **********************************************************************/
    bool
putclose(Session *sess)
{
    return true;
}

/**********************************************************************
 *
 **********************************************************************/
    bool
putquitxanadu(Session *sess)
{
    sess->outp << "Good Bye." << endl;
    return true;
}

/**********************************************************************
 *  Original Copyright � 1979-1999 Udanax.com.   All Rights Reserved
 **********************************************************************/
