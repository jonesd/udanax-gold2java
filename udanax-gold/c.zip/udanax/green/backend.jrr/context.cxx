/**
 * @file  context.cxx
 * @brief ???
 *
 * (to be defined)
 *
 **/

#include <nana/nana.h>  // GNU Assertion/Logging Tool

#include "xanadu.h"
#include "enf.h"

int contextnum     = 0;
int c2dontextnum   = 0;

/**********************************************************************
 *
 **********************************************************************/
CrumContext::CrumContext(CoreBottomCrum *crum, Displacer *offset)
: corecrum(crum)
, totaloffset(*offset)  // Copy Displacer Value
{
    crum->reserve();
}

/**********************************************************************
 *
 **********************************************************************/
CrumContext::~CrumContext()
{
    if (corecrum)
        corecrum->rejuvinate();
}

/**********************************************************************
 *
 **********************************************************************/
   Context *
createcontext(unsigned char type)
{
    Context *ret;

    if (type == GRAN) {
        ret = (Context *) eallocwithtag(sizeof(Context), CONTEXTTAG);
        memset(ret, 0, sizeof(Context));
        ++contextnum;
    } else {
        ret = (Context *) eallocwithtag(sizeof(type2dcontext), CONTEXT2DTAG);
        memset(ret, 0, sizeof(type2dcontext));
        ++c2dontextnum;
    }

    ret->contexttype = type;
    return ret;
}

/**********************************************************************
 *
 **********************************************************************/
    void
contextfree(Context *context)
{
    Context *c;

    for (; (c = context) != 0; ) {
        if (c->contexttype == GRAN) {
            --contextnum;
        } else {
            --c2dontextnum;
        }

        context = context->nextcontext;;
        efree ((char*)c);
    }
}

/**********************************************************************
 *
 **********************************************************************/
/* put c on clist in index order */
    void
incontextlistnd(Context **clistptr, Context *c, int index)
{
    Displacer grasp;
    prologuecontextnd(c, &grasp, NULL);
    c->nextcontext = NULL;

    Context *clist = *clistptr;

    if (clist == NULL) { // First Insertion
        *clistptr = c;
        return;
    }
                                  /* on beginning */
    if (whereoncontext(clist, &grasp[index], index) < THRUME) {
        /* if (debug)
         *     cerr << "beginning" << endl;
         */

        c->nextcontext = clist;
        *clistptr = c;
        return;

    } else {
        Context  *nextc;
        for (; (nextc = clist->nextcontext) != 0; clist = nextc) {
            /* in middle */
            if ((whereoncontext(clist, &grasp[index], index) > ONMYLEFTBORDER)
            &&  (whereoncontext(nextc, &grasp[index], index) < ONMYLEFTBORDER)) {

                c->nextcontext = nextc;
                clist->nextcontext = c;
                return;
            }
        }
    }

                             /* on end */
    c->nextcontext = NULL;
    clist->nextcontext = c;
}

/**********************************************************************
 *
 **********************************************************************/
    void
oncontextlistseq(Context **clistptr, Context *c) /* add to list of context */
{
    c->nextcontext = NULL;

    if (!*clistptr) { /* 1st insertion */
        *clistptr = c;
        c->lastcontext = c;
    } else {            /* on end */
        (*clistptr)->lastcontext->nextcontext = c;
        (*clistptr)->lastcontext = c;
    }
}

/**********************************************************************
 *
 **********************************************************************/
    int
whereoncontext(Context *ptr, Tumbler *address, int index)
/* index:: used when enftype == SPAN or POOM */
{
    StreamAddr left, right;

    switch (ptr->contexttype) {
    case GRAN:
        left  = ptr->totaloffset[WIDTH];
        right = left + ptr->contextwid[WIDTH];

        break;

    case SPAN:
        /*zzz
         * if (ptr->contextwid[SPANRANGE].iszero())
         *     qerror("zero spanrange in whereoncontext\n");
         */

    case POOM:
        left  = ptr->totaloffset[index];
        right = left + ptr->contextwid[index];
        break;

    default:
        I(false); // Bad Enfilade Type
    }

    return intervalcmp(&left, &right, address);
}

/**********************************************************************
 *
 **********************************************************************/
    Context *
makecontextfromcbc(CoreBottomCrum *crumptr, Displacer *offsetptr)
{
    crumptr->reserve();

    Context *context = createcontext(crumptr->cenftype);

//    movewid(offsetptr, &context->totaloffset); // Move a WISP
    context->totaloffset = *offsetptr; // Move a WID into a DSP

//    movewid(&crumptr->cwid, &context->contextwid); // Move a WISP
    context->contextwid = crumptr->cwid; // Move a WID/WISP

    if (crumptr->is2dcrum())
//        move2dinfo(&((Core2dBottomCrum *) crumptr)->c2dinfo, &((type2dcontext *) context)->context2dinfo);
        ((type2dcontext *) context)->context2dinfo = ((Core2dBottomCrum *) crumptr)->c2dinfo;

    else
//        moveinfo(&crumptr->cinfo, &context->contextinfo);
        context->contextinfo = crumptr->cinfo;

    if (crumptr->cenftype != GRAN)
//        dspadd(&context->totaloffset, &crumptr->cdsp, &context->totaloffset, (int) crumptr->cenftype);
        context->totaloffset = add(context->totaloffset, crumptr->cdsp, crumptr->cenftype);

    context->nextcontext = NULL;
    crumptr->rejuvinate();

    return context;
}

/**********************************************************************
 *
 **********************************************************************/
    void
context2span(Context *context, typespan *restrictionspanptr, int idx1, typespan *foundspanptr, int idx2)
{
    StreamAddr lowerbound = restrictionspanptr->stream;
    StreamAddr upperbound = lowerbound + restrictionspanptr->width;

    Displacer grasp, reach;
    prologuecontextnd(context, &grasp, &reach);

    if (grasp[idx1] < lowerbound)
        grasp[idx2] = grasp[idx2].increment(0, (int) tumblerintdiff(&lowerbound, &grasp[idx1]));
//        tumblerincrement(&grasp[idx2], 0, (int) tumblerintdiff(&lowerbound, &grasp[idx1]), &grasp[idx2]);

    if (reach[idx1] > upperbound)
        reach[idx2] = reach[idx2].increment(0, /*i=*/ - tumblerintdiff(&reach[idx1], &upperbound));
//        tumblerincrement(&reach[idx2], 0, /*i=*/ - tumblerintdiff(&reach[idx1], &upperbound), &reach[idx2]);

    foundspanptr->stream = grasp[idx2];

//    tumblersub(&reach[idx2], &grasp[idx2], &foundspanptr->width);
    foundspanptr->width = reach[idx2] - grasp[idx2];

    foundspanptr->itemid = index2itemid(idx2, context);
    foundspanptr->next = NULL;
}

/**********************************************************************
 *
 **********************************************************************/
/* sets grasp & reach from ptr */
/*  reach may be NULL so that we won't set it */
    void
prologuecontextnd(Context *ptr, Displacer *grasp, Displacer *reach)
{
//    movedsp(&ptr->totaloffset, grasp); // Move a WISP
    *grasp = ptr->totaloffset; // Move a DSP/WISP

    if (reach)
//        dspadd(grasp, static_cast<Displacer*>(static_cast<Wisp*>(&ptr->contextwid)), reach, ptr->contexttype);
        *reach = add(*grasp, ptr->contextwid, ptr->contexttype);
}

/**********************************************************************
 *
 **********************************************************************/
    int
index2itemid(int index, Context *context)
{
    switch (context->contexttype) {
    case POOM:  return index == I_BASIS ? ISPANID : VSPANID;
    case SPAN:  return ISPANID;
    default :
        I(false); // Invalid Enfilade Type
        return 0; // for lint
    }
}

/**********************************************************************
 *
 **********************************************************************/
    bool
context2vstuff(Session *sess, Context *context, typeispan *ispanptr, typevstuffset *vstuffsetptr)
{
    typevstuffset vstuffset = NULL;

    int contextinfotype = context->contextinfo.infotype;
    if (contextinfotype != CoreBottomCrum::GRANTEXT && contextinfotype != CoreBottomCrum::GRANORGL)
        return false;

    switch (contextinfotype) {
    case CoreBottomCrum::GRANTEXT:
        vstuffset = (typevstuffset) taskalloc(sess, sizeof(typetext));
        ((typeitemheader *) vstuffset)->next = NULL;

        ((typeitemheader *) vstuffset)->itemid = TEXTID;
        context2vtext(context, ispanptr, vstuffset);

        if (((typetext *) vstuffset)->length == 0)
            return false;

        break;

    case CoreBottomCrum::GRANORGL:
        vstuffset = (typevstuffset) taskalloc(sess, sizeof(typeaddress));
        ((typeitemheader *) vstuffset)->next = NULL;

        ((typeitemheader *) vstuffset)->itemid = ADDRESSID;

        ((typelink *) vstuffset)->address = context->totaloffset[WIDTH];

    default:
        I(false); //fixme: INVARIANT should never happen
    }

    *vstuffsetptr = vstuffset;
    return true;
}

/**********************************************************************
 *
 **********************************************************************/
    void
context2vtext(Context *context, typeispan *ispanptr, typevstuffset vstuffset)
{
    IStreamAddr crumistart = context->totaloffset[WIDTH];

    IStreamAddr crumiend;
    crumiend = crumistart.increment(0, (int) context->contextinfo.granstuff.textstuff.textlength);
//    tumblerincrement(&crumistart, 0, (int) context->contextinfo.granbottomcruminfo.granstuff.textstuff.textlength, &crumiend);

    IStreamAddr ispanstart = ispanptr->stream;
    IStreamAddr ispanend   = ispanstart + ispanptr->width;

    int i = 0;

    int vtlength = context->contextinfo.granstuff.textstuff.textlength;

    if (crumistart < ispanstart) {
        i = tumblerintdiff(&ispanstart, &crumistart);
        vtlength -= i;
    }

    if (crumiend > ispanend)
        vtlength -= tumblerintdiff(&crumiend, &ispanend);

    ((typetext *) vstuffset)->length = vtlength > 0 ? vtlength : -vtlength;

    memmove(((typetext *) vstuffset)->string,
           &context->contextinfo.granstuff.textstuff.textstring[i],
           ((typetext *) vstuffset)->length);
}

/**********************************************************************
 *  Original Copyright � 1979-1999 Udanax.com.   All Rights Reserved
 **********************************************************************/
