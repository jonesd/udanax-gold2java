/**
 * @file  queues.cxx
 * @brief Queue Manipulation Routines
 *
 * (to be defined)
 *
 **/

#include <nana/nana.h>  // GNU Assertion/Logging Tool

#include <stdio.h>
#include <assert.h>

#include "queues.h"

/**********************************************************************
 *
 **********************************************************************/
 /*  QINIT  --  Initialise links for null queue */

    void
qinit(queue *qhead)
{
    qhead->qnext = qhead->qprev = qhead;
}

/**********************************************************************
 *
 **********************************************************************/
 /*  QINSERT  --  Insert object at end of queue */

    void
qinsert(queue *qhead, queue *object)
{
    assert(qhead->qprev->qnext == qhead);
    assert(qhead->qnext->qprev == qhead);

    object->qnext        = qhead;
    object->qprev        = qhead->qprev;
    qhead->qprev         = object;
    object->qprev->qnext = object;
}

/**********************************************************************
 *
 **********************************************************************/
 /*  QPUSH  --  Push object at start of queue  */

    void
qpush(queue *qhead, queue *object)
{
    assert(qhead->qprev->qnext == qhead);
    assert(qhead->qnext->qprev == qhead);

    object->qprev        = qhead;
    object->qnext        = qhead->qnext;
    qhead->qnext         = object;
    object->qnext->qprev = object;
}

/**********************************************************************
 *
 **********************************************************************/
 /*  QREMOVE  --  Remove object from queue.  Returns NULL if queue empty  */

    queue *
qremove(queue *qhead)
{
    queue *object;

    assert(qhead->qprev->qnext == qhead);
    assert(qhead->qnext->qprev == qhead);

    if ((object = qhead->qnext) == qhead)
        return NULL;

    qhead->qnext         = object->qnext;
    object->qnext->qprev = qhead;

    return object;
}

/**********************************************************************
 *
 **********************************************************************/
 /*  QNEXT  --  Get next object from queue nondestructively. Returns
               NULL at end of queue */

    queue *
qnext(queue *qthis, queue *qhead)
{
    queue *object;

    if ((object = qthis->qnext) == qhead)
        object = NULL;

    return object;
}

/**********************************************************************
 *
 **********************************************************************/
 /*  QDCHAIN  --  Dequeue an item from the middle of a queue.  Passed
                 the queue item, returns the (now dechained) queue item. */

    queue *
qdchain(queue *qitem)
{
    assert(qitem->qprev->qnext == qitem);
    assert(qitem->qnext->qprev == qitem);

    return qremove(qitem->qprev);
}

/**********************************************************************
 *
 **********************************************************************/
 /*  QLENGTH  --  Return number of items on queue, zero if queue empty.
                 Note that this must traverse all the links of the
                 queue, so if all you're testing is whether the queue
                 is empty or not, you should use the qempty(queue)
                 macro (defined in queues.h) which uses qnext() to
                 detect an empty queue much faster. */

    int
qlength(queue *qhead)
{
    int l = 0;
    queue *qp = qhead->qnext;

    while (qp != qhead) {
        l++;
        qp = qp->qnext;
    }

    return l;
}

/**********************************************************************
 *
 **********************************************************************/
 /*  QVALID  -- Validates all of the links in a queue.  Returns
                1 if all of the links are valid and 0 otherwise.
                Note that if the queue contains any bad pointers
                this routine may crash.  */

    bool
qvalid(queue *qhead)
{
    queue *qp;

    qp = qhead;
    if (qp == NULL)
        return false;

    do {
        if ((qp->qnext == NULL)
        ||  (qp->qprev == NULL)
        ||  (qp->qnext->qprev != qp)
        ||  (qp->qprev->qnext != qp))
            return false;

        qp = qp->qnext;
    } while (qp != qhead);

    return true;
}

/**********************************************************************
 *  Original Copyright � 1979-1999 Udanax.com.   All Rights Reserved
 **********************************************************************/
