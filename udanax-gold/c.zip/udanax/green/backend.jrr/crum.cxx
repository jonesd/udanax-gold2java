/**
 * @file  genf.cxx
 * @brief General Enfilade Manipulation Routines
 *
 * (to be defined)
 *
 **/

#include <nana/nana.h>  // GNU Assertion/Logging Tool

#include "xanadu.h"
#include "enf.h"
#include "coredisk.h"
#include "crum.h"

extern int reservnumber;

/**********************************************************************
 *
 **********************************************************************/
    void
CoreCrum::ivemodified()
{
    rejuvinateifnotRESERVED();

    bool fatherflag = true; /* not really, but the incoming ptr wants to get modified */

    CoreCrum *ptr = this;
    while (ptr) {
        /* if (ptr->height == 0) */ /* 10-2-84 what was this for bug */

        ptr->rejuvinateifnotRESERVED();
        if (fatherflag) {
            /*
             * if (ptr->modified)
             * return;
             */ /* this optimization commented out because createcrum sets flag true to fix this makesure that all created crums get ivemodified then change createcrum then fix here*/

            ptr->modified = true;
        }

        fatherflag = ptr->isleftmost;
        ptr        = ptr->leftbroorfather;
    }
}

/**********************************************************************
 *
 **********************************************************************/
    void
CoreCrum::disownnomodify()
{
    I(!isTopmost());

    CoreUpperCrum *father = weakFather();

    I(father != NULL);

    CoreCrum *right = rightBrother();
    father->numberofsons -= 1;

    if (isleftmost) {
        father->leftson = right;
        if (right) {
            right->leftbroorfather = (CoreCrum *) father;
            right->isleftmost      = true;
        }

    } else { /* has left brother */
        CoreCrum *left = leftBrother();
        left->rightbro = right;

        if (right)
            right->leftbroorfather = left;
    }

    leftbroorfather = rightbro = NULL;
    /* father->ivemodified(); */ /*for now till we remove this*/
}

/**********************************************************************
 * Remove crum from its father and siblings.  It keeps any kids it has.
 **********************************************************************/
    void
CoreCrum::disown()
{
    I(!isTopmost()); // Can't Remove Topmost Crum

    CoreUpperCrum *father = weakFather();

    I(father != NULL); // Can't Remove Fatherless Crum

    disownnomodify();
    father->ivemodified();
}

/**
 *
 * Test a Crum for being of type Text.
 *
 * A text crum represents a stream of continuous bytes, numbered from
 * zero.  It's tumbler address (DSP) looks like:
 *
 *   ?.0...
 *
 **********************************************************************/
    bool
CoreCrum::isTextCrum()
{
    if (cdsp[V_BASIS].mantissa[1] == 0 && is1story(&cwid[V_BASIS]))
        return true;

    return false;
}

/**
 *
 * A link crum represents a link between places, numbered from zero.
 * It's tumbler address (DSP) looks like:
 *
 *   1.n...
 *
 * where n is never zero.
 *
 **********************************************************************/
    bool
CoreCrum::isLinkCrum()
{
    if (cdsp[V_BASIS].mantissa[0] == 1 && cdsp[V_BASIS].mantissa[1] != 0)
        /* if the whole crum is displaced into link space it is a link crum this is true if
         * the tumbler is a 1.n tumbler where n!= 0
         */
        return true;

    return false;
}

/**
 *
 * Return a pointer to the node to my left, or NULL if there is none.
 *
 **********************************************************************/
    CoreCrum *
CoreCrum::leftBrother()
{
    if (isleftmost) {
        rejuvinateifnotRESERVED();
        return NULL; // No Nodes Further to My Left
    }

    CoreCrum *ptr = leftbroorfather;
    if (ptr)
        ptr->rejuvinateifnotRESERVED();

    return ptr;  // Next Node to My left
}

/**
 *
 * Return a pointer to the furthest node on my left side. (?)
 *
 **********************************************************************/
    CoreCrum *
CoreCrum::leftmostBrother()
{
    CoreCrum *p = this;

    while ((p = p->leftBrother()) != NULL)
        ; // Walk to End of Left-Brother Linked List

    return p;
}

/**********************************************************************
 *
 **********************************************************************/
    CoreCrum *
CoreCrum::weakLeftmostBrother()
{
    CoreCrum *p = this;

    while (!p->isleftmost) {
        p = p->leftbroorfather;
        I(p != NULL);
    }

    return p;
}

/**********************************************************************
 *
 **********************************************************************/
    CoreCrum *
CoreCrum::rightBrother()
{
    rejuvinateifnotRESERVED();

    CoreCrum *ptr = rightbro;
    if (ptr)
        ptr->rejuvinateifnotRESERVED();

    return ptr;
}

/**********************************************************************
 *
 **********************************************************************/
    CoreCrum *
CoreCrum::rightmostBrother()
{
    CoreCrum *p = this;

    while ((p = p->rightBrother()) != NULL)
        ; // Walk to End of Right-Brother Linked List

    return p;
}

/**********************************************************************
 *
 **********************************************************************/
    CoreUpperCrum *
CoreCrum::father()
{
    CoreCrum *ptr = leftmostBrother()->leftbroorfather;
    if (ptr)
        ptr->rejuvinateifnotRESERVED();

    return (CoreUpperCrum *) ptr;
}

/**********************************************************************
 *
 **********************************************************************/
    CoreUpperCrum *
CoreCrum::weakFather()
{
    if (isTopmost())   /* what about spanf*/
        return NULL;

    CoreCrum *ptr = this;
    for (; ptr && !ptr->isleftmost; ptr = ptr->leftbroorfather)
        ;

    if (ptr)
        return (CoreUpperCrum *) ptr->leftbroorfather;
    else
        return NULL;
}

/**********************************************************************
 *
 **********************************************************************/
    CoreUpperCrum *
CoreCrum::topmost()
{
    CoreCrum *ptr = this;

    for (; !ptr->isTopmost(); ptr = ptr->father());
        return (CoreUpperCrum *) ptr;
}

/**********************************************************************
 *
 **********************************************************************/
    void
CoreCrum::rejuvinate()
{
    if (age == RESERVED) {
        I(reservnumber > 0);
        --reservnumber;
    }
    age = NEW;
}

/**********************************************************************
 *     Protect a Crum and its Ancestors from Being Grimly Reaped
 **********************************************************************/
    void
CoreCrum::reserve()
{
    I(age != RESERVED); // Recursive Reserves Not Legal

    ++reservnumber;
    age = RESERVED;
}

/**********************************************************************
 * Adopt "new" Crum (and his Kids) into Our Family as Given Relation
 **********************************************************************/
    void
CoreCrum::adopt(CoreCrum *newcrum, Relation relative)
{
    I(newcrum != NULL);
    I(newcrum != this);

    /*
     *   if (newcrum->isTopmost())
     *       qerror("adopt called with fullcrum\n");
     */

    newcrum->cenftype = cenftype; /* make crum know what kind it is */

    CoreCrum        *left, *right;
    CoreUpperCrum   *father;

    switch (relative) {
    case LEFTMOSTSON:
        father = (CoreUpperCrum *) this;
        left   = NULL;
        right  = father->leftSon();
        break;

    case RIGHTMOSTSON:
        father = (CoreUpperCrum *) this;
        if (father->leftson)
            left = father->rightmostSon();
        else
            left = NULL;

        right = NULL;
        break;

    case RIGHTBRO:
        I(newcrum->height == height);

        left   = this;
        father = left->father();
        right  = left->rightBrother();
        break;

    case LEFTBRO:
        I(newcrum->height == height);

        right  = this;
        father = right->father();
        left   = right->leftBrother();
        break;

    default:
        I(false); // Unknown Type of Relationship
        return;
    }

    I(father != NULL);

    if (father->height != newcrum->height + 1) {
#ifndef DISTRIBUTION
        cerr << "father =" << endl;
        dump((CoreCrum *) father);

        cerr << endl << "new =" << endl;
        dump(newcrum);

        cerr << endl << "old =" << endl;
        dump(this);

        cerr << "relative = " << (int) relative << endl;
        qerror("height mismatch in adopt\n");
#else
        gerror("");
#endif
    }

    if (left) {
        left->rightbro       = newcrum;
        newcrum->leftbroorfather = left;
        newcrum->isleftmost      = false;
    } else {
        father->leftson      = newcrum;
        newcrum->leftbroorfather = (CoreCrum *) father;
        newcrum->isleftmost      = true;
    }

    newcrum->rightbro = right;
    if (right) {
        right->leftbroorfather = newcrum;
        right->isleftmost      = false;
    }

    ++father->numberofsons;
}

/**********************************************************************
 *
 **********************************************************************/
    CoreCrum *
CoreUpperCrum::leftSon()
{
    rejuvinateifnotRESERVED();

    CoreCrum *ptr = leftson;
    if (ptr)
        ptr->rejuvinateifnotRESERVED();

    return (CoreCrum *) ptr;
}

/**********************************************************************
 *
 **********************************************************************/
//    CoreCrum *
//CoreUpperCrum::leftSon()
//{
//    int oldage = age;
//    if (leftson == NULL) {
//        if (sonorigin.diskblocknumber == NULLBLOCKNUM)
//            return NULL; // No Immediate Left-Son and No Disk Trail to Follow
//
//        ptr->reserve();
//
//        I(ptr->sonorigin.diskblocknumber != 0);
//        inloaf(ptr);
//
//        /* THIS IS A REAL REJUVINATE FOR A RESERVE*/
//        if (oldage != RESERVED) /* zzz experimental zz */
//            rejuvinate();
//    }
//
//    leftson->rejuvinateifnotRESERVED();
//
//    return leftson;
//}

/**********************************************************************
 *
 **********************************************************************/
    CoreCrum *
CoreUpperCrum::rightmostSon()
{
    return leftSon()->rightmostBrother();
}

/**********************************************************************
 *
 **********************************************************************/
    bool
CoreUpperCrum::toomanysons()
{
    if (height)
        leftSon();

    return numberofsons > (height > 1 ? MAXUCINLOAF : (is2dcrum() ? MAX2DBCINLOAF : MAXBCINLOAF));
}

/**********************************************************************
 *
 **********************************************************************/
    bool
CoreUpperCrum::toofewsons()
{
    if (height && !leftson) /* brings in leftson if not here */
        leftSon();

    return numberofsons < (height > 1 ? MAXUCINLOAF - 1 : (is2dcrum() ? MAX2DBCINLOAF : MAXBCINLOAF));
}

/**********************************************************************
 *
 **********************************************************************/
    bool
CoreUpperCrum::roomformoresons()
{
    if (height && !leftson) /* brings in leftson if not here */
        leftSon();

    return numberofsons < (height > 1 ? MAXUCINLOAF : (is2dcrum() ? MAX2DBCINLOAF : MAXBCINLOAF));
}

/**********************************************************************
 *  Original Copyright � 1979-1999 Udanax.com.   All Rights Reserved
 **********************************************************************/
