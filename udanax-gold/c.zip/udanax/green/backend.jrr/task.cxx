/**
 * @file  task.cxx
 * @brief ???
 *
 * (to be defined)
 *
 **/

#include <nana/nana.h>  // GNU Assertion/Logging Tool

#include "xanadu.h"

//extern int errno;

/**********************************************************************
 *
 **********************************************************************/
    void
inittask(Session *sess)
{
    sess->inp           = cin;
    sess->outp          = cout;
    sess->errp          = cerr;
    sess->tempspacehead = NULL;
    sess->tempspacetail = NULL;

    /* sess->account.clear(); */
}

/**********************************************************************
 *
 **********************************************************************/
    bool
getaccount(Session *sess, IStreamAddr *accountptr)
{
    accountptr->clear();

    return true;

    /* prompt(sess, "account? "); */
}

/**********************************************************************
 *
 **********************************************************************/
    int *
taskalloc(Session *sess, int nbytes)
{
    return talloc(sess, nbytes);
}

/**********************************************************************
 *
 **********************************************************************/
    int *
talloc(Session *sess, int nbytes)
{
    typetthingheader *thishdr, *head;

    head = sess->tempspacehead;
    thishdr = (typetthingheader *) eallocwithtag((unsigned) (sizeof(typetthingheader) + nbytes), TASKEDTAG);

    if (((unsigned) thishdr) & 1)
        qerror("ealloc returned unaligned pointer.\n");

    thishdr->tnext = head;
    thishdr->tlast = NULL;

    if (head)
        head->tlast = thishdr;

    sess->tempspacehead = thishdr;
    ++thishdr;

    if (((unsigned) thishdr) & 1)
        qerror("talloc trying to return unaligned pointer.\n");

    return (int *) thishdr;
}

/**********************************************************************
 *
 **********************************************************************/
    void
tfree(Session *sess)
{
    typetthingheader *ptr;
    typetthingheader *p;

    for (ptr = sess->tempspacehead; ptr; ptr = p) {
        p = ptr->tnext;
        checkpointer("tfree: ", (char *) ptr);

        /*
         * if (ptr > (char *) 0x1b0000)
         *     gerror("tfree: ptr pointing into stack region.\n");
         */

        efree((char *) ptr);
    }

    sess->tempspacehead = NULL;
}

/**********************************************************************
 *
 **********************************************************************/
    void
tfreeexplicit(Session *sess, char *ptr)
{
    typetthingheader *header;

    checkpointer("tfreeexplicit: ", ptr);

    /* return; */

    header = (typetthingheader *) ptr;
    --header;

    if (header->tnext)
        header->tnext->tlast = header->tlast;

    if (header->tlast)
        header->tlast->tnext = header->tnext;

    if (header == sess->tempspacehead)
        sess->tempspacehead = header->tnext;

    efree((char *) header);
}

/**********************************************************************
 *
 **********************************************************************/
    void
tfreeitemset(Session *sess, typeitemset itemset)
{
    typeitem *nextitem;

    for (; itemset; itemset = nextitem) {
        checkitem("tfreeitemset: ", itemset);
        nextitem = (typeitem *) ((typeitemheader *) itemset)->next;

        if (((typeitemheader *) itemset)->itemid == VSPECID)
            tfreeitemset(sess, (typeitemset) ((typevspec *) itemset)->vspanset);

        tfreeexplicit(sess, (char *) itemset);
    }
}

/**********************************************************************
 *  Original Copyright � 1979-1999 Udanax.com.   All Rights Reserved
 **********************************************************************/
