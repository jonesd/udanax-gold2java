/**
 * @file  disk.cxx
 * @brief Lower-Level Disk Routines
 *
 * (to be defined)
 *
 **/

#include <stdio.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/types.h>
#include <netinet/in.h>
#include <errno.h>

#include <nana/nana.h>  // GNU Assertion/Logging Tool

#include "allocio.h"
#include "xanadu.h"
#include "enf.h"
#include "coredisk.h"

//FileBlockIO bio(NUMBYTESINLOAF);
extern MMapCacheIO   *cio;
extern BitmapAllocIO *aio;

/**********************************************************************
 *                  Operation on a Loaf Object
 **********************************************************************/
    int
findnumberofdamnsons(DiskLoafAddr diskptr)
{
    I(diskptr.diskblocknumber != NULLBLOCKNUM);

    void *loaf = cio->grabBlock(diskptr.diskblocknumber);
    char *loafp = findinsideloaf((typeuberdiskloaf *) loaf, diskptr.insidediskblocknumber);

    int size, isapex, height, enftype, numberofsons;
    hgetfromloaf(&size,         loafp);
    hgetfromloaf(&isapex,       loafp);
    hgetfromloaf(&height,       loafp);
    hgetfromloaf(&enftype,      loafp);
    hgetfromloaf(&numberofsons, loafp);

    cio->ungrabBlock(loaf, CacheIO::CLEAN);

    return numberofsons;
}

/**********************************************************************
 *
 **********************************************************************/
    int
changerefcount(DiskLoafAddr diskptr, int delta)
{
    I(diskptr.diskblocknumber != NULLBLOCKNUM);

    void *loaf = cio->grabBlock(diskptr.diskblocknumber);

    char *loafp              = findinsideloaf((typeuberdiskloaf *) loaf, diskptr.insidediskblocknumber);
    int   refcount           = changeunterrefcount((DiskLoaf *) loaf, loafp, delta);
    int   numberofunterloafs = numberofliveunterloafs((typeuberdiskloaf *) loaf);

    if (refcount > 0 && numberofunterloafs > 0)
        cio->ungrabBlock(loaf, CacheIO::DIRTY);
    else {
        cio->ungrabBlock(loaf, CacheIO::CLEAN);

//        diskfree(diskptr.diskblocknumber);
        aio->freeBlock(diskptr.diskblocknumber);
    }

    return refcount;
}

/**********************************************************************
 *
 **********************************************************************/
    int
changeunterrefcount(DiskLoaf *wholeloafp, char *originalloafp, int delta)
{
    int lengthdif;
    unsigned int refcount, dummylength, dummy;

    char *loafp = (char *) originalloafp;
    /* loafp += 3; */

    int size, isapex;
    hgetfromloaf(&size, loafp);
    hgetfromloaf(&isapex, loafp);

    int height, enftype, numberofsons;
    hgetfromloaf(&height,       loafp);
    hgetfromloaf(&enftype,      loafp);
    hgetfromloaf(&numberofsons, loafp);

    char *refcountloafp = loafp;
    hgetfromloaf(&refcount, loafp);
    int foo = loafp - (char *) wholeloafp;

    unsigned int oldlength = intlengthoflength(refcount);
    refcount  += delta;
    int ret    = refcount;
    unsigned int newlength  = intlengthoflength(refcount);

    if ((int) refcount > 0) {
        if (oldlength != newlength) {
            lengthdif = newlength - oldlength;

            if (newlength > oldlength)
                memmove(loafp - oldlength + newlength, loafp, sizeof(typeuberrawdiskloaf) - foo - newlength);
            else if (newlength > oldlength)
                memmove(loafp - oldlength + newlength, loafp, sizeof(typeuberrawdiskloaf) - foo - oldlength);

            size = size + oldlength - newlength;
            (void) humber3put(size, (humber) originalloafp, &dummy);
        }
        (void) humberput((int) refcount, (humber) refcountloafp /* - oldlength */, &dummylength);
    } else {
        memmove(originalloafp + 1, originalloafp + size, sizeof(typeuberrawdiskloaf) - foo - size + 3);
        *originalloafp = 1;
    }

    return ret;
}

/**********************************************************************
 *
 **********************************************************************/
 /* Reads whats on disk at place named by loafptr in
*       place pointed to by loaf
*/

    void
readloaf(DiskLoaf *loafptr, DiskLoafAddr diskptr)
{
    typeuberrawdiskloaf  uberrawloaf;
    humber               temp;

    // Read Raw Loaf into 'uberrawloaf'
    actuallyreadrawloaf(&uberrawloaf, diskptr.diskblocknumber);

    temp = (humber) findinsideloaf((typeuberdiskloaf *) &uberrawloaf, diskptr.insidediskblocknumber);
    if (!temp)
        temp = (humber) (((char *) &uberrawloaf) + 6);

    memmove(loafptr, temp, intof(temp)); /* humber at temp is length of loaf */
}

/**********************************************************************
 *               Read a Raw Loaf into Memory
 **********************************************************************/
    void
actuallyreadrawloaf(typeuberrawdiskloaf *loafptr, BlockNum blocknumber)
{
    I(loafptr != NULL);
    I(blocknumber != NULLBLOCKNUM);

    cerr << "About to test block# " << blocknumber << " for validity" << endl;
    I(aio->validDataBlockNum(blocknumber));

    void *loaf = cio->grabBlock(blocknumber);
    memcpy(loafptr, loaf, sizeof(*loafptr));
    cio->ungrabBlock(loaf, CacheIO::CLEAN);
}

/**********************************************************************
 *
 **********************************************************************/
/* Writes stuff at loaf onto piece of disk named by loafptr */
    void
writeloaf(DiskLoaf *loafptr, DiskLoafAddr diskptr, int newloaf)
{
    typeuberrawdiskloaf  loaf;
    char                *temp, *last,*end;
    int                  s;
    short                loaftemp;

    cerr << "Entering writeloaf() for block# " << diskptr.diskblocknumber << endl;

    I(diskptr.insidediskblocknumber <= 100);

    intof((humber) loafptr); /* test it to see if it starts with length */

    /* test diskalloc if alloced read in else do as old version */

    if (!newloaf) {
        cerr << "In writeloaf(), decided it was an old loaf" << endl;
        actuallyreadrawloaf(&loaf, diskptr.diskblocknumber);

        temp = findinsideloaf((typeuberdiskloaf *) &loaf, diskptr.insidediskblocknumber);

        if (diskptr.insidediskblocknumber == loaf.xuberdiskloaf.numberofunterloafs) {
            end = temp + intof((humber) temp);
        } else {
            last = findinsideloaf((typeuberdiskloaf *) &loaf, (int) ntohs(loaf.xuberdiskloaf.numberofunterloafs) - 1);
            end  = last +  intof((humber)last);
        }

        s = sizeof(typeuberrawdiskloaf) - (end - (char *) &loaf) - SIZEOFUBERDISKHEADER;
        memmove(/* ((char *) &loaf) + 6 */ temp, loafptr, s);
        loaf.xuberdiskloaf.versiondisknumber = 1;
        loaftemp = ntohs(loaf.xuberdiskloaf.numberofunterloafs) + 1;
        loaf.xuberdiskloaf.numberofunterloafs = htons(loaftemp);

    } else {
        cerr << "In writeloaf(), decided it was a new loaf" << endl;
        memmove(((char *) &loaf) + 6, loafptr, sizeof(typeuberrawdiskloaf) - SIZEOFUBERDISKHEADER);
        loaf.xuberdiskloaf.versiondisknumber = htonl(1);
        loaf.xuberdiskloaf.numberofunterloafs = htons(1);
    }

    actuallywriteloaf( /* size, */ &loaf, diskptr.diskblocknumber);
}
/**********************************************************************
 *
 **********************************************************************/
    void
actuallywriteloaf(typeuberrawdiskloaf *loafptr, BlockNum blocknumber)
{
    I(loafptr != NULL);
    I(blocknumber != NULLBLOCKNUM);

    cerr << "actuallywriteloaf of block# " << blocknumber << endl;
//    I(aio->validDataBlockNum(blocknumber));

    void *loaf = cio->grabBlock(blocknumber);
    memcpy(loaf, loafptr, sizeof(*loafptr));
    cio->ungrabBlock(loaf, CacheIO::DIRTY);
}

/**********************************************************************
 *
 **********************************************************************/
//    bool   /* return false if new file */
//initenffile()
//{
//    initincorealloctables();
//    bool ret = true;
//
//    cerr << "Opening CacheIO File in disk.cxx:initenffile" << endl;
//    CacheIO::OpenStatus ostat = cio->open("enf.enf");
//
//    switch (ostat) {
//    case BlockIO::OS_CREATED:
//        initheader();
//        ret = false;
//        break;
//
//    case BlockIO::OS_OPENED:
//        ret = readallocinfo(bio.blockfd);
//        break;
//
//    case BlockIO::OS_FAILED:
//        perror("initenffile");
//        gerror("cant open enf.enf or creatit");
//        break;
//    }
//
//    int fd = open("enf.enf", 2 /*rw*/, 0);
//    if (fd == -1) { // Open failed, create a new, empty enfilade file
//        errno = 0;
//        if ((fd = creat("enf.enf", 0666)) == -1) {
//            perror("initenffile");
//            gerror ("cant open enf.enf or creatit");
//        }
//
//        initheader ();
//        enffileread = false;
//        ret = false;
//    }
//
//    if (!ret)
//        aio->sync();
//
//    return ret;
//}

/**********************************************************************
 *
 **********************************************************************/
//    void
//closediskfile()
//{
////fixme    diskallocexit(bio.blockfd);
//
//    aio->sync();
//    cio->close();
//}

/**********************************************************************
 *  Original Copyright � 1979-1999 Udanax.com.   All Rights Reserved
 **********************************************************************/
