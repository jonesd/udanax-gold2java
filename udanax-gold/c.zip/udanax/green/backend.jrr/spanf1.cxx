/**
 * @file  spanf1.cxx
 * @brief Spanfilade Calls
 *
 * (to be defined)
 *
 **/

#include <nana/nana.h>  // GNU Assertion/Logging Tool

#include "xanadu.h"
#include "enf.h"

//extern bool isxumain;

/**********************************************************************
 *
 **********************************************************************/
    bool
insertspanf(Session *sess, Enfilade2d *spanfptr, IStreamAddr *isaptr, typesporglset sporglset, int spantype)
{
    Displacer              crumorigin;
    Widener               crumwidth;
    StreamAddr            lstream;
    StreamDiff            lwidth;
    Core2dBottomCrum::type2dbottomcruminfo  linfo;  /* zzz 2dinfo ? fix ? 5/27/84 ----- */

    prefixtumbler(isaptr, spantype, &crumorigin[ORGLRANGE]);
    crumwidth[ORGLRANGE].clear();

    memset(&linfo, 0, sizeof(linfo));

    for (; sporglset; sporglset = (typesporglset) ((typeitemheader *) sporglset)->next) {
        if (((typeitemheader *) sporglset)->itemid == ISPANID) {
            lstream = ((typeispan *) sporglset)->stream;

            lwidth = ((typeispan *) sporglset)->width;

	    linfo.homedoc = *isaptr;

        } else if (((typeitemheader *) sporglset)->itemid == SPORGLID) {
            lstream = ((typesporgl *) sporglset)->sporglorigin;

            lwidth = ((typesporgl *) sporglset)->sporglwidth;

            linfo.homedoc = ((typesporgl *) sporglset)->sporgladdress;

        } else if (((typeitemheader *) sporglset)->itemid == TEXTID) {
            lstream = *isaptr;

            /* create lwidth out of sporglset->length */
            lwidth.clear();
            lwidth.mantissa[1] = ((typetext *) sporglset)->length;
            tumblerjustify(&lwidth);

            linfo.homedoc = *isaptr;

        } else
            I(false); // insertspanf - bad itemid

        crumorigin[SPANRANGE] = lstream;
        crumwidth[SPANRANGE]  = lwidth;

        ((Enfilade2d *) spanfptr)->insertnd(sess, &crumorigin, &crumwidth, &linfo, SPANRANGE);
    }

    return true;
}

/**********************************************************************
 *
 **********************************************************************/
    bool
findlinksfromtothreesp(Session *sess, Enfilade2d *spanfptr, typespecset fromvspecset, typespecset tovspecset,
           typespecset threevspecset, typeispan *orglrange, typelinkset *linksetptr)
{
  typesporglset  fromsporglset;
  typesporglset  tosporglset;
  typesporglset  threesporglset;
  typelinkset    fromlinkset;
  typelinkset    tolinkset;
  typelinkset    threelinkset;

    bool olddebug = debug;

    fromlinkset = tolinkset = threelinkset = NULL;

    if (fromvspecset)
        specset2sporglset(sess, fromvspecset, &fromsporglset, NOBERTREQUIRED);

    if (tovspecset)
        specset2sporglset(sess, tovspecset, &tosporglset, NOBERTREQUIRED);

    if (threevspecset)
        specset2sporglset(sess, threevspecset, &threesporglset, NOBERTREQUIRED);

    if (fromvspecset) {
        sporglset2linkset(sess, (CoreUpperCrum *) spanfptr, fromsporglset, &fromlinkset, orglrange, LINKFROMSPAN);
        if (!fromlinkset) {
            *linksetptr = NULL;
            debug = olddebug;
            return true;
        }
    }

    if (tovspecset) {
        sporglset2linkset(sess, (CoreUpperCrum *) spanfptr, tosporglset, &tolinkset, orglrange, LINKTOSPAN);
        if (!tolinkset) {
            *linksetptr = NULL;
            debug = olddebug;
            return true;
        }
    }

    if (threevspecset) {
        sporglset2linkset(sess, (CoreUpperCrum *) spanfptr, threesporglset, &threelinkset, orglrange, LINKTHREESPAN);
        if (!threelinkset) {
            *linksetptr = NULL;
            debug = olddebug;
            return true;
        }
    }

    intersectlinksets(sess, fromlinkset, tolinkset, threelinkset, linksetptr);
    debug = olddebug;
    return true;
}

/**********************************************************************
 *
 **********************************************************************/
    bool
findnumoflinksfromtothreesp(Session *sess, Enfilade2d *spanfptr, typespecset fromvspecset, typespecset tovspecset,
         typespecset threevspecset, typeispan *orglrange, int *numptr)
{
    typelinkset linkset;
    int n;

    if (!findlinksfromtothreesp(sess, spanfptr, fromvspecset, tovspecset, threevspecset, orglrange, &linkset))
        return false;

    for (n = 0; linkset; linkset = linkset->next, ++n)
        ;

    *numptr = n;
    return true;
}

/**********************************************************************
 *
 **********************************************************************/
    bool
findnextnlinksfromtothreesp(Session *sess, typespecset fromvspecset, typespecset tovspecset, typespecset threevspecset,
    typeispan *orglrangeptr, IStreamAddr *lastlinkisaptr, typelinkset *nextlinksetptr, int *nptr)
{
    int n;
    typelinkset linkset;

    n = 0;
    *nextlinksetptr = NULL;

    if (!findlinksfromtothreesp(sess, spanf, fromvspecset, tovspecset, threevspecset, orglrangeptr, &linkset))
        return false;

    if (lastlinkisaptr->iszero())
        *nextlinksetptr = linkset;

    else {
        for (; linkset; linkset = linkset->next) {
            if (linkset->address == *lastlinkisaptr) {
                *nextlinksetptr = linkset->next;
                break;
            }
        }
    }

    if (!linkset) {
        *nextlinksetptr = NULL;
        *nptr = 0;
        return true;
    }

    for (linkset = *nextlinksetptr; linkset; linkset = linkset->next) {
        if (++n >= *nptr) {
            linkset->next = NULL;
            break;
        }
    }

    *nptr = n;
    return true;
}

/**********************************************************************
 *
 **********************************************************************/
    bool
finddocscontainingsp(Session *sess, typespanset ispanset, typelinkset *addresssetptr)
{
    Tumbler docid;
    Context *context, *c;
    typelinkset *headptr;
    typelink document;
    typespan docspace;

    headptr = addresssetptr;
    *addresssetptr = NULL;

    memset(&docspace, 0, sizeof(typespan));

//    tumblerincrement(&docspace.stream, 0, DOCISPAN, &docspace.stream);
    docspace.stream = docspace.stream.increment(0, DOCISPAN);

//    tumblerincrement(&docspace.width, 0, 1, &docspace.width);
    docspace.width = docspace.width.increment(0, 1);

    for (; ispanset; ispanset = ispanset->next) {
        context = retrieverestricted((CoreUpperCrum *) spanf, &docspace, ORGLRANGE, ispanset, SPANRANGE, (IStreamAddr *) NULL);

        for (c = context; c; c = c->nextcontext) {
            docid = c->totaloffset[ORGLRANGE];

            beheadtumbler(&docid, &document.address);

            if (isinlinklist(*headptr, &document.address))
                continue;

            document.itemid = LINKID;
            document.next = NULL;
            addresssetptr = (typelinkset *) onitemlist(sess, (typeitem *) &document, (typeitemset *) addresssetptr);
        }

        contextfree(context);
    }
#ifndef DISTRIBUTION
    if(debug)
        fooitemset("", (typeitem *) *headptr);
#endif

    return true;
}

/**********************************************************************
 *
 **********************************************************************/
    bool
retrieveendsetsfromspanf(Session *sess, typespecset specset, typespecset *fromsetptr, typespecset *tosetptr, typespecset *threesetptr)
{
    typespan fromspace, tospace, threespace;
    typesporglset sporglset;
    typesporglset fromsporglset;
    typesporglset tosporglset;
    typesporglset threesporglset;
    bool temp;

    memset(&fromspace, 0, sizeof(typespan));
    memset(&tospace, 0, sizeof(typespan));
    memset(&threespace, 0, sizeof(typespan));

    fromspace.stream.mantissa[0] = LINKFROMSPAN;
    fromspace.width.mantissa[0] = 1;

    tospace.stream.mantissa[0] = LINKTOSPAN;
    tospace.width.mantissa[0] = 1;

    threespace.stream.mantissa[0] = LINKTHREESPAN;
    threespace.width.mantissa[0] = 1;

    fromsporglset = tosporglset = threesporglset = NULL;

    if (!(specset2sporglset(sess, specset, &sporglset, NOBERTREQUIRED)
    && retrievesporglsetinrange(sess, sporglset, &fromspace, &fromsporglset)
    && linksporglset2specset(sess, &((typevspec *) specset)->docisa, fromsporglset, fromsetptr, NOBERTREQUIRED)
    && retrievesporglsetinrange(sess, sporglset, &tospace, &tosporglset)
    && linksporglset2specset(sess, &((typevspec *) specset)->docisa, tosporglset, tosetptr, NOBERTREQUIRED))) {

        return false;
    }

    if (threesetptr) {
        temp = (retrievesporglsetinrange(sess, sporglset, &threespace, &threesporglset)
             && linksporglset2specset(sess, &((typevspec *) specset)->docisa, threesporglset, threesetptr, NOBERTREQUIRED));

        return temp;
    }

    return true;
}

/**********************************************************************
 *
 **********************************************************************/
    bool
retrievesporglsetinrange(Session *sess, typesporglset sporglptr, typespan *whichspace, typesporglset *sporglsetptr)
{
    Context *context, *c, *tmp;
    typesporgl  *sporglset;

////////////////////////////////////////FIXME
//    for (; sporglptr; sporglptr = (typesporglset) sporglptr->xxxxsporgl.next) {
    for (; sporglptr; sporglptr = (typesporglset) ((typesporgl *) sporglptr)->next) {
////////////////////////////////////////FIXME

        context = retrieverestricted((CoreUpperCrum *) spanf, (typespan *) sporglptr, SPANRANGE, whichspace, ORGLRANGE,
                       (IStreamAddr *) NULL /*kluge to make links show thru to version &sporglptr->sporgladdress */);

        /* dumpcontextlist(context); */

        for (c = context; c;) {
            sporglset = (typesporgl *) taskalloc(sess, sizeof(typesporgl));
            contextintosporgl((type2dcontext *) c, (Tumbler *) NULL, sporglset, SPANRANGE);
            *sporglsetptr = (typesporglset) sporglset;
            sporglsetptr = (typesporglset *) &sporglset->next;

            tmp = c->nextcontext;

            /*
             * if (c->contexttype == GRAN)
             *     --contextnum;
             * else
             *     --c2dontextnum;
             *
             * efree((char *) c);
             */

            c = tmp;
        }

        contextfree(context);
    }

    return true;
}

/**********************************************************************
 *  Original Copyright � 1979-1999 Udanax.com.   All Rights Reserved
 **********************************************************************/
