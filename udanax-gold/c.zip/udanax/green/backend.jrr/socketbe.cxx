/**
 * @file  socketbe.cxx
 * @brief ???
 *
 * (to be defined)
 *
 **/

#include <fstream>
#include <iostream>
#include <stdio.h>
#include "common.h"
#include "players.h"
//#include "port.h"
#include <errno.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <sys/time.h>
#include <stdio.h>
#include <netdb.h>
#include <string.h>
#include <unistd.h>

#include <nana/nana.h>  // GNU Assertion/Logging Tool

#include "xanadu.h"

#define ERROR           -1
#define typerequest     int
#define MAX_PLAYERS     25       /* max # concurrent players */

extern bool establishprotocol(ifstream inp, ofstream outp);

/* These two are set in rcfile.c, possibly from the .backendrc file */
extern char hostname[];
extern int  portname;

int     fdtoplayer[32];
IStreamAddr defaultaccount("1.1.0.14");

PLAYER  player[MAX_PLAYERS];            /* player information   */
int     n_players = 0;
fd_set  inputfds;
int     nfds = 0;

int     main_socket = ERROR;      /* socket to accept connections on */


void  new_players(PLAYER player[], int *n_playersp, int block, Session *sess);
void  leave(PLAYER player[], int *xn_players);
int   open_sock();
void *crash(int);
bool  isthisusersdocument(Tumbler *tp);

/**********************************************************************
 *
 **********************************************************************/
    void
new_players(PLAYER player[], int *n_playersp, int block, Session *sess)
/* n_playersp:: number of players (incl comp)        */
/* block:: if nobody wants to join, wait on socket until somebody does. */
{
    fd_set                readfds;  /* for select() call    */
    int                   s;        /* temp holder for new socket   */
    int                   rc;       /* # ready selected sockets */
    struct sockaddr_in    from;     /* connection acceptor */
    int                   fromlen = sizeof(from);
    struct timeval        t;        /* don't let select() run forever */
//    int                   i;
//    FILE                 *temp;
//    char                  devicename[100];
//    int                   len;
//    typerequest           requestinstance;

    int open_sock();            /* to open main socket */

    if (main_socket == ERROR)
        main_socket = open_sock();

    /* set up 0 second timeout for use on  select() calls */
    /* well it  USED  to be  0 seconds, but that seems too fast now !<reg sep 10 1999>*/

    t.tv_sec  = 0L;
    t.tv_usec = 3L;

    FD_ZERO(&readfds);

    for (;;) {
        /* readfds = 1 << main_socket; */
        FD_SET(main_socket, &readfds);

        t.tv_sec  = 0L;
        t.tv_usec = 3L;

        if ((rc = select(32, &readfds, 0, 0, &t)) == -1) {
            perror("select");
            fflush(stdout);
            break;
        }

        if (rc > 0 || block) {
            if ((s = accept(main_socket, (sockaddr *) &from, &fromlen)) < 0) {
                perror("accept");
                fflush(stdout);
                break;
            }

            if (*n_playersp >= MAX_PLAYERS) {
                cerr << "TOOMANY frontends: won't log another one" << endl;
                close(s);

            } else {
                block = false;

#ifndef DISTRIBUTION
                cerr << "---------- Start of Session on Socket " << s << " ----------" << endl;
#endif

                /* read ttyname and open socket for it */

                player[*n_playersp].socket = s;
//                player[*n_playersp].inp.attach(s);
//                player[*n_playersp].outp.attach(s);

                sess->outp = player[*n_playersp].outp;
                sess->inp = player[*n_playersp].inp;

#ifndef DISTRIBUTION
                cerr << (char *) &(player[*n_playersp].account) << endl;
#endif

//                if (!establishprotocol(sess->inp, sess->outp))
//                    break;

                //getrequest(sess, &requestinstance);
                //getxaccount(sess, &(player[*n_playersp].account));
                //logaccount(&(player[*n_playersp].account));

                player[*n_playersp].wantsout = false;

                fdtoplayer[s] = *n_playersp;
                FD_SET(s, &inputfds);

//                nfds = max(s, nfds);
                nfds = (s > nfds) ? s : nfds;

                (*n_playersp)++;
                break;
            }
        } else
            break;
    }
}

/**********************************************************************
 *
 **********************************************************************/
    void
leave(PLAYER player[], int *xn_players)
{
    register int i;

    for (i = 0; i < *xn_players; i++)
        if (player[i].wantsout) {
	    FD_CLR(player[i].socket, &inputfds);

            if (close(player[i].socket) != 0) {
                cerr << "user " << i << ": ";
                perror("close player.socket");
            }

//            if (*xn_players > 1)
//                player[i] = player[*xn_players - 1];

            (*xn_players)--;
            --i;    /* since this entry is new, test again */
        }
}

/**********************************************************************
 *
 **********************************************************************/
    int
open_sock()  /* Open the main socket. */
{
    int                  s;
    struct  sockaddr_in  sockaddr;

    if ((s = socket(AF_INET, SOCK_STREAM, 0)) < 0) {
        perror("socket()");
        exit(1);
    }

/*
 *    struct hostent *host;
 *    if ((host = gethostbyname(hostname)) == NULL) {
 *        perror("gethostbyname()");
 *        exit(1);
 *    }
 */

    sockaddr.sin_family      = AF_INET;
    sockaddr.sin_port        = htons(portname);
    sockaddr.sin_addr.s_addr = /* inetaddr */ INADDR_ANY;

    if (bind(s, (struct sockaddr *) &sockaddr, sizeof(sockaddr)) < 0) {
        perror("bind()");
        exit(1);
    }

    if (listen(s, 0) < 0) {
        perror("listen()");
        exit(1);
    } else
        cerr << "Listening on TCP Port " << portname << ", Any Interface" << endl;

    return s;
}

/**********************************************************************
 *           Signal Handler
 **********************************************************************/
    void *
crash(int)
{
    int i;

    cerr << "CRASH while dealing with user " << user << endl;

    for (i = 0; i < 32; i++)
        close(i); /* BOO HISS: too many closes */

    exit(9);
}

/**********************************************************************
 *
 **********************************************************************/
    bool
isthisusersdocument(Tumbler *tp)
{
    /* was &(player[n_players].account)  !!!!!! GRRRR ECH */

    return tumbleraccounteq(tp, &(player[user].account));
}

/**********************************************************************
 *  Original Copyright � 1979-1999 Udanax.com.   All Rights Reserved
 **********************************************************************/
