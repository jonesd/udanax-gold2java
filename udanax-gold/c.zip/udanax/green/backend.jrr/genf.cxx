/**
 * @file  genf.cxx
 * @brief General Enfilade Manipulation Routines
 *
 * (to be defined)
 *
 **/

#include <nana/nana.h>  // GNU Assertion/Logging Tool

#include "xanadu.h"
#include "enf.h"
#include "coredisk.h"

extern int reservnumber;

/**********************************************************************
 *
 **********************************************************************/
    void
levelpush(CoreUpperCrum *fullcrumptr)
{
    I(fullcrumptr->isTopmost());

    CoreUpperCrum *newcrum = (CoreUpperCrum *) ((Enfilade *) fullcrumptr)->createCrum(fullcrumptr->height, fullcrumptr->cenftype);
    newcrum->isleftmost = true;

    transferloaf(fullcrumptr, newcrum);
    DiskLoafAddr temploafptr = fullcrumptr->sonorigin;

    fullcrumptr->sonorigin.diskblocknumber = NULLBLOCKNUM;
    fullcrumptr->height++;

    fullcrumptr->adoptAsSon((CoreCrum *) newcrum);
    newcrum->sonorigin = temploafptr;

    setwispupwards(newcrum, 1);
    newcrum->ivemodified();
    fullcrumptr->ivemodified(); /* is this redundant*/
}

/**********************************************************************
 *
 **********************************************************************/
    void
transferloaf(CoreUpperCrum *from, CoreUpperCrum *to)
{
    if (from->height == 0)  /* bottom crums */
        return;

    if (from->cenftype == SPAN || from->cenftype == POOM) {
        /* the sucker doesn't know what it is yet anyhow */
    }

    CoreUpperCrum *ptr   = (CoreUpperCrum *) from->leftSon();
    int nsons            = from->numberofsons;
    from->numberofsons   = 0;
    to->numberofsons     = nsons;
    ptr->leftbroorfather = (CoreCrum *) to;
    to->leftson          = (CoreCrum *) ptr;
    from->leftson        = NULL;

    /*
     * to->sonorigin        = from->sonorigin;
     * from->sonorigin      = NULLBLOCKNUM;
     */
}

/**********************************************************************
 *
 **********************************************************************/
    void
levelpull(CoreUpperCrum *fullcrumptr)
{
    /* CoreUpperCrum *ptr; */

    return;

/*
 *    if (!fullcrumptr->isTopmost())
 *#ifndef DISTRIBUTION
 *        gerror("Levelpull not called with fullcrum.");
 *#else
 *        gerror("");
 *#endif
 *
 *    if (fullcrumptr->numberofsons > 1)
 *        return;
 *
 *    if (fullcrumptr->height <= 1)
 *        return;
 *
 *    ptr = fullcrumptr->leftSon();
 *
 * //   dspadd(&fullcrumptr->cdsp, &ptr->cdsp, &fullcrumptr->cdsp, fullcrumptr->cenftype);
 *    fullcrumptr->cdsp = add(fullcrumptr->cdsp, ptr->cdsp, fullcrumptr->cenftype);
 *
 *    ptr->disown();
 *    fullcrumptr->height--;
 *    transferloaf(ptr, fullcrumptr);
 *    setwispupwards(fullcrumptr, 1);
 *    destroyCrum(ptr);
 */

}

/**********************************************************************
 *
 **********************************************************************/
    int
qerror(char *message)
{
    cerr << "Error: " << message << endl;
    abort();

    return 1;
}

/**********************************************************************
 *  Original Copyright � 1979-1999 Udanax.com.   All Rights Reserved
 **********************************************************************/
