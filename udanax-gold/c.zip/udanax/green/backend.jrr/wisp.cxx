/**
 * @file  wisp.cxx
 * @brief Integrated wid and dsp Arithmetic Routines
 *
 * (to be defined)
 *
 **/

#include <nana/nana.h>  // GNU Assertion/Logging Tool

#include "common.h"
#include "enf.h"
#include "tumbler.h"

/**********************************************************************
 *
 **********************************************************************/
    Widener
max(const Widener& a, const Widener& b, int enftype)
{
    unsigned loxize = dspsize(enftype);

    Widener c;

    while (loxize--)
        c[loxize] = max(a[loxize], b[loxize]);

    return c;
}

/**********************************************************************
 *
 **********************************************************************/
    Displacer
min(const Displacer& a, const Displacer& b, int enftype)
{
    unsigned loxize = dspsize(enftype);

    Displacer c;

    while (loxize--)
        c[loxize] = min(a[loxize], b[loxize]);

    return c;
}

/**********************************************************************
 *
 **********************************************************************/
    Displacer
sub(const Displacer& a, const Displacer& b, int enftype)
{
    unsigned loxize = dspsize(enftype);

    Widener c;

    while (loxize--)
        c[loxize] = a[loxize] - b[loxize];

    return * static_cast<Displacer*>(static_cast<Wisp*>(&c));
}

/**********************************************************************
 *
 **********************************************************************/
    Widener
sub(const Widener& a, const Widener& b, int enftype)
{
    unsigned loxize = dspsize(enftype);

    Widener c;

    const Displacer& aa = static_cast<const Displacer&>( static_cast<const Wisp&>(a) );
    const Displacer& bb = static_cast<const Displacer&>( static_cast<const Wisp&>(b) );

    while (loxize--)
        c[loxize] = aa[loxize] - bb[loxize];

    return c;
}

/**********************************************************************
 *
 **********************************************************************/
    Displacer
add(const Displacer& a, const Wisp& b, int enftype)
{
    unsigned loxize = dspsize(enftype);

    Displacer c;

    const Widener& bb = static_cast<const Widener&>(b);

    while (loxize--)
        c[loxize] = a[loxize] + bb[loxize];

    return c;
}

/**********************************************************************
 *
 **********************************************************************/
    Widener
add(const Widener& a, const Widener& b, int enftype)
{
    unsigned loxize = dspsize(enftype);

    Widener c;

    while (loxize--)
        c[loxize] = a[loxize] + b[loxize];

    return c;
}

/**********************************************************************
 *
 **********************************************************************/
/* Should be called whenever the wisp of a crum may need to
**   be recalculated by looking at its son.
*/
    bool
setwispupwards(CoreUpperCrum *ptr, int testflag)
{
    int ntimeschanged = 0;

    if (!ptr)
        return false;

    CoreUpperCrum *oldptr = ptr;
    CoreUpperCrum *father;

    bool changed;
    for (changed = true; changed && ptr; ptr = father) {
        father  = ptr->father();
        changed = setwisp((CoreCrum *) ptr);

        if (changed)
            ntimeschanged +=1;
    }

    if (ntimeschanged)
        oldptr->ivemodified();

    return /**/ (0 != ntimeschanged) /**/;
}

/**********************************************************************
 *
 **********************************************************************/
    void
setwispsofsons(CoreUpperCrum *ptr)
{
    ptr = (CoreUpperCrum *) ptr->leftmostBrother();
    while (ptr) {
        setwisp((CoreCrum *) ptr);
        ptr = (CoreUpperCrum *) ptr->rightBrother();
    }
}

/**********************************************************************
 *
 **********************************************************************/
/* the widditive operation in general */
    bool  /* return whether wisp of ptr has changed */
setwisp(CoreCrum *ptr)
{
    if (ptr->height == 0) // If Distance from Bottom of Tree is Zero,
        return false;     // We Don't Operate on the Bottom Crums

    switch (ptr->cenftype) {
    case GRAN:
        return setwidseq((CoreUpperCrum *) ptr);

    case SPAN:
    case POOM:
        return setwispnd((CoreUpperCrum *) ptr);

    default:
        gerror("setwisp: bad enftype\n");
    }

    return true;
}

/**********************************************************************
 *
 **********************************************************************/
/* the widditive operation in sequential enfilades */
    bool
setwidseq(CoreUpperCrum *father)
{
    if (father->height == 0) // If Distance from Bottom of Tree is Zero,
        return false;        // We Don't Operate on the Bottom Crums

    Widener sum;
    memset(&sum, 0, sizeof(sum));

    CoreCrum *ptr;
    for (ptr = father->leftSon(); ptr; ptr = ptr->rightBrother())
        sum = add(sum, ptr->cwid, GRAN);

    if (sum.isEqual(father->cwid, widsize(father->cenftype)))
        return false;

    father->cwid = sum;
    father->ivemodified();

    return true;
}

/**********************************************************************
 *
 **********************************************************************/
/* the widditive operation for nd */
    bool
setwispnd(CoreUpperCrum *father)
{
    CoreCrum *ptr;
    Displacer newdsp;
    Widener newwid, tempwid;
    bool lockiszerop;
    bool somethingchangedp = false; /* mindsp != 0 or some tempwid !=0 */

    if (father->height == 0)
        return false;

    /* remember original so can tell if changed */
    if ((ptr = father->leftSon()) == NULL) {
        gerror("in setwispnd null findleftson\n");
        memset(&father->cdsp, 0, sizeof(father->cdsp));
        memset(&father->cwid, 0, sizeof(father->cwid));
        father->ivemodified();
        return true;
    }

    /* find new upper-left corner */
    Displacer mindsp = ptr->cdsp; // Move a DSP/WISP
    for (ptr = ptr->rightBrother(); ptr; ptr = ptr->rightBrother())
        mindsp = min(mindsp, ptr->cdsp, ptr->cenftype);

    lockiszerop = mindsp.isEmpty(dspsize(father->cenftype));
    if (!lockiszerop) {
        somethingchangedp = true;
        newdsp = add(father->cdsp, mindsp, father->cenftype);

    } else
        newdsp = father->cdsp; // Move a DSP/WISP

    /* find new lower-right corner at the same time that */
    /*  we are readjusting the son's dsps to compensate */
    /*  for change in the father */

    memset(&newwid, 0, sizeof(newwid));
    for (ptr = father->leftSon(); ptr; ptr = ptr->rightBrother()) {
        if (!lockiszerop) {
            ptr->modified = true;   /* father gets ivemodified soon */
            ptr->cdsp = sub(ptr->cdsp, mindsp, ptr->cenftype);

        }

        Displacer d = add(ptr->cdsp, ptr->cwid, ptr->cenftype);
	tempwid = * static_cast<Widener *>(static_cast<Wisp *>(&d));

        newwid = max(newwid, tempwid, ptr->cenftype);
    }

    if (!somethingchangedp && !newwid.isEqual(father->cwid, widsize(father->cenftype)))
        somethingchangedp = true;

    if (!somethingchangedp)
        return false;

    father->cdsp = newdsp; // Move a DSP/WISP
    father->cwid = newwid;
    father->ivemodified();

    return true;
}

/**********************************************************************
 *
 **********************************************************************/
/* reset father's wid but leave dsp alone */
    void
setwidnd(CoreUpperCrum *father)
{
    CoreCrum *ptr;
    Widener newwid;

    for (ptr = father->leftSon(); ptr; ptr = ptr->rightBrother()) {
        memset(&newwid, 0, sizeof(newwid));

        newwid = max(newwid, ptr->cwid, ptr->cenftype);
    }

    if (!father->cwid.isEqual(newwid, widsize(father->cenftype))) {
        father->cwid = newwid;
        father->ivemodified();
    }
}

/**********************************************************************
 *
 **********************************************************************/
/* --------- lock routines deal with full lock ------------- */
/* a lock is an array of loxize tumblers */

    bool
Wisp::isEmpty(unsigned loxize)
{
    Tumbler *lock = &dsas[0];

    while (loxize--)
        if (!(lock++)->iszero())
            return false;

    return true;
}

/**********************************************************************
 *
 **********************************************************************/
    bool
Wisp::isEqual(Wisp& other, unsigned loxize)
{
    Tumbler *lock1 = &dsas[0];
    Tumbler *lock2 = &other.dsas[0];

    while (loxize--)
        if (lock1++ != lock2++)
            return false;

    return true;
}

/**********************************************************************
 *
 **********************************************************************/
/* Returns whether ALL the lock is 1 story */
    bool
lockis1story(Tumbler *lock, unsigned loxize)
{
    while (loxize--)
        if (!is1story(lock++))
            return false;

    return true;
}

/**********************************************************************
 *
 **********************************************************************/
/*
 *    void
 *setwispallthewayupwards(CoreUpperCrum *ptr)
 *{
 *    CoreUpperCrum *father, *oldptr;
 *    bool setwisp();
 *    bool changed;
 *
 *    if (!ptr)
 *        return;
 *
 *    oldptr = ptr;
 *    for (; ptr; ptr = father) {
 *        father = ptr->father();
 *        for (ptr = ptr->leftmostBrother(ptr); ptr; ptr = ptr->rightBrother())
 *            setwisp(ptr);
 *    }
 *
 *    if (true && changed)
 *        oldptr->ivemodified();
 *}
 */

/**********************************************************************
 *  Original Copyright � 1979-1999 Udanax.com.   All Rights Reserved
 **********************************************************************/
