/**
 * @file  enfilade.cxx
 * @brief
 *
 * ???
 *
 **/

#include <nana/nana.h>  // GNU Assertion/Logging Tool

#include "xanadu.h"
#include "enf.h"
#include "ndenf.h"

/* use with GRAN */

static bool fillBottomCrum(CoreBottomCrum *ptr, Tumbler *crumboundary, CoreBottomCrum::typegranbottomcruminfo *info);
static void findLastBottomCrumAddr(CoreBottomCrum *ptr, IStreamAddr *offset);
static void klugefindisatoinsertnonmolecule(CoreUpperCrum *fullcrumptr, Hint *hintptr, IStreamAddr *isaptr);

CoreCrum *Enfilade::grimreaper;

/**********************************************************************
 *
 **********************************************************************/
    CoreCrum *
Enfilade::createCrum(int crumheight, int enftype)
{
    CoreCrum *ptr = createCrumInternal(crumheight, enftype, NULL);

    if (grimreaper) {
        ptr->nextcrum = grimreaper;
        ptr->prevcrum = grimreaper->prevcrum;

        grimreaper->prevcrum->nextcrum = ptr;
        grimreaper->prevcrum = ptr;

    } else
        grimreaper = ptr->nextcrum = ptr->prevcrum = ptr;

    return ptr;
}

/**********************************************************************
 *
 **********************************************************************/
    void
Enfilade::destroyCrum(CoreCrum *ptr)
{
    if (ptr->age == RESERVED)
        gerror("destroyCrum called with RESERVED crum.\n");

    if (grimreaper == ptr)
        grimreaper = grimreaper->nextcrum;

    if (grimreaper == ptr)
        grimreaper = NULL;

    ptr->nextcrum->prevcrum = ptr->prevcrum;
    ptr->prevcrum->nextcrum = ptr->nextcrum;

    /* zzz should it decrement usecount here sometimes? */

    efree((char *) ptr);
}

/**********************************************************************
 *
 **********************************************************************/
    CoreCrum *
Enfilade::createCrumInternal(int crumheight, int enftype, CoreCrum *allocated)
{
    unsigned crumsize;

    if (crumheight == 0) {
        switch (enftype) {
        case GRAN:
            crumsize = sizeof(CoreBottomCrum);
            break;
        case SPAN:
        case POOM:
            crumsize = sizeof(Core2dBottomCrum);
            break;
        default:
            I(false); // Invalid Type of Enfilade
            return NULL;
        }

    } else
        crumsize = sizeof(CoreUpperCrum);

    CoreCrum *ptr;
    if (!allocated)
        ptr = (CoreCrum *) eallocwithtag(crumsize, (tagtype) (crumheight > 0 ? CUCTAG : CBCTAG));
    else
        ptr = allocated;

    ptr->height          = crumheight;
    ptr->isapex          = false;
    ptr->cenftype        = enftype;
    ptr->modified        = true /* false */;
    ptr->isleftmost      = false;
    ptr->age             = NEW;
    ptr->leftbroorfather = NULL;
    ptr->rightbro        = NULL;

    memset(&ptr->cdsp, 0, sizeof(ptr->cdsp));
    memset(&ptr->cwid, 0, sizeof(ptr->cwid));

    if (crumheight > 0) {
        ((CoreUpperCrum *) ptr)->numberofsons = 0;
        ((CoreUpperCrum *) ptr)->leftson = NULL;
        ((CoreUpperCrum *) ptr)->sonorigin.diskblocknumber = NULLBLOCKNUM;

    } else {
        if (enftype == GRAN) {
            memset(&((CoreBottomCrum *) ptr)->cinfo, 0, sizeof(((CoreBottomCrum *) ptr)->cinfo));
            ((CoreBottomCrum *) ptr)->cinfo.infotype = CoreBottomCrum::GRANCLEARLYILLEGALINFO;
        } else
            memset(&((Core2dBottomCrum *) ptr)->c2dinfo, 0, sizeof(((Core2dBottomCrum *) ptr)->c2dinfo));
    }

    return ptr;
}

/**********************************************************************
 *
 **********************************************************************/
    CoreUpperCrum *
Enfilade::create(int enftype)
{
    // Create an Upper Crum to Act as the Root Node
    CoreUpperCrum *fullcrumptr /*fixme = (CoreUpperCrum *) createCrum(1, enftype) */ ;
    fullcrumptr->cenftype   = enftype;
    fullcrumptr->isapex     = true;
    fullcrumptr->isleftmost = true;

    // Create a Null Bottom Crum to Act as Son of Root
    CoreCrum *ptr /*fixme = createCrum(0, enftype) */ ;
    fullcrumptr->adoptAsSon(ptr);

    if (enftype == GRAN)
        ((CoreBottomCrum *) ptr)->cinfo.infotype = CoreBottomCrum::GRANNULL; /* KLUGE will this work?? */

    ptr->ivemodified();

    /*
     * if (enftype == GRAN) {
     *     levelpush(fullcrumptr);
     *     fullcrumptr->leftson->adoptAsRightBrother(createcrum(0, enftype));
     *     fullcrumptr->leftson->rightbro->adoptAsSon(createcrum(0, enftype));
     *     ptr = fullcrumptr->leftson->leftson;
     *     tumblerincrement(&(ptr->cwid.dsas[WIDTH]), 2, 1, &(ptr->cwid.dsas[WIDTH]));
     *     setwispupwards(ptr, 1);
     * }
     */

    return fullcrumptr;
}

/**********************************************************************
 *
 **********************************************************************/
    bool
Enfilade::isEmpty()
{
    if (!isTopmost())
        return false;

    switch (cenftype) {
    case GRAN:
        return cwid.isEmpty( widsize(cenftype) );

    case SPAN:
    case POOM:
        return cwid.isEmpty( widsize(cenftype) )
            && cdsp.isEmpty( dspsize(cenftype) );

    default :
        I(false); // Invalid Type of Enfilade
    }

    return false;
}

/**
 * Traverse
 *  Method on CoreUpperCrum/Enfilade
 **/
    CrumContext *
Enfilade1d::locate(Tumbler *address)
{
    Displacer offset;
    memset(&offset, 0, sizeof(offset));

    // In Enfilade 'fullcrumptr' at Location 'address', ...
    return findcbcseqcrum(&offset, address);
}

/**********************************************************************
 *
 **********************************************************************/
/* all findcbc* routines are recursive with depth of
**   recursion == height of enfilade being searched
*/
/* Model-T like retrieves */
    CrumContext *
Enfilade1d::findcbcseqcrum(Displacer *offsetptr, Tumbler *address)
{
    CoreUpperCrum *ptr = this;

    // For Each Brother Node to the Right...
    for (; ptr->rightBrother(); ptr = (CoreUpperCrum *) ptr->rightbro) {

        // Determine Down Which Crum We Should Look for the Given Address
        // TOMYLEFT, ONMYLEFTBORDER or THRUME
        if (whereoncrum(ptr, offsetptr, address, WIDTH) <= THRUME)
            break; // Ah, Found the Crum Containing the Given Address...

        // Increment Stream Displacement As We Move from Left to Right on This Level
        *offsetptr = add(*offsetptr, ptr->cwid, ptr->cenftype);
    }

    if (ptr->height == 0) // Got to Bottom, Return (BottomCrum, StreamOffset) Tuple
        return new CrumContext((CoreBottomCrum *) ptr, offsetptr);
    
     // No More Brothers on Right, but Not at Bottom Yet
    ptr = (CoreUpperCrum *) ptr->leftSon(); // Descend *One* More Level
    return ((Enfilade1d *) ptr)->findcbcseqcrum(offsetptr, address);
}

/**********************************************************************
 * (appears to never be used)
 **********************************************************************/
    void
Enfilade1d::remove(Tumbler *address, int index)
{
    CrumContext *context = locate(address);
    CoreBottomCrum *ptr  = (CoreBottomCrum *) context->corecrum;

    destroyCrum((CoreCrum *) &context->corecrum);
    context->corecrum = NULL;
    delete context;

    setwispupwards(ptr->father(), 1);
    recombine(ptr->father());
}

/**********************************************************************
 * Insert New Node (GRANORGL) or Text (GRANTEXT) into Grand Enfilade
 **********************************************************************/
    void
Enfilade1d::insert(Tumbler *address, CoreBottomCrum::typegranbottomcruminfo *info)
{
    Tumbler nextaddress = *address;

    // *********************************************************************
    CrumContext    *ctxt   = locate(address);                           // *
    CoreBottomCrum *ptr    = ctxt->corecrum;                            // *
    Displacer       offset = ctxt->totaloffset;                         // *
    delete ctxt;                                                        // *
    // *********************************************************************

    if (info->infotype == CoreBottomCrum::GRANTEXT /* crum can be extended */
    && ptr->cinfo.infotype == CoreBottomCrum::GRANTEXT
    && ptr->cinfo.granstuff.textstuff.textlength < GRANTEXTLENGTH) {

        if (!fillBottomCrum(ptr, &nextaddress, info)) {
            ptr->ivemodified();
            return;
        }
    }

    ptr->reserve();
    CoreCrum *newcrum = createCrum(0, (int) ptr->cenftype);
    newcrum->reserve();
    ptr->adoptAsRightBrother(newcrum);
    newcrum->ivemodified();

    bool splitsomething = splitcrumupwards( newcrum->father() );
    if (info->infotype == CoreBottomCrum::GRANORGL)
        info->granstuff.orglstuff.orglptr->leftbroorfather = newcrum;

//    moveinfo(info, &((CoreBottomCrum *) newcrum)->cinfo);
    ((CoreBottomCrum *) newcrum)->cinfo = *info;

    if (ptr->cwid[WIDTH].iszero()) {  /* last crum in granf */
        newcrum->cwid[WIDTH].clear();

        ptr->cwid[WIDTH] = nextaddress - offset[WIDTH];

    } else {
        Displacer reach      = add(offset, ptr->cwid, GRAN);
        newcrum->cwid[WIDTH] = reach[WIDTH] - nextaddress;
        ptr->cwid[WIDTH]     = nextaddress - offset[WIDTH];
    }

    ptr->ivemodified();
    setwispupwards(ptr->father(), 0);
    setwispupwards(newcrum->father(), 1);

    splitsomething |= splitcrumupwards( ptr->father());
    ptr->rejuvinate();
    newcrum->rejuvinate();

    if (splitsomething)
        recombine(this);
}

/**********************************************************************
 *
 **********************************************************************/
    bool
Enfilade1d::addrExists(IStreamAddr *isaptr)
{
    Context *context = retrieve(this, isaptr, WIDTH);

    bool ret = (context->totaloffset[0] == *isaptr);

    contextfree(context);

    return ret;
}

/**********************************************************************
 *       Find IStreamAddress At Which to Insert New Material
 *
 * The IStreamAddr is returned via the isaptr Argument.
 **********************************************************************/
    bool
Enfilade1d::findAddrToInsertAt(Hint *hintptr, IStreamAddr *isaptr)
{
    if (!addrExists(&hintptr->hintisa)) {
        if (hintptr->subtype != ATOM) {
            klugefindisatoinsertnonmolecule(this, hintptr, isaptr);
            tumblerjustify(isaptr);
            return true;
        }

        return false;
    }

    if (hintptr->subtype == ATOM)
        findAddrToInsertMolecule(hintptr, isaptr);
    else
        findAddrToInsertNonMolecule(hintptr, isaptr);

    tumblerjustify(isaptr);
    return true;
}

/**********************************************************************
 *
 **********************************************************************/
    void
Enfilade1d::findAddrToInsertMolecule(Hint *hintptr, IStreamAddr *isaptr)
{
    IStreamAddr upperbound = hintptr->hintisa.increment(2, hintptr->atomtype + 1);
    IStreamAddr lowerbound(0);

    findPrevAddr(&upperbound, &lowerbound);

    if (tumblerlength(&hintptr->hintisa) == tumblerlength(&lowerbound)) {
        *isaptr = lowerbound.increment(2, hintptr->atomtype);
        *isaptr = isaptr->increment(1, 1);

    } else if (hintptr->atomtype == TEXTATOM) {
        *isaptr = lowerbound.increment(0, 1);

    } else if (hintptr->atomtype == LINKATOM) {
        *isaptr = hintptr->hintisa.increment(2, 2);

        if (lowerbound < *isaptr)
            *isaptr = isaptr->increment(1, 1);
        else
            *isaptr = lowerbound.increment(0, 1);

    } else
        I(false);
}

/**********************************************************************
 *
 **********************************************************************/
    void
Enfilade1d::findAddrToInsertNonMolecule(Hint *hintptr, IStreamAddr *isaptr)
{
    int depth      = (hintptr->supertype == hintptr->subtype) ? 1 : 2;
    int hintlength = tumblerlength(&hintptr->hintisa);

    IStreamAddr upperbound = hintptr->hintisa.increment(depth - 1, 1);
    IStreamAddr lowerbound(0);

    findPrevAddr(&upperbound, &lowerbound);
    tumblertruncate(&lowerbound, hintlength + depth, isaptr);

    int n = (tumblerlength(isaptr) == hintlength) ? depth : 0;
    *isaptr = isaptr->increment(n, 1);
}

/**********************************************************************
 *  Give an IStreamAddr, find the Existing IStreamAddr Previous To It
 **********************************************************************/
    void
Enfilade1d::findPrevAddr(IStreamAddr *upperbound, IStreamAddr *offset)
{
    if (height == 0) { // If We're Walking the Bottom Tree Layer...
        findLastBottomCrumAddr((CoreBottomCrum *) this, offset);
        return;
    }

    CoreCrum *ptr;
    for (ptr = leftSon(); ptr; ptr = ptr->rightBrother()) {
        int tmp = whereoncrum(ptr, (Displacer *) offset, upperbound, WIDTH);

        if (tmp == THRUME || tmp == ONMYRIGHTBORDER || !ptr->rightbro) {
            findPrevAddr(upperbound, offset);
            return;

        } else
            *offset = *offset + ptr->cwid[WIDTH];
    }
}

/**********************************************************************
 *
 **********************************************************************/
    static bool
fillBottomCrum(CoreBottomCrum *ptr, Tumbler *crumboundary, CoreBottomCrum::typegranbottomcruminfo *info)
{
    /** first     copy the text from the info to the crum that ptr points to */

    int crumlength    = ptr->cinfo.granstuff.textstuff.textlength;
    int remainingroom = GRANTEXTLENGTH - crumlength;
    int textlength    = info->granstuff.textstuff.textlength;

    if (remainingroom > textlength) {
        memmove((char *) &(ptr->cinfo.granstuff.textstuff) + crumlength, &info->granstuff.textstuff.textstring, textlength);
        ptr->cinfo.granstuff.textstuff.textlength = crumlength + textlength;

        *crumboundary = crumboundary->increment(0, textlength);

        return false;

    } else {
        memmove((char *) (&(ptr->cinfo.granstuff.textstuff)) + crumlength, &info->granstuff.textstuff.textstring, remainingroom);
        ptr->cinfo.granstuff.textstuff.textlength = GRANTEXTLENGTH;

        *crumboundary = crumboundary->increment(0, remainingroom);
    }

    /* then take whats left in info and renormalize it */
    info->granstuff.textstuff.textlength -= remainingroom;

    char temp[GRANTEXTLENGTH];
    memmove(temp, &info->granstuff.textstuff.textstring[remainingroom], info->granstuff.textstuff.textlength);
    memset(info->granstuff.textstuff.textstring, 0, GRANTEXTLENGTH);
    memmove(info->granstuff.textstuff.textstring, temp, info->granstuff.textstuff.textlength);

    return true;
}

/**********************************************************************
 *  Offset is last isa if non-text or one char
 **********************************************************************/
    static void
findLastBottomCrumAddr(CoreBottomCrum *ptr, IStreamAddr *offset)
{
    if (ptr->cinfo.infotype == CoreBottomCrum::GRANTEXT)
        *offset = offset->increment(0, ptr->cinfo.granstuff.textstuff.textlength - 1);
}

/**********************************************************************
 *
 **********************************************************************/
    static void
klugefindisatoinsertnonmolecule(CoreUpperCrum *fullcrumptr, Hint *hintptr, IStreamAddr *isaptr)
{
/*
 *    IStreamAddr upperbound, lowerbound;
 *    int depth, hintlength;
 *
 *    depth = hintptr->supertype == hintptr->subtype ? 1 : 2;
 *    hintlength = tumblerlength(&hintptr->hintisa);
 *    tumblerincrement(&hintptr->hintisa, depth - 1, 1, &upperbound);
 *    memset(&lowerbound, 0, sizeof(lowerbound));
 *    findpreviousisagr(fullcrumptr, &upperbound, &lowerbound);
 *    tumblertruncate(&lowerbound, hintlength + depth, isaptr);
 *    tumblerincrement(isaptr, tumblerlength(isaptr) == hintlength ? depth : 0, 1, isaptr);
*/

//#ifdef UnDeFIned
//    tumblercopy(/*&*/hintptr/*->hintisa*/, isaptr); /* ECH 8-30-88 was hintptr, not &hintptr->hintisa */
//#endif

//    tumblercopy(&hintptr->hintisa, isaptr);
    *isaptr = hintptr->hintisa;
}

/**********************************************************************
 * origin:: origin is vsa of crum; note that here they're wids,
 * width:: and in deletend they're single tumblers
 **********************************************************************/
    void
Enfilade2d::insertnd(Session *sess, Displacer *origin, Widener *width, Core2dBottomCrum::type2dbottomcruminfo *infoptr, int index)
{
    int bothertorecombine;

//    int olddiff = widdiffs();
    int oldheight = height;

    if ((*width)[index].iszero())
        gerror("zero width in insertnd\n");

    Tumbler oldwid = cwid[V_BASIS];

    switch (cenftype) {
    case POOM:
        makegappm(sess, this, origin, width);
        checkspecandstringbefore();
        setwispupwards(this, 0);
        bothertorecombine = doinsertnd(this, origin, width, infoptr, index);
        setwispupwards(this, 1);

        /* fixincoresubtreewids(this); //1999 // a temp kluge zzz till we find where setwisp isnt called//
            this is a brute  force kluge, if this fixes anything it means that the wids aren't being set properly somplace else probably near here */

        break;

    case SPAN:
        bothertorecombine = doinsertnd(this, origin, width, infoptr, index);
        setwispupwards(this, 1);

        /* fixincoresubtreewids(this); //1999 // a temp kluge zzz till we find where setwisp isnt called//
           this is a brute  force kluge, if this fixes anything it means that the wids aren't being set properly somplace else probably near here */

        break;

    default:
        gerror("insertnd: bad enftype\n");
	return;
    }

    if (/* true || */ bothertorecombine || (height != oldheight)) {
#ifndef DISTRIBUTION
        if (!bothertorecombine)
            cerr << "insertnd recombineing and notbothertorecombine" << endl;
#endif
        recombine(this);
    }

//    int newdiff = widdiffs();

#ifndef DISTRIBUTION
//    if (false && (cenftype == POOM) && olddiff != newdiff) {
//        cerr << "insertnd  possible error dumping widdiffs " << olddiff << ' ' << newdiff << endl;
//        dump /* wholesubtree */ ((CoreCrum *) fullcrumptr);
//        cerr << "insertnd not match after insert asserting" << endl;
//        asserttreeisok((CoreCrum *) fullcrumptr);
//    }
#endif

#ifndef DISTRIBUTION
    if (false && cenftype == POOM && cwid[V_BASIS] == oldwid) { /* remember links this code doesnt work */
        cerr << "insertnd no change after insert" << endl;
        cerr << oldwid;
        dumpwholesubtree(this);
        gerror("insertnd no change after insert");
    }
#endif

#ifdef UNdeFIned
    /**/ fixincoresubtreewids(this); /*1999 a temp kluge zzz till we find where setwisp isnt called */
      /* this is a brute  force kluge, if this fixes anything it means that the wids aren't being set properly somplace else probably near here */

    switch (cenftype) {
    case POOM:
        dumppoomwisps(this);
        break;

    case SPAN:
        showspanf(this);
        break;
    }
#endif
}

/**********************************************************************
 *
 **********************************************************************/
    int
Enfilade2d::widdiffs()
{
    if (cenftype != POOM)
        return 0;

    int i = lastdigitintumbler(&cwid[I_BASIS]);
    int v = lastdigitintumbler(&cwid[V_BASIS]);

    return i - v;
}

/**********************************************************************
 *  Original Copyright � 1979-1999 Udanax.com.   All Rights Reserved
 **********************************************************************/
