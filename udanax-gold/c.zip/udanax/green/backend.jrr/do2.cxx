/**
 * @file  do2.cxx
 * @brief Miscellaneous Bottom-of-the-Top Routines
 *
 * (to be defined)
 *
 **/

#include <nana/nana.h>  // GNU Assertion/Logging Tool

#include "xanadu.h"
#include "enf.h"

/**********************************************************************
 *
 **********************************************************************/
    bool
specset2ispanset(Session *sess, typespec *specset, typeispanset *ispansetptr, int type)
{
    typeorgl docorgl;
    typeispanset *save;

    save = ispansetptr;
    *ispansetptr = NULL;

    for (; specset; specset = (typespec *) ((typeitemheader *) specset)->next) {
        if (((typeitemheader *) specset)->itemid == ISPANID) {
            *ispansetptr = (typeispanset) specset;
            ispansetptr = (typeispanset *) &((typeitemheader *) specset)->next;

        } else if (((typeitemheader *) specset)->itemid == VSPECID) {
            typevspec *vspec = (typevspec *) specset;

            if (vspec->docisa.iszero())
#ifndef DISTRIBUTION
                qerror("retrieve called with docisa 0\n");
#else
                gerror("");
#endif

            if (!(findorgl(sess, granf, &((typevspec *) specset)->docisa, &docorgl, type) /*BERT*/
            && (ispansetptr = vspanset2ispanset(sess, docorgl, ((typevspec *) specset)->vspanset, ispansetptr))))

                return false; /*zzzz*/
        }
    }

    /* zzz *ispansetptr = NULL; */

    return true;
}

/**********************************************************************
 *
 **********************************************************************/
    bool
tumbler2spanset(Session *sess, IStreamAddr *tumblerptr, typespanset *spansetptr)
{
    typespan *spanptr = (typespan *) taskalloc(sess, sizeof(typespan));

    spanptr->next   = NULL;
    spanptr->itemid = ISPANID;
    spanptr->stream = *tumblerptr;

    spanptr->width.clear();

//    tumblerincrement(&spanptr->width, tumblerlength(tumblerptr) - 1 /*zzzzz*/, 1, &spanptr->width);
    spanptr->width = spanptr->width.increment(tumblerlength(tumblerptr) - 1, +1);

    *spansetptr = spanptr;

    return true;
}

/**********************************************************************
 *
 **********************************************************************/
/*
 *    bool
 *spanset2tumbler(Session *sess, typespanset spanset, Tumbler *tmblptr)
 *{
 *    int *ealloc(), *eallocwithtag();
 *
 *    if (spanset->next || !spanset->width.iszero())
 *        return false;
 *
 *    tmblptr = (Tumbler *) eallocwithtag(sizeof(Tumbler), TUMBLERTAG);
 *
 *    movetumbler(&spanset->stream, tmblptr // SUSPECT //);
 *    *tmblptr = spanset->stream;
 *
 *    return true;
 *}
 */

/**********************************************************************
 *
 **********************************************************************/
Hint::Hint(int typeabove, int typebelow, int typeofatom, IStreamAddr *isaptr)
{
    supertype = typeabove;
    subtype   = typebelow;
    atomtype  = typeofatom;
    hintisa   = *isaptr;
}

/**********************************************************************
 *
 **********************************************************************/
//    bool
//Hint:isValid()
//{
//    if ((supertype < NODE)
//    ||  (supertype > DOCUMENT)
//    ||  (subtype < ACCOUNT)
//    ||  (subtype > ATOM)
//    ||  (atomtype < 0)
//    ||  (atomtype > 2)
//    ||  (subtype < supertype)
//    || ((subtype - supertype) > 1)
//    || ((subtype == ATOM) == !atomtype) ) {
//
//#ifndef DISTRIBUTION
//        /*
//         * cerr << "bad hint:"
//         *      << " supertype = " << hintptr->supertype
//         *      << " subtype = "   << hintptr->subtype
//         *      << " atomtype = " << hintptr->atomtype << endl;
//         * cerr << "hintisa = " << hintptr->hintisa);
//         */
//
//        gerror("bad hint");
//#else
//        gerror("");
//#endif
//    }
//}

/**********************************************************************
 *
 **********************************************************************/
    bool  /* vsa 1 if zenf, else w/in vspan of fullcrum */
acceptablevsa(Tumbler *vsaptr, typeorgl orglptr)
{
    return true;
}

/**********************************************************************
 *
 **********************************************************************/
    bool
insertendsetsinspanf(Session *sess, Enfilade2d *spanfptr, IStreamAddr *linkisaptr, typesporglset fromsporglset,
    typesporglset tosporglset, typesporglset threesporglset)
{
    if (!(insertspanf(sess, spanfptr, linkisaptr, fromsporglset, LINKFROMSPAN)
    &&    insertspanf(sess, spanfptr, linkisaptr, tosporglset, LINKTOSPAN)))
        return false;

    if (threesporglset)
        if (!insertspanf(sess, spanfptr, linkisaptr, threesporglset, LINKTHREESPAN))
            return false;

    return true;
}

/**********************************************************************
 *
 **********************************************************************/
    bool
insertendsetsinorgl(Session *sess, IStreamAddr *linkisaptr, typeorgl link, VStreamAddr *fromvsa, typesporglset fromsporglset,
       VStreamAddr *tovsa, typesporglset tosporglset, VStreamAddr *threevsa, typesporglset threesporglset)
{
    if (!(insertpm(sess, linkisaptr, link, fromvsa, fromsporglset)
    &&    insertpm(sess, linkisaptr, link, tovsa, tosporglset)))
        return false;

    if (threevsa && threesporglset) {
        if (!insertpm(sess, linkisaptr, link, threevsa, threesporglset))
            return false;
    }
    return true;
}

/**********************************************************************
 *
 **********************************************************************/
    bool
findnextlinkvsa(Session *sess, IStreamAddr *docisaptr, VStreamAddr *vsaptr)
{
    VStreamAddr firstlink(0);

    firstlink = firstlink.increment(0, 2);
    firstlink = firstlink.increment(1, 1);

    typevspan vspan;
    doretrievedocvspan(sess, docisaptr, &vspan);
    VStreamAddr vspanreach = vspan.stream + vspan.width;

    if (vspanreach < firstlink)
        *vsaptr = firstlink;
    else
        *vsaptr = vspanreach;

    return true;
}

/**********************************************************************
 *
 **********************************************************************/
    bool
setlinkvsas(Tumbler *fromvsaptr, Tumbler *tovsaptr, Tumbler *threevsaptr)
{
    fromvsaptr->clear();
    *fromvsaptr = fromvsaptr->increment(0, 1);

    *fromvsaptr = fromvsaptr->increment(1, 1);

    tovsaptr->clear();
    *tovsaptr = tovsaptr->increment(0, 2);

    *tovsaptr = tovsaptr->increment(1, 1);

    if (threevsaptr) {
        threevsaptr->clear();
        *threevsaptr = threevsaptr->increment(0, 3);
        *threevsaptr = threevsaptr->increment(1, 1);
    }

    return true;
}

/**********************************************************************
 *
 **********************************************************************/
    bool
ispansetandspecsets2spanpairset(Session *sess, typeispanset ispanset, typespecset specset1, typespecset specset2, typespanpairset *pairsetptr)
{
    if (ispanset == NULL) {
        *pairsetptr = NULL;

    } else {
        restrictspecsetsaccordingtoispans(sess, ispanset, &specset1, &specset2);
        makespanpairset(sess, ispanset, specset1, specset2, pairsetptr);
    }

    return true;
}

/**********************************************************************
 *  Original Copyright � 1979-1999 Udanax.com.   All Rights Reserved
 **********************************************************************/
