/**********************************************************************
 * Copyright 2002 Jeff Rush <jrush@taupro.com>
 * Original Copyright 1979-2002 Udanax.com
 *
 * This file is part of the Udanax xanalogical storage system.
 *
 * Udanax is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * Udanax is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with Udanax; if not, write to the Free Software Foundation,
 * Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 **********************************************************************/

/**
 * @file  u_links.cxx
 * @brief ???
 *
 * (to be defined)
 *
 **/

/* Modification History:
 * $Log: u_links.cxx,v $
 * Revision 1.6  2002/05/28 04:01:48  jrush
 * Sources changed to comply with GPL licensing.
 *
 * Revision 1.5  2002/04/08 20:46:46  jrush
 * Grouped python type structures and functions into
 * udanaxmodule.h.  Also eliminated use of global sessx
 * variable and use the one in Session objects instead.
 *
 * Revision 1.4  2002/04/08 18:58:07  jrush
 * Renamed xxxObject to xxxPyObject for easier to follow Doxygen graphs.
 *
 * Revision 1.3  2002/04/07 22:09:38  jrush
 * Added documentation header to top of source file.
 *
 *
 */

static char doclinks__doc__ [] =
"This type provides access to operating system functionality that is\n\
standardized by the C Standard and the POSIX standard (a thinly\n\
disguised Unix interface).  Refer to the library manual and\n\
corresponding Unix manual entries for more information on calls.
";

/* DocLinks subobjects of a Document object */

#include "udanaxmodule.h"

static void      DocLinks_dealloc(DocLinksPyObject *self);
static PyObject *DocLinks_getattr(DocLinksPyObject *self, char *name);
static PyObject *DocLinks_str(DocLinksPyObject *obj);
static PyObject *DocLinks_repr(DocLinksPyObject *obj);

static int
DocLinks_sq_length(DocLinksPyObject *self)
{
    typevspan *vspanset;

    bool f = doretrievedocvspanset(self->x_doc->x_sess->x_sess, &self->x_doc->x_docid, &vspanset);
    if (!f) {
        //TBD: need to distinguish btw fail due to empty and fail for other reasons
        return 0; // Length of Zero
    }

    if (vspanset->next)
        return vspanset->next->width.mantissa[0];
    else
        return 0;
}

static PySequenceMethods DocLinks_SequenceMethods = {
    (inquiry)          &DocLinks_sq_length,                   /*sq_length*/
    (binaryfunc)       0,                                     /*sq_concat*/
    (intargfunc)       0,                                     /*sq_repeat*/
    (intargfunc)       0,                                       /*sq_item*/
    (intintargfunc)    0,                                      /*sq_slice*/
    (intobjargproc)    0,                                   /*sq_ass_item*/
    (intintobjargproc) 0,                                  /*sq_ass_slice*/
    (objobjproc)       0,                                   /*sq_contains*/
    (binaryfunc)       0,                             /*sq_inplace_concat*/
    (intargfunc)       0,                             /*sq_inplace_repeat*/
};

PyTypeObject DocLinks_Type = {
    /* The ob_type field must be initialized in the module init function
     * to be portable to Windows without using C++.
     */
    PyObject_HEAD_INIT(NULL)
    0,                                                          /*ob_size*/
    "DocLinks",                                                 /*tp_name*/
    sizeof(DocLinksPyObject),                              /*tp_basicsize*/
    0,                                                      /*tp_itemsize*/
    /* Methods to implement standard operations */
    (destructor) DocLinks_dealloc,                           /*tp_dealloc*/
    0,                                                         /*tp_print*/
    (getattrfunc) DocLinks_getattr,                          /*tp_getattr*/
    (setattrfunc) 0,                                         /*tp_setattr*/
    0,                                                       /*tp_compare*/
    (reprfunc) DocLinks_repr,                                   /*tp_repr*/
    /* Method suites for standard classes */
    0,                                                     /*tp_as_number*/
    &DocLinks_SequenceMethods,                           /*tp_as_sequence*/
    0,                                                    /*tp_as_mapping*/
    /* More standard operations (here for binary compatibility) */
    0,                                                          /*tp_hash*/
    (ternaryfunc) 0,                                            /*tp_call*/
    (reprfunc) DocLinks_str,                                     /*tp_str*/
    (getattrofunc) 0,                                       /*tp_getattro*/
    (setattrofunc) 0,                                       /*tp_setattro*/
    /* Functions to access object as input/output buffer */
    (PyBufferProcs *) 0,                                   /*tp_as_buffer*/
    /* Flags to define presence of optional/expanded features */
    (long) 0,                                                  /*tp_flags*/
    (char *) doclinks__doc__,                    /* Documentation string */
    /* call function for all accessible objects */
    (traverseproc) 0,                                       /*tp_traverse*/
    /* delete references to contained objects */
    (inquiry) 0,                                               /*tp_clear*/
    /* rich comparisons */
    (richcmpfunc) 0,                                     /*tp_richcompare*/
    /* weak reference enabler */
    (long) 0,                                         /*tp_weaklistoffset*/
};

PyObject *
wrapDocLinksPyObject(DocumentPyObject *docobj)
{
    DocLinksPyObject *self;

    self = PyObject_New(DocLinksPyObject, &DocLinks_Type);
    if (self == NULL)
        return NULL;

    self->x_doc = docobj;
    Py_INCREF(self->x_doc);

    return (PyObject *) self;
}

static void
DocLinks_dealloc(DocLinksPyObject *self)
{
    PyObject_Del(self);
}

/* DocLinks methods */

static PyObject *
DocLinks_str(DocLinksPyObject *self)
{
    char buffer[128];

    if (tumbler_to_str(&self->x_doc->x_docid, buffer, sizeof(buffer)))
        return PyString_FromString(buffer);
    else
	Py_INCREF(Py_None);
	return Py_None;
}

static PyObject *
DocLinks_repr(DocLinksPyObject *obj)
{
    char buffer[128] = "DocLinks(docid='";

    if (tumbler_to_str(&obj->x_doc->x_docid, &buffer[strlen(buffer)], sizeof(buffer) - strlen(buffer))) {
        strcat(buffer, "')");
        return PyString_FromString(buffer);
    } else
	Py_INCREF(Py_None);
	return Py_None;
}

static PyMethodDef DocLinks_methods[] = {
    {NULL,     NULL}  /* sentinel */
};

static PyObject *
DocLinks_getattr(DocLinksPyObject *self, char *name)
{
    return Py_FindMethod(DocLinks_methods, (PyObject *)self, name);
}
