/**********************************************************************
 * Copyright 2002 Jeff Rush <jrush@taupro.com>
 * Original Copyright 1979-2002 Udanax.com
 *
 * This file is part of the Udanax xanalogical storage system.
 *
 * Udanax is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * Udanax is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with Udanax; if not, write to the Free Software Foundation,
 * Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 **********************************************************************/

/**
 * @file  u_document.cxx
 * @brief ???
 *
 * (to be defined)
 *
 **/

/* Modification History:
 * $Log: u_document.cxx,v $
 * Revision 1.4  2002/05/28 04:01:48  jrush
 * Sources changed to comply with GPL licensing.
 *
 * Revision 1.3  2002/04/10 18:01:54  jrush
 * Renamed class typeisa to IStreamAddr.
 *
 * Revision 1.2  2002/04/09 21:45:46  jrush
 * Renamed class 'tumbler' to 'Tumbler', for consistency with Python sources,
 * and changed typeisa from typedef to a subclass, in preparation for cleaning
 * up the type/class tree.
 *
 * Revision 1.1  2002/04/08 20:44:19  jrush
 * Renamed u_opendoc.xxx to u_document.cxx.
 *
 * Revision 1.5  2002/04/08 18:58:07  jrush
 * Renamed xxxObject to xxxPyObject for easier to follow Doxygen graphs.
 *
 * Revision 1.4  2002/04/07 22:09:38  jrush
 * Added documentation header to top of source file.
 *
 *
 */

static char document__doc__ [] =
"This type provides access to operating system functionality that is\n\
standardized by the C Standard and the POSIX standard (a thinly\n\
disguised Unix interface).  Refer to the library manual and\n\
corresponding Unix manual entries for more information on calls.
";

/* Document objects */

#include "udanaxmodule.h"

static void      Document_dealloc(DocumentPyObject *self);
static PyObject *Document_getattr(DocumentPyObject *self, char *name);
static int       Document_setattr(DocumentPyObject *self, char *name, PyObject *v);
static PyObject *Document_str(DocumentPyObject *obj);
static PyObject *Document_repr(DocumentPyObject *obj);

PyTypeObject Document_Type = {
    PyObject_HEAD_INIT(NULL)
    0,                                                          /*ob_size*/
    "Document",                                                 /*tp_name*/
    sizeof(DocumentPyObject),                              /*tp_basicsize*/
    0,                                                      /*tp_itemsize*/
    /* Methods to implement standard operations */
    (destructor) Document_dealloc,                           /*tp_dealloc*/
    0,                                                         /*tp_print*/
    (getattrfunc) Document_getattr,                          /*tp_getattr*/
    (setattrfunc) Document_setattr,                          /*tp_setattr*/
    0,                                                       /*tp_compare*/
    (reprfunc) Document_repr,                                   /*tp_repr*/
    /* Method suites for standard classes */
    0,                                                     /*tp_as_number*/
    0,                                                   /*tp_as_sequence*/
    0,                                                    /*tp_as_mapping*/
    /* More standard operations (here for binary compatibility) */
    0,                                                          /*tp_hash*/
    (ternaryfunc) 0,                                            /*tp_call*/
    (reprfunc) Document_str,                                     /*tp_str*/
    (getattrofunc) 0,                                       /*tp_getattro*/
    (setattrofunc) 0,                                       /*tp_setattro*/
    /* Functions to access object as input/output buffer */
    (PyBufferProcs *) 0,                                   /*tp_as_buffer*/
    /* Flags to define presence of optional/expanded features */
    (long) 0,                                                  /*tp_flags*/
    (char *) document__doc__,                    /* Documentation string */
    /* call function for all accessible objects */
    (traverseproc) 0,                                       /*tp_traverse*/
    /* delete references to contained objects */
    (inquiry) 0,                                               /*tp_clear*/
    /* rich comparisons */
    (richcmpfunc) 0,                                     /*tp_richcompare*/
    /* weak reference enabler */
    (long) 0,                                         /*tp_weaklistoffset*/
};

PyObject *
wrapDocumentPyObject(Tumbler *docid, char type, SessionPyObject *sess)
{
    DocumentPyObject *self;

    self = PyObject_New(DocumentPyObject, &Document_Type);
    if (self == NULL)
        return NULL;

    self->x_attr = NULL;
    self->x_type = type;

    self->x_sess = sess;
    Py_INCREF(sess);

    tumblercopy(docid, &self->x_docid);

    return (PyObject *) self;
}

static void
Document_dealloc(DocumentPyObject *self)
{
//    printf("dealloc() method of document invoked\n");
//    doclose(sessx, &self->x_docid);

    Py_XDECREF(self->x_sess);
    Py_XDECREF(self->x_attr);
    PyObject_Del(self);
}

/* Document methods */

static PyObject *
Document_str(DocumentPyObject *obj)
{
    char buffer[128];

    if (tumbler_to_str(&obj->x_docid, buffer, sizeof(buffer)))
        return PyString_FromString(buffer);
    else
	Py_INCREF(Py_None);
	return Py_None;
}

static PyObject *
Document_repr(DocumentPyObject *obj)
{
    char buffer[128] = "Document('";

    if (tumbler_to_str(&obj->x_docid, &buffer[strlen(buffer)], sizeof(buffer) - strlen(buffer))) {
        char s[2];

        strcat(buffer, "', mode='");
        s[0] = obj->x_type;
        s[1] = '\0';
        strcat(buffer, s);
        strcat(buffer, "')");
        return PyString_FromString(buffer);
    } else
	Py_INCREF(Py_None);
	return Py_None;
}

static char Document_close__doc__[] =
"close() -> None\n\
Close the document.\n";

static PyObject *
Document_close(DocumentPyObject *self, PyObject *args)
{
    if (!PyArg_ParseTuple(args, ":close"))
        return NULL;

    printf("close() method of document invoked\n");
    bool f = doclose(self->x_sess->x_sess, &self->x_docid);
    if (f) {
        self->x_type = 'c';

        Py_INCREF(Py_None);
        return Py_None;
    } else {
        Py_INCREF(Py_None);
        return Py_None;
    }
}

static char Document_fetch__doc__[] =
"fetch(spectuple) -> contenttuple\n\
\n";

static PyObject *
Document_fetch(DocumentPyObject *self, PyObject *args)
{
    PyObject *spectuple;

    if (!PyArg_ParseTuple(args, "O:fetch", &spectuple))
        return NULL;

    if (!PyTuple_Check(spectuple)) {
        PyErr_SetString(PyExc_AttributeError,
                        "argument must be a tuple of vspans");        
        return NULL;
    }

    typespec *spec        = (typespec *) new(self->x_sess->x_sess) typevspec;
    spec->xxxvspec.next   = NULL; // Single-Item specset, containing a list of vspans
    spec->xxxvspec.itemid = VSPECID;
    tumblercopy(&self->x_docid, &spec->xxxvspec.docisa);

    if (!PyArg_ParseSpanTuple(self->x_sess, spectuple, &spec->xxxvspec.vspanset))
        return NULL;

    typespecset specset = spec;

    printf("----- DUMPITEM of SPECSET\n");
    dumpitemset((typeitem *) specset);
    printf("----- END OF DUMPITEM of SPECSET\n");

    typevstuffset  vstuffset; // Set coming out

    bool f = doretrievev(self->x_sess->x_sess, specset, &vstuffset);
    if (f) {
        printf("doretrievev succeeded\n");

        dumpitemset((typeitem *) vstuffset);

        int nitems;
        typevstuff *vs;

        for (vs = vstuffset, nitems = 0; vs; vs = (typevstuff *) vs->xxxtext.next, nitems++)
            ;
        printf("There are %u items in the result\n", nitems);

        PyObject *t = PyTuple_New(nitems);

        for (vs = vstuffset, nitems = 0; vs; vs = (typevstuff *) vs->xxxtext.next, nitems++) {
            if (vs->xxxtext.itemid == TEXTID) {
                PyObject *stringobj = PyString_FromStringAndSize(vs->xxxtext.string, vs->xxxtext.length);
                PyTuple_SetItem(t, nitems, stringobj);
            }
            if (vs->xxxlink.itemid == LINKID) {
                PyObject *linkisa = wrapTumblerPyObject(&vs->xxxlink.address);
                //TBD -- check success of wrapping operation (can fail)
                PyTuple_SetItem(t, nitems, linkisa);
            }
        }
        return t;

    } else {
        printf("doretrievev failed\n");

        Py_INCREF(Py_None);
        return Py_None;
    }

    Py_INCREF(Py_None);
    return Py_None;
}

static char Document_copy__doc__[] =
"copy(vaddr, specset) -> None\n\
\n";

static PyObject *
Document_copy(DocumentPyObject *self, PyObject *args)
{
    PyObject *vaddrobj;
    PyObject *specsetobj;

    if (!PyArg_ParseTuple(args, "OO:copy", &vaddrobj, &specsetobj))
        return NULL;

    IStreamAddr vsa;
    if (!PyArg_ParseTumbler(vaddrobj, &vsa))
        return NULL;

    typespecset zzspecset;
    typespecset *specset = &zzspecset;

    int itemno = 0;
    int nspecs = PyTuple_Size(specsetobj);

    while (nspecs) {
        typespec *spec        = new(self->x_sess->x_sess) typespec;
        spec->xxxispan.next   = NULL; // Single-Item specset, containing a list of vspans
        spec->xxxispan.itemid = ISPANID;

        PyObject *spantuple = PyTuple_GetItem(specsetobj, itemno++);

        if (!PyArg_ParseSpan(spantuple, &spec->xxxispan.stream, &spec->xxxispan.width))
            return 0;

        *specset = spec;
        specset  = (typespecset *) &spec->xxxispan.next;
        nspecs--;
    }

    printf("----- DUMPITEM of SPECSET\n");
    dumpitemset((typeitem *) specset);
    printf("----- END OF DUMPITEM of SPECSET\n");

    bool f = docopy(self->x_sess->x_sess, &self->x_docid, &vsa, (typespecset) specset);
    if (f) {
        printf("docopy succeeded\n");

        Py_INCREF(Py_None);
        return Py_None;
    } else {
        printf("docopy failed\n");

        Py_INCREF(Py_None);
        return Py_None;
    }

    Py_INCREF(Py_None);
    return Py_None;
}

static char Document_createlink__doc__[] =
"createlink(specset1, specset2, specset3) -> linkid\n\
Create a link with the specified end-sets and return its identifier.
The new link is appended to the link space of iddoc.  iddoc is the home
for the idlink.  iddoc must already be open for writing.\n";

static PyObject *
Document_createlink(DocumentPyObject *self, PyObject *args)
{
    PyObject *specset1obj;
    PyObject *specset2obj;
    PyObject *specset3obj;

    if (!PyArg_ParseTuple(args, "OOO:createlink", &specset1obj, &specset2obj, &specset3obj))
        return NULL;

    typespecset *specset1;
    typespecset *specset2;
    typespecset *specset3;

    printf("PARSE SPEC1\n");
    if (!ParseSpecSet(self->x_sess, specset1obj, &specset1))
        return NULL;
    printf("RETURN FROM PARSE SPEC1\n");

    if (!ParseSpecSet(self->x_sess, specset2obj, &specset2))
        return NULL;

    if (!ParseSpecSet(self->x_sess, specset3obj, &specset3))
        return NULL;

    printf("----- DUMPITEM of SPECSET1\n");
    dumpitemset((typeitem *) specset1);
    printf("----- END OF DUMPITEM of SPECSET1\n");

    printf("----- DUMPITEM of SPECSET2\n");
    dumpitemset((typeitem *) specset2);
    printf("----- END OF DUMPITEM of SPECSET2\n");

    printf("----- DUMPITEM of SPECSET3\n");
    dumpitemset((typeitem *) specset3);
    printf("----- END OF DUMPITEM of SPECSET3\n");

    IStreamAddr linkid;
    bool f = docreatelink(self->x_sess->x_sess, &self->x_docid, (typespecset) specset1, (typespecset) specset2, (typespecset) specset3, &linkid);
    if (f) {
        printf("docreatelink succeeded\n");

        return wrapTumblerPyObject(&linkid);
    } else {
        printf("docreatelink failed\n");

        Py_INCREF(Py_None);
        return Py_None;
    }

    Py_INCREF(Py_None);
    return Py_None;
}

static PyMethodDef Document_methods[] = {
    {"createlink", (PyCFunction) Document_createlink,  METH_VARARGS, Document_createlink__doc__},
    {"copy",       (PyCFunction) Document_copy,        METH_VARARGS, Document_copy__doc__},
    {"fetch",      (PyCFunction) Document_fetch,       METH_VARARGS, Document_fetch__doc__},
    {"close",      (PyCFunction) Document_close,       METH_VARARGS, Document_close__doc__},
    {NULL,         NULL}  /* sentinel */
};

static PyObject *
Document_getattr(DocumentPyObject *self, char *name)
{
//BUG: successive accesses to .bytes or .links results in repeated wrappings and a memory leak.

    if (strcmp(name, "bytes") == 0) {
        if (self->x_attr == NULL) {
            self->x_attr = PyDict_New();
            if (self->x_attr == NULL)
                return NULL;
        }
        PyObject *v = wrapDocBytesPyObject(self);
        if (v == NULL)
            return NULL;
	    
        PyDict_SetItemString(self->x_attr, "bytes", v);
        Py_INCREF(v);
        return v;
    }
    
    if (strcmp(name, "links") == 0) {
        if (self->x_attr == NULL) {
            self->x_attr = PyDict_New();
            if (self->x_attr == NULL)
                return NULL;
        }

        PyObject *v = wrapDocLinksPyObject(self);
        if (v == NULL)
            return NULL;
	    
        PyDict_SetItemString(self->x_attr, "links", v);
        Py_INCREF(v);
        return v;
    }

    if (self->x_attr != NULL) {
        PyObject *v = PyDict_GetItemString(self->x_attr, name);
        if (v != NULL) {
            Py_INCREF(v);
            return v;
        }
    }

    return Py_FindMethod(Document_methods, (PyObject *)self, name);
}

static int
Document_setattr(DocumentPyObject *self, char *name, PyObject *v)
{
    if (self->x_attr == NULL) {
        self->x_attr = PyDict_New();
        if (self->x_attr == NULL)
            return -1;
    }

    if (strcmp(name, "bytes") == 0 || strcmp(name, "links") == 0) {
        PyErr_SetString(PyExc_AttributeError,
                        "cannot delete/modify specified attribute");
        return -1;
    }

    if (v == NULL) {
        int rv = PyDict_DelItemString(self->x_attr, name);
        if (rv < 0)
            PyErr_SetString(PyExc_AttributeError,
                            "delete non-existing Document attribute");
        return rv;
    } else
        return PyDict_SetItemString(self->x_attr, name, v);
}
