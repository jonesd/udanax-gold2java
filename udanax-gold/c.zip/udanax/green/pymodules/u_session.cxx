/**********************************************************************
 * Copyright 2002 Jeff Rush <jrush@taupro.com>
 * Original Copyright 1979-2002 Udanax.com
 *
 * This file is part of the Udanax xanalogical storage system.
 *
 * Udanax is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * Udanax is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with Udanax; if not, write to the Free Software Foundation,
 * Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 **********************************************************************/

/**
 * @file  u_session.cxx
 * @brief ???
 *
 * (to be defined)
 *
 **/

/* Modification History:
 * $Log: u_session.cxx,v $
 * Revision 1.8  2002/05/28 04:01:48  jrush
 * Sources changed to comply with GPL licensing.
 *
 * Revision 1.7  2002/04/13 14:08:35  jrush
 * Changed typedef of structs into just structs, for C++ style.
 *
 * Revision 1.6  2002/04/12 12:02:01  jrush
 * Added database name to SessionPyObject, and tried to permit multiple
 * database sessions and the ability to close and reopen the database
 * within a process.
 *
 * Revision 1.5  2002/04/10 18:01:54  jrush
 * Renamed class typeisa to IStreamAddr.
 *
 * Revision 1.4  2002/04/08 20:46:46  jrush
 * Grouped python type structures and functions into
 * udanaxmodule.h.  Also eliminated use of global sessx
 * variable and use the one in Session objects instead.
 *
 * Revision 1.3  2002/04/08 18:58:07  jrush
 * Renamed xxxObject to xxxPyObject for easier to follow Doxygen graphs.
 *
 * Revision 1.2  2002/04/07 22:09:38  jrush
 * Added documentation header to top of source file.
 *
 *
 */

static char session__doc__ [] =
"This type provides access to operating system functionality that is\n\
standardized by the C Standard and the POSIX standard (a thinly\n\
disguised Unix interface).  Refer to the library manual and\n\
corresponding Unix manual entries for more information on calls.
";

/* Session objects */

#include <string.h>

#include "udanaxmodule.h"

static void      Session_dealloc(SessionPyObject *self);
static PyObject *Session_getattr(SessionPyObject *self, char *name);
static int       Session_setattr(SessionPyObject *self, char *name, PyObject *v);
static PyObject *Session_str(SessionPyObject *obj);
static PyObject *Session_repr(SessionPyObject *obj);

PyTypeObject Session_Type = {
    PyObject_HEAD_INIT(NULL)
    0,                                                          /*ob_size*/
    "Session",                                                  /*tp_name*/
    sizeof(SessionPyObject),                               /*tp_basicsize*/
    0,                                                      /*tp_itemsize*/
    /* Methods to implement standard operations */
    (destructor) Session_dealloc,                            /*tp_dealloc*/
    0,                                                         /*tp_print*/
    (getattrfunc) Session_getattr,                           /*tp_getattr*/
    (setattrfunc) Session_setattr,                           /*tp_setattr*/
    0,                                                       /*tp_compare*/
    (reprfunc) &Session_repr,                                   /*tp_repr*/
    /* Method suites for standard classes */
    0,                                                     /*tp_as_number*/
    0,                                                   /*tp_as_sequence*/
    0,                                                    /*tp_as_mapping*/
    /* More standard operations (here for binary compatibility) */
    0,                                                          /*tp_hash*/
    (ternaryfunc) 0,                                            /*tp_call*/
    (reprfunc) 0,                                                /*tp_str*/
    (getattrofunc) 0,                                       /*tp_getattro*/
    (setattrofunc) 0,                                       /*tp_setattro*/
    /* Functions to access object as input/output buffer */
    (PyBufferProcs *) 0,                                   /*tp_as_buffer*/
    /* Flags to define presence of optional/expanded features */
    (long) 0,                                                  /*tp_flags*/
    (char *) session__doc__,                     /* Documentation string */
    /* call function for all accessible objects */
    (traverseproc) 0,                                       /*tp_traverse*/
    /* delete references to contained objects */
    (inquiry) 0,                                               /*tp_clear*/
    /* rich comparisons */
    (richcmpfunc) 0,                                     /*tp_richcompare*/
    /* weak reference enabler */
    (long) 0,                                         /*tp_weaklistoffset*/
};

PyObject *
SetPyErrFromSession(SessionPyObject *sess)
{
    char temp[128];

    switch (sess->x_sess->errorcode) {
    case ERR_CLOSE_WO_OPEN:
           PyErr_SetString(PyExc_ValueError,
                        "attempt to close document never opened");
           break;
    case ERR_OPEN_COPY:
           PyErr_SetString(PyExc_ValueError,
                        "unable to open a copy of document");
           break;
    default:
           sprintf(temp, "unknown udanax error code %d", sess->x_sess->errorcode);
           PyErr_SetString(PyExc_ValueError, temp);
           break;
    }
    return NULL;
}

static bool
validaccount(char *username, char *password, IStreamAddr *acct)
{
    if (strcmp(username, "1.7.0.9") != 0 || strcmp(password, "test") != 0) {
        PyErr_SetString(PyExc_ValueError,
                        "username or password not recognized");
        return false;
    }

    if (!str_to_tumbler(username, acct))
        return false;

    return true;
}

PyObject *
wrapSessionPyObject(char *username, char *password, char *database)
{
    SessionPyObject *self = PyObject_New(SessionPyObject, &Session_Type);
    if (self == NULL)
        return NULL;

    self->x_attr     = NULL;
    self->x_username = strdup(username);
    self->x_sess     = new Session;

    initmagicktricks();

    if (!validaccount(username, password, &self->x_sess->account))
        return NULL;

    return (PyObject *) self;
}

static void
Session_dealloc(SessionPyObject *self)
{
    //FIXME: need to flush all open BERTs for this session

//    writeenfilades();
//    closediskfile();

    self->x_sess->free();
    delete self->x_sess;
    delete self->x_username;

    Py_XDECREF(self->x_attr);
    PyObject_Del(self);
}

/* Session methods */

static char Session_close__doc__[] =
"close() -> None\n\
Describes where links attach to contents.  Each returned spec-set
describes the union of all end-sets of the given type that attach
to the supplied spec-setcontents.\n";

static PyObject *
Session_close(SessionPyObject *self, PyObject *args)
{
    if (!PyArg_ParseTuple(args, ":close"))
        return NULL;

    writeenfilades();
    closediskfile();

    Py_INCREF(Py_None);
    return Py_None;
}

static PyObject *
Session_repr(SessionPyObject *self)
{
    char buffer[128];

    sprintf(buffer, "Session(username='%s\', acct='", self->x_username);

    if (tumbler_to_str(&self->x_sess->account, &buffer[strlen(buffer)], sizeof(buffer) - strlen(buffer) - 1))
        strcat(buffer, "')");

    return PyString_FromString(buffer);
}

static char Session_dump__doc__[] =
"dump() -> None\n\
Open a pseudo-terminal, returning open fd's for both master and slave end.\n";

static PyObject *
Session_dump(SessionPyObject *self, PyObject *args)
{
    if (!PyArg_ParseTuple(args, ":dump"))
        return NULL;

    showsubtree((typecorecrumhedr *) granf);

    Py_INCREF(Py_None);
    return Py_None;
}

static char Session_gdump__doc__[] =
"gdump() -> None\n\
Open a pseudo-terminal, returning open fd's for both master and slave end.\n";

static PyObject *
Session_gdump(SessionPyObject *self, PyObject *args)
{
    char *graphlabel = "";
    char *filename = NULL;

    if (!PyArg_ParseTuple(args, "s|s:gdump", &filename, &graphlabel))
        return NULL;

    graphwholetree(filename, (typecorecrum *) granf, graphlabel);

    Py_INCREF(Py_None);
    return Py_None;
}

static char Session_sdump__doc__[] =
"sdump() -> None\n\
Open a pseudo-terminal, returning open fd's for both master and slave end.\n";

static PyObject *
Session_sdump(SessionPyObject *self, PyObject *args)
{
    char *graphlabel = "";
    char *filename = NULL;

    if (!PyArg_ParseTuple(args, "s|s:sdump", &filename, &graphlabel))
        return NULL;

    graphwholetree(filename, (typecorecrum *) spanf, graphlabel);

    Py_INCREF(Py_None);
    return Py_None;
}

static char Session_allocnode__doc__[] =
"allocnode(nodeid) -> nodeid | None\n\
Allocate a entry in the Docuverse for the specified node address.  If such\n\
an entry already exists, no exception is raised and the call is a NOP.\n";

static PyObject *
Session_allocnode(SessionPyObject *self, PyObject *args)
{
    char *s = NULL;

    if (!PyArg_ParseTuple(args, "s:allocnode", &s))
        return NULL;

    IStreamAddr isa;

    if (str_to_tumbler(s, &isa)) {

        //TBD -- validate nodeid for reasonableness

        bool f = docreatenode_or_account(self->x_sess, &isa);
        if (f) {
            return wrapTumblerPyObject(&isa);
        } else {
            Py_INCREF(Py_None);
            return Py_None;
        }
    }
    return NULL;
}

static char Session_allocacct__doc__[] =
"allocacct(acctid) -> opendoc_fd\n\
Open a pseudo-terminal, returning open fd's for both master and slave end.\n";

static PyObject *
Session_allocacct(SessionPyObject *self, PyObject *args)
{
    char *s = NULL;

    if (!PyArg_ParseTuple(args, "s:allocacct", &s))
        return NULL;

    IStreamAddr isa;

    if (str_to_tumbler(s, &isa)) {
        bool f = docreatenode_or_account(self->x_sess, &isa);
        if (f) {
            return wrapTumblerPyObject(&isa);
        } else
            return SetPyErrFromSession(self);
    }
    return NULL;
}

static char Session_allocdoc__doc__[] =
"allocdoc() -> opendoc_fd\n\
Open a pseudo-terminal, returning open fd's for both master and slave end.\n";

static PyObject *
Session_allocdoc(SessionPyObject *self, PyObject *args)
{
    if (!PyArg_ParseTuple(args, ":allocdoc"))
        return NULL;

    IStreamAddr new_isa;

    bool f = docreatenewdocument(self->x_sess, &new_isa);
    if (f) {
        return wrapTumblerPyObject(&new_isa);
    } else
        return SetPyErrFromSession(self);
}

static char Session_allocver__doc__[] =
"allocver(docid) -> opendoc_fd\n\
Open a pseudo-terminal, returning open fd's for both master and slave end.\n";

static PyObject *
Session_allocver(SessionPyObject *self, PyObject *args)
{
    char *s = NULL;

    if (!PyArg_ParseTuple(args, "s:allocver", &s))
        return NULL;

    IStreamAddr doc_isa;
    IStreamAddr new_isa;

    if (str_to_tumbler(s, &doc_isa)) {
        bool f = docreatenewversion(self->x_sess, &doc_isa, &doc_isa, &new_isa);
        if (f) {
            return wrapTumblerPyObject(&new_isa);
        } else
            return SetPyErrFromSession(self);
    } else
        return NULL;
}

static char Session_open__doc__[] =
"open(docid, type, mode) -> opendoc_fd\n\
mode ::= `1'read-only delim | `2'read-write delim\n\
copy-switch ::= `1'fail-on-conflict delim | `2'copy-on-conflict delim | `3'always-copy delim\n\
Open a pseudo-terminal, returning open fd's for both master and slave end.\n";

static PyObject *
Session_open(SessionPyObject *self, PyObject *args)
{
    char *docstr = NULL;
    char *typestr = NULL;
    char *modestr = NULL;

    if (!PyArg_ParseTuple(args, "sss:open", &docstr, &typestr, &modestr))
        return NULL;

    IStreamAddr doc_isa;
    IStreamAddr new_isa;

    int type, mode;

    switch (*typestr) {
    case 'r':  type = READBERT;   break;
    case 'w':  type = WRITEBERT;  break;
    default:
        PyErr_SetString(PyExc_ValueError,
                        "open() type arg must be 'r' or 'w'");
        return NULL;
    }

    switch (*modestr) {
    case 'f':  mode = BERTMODEONLY;    break; // Fail on Conflict
    case 'd':  mode = BERTMODECOPYIF;  break; // Copy on Conflict
    case 'c':  mode = BERTMODECOPY;    break; // Always Copy

    default:
        PyErr_SetString(PyExc_ValueError,
                        "open() mode arg must be 'f', 'd', or 'c'");
        return NULL;
    }

    if (!str_to_tumbler(docstr, &doc_isa))
        return NULL;

    printf("ABOUT TO CALL doopen()\n");
    bool f = doopen(self->x_sess, &doc_isa, &new_isa, type, mode);
    printf("RETURNED FROM CALL TO doopen()\n");
    if (!f)
        return SetPyErrFromSession(self);

    return wrapDocumentPyObject(&new_isa, *typestr, self);
}

static char Session_finddocscontaining__doc__[] =
"finddocscontaining(specset) -> (docid, ...) | None\n\
Return identifiers for all documents that include any of the contents
specified by the argument.  All documents with contents in spec-set
must be open for reading.\n";

static PyObject *
Session_finddocscontaining(SessionPyObject *self, PyObject *args)
{
    PyObject *specsetobj;

    if (!PyArg_ParseTuple(args, "O:finddocscontaining", &specsetobj))
        return NULL;

    typespecset *specset;

    int itemno = 0;
    int nspecs = PyTuple_Size(specsetobj);

    while (nspecs) {
        typespec *spec        = new(self->x_sess) typespec;
        spec->xxxispan.next   = NULL; // Single-Item specset, containing a list of vspans
        spec->xxxispan.itemid = ISPANID;

        PyObject *spantuple = PyTuple_GetItem(specsetobj, itemno++);

        if (!PyArg_ParseSpan(spantuple, &spec->xxxispan.stream, &spec->xxxispan.width))
            return 0;

        *specset = spec;
        specset  = (typespecset *) &spec->xxxispan.next;
        nspecs--;
    }

    printf("----- DUMPITEM of SPECSET\n");
    dumpitemset((typeitem *) specset);
    printf("----- END OF DUMPITEM of SPECSET\n");

    typelinkset  addrset; // Set coming out

    bool f = dofinddocscontaining(self->x_sess, (typespecset) specset, &addrset);
    if (f) {
        printf("finddocscontaining succeeded\n");

        dumpitemset((typeitem *) addrset);

        int nitems;
        typelink *addr;

        for (addr = addrset, nitems = 0; addr; addr = (typelink *) addr->next, nitems++)
            ;
        printf("There are %u items in the result\n", nitems);

        PyObject *t = PyTuple_New(nitems);

        for (addr = addrset, nitems = 0; addr; addr = (typelink *) addr->next, nitems++) {
            if (addr->itemid == ADDRESSID) {
                PyObject *linkisa = wrapTumblerPyObject(&addr->address);
                //TBD -- check success of wrapping operation (can fail)
                PyTuple_SetItem(t, nitems, linkisa);
            } else {
                Py_XDECREF(t);
                PyErr_SetString(PyExc_ValueError,
                                "unknown itemid in return from dofinddocscontaining()");
                return NULL;
            }
        }
        return t;
    } else {
        printf("finddocscontaining failed\n");

        Py_INCREF(Py_None);
        return Py_None;
    }

    Py_INCREF(Py_None);
    return Py_None;
}

static char Session_followlink__doc__[] =
"followlink(endno, linkid) -> opendoc_fd\n\
Return an end-set of idlink . end-switch determines the end-set returned.\n";

static PyObject *
Session_followlink(SessionPyObject *self, PyObject *args)
{
    int endno = 0;
    char *s = NULL;

    if (!PyArg_ParseTuple(args, "is:followlink", &endno, &s))
        return NULL;

    IStreamAddr link_isa;
    typespecset specset;

    if (str_to_tumbler(s, &link_isa)) {
        printf("Following link ");
        puttumbler(stdout, &link_isa);
        printf(", endpoint %u\n", endno);

        bool f = dofollowlink(self->x_sess, &link_isa, &specset, endno);
        if (f) {
            printf("dofollowlink succeeded\n");

            int n;
            typespec *spec;

            printf("----- DUMPITEM of SPECSET\n");
            dumpitemset((typeitem *) specset);
            printf("----- END OF DUMPITEM of SPECSET\n");

            for (spec = specset, n = 0; spec; spec = (typespec *) spec->xxxispan.next, n++)
                ;

            printf("allocating specset of %u slots\n", n);

            PyObject *set = PyTuple_New(n);

            for (spec = specset, n = 0; spec; spec = (typespec *) spec->xxxispan.next, n++) {
                PyObject *t = PyTuple_New(2);

                assert(spec->xxxispan.itemid == ISPANID);

                PyObject *stream = wrapTumblerPyObject(&spec->xxxispan.stream);
                PyObject *width  = wrapTumblerPyObject(&spec->xxxispan.width);

                PyTuple_SetItem(t, 0, stream);
                PyTuple_SetItem(t, 1, width);

                PyTuple_SetItem(set, n, t);
            }

            return set;
        } else {
            printf("dofollowlink failed\n");

            Py_INCREF(Py_None);
            return Py_None;
        }
    } else
        return NULL;
}

static char Session_findnumoflinks__doc__[] =
"findnumoflinks(specset1, specset2, specset3) -> linkid\n\
Create a link with the specified end-sets and return its identifier.
The new link is appended to the link space of iddoc.  iddoc is the home
for the idlink.  iddoc must already be open for writing.\n";

static PyObject *
Session_findnumoflinks(SessionPyObject *self, PyObject *args)
{
    PyObject *specset1obj;
    PyObject *specset2obj;
    PyObject *specset3obj;
    PyObject *homespanobj;

    if (!PyArg_ParseTuple(args, "OOOO:findnumoflinks", &specset1obj, &specset2obj, &specset3obj, &homespanobj))
        return NULL;

    typespecset *specset1;
    typespecset *specset2;
    typespecset *specset3;

    if (!ParseSpecSet(self, specset1obj, &specset1))
        return NULL;

    if (!ParseSpecSet(self, specset2obj, &specset2))
        return NULL;

    if (!ParseSpecSet(self, specset3obj, &specset3))
        return NULL;

    typeispan homespan;
    homespan.next = NULL;
    homespan.itemid = ISPANID;
    if (!PyArg_ParseSpan(homespanobj, &homespan.stream, &homespan.width))
        return NULL;

    printf("----- DUMPITEM of SPECSET1\n");
    dumpitemset((typeitem *) specset1);
    printf("----- END OF DUMPITEM of SPECSET1\n");

    printf("----- DUMPITEM of SPECSET2\n");
    dumpitemset((typeitem *) specset2);
    printf("----- END OF DUMPITEM of SPECSET2\n");

    printf("----- DUMPITEM of SPECSET3\n");
    dumpitemset((typeitem *) specset3);
    printf("----- END OF DUMPITEM of SPECSET3\n");

    int count = 0;

    bool f = dofindnumoflinksfromtothree(self->x_sess, specset1, specset2, specset3, &homespan, &count);
    if (f) {
        printf("dofindnumoflinks succeeded\n");
        return PyInt_FromLong(count);
    } else {
        printf("dofindnumoflinks failed\n");

        Py_INCREF(Py_None);
        return Py_None;
    }

    Py_INCREF(Py_None);
    return Py_None;
}

static char Session_findlinks__doc__[] =
"findlinks(specset1, specset2, specset3, home) -> (linkid, ...)\n\
Create a link with the specified end-sets and return its identifier.
The new link is appended to the link space of iddoc.  iddoc is the home
for the idlink.  iddoc must already be open for writing.\n";

static PyObject *
Session_findlinks(SessionPyObject *self, PyObject *args)
{
    PyObject *specset1obj;
    PyObject *specset2obj;
    PyObject *specset3obj;
    PyObject *homespanobj;

    if (!PyArg_ParseTuple(args, "OOOO:findlinks", &specset1obj, &specset2obj, &specset3obj, &homespanobj))
        return NULL;

    typespecset *specset1;
    typespecset *specset2;
    typespecset *specset3;

    if (!ParseSpecSet(self, specset1obj, &specset1))
        return NULL;

    if (!ParseSpecSet(self, specset2obj, &specset2))
        return NULL;

    if (!ParseSpecSet(self, specset3obj, &specset3))
        return NULL;

    typeispan homespan;
    homespan.next = NULL;
    homespan.itemid = ISPANID;
    if (!PyArg_ParseSpan(homespanobj, &homespan.stream, &homespan.width))
        return NULL;

    printf("----- DUMPITEM of SPECSET1\n");
    dumpitemset((typeitem *) specset1);
    printf("----- END OF DUMPITEM of SPECSET1\n");

    printf("----- DUMPITEM of SPECSET2\n");
    dumpitemset((typeitem *) specset2);
    printf("----- END OF DUMPITEM of SPECSET2\n");

    printf("----- DUMPITEM of SPECSET3\n");
    dumpitemset((typeitem *) specset3);
    printf("----- END OF DUMPITEM of SPECSET3\n");

    typelinkset addrset;

    bool f = dofindlinksfromtothree(self->x_sess, (typespecset) specset1, (typespecset) specset2, (typespecset) specset3, &homespan, &addrset);
    if (f) {
        printf("dofindlinks succeeded\n");

        dumpitemset((typeitem *) addrset);

        int nitems;
        typelink *addr;

        for (addr = addrset, nitems = 0; addr; addr = (typelink *) addr->next, nitems++)
            ;
        printf("There are %u items in the result\n", nitems);

        PyObject *t = PyTuple_New(nitems);

        for (addr = addrset, nitems = 0; addr; addr = (typelink *) addr->next, nitems++) {
            if (addr->itemid == ADDRESSID) {
                PyObject *linkisa = wrapTumblerPyObject(&addr->address);
                //TBD -- check success of wrapping operation (can fail)
                PyTuple_SetItem(t, nitems, linkisa);
            } else {
                Py_XDECREF(t);
                PyErr_SetString(PyExc_ValueError,
                                "unknown itemid in return from dofindlinksfromtothree()");
                return NULL;
            }
        }
        return t;

    } else {
        printf("dofindlinks failed\n");

        Py_INCREF(Py_None);
        return Py_None;
    }

    Py_INCREF(Py_None);
    return Py_None;
}

static char Session_retrieveendsets__doc__[] =
"retrieveendsets(specset) -> (docid, ...) | None\n\
Describes where links attach to contents.  Each returned spec-set
describes the union of all end-sets of the given type that attach
to the supplied spec-setcontents.\n";

static PyObject *
Session_retrieveendsets(SessionPyObject *self, PyObject *args)
{
    PyObject *specsetobj;

    if (!PyArg_ParseTuple(args, "O:retrieveendsets", &specsetobj))
        return NULL;

    typespecset *specset;

    int itemno = 0;
    int nspecs = PyTuple_Size(specsetobj);

    while (nspecs) {
        typespec *spec        = new(self->x_sess) typespec;
        spec->xxxispan.next   = NULL; // Single-Item specset, containing a list of vspans
        spec->xxxispan.itemid = ISPANID;

        PyObject *spantuple = PyTuple_GetItem(specsetobj, itemno++);

        if (!PyArg_ParseSpan(spantuple, &spec->xxxispan.stream, &spec->xxxispan.width))
            return 0;

        *specset = spec;
        specset  = (typespecset *) &spec->xxxispan.next;
        nspecs--;
    }

    printf("----- DUMPITEM of SPECSET\n");
    dumpitemset((typeitem *) specset);
    printf("----- END OF DUMPITEM of SPECSET\n");

    typespecset specset1;
    typespecset specset2;
    typespecset specset3;

    bool f = doretrieveendsets(self->x_sess, (typespecset) specset, &specset1, &specset2, &specset3);
    if (f) {
        printf("doretrieveendsets succeeded\n");
        PyObject *reply = PyTuple_New(3);
        PyObject *set;

        int n;
        typespec *spec;

        printf("----- DUMPITEM of SPECSET1\n");
        dumpitemset((typeitem *) specset1);
        printf("----- END OF DUMPITEM of SPECSET1\n");

        for (spec = specset1, n = 0; spec; spec = (typespec *) spec->xxxispan.next, n++)
            ;

        printf("allocating specset of %u slots\n", n);

        set = PyTuple_New(n);



//struct typevspec {
//    typevspec *next;
//    typeitemid itemid;
//    IStreamAddr docisa;
//    typevspanset vspanset;
//};




        for (spec = specset1, n = 0; spec; spec = (typespec *) spec->xxxispan.next, n++) {
            PyObject *t = PyTuple_New(2);

//            assert(spec->xxxispan.itemid == ISPANID);
            printf("ITEMID is %d\n", spec->xxxispan.itemid);

            PyObject *stream = wrapTumblerPyObject(&spec->xxxispan.stream);
            PyObject *width  = wrapTumblerPyObject(&spec->xxxispan.width);

            PyTuple_SetItem(t, 0, stream);
            PyTuple_SetItem(t, 1, width);

            PyTuple_SetItem(set, n, t);
        }
        PyTuple_SetItem(reply, 0, set);


        printf("----- DUMPITEM of SPECSET2\n");
        dumpitemset((typeitem *) specset2);
        printf("----- END OF DUMPITEM of SPECSET2\n");

        for (spec = specset2, n = 0; spec; spec = (typespec *) spec->xxxispan.next, n++)
            ;

        printf("allocating specset of %u slots\n", n);

        set = PyTuple_New(n);

        for (spec = specset2, n = 0; spec; spec = (typespec *) spec->xxxispan.next, n++) {
            PyObject *t = PyTuple_New(2);

//            assert(spec->xxxispan.itemid == ISPANID);
            printf("ITEMID is %d\n", spec->xxxispan.itemid);

            PyObject *stream = wrapTumblerPyObject(&spec->xxxispan.stream);
            PyObject *width  = wrapTumblerPyObject(&spec->xxxispan.width);

            PyTuple_SetItem(t, 0, stream);
            PyTuple_SetItem(t, 1, width);

            PyTuple_SetItem(set, n, t);
        }
        PyTuple_SetItem(reply, 1, set);


        printf("----- DUMPITEM of SPECSET3\n");
        dumpitemset((typeitem *) specset3);
        printf("----- END OF DUMPITEM of SPECSET3\n");

        for (spec = specset3, n = 0; spec; spec = (typespec *) spec->xxxispan.next, n++)
            ;

        printf("allocating specset of %u slots\n", n);

        set = PyTuple_New(n);

        for (spec = specset3, n = 0; spec; spec = (typespec *) spec->xxxispan.next, n++) {
            PyObject *t = PyTuple_New(2);

//            assert(spec->xxxispan.itemid == ISPANID);
            printf("ITEMID is %d\n", spec->xxxispan.itemid);

            PyObject *stream = wrapTumblerPyObject(&spec->xxxispan.stream);
            PyObject *width  = wrapTumblerPyObject(&spec->xxxispan.width);

            PyTuple_SetItem(t, 0, stream);
            PyTuple_SetItem(t, 1, width);

            PyTuple_SetItem(set, n, t);
        }
        PyTuple_SetItem(reply, 2, set);

        return reply;

    } else {
        printf("doretrieveendsets failed\n");

        Py_INCREF(Py_None);
        return Py_None;
    }

    Py_INCREF(Py_None);
    return Py_None;
}


//bool
//dofindnextnlinksfromtothree(Session *sess, typevspec *fromvspecptr, typevspec *tovspecptr,
//                            typevspec *threevspecptr, typeispan *orglrangeptr, IStreamAddr *lastlinkisaptr,
//                            typelinkset *nextlinksetptr, int *nptr)

static char Session_expunge__doc__[] =
"expunge() -> None\n\
Describes where links attach to contents.  Each returned spec-set
describes the union of all end-sets of the given type that attach
to the supplied spec-setcontents.\n";

static PyObject *
Session_expunge(SessionPyObject *self, PyObject *args)
{
    if (!PyArg_ParseTuple(args, ":expunge"))
        return NULL;

    self->x_sess->free();

    Py_INCREF(Py_None);
    return Py_None;
}

static PyMethodDef Session_methods[] = {
    {"close",           (PyCFunction) Session_close,         METH_VARARGS, Session_close__doc__},
    {"expunge",         (PyCFunction) Session_expunge,       METH_VARARGS, Session_expunge__doc__},
    {"retrieveendsets", (PyCFunction) Session_retrieveendsets,  METH_VARARGS, Session_retrieveendsets__doc__},
    {"findlinks",       (PyCFunction) Session_findlinks,  METH_VARARGS, Session_findlinks__doc__},
    {"findnumoflinks",  (PyCFunction) Session_findnumoflinks,  METH_VARARGS, Session_findnumoflinks__doc__},
    {"followlink",     (PyCFunction) Session_followlink,  METH_VARARGS, Session_followlink__doc__},
    {"finddocscontaining",  (PyCFunction) Session_finddocscontaining,  METH_VARARGS, Session_finddocscontaining__doc__},
    {"allocnode",      (PyCFunction) Session_allocnode,      METH_VARARGS, Session_allocnode__doc__},
    {"allocacct",      (PyCFunction) Session_allocacct,      METH_VARARGS, Session_allocacct__doc__},
    {"allocdoc",       (PyCFunction) Session_allocdoc,       METH_VARARGS, Session_allocdoc__doc__},
    {"allocver",       (PyCFunction) Session_allocver,       METH_VARARGS, Session_allocver__doc__},
    {"dump",           (PyCFunction) Session_dump,           METH_VARARGS, Session_dump__doc__},
    {"gdump",          (PyCFunction) Session_gdump,          METH_VARARGS, Session_gdump__doc__},
    {"sdump",          (PyCFunction) Session_sdump,          METH_VARARGS, Session_sdump__doc__},
    {"open",           (PyCFunction) Session_open,           METH_VARARGS, Session_open__doc__},
    {NULL,             NULL}  /* sentinel */
};

static PyObject *
Session_getattr(SessionPyObject *self, char *name)
{
    if (self->x_attr != NULL) {
        PyObject *v = PyDict_GetItemString(self->x_attr, name);
        if (v != NULL) {
            Py_INCREF(v);
            return v;
        }
    }
    return Py_FindMethod(Session_methods, (PyObject *)self, name);
}

static int
Session_setattr(SessionPyObject *self, char *name, PyObject *v)
{
    if (self->x_attr == NULL) {
        self->x_attr = PyDict_New();
        if (self->x_attr == NULL)
            return -1;
    }

    if (v == NULL) {
        int rv = PyDict_DelItemString(self->x_attr, name);
        if (rv < 0)
            PyErr_SetString(PyExc_AttributeError,
                            "delete non-existing Session attribute");
        return rv;
    } else
        return PyDict_SetItemString(self->x_attr, name, v);
}
