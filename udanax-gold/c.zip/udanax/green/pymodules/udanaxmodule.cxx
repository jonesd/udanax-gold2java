/**********************************************************************
 * Copyright 2002 Jeff Rush <jrush@taupro.com>
 * Original Copyright 1979-2002 Udanax.com
 *
 * This file is part of the Udanax xanalogical storage system.
 *
 * Udanax is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * Udanax is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with Udanax; if not, write to the Free Software Foundation,
 * Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 **********************************************************************/

/**
 * @file  udanaxmodule.cxx
 * @brief ???
 *
 * (to be defined)
 *
 **/

/* Modification History:
 * $Log: udanaxmodule.cxx,v $
 * Revision 1.8  2002/05/28 04:01:48  jrush
 * Sources changed to comply with GPL licensing.
 *
 * Revision 1.7  2002/04/12 12:02:01  jrush
 * Added database name to SessionPyObject, and tried to permit multiple
 * database sessions and the ability to close and reopen the database
 * within a process.
 *
 * Revision 1.6  2002/04/09 21:45:46  jrush
 * Renamed class 'tumbler' to 'Tumbler', for consistency with Python sources,
 * and changed typeisa from typedef to a subclass, in preparation for cleaning
 * up the type/class tree.
 *
 * Revision 1.5  2002/04/08 20:46:46  jrush
 * Grouped python type structures and functions into
 * udanaxmodule.h.  Also eliminated use of global sessx
 * variable and use the one in Session objects instead.
 *
 * Revision 1.4  2002/04/08 18:58:07  jrush
 * Renamed xxxObject to xxxPyObject for easier to follow Doxygen graphs.
 *
 * Revision 1.3  2002/04/07 22:09:38  jrush
 * Added documentation header to top of source file.
 *
 *
 */

static char udanaxmodule__doc__ [] =
"This module wraps the Udanax-Green implementation of hypertext and provides\n\
Python objects that correspond to documents, versions, byte and link streams.\n\
\n\
>>> import udanax\n\
>>> sess = udanax.login('1.7.0.9', 'test') # Username and Password\n\
";

#include "udanaxmodule.h"

PyObject *UdanaxErrorPyObject;

static char udanax_login__doc__[] =
"login(username, password) -> Session\n\
Open a pseudo-terminal, returning open fd's for both master and slave end.\n";

static PyObject *
udanax_login(PyObject *self, PyObject *args)
{
    char *username, *password, *database = "enf.enf";

    if (!PyArg_ParseTuple(args, "ss", &username, &password))
        return NULL;

    return wrapSessionPyObject(username, password, database);
}

/* List of functions defined in the module */

static PyMethodDef module_methods[] = {
    {"login",  (PyCFunction) udanax_login,  METH_VARARGS, udanax_login__doc__},
    {NULL,     NULL}                        /* sentinel */
};

//void
//cleanup(void)
//{
//    printf("Cleaning up enfilade for shutdown...\n");
//    writeenfilades();
//    closediskfile();
//}

/* Initialization function for the module (*must* be called initudanax) */
extern "C" DL_EXPORT(void)
initudanax(void)
{
    char *rev="$Revision: 1.8 $";

    /* Initialize the type of the new type object here; doing it here
     * is required for portability to Windows without requiring C++. */
    Tumbler_Type.ob_type      = &PyType_Type;
    Session_Type.ob_type      = &PyType_Type;
    Document_Type.ob_type     = &PyType_Type;
    DocBytes_Type.ob_type     = &PyType_Type;
    DocLinks_Type.ob_type     = &PyType_Type;
    VSpec_Type.ob_type        = &PyType_Type;

    /* Create the module and add the functions */
    PyObject *m = Py_InitModule4("udanax", module_methods, udanaxmodule__doc__, (PyObject *) NULL, PYTHON_API_VERSION);

    /* Add some symbolic constants to the module */
    PyObject *d = PyModule_GetDict(m);
    UdanaxErrorPyObject = PyErr_NewException("udanax.error", NULL, NULL);
    PyDict_SetItemString(d, "error", UdanaxErrorPyObject);
    PyDict_SetItemString(d, "__version__", PyString_FromStringAndSize(rev + 11, strlen(rev + 11) - 2));

    /* Set up test dictionary for use by doctest module */
    PyObject *dt = PyDict_New();
    PyDict_SetItemString(dt, "Tumbler",    (PyObject *) &Tumbler_Type);
    PyDict_SetItemString(dt, "Session",    (PyObject *) &Session_Type);
    PyDict_SetItemString(dt, "Document",   (PyObject *) &Document_Type);

    PyDict_SetItemString(d, "__test__", dt);

//    Py_AtExit(cleanup);
}

bool
ParseSpecSet(SessionPyObject *sess, PyObject *specsetobj, typespecset **result)
{
    int itemno = 0;
    int nspecs = PyTuple_Size(specsetobj);

    typespecset zzspecset;
    typespecset *specset = &zzspecset;
    while (nspecs) {
        typespec *spec        = new(sess->x_sess) typespec;
        spec->xxxispan.next   = NULL; // Single-Item specset, containing a list of vspans
        spec->xxxispan.itemid = ISPANID;

        PyObject *spantuple = PyTuple_GetItem(specsetobj, itemno++);

        if (!PyArg_ParseSpan(spantuple, &spec->xxxispan.stream, &spec->xxxispan.width))
            return false;

        *specset = spec;
        specset  = (typespecset *) &spec->xxxispan.next;
        nspecs--;
    }

    *result = specset;
    return true;
}

int
PyArg_ParseSpanTuple(SessionPyObject *sess, PyObject *spansettuple, typespanset *spanset)
{
    int itemno = 0;
    int nspans = PyTuple_Size(spansettuple);

    while (nspans) {
        typespan *span = new(sess->x_sess) typespan;
        span->next     = NULL;
        span->itemid   = VSPANID;

    //BUG -- parses as tuples but doesn't handle lists !!!!

        PyObject *spantuple = PyTuple_GetItem(spansettuple, itemno++);

        if (!PyArg_ParseSpan(spantuple, &span->stream, &span->width))
            return 0;

        *spanset = span;        // Point SPEC to new SPAN
        spanset  = &span->next; // Update ptr to new ptr to SPAN
        nspans--;
    }
    return 1;
}

int
PyArg_ParseTumbler(PyObject *arg, Tumbler *t)
{
    if (PyString_Check(arg)) {
        if (!str_to_tumbler(PyString_AsString(arg), t))
            return 0;

    } else if (TumblerPyObject_Check(arg)) {
        t = &((TumblerPyObject *)arg)->x_tumbler;

    } else {
        PyErr_SetString(PyExc_ValueError,
                        "must be either a tumbler object or string");
        return 0;
    }

    return 1;
}

int
PyArg_ParseSpan(PyObject *spanseq, Tumbler *stream, Tumbler *width)
{
    if (!PyTuple_Check(spanseq) && !PyList_Check(spanseq)) {
        PyErr_SetString(PyExc_AttributeError,
                        "span must be either a list or tuple");
        return 0;
    }

    PyObject *streamobj, *widthobj;

    //BUG -- parses as tuples but doesn't handle lists !!!!

    if (!PyArg_ParseTuple(spanseq, "OO;bad span format", &streamobj, &widthobj))
        return 0;

    if (!PyArg_ParseTumbler(streamobj, stream))
        return 0;

    if (!PyArg_ParseTumbler(widthobj, width))
        return 0;

    return 1;
}
