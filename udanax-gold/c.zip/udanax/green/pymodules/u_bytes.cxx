/**********************************************************************
 * Copyright 2002 Jeff Rush <jrush@taupro.com>
 * Original Copyright 1979-2002 Udanax.com
 *
 * This file is part of the Udanax xanalogical storage system.
 *
 * Udanax is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * Udanax is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with Udanax; if not, write to the Free Software Foundation,
 * Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 **********************************************************************/

/**
 * @file  u_bytes.cxx
 * @brief ???
 *
 * (to be defined)
 *
 **/

/* Modification History:
 * $Log: u_bytes.cxx,v $
 * Revision 1.9  2002/05/28 04:01:48  jrush
 * Sources changed to comply with GPL licensing.
 *
 * Revision 1.8  2002/04/10 18:01:54  jrush
 * Renamed class typeisa to IStreamAddr.
 *
 * Revision 1.7  2002/04/08 20:46:46  jrush
 * Grouped python type structures and functions into
 * udanaxmodule.h.  Also eliminated use of global sessx
 * variable and use the one in Session objects instead.
 *
 * Revision 1.6  2002/04/08 18:58:07  jrush
 * Renamed xxxObject to xxxPyObject for easier to follow Doxygen graphs.
 *
 * Revision 1.5  2002/04/07 14:01:05  jrush
 * Added documentation header to top of source file.
 *
 */

static char docbytes__doc__ [] =
"This type provides access to operating system functionality that is\n\
standardized by the C Standard and the POSIX standard (a thinly\n\
disguised Unix interface).  Refer to the library manual and\n\
corresponding Unix manual entries for more information on calls.
";

/* Bytes subobjects of a OpenDoc object */

#include "udanaxmodule.h"

static void      DocBytes_dealloc(DocBytesPyObject *self);
static PyObject *DocBytes_getattr(DocBytesPyObject *self, char *name);
static PyObject *DocBytes_str(DocBytesPyObject *obj);
static PyObject *DocBytes_repr(DocBytesPyObject *obj);

static int // len(docbytesobj) -> length, in bytes, of the entire document
DocBytes_sq_length(DocBytesPyObject *self)
{
    typevspan *vspanset;
    bool f = doretrievedocvspanset(self->x_doc->x_sess->x_sess, &self->x_doc->x_docid, &vspanset);
    if (!f) {
        //TBD: need to distinguish btw fail due to empty and fail for other reasons
        return 0; // Length of Zero
    }
    return vspanset->width.mantissa[0];
}

static PyObject *
DocBytes_sq_slice(DocBytesPyObject *self, int from, int to)
{
    return wrapVSpecPyObject(self->x_doc, from, to);
}

static PyObject *
DocBytes_sq_item(DocBytesPyObject *self, int slot)
{
    return DocBytes_sq_slice(self, slot, slot+1);
}

static int
DocBytes_sq_ass_slice(DocBytesPyObject *self, int from, int to, PyObject *other)
{
    if (other == NULL) { // del docbytes[n:m]
        typevspan  vspan;
        vspan.next   = NULL;
        vspan.itemid = VSPANID;

        str_to_tumbler("1.1", &vspan.stream);
        vspan.stream.mantissa[1] = from + 1;

        str_to_tumbler("0.1", &vspan.width);
        vspan.width.mantissa[0] =  abs(to - from);

        printf("deleting vspan ");
        puttumbler(stdout, &vspan.stream);
        printf(" width ");
        puttumbler(stdout, &vspan.width);
        printf("\n");

        bool f = dodeletevspan(self->x_doc->x_sess->x_sess, &self->x_doc->x_docid, &vspan);
        if (f) {
            printf("dodeletevspan succeeded\n");

            return 0;
        } else {
            PyErr_SetString(PyExc_AttributeError,
                            "dodeletevspan failed");
            return -1;
        }
        return 0;
    }

    PyErr_SetString(PyExc_AttributeError,
                    "DocBytes.sq_ass_slice not implemented yet");
    return -1;
}

static int
DocBytes_sq_ass_item(DocBytesPyObject *self, int slot, PyObject *other)
{
    printf("sq_ass_item of DocBytes invoked, slot %d, other %d\n", slot, other);

    if (other == NULL) // del docbytes[n]
        return DocBytes_sq_ass_slice(self, slot, slot+1, other);

    PyErr_SetString(PyExc_AttributeError,
                    "DocBytes.sq_ass_item not implemented yet");
    return -1;
}

static PySequenceMethods DocBytes_SequenceMethods = {
    (inquiry)          &DocBytes_sq_length,                   /*sq_length*/
    (binaryfunc)       0,                                     /*sq_concat*/
    (intargfunc)       0,                                     /*sq_repeat*/
    (intargfunc)       &DocBytes_sq_item,                       /*sq_item*/
    (intintargfunc)    &DocBytes_sq_slice,                     /*sq_slice*/
    (intobjargproc)    &DocBytes_sq_ass_item,               /*sq_ass_item*/
    (intintobjargproc) &DocBytes_sq_ass_slice,             /*sq_ass_slice*/
    (objobjproc)       0,                                   /*sq_contains*/
    (binaryfunc)       0,                             /*sq_inplace_concat*/
    (intargfunc)       0,                             /*sq_inplace_repeat*/
};

PyTypeObject DocBytes_Type = {
    /* The ob_type field must be initialized in the module init function
     * to be portable to Windows without using C++.
     */
    PyObject_HEAD_INIT(NULL)
    0,                                                          /*ob_size*/
    "DocBytes",                                                 /*tp_name*/
    sizeof(DocBytesPyObject),                              /*tp_basicsize*/
    0,                                                      /*tp_itemsize*/
    /* Methods to implement standard operations */
    (destructor) DocBytes_dealloc,                           /*tp_dealloc*/
    0,                                                         /*tp_print*/
    (getattrfunc) DocBytes_getattr,                          /*tp_getattr*/
    (setattrfunc) 0,                                         /*tp_setattr*/
    0,                                                       /*tp_compare*/
    (reprfunc) DocBytes_repr,                                   /*tp_repr*/
    /* Method suites for standard classes */
    0,                                                     /*tp_as_number*/
    &DocBytes_SequenceMethods,                           /*tp_as_sequence*/
    0,                                                    /*tp_as_mapping*/
    /* More standard operations (here for binary compatibility) */
    0,                                                          /*tp_hash*/
    (ternaryfunc) 0,                                            /*tp_call*/
    (reprfunc) DocBytes_str,                                     /*tp_str*/
    (getattrofunc) 0,                                       /*tp_getattro*/
    (setattrofunc) 0,                                       /*tp_setattro*/
    /* Functions to access object as input/output buffer */
    (PyBufferProcs *) 0,                                   /*tp_as_buffer*/
    /* Flags to define presence of optional/expanded features */
    (long) 0,                                                  /*tp_flags*/
    (char *) docbytes__doc__,                    /* Documentation string */
    /* call function for all accessible objects */
    (traverseproc) 0,                                       /*tp_traverse*/
    /* delete references to contained objects */
    (inquiry) 0,                                               /*tp_clear*/
    /* rich comparisons */
    (richcmpfunc) 0,                                     /*tp_richcompare*/
    /* weak reference enabler */
    (long) 0,                                         /*tp_weaklistoffset*/
};

PyObject *
wrapDocBytesPyObject(DocumentPyObject *docobj)
{
    DocBytesPyObject *self;

    self = PyObject_New(DocBytesPyObject, &DocBytes_Type);
    if (self == NULL)
        return NULL;

    self->x_doc = docobj;
    Py_INCREF(self->x_doc);

    return (PyObject *) self;
}

static void
DocBytes_dealloc(DocBytesPyObject *self)
{
    Py_INCREF(self->x_doc);
    PyObject_Del(self);
}

static typevstuffset
FetchContent(DocBytesPyObject *self, int from, int to)
{
    typespec spec;
    spec.xxxvspec.next   = NULL; // Single-Item specset, containing a list of vspans
    spec.xxxvspec.itemid = VSPECID;
    tumblercopy(&self->x_doc->x_docid, &spec.xxxvspec.docisa);

    typespan span;
    span.next   = NULL;
    span.itemid = VSPANID;

    if (to == 2147483647)
        to = 2147483646;

    if (from > to) {
        PyErr_SetString(PyExc_ValueError,
                        "first index must be smaller than second index");
        return NULL;
    }

    str_to_tumbler("1.1", &span.stream);
    span.stream.mantissa[1] = from + 1;

    str_to_tumbler("0.1", &span.width);
    span.width.mantissa[0] =  abs(to - from);

    spec.xxxvspec.vspanset = &span;

    typevstuffset  vstuffset; // Set coming out
    bool f = doretrievev(self->x_doc->x_sess->x_sess, &spec, &vstuffset);
    if (!f) {
        PyErr_SetString(PyExc_AttributeError,
                        "delete non-existing DocBytes attribute");
        return NULL;
    }
    return vstuffset;
}

/* DocBytes methods */

static char DocBytes_append__doc__[] =
"append(text|vspec) -> None\n\
\n";

static PyObject *
DocBytes_append(DocBytesPyObject *self, PyObject *args)
{
    PyObject *source;
    if (!PyArg_ParseTuple(args, "O:source", &source))
        return NULL;

    if (PyString_Check(source)) {
        char *s    = PyString_AS_STRING(source);
        int   slen = PyString_GET_SIZE(source);

        while (slen) {
            int n = min(slen, GRANTEXTLENGTH);
            typetextset textset = new(self->x_doc->x_sess->x_sess) typetext;

            memcpy(textset->string, s, n);
            s    += n;
            slen -= n;

            textset->next   = NULL;
            textset->itemid = TEXTID;
            textset->length = n;

            bool f = doappend(self->x_doc->x_sess->x_sess, &self->x_doc->x_docid, textset);
            //TBD: check f and raise exception if error
        }

    } else if (DocBytesPyObject_Check(source)) {

        source = wrapVSpecPyObject(self->x_doc, 0, DocBytes_sq_length((DocBytesPyObject *) source));

        IStreamAddr inspoint_vsa;
        str_to_tumbler("1.1", &inspoint_vsa);
        inspoint_vsa.mantissa[1] = DocBytes_sq_length(self) + 1;

//        typespecset zzspecset;
//        typespecset *specset = &zzspecset;
//
//
//        *specset = VSpec_asSpec(source);
//        specset  = (typespecset *) &(*specset)->xxxispan.next;

        printf("\n*** NOT IMPLEMENTED YET ***\n");

        bool f /*= docopy(self->x_doc->x_sess->x_sess, &self->x_doc->x_docid, &inspoint_vsa, VSpec_asSpec(source)) */;
        Py_DECREF(source);
        if (f) {
            printf("docopy succeeded\n");

            Py_INCREF(Py_None);
            return Py_None;
        } else {
            printf("docopy failed\n");

            Py_INCREF(Py_None);
            return Py_None;
        }

        Py_INCREF(Py_None);
        return Py_None;

    } else if (VSpecPyObject_Check(source)) {
        /* Construct a V-Stream address pointing to the end of the existing
         * bytestream, at which to append the new content.
         */

        IStreamAddr inspoint_vsa;
        str_to_tumbler("1.1", &inspoint_vsa);
        inspoint_vsa.mantissa[1] = DocBytes_sq_length(self) + 1;

        typespecset zzspecset;
        typespecset *specset = &zzspecset;

        *specset = VSpec_asSpec((VSpecPyObject *) source);
        specset  = (typespecset *) &(*specset)->xxxispan.next;

        bool f = docopy(self->x_doc->x_sess->x_sess, &self->x_doc->x_docid, &inspoint_vsa, (typespecset) specset);
        if (f) {
            printf("docopy succeeded\n");

            Py_INCREF(Py_None);
            return Py_None;
        } else {
            printf("docopy failed\n");

            Py_INCREF(Py_None);
            return Py_None;
        }

        Py_INCREF(Py_None);
        return Py_None;

    } else {
        PyErr_SetString(PyExc_ValueError,
                        "can only append text or byte substreams to a byte stream");
        return NULL;
    }

    Py_INCREF(Py_None);
    return Py_None;
}

static char DocBytes_insert__doc__[] =
"insert(text) -> None\n\
\n";

static PyObject *
DocBytes_insert(DocBytesPyObject *self, PyObject *args)
{
    int inspoint;
    char *s = NULL;
    int slen = 0;

    if (!PyArg_ParseTuple(args, "is#:insert", &inspoint, &s, &slen))
        return NULL;

    IStreamAddr vsa;
    str_to_tumbler("1.1", &vsa);
    vsa.mantissa[1] = inspoint + 1;

    while (slen) {
        int n = min(slen, GRANTEXTLENGTH);
        typetextset textset = new(self->x_doc->x_sess->x_sess) typetext;

        memcpy(textset->string, s, n);
        s += n;
        slen -= n;

        textset->next   = NULL;
        textset->itemid = TEXTID;
        textset->length = n;

        bool f = doinsert(self->x_doc->x_sess->x_sess, &self->x_doc->x_docid, &vsa, textset);
        //TBD: check f and raise exception if error
    }

    Py_INCREF(Py_None);
    return Py_None;
}

static PyObject *
DocBytes_str(DocBytesPyObject *self)
{
    int nbytes = DocBytes_sq_length(self);
    if (nbytes < 0)
        return NULL;

    PyObject *str = PyString_FromStringAndSize(NULL, nbytes);
    if (!str)
        return NULL;

    typespec spec;
    spec.xxxvspec.next   = NULL; // Single-Item specset, containing a list of vspans
    spec.xxxvspec.itemid = VSPECID;
    tumblercopy(&self->x_doc->x_docid, &spec.xxxvspec.docisa);

    typespan span;
    span.next   = NULL;
    span.itemid = VSPANID;

    str_to_tumbler("1.1", &span.stream);
    str_to_tumbler("1", &span.width);

    spec.xxxvspec.vspanset = &span;

    typevstuffset  vstuffset; // Set coming out
    bool f = doretrievev(self->x_doc->x_sess->x_sess, &spec, &vstuffset);
    if (!f) {
        PyErr_SetString(PyExc_AttributeError,
                        "delete non-existing DocBytes attribute");
        return NULL;
    }

    char *s = ((PyStringObject *) str)->ob_sval;

    typevstuff *vs = vstuffset;
    while (vs) {
        if (vs->xxxtext.itemid == TEXTID) {
            memcpy(s, vs->xxxtext.string, vs->xxxtext.length);
            s += vs->xxxtext.length;
        }
        vs = (typevstuff *) vs->xxxtext.next;
    }
    return str;
}

static PyObject *
DocBytes_repr(DocBytesPyObject *self)
{
    char buffer[128] = "DocBytes(docid='";

    if (tumbler_to_str(&self->x_doc->x_docid, &buffer[strlen(buffer)], sizeof(buffer) - strlen(buffer))) {
        strcat(buffer, "')");
        return PyString_FromString(buffer);
    } else
	Py_INCREF(Py_None);
	return Py_None;
}

static PyMethodDef DocBytes_methods[] = {
    {"insert",     (PyCFunction) DocBytes_insert,      METH_VARARGS, DocBytes_insert__doc__},
    {"append",     (PyCFunction) DocBytes_append,      METH_VARARGS, DocBytes_append__doc__},
    {NULL,         NULL}  /* sentinel */
};

static PyObject *
DocBytes_getattr(DocBytesPyObject *self, char *name)
{
    return Py_FindMethod(DocBytes_methods, (PyObject *)self, name);
}
