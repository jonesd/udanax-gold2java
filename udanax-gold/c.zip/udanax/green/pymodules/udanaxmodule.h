/**********************************************************************
 * Copyright 2002 Jeff Rush <jrush@taupro.com>
 * Original Copyright 1979-2002 Udanax.com
 *
 * This file is part of the Udanax xanalogical storage system.
 *
 * Udanax is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * Udanax is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with Udanax; if not, write to the Free Software Foundation,
 * Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 **********************************************************************/

/**
 * @file  udanaxmodule.h
 * @brief ???
 *
 * (to be defined)
 *
 **/

/* Modification History:
 * $Log: udanaxmodule.h,v $
 * Revision 1.5  2002/05/28 04:01:48  jrush
 * Sources changed to comply with GPL licensing.
 *
 * Revision 1.4  2002/04/12 12:01:20  jrush
 * Renamed xanadu.h to udanax.h and added database name to SessionPyObject.
 *
 * Revision 1.3  2002/04/10 18:01:54  jrush
 * Renamed class typeisa to IStreamAddr.
 *
 * Revision 1.2  2002/04/09 21:45:46  jrush
 * Renamed class 'tumbler' to 'Tumbler', for consistency with Python sources,
 * and changed typeisa from typedef to a subclass, in preparation for cleaning
 * up the type/class tree.
 *
 * Revision 1.1  2002/04/08 20:46:46  jrush
 * Grouped python type structures and functions into
 * udanaxmodule.h.  Also eliminated use of global sessx
 * variable and use the one in Session objects instead.
 *
 *
 */

#ifndef __UDANAXMODULE_H__
#define __UDANAXMODULE_H__

#include "udanax.h"
#include "Python.h"

extern PyObject *UdanaxErrorPyObject;

/*
 * Session
 */

typedef struct {
    PyObject_HEAD
    PyObject        *x_attr;      // Attributes dictionary
    char            *x_username;
    Session         *x_sess;
} SessionPyObject;

extern PyObject *wrapSessionPyObject(char *username, char *password, char *database);

extern PyTypeObject Session_Type;
#define SessionPyObject_Check(v)	((v)->ob_type == &Session_Type)


/*
 * Document
 */

typedef struct {
    PyObject_HEAD
    PyObject         *x_attr;     // Attributes dictionary
    IStreamAddr       x_docid;
    char              x_type;
    SessionPyObject  *x_sess;
} DocumentPyObject;

extern PyObject *wrapDocumentPyObject(Tumbler *docid, char type, SessionPyObject *sess);

extern PyTypeObject Document_Type;
#define DocumentPyObject_Check(v)	((v)->ob_type == &Document_Type)


/*
 * DocBytes
 */

typedef struct {
    PyObject_HEAD
    DocumentPyObject  *x_doc;
} DocBytesPyObject;

extern PyObject *wrapDocBytesPyObject(DocumentPyObject *docobj);

extern PyTypeObject DocBytes_Type;
#define DocBytesPyObject_Check(v)	((v)->ob_type == &DocBytes_Type)


/*
 * DocLinks
 */

typedef struct {
    PyObject_HEAD
    DocumentPyObject  *x_doc;
} DocLinksPyObject;

extern PyObject *wrapDocLinksPyObject(DocumentPyObject *docobj);

extern PyTypeObject DocLinks_Type;
#define DocLinksPyObject_Check(v)	((v)->ob_type == &DocLinks_Type)

/*
 * VSpec
 */

typedef struct {
    PyObject_HEAD
    DocumentPyObject  *x_doc;
    typespec           x_spec;
    typespan           x_span;
} VSpecPyObject;

extern typespec *VSpec_asSpec(VSpecPyObject *self);
extern PyObject *wrapVSpecPyObject(DocumentPyObject *docobj, int from, int to);

extern PyTypeObject VSpec_Type;
#define VSpecPyObject_Check(v)	((v)->ob_type == &VSpec_Type)


/*
 * Tumbler
 */

typedef struct {
    PyObject_HEAD
    PyObject       *x_attr;      /* Attributes dictionary */
    Tumbler         x_tumbler;
} TumblerPyObject;

extern PyObject  *wrapTumblerPyObject(Tumbler *from);
extern bool       str_to_tumbler(const char *s, Tumbler *t);
extern bool       tumbler_to_str(Tumbler *t, char *s, int maxlen);
extern void       puttumbler(FILE *outfile, Tumbler *tumblerptr);

extern PyTypeObject Tumbler_Type;
#define TumblerPyObject_Check(v)	((v)->ob_type == &Tumbler_Type)


/*
 * General Utility Functions
 */

extern int        PyArg_ParseSpan(PyObject *spanseq, Tumbler *stream, Tumbler *width);
extern bool       ParseSpecSet(SessionPyObject *sess, PyObject *specsetobj, typespecset **result);
extern void       graphwholetree(char *filename, typecorecrum *ptr, char *graphlabel);
extern int        PyArg_ParseTumbler(PyObject *arg, Tumbler *t);
extern int        PyArg_ParseSpan(PyObject *spanseq, Tumbler *stream, Tumbler *width);
extern int        PyArg_ParseSpanTuple(SessionPyObject *sess, PyObject *spansettuple, typespanset *spanset);


#endif /* !__UDANAXMODULE_H__*/
