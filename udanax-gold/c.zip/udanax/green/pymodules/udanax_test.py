#!/usr/bin/python2.1

import unittest, udanax, doctest

class TumblerTestCase(unittest.TestCase):
    def runTest(self):
        self.failUnless(Tumbler() == '4', 'incorrect default size')

class WidgetTestCase(unittest.TestCase):
    def setUp(self):
        pass

    def tearDown(self):
        pass

    def testDefaultTumbler(self):
        self.failUnless(`udanax.Tumbler()` == 'Tumbler()',
                        'incorrect default value')

#    def testResize(self):
#        self.widget.resize(100,150)
#        self.failUnless(self.widget.size() == (100,150),
#                        'wrong size after resize')

testRunner = unittest.TextTestRunner(verbosity=2)

if __name__ == '__main__':
    doctest.testmod(udanax, verbose=1)
#    unittest.main(testRunner=testRunner)
