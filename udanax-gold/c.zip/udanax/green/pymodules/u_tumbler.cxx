/**********************************************************************
 * Copyright 2002 Jeff Rush <jrush@taupro.com>
 * Original Copyright 1979-2002 Udanax.com
 *
 * This file is part of the Udanax xanalogical storage system.
 *
 * Udanax is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * Udanax is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with Udanax; if not, write to the Free Software Foundation,
 * Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 **********************************************************************/

/**
 * @file  u_tumbler.cxx
 * @brief ???
 *
 * (to be defined)
 *
 **/

/* Modification History:
 * $Log: u_tumbler.cxx,v $
 * Revision 1.8  2002/05/28 04:01:48  jrush
 * Sources changed to comply with GPL licensing.
 *
 * Revision 1.7  2002/04/09 21:45:46  jrush
 * Renamed class 'tumbler' to 'Tumbler', for consistency with Python sources,
 * and changed typeisa from typedef to a subclass, in preparation for cleaning
 * up the type/class tree.
 *
 * Revision 1.6  2002/04/08 20:46:46  jrush
 * Grouped python type structures and functions into
 * udanaxmodule.h.  Also eliminated use of global sessx
 * variable and use the one in Session objects instead.
 *
 * Revision 1.5  2002/04/08 18:58:07  jrush
 * Renamed xxxObject to xxxPyObject for easier to follow Doxygen graphs.
 *
 * Revision 1.4  2002/04/07 22:09:38  jrush
 * Added documentation header to top of source file.
 *
 *
 */

static char tumbler__doc__ [] =
"This type provides access to operating system functionality that is\n\
standardized by the C Standard and the POSIX standard (a thinly\n\
disguised Unix interface).  Refer to the library manual and\n\
corresponding Unix manual entries for more information on calls.

>>> Tumbler()
Tumbler('0')
>>> Tumbler('5')
Tumbler('5')
>>> Tumbler('1.2')
Tumbler('1.2')
>>> Tumbler('1.2.3.4.5.6')
Tumbler('1.2.3.4.5.6')
>>> Tumbler('5..4')
Traceback (most recent call last):
ValueError: no digits within tumbler
>>> Tumbler('-2.3.4')
Tumbler('-2.3.4')
>>> Tumbler('1.2.3.4.1.2.3.4.1.2.3.4.3.4.3.4.3.4.3.4.3')
Traceback (most recent call last):
ValueError: tumbler overflow
";

/* Tumbler objects */

#include "udanaxmodule.h"

#define MINEXP  -10

static void      Tumbler_dealloc(TumblerPyObject *self);
static PyObject *Tumbler_getattr(TumblerPyObject *self, char *name);
static int       Tumbler_setattr(TumblerPyObject *self, char *name, PyObject *v);
static PyObject *Tumbler_str(TumblerPyObject *obj);
static PyObject *Tumbler_repr(TumblerPyObject *obj);

PyNumberMethods Tumbler_NumberMethods = {
	/* For numbers without flag bit Py_TPFLAGS_CHECKTYPES set, all
	   arguments are guaranteed to be of the object's type (modulo
	   coercion hacks that is -- i.e. if the type's coercion function
	   returns other types, then these are allowed as well).  Numbers that
	   have the Py_TPFLAGS_CHECKTYPES flag bit set should check *both*
	   arguments for proper type and implement the necessary conversions
	   in the slot functions themselves. */

    (binaryfunc)  0,                                             /*nb_add*/
    (binaryfunc)  0,                                        /*nb_subtract*/
    (binaryfunc)  0,                                        /*nb_multiply*/
    (binaryfunc)  0,                                          /*nb_divide*/
    (binaryfunc)  0,                                       /*nb_remainder*/
    (binaryfunc)  0,                                          /*nb_divmod*/
    (ternaryfunc) 0,                                           /*nb_power*/
    (unaryfunc)   0,                                        /*nb_negative*/
    (unaryfunc)   0,                                        /*nb_positive*/
    (unaryfunc)   0,                                        /*nb_absolute*/
    (inquiry)     0,                                         /*nb_nonzero*/
    (unaryfunc)   0,                                          /*nb_invert*/
    (binaryfunc)  0,                                          /*nb_lshift*/
    (binaryfunc)  0,                                          /*nb_rshift*/
    (binaryfunc)  0,                                             /*nb_and*/
    (binaryfunc)  0,                                             /*nb_xor*/
    (binaryfunc)  0,                                              /*nb_or*/
    (coercion)    0,                                          /*nb_coerce*/
    (unaryfunc)   0,                                             /*nb_int*/
    (unaryfunc)   0,                                            /*nb_long*/
    (unaryfunc)   0,                                           /*nb_float*/
    (unaryfunc)   0,                                             /*nb_oct*/
    (unaryfunc)   0,                                             /*nb_hex*/
    (binaryfunc)  0,                                     /*nb_inplace_add*/
    (binaryfunc)  0,                                /*nb_inplace_subtract*/
    (binaryfunc)  0,                                /*nb_inplace_multiply*/
    (binaryfunc)  0,                                  /*nb_inplace_divide*/
    (binaryfunc)  0,                               /*nb_inplace_remainder*/
    (ternaryfunc) 0,                                   /*nb_inplace_power*/
    (binaryfunc)  0,                                  /*nb_inplace_lshift*/
    (binaryfunc)  0,                                  /*nb_inplace_rshift*/
    (binaryfunc)  0,                                     /*nb_inplace_and*/
    (binaryfunc)  0,                                     /*nb_inplace_xor*/
    (binaryfunc)  0,                                      /*nb_inplace_or*/
};

PySequenceMethods Tumbler_SequenceMethods = {
    (inquiry)          0,                                     /*sq_length*/
    (binaryfunc)       0,                                     /*sq_concat*/
    (intargfunc)       0,                                     /*sq_repeat*/
    (intargfunc)       0,                                       /*sq_item*/
    (intintargfunc)    0,                                      /*sq_slice*/
    (intobjargproc)    0,                                   /*sq_ass_item*/
    (intintobjargproc) 0,                                  /*sq_ass_slice*/
    (objobjproc)       0,                                   /*sq_contains*/
    (binaryfunc)       0,                             /*sq_inplace_concat*/
    (intargfunc)       0,                             /*sq_inplace_repeat*/
};

PyTypeObject Tumbler_Type = {
    /* The ob_type field must be initialized in the module init function
     * to be portable to Windows without using C++.
     */
    PyObject_HEAD_INIT(NULL)
    0,                                                          /*ob_size*/
    "Tumbler",                                                  /*tp_name*/
    sizeof(TumblerPyObject),                               /*tp_basicsize*/
    0,                                                      /*tp_itemsize*/
    /* Methods to implement standard operations */
    (destructor) Tumbler_dealloc,                            /*tp_dealloc*/
    0,                                                         /*tp_print*/
    (getattrfunc) Tumbler_getattr,                           /*tp_getattr*/
    (setattrfunc) Tumbler_setattr,                           /*tp_setattr*/
    0,                                                       /*tp_compare*/
    (reprfunc) Tumbler_repr,                                    /*tp_repr*/
    /* Method suites for standard classes */
    &Tumbler_NumberMethods,                                /*tp_as_number*/
    &Tumbler_SequenceMethods,                            /*tp_as_sequence*/
    0,                                                    /*tp_as_mapping*/
    /* More standard operations (here for binary compatibility) */
    0,                                                          /*tp_hash*/
    (ternaryfunc) 0,                                            /*tp_call*/
    (reprfunc) Tumbler_str,                                      /*tp_str*/
    (getattrofunc) 0,                                       /*tp_getattro*/
    (setattrofunc) 0,                                       /*tp_setattro*/
    /* Functions to access object as input/output buffer */
    (PyBufferProcs *) 0,                                   /*tp_as_buffer*/
    /* Flags to define presence of optional/expanded features */
    (long) 0,                                                  /*tp_flags*/
    (char *) tumbler__doc__,                     /* Documentation string */
    /* call function for all accessible objects */
    (traverseproc) 0,                                       /*tp_traverse*/
    /* delete references to contained objects */
    (inquiry) 0,                                               /*tp_clear*/
    /* rich comparisons */
    (richcmpfunc) 0,                                     /*tp_richcompare*/
    /* weak reference enabler */
    (long) 0,                                         /*tp_weaklistoffset*/
};

PyObject *
wrapTumblerPyObject(Tumbler *from)
{
    TumblerPyObject *self;

    self = PyObject_New(TumblerPyObject, &Tumbler_Type);
    if (self == NULL)
        return NULL;

    self->x_attr    = NULL;

    tumblercopy(from, &self->x_tumbler);

    return (PyObject *) self;
}

static void
Tumbler_dealloc(TumblerPyObject *self)
{
    Py_XDECREF(self->x_attr);
    PyObject_Del(self);
}

/* Tumbler methods */

bool
tumbler_isvalid(Tumbler *t)
{
    int i;

    if (t->exp > 0) {
        PyErr_SetString(PyExc_ValueError, "invalid tumbler exponent");
        return false;
    }

    if (t->sign && t->mantissa[0] == 0) {
        PyErr_SetString(PyExc_ValueError, "negative zero tumbler");
        return false;
    }

    if (t->exp && t->mantissa[0] == 0) {
        PyErr_SetString(PyExc_ValueError, "unnormalized tumbler");
        return false;
    }

    if (t->mantissa[0] == 0) {
        for (i = 1; i < NPLACES; ++i) {
            if (t->mantissa[i] != 0) {
                PyErr_SetString(PyExc_ValueError, "nonzero zero tumbler");
                return false;
            }
        }
    }

    for (i = 0; i < NPLACES; ++i) {
        if (t->mantissa[i] < 0) {
            PyErr_SetString(PyExc_ValueError, "negative tumbler digit");
            return false;
        }
    }

    return true;
}

bool
tumbler_to_str(Tumbler *t, char *s, int maxlen)
{
    int i, place;

    if (!tumbler_isvalid(t) || t->exp < MINEXP)
        return false;

    if (t->sign)
        *s++ = '-';

    for (i = t->exp; i < 0; ++i) {
        *s++ = '0';
        *s++ = '.';
    }

    place = NPLACES;
    do {
        --place;
    } while (place > 0 && t->mantissa[place] == 0);

    for (i = 0; i <= place; ++i) {
        s += sprintf(s, "%u", t->mantissa[i]);
        if (i < place)
            *s++ = '.';
    }
    return true;
}

static PyObject *
Tumbler_str(TumblerPyObject *obj)
{
    char buffer[128];

    if (tumbler_to_str(&obj->x_tumbler, buffer, sizeof(buffer)))
        return PyString_FromString(buffer);
    else
	Py_INCREF(Py_None);
	return Py_None;
}

static PyObject *
Tumbler_repr(TumblerPyObject *obj)
{
    char buffer[128] = "Tumbler('";

    if (tumbler_to_str(&obj->x_tumbler, &buffer[strlen(buffer)], sizeof(buffer) - strlen(buffer))) {
        strcat(buffer, "')");
        return PyString_FromString(buffer);
    } else
	Py_INCREF(Py_None);
	return Py_None;
}

static PyMethodDef Tumbler_methods[] = {
    {NULL,     NULL}  /* sentinel */
};

static PyObject *
Tumbler_getattr(TumblerPyObject *self, char *name)
{
    if (self->x_attr != NULL) {
        PyObject *v = PyDict_GetItemString(self->x_attr, name);
        if (v != NULL) {
            Py_INCREF(v);
            return v;
        }
    }
    return Py_FindMethod(Tumbler_methods, (PyObject *)self, name);
}

static int
Tumbler_setattr(TumblerPyObject *self, char *name, PyObject *v)
{
    if (self->x_attr == NULL) {
        self->x_attr = PyDict_New();
        if (self->x_attr == NULL)
            return -1;
    }

    if (v == NULL) {
        int rv = PyDict_DelItemString(self->x_attr, name);
        if (rv < 0)
            PyErr_SetString(PyExc_AttributeError,
                            "delete non-existing Tumbler attribute");
        return rv;
    } else
        return PyDict_SetItemString(self->x_attr, name, v);
}

bool
str_to_tumbler(const char *s, Tumbler *t)
{
    int i;

    tumblerclear(t);

    if (*s == '-') {
        s++;
        t->sign = 1;
    }

    for (i = 0; i < NPLACES; ++i) {
        unsigned accum = 0;
        bool anydigits = false;

        while (isdigit(*s)) {
            accum = accum * 10 + (*s - '0');
            anydigits = true;
            s++;
        }

        if (!anydigits) {
            PyErr_SetString(PyExc_ValueError, "no digits within tumbler");
            return false;
        }
        t->mantissa[i] = accum;

        if (t->mantissa[i] == 0 && i == 0) {
            --t->exp;
            --i;
        }

        if (*s == '.')  s++;
        else break;
    }

    if (*s != '\0') {
        s++;
        PyErr_SetString(PyExc_ValueError, "tumbler overflow");
        return false;
    }

    for (i = 0; i < NPLACES && t->mantissa[i] == 0; ++i)
        ;

    if (i == NPLACES)
        t->exp = 0;

    return true;
}
