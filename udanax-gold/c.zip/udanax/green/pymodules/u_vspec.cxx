/**********************************************************************
 * Copyright 2002 Jeff Rush <jrush@taupro.com>
 * Original Copyright 1979-2002 Udanax.com
 *
 * This file is part of the Udanax xanalogical storage system.
 *
 * Udanax is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * Udanax is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with Udanax; if not, write to the Free Software Foundation,
 * Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 **********************************************************************/

/**
 * @file  u_vspec.cxx
 * @brief ???
 *
 * (to be defined)
 *
 **/

/* Modification History:
 * $Log: u_vspec.cxx,v $
 * Revision 1.7  2002/05/28 04:01:48  jrush
 * Sources changed to comply with GPL licensing.
 *
 * Revision 1.6  2002/04/08 20:46:46  jrush
 * Grouped python type structures and functions into
 * udanaxmodule.h.  Also eliminated use of global sessx
 * variable and use the one in Session objects instead.
 *
 * Revision 1.5  2002/04/08 18:58:07  jrush
 * Renamed xxxObject to xxxPyObject for easier to follow Doxygen graphs.
 *
 * Revision 1.4  2002/04/07 22:09:38  jrush
 * Added documentation header to top of source file.
 *
 *
 */

static char vspec__doc__ [] =
"This type provides access to operating system functionality that is\n\
standardized by the C Standard and the POSIX standard (a thinly\n\
disguised Unix interface).  Refer to the library manual and\n\
corresponding Unix manual entries for more information on calls.
";

/* VSpec objects */

#include "udanaxmodule.h"

static void      VSpec_dealloc(VSpecPyObject *self);
static PyObject *VSpec_str(VSpecPyObject *obj);
static PyObject *VSpec_repr(VSpecPyObject *obj);

PyNumberMethods VSpec_NumberMethods = {
	/* For numbers without flag bit Py_TPFLAGS_CHECKTYPES set, all
	   arguments are guaranteed to be of the object's type (modulo
	   coercion hacks that is -- i.e. if the type's coercion function
	   returns other types, then these are allowed as well).  Numbers that
	   have the Py_TPFLAGS_CHECKTYPES flag bit set should check *both*
	   arguments for proper type and implement the necessary conversions
	   in the slot functions themselves. */

    (binaryfunc)  0,                                             /*nb_add*/
    (binaryfunc)  0,                                        /*nb_subtract*/
    (binaryfunc)  0,                                        /*nb_multiply*/
    (binaryfunc)  0,                                          /*nb_divide*/
    (binaryfunc)  0,                                       /*nb_remainder*/
    (binaryfunc)  0,                                          /*nb_divmod*/
    (ternaryfunc) 0,                                           /*nb_power*/
    (unaryfunc)   0,                                        /*nb_negative*/
    (unaryfunc)   0,                                        /*nb_positive*/
    (unaryfunc)   0,                                        /*nb_absolute*/
    (inquiry)     0,                                         /*nb_nonzero*/
    (unaryfunc)   0,                                          /*nb_invert*/
    (binaryfunc)  0,                                          /*nb_lshift*/
    (binaryfunc)  0,                                          /*nb_rshift*/
    (binaryfunc)  0,                                             /*nb_and*/
    (binaryfunc)  0,                                             /*nb_xor*/
    (binaryfunc)  0,                                              /*nb_or*/
    (coercion)    0,                                          /*nb_coerce*/
    (unaryfunc)   0,                                             /*nb_int*/
    (unaryfunc)   0,                                            /*nb_long*/
    (unaryfunc)   0,                                           /*nb_float*/
    (unaryfunc)   0,                                             /*nb_oct*/
    (unaryfunc)   0,                                             /*nb_hex*/
    (binaryfunc)  0,                                     /*nb_inplace_add*/
    (binaryfunc)  0,                                /*nb_inplace_subtract*/
    (binaryfunc)  0,                                /*nb_inplace_multiply*/
    (binaryfunc)  0,                                  /*nb_inplace_divide*/
    (binaryfunc)  0,                               /*nb_inplace_remainder*/
    (ternaryfunc) 0,                                   /*nb_inplace_power*/
    (binaryfunc)  0,                                  /*nb_inplace_lshift*/
    (binaryfunc)  0,                                  /*nb_inplace_rshift*/
    (binaryfunc)  0,                                     /*nb_inplace_and*/
    (binaryfunc)  0,                                     /*nb_inplace_xor*/
    (binaryfunc)  0,                                      /*nb_inplace_or*/
};

/*
 * Returns the length, in bytes, of the particular subportion of a document.
 */
static int
VSpec_sq_length(VSpecPyObject *self)
{
    typevstuffset  vstuffset; // Set coming out
    bool f = doretrievev(self->x_doc->x_sess->x_sess, &self->x_spec, &vstuffset);
    if (!f) {
        PyErr_SetString(PyExc_AttributeError,
                        "doretrievev failed");
        return -1;
    }

    int nbytes = 0;
    for (typevstuff *vs = vstuffset; vs; vs = (typevstuff *) vs->xxxtext.next) {
        if (vs->xxxtext.itemid == TEXTID)
            nbytes += vs->xxxtext.length;
    }

    return nbytes;
}

PySequenceMethods VSpec_SequenceMethods = {
    (inquiry)          &VSpec_sq_length,                      /*sq_length*/
    (binaryfunc)       0,                                     /*sq_concat*/
    (intargfunc)       0,                                     /*sq_repeat*/
    (intargfunc)       0,                                       /*sq_item*/
    (intintargfunc)    0,                                      /*sq_slice*/
    (intobjargproc)    0,                                   /*sq_ass_item*/
    (intintobjargproc) 0,                                  /*sq_ass_slice*/
    (objobjproc)       0,                                   /*sq_contains*/
    (binaryfunc)       0,                             /*sq_inplace_concat*/
    (intargfunc)       0,                             /*sq_inplace_repeat*/
};

PyTypeObject VSpec_Type = {
    /* The ob_type field must be initialized in the module init function
     * to be portable to Windows without using C++.
     */
    PyObject_HEAD_INIT(NULL)
    0,                                                          /*ob_size*/
    "VSpec",                                                    /*tp_name*/
    sizeof(VSpecPyObject),                                 /*tp_basicsize*/
    0,                                                      /*tp_itemsize*/
    /* Methods to implement standard operations */
    (destructor) VSpec_dealloc,                              /*tp_dealloc*/
    0,                                                         /*tp_print*/
    (getattrfunc) 0,                                         /*tp_getattr*/
    (setattrfunc) 0,                                         /*tp_setattr*/
    0,                                                       /*tp_compare*/
    (reprfunc) VSpec_repr,                                      /*tp_repr*/
    /* Method suites for standard classes */
    &VSpec_NumberMethods,                                  /*tp_as_number*/
    &VSpec_SequenceMethods,                              /*tp_as_sequence*/
    0,                                                    /*tp_as_mapping*/
    /* More standard operations (here for binary compatibility) */
    0,                                                          /*tp_hash*/
    (ternaryfunc) 0,                                            /*tp_call*/
    (reprfunc) VSpec_str,                                        /*tp_str*/
    (getattrofunc) 0,                                       /*tp_getattro*/
    (setattrofunc) 0,                                       /*tp_setattro*/
    /* Functions to access object as input/output buffer */
    (PyBufferProcs *) 0,                                   /*tp_as_buffer*/
    /* Flags to define presence of optional/expanded features */
    (long) 0,                                                  /*tp_flags*/
    (char *) vspec__doc__,                       /* Documentation string */
    /* call function for all accessible objects */
    (traverseproc) 0,                                       /*tp_traverse*/
    /* delete references to contained objects */
    (inquiry) 0,                                               /*tp_clear*/
    /* rich comparisons */
    (richcmpfunc) 0,                                     /*tp_richcompare*/
    /* weak reference enabler */
    (long) 0,                                         /*tp_weaklistoffset*/
};

PyObject *
wrapVSpecPyObject(DocumentPyObject *docobj, int from, int to)
{
    VSpecPyObject *self;

    self = PyObject_New(VSpecPyObject, &VSpec_Type);
    if (self == NULL)
        return NULL;

    self->x_spec.xxxvspec.next   = NULL; // Single-Item specset, containing a list of vspans
    self->x_spec.xxxvspec.itemid = VSPECID;
    tumblercopy(&docobj->x_docid, &self->x_spec.xxxvspec.docisa);

    self->x_span.next   = NULL;
    self->x_span.itemid = VSPANID;

    str_to_tumbler("1.1", &self->x_span.stream);
    self->x_span.stream.mantissa[1] = from + 1;

    str_to_tumbler("0.1", &self->x_span.width);
    self->x_span.width.mantissa[0] =  abs(to - from);

    self->x_spec.xxxvspec.vspanset = &self->x_span;

    return (PyObject *) self;
}

static void
VSpec_dealloc(VSpecPyObject *self)
{
    PyObject_Del(self);
}

typespec *
VSpec_asSpec(VSpecPyObject *self)
{
    typespec *spec = &((VSpecPyObject *)self)->x_spec;

    printf("(VSpec_asSpec\n"); putitemset(self->x_doc->x_sess->x_sess, (typeitem *) spec);  printf(")\n");
    return spec;
}

/* VSpec methods */

static PyObject *
VSpec_str(VSpecPyObject *self)
{
    typevstuffset  vstuffset; // Set coming out
    bool f = doretrievev(self->x_doc->x_sess->x_sess, &self->x_spec, &vstuffset);
    if (!f) {
        PyErr_SetString(PyExc_AttributeError,
                        "doretrievev failed");
        return NULL;
    }

    int nbytes = 0;
    typevstuff *vs = vstuffset;
    while (vs) { // Walk list and sum bytecounts
        if (vs->xxxtext.itemid == TEXTID)
            nbytes += vs->xxxtext.length;
        vs = (typevstuff *) vs->xxxtext.next;
    }

    PyObject *str = PyString_FromStringAndSize(NULL, nbytes);
    if (!str)
        return NULL;

    char *s = ((PyStringObject *) str)->ob_sval;

    vs = vstuffset;
    while (vs) { // Re-Walk list and copy bytes into string
        if (vs->xxxtext.itemid == TEXTID) {
            memcpy(s, vs->xxxtext.string, vs->xxxtext.length);
            s += vs->xxxtext.length;
        }
        vs = (typevstuff *) vs->xxxtext.next;
    }
    return str;
}

static PyObject *
VSpec_repr(VSpecPyObject *self)
{
    char buffer[128] = "VSpec(docid='";

    if (tumbler_to_str(&self->x_spec.xxxvspec.docisa, &buffer[strlen(buffer)], sizeof(buffer) - strlen(buffer))) {
        strcat(buffer, "', vspan=(");

        int from = self->x_span.stream.mantissa[1] - 1;
        int to   = self->x_span.width.mantissa[0] + from;

        sprintf(&buffer[strlen(buffer)], "%u, %u", from, to);

        strcat(buffer, "))");
        return PyString_FromString(buffer);
    } else
	Py_INCREF(Py_None);
	return Py_None;
}
