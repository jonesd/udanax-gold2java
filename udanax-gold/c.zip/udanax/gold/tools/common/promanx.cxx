/* Copyright Xanadu Operating Company.  All Rights Reserved. */

/******************************************************************************
*                                                                            *
* The information contained herein is confidential, proprietary to Xanadu    *
* Operating Company, and considered a trade secret as defined in section     * 
* 499C of the penal code of the State of California.  Use of this information* 
* by anyone other than authorized employees of Xanadu is granted             *
* only under a  written non-disclosure agreement, expressly prescribing      * 
* the scope and  manner of such use.                                         *
*                                                                            *
***************************************************************************
Output from Objectworks for Smalltalk-80(tm), Version 2.5 of 29 July 1989
*/

#ifndef PROMANX_CXX
#define PROMANX_CXX


#ifndef CHOOSEX_HXX
#include "choosex.hxx"
#endif /* CHOOSEX_HXX */

#ifndef PROMANX_HXX
#include "promanx.hxx"
#endif /* PROMANX_HXX */

#ifndef PROMANX_IXX
#include "promanx.ixx"
#endif /* PROMANX_IXX */

#ifndef PROMANR_HXX
#include "promanr.hxx"
#endif /* PROMANR_HXX */

#ifndef PROMANR_IXX
#include "promanr.ixx"
#endif /* PROMANR_IXX */

#ifndef PROMANP_HXX
#include "promanp.hxx"
#endif /* PROMANP_HXX */

#ifndef PROMANP_IXX
#include "promanp.ixx"
#endif /* PROMANP_IXX */


#ifndef BOMBX_HXX
#include "bombx.hxx"
#endif /* BOMBX_HXX */

#ifndef CROSSX_HXX
#include "crossx.hxx"
#endif /* CROSSX_HXX */

#ifndef DETECTX_HXX
#include "detectx.hxx"
#endif /* DETECTX_HXX */

#ifndef FHASHX_HXX
#include "fhashx.hxx"
#endif /* FHASHX_HXX */

#ifndef FILETPX_HXX
#include "filetpx.hxx"
#endif /* FILETPX_HXX */

#ifndef FILTERX_HXX
#include "filterx.hxx"
#endif /* FILTERX_HXX */

#ifndef IDX_HXX
#include "idx.hxx"
#endif /* IDX_HXX */

#ifndef INTEGERX_HXX
#include "integerx.hxx"
#endif /* INTEGERX_HXX */

#ifndef LOGGERX_HXX
#include "loggerx.hxx"
#endif /* LOGGERX_HXX */

#ifndef NADMINX_HXX
#include "nadminx.hxx"
#endif /* NADMINX_HXX */

#ifndef NKERNELX_HXX
#include "nkernelx.hxx"
#endif /* NKERNELX_HXX */

#ifndef NLINKSX_HXX
#include "nlinksx.hxx"
#endif /* NLINKSX_HXX */

#ifndef NXCVRX_HXX
#include "nxcvrx.hxx"
#endif /* NXCVRX_HXX */

#ifndef PORTALR_HXX
#include "portalr.hxx"
#endif /* PORTALR_HXX */

#ifndef PRIMVALX_HXX
#include "primvalx.hxx"
#endif /* PRIMVALX_HXX */

#ifndef REALX_HXX
#include "realx.hxx"
#endif /* REALX_HXX */

#ifndef SEQUENCX_HXX
#include "sequencx.hxx"
#endif /* SEQUENCX_HXX */

#ifndef SPACEX_HXX
#include "spacex.hxx"
#endif /* SPACEX_HXX */

#ifndef STEPPERX_HXX
#include "stepperx.hxx"
#endif /* STEPPERX_HXX */

#ifndef STRINGX_HXX
#include "stringx.hxx"
#endif /* STRINGX_HXX */

#ifndef SYSADMX_HXX
#include "sysadmx.hxx"
#endif /* SYSADMX_HXX */

#ifndef TXTCOMMX_HXX
#include "txtcommx.hxx"
#endif /* TXTCOMMX_HXX */

#ifndef WRAPPERX_HXX
#include "wrapperx.hxx"
#endif /* WRAPPERX_HXX */




/* ************************************************************************ *
 * 
 *                    Class PromiseManager 
 *
 * ************************************************************************ */



/* Initializers for PromiseManager */

GPTR(PtrArray) OF1(Category) PromiseManager::PromiseClasses = NULL;
GPTR(PtrArray) OF1(RequestHandler) PromiseManager::AllRequests = NULL;
DEFINE_LOGGER(BlastLog,NULL);	/* in PromiseManager */



BEGIN_INIT_TIME(PromiseManager,initTimeNonInherited) {
	PromiseManager::PromiseClasses = PtrArray::nulls(100);
	PromiseManager::fillClassTable(PromiseManager::PromiseClasses);
	PromiseManager::AllRequests = PtrArray::nulls(500);
	PromiseManager::AllRequests->storeAll(SpecialHandler::make ((VHFn)&PromiseManager::noRequest));
	/* LoginRequests _ PtrArray nulls: 500.
			LoginRequests storeAll: 
				(SpecialHandler make: (PromiseManager 
		pointerToStaticMember: #notLoginRequest: with: 'VHFn')). */
	PromiseManager::fillRequestTable(PromiseManager::AllRequests);
} END_INIT_TIME(PromiseManager,initTimeNonInherited);


/* exceptions: exceptions */



/* Initializers for PromiseManager */






/* constants */


Int32 PromiseManager::ackResponse (){
	return Int32Zero;
}


Int32 PromiseManager::doneResponse (){
	return 14;
}


Int32 PromiseManager::errorResponse (){
	return 1;
}


Int32 PromiseManager::excusedResponse (){
	return 2;
}


Int32 PromiseManager::filledResponse (){
	return 13;
}


Int32 PromiseManager::grabbedResponse (){
	return 9;
}


Int32 PromiseManager::humberResponse (){
	return 3;
}


Int32 PromiseManager::humbersResponse (){
	return 5;
}


Int32 PromiseManager::IEEEResponse (){
	return 4;
}


Int32 PromiseManager::IEEEsResponse (){
	return 7;
}


Int32 PromiseManager::intsResponse (){
	return 6;
}


Int32 PromiseManager::problemNumber (char * prob){
	/* The number that gets sent over the wire for the given 
	problem name */
	/* PromiseManager problemNumber: 'VALUE_IS_UNKIND'  */
	
	return ::fastHash(prob) & 16777215;
}


Int32 PromiseManager::problemSource (char * file, int line){
	/* The number that gets sent over the wire for the given 
	problem file/line number */
	
	return (::fastHash(file) & 65535) << 15 ^ line & 32767;
}


Int32 PromiseManager::promisesResponse (){
	return 8;
}


Int32 PromiseManager::rangeFilledResponse (){
	return 12;
}


Int32 PromiseManager::releasedResponse (){
	return 10;
}


Int32 PromiseManager::revisedResponse (){
	return 11;
}


Int32 PromiseManager::terminatedResponse (){
	return 15;
}
/* creation */


RPTR(PromiseManager) PromiseManager::make (APTR(Portal) portal){
	SPTR(Rcvr) reader;
	SPTR(Xmtr) writer;
	char * target;
	SPTR(ByteShuffler) shuffler;
	
	reader = TextyXcvrMaker::makeReader(portal->readStream());
	writer = TextyXcvrMaker::makeWriter(portal->writeStream());
	/* Thing to do !!!! */
	
	/* Make the following loop a helper routine. */
		/* Meta-protocol */
	target = reader->receiveString();
	while (!(::strcmp(target, "simple") == Int32Zero)) {
		delete target;
		target = NULL;
		writer->sendString("no!");
		target = reader->receiveString();
	}
	writer->sendString("yes");
	delete target;
	target = NULL;
	/* Architecture. */
	target = reader->receiveString();
	while (!(::strcmp(target, "sun") == Int32Zero || ::strcmp(target, "intel") == Int32Zero)) {
		delete target;
		target = NULL;
		writer->sendString("no!");
		target = reader->receiveString();
	}
	
	if (::strcmp(target, "intel") == Int32Zero) {
		CONSTRUCT(shuffler,SimpleShuffler,());
	} else {
		CONSTRUCT(shuffler,NoShuffler,());
	}
	
	delete target;
	target = NULL;
	writer->sendString("yes");
	/* Syntax */
	target = reader->receiveString();
	while (!(::strcmp(target, "binary2") == Int32Zero)) {
		delete target;
		target = NULL;
		writer->sendString("no!");
		target = reader->receiveString();
	}
	delete target;
	target = NULL;
	writer->sendString("yes");
	/* Semantics */
	target = reader->receiveString();
	while (!(::strcmp(target, "febe92.2") == Int32Zero)) {
		delete target;
		target = NULL;
		writer->sendString("no!");
		target = reader->receiveString();
	}
	writer->sendString("yes");
	{writer->destroy();  writer = NULL /* don't want stale (S/CHK)PTRs */;}
	{reader->destroy();  reader = NULL /* don't want stale (S/CHK)PTRs */;}
	RETURN_CONSTRUCT(PromiseManager,(portal, target, shuffler));
}
/* detector requests */


void PromiseManager::fillDetector (APTR(PromiseManager) pm){
	/* Create the comm detector and add it. */
	
	SPTR(FeRangeElement) OR(NULL) rangeElement;
	
	rangeElement = CAST(FeRangeElement,pm->fetchNonNullHeaper(cat_FeRangeElement));
	if (pm->noErrors()) {
		SPTR(FeFillDetector) detector;
		
		detector = 
				CommFillDetector::make (pm, pm->clientPromiseNumber(), rangeElement);
		rangeElement->addFillDetector(detector);
		pm->respondHeaper(detector);
	}
}


void PromiseManager::fillRangeDetector (APTR(PromiseManager) pm){
	/* Create the comm detector and add it. */
	
	SPTR(FeEdition) OR(NULL) receiver;
	
	receiver = CAST(FeEdition,pm->fetchNonNullHeaper(cat_FeEdition));
	if (pm->noErrors()) {
		SPTR(FeFillRangeDetector) detector;
		
		detector = 
				CommFillRangeDetector::make (pm, pm->clientPromiseNumber(), receiver);
		receiver->addFillRangeDetector(detector);
		pm->respondHeaper(detector);
	}
}


void PromiseManager::revisionDetector (APTR(PromiseManager) pm){
	/* Create the comm detector and add it. */
	
	SPTR(FeWork) OR(NULL) receiver;
	
	receiver = CAST(FeWork,pm->fetchNonNullHeaper(cat_FeWork));
	if (pm->noErrors()) {
		SPTR(FeRevisionDetector) detector;
		
		detector = 
				CommRevisionDetector::make (pm, pm->clientPromiseNumber(), receiver);
		receiver->addRevisionDetector(detector);
		pm->respondHeaper(detector);
	}
}


void PromiseManager::statusDetector (APTR(PromiseManager) pm){
	/* Create the comm detector and add it. */
	
	SPTR(FeWork) OR(NULL) receiver;
	
	receiver = CAST(FeWork,pm->fetchNonNullHeaper(cat_FeWork));
	if (pm->noErrors()) {
		SPTR(FeStatusDetector) detector;
		
		detector = 
				CommStatusDetector::make (pm, pm->clientPromiseNumber(), receiver);
		receiver->addStatusDetector(detector);
		pm->respondHeaper(detector);
	}
}


void PromiseManager::waitForConsequences (APTR(PromiseManager) pm){
	/* Create the comm detector and add it. */
	
	SPTR(FeWaitDetector) detector;
	
	detector = CommWaitDetector::make (pm, pm->clientPromiseNumber());
	FeServer::waitForConsequences(detector);
	pm->respondHeaper(detector);
}


void PromiseManager::waitForWrite (APTR(PromiseManager) pm){
	/* Create the comm detector and add it. */
	
	SPTR(FeWaitDetector) detector;
	
	detector = CommWaitDetector::make (pm, pm->clientPromiseNumber());
	FeServer::waitForWrite(detector);
	pm->respondHeaper(detector);
}
/* misc requests */


void PromiseManager::delayCast (APTR(PromiseManager) pm){
	SPTR(Heaper) result;
	SPTR(Category) cat;
	
	result = pm->fetchHeaper(cat_Heaper);
	cat = pm->fetchCategory();
	if (pm->noErrors()) {
		{	BooleanVar crutch_Flag;
			/* result == NULL || result->isKindOf(cat) */
			
			crutch_Flag = result == NULL;
			if(!crutch_Flag) {
				crutch_Flag = result->isKindOf(cat);
			}
			if (!crutch_Flag) {
				BLAST(CastFailed);
			}
		}
		pm->respondHeaper(result);
	}
}


void PromiseManager::equals (APTR(PromiseManager) pm){
	SPTR(Heaper) me;
	SPTR(Heaper) him;
	
	me = pm->fetchNonNullHeaper(cat_Heaper);
	him = pm->fetchNonNullHeaper(cat_Heaper);
	if (pm->noErrors()) {
		pm->respondBooleanVar(me->isEqual(him));
	}
}


void PromiseManager::export0 (APTR(PromiseManager) pm){
	/* The zero argument version of PrimArray export. */
	
	SPTR(PrimArray) array;
	
	array = CAST(PrimArray,pm->fetchNonNullHeaper(cat_PrimArray));
	if (pm->noErrors()) {
		BEGIN_CHOOSE(array) {
			BEGIN_KIND(PrimIntArray,a) {
				pm->sendInts(a, a->count(), Int32Zero);
			} END_KIND;
			BEGIN_KIND(IntegerVarArray,a) {
				pm->sendHumbers(a, a->count(), Int32Zero);
			} END_KIND;
			BEGIN_KIND(PtrArray,a) {
				pm->sendPromises(a, a->count(), Int32Zero);
			} END_KIND;
			BEGIN_KIND(PrimFloatArray,a) {
				pm->sendIEEEs(a, a->count(), Int32Zero);
			} END_KIND;
		} END_CHOOSE;
	}
}


void PromiseManager::export1 (APTR(PromiseManager) pm){
	/* The one argument version of PrimArray export. */
	
	SPTR(PrimArray) array;
	Int32 count;
	
	array = CAST(PrimArray,pm->fetchNonNullHeaper(cat_PrimArray));
	count = pm->fetchInt32();
	if (pm->noErrors()) {
		BEGIN_CHOOSE(array) {
			BEGIN_KIND(PrimIntArray,a) {
				pm->sendInts(a, count, Int32Zero);
			} END_KIND;
			BEGIN_KIND(IntegerVarArray,a) {
				pm->sendHumbers(a, count, Int32Zero);
			} END_KIND;
			BEGIN_KIND(PtrArray,a) {
				pm->sendPromises(a, count, Int32Zero);
			} END_KIND;
			BEGIN_KIND(PrimFloatArray,a) {
				pm->sendIEEEs(a, count, Int32Zero);
			} END_KIND;
		} END_CHOOSE;
	}
}


void PromiseManager::export2 (APTR(PromiseManager) pm){
	/* The two argument version of PrimArray export. */
	
	SPTR(PrimArray) array;
	Int32 count;
	Int32 start;
	
	array = CAST(PrimArray,pm->fetchNonNullHeaper(cat_PrimArray));
	count = pm->fetchInt32();
	start = pm->fetchInt32();
	if (pm->noErrors()) {
		BEGIN_CHOOSE(array) {
			BEGIN_KIND(PrimIntArray,a) {
				pm->sendInts(a, count, start);
			} END_KIND;
			BEGIN_KIND(IntegerVarArray,a) {
				pm->sendHumbers(a, count, start);
			} END_KIND;
			BEGIN_KIND(PtrArray,a) {
				pm->sendPromises(a, count, start);
			} END_KIND;
			BEGIN_KIND(PrimFloatArray,a) {
				pm->sendIEEEs(a, count, start);
			} END_KIND;
		} END_CHOOSE;
	}
}


void PromiseManager::forceIt (APTR(PromiseManager) pm){
	pm->force();
}


RPTR(PtrArray) OF1(RequestHandler) PromiseManager::makeRequestTable (){
	/* PromiseManager makeRequestTable. */
	
	SPTR(PtrArray) table;
	
	table = PtrArray::nulls(500);
	table->storeAll(SpecialHandler::make ((VHFn)&PromiseManager::noRequest));
	PromiseManager::fillRequestTable(table);
	WPTR(PtrArray) OF1(RequestHandler) 	returnValue;
	returnValue = table;
	return returnValue;
}


void PromiseManager::noRequest (APTR(PromiseManager) /* pm */){
	/* For illegal requests. */
	
	BLAST(BadRequest);
}


void PromiseManager::notLoggedInRequest (APTR(PromiseManager) /* pm */){
	/* For illegal requests. */
	
	BLAST(NotLoggedIn);
}


void PromiseManager::promiseHash (APTR(PromiseManager) pm){
	SPTR(Heaper) me;
	
	me = pm->fetchNonNullHeaper(cat_Heaper);
	if (pm->noErrors()) {
		pm->respondIntegerVar(me->hashForEqual());
	}
}


void PromiseManager::setCurrentAuthor (APTR(PromiseManager) pm){
	/* The one argument version of PrimArray export. */
	
	SPTR(ID) iD;
	
	iD = CAST(ID,pm->fetchHeaper(cat_ID));
	if (pm->noErrors()) {
		FeServer::setCurrentAuthor(iD);
	}
}


void PromiseManager::setCurrentKeyMaster (APTR(PromiseManager) pm){
	/* Set the fluid. */
	
	SPTR(FeKeyMaster) keymaster;
	
	keymaster = CAST(FeKeyMaster,pm->fetchHeaper(cat_FeKeyMaster));
	if (pm->noErrors()) {
		FeServer::setCurrentKeyMaster(keymaster);
	}
}


void PromiseManager::setInitialEditClub (APTR(PromiseManager) pm){
	/* Set the fluid. */
	
	SPTR(ID) iD;
	
	iD = CAST(ID,pm->fetchHeaper(cat_ID));
	if (pm->noErrors()) {
		FeServer::setInitialEditClub(iD);
	}
}


void PromiseManager::setInitialOwner (APTR(PromiseManager) pm){
	/* Set the fluid. */
	
	SPTR(ID) iD;
	
	iD = CAST(ID,pm->fetchHeaper(cat_ID));
	if (pm->noErrors()) {
		FeServer::setInitialOwner(iD);
	}
}


void PromiseManager::setInitialReadClub (APTR(PromiseManager) pm){
	/* Set the fluid. */
	
	SPTR(ID) iD;
	
	iD = CAST(ID,pm->fetchHeaper(cat_ID));
	if (pm->noErrors()) {
		FeServer::setInitialReadClub(iD);
	}
}


void PromiseManager::setInitialSponsor (APTR(PromiseManager) pm){
	/* Set the fluid. */
	
	SPTR(ID) iD;
	
	iD = CAST(ID,pm->fetchHeaper(cat_ID));
	if (pm->noErrors()) {
		FeServer::setInitialSponsor(iD);
	}
}


void PromiseManager::shutdown (APTR(PromiseManager) pm){
	SPTR(FeAdminer) adm;
	
	adm = CAST(FeAdminer,pm->fetchNonNullHeaper(cat_FeAdminer));
	if (pm->noErrors()) {
		pm->force();
		adm->shutdown();
	}
}


void PromiseManager::testKindOf (APTR(PromiseManager) pm){
	SPTR(Heaper) result;
	SPTR(Category) cat;
	
	result = pm->fetchNonNullHeaper(cat_Heaper);
	cat = pm->fetchCategory();
	if (pm->noErrors()) {
		pm->respondBooleanVar(result->isKindOf(cat));
	}
}


void PromiseManager::waiveEm (APTR(PromiseManager) pm){
	pm->waiveMany();
}


void PromiseManager::waiveIt (APTR(PromiseManager) pm){
	pm->waive();
}
/* making requests */


void PromiseManager::makeFloat (APTR(PromiseManager) pm){
	/* <sizeof> <byte>*  */
	
	Int32 size;
	
	size = pm->receiveIntegerVar().asLong();
	if (size == 4) {
		IEEE32 f;
		pm->readStream ()->getBytes ((void *) &f, 4);
		pm->respondHeaper (PrimIEEE32::make (f));
		return;
		
	} else {
		if (size == 8) {
			IEEE64 f;
		pm->readStream ()->getBytes ((void *) &f, 8);
		pm->respondHeaper (PrimIEEE64::make (f));
		return;
			
		}
	}
	{
		for (Int32 T_LoopVar = size; T_LoopVar > 0; T_LoopVar -= 1) {
			pm->readStream()->getByte();
		}
	}
	if (pm->noErrors()) {
		BLAST(NOT_YET_IMPLEMENTED);
	}
}


void PromiseManager::makeFloatArray (APTR(PromiseManager) pm){
	IntegerVar sizeofFloat;
	IntegerVar count;
	
	sizeofFloat = pm->receiveIntegerVar();
	count = pm->receiveIntegerVar();
	if (pm->noErrors()) {
		Int32 size;
		UInt8* buffer;
		SPTR(PrimFloatArray) result;
		
		size = (sizeofFloat * count).asLong();
		
		if (size > 0) {
			buffer = new UInt8[size];
		} else {
			buffer = NULL;
		}
		
		pm->readStream()->getBytes(buffer, size);
		result = CAST(PrimFloatArray,PrimSpec::iEEE((sizeofFloat * 8).asLong())->arrayFromBuffer(count.asLong(), buffer));
		if (buffer != NULL) {
			delete buffer;
		}
		pm->respondHeaper(result);
	}
}


void PromiseManager::makeHumber (APTR(PromiseManager) pm){
	IntegerVar num;
	
	num = pm->receiveIntegerVar();
	if (pm->noErrors()) {
		pm->respondHeaper(PrimIntValue::make (num));
	}
}


void PromiseManager::makeHumberArray (APTR(PromiseManager) pm){
	Int32 count;
	SPTR(PrimIntegerArray) result;
	
	count = pm->receiveIntegerVar().asLong();
	result = IntegerVarArray::zeros(count);
	{
		Int32 LoopFinal = count;
		Int32 i = Int32Zero;
		for (;;) {
			if (i >= LoopFinal){
				break;
			}
			{
				result->storeInteger(i, pm->receiveIntegerVar());
			}
			i += 1;
		}
	}
	if (pm->noErrors()) {
		pm->respondHeaper(result);
	}
}


void PromiseManager::makeIntArray (APTR(PromiseManager) pm){
	IntegerVar precision;
	IntegerVar count;
	Int32 size;
	UInt8* buffer;
	Int32 bits;
	SPTR(PrimSpec) spec;
	SPTR(PrimIntegerArray) result;
	
	precision = pm->receiveIntegerVar();
	count = pm->receiveIntegerVar();
	bits = abs(precision).asLong();
	size = (abs(precision) / 8 * count).asLong();
	
	if (size > 0) {
		buffer = new UInt8[size];
	} else {
		buffer = NULL;
	}
	
	pm->readStream()->getBytes(buffer, size);
	if (precision < Int32Zero) {
		spec = PrimSpec::signedInteger(bits);
	} else {
		spec = PrimSpec::unsignedInteger(bits);
	}
	result = CAST(PrimIntegerArray,spec->arrayFromBuffer(count.asLong(), buffer));
	if (buffer != NULL) {
		delete buffer;
	}
	pm->respondHeaper(result);
}


void PromiseManager::makePtrArray (APTR(PromiseManager) pm){
	/* If any of the promises is an error, then pm won't return 
	the PtrArray. */
	
	Int32 count;
	SPTR(PtrArray) result;
	
	count = pm->receiveIntegerVar().asLong();
	result = PtrArray::nulls(count);
	{
		Int32 LoopFinal = count;
		Int32 i = Int32Zero;
		for (;;) {
			if (i >= LoopFinal){
				break;
			}
			{
				result->store(i, pm->fetchHeaper(cat_Heaper));
			}
			i += 1;
		}
	}
	if (pm->noErrors()) {
		pm->respondHeaper(result);
	}
}
/* translate: generated */


void PromiseManager::fillClassTable (APTR(PtrArray) table){
	table->storeValue(1, cat_Heaper);
	table->storeValue(2, cat_FeAdminer);
	table->storeValue(3, cat_FeArchiver);
	table->storeValue(4, cat_PrimArray);
	table->storeValue(5, cat_PrimFloatArray);
	table->storeValue(6, cat_IntegerVarArray);
	table->storeValue(7, cat_PrimIntArray);
	table->storeValue(8, cat_PtrArray);
	table->storeValue(9, cat_FeBundle);
	table->storeValue(10, cat_FeArrayBundle);
	table->storeValue(11, cat_FeElementBundle);
	table->storeValue(12, cat_FePlaceHolderBundle);
	table->storeValue(13, cat_CoordinateSpace);
	table->storeValue(14, cat_CrossSpace);
	table->storeValue(15, cat_FilterSpace);
	table->storeValue(16, cat_IDSpace);
	table->storeValue(17, cat_IntegerSpace);
	table->storeValue(18, cat_RealSpace);
	table->storeValue(19, cat_SequenceSpace);
	table->storeValue(20, cat_FeFillRangeDetector);
	table->storeValue(21, cat_FeFillDetector);
	table->storeValue(22, cat_FeKeyMaster);
	table->storeValue(23, cat_Lock);
	table->storeValue(24, cat_BooLock);
	table->storeValue(25, cat_ChallengeLock);
	table->storeValue(26, cat_MatchLock);
	table->storeValue(27, cat_MultiLock);
	table->storeValue(28, cat_WallLock);
	table->storeValue(29, cat_Mapping);
	table->storeValue(30, cat_CrossMapping);
	table->storeValue(31, cat_IntegerMapping);
	table->storeValue(32, cat_SequenceMapping);
	table->storeValue(33, cat_OrderSpec);
	table->storeValue(34, cat_CrossOrderSpec);
	table->storeValue(35, cat_Position);
	table->storeValue(36, cat_FilterPosition);
	table->storeValue(37, cat_ID);
	table->storeValue(38, cat_Sequence);
	table->storeValue(39, cat_Tuple);
	table->storeValue(40, cat_IntegerPos);
	table->storeValue(41, cat_RealPos);
	table->storeValue(42, cat_FeRangeElement);
	table->storeValue(43, cat_FeDataHolder);
	table->storeValue(44, cat_FeEdition);
	table->storeValue(45, cat_FeIDHolder);
	table->storeValue(46, cat_FeLabel);
	table->storeValue(47, cat_FeWork);
	table->storeValue(48, cat_FeClub);
	table->storeValue(49, cat_FeRevisionDetector);
	table->storeValue(50, cat_FeServer);
	table->storeValue(51, cat_FeSession);
	table->storeValue(52, cat_FeStatusDetector);
	table->storeValue(53, cat_Stepper);
	table->storeValue(54, cat_TableStepper);
	table->storeValue(55, cat_FeWaitDetector);
	table->storeValue(56, cat_FeWrapper);
	table->storeValue(57, cat_FeClubDescription);
	table->storeValue(58, cat_FeHyperLink);
	table->storeValue(59, cat_FeHyperRef);
	table->storeValue(60, cat_FeMultiRef);
	table->storeValue(61, cat_FeSingleRef);
	table->storeValue(62, cat_FeLockSmith);
	table->storeValue(63, cat_FeBooLockSmith);
	table->storeValue(64, cat_FeChallengeLockSmith);
	table->storeValue(65, cat_FeMatchLockSmith);
	table->storeValue(66, cat_FeMultiLockSmith);
	table->storeValue(67, cat_FeWallLockSmith);
	table->storeValue(68, cat_FePath);
	table->storeValue(69, cat_FeSet);
	table->storeValue(70, cat_FeText);
	table->storeValue(71, cat_FeWrapperSpec);
	table->storeValue(72, cat_XnRegion);
	table->storeValue(73, cat_CrossRegion);
	table->storeValue(74, cat_Filter);
	table->storeValue(75, cat_IDRegion);
	table->storeValue(76, cat_IntegerRegion);
	table->storeValue(77, cat_RealRegion);
	table->storeValue(78, cat_SequenceRegion);
	table->storeValue(79, cat_PrimValue);
	table->storeValue(80, cat_PrimFloatValue);
	table->storeValue(81, cat_PrimIntValue);
}


void PromiseManager::fillRequestTable1 (APTR(PtrArray) table){
	table->storeValue(27, HHandler::make ((HFn)&RequestHandler::IDSpace_unique_N0));
	table->storeValue(283, HHHandler::make ((HHFn)&RequestHandler::IDSpace_export_N1, cat_IDSpace));
	table->storeValue(430, 
			HHHHandler::make ((HHHFn)&RequestHandler::IDSpace_iDsFromServer_N2, cat_IDSpace, cat_Sequence));
	table->storeValue(28, HHHandler::make ((HHFn)&RequestHandler::IDSpace_newID_N1, cat_IDSpace));
	table->storeValue(29, 
			HHHHandler::make ((HHHFn)&RequestHandler::IDSpace_newIDs_N2, cat_IDSpace, cat_PrimIntValue));
	/* Requests for class IntegerSpace */
	table->storeValue(30, HHandler::make ((HFn)&RequestHandler::IntegerSpace_make_N0));
	table->storeValue(31, HHBHandler::make ((HHBFn)&RequestHandler::IntegerSpace_above_N2, cat_IntegerPos));
	table->storeValue(32, HHBHandler::make ((HHBFn)&RequestHandler::IntegerSpace_below_N2, cat_IntegerPos));
	table->storeValue(33, 
			HHHHandler::make ((HHHFn)&RequestHandler::IntegerSpace_interval_N2, cat_IntegerPos, cat_IntegerPos));
	table->storeValue(34, HHHandler::make ((HHFn)&RequestHandler::IntegerSpace_position_N1, cat_PrimIntValue));
	table->storeValue(35, HHHandler::make ((HHFn)&RequestHandler::IntegerSpace_translation_N1, cat_PrimIntValue));
	/* Requests for class RealSpace */
	table->storeValue(284, HHandler::make ((HFn)&RequestHandler::RealSpace_make_N0));
	table->storeValue(36, 
			HHHBHandler::make ((HHHBFn)&RequestHandler::RealSpace_above_N3, cat_RealSpace, cat_RealPos));
	table->storeValue(37, 
			HHHBHandler::make ((HHHBFn)&RequestHandler::RealSpace_below_N3, cat_RealSpace, cat_RealPos));
	table->storeValue(38, 
			HHHHHandler::make ((HHHHFn)&RequestHandler::RealSpace_interval_N3, cat_RealSpace, cat_RealPos, cat_RealPos));
	table->storeValue(39, 
			HHHHandler::make ((HHHFn)&RequestHandler::RealSpace_position_N2, cat_RealSpace, cat_PrimFloatValue));
	/* Requests for class SequenceSpace */
	table->storeValue(40, HHandler::make ((HFn)&RequestHandler::SequenceSpace_make_N0));
	table->storeValue(41, HHBHandler::make ((HHBFn)&RequestHandler::SequenceSpace_above_N2, cat_Sequence));
	table->storeValue(42, HHBHandler::make ((HHBFn)&RequestHandler::SequenceSpace_below_N2, cat_Sequence));
	table->storeValue(43, 
			HHHHandler::make ((HHHFn)&RequestHandler::SequenceSpace_interval_N2, cat_Sequence, cat_Sequence));
	table->storeValue(285, HHHandler::make ((HHFn)&RequestHandler::SequenceSpace_mapping_N1, cat_PrimIntValue));
	table->storeValue(286, 
			HHHHandler::make ((HHHFn)&RequestHandler::SequenceSpace_mapping_N2, cat_PrimIntValue, cat_Sequence));
	table->storeValue(44, HHHandler::make ((HHFn)&RequestHandler::SequenceSpace_position_N1, cat_PrimArray));
	table->storeValue(45, 
			HHHHandler::make ((HHHFn)&RequestHandler::SequenceSpace_position_N2, cat_PrimArray, cat_PrimIntValue));
	table->storeValue(287, 
			HHHHandler::make ((HHHFn)&RequestHandler::SequenceSpace_prefixedBy_N2, cat_Sequence, cat_PrimIntValue));
	/* Requests for class FillRangeDetector */
		/* Requests for class FillDetector */
		/* Requests for class KeyMaster */
	table->storeValue(288, HHHandler::make ((HHFn)&RequestHandler::KeyMaster_actualAuthority_N1, cat_FeKeyMaster));
	table->storeValue(289, HHHandler::make ((HHFn)&RequestHandler::KeyMaster_copy_N1, cat_FeKeyMaster));
	table->storeValue(290, 
			BHHHandler::make ((BHHFn)&RequestHandler::KeyMaster_hasAuthority_N2, cat_FeKeyMaster, cat_ID));
	table->storeValue(291, 
			VHHHandler::make ((VHHFn)&RequestHandler::KeyMaster_incorporate_N2, cat_FeKeyMaster, cat_FeKeyMaster));
	table->storeValue(292, HHHandler::make ((HHFn)&RequestHandler::KeyMaster_loginAuthority_N1, cat_FeKeyMaster));
	table->storeValue(293, 
			VHHHandler::make ((VHHFn)&RequestHandler::KeyMaster_removeLogins_N2, cat_FeKeyMaster, cat_IDRegion));
	/* Requests for class Lock */
		/* Requests for class BooLock */
	table->storeValue(431, HHHandler::make ((HHFn)&RequestHandler::BooLock_boo_N1, cat_BooLock));
	/* Requests for class ChallengeLock */
	table->storeValue(432, HHHandler::make ((HHFn)&RequestHandler::ChallengeLock_challenge_N1, cat_ChallengeLock));
	table->storeValue(433, 
			HHHHandler::make ((HHHFn)&RequestHandler::ChallengeLock_response_N2, cat_ChallengeLock, cat_PrimIntArray));
	/* Requests for class MatchLock */
	table->storeValue(434, 
			HHHHandler::make ((HHHFn)&RequestHandler::MatchLock_encryptedPassword_N2, cat_MatchLock, cat_PrimIntArray));
	/* Requests for class MultiLock */
	table->storeValue(435, 
			HHHHandler::make ((HHHFn)&RequestHandler::MultiLock_lock_N2, cat_MultiLock, cat_Sequence));
	table->storeValue(436, HHHandler::make ((HHFn)&RequestHandler::MultiLock_lockNames_N1, cat_MultiLock));
	/* Requests for class WallLock */
		/* Requests for class Mapping */
	table->storeValue(46, 
			HHHHandler::make ((HHHFn)&RequestHandler::Mapping_combine_N2, cat_Mapping, cat_Mapping));
	table->storeValue(47, HHHandler::make ((HHFn)&RequestHandler::Mapping_domain_N1, cat_Mapping));
	table->storeValue(294, HHHandler::make ((HHFn)&RequestHandler::Mapping_domainSpace_N1, cat_Mapping));
	table->storeValue(48, HHHandler::make ((HHFn)&RequestHandler::Mapping_inverse_N1, cat_Mapping));
	table->storeValue(49, BHHandler::make ((BHFn)&RequestHandler::Mapping_isComplete_N1, cat_Mapping));
	table->storeValue(50, BHHandler::make ((BHFn)&RequestHandler::Mapping_isIdentity_N1, cat_Mapping));
	table->storeValue(51, 
			HHHHandler::make ((HHHFn)&RequestHandler::Mapping_of_N2, cat_Mapping, cat_Position));
	table->storeValue(52, 
			HHHHandler::make ((HHHFn)&RequestHandler::Mapping_ofAll_N2, cat_Mapping, cat_XnRegion));
	table->storeValue(295, HHHandler::make ((HHFn)&RequestHandler::Mapping_range_N1, cat_Mapping));
	table->storeValue(296, HHHandler::make ((HHFn)&RequestHandler::Mapping_rangeSpace_N1, cat_Mapping));
	table->storeValue(53, 
			HHHHandler::make ((HHHFn)&RequestHandler::Mapping_restrict_N2, cat_Mapping, cat_XnRegion));
	table->storeValue(54, HHHandler::make ((HHFn)&RequestHandler::Mapping_simplerMappings_N1, cat_Mapping));
	table->storeValue(55, HHHandler::make ((HHFn)&RequestHandler::Mapping_unrestricted_N1, cat_Mapping));
	/* Requests for class CrossMapping */
	table->storeValue(297, 
			HHHHandler::make ((HHHFn)&RequestHandler::CrossMapping_subMapping_N2, cat_CrossMapping, cat_PrimIntValue));
	table->storeValue(298, HHHandler::make ((HHFn)&RequestHandler::CrossMapping_subMappings_N1, cat_CrossMapping));
	/* Requests for class IntegerMapping */
	table->storeValue(56, HHHandler::make ((HHFn)&RequestHandler::IntegerMapping_translation_N1, cat_IntegerMapping));
	/* Requests for class SequenceMapping */
	table->storeValue(57, HHHandler::make ((HHFn)&RequestHandler::SequenceMapping_shift_N1, cat_SequenceMapping));
	table->storeValue(58, HHHandler::make ((HHFn)&RequestHandler::SequenceMapping_translation_N1, cat_SequenceMapping));
	/* Requests for class OrderSpec */
	table->storeValue(299, HHHandler::make ((HHFn)&RequestHandler::OrderSpec_coordinateSpace_N1, cat_OrderSpec));
	table->storeValue(59, 
			BHHHHandler::make ((BHHHFn)&RequestHandler::OrderSpec_follows_N3, cat_OrderSpec, cat_Position, cat_Position));
	table->storeValue(300, HHHandler::make ((HHFn)&RequestHandler::OrderSpec_reversed_N1, cat_OrderSpec));
	/* Requests for class CrossOrderSpec */
	table->storeValue(301, HHHandler::make ((HHFn)&RequestHandler::CrossOrderSpec_lexOrder_N1, cat_CrossOrderSpec));
	table->storeValue(302, 
			HHHHandler::make ((HHHFn)&RequestHandler::CrossOrderSpec_subOrder_N2, cat_CrossOrderSpec, cat_PrimIntValue));
	table->storeValue(303, HHHandler::make ((HHFn)&RequestHandler::CrossOrderSpec_subOrders_N1, cat_CrossOrderSpec));
	/* Requests for class Position */
	table->storeValue(60, HHHandler::make ((HHFn)&RequestHandler::Position_asRegion_N1, cat_Position));
	table->storeValue(304, HHHandler::make ((HHFn)&RequestHandler::Position_coordinateSpace_N1, cat_Position));
	/* Requests for class FilterPosition */
	table->storeValue(437, HHHandler::make ((HHFn)&RequestHandler::FilterPosition_baseRegion_N1, cat_FilterPosition));
	/* Requests for class ID */
	table->storeValue(305, HHHandler::make ((HHFn)&RequestHandler::ID_import_N1, cat_PrimIntArray));
	table->storeValue(306, HHHandler::make ((HHFn)&RequestHandler::ID_export_N1, cat_ID));
	/* Requests for class Sequence */
	table->storeValue(61, HHHandler::make ((HHFn)&RequestHandler::Sequence_firstIndex_N1, cat_Sequence));
	table->storeValue(307, 
			HHHHandler::make ((HHHFn)&RequestHandler::Sequence_integerAt_N2, cat_Sequence, cat_PrimIntValue));
	table->storeValue(62, HHHandler::make ((HHFn)&RequestHandler::Sequence_integers_N1, cat_Sequence));
	table->storeValue(63, BHHandler::make ((BHFn)&RequestHandler::Sequence_isZero_N1, cat_Sequence));
	table->storeValue(308, HHHandler::make ((HHFn)&RequestHandler::Sequence_lastIndex_N1, cat_Sequence));
	table->storeValue(309, 
			HHHHHandler::make ((HHHHFn)&RequestHandler::Sequence_with_N3, cat_Sequence, cat_PrimIntValue, cat_PrimIntValue));
	/* Requests for class Tuple */
	table->storeValue(64, 
			HHHHandler::make ((HHHFn)&RequestHandler::Tuple_coordinate_N2, cat_Tuple, cat_PrimIntValue));
	table->storeValue(65, HHHandler::make ((HHFn)&RequestHandler::Tuple_coordinates_N1, cat_Tuple));
	/* Requests for class Integer */
	table->storeValue(66, HHHandler::make ((HHFn)&RequestHandler::Integer_value_N1, cat_IntegerPos));
	/* Requests for class Real */
	table->storeValue(67, HHHandler::make ((HHFn)&RequestHandler::Real_value_N1, cat_RealPos));
	/* Requests for class RangeElement */
	table->storeValue(68, HHandler::make ((HFn)&RequestHandler::RangeElement_placeHolder_N0));
	table->storeValue(310, HHHandler::make ((HHFn)&RequestHandler::RangeElement_again_N1, cat_FeRangeElement));
	table->storeValue(311, 
			BHHHandler::make ((BHHFn)&RequestHandler::RangeElement_canMakeIdentical_N2, cat_FeRangeElement, cat_FeRangeElement));
	table->storeValue(312, SpecialHandler::make ((VHFn)&PromiseManager::fillDetector));
	PromiseManager::fillRequestTable2(table);
}


void PromiseManager::fillRequestTable2 (APTR(PtrArray) table){
	table->storeValue(69, 
			BHHHandler::make ((BHHFn)&RequestHandler::RangeElement_isIdentical_N2, cat_FeRangeElement, cat_FeRangeElement));
	table->storeValue(70, HHHandler::make ((HHFn)&RequestHandler::RangeElement_label_N1, cat_FeRangeElement));
	table->storeValue(313, 
			VHHHandler::make ((VHHFn)&RequestHandler::RangeElement_makeIdentical_N2, cat_FeRangeElement, cat_FeRangeElement));
	table->storeValue(314, HHHandler::make ((HHFn)&RequestHandler::RangeElement_owner_N1, cat_FeRangeElement));
	table->storeValue(71, 
			HHHHandler::make ((HHHFn)&RequestHandler::RangeElement_relabelled_N2, cat_FeRangeElement, cat_FeLabel));
	table->storeValue(315, 
			VHHHandler::make ((VHHFn)&RequestHandler::RangeElement_setOwner_N2, cat_FeRangeElement, cat_ID));
	table->storeValue(72, HHHandler::make ((HHFn)&RequestHandler::RangeElement_transcluders_N1, cat_FeRangeElement));
	table->storeValue(73, 
			HHHHandler::make ((HHHFn)&RequestHandler::RangeElement_transcluders_N2, cat_FeRangeElement, cat_Filter));
	table->storeValue(74, 
			HHHHHandler::make ((HHHHFn)&RequestHandler::RangeElement_transcluders_N3, cat_FeRangeElement, cat_Filter, cat_Filter));
	table->storeValue(75, 
			HHHHHHandler::make ((HHHHHFn)&RequestHandler::RangeElement_transcluders_N4, cat_FeRangeElement, cat_Filter, cat_Filter, cat_PrimIntValue));
	table->storeValue(316, 
			HHHHHHHandler::make ((HHHHHHFn)&RequestHandler::RangeElement_transcluders_N5, cat_FeRangeElement, cat_Filter, cat_Filter, cat_PrimIntValue, cat_FeEdition));
	table->storeValue(76, HHHandler::make ((HHFn)&RequestHandler::RangeElement_works_N1, cat_FeRangeElement));
	table->storeValue(77, 
			HHHHandler::make ((HHHFn)&RequestHandler::RangeElement_works_N2, cat_FeRangeElement, cat_Filter));
	table->storeValue(78, 
			HHHHHandler::make ((HHHHFn)&RequestHandler::RangeElement_works_N3, cat_FeRangeElement, cat_Filter, cat_PrimIntValue));
	table->storeValue(317, 
			HHHHHHandler::make ((HHHHHFn)&RequestHandler::RangeElement_works_N4, cat_FeRangeElement, cat_Filter, cat_PrimIntValue, cat_FeEdition));
	/* Requests for class DataHolder */
	table->storeValue(79, HHHandler::make ((HHFn)&RequestHandler::DataHolder_make_N1, cat_PrimValue));
	table->storeValue(80, HHHandler::make ((HHFn)&RequestHandler::DataHolder_value_N1, cat_FeDataHolder));
	/* Requests for class Edition */
	table->storeValue(81, HHHandler::make ((HHFn)&RequestHandler::Edition_empty_N1, cat_CoordinateSpace));
	table->storeValue(82, 
			HHHHandler::make ((HHHFn)&RequestHandler::Edition_fromAll_N2, cat_XnRegion, cat_FeRangeElement));
	table->storeValue(83, HHHandler::make ((HHFn)&RequestHandler::Edition_fromArray_N1, cat_PrimArray));
	table->storeValue(84, 
			HHHHandler::make ((HHHFn)&RequestHandler::Edition_fromArray_N2, cat_PrimArray, cat_XnRegion));
	table->storeValue(318, 
			HHHHHandler::make ((HHHHFn)&RequestHandler::Edition_fromArray_N3, cat_PrimArray, cat_XnRegion, cat_OrderSpec));
	table->storeValue(85, 
			HHHHandler::make ((HHHFn)&RequestHandler::Edition_fromOne_N2, cat_Position, cat_FeRangeElement));
	table->storeValue(86, HHHandler::make ((HHFn)&RequestHandler::Edition_placeHolders_N1, cat_XnRegion));
	table->storeValue(319, 
			HHHHandler::make ((HHHFn)&RequestHandler::Edition_canMakeRangeIdentical_N2, cat_FeEdition, cat_FeEdition));
	table->storeValue(320, 
			HHHHHandler::make ((HHHHFn)&RequestHandler::Edition_canMakeRangeIdentical_N3, cat_FeEdition, cat_FeEdition, cat_XnRegion));
	table->storeValue(87, 
			HHHHandler::make ((HHHFn)&RequestHandler::Edition_combine_N2, cat_FeEdition, cat_FeEdition));
	table->storeValue(88, HHHandler::make ((HHFn)&RequestHandler::Edition_coordinateSpace_N1, cat_FeEdition));
	table->storeValue(89, 
			HHHHandler::make ((HHHFn)&RequestHandler::Edition_copy_N2, cat_FeEdition, cat_XnRegion));
	table->storeValue(321, 
			HHHHandler::make ((HHHFn)&RequestHandler::Edition_cost_N2, cat_FeEdition, cat_PrimIntValue));
	table->storeValue(90, HHHandler::make ((HHFn)&RequestHandler::Edition_count_N1, cat_FeEdition));
	table->storeValue(91, HHHandler::make ((HHFn)&RequestHandler::Edition_domain_N1, cat_FeEdition));
	table->storeValue(92, 
			VHHHandler::make ((VHHFn)&RequestHandler::Edition_endorse_N2, cat_FeEdition, cat_CrossRegion));
	table->storeValue(93, HHHandler::make ((HHFn)&RequestHandler::Edition_endorsements_N1, cat_FeEdition));
	table->storeValue(322, SpecialHandler::make ((VHFn)&PromiseManager::fillRangeDetector));
	table->storeValue(94, 
			HHHHandler::make ((HHHFn)&RequestHandler::Edition_get_N2, cat_FeEdition, cat_Position));
	table->storeValue(95, 
			BHHHandler::make ((BHHFn)&RequestHandler::Edition_hasPosition_N2, cat_FeEdition, cat_Position));
	table->storeValue(96, BHHandler::make ((BHFn)&RequestHandler::Edition_isEmpty_N1, cat_FeEdition));
	table->storeValue(97, BHHandler::make ((BHFn)&RequestHandler::Edition_isFinite_N1, cat_FeEdition));
	table->storeValue(323, 
			BHHHandler::make ((BHHFn)&RequestHandler::Edition_isRangeIdentical_N2, cat_FeEdition, cat_FeEdition));
	table->storeValue(324, 
			HHHHandler::make ((HHHFn)&RequestHandler::Edition_makeRangeIdentical_N2, cat_FeEdition, cat_FeEdition));
	table->storeValue(325, 
			HHHHHandler::make ((HHHHFn)&RequestHandler::Edition_makeRangeIdentical_N3, cat_FeEdition, cat_FeEdition, cat_XnRegion));
	table->storeValue(98, 
			HHHHandler::make ((HHHFn)&RequestHandler::Edition_mapSharedOnto_N2, cat_FeEdition, cat_FeEdition));
	table->storeValue(326, 
			HHHHandler::make ((HHHFn)&RequestHandler::Edition_mapSharedTo_N2, cat_FeEdition, cat_FeEdition));
	table->storeValue(99, 
			HHHHandler::make ((HHHFn)&RequestHandler::Edition_notSharedWith_N2, cat_FeEdition, cat_FeEdition));
	table->storeValue(100, 
			HHHHHandler::make ((HHHHFn)&RequestHandler::Edition_notSharedWith_N3, cat_FeEdition, cat_FeEdition, cat_PrimIntValue));
	table->storeValue(101, 
			HHHHandler::make ((HHHFn)&RequestHandler::Edition_positionsLabelled_N2, cat_FeEdition, cat_FeLabel));
	table->storeValue(102, 
			HHHHandler::make ((HHHFn)&RequestHandler::Edition_positionsOf_N2, cat_FeEdition, cat_FeRangeElement));
	table->storeValue(327, 
			HHHHandler::make ((HHHFn)&RequestHandler::Edition_rangeOwners_N2, cat_FeEdition, cat_XnRegion));
	table->storeValue(103, HHHandler::make ((HHFn)&RequestHandler::Edition_rangeTranscluders_N1, cat_FeEdition));
	table->storeValue(104, 
			HHHHandler::make ((HHHFn)&RequestHandler::Edition_rangeTranscluders_N2, cat_FeEdition, cat_XnRegion));
	table->storeValue(105, 
			HHHHHandler::make ((HHHHFn)&RequestHandler::Edition_rangeTranscluders_N3, cat_FeEdition, cat_XnRegion, cat_Filter));
	table->storeValue(106, 
			HHHHHHandler::make ((HHHHHFn)&RequestHandler::Edition_rangeTranscluders_N4, cat_FeEdition, cat_XnRegion, cat_Filter, cat_Filter));
	table->storeValue(107, 
			HHHHHHHandler::make ((HHHHHHFn)&RequestHandler::Edition_rangeTranscluders_N5, cat_FeEdition, cat_XnRegion, cat_Filter, cat_Filter, cat_PrimIntValue));
	table->storeValue(328, 
			HHHHHHHHandler::make ((HHHHHHHFn)&RequestHandler::Edition_rangeTranscluders_N6, cat_FeEdition, cat_XnRegion, cat_Filter, cat_Filter, cat_PrimIntValue, cat_FeEdition));
	table->storeValue(329, HHHandler::make ((HHFn)&RequestHandler::Edition_rangeWorks_N1, cat_FeEdition));
	table->storeValue(330, 
			HHHHandler::make ((HHHFn)&RequestHandler::Edition_rangeWorks_N2, cat_FeEdition, cat_XnRegion));
	table->storeValue(331, 
			HHHHHandler::make ((HHHHFn)&RequestHandler::Edition_rangeWorks_N3, cat_FeEdition, cat_XnRegion, cat_Filter));
	table->storeValue(332, 
			HHHHHHandler::make ((HHHHHFn)&RequestHandler::Edition_rangeWorks_N4, cat_FeEdition, cat_XnRegion, cat_Filter, cat_PrimIntValue));
	table->storeValue(333, 
			HHHHHHHandler::make ((HHHHHHFn)&RequestHandler::Edition_rangeWorks_N5, cat_FeEdition, cat_XnRegion, cat_Filter, cat_PrimIntValue, cat_FeEdition));
	table->storeValue(108, 
			HHHHHandler::make ((HHHHFn)&RequestHandler::Edition_rebind_N3, cat_FeEdition, cat_Position, cat_FeEdition));
	table->storeValue(109, 
			HHHHandler::make ((HHHFn)&RequestHandler::Edition_replace_N2, cat_FeEdition, cat_FeEdition));
	table->storeValue(334, 
			VHHHandler::make ((VHHFn)&RequestHandler::Edition_retract_N2, cat_FeEdition, cat_CrossRegion));
	table->storeValue(110, HHHandler::make ((HHFn)&RequestHandler::Edition_retrieve_N1, cat_FeEdition));
	table->storeValue(111, 
			HHHHandler::make ((HHHFn)&RequestHandler::Edition_retrieve_N2, cat_FeEdition, cat_XnRegion));
	table->storeValue(112, 
			HHHHHandler::make ((HHHHFn)&RequestHandler::Edition_retrieve_N3, cat_FeEdition, cat_XnRegion, cat_OrderSpec));
	table->storeValue(113, 
			HHHHHHandler::make ((HHHHHFn)&RequestHandler::Edition_retrieve_N4, cat_FeEdition, cat_XnRegion, cat_OrderSpec, cat_PrimIntValue));
	table->storeValue(335, 
			HHHHandler::make ((HHHFn)&RequestHandler::Edition_setRangeOwners_N2, cat_FeEdition, cat_ID));
	table->storeValue(336, 
			HHHHHandler::make ((HHHHFn)&RequestHandler::Edition_setRangeOwners_N3, cat_FeEdition, cat_ID, cat_XnRegion));
	table->storeValue(114, 
			HHHHandler::make ((HHHFn)&RequestHandler::Edition_sharedRegion_N2, cat_FeEdition, cat_FeEdition));
	table->storeValue(115, 
			HHHHHandler::make ((HHHHFn)&RequestHandler::Edition_sharedRegion_N3, cat_FeEdition, cat_FeEdition, cat_PrimIntValue));
	table->storeValue(116, 
			HHHHandler::make ((HHHFn)&RequestHandler::Edition_sharedWith_N2, cat_FeEdition, cat_FeEdition));
	table->storeValue(117, 
			HHHHHandler::make ((HHHHFn)&RequestHandler::Edition_sharedWith_N3, cat_FeEdition, cat_FeEdition, cat_PrimIntValue));
	table->storeValue(118, HHHandler::make ((HHFn)&RequestHandler::Edition_stepper_N1, cat_FeEdition));
	table->storeValue(119, 
			HHHHandler::make ((HHHFn)&RequestHandler::Edition_stepper_N2, cat_FeEdition, cat_XnRegion));
	table->storeValue(337, 
			HHHHHandler::make ((HHHHFn)&RequestHandler::Edition_stepper_N3, cat_FeEdition, cat_XnRegion, cat_OrderSpec));
	table->storeValue(120, HHHandler::make ((HHFn)&RequestHandler::Edition_theOne_N1, cat_FeEdition));
	table->storeValue(121, 
			HHHHandler::make ((HHHFn)&RequestHandler::Edition_transformedBy_N2, cat_FeEdition, cat_Mapping));
	table->storeValue(122, HHHandler::make ((HHFn)&RequestHandler::Edition_visibleEndorsements_N1, cat_FeEdition));
	table->storeValue(123, 
			HHHHHandler::make ((HHHHFn)&RequestHandler::Edition_with_N3, cat_FeEdition, cat_Position, cat_FeRangeElement));
	PromiseManager::fillRequestTable3(table);
}


void PromiseManager::fillRequestTable3 (APTR(PtrArray) table){
	table->storeValue(124, 
			HHHHHandler::make ((HHHHFn)&RequestHandler::Edition_withAll_N3, cat_FeEdition, cat_XnRegion, cat_FeRangeElement));
	table->storeValue(125, 
			HHHHandler::make ((HHHFn)&RequestHandler::Edition_without_N2, cat_FeEdition, cat_Position));
	table->storeValue(126, 
			HHHHandler::make ((HHHFn)&RequestHandler::Edition_withoutAll_N2, cat_FeEdition, cat_XnRegion));
	/* Requests for class IDHolder */
	table->storeValue(338, HHHandler::make ((HHFn)&RequestHandler::IDHolder_make_N1, cat_ID));
	table->storeValue(339, HHHandler::make ((HHFn)&RequestHandler::IDHolder_iD_N1, cat_FeIDHolder));
	/* Requests for class Label */
	table->storeValue(340, HHandler::make ((HFn)&RequestHandler::Label_make_N0));
	/* Requests for class Work */
	table->storeValue(127, HHHandler::make ((HHFn)&RequestHandler::Work_make_N1, cat_FeEdition));
	table->storeValue(128, BHHandler::make ((BHFn)&RequestHandler::Work_canRead_N1, cat_FeWork));
	table->storeValue(129, BHHandler::make ((BHFn)&RequestHandler::Work_canRevise_N1, cat_FeWork));
	table->storeValue(130, HHHandler::make ((HHFn)&RequestHandler::Work_editClub_N1, cat_FeWork));
	table->storeValue(131, HHHandler::make ((HHFn)&RequestHandler::Work_edition_N1, cat_FeWork));
	table->storeValue(341, 
			VHHHandler::make ((VHHFn)&RequestHandler::Work_endorse_N2, cat_FeWork, cat_CrossRegion));
	table->storeValue(132, HHHandler::make ((HHFn)&RequestHandler::Work_endorsements_N1, cat_FeWork));
	table->storeValue(133, VHHandler::make ((VHFn)&RequestHandler::Work_grab_N1, cat_FeWork));
	table->storeValue(342, HHHandler::make ((HHFn)&RequestHandler::Work_grabber_N1, cat_FeWork));
	table->storeValue(343, HHHandler::make ((HHFn)&RequestHandler::Work_historyClub_N1, cat_FeWork));
	table->storeValue(134, HHHandler::make ((HHFn)&RequestHandler::Work_lastRevisionAuthor_N1, cat_FeWork));
	table->storeValue(344, HHHandler::make ((HHFn)&RequestHandler::Work_lastRevisionNumber_N1, cat_FeWork));
	table->storeValue(135, HHHandler::make ((HHFn)&RequestHandler::Work_lastRevisionTime_N1, cat_FeWork));
	table->storeValue(136, HHHandler::make ((HHFn)&RequestHandler::Work_readClub_N1, cat_FeWork));
	table->storeValue(137, VHHandler::make ((VHFn)&RequestHandler::Work_release_N1, cat_FeWork));
	table->storeValue(345, VHHandler::make ((VHFn)&RequestHandler::Work_removeEditClub_N1, cat_FeWork));
	table->storeValue(346, VHHandler::make ((VHFn)&RequestHandler::Work_removeReadClub_N1, cat_FeWork));
	table->storeValue(138, VHHandler::make ((VHFn)&RequestHandler::Work_requestGrab_N1, cat_FeWork));
	table->storeValue(347, 
			VHHHandler::make ((VHHFn)&RequestHandler::Work_retract_N2, cat_FeWork, cat_CrossRegion));
	table->storeValue(139, 
			VHHHandler::make ((VHHFn)&RequestHandler::Work_revise_N2, cat_FeWork, cat_FeEdition));
	table->storeValue(348, SpecialHandler::make ((VHFn)&PromiseManager::revisionDetector));
	table->storeValue(349, HHHandler::make ((HHFn)&RequestHandler::Work_revisions_N1, cat_FeWork));
	table->storeValue(350, 
			VHHHandler::make ((VHHFn)&RequestHandler::Work_setEditClub_N2, cat_FeWork, cat_ID));
	table->storeValue(351, 
			VHHHandler::make ((VHHFn)&RequestHandler::Work_setHistoryClub_N2, cat_FeWork, cat_ID));
	table->storeValue(352, 
			VHHHandler::make ((VHHFn)&RequestHandler::Work_setReadClub_N2, cat_FeWork, cat_ID));
	table->storeValue(353, 
			VHHHandler::make ((VHHFn)&RequestHandler::Work_sponsor_N2, cat_FeWork, cat_IDRegion));
	table->storeValue(354, HHHandler::make ((HHFn)&RequestHandler::Work_sponsors_N1, cat_FeWork));
	table->storeValue(355, SpecialHandler::make ((VHFn)&PromiseManager::statusDetector));
	table->storeValue(356, 
			VHHHandler::make ((VHHFn)&RequestHandler::Work_unsponsor_N2, cat_FeWork, cat_IDRegion));
	/* Requests for class Club */
	table->storeValue(357, HHHandler::make ((HHFn)&RequestHandler::Club_make_N1, cat_FeEdition));
	table->storeValue(358, VHHandler::make ((VHFn)&RequestHandler::Club_removeSignatureClub_N1, cat_FeClub));
	table->storeValue(359, 
			VHHHandler::make ((VHHFn)&RequestHandler::Club_setSignatureClub_N2, cat_FeClub, cat_ID));
	table->storeValue(360, HHHandler::make ((HHFn)&RequestHandler::Club_signatureClub_N1, cat_FeClub));
	table->storeValue(361, HHHandler::make ((HHFn)&RequestHandler::Club_sponsoredWorks_N1, cat_FeClub));
	table->storeValue(362, 
			HHHHandler::make ((HHHFn)&RequestHandler::Club_sponsoredWorks_N2, cat_FeClub, cat_Filter));
	/* Requests for class RevisionDetector */
		/* Requests for class Server */
	table->storeValue(438, HHandler::make ((HFn)&RequestHandler::Server_accessClubID_N0));
	table->storeValue(439, HHandler::make ((HFn)&RequestHandler::Server_adminClubID_N0));
	table->storeValue(440, HHandler::make ((HFn)&RequestHandler::Server_archiveClubID_N0));
	table->storeValue(363, HHHandler::make ((HHFn)&RequestHandler::Server_assignID_N1, cat_FeRangeElement));
	table->storeValue(364, 
			HHHHandler::make ((HHHFn)&RequestHandler::Server_assignID_N2, cat_FeRangeElement, cat_ID));
	table->storeValue(441, HHandler::make ((HFn)&RequestHandler::Server_clubDirectoryID_N0));
	table->storeValue(365, HHandler::make ((HFn)&RequestHandler::Server_currentTime_N0));
	table->storeValue(442, HHandler::make ((HFn)&RequestHandler::Server_encrypterName_N0));
	table->storeValue(140, SpecialHandler::make ((VHFn)&PromiseManager::forceIt));
	table->storeValue(141, HHHandler::make ((HHFn)&RequestHandler::Server_get_N1, cat_ID));
	table->storeValue(443, HHandler::make ((HFn)&RequestHandler::Server_identifier_N0));
	table->storeValue(142, HHHandler::make ((HHFn)&RequestHandler::Server_iDOf_N1, cat_FeRangeElement));
	table->storeValue(143, HHHandler::make ((HHFn)&RequestHandler::Server_iDsOf_N1, cat_FeRangeElement));
	table->storeValue(144, HHHandler::make ((HHFn)&RequestHandler::Server_iDsOfRange_N1, cat_FeEdition));
	table->storeValue(444, HHHandler::make ((HHFn)&RequestHandler::Server_login_N1, cat_ID));
	table->storeValue(445, HHHandler::make ((HHFn)&RequestHandler::Server_loginByName_N1, cat_Sequence));
	table->storeValue(446, HHandler::make ((HFn)&RequestHandler::Server_emptyClubID_N0));
	table->storeValue(447, HHandler::make ((HFn)&RequestHandler::Server_publicClubID_N0));
	table->storeValue(448, HHandler::make ((HFn)&RequestHandler::Server_publicKey_N0));
	table->storeValue(145, SpecialHandler::make ((VHFn)&PromiseManager::setCurrentAuthor));
	table->storeValue(146, SpecialHandler::make ((VHFn)&PromiseManager::setCurrentKeyMaster));
	table->storeValue(147, SpecialHandler::make ((VHFn)&PromiseManager::setInitialEditClub));
	table->storeValue(148, SpecialHandler::make ((VHFn)&PromiseManager::setInitialOwner));
	table->storeValue(149, SpecialHandler::make ((VHFn)&PromiseManager::setInitialReadClub));
	table->storeValue(150, SpecialHandler::make ((VHFn)&PromiseManager::setInitialSponsor));
	table->storeValue(366, SpecialHandler::make ((VHFn)&PromiseManager::waitForConsequences));
	table->storeValue(367, SpecialHandler::make ((VHFn)&PromiseManager::waitForWrite));
	/* Requests for class Session */
	table->storeValue(449, HHandler::make ((HFn)&RequestHandler::Session_current_N0));
	table->storeValue(450, HHHandler::make ((HHFn)&RequestHandler::Session_connectTime_N1, cat_FeSession));
	table->storeValue(451, VHHandler::make ((VHFn)&RequestHandler::Session_endSession_N1, cat_FeSession));
	table->storeValue(452, VHBHandler::make ((VHBFn)&RequestHandler::Session_endSession_N2, cat_FeSession));
	table->storeValue(453, HHHandler::make ((HHFn)&RequestHandler::Session_initialLogin_N1, cat_FeSession));
	table->storeValue(454, HHHandler::make ((HHFn)&RequestHandler::Session_port_N1, cat_FeSession));
	table->storeValue(470, BHHandler::make ((BHFn)&RequestHandler::Session_isConnected_N1, cat_FeSession));
	/* Requests for class StatusDetector */
		/* Requests for class Stepper */
	table->storeValue(151, BHHandler::make ((BHFn)&RequestHandler::Stepper_atEnd_N1, cat_Stepper));
	table->storeValue(254, HHHandler::make ((HHFn)&RequestHandler::Stepper_copy_N1, cat_Stepper));
	table->storeValue(152, HHHandler::make ((HHFn)&RequestHandler::Stepper_get_N1, cat_Stepper));
	table->storeValue(153, VHHandler::make ((VHFn)&RequestHandler::Stepper_step_N1, cat_Stepper));
	table->storeValue(154, HHHandler::make ((HHFn)&RequestHandler::Stepper_stepMany_N1, cat_Stepper));
	PromiseManager::fillRequestTable4(table);
}


void PromiseManager::fillRequestTable4 (APTR(PtrArray) table){
	table->storeValue(155, 
			HHHHandler::make ((HHHFn)&RequestHandler::Stepper_stepMany_N2, cat_Stepper, cat_PrimIntValue));
	table->storeValue(156, HHHandler::make ((HHFn)&RequestHandler::Stepper_theOne_N1, cat_Stepper));
	/* Requests for class TableStepper */
	table->storeValue(157, HHHandler::make ((HHFn)&RequestHandler::TableStepper_position_N1, cat_TableStepper));
	table->storeValue(158, HHHandler::make ((HHFn)&RequestHandler::TableStepper_stepManyPairs_N1, cat_TableStepper));
	table->storeValue(159, 
			HHHHandler::make ((HHHFn)&RequestHandler::TableStepper_stepManyPairs_N2, cat_TableStepper, cat_PrimIntValue));
	/* Requests for class Void */
		/* Requests for class WaitDetector */
		/* Requests for class Wrapper */
	table->storeValue(160, HHHandler::make ((HHFn)&RequestHandler::Wrapper_edition_N1, cat_FeWrapper));
	table->storeValue(368, HHHandler::make ((HHFn)&RequestHandler::Wrapper_inner_N1, cat_FeWrapper));
	/* Requests for class ClubDescription */
	table->storeValue(369, 
			HHHHandler::make ((HHHFn)&RequestHandler::ClubDescription_make_N2, cat_FeSet, cat_FeLockSmith));
	table->storeValue(370, HHHandler::make ((HHFn)&RequestHandler::ClubDescription_lockSmith_N1, cat_FeClubDescription));
	table->storeValue(371, HHHandler::make ((HHFn)&RequestHandler::ClubDescription_membership_N1, cat_FeClubDescription));
	table->storeValue(372, 
			HHHHandler::make ((HHHFn)&RequestHandler::ClubDescription_withLockSmith_N2, cat_FeClubDescription, cat_FeLockSmith));
	table->storeValue(373, 
			HHHHandler::make ((HHHFn)&RequestHandler::ClubDescription_withMembership_N2, cat_FeClubDescription, cat_FeSet));
	/* Requests for class HyperLink */
	table->storeValue(161, 
			HHHHHandler::make ((HHHHFn)&RequestHandler::HyperLink_make_N3, cat_FeSet, cat_FeHyperRef, cat_FeHyperRef));
	table->storeValue(162, 
			HHHHandler::make ((HHHFn)&RequestHandler::HyperLink_endAt_N2, cat_FeHyperLink, cat_Sequence));
	table->storeValue(163, HHHandler::make ((HHFn)&RequestHandler::HyperLink_endNames_N1, cat_FeHyperLink));
	table->storeValue(164, HHHandler::make ((HHFn)&RequestHandler::HyperLink_linkTypes_N1, cat_FeHyperLink));
	table->storeValue(165, 
			HHHHHandler::make ((HHHHFn)&RequestHandler::HyperLink_withEnd_N3, cat_FeHyperLink, cat_Sequence, cat_FeHyperRef));
	table->storeValue(374, 
			HHHHandler::make ((HHHFn)&RequestHandler::HyperLink_withLinkTypes_N2, cat_FeHyperLink, cat_FeSet));
	table->storeValue(375, 
			HHHHandler::make ((HHHFn)&RequestHandler::HyperLink_withoutEnd_N2, cat_FeHyperLink, cat_Sequence));
	/* Requests for class HyperRef */
	table->storeValue(166, HHHandler::make ((HHFn)&RequestHandler::HyperRef_originalContext_N1, cat_FeHyperRef));
	table->storeValue(167, HHHandler::make ((HHFn)&RequestHandler::HyperRef_pathContext_N1, cat_FeHyperRef));
	table->storeValue(376, 
			HHHHandler::make ((HHHFn)&RequestHandler::HyperRef_withOriginalContext_N2, cat_FeHyperRef, cat_FeWork));
	table->storeValue(377, 
			HHHHandler::make ((HHHFn)&RequestHandler::HyperRef_withPathContext_N2, cat_FeHyperRef, cat_FePath));
	table->storeValue(378, 
			HHHHandler::make ((HHHFn)&RequestHandler::HyperRef_withWorkContext_N2, cat_FeHyperRef, cat_FeWork));
	table->storeValue(168, HHHandler::make ((HHFn)&RequestHandler::HyperRef_workContext_N1, cat_FeHyperRef));
	/* Requests for class MultiRef */
	table->storeValue(169, HHHandler::make ((HHFn)&RequestHandler::MultiRef_make_N1, cat_PtrArray));
	table->storeValue(170, 
			HHHHandler::make ((HHHFn)&RequestHandler::MultiRef_make_N2, cat_PtrArray, cat_FeWork));
	table->storeValue(171, 
			HHHHHandler::make ((HHHHFn)&RequestHandler::MultiRef_make_N3, cat_PtrArray, cat_FeWork, cat_FeWork));
	table->storeValue(172, 
			HHHHHHandler::make ((HHHHHFn)&RequestHandler::MultiRef_make_N4, cat_PtrArray, cat_FeWork, cat_FeWork, cat_FePath));
	table->storeValue(379, 
			HHHHandler::make ((HHHFn)&RequestHandler::MultiRef_intersect_N2, cat_FeMultiRef, cat_FeMultiRef));
	table->storeValue(380, 
			HHHHandler::make ((HHHFn)&RequestHandler::MultiRef_minus_N2, cat_FeMultiRef, cat_FeMultiRef));
	table->storeValue(173, HHHandler::make ((HHFn)&RequestHandler::MultiRef_refs_N1, cat_FeMultiRef));
	table->storeValue(381, 
			HHHHandler::make ((HHHFn)&RequestHandler::MultiRef_unionWith_N2, cat_FeMultiRef, cat_FeMultiRef));
	table->storeValue(382, 
			HHHHandler::make ((HHHFn)&RequestHandler::MultiRef_with_N2, cat_FeMultiRef, cat_FeHyperRef));
	table->storeValue(383, 
			HHHHandler::make ((HHHFn)&RequestHandler::MultiRef_without_N2, cat_FeMultiRef, cat_FeHyperRef));
	/* Requests for class SingleRef */
	table->storeValue(174, HHHandler::make ((HHFn)&RequestHandler::SingleRef_make_N1, cat_FeEdition));
	table->storeValue(175, 
			HHHHandler::make ((HHHFn)&RequestHandler::SingleRef_make_N2, cat_FeEdition, cat_FeWork));
	table->storeValue(176, 
			HHHHHandler::make ((HHHHFn)&RequestHandler::SingleRef_make_N3, cat_FeEdition, cat_FeWork, cat_FeWork));
	table->storeValue(177, 
			HHHHHHandler::make ((HHHHHFn)&RequestHandler::SingleRef_make_N4, cat_FeEdition, cat_FeWork, cat_FeWork, cat_FePath));
	table->storeValue(178, HHHandler::make ((HHFn)&RequestHandler::SingleRef_excerpt_N1, cat_FeSingleRef));
	table->storeValue(384, 
			HHHHandler::make ((HHHFn)&RequestHandler::SingleRef_withExcerpt_N2, cat_FeSingleRef, cat_FeEdition));
	/* Requests for class LockSmith */
		/* Requests for class BooLockSmith */
	table->storeValue(455, HHandler::make ((HFn)&RequestHandler::BooLockSmith_make_N0));
	/* Requests for class ChallengeLockSmith */
	table->storeValue(456, 
			HHHHandler::make ((HHHFn)&RequestHandler::ChallengeLockSmith_make_N2, cat_PrimIntArray, cat_Sequence));
	table->storeValue(457, HHHandler::make ((HHFn)&RequestHandler::ChallengeLockSmith_encrypterName_N1, cat_FeChallengeLockSmith));
	table->storeValue(458, HHHandler::make ((HHFn)&RequestHandler::ChallengeLockSmith_publicKey_N1, cat_FeChallengeLockSmith));
	/* Requests for class MatchLockSmith */
	table->storeValue(459, 
			HHHHandler::make ((HHHFn)&RequestHandler::MatchLockSmith_make_N2, cat_PrimIntArray, cat_Sequence));
	table->storeValue(460, HHHandler::make ((HHFn)&RequestHandler::MatchLockSmith_scrambledPassword_N1, cat_FeMatchLockSmith));
	table->storeValue(461, HHHandler::make ((HHFn)&RequestHandler::MatchLockSmith_scramblerName_N1, cat_FeMatchLockSmith));
	/* Requests for class MultiLockSmith */
	table->storeValue(462, HHandler::make ((HFn)&RequestHandler::MultiLockSmith_make_N0));
	table->storeValue(463, 
			HHHHandler::make ((HHHFn)&RequestHandler::MultiLockSmith_lockSmith_N2, cat_FeMultiLockSmith, cat_Sequence));
	table->storeValue(464, HHHandler::make ((HHFn)&RequestHandler::MultiLockSmith_lockSmithNames_N1, cat_FeMultiLockSmith));
	table->storeValue(465, 
			HHHHHandler::make ((HHHHFn)&RequestHandler::MultiLockSmith_with_N3, cat_FeMultiLockSmith, cat_Sequence, cat_FeLockSmith));
	table->storeValue(466, 
			HHHHandler::make ((HHHFn)&RequestHandler::MultiLockSmith_without_N2, cat_FeMultiLockSmith, cat_Sequence));
	/* Requests for class WallLockSmith */
	table->storeValue(467, HHandler::make ((HFn)&RequestHandler::WallLockSmith_make_N0));
	/* Requests for class Path */
	table->storeValue(179, HHHandler::make ((HHFn)&RequestHandler::Path_make_N1, cat_PtrArray));
	table->storeValue(180, 
			HHHHandler::make ((HHHFn)&RequestHandler::Path_follow_N2, cat_FePath, cat_FeEdition));
	/* Requests for class Set */
	table->storeValue(181, HHandler::make ((HFn)&RequestHandler::Set_make_N0));
	table->storeValue(182, HHHandler::make ((HHFn)&RequestHandler::Set_make_N1, cat_PtrArray));
	table->storeValue(183, HHHandler::make ((HHFn)&RequestHandler::Set_count_N1, cat_FeSet));
	table->storeValue(184, 
			BHHHandler::make ((BHHFn)&RequestHandler::Set_includes_N2, cat_FeSet, cat_FeRangeElement));
	table->storeValue(385, 
			HHHHandler::make ((HHHFn)&RequestHandler::Set_intersect_N2, cat_FeSet, cat_FeSet));
	table->storeValue(386, 
			HHHHandler::make ((HHHFn)&RequestHandler::Set_minus_N2, cat_FeSet, cat_FeSet));
	table->storeValue(185, HHHandler::make ((HHFn)&RequestHandler::Set_theOne_N1, cat_FeSet));
	table->storeValue(387, 
			HHHHandler::make ((HHHFn)&RequestHandler::Set_unionWith_N2, cat_FeSet, cat_FeSet));
	table->storeValue(388, 
			HHHHandler::make ((HHHFn)&RequestHandler::Set_with_N2, cat_FeSet, cat_FeRangeElement));
	table->storeValue(389, 
			HHHHandler::make ((HHHFn)&RequestHandler::Set_without_N2, cat_FeSet, cat_FeRangeElement));
	/* Requests for class Text */
	table->storeValue(186, HHHandler::make ((HHFn)&RequestHandler::Text_make_N1, cat_PrimArray));
	table->storeValue(187, HHHandler::make ((HHFn)&RequestHandler::Text_contents_N1, cat_FeText));
	table->storeValue(188, HHHandler::make ((HHFn)&RequestHandler::Text_count_N1, cat_FeText));
	table->storeValue(189, 
			HHHHandler::make ((HHHFn)&RequestHandler::Text_extract_N2, cat_FeText, cat_IntegerRegion));
	table->storeValue(190, 
			HHHHHandler::make ((HHHHFn)&RequestHandler::Text_insert_N3, cat_FeText, cat_PrimIntValue, cat_FeText));
	table->storeValue(191, 
			HHHHHandler::make ((HHHHFn)&RequestHandler::Text_move_N3, cat_FeText, cat_PrimIntValue, cat_IntegerRegion));
	table->storeValue(192, 
			HHHHHandler::make ((HHHHFn)&RequestHandler::Text_replace_N3, cat_FeText, cat_IntegerRegion, cat_FeText));
	/* Requests for class WrapperSpec */
	table->storeValue(193, HHHandler::make ((HHFn)&RequestHandler::WrapperSpec_get_N1, cat_Sequence));
	table->storeValue(194, HHHandler::make ((HHFn)&RequestHandler::WrapperSpec_filter_N1, cat_FeWrapperSpec));
	table->storeValue(390, HHHandler::make ((HHFn)&RequestHandler::WrapperSpec_name_N1, cat_FeWrapperSpec));
	table->storeValue(195, 
			HHHHandler::make ((HHHFn)&RequestHandler::WrapperSpec_wrap_N2, cat_FeWrapperSpec, cat_FeEdition));
	/* Requests for class Region */
	table->storeValue(196, 
			HHHHandler::make ((HHHFn)&RequestHandler::Region_chooseMany_N2, cat_XnRegion, cat_PrimIntValue));
	table->storeValue(197, 
			HHHHHandler::make ((HHHHFn)&RequestHandler::Region_chooseMany_N3, cat_XnRegion, cat_PrimIntValue, cat_OrderSpec));
	table->storeValue(198, HHHandler::make ((HHFn)&RequestHandler::Region_chooseOne_N1, cat_XnRegion));
	PromiseManager::fillRequestTable5(table);
}


void PromiseManager::fillRequestTable5 (APTR(PtrArray) table){
	table->storeValue(199, 
			HHHHandler::make ((HHHFn)&RequestHandler::Region_chooseOne_N2, cat_XnRegion, cat_OrderSpec));
	table->storeValue(200, HHHandler::make ((HHFn)&RequestHandler::Region_complement_N1, cat_XnRegion));
	table->storeValue(201, HHHandler::make ((HHFn)&RequestHandler::Region_coordinateSpace_N1, cat_XnRegion));
	table->storeValue(202, HHHandler::make ((HHFn)&RequestHandler::Region_count_N1, cat_XnRegion));
	table->storeValue(203, 
			BHHHandler::make ((BHHFn)&RequestHandler::Region_hasMember_N2, cat_XnRegion, cat_Position));
	table->storeValue(204, 
			HHHHandler::make ((HHHFn)&RequestHandler::Region_intersect_N2, cat_XnRegion, cat_XnRegion));
	table->storeValue(205, 
			BHHHandler::make ((BHHFn)&RequestHandler::Region_intersects_N2, cat_XnRegion, cat_XnRegion));
	table->storeValue(206, BHHandler::make ((BHFn)&RequestHandler::Region_isEmpty_N1, cat_XnRegion));
	table->storeValue(207, BHHandler::make ((BHFn)&RequestHandler::Region_isFinite_N1, cat_XnRegion));
	table->storeValue(208, BHHandler::make ((BHFn)&RequestHandler::Region_isFull_N1, cat_XnRegion));
	table->storeValue(209, 
			BHHHandler::make ((BHHFn)&RequestHandler::Region_isSubsetOf_N2, cat_XnRegion, cat_XnRegion));
	table->storeValue(210, 
			HHHHandler::make ((HHHFn)&RequestHandler::Region_minus_N2, cat_XnRegion, cat_XnRegion));
	table->storeValue(211, HHHandler::make ((HHFn)&RequestHandler::Region_stepper_N1, cat_XnRegion));
	table->storeValue(212, 
			HHHHandler::make ((HHHFn)&RequestHandler::Region_stepper_N2, cat_XnRegion, cat_OrderSpec));
	table->storeValue(213, HHHandler::make ((HHFn)&RequestHandler::Region_theOne_N1, cat_XnRegion));
	table->storeValue(214, 
			HHHHandler::make ((HHHFn)&RequestHandler::Region_unionWith_N2, cat_XnRegion, cat_XnRegion));
	table->storeValue(215, 
			HHHHandler::make ((HHHFn)&RequestHandler::Region_with_N2, cat_XnRegion, cat_Position));
	table->storeValue(216, 
			HHHHandler::make ((HHHFn)&RequestHandler::Region_without_N2, cat_XnRegion, cat_Position));
	/* Requests for class CrossRegion */
	table->storeValue(217, HHHandler::make ((HHFn)&RequestHandler::CrossRegion_boxes_N1, cat_CrossRegion));
	table->storeValue(218, BHHandler::make ((BHFn)&RequestHandler::CrossRegion_isBox_N1, cat_CrossRegion));
	table->storeValue(219, 
			HHHHandler::make ((HHHFn)&RequestHandler::CrossRegion_projection_N2, cat_CrossRegion, cat_PrimIntValue));
	table->storeValue(220, HHHandler::make ((HHFn)&RequestHandler::CrossRegion_projections_N1, cat_CrossRegion));
	/* Requests for class Filter */
	table->storeValue(391, HHHandler::make ((HHFn)&RequestHandler::Filter_baseRegion_N1, cat_Filter));
	table->storeValue(392, HHHandler::make ((HHFn)&RequestHandler::Filter_intersectedFilters_N1, cat_Filter));
	table->storeValue(393, BHHandler::make ((BHFn)&RequestHandler::Filter_isAllFilter_N1, cat_Filter));
	table->storeValue(394, BHHandler::make ((BHFn)&RequestHandler::Filter_isAnyFilter_N1, cat_Filter));
	table->storeValue(221, 
			BHHHandler::make ((BHHFn)&RequestHandler::Filter_match_N2, cat_Filter, cat_XnRegion));
	table->storeValue(395, HHHandler::make ((HHFn)&RequestHandler::Filter_unionedFilters_N1, cat_Filter));
	/* Requests for class IDRegion */
	table->storeValue(396, HHHandler::make ((HHFn)&RequestHandler::IDRegion_import_N1, cat_PrimIntArray));
	table->storeValue(397, HHHandler::make ((HHFn)&RequestHandler::IDRegion_export_N1, cat_IDRegion));
	/* Requests for class IntegerRegion */
	table->storeValue(222, HHHandler::make ((HHFn)&RequestHandler::IntegerRegion_intervals_N1, cat_IntegerRegion));
	table->storeValue(398, 
			HHHHandler::make ((HHHFn)&RequestHandler::IntegerRegion_intervals_N2, cat_IntegerRegion, cat_OrderSpec));
	table->storeValue(223, BHHandler::make ((BHFn)&RequestHandler::IntegerRegion_isBoundedAbove_N1, cat_IntegerRegion));
	table->storeValue(224, BHHandler::make ((BHFn)&RequestHandler::IntegerRegion_isBoundedBelow_N1, cat_IntegerRegion));
	table->storeValue(225, BHHandler::make ((BHFn)&RequestHandler::IntegerRegion_isInterval_N1, cat_IntegerRegion));
	table->storeValue(226, HHHandler::make ((HHFn)&RequestHandler::IntegerRegion_start_N1, cat_IntegerRegion));
	table->storeValue(227, HHHandler::make ((HHFn)&RequestHandler::IntegerRegion_stop_N1, cat_IntegerRegion));
	/* Requests for class RealRegion */
	table->storeValue(228, HHHandler::make ((HHFn)&RequestHandler::RealRegion_intervals_N1, cat_RealRegion));
	table->storeValue(399, 
			HHHHandler::make ((HHHFn)&RequestHandler::RealRegion_intervals_N2, cat_RealRegion, cat_OrderSpec));
	table->storeValue(229, BHHandler::make ((BHFn)&RequestHandler::RealRegion_isBoundedAbove_N1, cat_RealRegion));
	table->storeValue(230, BHHandler::make ((BHFn)&RequestHandler::RealRegion_isBoundedBelow_N1, cat_RealRegion));
	table->storeValue(231, BHHandler::make ((BHFn)&RequestHandler::RealRegion_isInterval_N1, cat_RealRegion));
	table->storeValue(232, HHHandler::make ((HHFn)&RequestHandler::RealRegion_lowerBound_N1, cat_RealRegion));
	table->storeValue(233, HHHandler::make ((HHFn)&RequestHandler::RealRegion_upperBound_N1, cat_RealRegion));
	/* Requests for class SequenceRegion */
	table->storeValue(234, HHHandler::make ((HHFn)&RequestHandler::SequenceRegion_intervals_N1, cat_SequenceRegion));
	table->storeValue(400, 
			HHHHandler::make ((HHHFn)&RequestHandler::SequenceRegion_intervals_N2, cat_SequenceRegion, cat_OrderSpec));
	table->storeValue(235, BHHandler::make ((BHFn)&RequestHandler::SequenceRegion_isBoundedAbove_N1, cat_SequenceRegion));
	table->storeValue(236, BHHandler::make ((BHFn)&RequestHandler::SequenceRegion_isBoundedBelow_N1, cat_SequenceRegion));
	table->storeValue(237, BHHandler::make ((BHFn)&RequestHandler::SequenceRegion_isInterval_N1, cat_SequenceRegion));
	table->storeValue(238, HHHandler::make ((HHFn)&RequestHandler::SequenceRegion_lowerEdge_N1, cat_SequenceRegion));
	table->storeValue(239, HHHandler::make ((HHFn)&RequestHandler::SequenceRegion_lowerEdgePrefixLimit_N1, cat_SequenceRegion));
	table->storeValue(240, HHHandler::make ((HHFn)&RequestHandler::SequenceRegion_lowerEdgeType_N1, cat_SequenceRegion));
	table->storeValue(241, HHHandler::make ((HHFn)&RequestHandler::SequenceRegion_upperEdge_N1, cat_SequenceRegion));
	table->storeValue(242, HHHandler::make ((HHFn)&RequestHandler::SequenceRegion_upperEdgePrefixLimit_N1, cat_SequenceRegion));
	table->storeValue(243, HHHandler::make ((HHFn)&RequestHandler::SequenceRegion_upperEdgeType_N1, cat_SequenceRegion));
	/* Requests for class Value */
		/* Requests for class FloatValue */
	table->storeValue(244, SpecialHandler::make ((VHFn)&PromiseManager::makeFloat));
	table->storeValue(401, HHHandler::make ((HHFn)&RequestHandler::FloatValue_bitCount_N1, cat_PrimFloatValue));
	/* Requests for class IntValue */
	table->storeValue(245, SpecialHandler::make ((VHFn)&PromiseManager::makeHumber));
	table->storeValue(402, 
			HHHHandler::make ((HHHFn)&RequestHandler::IntValue_bitwiseAnd_N2, cat_PrimIntValue, cat_PrimIntValue));
	table->storeValue(403, 
			HHHHandler::make ((HHHFn)&RequestHandler::IntValue_bitwiseOr_N2, cat_PrimIntValue, cat_PrimIntValue));
	table->storeValue(404, 
			HHHHandler::make ((HHHFn)&RequestHandler::IntValue_bitwiseXor_N2, cat_PrimIntValue, cat_PrimIntValue));
	table->storeValue(246, 
			HHHHandler::make ((HHHFn)&RequestHandler::IntValue_dividedBy_N2, cat_PrimIntValue, cat_PrimIntValue));
	table->storeValue(247, 
			BHHHandler::make ((BHHFn)&RequestHandler::IntValue_isGE_N2, cat_PrimIntValue, cat_PrimIntValue));
	table->storeValue(405, 
			HHHHandler::make ((HHHFn)&RequestHandler::IntValue_leftShift_N2, cat_PrimIntValue, cat_PrimIntValue));
	table->storeValue(248, 
			HHHHandler::make ((HHHFn)&RequestHandler::IntValue_maximum_N2, cat_PrimIntValue, cat_PrimIntValue));
	table->storeValue(249, 
			HHHHandler::make ((HHHFn)&RequestHandler::IntValue_minimum_N2, cat_PrimIntValue, cat_PrimIntValue));
	table->storeValue(250, 
			HHHHandler::make ((HHHFn)&RequestHandler::IntValue_minus_N2, cat_PrimIntValue, cat_PrimIntValue));
	table->storeValue(406, 
			HHHHandler::make ((HHHFn)&RequestHandler::IntValue_mod_N2, cat_PrimIntValue, cat_PrimIntValue));
	table->storeValue(251, 
			HHHHandler::make ((HHHFn)&RequestHandler::IntValue_plus_N2, cat_PrimIntValue, cat_PrimIntValue));
	table->storeValue(407, HHHandler::make ((HHFn)&RequestHandler::IntValue_bitCount_N1, cat_PrimIntValue));
	table->storeValue(252, 
			HHHHandler::make ((HHHFn)&RequestHandler::IntValue_times_N2, cat_PrimIntValue, cat_PrimIntValue));
}


void PromiseManager::fillRequestTable (APTR(PtrArray) table){
	/* Requests for class Promise */
	
	table->storeValue(253, SpecialHandler::make ((VHFn)&PromiseManager::waiveEm));
	table->storeValue(1, SpecialHandler::make ((VHFn)&PromiseManager::delayCast));
	table->storeValue(2, SpecialHandler::make ((VHFn)&PromiseManager::equals));
	table->storeValue(3, SpecialHandler::make ((VHFn)&PromiseManager::promiseHash));
	table->storeValue(4, SpecialHandler::make ((VHFn)&PromiseManager::testKindOf));
	table->storeValue(5, SpecialHandler::make ((VHFn)&PromiseManager::waiveIt));
	/* Requests for class Adminer */
	table->storeValue(408, HHandler::make ((HFn)&RequestHandler::Adminer_make_N0));
	table->storeValue(409, VHBHandler::make ((VHBFn)&RequestHandler::Adminer_acceptConnections_N2, cat_FeAdminer));
	table->storeValue(410, HHHandler::make ((HHFn)&RequestHandler::Adminer_activeSessions_N1, cat_FeAdminer));
	table->storeValue(411, 
			VHHHandler::make ((VHHFn)&RequestHandler::Adminer_execute_N2, cat_FeAdminer, cat_PrimIntArray));
	table->storeValue(412, HHHandler::make ((HHFn)&RequestHandler::Adminer_gateLockSmith_N1, cat_FeAdminer));
	table->storeValue(413, 
			VHHHHandler::make ((VHHHFn)&RequestHandler::Adminer_grant_N3, cat_FeAdminer, cat_ID, cat_IDRegion));
	table->storeValue(414, HHHandler::make ((HHFn)&RequestHandler::Adminer_grants_N1, cat_FeAdminer));
	table->storeValue(415, 
			HHHHandler::make ((HHHFn)&RequestHandler::Adminer_grants_N2, cat_FeAdminer, cat_IDRegion));
	table->storeValue(416, 
			HHHHHandler::make ((HHHHFn)&RequestHandler::Adminer_grants_N3, cat_FeAdminer, cat_IDRegion, cat_IDRegion));
	table->storeValue(417, BHHandler::make ((BHFn)&RequestHandler::Adminer_isAcceptingConnections_N1, cat_FeAdminer));
	table->storeValue(418, 
			VHHHandler::make ((VHHFn)&RequestHandler::Adminer_setGateLockSmith_N2, cat_FeAdminer, cat_FeLockSmith));
	table->storeValue(419, SpecialHandler::make ((VHFn)&PromiseManager::shutdown));
	/* Requests for class Archiver */
	table->storeValue(420, HHandler::make ((HFn)&RequestHandler::Archiver_make_N0));
	table->storeValue(421, 
			HHHHHandler::make ((HHHHFn)&RequestHandler::Archiver_archive_N3, cat_FeArchiver, cat_FeEdition, cat_FeEdition));
	table->storeValue(422, 
			VHHHandler::make ((VHHFn)&RequestHandler::Archiver_markArchived_N2, cat_FeArchiver, cat_FeEdition));
	table->storeValue(423, 
			HHHHHandler::make ((HHHHFn)&RequestHandler::Archiver_restore_N3, cat_FeArchiver, cat_FeEdition, cat_FeEdition));
	/* Requests for class Array */
	table->storeValue(468, HHHandler::make ((HHFn)&RequestHandler::Array_copy_N1, cat_PrimArray));
	table->storeValue(469, 
			HHHHandler::make ((HHHFn)&RequestHandler::Array_copy_N2, cat_PrimArray, cat_PrimIntValue));
	table->storeValue(255, 
			HHHHHandler::make ((HHHHFn)&RequestHandler::Array_copy_N3, cat_PrimArray, cat_PrimIntValue, cat_PrimIntValue));
	table->storeValue(424, 
			HHHHHHandler::make ((HHHHHFn)&RequestHandler::Array_copy_N4, cat_PrimArray, cat_PrimIntValue, cat_PrimIntValue, cat_PrimIntValue));
	table->storeValue(425, 
			HHHHHHHandler::make ((HHHHHHFn)&RequestHandler::Array_copy_N5, cat_PrimArray, cat_PrimIntValue, cat_PrimIntValue, cat_PrimIntValue, cat_PrimIntValue));
	table->storeValue(6, HHHandler::make ((HHFn)&RequestHandler::Array_count_N1, cat_PrimArray));
	table->storeValue(7, SpecialHandler::make ((VHFn)&PromiseManager::export0));
	table->storeValue(256, SpecialHandler::make ((VHFn)&PromiseManager::export1));
	table->storeValue(257, SpecialHandler::make ((VHFn)&PromiseManager::export2));
	table->storeValue(8, 
			HHHHandler::make ((HHHFn)&RequestHandler::Array_get_N2, cat_PrimArray, cat_PrimIntValue));
	table->storeValue(9, 
			VHHHHandler::make ((VHHHFn)&RequestHandler::Array_store_N3, cat_PrimArray, cat_PrimIntValue, cat_Heaper));
	table->storeValue(258, VHHandler::make ((VHFn)&RequestHandler::Array_storeAll_N1, cat_PrimArray));
	table->storeValue(259, 
			VHHHandler::make ((VHHFn)&RequestHandler::Array_storeAll_N2, cat_PrimArray, cat_Heaper));
	table->storeValue(260, 
			VHHHHandler::make ((VHHHFn)&RequestHandler::Array_storeAll_N3, cat_PrimArray, cat_Heaper, cat_PrimIntValue));
	table->storeValue(261, 
			VHHHHHandler::make ((VHHHHFn)&RequestHandler::Array_storeAll_N4, cat_PrimArray, cat_Heaper, cat_PrimIntValue, cat_PrimIntValue));
	table->storeValue(262, 
			VHHHHandler::make ((VHHHFn)&RequestHandler::Array_storeMany_N3, cat_PrimArray, cat_PrimIntValue, cat_PrimArray));
	table->storeValue(263, 
			VHHHHHandler::make ((VHHHHFn)&RequestHandler::Array_storeMany_N4, cat_PrimArray, cat_PrimIntValue, cat_PrimArray, cat_PrimIntValue));
	table->storeValue(264, 
			VHHHHHHandler::make ((VHHHHHFn)&RequestHandler::Array_storeMany_N5, cat_PrimArray, cat_PrimIntValue, cat_PrimArray, cat_PrimIntValue, cat_PrimIntValue));
	/* Requests for class FloatArray */
	table->storeValue(265, SpecialHandler::make ((VHFn)&PromiseManager::makeFloatArray));
	table->storeValue(266, 
			HHHHandler::make ((HHHFn)&RequestHandler::FloatArray_zeros_N2, cat_PrimIntValue, cat_PrimIntValue));
	table->storeValue(267, HHHandler::make ((HHFn)&RequestHandler::FloatArray_bitCount_N1, cat_PrimFloatArray));
	/* Requests for class HumberArray */
	table->storeValue(268, SpecialHandler::make ((VHFn)&PromiseManager::makeHumberArray));
	table->storeValue(269, HHHandler::make ((HHFn)&RequestHandler::HumberArray_zeros_N1, cat_PrimIntValue));
	/* Requests for class IntArray */
	table->storeValue(10, SpecialHandler::make ((VHFn)&PromiseManager::makeIntArray));
	table->storeValue(11, 
			HHHHandler::make ((HHHFn)&RequestHandler::IntArray_zeros_N2, cat_PrimIntValue, cat_PrimIntValue));
	table->storeValue(12, HHHandler::make ((HHFn)&RequestHandler::IntArray_bitCount_N1, cat_PrimIntArray));
	/* Requests for class PtrArray */
	table->storeValue(270, SpecialHandler::make ((VHFn)&PromiseManager::makePtrArray));
	table->storeValue(271, HHHandler::make ((HHFn)&RequestHandler::PtrArray_nulls_N1, cat_PrimIntValue));
	/* Requests for class Bundle */
	table->storeValue(13, HHHandler::make ((HHFn)&RequestHandler::Bundle_region_N1, cat_FeBundle));
	/* Requests for class ArrayBundle */
	table->storeValue(14, HHHandler::make ((HHFn)&RequestHandler::ArrayBundle_array_N1, cat_FeArrayBundle));
	table->storeValue(15, HHHandler::make ((HHFn)&RequestHandler::ArrayBundle_ordering_N1, cat_FeArrayBundle));
	/* Requests for class ElementBundle */
	table->storeValue(16, HHHandler::make ((HHFn)&RequestHandler::ElementBundle_element_N1, cat_FeElementBundle));
	/* Requests for class PlaceHolderBundle */
		/* Requests for class CoordinateSpace */
	table->storeValue(272, HHHandler::make ((HHFn)&RequestHandler::CoordinateSpace_ascending_N1, cat_CoordinateSpace));
	table->storeValue(273, 
			HHHHandler::make ((HHHFn)&RequestHandler::CoordinateSpace_completeMapping_N2, cat_CoordinateSpace, cat_XnRegion));
	table->storeValue(274, HHHandler::make ((HHFn)&RequestHandler::CoordinateSpace_descending_N1, cat_CoordinateSpace));
	table->storeValue(17, HHHandler::make ((HHFn)&RequestHandler::CoordinateSpace_emptyRegion_N1, cat_CoordinateSpace));
	table->storeValue(18, HHHandler::make ((HHFn)&RequestHandler::CoordinateSpace_fullRegion_N1, cat_CoordinateSpace));
	table->storeValue(19, HHHandler::make ((HHFn)&RequestHandler::CoordinateSpace_identityMapping_N1, cat_CoordinateSpace));
	/* Requests for class CrossSpace */
	table->storeValue(20, HHHandler::make ((HHFn)&RequestHandler::CrossSpace_make_N1, cat_PtrArray));
	table->storeValue(275, HHHandler::make ((HHFn)&RequestHandler::CrossSpace_axes_N1, cat_CrossSpace));
	table->storeValue(276, 
			HHHHandler::make ((HHHFn)&RequestHandler::CrossSpace_axis_N2, cat_CrossSpace, cat_PrimIntValue));
	table->storeValue(277, HHHandler::make ((HHFn)&RequestHandler::CrossSpace_axisCount_N1, cat_CrossSpace));
	table->storeValue(278, HHHandler::make ((HHFn)&RequestHandler::CrossSpace_crossOfMappings_N1, cat_CrossSpace));
	table->storeValue(279, 
			HHHHandler::make ((HHHFn)&RequestHandler::CrossSpace_crossOfMappings_N2, cat_CrossSpace, cat_PtrArray));
	table->storeValue(426, HHHandler::make ((HHFn)&RequestHandler::CrossSpace_crossOfOrderSpecs_N1, cat_CrossSpace));
	table->storeValue(427, 
			HHHHandler::make ((HHHFn)&RequestHandler::CrossSpace_crossOfOrderSpecs_N2, cat_CrossSpace, cat_PtrArray));
	table->storeValue(428, 
			HHHHHandler::make ((HHHHFn)&RequestHandler::CrossSpace_crossOfOrderSpecs_N3, cat_CrossSpace, cat_PtrArray, cat_PrimIntArray));
	table->storeValue(21, 
			HHHHandler::make ((HHHFn)&RequestHandler::CrossSpace_crossOfPositions_N2, cat_CrossSpace, cat_PtrArray));
	table->storeValue(22, 
			HHHHandler::make ((HHHFn)&RequestHandler::CrossSpace_crossOfRegions_N2, cat_CrossSpace, cat_PtrArray));
	table->storeValue(23, 
			HHHHHandler::make ((HHHHFn)&RequestHandler::CrossSpace_extrusion_N3, cat_CrossSpace, cat_PrimIntValue, cat_XnRegion));
	/* Requests for class FilterSpace */
	table->storeValue(280, HHHandler::make ((HHFn)&RequestHandler::FilterSpace_make_N1, cat_CoordinateSpace));
	table->storeValue(24, 
			HHHHandler::make ((HHHFn)&RequestHandler::FilterSpace_allFilter_N2, cat_FilterSpace, cat_XnRegion));
	table->storeValue(25, 
			HHHHandler::make ((HHHFn)&RequestHandler::FilterSpace_anyFilter_N2, cat_FilterSpace, cat_XnRegion));
	table->storeValue(281, HHHandler::make ((HHFn)&RequestHandler::FilterSpace_baseSpace_N1, cat_FilterSpace));
	table->storeValue(429, 
			HHHHandler::make ((HHHFn)&RequestHandler::FilterSpace_position_N2, cat_FilterSpace, cat_XnRegion));
	/* Requests for class IDSpace */
	table->storeValue(26, HHandler::make ((HFn)&RequestHandler::IDSpace_global_N0));
	table->storeValue(282, HHHandler::make ((HHFn)&RequestHandler::IDSpace_import_N1, cat_PrimIntArray));
	PromiseManager::fillRequestTable1(table);
}
/* operations */


void PromiseManager::force (){
	this->flushAcks();
	if (myDetectorEvents != NULL) {
		while (myDetectorEvents != NULL) {
			myDetectorEvents->trigger(this);
			myDetectorEvents = myDetectorEvents->next();
		}
	}
	myWriteStream->flush();
}


void PromiseManager::handleRequest (){
	amInsideRequest = TRUE;
	/* Thing to do !!!! */
	
	/* This should not forward all errors. */
	do {
		INSTALL_SHIELD(ex);
		SHIELD_UP_BEGIN(ex, EVERY_COMMFilter) {
			Problem * prob;
			
			prob = &PROBLEM(ex);
			
			
			this->respondProblem(prob);
			break;
		} SHIELD_UP_END(ex);
		Int32 reqnum;
		
		reqnum = this->receiveRequestNumber();
		/* [cerr cr << myNextClientPromise << (myHandlers 
			get: reqnum).  cerr endEntry] smalltalkOnly. */
		CAST(RequestHandler,myHandlers->get(reqnum))->handleRequest(this);
	} while (FALSE);
	if (myError != NULL) {
		this->respondError();
	}
	amInsideRequest = FALSE;
	/* Forcing flushes detector events too. */
	if (myDetectorEvents != NULL) {
		this->force();
	} else {
		myWriteStream->flush();
	}
}


BooleanVar PromiseManager::noErrors (){
	/* Return true if no errors have occurred in the current 
	transaction. */
	
	return myError == NULL;
}


void PromiseManager::queueDetectorEvent (APTR(DetectorEvent) event){
	/* Queue up the detector event.  It will be executed after 
	the next transaction. */
	
	event->setNext(myDetectorEvents);
	myDetectorEvents = event;
	if (!amInsideRequest) {
		this->force();
	}
}


void PromiseManager::waive (){
	/* Release the promise argument.  This could return a value 
	because the PromiseManager doesn't keep any state for void promises. */
	
	this->actualWaive(this->receiveIntegerVar());
}


void PromiseManager::waiveMany (){
	/* Release a range of promise argument, given a start and a 
	count.  This could return a value because the PromiseManager 
	doesn't keep any state for void promises. */
	
	IntegerVar prnum;
	IntegerVar prcount;
	
	prnum = this->receiveIntegerVar();
	prcount = this->receiveIntegerVar();
	{
		IntegerVar LoopFinal = prnum + prcount;
		IntegerVar i = prnum;
		for (;;) {
			if (i >= LoopFinal){
				break;
			}
			{
				this->actualWaive(i);
			}
			i += 1;
		}
	}
}
/* comm */


BooleanVar PromiseManager::fetchBooleanVar (){
	/* Optimize promise arguments that are expected to point at 
	IntValues. */
	
	IntegerVar num;
	SPTR(Heaper) OR(NULL) result;
	
	num = this->receiveIntegerVar();
	result = myActuals->fetch(num);
	if (result == NULL) {
		myError = ExceptionRecord::excuse(num)->best(myError);
		return FALSE;
	}
	BEGIN_CHOOSE(result) {
		BEGIN_KIND(PrimIntValue,number) {
			return number->asIntegerVar() != IntegerVarZero;
		} END_KIND;
		BEGIN_OTHERS {
			myError = ExceptionRecord::mismatch(num)->best(myError);
		} END_OTHERS;
	} END_CHOOSE;
	return FALSE;
}


RPTR(Category) OR(NULL) PromiseManager::fetchCategory (){
	Int32 num;
	SPTR(Category) OR(NULL) result;
	
	/* Thing to do !!!! */
	
	/* Renumber the categories from 0. */
	num = this->receiveRequestNumber();
	result = CAST(Category,PromiseManager::PromiseClasses->fetch(num));
	if (result == NULL) {
		myError = ExceptionRecord::badCategory(num)->best(myError);
		return NULL;
	}
	WPTR(Category) OR(NULL) 	returnValue;
	returnValue = result;
	return returnValue;
}


RPTR(Heaper) PromiseManager::fetchHeaper (APTR(Category) cat){
	IntegerVar num;
	SPTR(Heaper) OR(NULL) result;
	
	num = this->receiveIntegerVar();
	if (num == IntegerVarZero) {
		return NULL;
	}
	result = myActuals->fetch(num);
	if (result == NULL) {
		myError = ExceptionRecord::excuse(num)->best(myError);
		return NULL;
	}
	if (!result->isKindOf(cat)) {
		myError = ExceptionRecord::mismatch(num)->best(myError);
		return NULL;
	}
	WPTR(Heaper) 	returnValue;
	returnValue = result;
	return returnValue;
}


Int32 PromiseManager::fetchInt32 (){
	return this->fetchIntegerVar().asLong();
}


IntegerVar PromiseManager::fetchIntegerVar (){
	/* Optimize promise arguments that are expected to point at 
	IntValues. */
	
	IntegerVar num;
	SPTR(Heaper) OR(NULL) result;
	
	num = this->receiveIntegerVar();
	result = myActuals->fetch(num);
	if (result == NULL) {
		myError = ExceptionRecord::excuse(num)->best(myError);
		return IntegerVarZero;
	}
	BEGIN_CHOOSE(result) {
		BEGIN_KIND(PrimIntValue,number) {
			return number->asIntegerVar();
		} END_KIND;
		BEGIN_OTHERS {
			myError = ExceptionRecord::mismatch(num)->best(myError);
		} END_OTHERS;
	} END_CHOOSE;
	return IntegerVarZero;
}


RPTR(Heaper) PromiseManager::fetchNonNullHeaper (APTR(Category) cat){
	IntegerVar num;
	SPTR(Heaper) OR(NULL) result;
	
	num = this->receiveIntegerVar();
	if (num == IntegerVarZero) {
		myError = ExceptionRecord::wasNull(num)->best(myError);
		return NULL;
	}
	result = myActuals->fetch(num);
	if (result == NULL) {
		myError = ExceptionRecord::excuse(num)->best(myError);
		return NULL;
	}
	if (!result->isKindOf(cat)) {
		myError = ExceptionRecord::mismatch(num)->best(myError);
		return NULL;
	}
	WPTR(Heaper) 	returnValue;
	returnValue = result;
	return returnValue;
}


IntegerVar PromiseManager::receiveIntegerVar (){
	/* A new representation that requires less shifting (eventually). */
	/* 
	7/1 		0<7>
	14/2	10<6>		<8>
	21/3	110<5>		<16>
	28/4	1110<4>		<24>
	35/5	11110<3>	<32>
	42/6	111110<2>	<40>
	49/7	1111110<1>	<48>
	56/8	11111110 	<56>
	+/+	11111111  <humber count>
	 */
	/* This is smalltalk only because smalltalk doesn't do sign-extend. */
	
	UInt8 byte;
	UInt8 mask;
	Int32 count;
	Int32 num;
	
	/* count is bytes following first word or -1 if bignum 
	meaning next byte is humber for actual count */
	byte = myReadStream->getByte();
	if (byte <= 63) {
		return byte;
	}
	if (byte <= 127) {
		return byte - 128;
	}
	if (byte <= 191) {
		mask = 63;
		count = 1;
	} else {
		if (byte <= 223) {
			mask = 31;
			count = 2;
		} else {
			if (byte <= 239) {
				mask = 15;
				count = 3;
			} else {
				if (byte <= 247) {
					mask = 7;
					count = 4;
				} else {
					BLAST(NOT_YET_IMPLEMENTED);
				}
			}
		}
	}
	byte &= mask;
	if ((byte & (~mask >> 1 & mask)) != Int32Zero) {
		byte |= ~mask;
		num = -1;
	} else {
		num = Int32Zero;
		{	BooleanVar crutch_Flag;
			/* count > 3 && byte != (byte & mask) */
			
			crutch_Flag = count > 3;
			if(crutch_Flag) {
				crutch_Flag = byte != (byte & mask);
			}
			if (crutch_Flag) {
				BLAST(NOT_YET_IMPLEMENTED);
			}
		}
	}
	num = (num << 8) + byte;
	{
		Int32 LoopFinal = count;
		Int32 i = 1;
		for (;;) {
			if (i > LoopFinal){
				break;
			}
			{
				num = (num << 8) + myReadStream->getByte();
			}
			i += 1;
		}
	}
	return num;
}


void PromiseManager::respondBooleanVar (BooleanVar val){
	if (myError == NULL) {
		this->flushAcks();
		this->sendResponse(PromiseManager::humberResponse());
		this->sendIntegerVar(val);
		myActuals->introduce(myNextClientPromise, PrimIntValue::make (val));
		
		
		myNextClientPromise += 1;
	}
}


void PromiseManager::respondHeaper (APTR(Heaper) result){
	if (result == NULL) {
		BLAST(NullResponseResult);
	}
	if (myError == NULL) {
		BEGIN_CHOOSE(result) {
			BEGIN_KIND(PrimIntValue,i) {
				this->flushAcks();
				this->sendResponse(PromiseManager::humberResponse());
				this->sendIntegerVar(i->asIntegerVar());
			} END_KIND;
			BEGIN_KIND(PrimFloatValue,f) {
				this->flushAcks();
				this->sendResponse(PromiseManager::IEEEResponse());
				if (f->bitCount() == 64) {
					this->sendIEEE64(f->asIEEE64());
				} else {
					if (f->bitCount() == 32) {
						this->sendIEEE32(f->asIEEE32());
					} else {
						BLAST(NOT_YET_IMPLEMENTED);
					}
				}
			} END_KIND;
			BEGIN_OTHERS {
				myAcks += 1;
			} END_OTHERS;
		} END_CHOOSE;
		myActuals->introduce(myNextClientPromise, result);
		if (result->isKindOf(cat_FeDetector)) {
			IntegerVar refCt;
			
			refCt = myRefCounts->fetch(result);
			if (refCt == -1) {
				myRefCounts->introduce(result, 1);
			} else {
				myRefCounts->remove(result);
				myRefCounts->introduce(result, refCt + 1);
			}
		}
		myNextClientPromise += 1;
	}
}


void PromiseManager::respondIntegerVar (IntegerVar val){
	if (myError == NULL) {
		this->flushAcks();
		this->sendResponse(PromiseManager::humberResponse());
		this->sendIntegerVar(val);
		myActuals->introduce(myNextClientPromise, PrimIntValue::make (val));
		myNextClientPromise += 1;
	}
}


void PromiseManager::respondVoid (){
	if (myError == NULL) {
		myAcks += 1;
		myNextClientPromise += 1;
	}
}


void PromiseManager::sendIEEE32 (IEEE32 f){
	this->sendIntegerVar (4);
	for (UInt32 i = 0; i < 4; i++) {
		myWriteStream->putByte (((UInt8 *) &f) [i]);
	}
	
	
}


void PromiseManager::sendIEEE64 (IEEE64 f){
	this->sendIntegerVar (8);
	for (UInt32 i = 0; i < 8; i++) {
		myWriteStream->putByte (((UInt8 *) &f) [i]);
	}
	
	
}


void PromiseManager::sendIntegerVar (IntegerVar num){
	/* Send a Dean style humber.  Like Drexler style, except all 
	the tag bits go into the first byte. */
	/* 
	7/1 		0<7>
	14/2	10<6>		<8>
	21/3	110<5>		<16>
	28/4	1110<4>		<24>
	35/5	11110<3>	<32>
	42/6	111110<2>	<40>
	49/7	1111110<1>	<48>
	56/8	11111110 	<56>
	+/+	11111111  <humber count>
	 */
	
	IntegerVar abs;
	Int32 low32;
	
	if (num < IntegerVarZero) {
		abs = -num;
	} else {
		abs = num;
	}
	/* (1 bitShift: 32) -1 */
	low32 = (num & 4294967295).asLong();
	/* 1 bitShift: 6 */
	if (num < 64) {
		myWriteStream->putByte(low32 & 127);
		return;
		
	}
	/* 1 bitShift: 13 */
	if (abs < 8192) {
		myWriteStream->putByte(low32 >> 8 & 63 | 128);
		myWriteStream->putByte(low32 & 255);
		return;
		
	}
	/* 1 bitShift: 20 */
	if (abs < 1048576) {
		myWriteStream->putByte(low32 >> 16 & 31 | 192);
		myWriteStream->putByte(low32 >> 8 & 255);
		myWriteStream->putByte(low32 & 255);
		return;
		
	}
	/* 1 bitShift: 27 */
	if (abs < 134217728) {
		myWriteStream->putByte(low32 >> 24 & 15 | 224);
		myWriteStream->putByte(low32 >> 16 & 255);
		myWriteStream->putByte(low32 >> 8 & 255);
		myWriteStream->putByte(low32 & 255);
		return;
		
	}
	/* abs < (1 bitShift: 34) */
		/* do shift in two steps to get around Sparc shift 
		bug /ravi/7/23/92/ */
	if (TRUE) {
		myWriteStream->putByte((num >> 16 >> 16 & 7 | 240).asLong());
		myWriteStream->putByte((num >> 24 & 255).asLong());
		myWriteStream->putByte((num >> 16 & 255).asLong());
		myWriteStream->putByte((num >> 8 & 255).asLong());
		myWriteStream->putByte((num & 255).asLong());
		return;
		
	}
	/* self sendIntegerVar: (abs log: 256) truncated + 1. */
		/* The humber count. */
		/* Write out each of the bytes. */
	BLAST(NOT_YET_IMPLEMENTED);
}


void PromiseManager::sendPromise (APTR(Heaper) heaper){
	/* Register heaper with the next Server promise number and 
	increment it.  The client must stay in sync. */
	
	myActuals->introduce(myNextServerPromise, heaper);
	myNextServerPromise -= 1;
}


void PromiseManager::sendResponse (Int32 num){
	/* Use a representation optimized for small positive numbers. */
	/* If the number is less than 255 then just send it.  
	Otherwise send 255, subtract 255 and recur. */
	
	Int32 val;
	
	val = num;
	while (!(num < 255)) {
		myWriteStream->putByte(255);
		val -= 255;
	}
	myWriteStream->putByte((UInt8 ) val);
}
/* arrays */


void PromiseManager::sendHumbers (
		APTR(IntegerVarArray) array, 
		Int32 count, 
		Int32 start)
{
	/* Send a bunch of IntegerVars to the client. */
	
	Int32 maxx;
	
	maxx = start + count;
	if (maxx > array->count()) {
		BLAST(OutOfBounds);
	}
	this->flushAcks();
	this->sendResponse(PromiseManager::humbersResponse());
	this->sendIntegerVar(count);
	myActuals->introduce(myNextClientPromise, PrimIntValue::make (count));
	{
		Int32 LoopFinal = maxx;
		Int32 i = start;
		for (;;) {
			if (i >= LoopFinal){
				break;
			}
			{
				this->sendIntegerVar(array->integerVarAt(i));
			}
			i += 1;
		}
	}
	myNextClientPromise += 1;
}


void PromiseManager::sendIEEEs (
		APTR(PrimFloatArray) array, 
		Int32 count, 
		Int32 start)
{
	/* Send a bunch of fixed precision integers to the client. */
	
	Int32 size;
	SPTR(UInt8Array) buffer;
	
	if (start + count > array->count()) {
		BLAST(OutOfBounds);
	}
	this->flushAcks();
	this->sendResponse(PromiseManager::IEEEsResponse());
	this->sendIntegerVar(array->bitCount() / 8);
	this->sendIntegerVar(count);
	myActuals->introduce(myNextClientPromise, PrimIntValue::make (count));
	size = array->bitCount() / 8 * count;
	buffer = CAST(UInt8Array,PrimIntArray::zeros(8, size));
	{
		PLANT_BOMB(ReleaseGuts,Boom);
		ARM_BOMB(Boom,(buffer))
		{
			array->copyToBuffer(buffer->gutsOf(), size, count, start);
		}
	}
	{
		PLANT_BOMB(ReleaseGuts,Boom);
		ARM_BOMB(Boom,(buffer))
		{
			myShuffler->shuffle(array->bitCount(), buffer->gutsOf(), count);
		}
	}
	myWriteStream->putData(buffer);
	myNextClientPromise += 1;
}


void PromiseManager::sendInts (
		APTR(PrimIntArray) array, 
		Int32 count, 
		Int32 start)
{
	/* Send a bunch of fixed precision integers to the client. */
	
	Int32 size;
	SPTR(UInt8Array) buffer;
	
	if (start + count > array->count()) {
		BLAST(OutOfBounds);
	}
	this->flushAcks();
	this->sendResponse(PromiseManager::intsResponse());
	this->sendIntegerVar(array->bitCount());
	this->sendIntegerVar(count);
	myActuals->introduce(myNextClientPromise, PrimIntValue::make (count));
	size = abs(array->bitCount()) / 8 * count;
	buffer = CAST(UInt8Array,PrimIntArray::zeros(8, size));
	{
		PLANT_BOMB(ReleaseGuts,Boom);
		ARM_BOMB(Boom,(buffer))
		{
			array->copyToBuffer(buffer->gutsOf(), size, count, start);
		}
	}
	{
		PLANT_BOMB(ReleaseGuts,Boom);
		ARM_BOMB(Boom,(buffer))
		{
			myShuffler->shuffle(abs(array->bitCount()), buffer->gutsOf(), count);
		}
	}
	myWriteStream->putData(buffer);
	myNextClientPromise += 1;
}


void PromiseManager::sendPromises (
		APTR(PtrArray) array, 
		Int32 count, 
		Int32 start)
{
	/* Register heaper with the next Server promise number and 
	increment it.  The client must stay in sync. */
	
	Int32 maxx;
	Int32 nulls;
	Int32 ptrs;
	
	maxx = start + count;
	if (maxx > array->count()) {
		BLAST(OutOfBounds);
	}
	nulls = Int32Zero;
	ptrs = Int32Zero;
	this->flushAcks();
	this->sendResponse(PromiseManager::promisesResponse());
	this->sendIntegerVar(count);
	myActuals->introduce(myNextClientPromise, PrimIntValue::make (count));
	{
		Int32 LoopFinal = maxx;
		Int32 i = start;
		for (;;) {
			if (i >= LoopFinal){
				break;
			}
			{
				SPTR(Heaper) OR(NULL) elem;
				
				elem = array->fetch(i);
				if (elem == NULL) {
					if (nulls <= Int32Zero) {
						this->sendIntegerVar(ptrs);
						ptrs = Int32Zero;
					}
					nulls += 1;
				} else {
					if (nulls > Int32Zero) {
						this->sendIntegerVar(nulls);
						nulls = Int32Zero;
					}
					this->sendPromise(elem);
					ptrs += 1;
				}
			}
			i += 1;
		}
	}
	if (ptrs >= 1) {
		this->sendIntegerVar(ptrs);
	}
	if (nulls >= 1) {
		this->sendIntegerVar(nulls);
	}
	myNextClientPromise += 1;
}
/* private: comm */


void PromiseManager::actualWaive (IntegerVar prnum){
	/* Release the promise argument.  This could return a value 
	because the PromiseManager doesn't keep any state for void promises. */
	
	SPTR(Heaper) actual;
	IntegerVar count;
	
	actual = myActuals->fetch(prnum);
	if (myActuals->fetch(prnum) != NULL) {
		myActuals->remove(prnum);
	}
	count = myRefCounts->fetch(actual);
	if (count == Int32Zero) {
		BLAST(RefCountBug);
	}
	if (count > Int32Zero) {
		if (count == 1) {
			myRefCounts->remove(actual);
			{actual->destroy();  actual = NULL /* don't want stale (S/CHK)PTRs */;}
		} else {
			myRefCounts->introduce(actual, count - 1);
		}
	}
}


IntegerVar PromiseManager::clientPromiseNumber (){
	return myNextClientPromise;
}


void PromiseManager::flushAcks (){
	/* If any acks have accumulated, flush them. */
	
	if (myAcks > IntegerVarZero) {
		this->sendResponse(PromiseManager::ackResponse());
		this->sendIntegerVar(myAcks);
		myAcks = IntegerVarZero;
	}
}


RPTR(XnReadStream) PromiseManager::readStream (){
	return (XnReadStream*) myReadStream;
}


Int32 PromiseManager::receiveRequestNumber (){
	/* Receive a request number.  The first byte is either 
	between 0 and 254 or it
		 is 255 and the second byte + 255 is the number. */
	
	Int32 byte;
	
	byte = myReadStream->getByte();
	if (byte < 255) {
		return byte;
	}
	return myReadStream->getByte() + 255;
}


void PromiseManager::respondError (){
	this->flushAcks();
	if (myError->isExcused()) {
		this->sendResponse(PromiseManager::excusedResponse());
		this->sendIntegerVar(myError->promise());
	} else {
		this->sendResponse(PromiseManager::errorResponse());
		this->sendIntegerVar(myError->error());
		this->sendIntegerVar(Int32Zero);
	}
	myNextClientPromise += 1;
	myError = NULL;
}


void PromiseManager::respondProblem (Problem * problem){
	BlastLog << "Blast sent: " << problem->getProblemName() << " at: ";
	BlastLog << problem->getFileName() << ":" << problem->getLineNumber() << "\n";
	
	this->flushAcks();
	this->sendResponse(PromiseManager::errorResponse());
	this->sendIntegerVar(PromiseManager::problemNumber(problem->getProblemName()));
	this->sendIntegerVar(PromiseManager::problemSource(problem->getFileName(), problem->getLineNumber()));
	myNextClientPromise += 1;
	myError = NULL;
}


IntegerVar PromiseManager::serverPromiseNumber (){
	return myNextServerPromise;
}
/* protected: creation */


PromiseManager::PromiseManager (
		APTR(Portal) portal, 
		char * clientID, 
		APTR(ByteShuffler) shuffler) 
{
	myPortal = portal;
	myReadStream = portal->readStream();
	myWriteStream = portal->writeStream();
	myActuals = PrimPtrTable::make (5000);
	myRefCounts = PrimIndexTable::make (63);
	myDetectorEvents = NULL;
	myNextClientPromise = 1;
	myNextServerPromise = -1;
	/* Thing to do !!!! */
	
	/* This should get a table based on the clientID. */
	myHandlers = PromiseManager::makeRequestTable();
	delete clientID;
	myAcks = Int32Zero;
	myError = NULL;
	amInsideRequest = FALSE;
	myShuffler = shuffler;
}


void PromiseManager::destruct (){
	SPTR(PrimIndexTableStepper) step;
	
	{myPortal->destroy();  myPortal = NULL /* don't want stale (S/CHK)PTRs */;}
	/* clean up all the ref counted Detectors */
	step = myRefCounts->stepper();
	while (step->hasValue()) {
		SPTR(Heaper) detect;
		
		detect = step->key();
		{detect->destroy();  detect = NULL /* don't want stale (S/CHK)PTRs */;}
		step->step();
	}
	this->Heaper::destruct();
}
/* testing */


UInt32 PromiseManager::actualHashForEqual (){
	return Heaper::takeOop();
}



/* ************************************************************************ *
 * 
 *                    Class ByteShuffler 
 *
 * ************************************************************************ */


/* Instances shuffle bytes to convert between byte sexes.  Subclasses 
are defined for each of the various transformations. */


/* shuffle */


RPTR(ByteShuffler) ByteShuffler::inverse (){
	/* Return a shuffler that inverts the receiver's shuffler.  
	This will typically be the same transformation. */
	
	return this;
}


void ByteShuffler::shuffle (
		Int32 precision, 
		void * buffer, 
		Int32 size)
{
	/* Go from one byte sex to another for representing numbers 
	of the specified precision. */
	
	if (precision == 8) {
		return;
		
	}
	if (precision == 16) {
		this->shuffle16(buffer, size);
		return;
		
	}
	if (precision == 32) {
		this->shuffle32(buffer, size);
		return;
		
	}
	if (precision == 64) {
		this->shuffle64(buffer, size);
		return;
		
	}
	BLAST(BadPrecision);
}
/* private: shuffle */
/* testing */


UInt32 ByteShuffler::actualHashForEqual (){
	return Heaper::takeOop();
}

	/* automatic 0-argument constructor */
ByteShuffler::ByteShuffler() {}



/* ************************************************************************ *
 * 
 *                    Class ExecutePromiseFile 
 *
 * ************************************************************************ */


/* Read client requests from one files and write the results to 
another file. */


/* operate */


BooleanVar ExecutePromiseFile::execute (){
	/* Execute the action defined by this thunk. */
	
	myManager->handleRequest();
	/* Thing to do !!!! */
	
	/* Check whether the read file is Empty. */
	return TRUE;
}
/* hooks: */


void ExecutePromiseFile::restartPromises (APTR(Rcvr) /* rcvr */){
	SPTR(XnReadStream) readStream;
	SPTR(XnWriteStream) writeStream;
	
	readStream = XnReadFile::make (myReadName);
	writeStream = XnWriteFile::make (myWriteName);
	myManager = PromiseManager::make (PairPortal::make (readStream, writeStream));
	myConnection = Connection::make (cat_FeServer);
	/* This should be unnecessary. */
	/* Thing to do !!!! */
	
}

	/* automatic 0-argument constructor */
ExecutePromiseFile::ExecutePromiseFile() {}



/* ************************************************************************ *
 * 
 *                    Class ExceptionRecord 
 *
 * ************************************************************************ */


/* constant */


Int32 ExceptionRecord::badCategory (){
	/* BLAST(BAD_CATEGORY) */
	return PromiseManager::problemNumber("BAD_CATEGORY");
}


Int32 ExceptionRecord::excused (){
	/* BLAST(BROKEN_PROMISE) */
	return PromiseManager::problemNumber("BROKEN_PROMISE");
}


Int32 ExceptionRecord::typeMismatch (){
	/* BLAST(TYPE_MISMATCH) */
	return PromiseManager::problemNumber("TYPE_MISMATCH");
}


Int32 ExceptionRecord::wasNull (){
	/* BLAST(WAS_NULL) */
	return PromiseManager::problemNumber("WAS_NULL");
}
/* creation */


RPTR(ExceptionRecord) ExceptionRecord::badCategory (IntegerVar promise){
	RETURN_CONSTRUCT(ExceptionRecord,(promise, ExceptionRecord::badCategory()));
}


RPTR(ExceptionRecord) ExceptionRecord::excuse (IntegerVar promise){
	RETURN_CONSTRUCT(ExceptionRecord,(promise, ExceptionRecord::excused()));
}


RPTR(ExceptionRecord) ExceptionRecord::mismatch (IntegerVar promise){
	RETURN_CONSTRUCT(ExceptionRecord,(promise, ExceptionRecord::typeMismatch()));
}


RPTR(ExceptionRecord) ExceptionRecord::wasNull (IntegerVar promise){
	RETURN_CONSTRUCT(ExceptionRecord,(promise, ExceptionRecord::wasNull()));
}
/* myPromise is the number of the promise that caused this error.  It 
will be the excuse for an Excused promise. */


/* accessing */


RPTR(ExceptionRecord) ExceptionRecord::best (APTR(ExceptionRecord) OR(NULL) rec){
	/* Return the error most useful to the client for figuring 
	out what happened.  This returns the earliest cause of an 
	error (typically a broken promise. */
	
	if (rec == NULL) {
		return this;
	}
	if (rec->promise() <= myPromise) {
		WPTR(ExceptionRecord) 	returnValue;
		returnValue = rec;
		return returnValue;
	}
	return this;
}


Int32 ExceptionRecord::error (){
	return myError;
}


BooleanVar ExceptionRecord::isExcused (){
	return myError == ExceptionRecord::excused();
}


IntegerVar ExceptionRecord::promise (){
	return myPromise;
}
/* creation */


ExceptionRecord::ExceptionRecord (IntegerVar promise, Int32 error) {
	myPromise = promise;
	myError = error;
}
/* printing */


void ExceptionRecord::printOn (ostream& oo){
	oo << this->getCategory()->name() << "(" << myPromise;
	if (myError == ExceptionRecord::excused()) {
		oo << ", excused)";
	} else {
		if (myError == ExceptionRecord::typeMismatch()) {
			oo << ", typeMismatch)";
		} else {
			if (myError == ExceptionRecord::badCategory()) {
				oo << ", badCategory)";
			}
		}
	}
}
/* testing */


UInt32 ExceptionRecord::actualHashForEqual (){
	return Heaper::takeOop();
}



/* ************************************************************************ *
 * 
 *                    Class NoShuffler 
 *
 * ************************************************************************ */


/* No transformation. */


/* shuffle */


void NoShuffler::shuffle16 (void * buffer, Int32 count){
	/* Do nothing. */
	
	
}


void NoShuffler::shuffle32 (void * buffer, Int32 count){
	/* Do nothing. */
	
	
}


void NoShuffler::shuffle64 (void * buffer, Int32 count){
	/* Do nothing. */
	
	
}

	/* automatic 0-argument constructor */
NoShuffler::NoShuffler() {}



/* ************************************************************************ *
 * 
 *                    Class SimpleShuffler 
 *
 * ************************************************************************ */


/* shuffle big-endian to little-endian transformation. */


/* shuffle */


void SimpleShuffler::shuffle16 (void * buffer, Int32 count){
	/*  shuffle alternating bytes.  */
	
	
	UInt8 temp;
	UInt8 * base = (UInt8 *) buffer;
	for (Int32 index = 0 ; index < count * 2 ; index += 2)
		{
		temp = base[index];
		base[index] = base[index + 1];
		base[index + 1] = temp;
		}

	
}


void SimpleShuffler::shuffle32 (void * buffer, Int32 count){
	/*  shuffle alternating words.  */
	
	
	UInt8 temp;
	UInt8 * base = (UInt8 *) buffer;
	for (Int32 index = 0 ; index < count * 4; index += 4)
		{
		temp = base[index];
		base[index] = base[index + 3];
		base[index + 3] = temp;
		temp = base[index + 1];
		base[index + 1] = base[index + 2];
		base[index + 2] = temp;
		}
	
}


void SimpleShuffler::shuffle64 (void * buffer, Int32 count){
	BLAST(NOT_YET_IMPLEMENTED);
}

	/* automatic 0-argument constructor */
SimpleShuffler::SimpleShuffler() {}



/* ************************************************************************ *
 * 
 *                    Class SpecialHandler 
 *
 * ************************************************************************ */


/* creation */


RPTR(RequestHandler) SpecialHandler::make (VHFn fn){
	RETURN_CONSTRUCT(SpecialHandler,(fn, tcsj));
}
/* request handling */


void SpecialHandler::handleRequest (APTR(PromiseManager) pm){
	(*(myFn)) (pm);
}
/* creation */


SpecialHandler::SpecialHandler (VHFn fn, TCSJ) {
	myFn = fn;
}

#ifndef PROMANX_SXX
#include "promanx.sxx"
#endif /* PROMANX_SXX */


#ifndef PROMANR_SXX
#include "promanr.sxx"
#endif /* PROMANR_SXX */


#ifndef PROMANP_SXX
#include "promanp.sxx"
#endif /* PROMANP_SXX */



#endif /* PROMANX_CXX */

