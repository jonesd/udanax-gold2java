/* Copyright Xanadu Operating Company.  All Rights Reserved. */

/******************************************************************************
*                                                                            *
* The information contained herein is confidential, proprietary to Xanadu    *
* Operating Company, and considered a trade secret as defined in section     * 
* 499C of the penal code of the State of California.  Use of this information* 
* by anyone other than authorized employees of Xanadu is granted             *
* only under a  written non-disclosure agreement, expressly prescribing      * 
* the scope and  manner of such use.                                         *
*                                                                            *
***************************************************************************
Output from Objectworks for Smalltalk-80(tm), Version 2.5 of 29 July 1989
*/

#ifndef SKTSRVX_CXX
#define SKTSRVX_CXX


#ifndef CHOOSEX_HXX
#include "choosex.hxx"
#endif /* CHOOSEX_HXX */

#ifndef SKTSRVX_HXX
#include "sktsrvx.hxx"
#endif /* SKTSRVX_HXX */

#ifndef SKTSRVX_IXX
#include "sktsrvx.ixx"
#endif /* SKTSRVX_IXX */

#ifndef SKTSRVP_HXX
#include "sktsrvp.hxx"
#endif /* SKTSRVP_HXX */

#ifndef SKTSRVP_IXX
#include "sktsrvp.ixx"
#endif /* SKTSRVP_IXX */


#ifndef GCHOOKSX_HXX
#include "gchooksx.hxx"
#endif /* GCHOOKSX_HXX */

#ifndef NXCVRX_HXX
#include "nxcvrx.hxx"
#endif /* NXCVRX_HXX */

#ifndef PROLSTNX_HXX
#include "prolstnx.hxx"
#endif /* PROLSTNX_HXX */

#ifndef SETX_HXX
#include "setx.hxx"
#endif /* SETX_HXX */

#ifndef STEPPERX_HXX
#include "stepperx.hxx"
#endif /* STEPPERX_HXX */




/* ************************************************************************ *
 * 
 *                    Class FDListener 
 *
 * ************************************************************************ */



/* Initializers for FDListener */


BEGIN_INIT_TIME(FDListener,initTimeNonInherited) {
	
#ifdef unix
	signal(SIGPIPE, SIG_IGN);
#endif

	
} END_INIT_TIME(FDListener,initTimeNonInherited);


/* exceptions: exceptions */



/* Initializers for FDListener */



/* This is the superclass for Listeners that use Berkeley UNIX sockets. */


/* accessing */


int FDListener::descriptor (){
	return myFD;
}
/* creation */


FDListener::FDListener () {
	
	myFD = (int) Int32Zero;
	
}


void FDListener::destruct (){
	
	close (myFD);
	
	this->ServerChunk::destruct();
}


void FDListener::registerFor (int anFD){
	myFD = anFD;
	CloseExecutor::registerHolder(this, anFD);
	ServerLoop::introduceChunk(this);
}



/* ************************************************************************ *
 * 
 *                    Class IPRendezvousListener 
 *
 * ************************************************************************ */


/* creation */


RPTR(FDListener) IPRendezvousListener::make (UInt32 anAddress){
	RETURN_CONSTRUCT(IPRendezvousListener,(anAddress, tcsj));
}
/* An IPRendezvousListener binds to a known rendezvous socket address.
	Its handleInput method accepts connection on this socket and sets up 
a FEBE connection
	on the spawned socket, including a IPConnectionListener. */


/* hooks: */


void IPRendezvousListener::restartIPRendezvous (APTR(Rcvr) /* rcvr *//* = NULL*/){
	int aSocket;
	
	
	
#ifdef NETMNG
#define SOCKA_SIZE sizeof(struct sockaddr)
	struct	sockaddr * sockName = (struct sockaddr *)falloc(SOCKA_SIZE);	
#else
#define SOCKA_SIZE sizeof(struct sockaddr_in)
	struct	sockaddr_in * sockName = (struct sockaddr_in *)falloc(SOCKA_SIZE);
#endif	
#ifdef UndeFIned_FALSE
#define SOCKA_SIZE sizeof(struct sockaddr)
	struct	sockaddr * sockName = (struct sockaddr *)falloc(SOCKA_SIZE);
#endif
#ifdef GNU
#define SOCK_CAST 
#else
#define SOCK_CAST (sockaddr *)
#endif

	sockName->sin_family = AF_INET;
	sockName->sin_port = htons((unsigned short)myAddress);
	sockName->sin_addr.s_addr = INADDR_ANY;
	
	aSocket = socket (PF_INET, SOCK_STREAM, IPPROTO_TCP);
	if (aSocket < 0) {
		BLAST(CANT_OPEN_RENDEZVOUS_SOCKET);
	}

	if (bind ( aSocket, SOCK_CAST sockName, SOCKA_SIZE) < 0) {

		BLAST(CANT_BIND_RENDEZVOUS_SOCKET);
	}
	if (listen (aSocket, 5) < 0) {
		BLAST(SOCKET_LISTEN_FAILED);
	}

	
	this->registerFor(aSocket);
}
/* creation */


IPRendezvousListener::IPRendezvousListener (UInt32 anAddress, TCSJ) {
	myAddress = anAddress;
	this->restartIPRendezvous(NULL);
}
/* accessing */


BooleanVar IPRendezvousListener::execute (){
	/* A client is trying to connect to the rendezvous socket.
	Accept the connection and spawn an IPconnectionListener for them.
	NOTE: in smalltalk (only) it is not guarnteed that there is 
	anyone there.
	so we do a non blocking operation and return quietly if there isn't */
	
	int newSocket;
	
	
	CurrentChunk = this;
	
	
#ifdef GNU
	sockaddr_in fromAddr;
#else
	sockaddr fromAddr;
#endif
	int fromAddrLen = sizeof fromAddr;
#ifdef NETMNG
	newSocket = accept (this->descriptor(), &fromAddr, &fromAddrLen);
#else
	newSocket = accept (this->descriptor(), (sockaddr*)&fromAddr, &fromAddrLen);
#endif
	if (newSocket < 0) {
		CurrentChunk = NULL;
		BLAST(ACCEPT_FAILURE_ON_RENDEZVOUS_SOCKET);
	}

	
	{
		INSTALL_SHIELD(ex);
		SHIELD_UP_BEGIN(ex, SOCKET_ERRSFilter) {
			/*cerr << &PROBLEM(ex);*/
			
			operator<<(cerr,(Problem *)&PROBLEM(ex));
			
			cerr << " Connection aborted.\n";
			CurrentChunk = NULL;
			return FALSE;
		} SHIELD_UP_END(ex);
		IPPromiseListener::make (newSocket);
	}
	CurrentChunk = NULL;
	return FALSE;
}


BooleanVar IPRendezvousListener::shouldBeReady (){
	/* since this is not really a connection it is always OK */
	return TRUE;
}



/* ************************************************************************ *
 * 
 *                    Class SelectServerLoop 
 *
 * ************************************************************************ */


/* creation */


RPTR(Thunk) SelectServerLoop::make (){
	RETURN_CONSTRUCT(SelectServerLoop,());
}
/* This is a ServerLoop designed specifically for Berkeley Sockets.  
It allows socket listeners to be registered and it dispatches among 
them based on a select() call */


/* creation */


SelectServerLoop::SelectServerLoop () {
	
#ifndef HIGHC
	FD_ZERO(&myFDSet);
#endif
	
}
/* execution */


void SelectServerLoop::scheduleChunks (){
	/* Schedule any chunks that have become active. */
	
	
	
	
#ifdef unix
	signal (SIGPIPE, SIG_IGN);
#endif
	
static	 fd_set readfds = myFDSet;
static	 fd_set exceptfds = myFDSet;
#if defined(unix) && ! defined(__sgi)
	int maxFDs = getdtablesize();
#else
	int maxFDs = FD_SETSIZE;
#endif /* unix */
	int numReady;
	readfds =exceptfds = myFDSet;
	if (this->activeChunks ()->isEmpty ()) {
		numReady = select (maxFDs-1, &readfds, NULL, &exceptfds, NULL);
	} else {
		/* timeout immediately so active Chunks can execute */
		timeval zero;
		zero.tv_sec = 0;
		zero.tv_usec = 0;
		numReady = select (maxFDs-1, &readfds, NULL, &exceptfds, &zero);
	}
	if (numReady <= 0 ) {
#ifdef WIN32
		if (numReady == 0 || errno == WSAEINTR) {
#else
		if (numReady == 0 || errno == EINTR) {
#endif /* WIN32 */
			return;
		}
		BLAST(SELECT_FAILED);
	}
	BEGIN_FOR_EACH(FDListener, aListener, (ServerLoop::chunks()->stepper())) {
		if (FD_ISSET(aListener->descriptor(), &exceptfds)) {
			ServerLoop::chunks()->remove(aListener);
			aListener->destroy ();
			if (--numReady <= 0)
				break;
		} else if (FD_ISSET(aListener->descriptor(), &readfds)) {
			if (aListener->shouldBeReady ()) {
				this->activeChunks()->store(aListener);
			} else {
				ServerLoop::chunks()->remove(aListener);
				aListener->destroy ();
			}
			if (--numReady <= 0)
				break;
		}
	} END_FOR_EACH;

	
	
}
/* protected: accessing */


void SelectServerLoop::deregisterChunk (APTR(ServerChunk) aChunk){
	this->ServerLoop::deregisterChunk(aChunk);
	
	FD_CLR(CAST(FDListener,aChunk)->descriptor(), &myFDSet);

	
}


void SelectServerLoop::registerChunk (APTR(ServerChunk) aChunk){
	this->ServerLoop::registerChunk(aChunk);
	
	FD_SET(CAST(FDListener,aChunk)->descriptor(), &myFDSet);

	
}

#ifndef SKTSRVX_SXX
#include "sktsrvx.sxx"
#endif /* SKTSRVX_SXX */


#ifndef SKTSRVP_SXX
#include "sktsrvp.sxx"
#endif /* SKTSRVP_SXX */



#endif /* SKTSRVX_CXX */

