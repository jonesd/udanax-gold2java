/* Copyright Xanadu Operating Company.  All Rights Reserved. */

/******************************************************************************
*                                                                            *
* The information contained herein is confidential, proprietary to Xanadu    *
* Operating Company, and considered a trade secret as defined in section     * 
* 499C of the penal code of the State of California.  Use of this information* 
* by anyone other than authorized employees of Xanadu is granted             *
* only under a  written non-disclosure agreement, expressly prescribing      * 
* the scope and  manner of such use.                                         *
*                                                                            *
***************************************************************************
Output from Objectworks for Smalltalk-80(tm), Version 2.5 of 29 July 1989
*/

#ifndef SCHUNKT_CXX
#define SCHUNKT_CXX


#ifndef CHOOSEX_HXX
#include "choosex.hxx"
#endif /* CHOOSEX_HXX */

#ifndef SCHUNKT_HXX
#include "schunkt.hxx"
#endif /* SCHUNKT_HXX */

#ifndef SCHUNKT_IXX
#include "schunkt.ixx"
#endif /* SCHUNKT_IXX */




/* ************************************************************************ *
 * 
 *                    Class TestChunk 
 *
 * ************************************************************************ */


/* accessing */


void TestChunk::processInput (){
	
}
/* execute */


BooleanVar TestChunk::execute (){
	return FALSE;
}

	/* automatic 0-argument constructor */
TestChunk::TestChunk() {}

#ifndef SCHUNKT_SXX
#include "schunkt.sxx"
#endif /* SCHUNKT_SXX */



#endif /* SCHUNKT_CXX */

