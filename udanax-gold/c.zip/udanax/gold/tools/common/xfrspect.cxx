/* Copyright Xanadu Operating Company.  All Rights Reserved. */

/******************************************************************************
*                                                                            *
* The information contained herein is confidential, proprietary to Xanadu    *
* Operating Company, and considered a trade secret as defined in section     * 
* 499C of the penal code of the State of California.  Use of this information* 
* by anyone other than authorized employees of Xanadu is granted             *
* only under a  written non-disclosure agreement, expressly prescribing      * 
* the scope and  manner of such use.                                         *
*                                                                            *
***************************************************************************
Output from Objectworks for Smalltalk-80(tm), Version 2.5 of 29 July 1989
*/

#ifndef XFRSPECT_CXX
#define XFRSPECT_CXX


#ifndef CHOOSEX_HXX
#include "choosex.hxx"
#endif /* CHOOSEX_HXX */

#ifndef XFRSPECT_HXX
#include "xfrspect.hxx"
#endif /* XFRSPECT_HXX */

#ifndef XFRSPECT_IXX
#include "xfrspect.ixx"
#endif /* XFRSPECT_IXX */


#ifndef XFRSPECT_SXX
#include "xfrspect.sxx"
#endif /* XFRSPECT_SXX */



#endif /* XFRSPECT_CXX */

