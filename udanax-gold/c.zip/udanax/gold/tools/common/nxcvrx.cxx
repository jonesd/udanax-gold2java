/* Copyright Xanadu Operating Company.  All Rights Reserved. */

/******************************************************************************
*                                                                            *
* The information contained herein is confidential, proprietary to Xanadu    *
* Operating Company, and considered a trade secret as defined in section     * 
* 499C of the penal code of the State of California.  Use of this information* 
* by anyone other than authorized employees of Xanadu is granted             *
* only under a  written non-disclosure agreement, expressly prescribing      * 
* the scope and  manner of such use.                                         *
*                                                                            *
***************************************************************************
Output from Objectworks for Smalltalk-80(tm), Version 2.5 of 29 July 1989
*/

#ifndef NXCVRX_CXX
#define NXCVRX_CXX


#ifndef CHOOSEX_HXX
#include "choosex.hxx"
#endif /* CHOOSEX_HXX */

#ifndef NXCVRX_HXX
#include "nxcvrx.hxx"
#endif /* NXCVRX_HXX */

#ifndef NXCVRX_IXX
#include "nxcvrx.ixx"
#endif /* NXCVRX_IXX */


#ifndef PARRAYX_HXX
#include "parrayx.hxx"
#endif /* PARRAYX_HXX */




/* ************************************************************************ *
 * 
 *                    Class Rcvr 
 *
 * ************************************************************************ */


/* receiving */

	/* automatic 0-argument constructor */
Rcvr::Rcvr() {}



/* ************************************************************************ *
 * 
 *                    Class Xmtr 
 *
 * ************************************************************************ */


/* sending */

	/* automatic 0-argument constructor */
Xmtr::Xmtr() {}

#ifndef NXCVRX_SXX
#include "nxcvrx.sxx"
#endif /* NXCVRX_SXX */



#endif /* NXCVRX_CXX */

