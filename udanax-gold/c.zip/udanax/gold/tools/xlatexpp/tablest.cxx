/* Copyright Xanadu Operating Company.  All Rights Reserved. */

/******************************************************************************
*                                                                            *
* The information contained herein is confidential, proprietary to Xanadu    *
* Operating Company, and considered a trade secret as defined in section     * 
* 499C of the penal code of the State of California.  Use of this information* 
* by anyone other than authorized employees of Xanadu is granted             *
* only under a  written non-disclosure agreement, expressly prescribing      * 
* the scope and  manner of such use.                                         *
*                                                                            *
***************************************************************************
Output from Objectworks for Smalltalk-80(tm), Version 2.5 of 29 July 1989
*/

#ifndef TABLEST_CXX
#define TABLEST_CXX


#ifndef CHOOSEX_HXX
#include "choosex.hxx"
#endif /* CHOOSEX_HXX */

#ifndef TABLEST_HXX
#include "tablest.hxx"
#endif /* TABLEST_HXX */

#ifndef TABLEST_IXX
#include "tablest.ixx"
#endif /* TABLEST_IXX */


#ifndef TABLEST_SXX
#include "tablest.sxx"
#endif /* TABLEST_SXX */



#endif /* TABLEST_CXX */

