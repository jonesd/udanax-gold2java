/* Copyright Xanadu Operating Company.  All Rights Reserved. */

/******************************************************************************
*                                                                            *
* The information contained herein is confidential, proprietary to Xanadu    *
* Operating Company, and considered a trade secret as defined in section     * 
* 499C of the penal code of the State of California.  Use of this information* 
* by anyone other than authorized employees of Xanadu is granted             *
* only under a  written non-disclosure agreement, expressly prescribing      * 
* the scope and  manner of such use.                                         *
*                                                                            *
***************************************************************************
Output from Objectworks for Smalltalk-80(tm), Version 2.5 of 29 July 1989
*/

#ifndef ARRAYT_CXX
#define ARRAYT_CXX


#ifndef CHOOSEX_HXX
#include "choosex.hxx"
#endif /* CHOOSEX_HXX */

#ifndef ARRAYT_HXX
#include "arrayt.hxx"
#endif /* ARRAYT_HXX */

#ifndef ARRAYT_IXX
#include "arrayt.ixx"
#endif /* ARRAYT_IXX */


#ifndef ARRAYT_SXX
#include "arrayt.sxx"
#endif /* ARRAYT_SXX */



#endif /* ARRAYT_CXX */

