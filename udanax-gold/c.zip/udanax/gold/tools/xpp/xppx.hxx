/*
      (C) Copyright 1988, 89 by Xanadu Operating Company, All Rights Reserved.

******************************************************************************
*                                                                            *
* The information contained herein is confidential, proprietary to Xanadu    *
* Operating Company, and considered a trade secret as defined in section     * 
* 499C of the penal code of the State of California.  Use of this information* 
* by anyone other than authorized employees of Xanadu is granted             *
* only under a  written non-disclosure agreement, expressly prescribing      * 
* the scope and  manner of such use.                                         *
*                                                                            *
**************************************************************************** */

#ifndef XPPX_HXX
#define XPPX_HXX

static char xppx_hxx_rcsid[] = "$Id: xppx.hxx,v 1.1.1.1 2001/07/28 21:24:54 jrush Exp $";

#include "ccompatc.h"
#include "xcompatx.hxx"
#include "bombx.hxx"
#include "initx.hxx"
#include "fluidx.hxx"
#include "tofux.hxx"
#include "intvarx.hxx"
#include "parrayx.hxx"
#include "sema4x.hxx"
// #include "mortalx.hxx"
#include "choosex.hxx"

/* From xlatexpp directory */
#include "stepperx.hxx"
#include "setx.hxx"

#include "spacex.hxx"
#include "integerx.hxx"
#include "hspacex.hxx"

#include "tablesx.hxx"
#include "inttabx.hxx"
#include "arrayx.hxx"
#include "hashtabx.hxx"

#endif /* XPPX_HXX */
