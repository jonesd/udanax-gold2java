void doStaticInit () {
  __sti__bombx_cxx_bombc_h_version_ ();
  __sti__cbombx_cxx_bombc_h_version_ ();
}
void doStaticTerm () {
  __std__bombx_cxx_bombc_h_version_ ();
  __std__cbombx_cxx_bombc_h_version_ ();
}
