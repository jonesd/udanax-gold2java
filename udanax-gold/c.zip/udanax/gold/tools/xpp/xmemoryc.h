#ifndef XMEMORYC_H
#define XMEMORYC_H

static char xmemoryc_h_rcsid[] = "$Id: xmemoryc.h,v 1.1.1.1 2001/07/28 21:24:54 jrush Exp $";

#include "ccompatc.h"

C_DECL_BEGIN
	void copyWords (UInt32 * dest, UInt32 * src, UInt32 numWords);
	void zeroWords (UInt32 * dest, UInt32 numWords);
C_DECL_END

#endif /* xmemoryc.h */
