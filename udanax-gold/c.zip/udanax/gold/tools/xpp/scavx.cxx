/* Copyright (C) 1993, Memex, Inc., All Rights Reserved */
/*
        WARNING: This module contains pointer arithmetic that may not
        be portable.

        Documentation note:  most of the documentation in this module
        was added by hkh and reg while we were completing and debugging
        it from mid to late 1994.  
 

*/

/* $Id: scavx.cxx,v 1.1.1.1 2001/07/28 21:24:54 jrush Exp $ */
int n;
#include "scavx.hxx"
#include "scavp.hxx"

#include "scavx.ixx"
#include "scavp.ixx"

#include "parrayx.hxx"
#include "wparrayx.hxx"

#include <assert.h>
#ifndef GNU
#include <osfcn.h>
#endif
#ifdef GNUSUN
#define sun 1
#endif
#if sun
#include <sys/mman.h>
#endif /* sun */
#define PROTECT_FREE_PAGES 1

int DisableOutPointers = 1;
Int32 DisableGC = 0;
Int32 ProtectFree = 1;
Int32 RecycleOld = 1;
// Int32 CycleCount = 0;

#define SANITY_CHECK {if(!(isScavengeable(this) && pageOf(this)==this)){BLAST(SanityViolation);}}

/*
        Class Heaplet

        The heap of contained Heapers starts at the bottom of the page
        after the page description.  The sets of in and out pointers
        grow downward from the end of the page, relocating as needed.

      The above is not true, heapers and in/out sets grow from the
      bottom of the page.  hkh 12/19/94
        
        The page is full when the heap reaches the pointer sets.
        Since stores to the pointer sets must never fail, an overflow
        mechanism is used.  Things should be tuned to avoid this.
        (the page layout is understandable--but wrong)  hkh */

// Note for newbies!  Operator new is overridden in xunewx.cxx
// There it calls falloc which is in allocx.cxx.  Thus, the 32k
// heapletSets are obtained there and not by system malloc. hkh

HeapletManager * Heaplet::PagePool = NULL;
HeapletSet *     Heaplet::Old = NULL;

/* fluid-like class variables */
Heaplet *       Heaplet::NewPage = NULL;
Heaplet *       Heaplet::AltNewPage = NULL;
HeapletSet *    Heaplet::Current = NULL;
HeapletSet *    Heaplet::NextCurrent = NULL;
HeapletSet *    Heaplet::CurrentDrainSet = NULL;
Int32 Heaplet::TenureAge = 20;  // a random number for later tuning (was 20)
Int32 Heaplet::NumberOfPagesSinceLastCollect = 0;

/* If storing into Old space or a global variable:
    Updates the remembered sets for the pages referenced
    by both the old and new value of the pointer being assigned.

 MORE detail needed here!  hkh

    The container argument is a pointer within the page holding
    the object responsible for holding the pointer.  This is
    necessary as the PrimArray classes keep their storage outside
    of the Heaplets. (True, see parrayx, but I am not sure this is
    very relavent. hkh) MORE the use of "page" is misleading, since
    it is used to test for storage *outside* of the heaplet pages.*/
 
/*INLINE*/ void Heaplet::checkedStore (Heaper** ptr, 
                                       Heaper* newValue,
                                       void* container)
{
    /* All of the other checking methods will only be called after
       the scavenger data structures are set up. Does this mean
       that this one is called before the structure has been set
       up?  hkh   MORE--the test on Current takes the bypass only
       before Current is initializeds.

       Second point:  checkedStore overloads the = (equal) asignment
       operator.  This gets really confusing in the debugger since
       there is no indication as to how program control got there.

       In English, the next line means that Current is not null, and
       that the location of the pointer which points at the heaper (i.e.
       object) is either in old, or is outside of the heaplet area.
       If these conditions are met, then call actual. . .because this
       is one of those locations where we have to keep a note that it 
       is pointing into the heaplet (moving memory) area.  The next 
       two routines have just about identical function.*/

    if (Current && (Old->contains (container) || !isScavengeable(container))) {
        actualCheckedStore (ptr, newValue, container);
    }
    *ptr = newValue;  //checked or not, correct pointer (may be NULL)
}

/*INLINE*/ void Heaplet::checkedArrayStore (PtrArray* array,
                                            Heaper** ptr, 
                                            Heaper* newValue,
                                            Int32 index)
{
    if (Old->contains (array)) {
        actualCheckedArrayStore (array, ptr, newValue, index);
    } else {
        ObjHead * head = ((ObjHead*)array) - 1;
        if (head->age == OLD_AGE) {
            BLAST(SanityViolation);
        }
    }
    *ptr = newValue;
}

/*INLINE*/ void Heaplet::checkedWeakStore (WeakPtrArray* array,
                                           Heaper** ptr, 
                                           Heaper* newValue,
                                           Int32 index)
{
    if (Old->contains (array)) {
        actualCheckedWeakStore (array, ptr, newValue, index);
    } else {
        ObjHead * head = ((ObjHead*)array) - 1;
        if (head->age == OLD_AGE) {
            BLAST(SanityViolation);
        }
    }
    *ptr = newValue;
}

/* The out-of-line work function for initialization -- currently 12/94 32k each*/
void Heaplet::actualInitialize () {
    PagePool    = HeapletManager::make ();
    Current     = HeapletSet::make (MAXPAGES);
    Old         = HeapletSet::make (MAXPAGES);
    NextCurrent = HeapletSet::make (MAXPAGES);

    NewPage = PagePool->take ();
    NumberOfPagesSinceLastCollect++;
    Current->introduce (NewPage);
}

void Heaplet::tenureAll () {
    Int32 save = TenureAge;
    TenureAge = 0;
    garbageCollect ();
    TenureAge = save;
}

Int32 Heaplet::setTenureAge (Int32 age) {
    Int32 old = TenureAge;
    TenureAge = age;
    return old;
}

/* Acquire storage for a new Heaper in new space. */
void * Heaplet::allocate (size_t nBytes) {
    Int32 nInt32s = (nBytes + 3) / sizeof(Int32) + sizeof(ObjHead)/sizeof(Int32); // extra for age and size
    ObjHead * result = allocateWords (nInt32s);
    return result + 1; 
}

/* Acquire storage for a new Heaper in new space. */
ObjHead * Heaplet::allocateWords (Int32 nInt32s) {
    ObjHead * head = NewPage->fetchAlloc (nInt32s);
    if (!head) {
        NewPage = PagePool->take ();  // returns or BLASTS
        NumberOfPagesSinceLastCollect++;
        Current->introduce (NewPage);
        head = NewPage->fetchAlloc (nInt32s);
    }
    return head;
}

/* Acquire storage for a new Heaper in old space. */
ObjHead * Heaplet::allocateOldWords (Int32 nInt32s) {
    if (AltNewPage == NULL) {
        AltNewPage = PagePool->take ();
        Old->introduce (AltNewPage);
    }
    ObjHead * head = AltNewPage->fetchAlloc (nInt32s);
    if (!head) {
        AltNewPage = PagePool->take ();  // returns or BLASTS
        Old->introduce (AltNewPage);
        head = AltNewPage->fetchAlloc (nInt32s);
    }
    return head;
}
//#include "entx.hxx"
//#include "granmapx.hxx"

/* Perform a scavenge over Current */
void Heaplet::garbageCollect () {
    /* NextCurrent is empty from last collection */
    if (DisableGC) {
        return;
    }
    Heaplet* target;
    HeapletSetStepper* stepper;

void checkthefuckingbranches();
    EstateRecorder::reset ();

    /* First we scavenge new pages--by stepping down the bits which are set
       in CurentDrainSet.  Each of these bits is translated to being a 
       heaplet address and passed back by stepper->fetch (in scavp.ixx)
       After stepping through each heaplet in the CDS, the CDS heaplets
       are all returned to the PagePool.  The inside references to Old
       are not understood at this point 11/25/94 hkh

       Major reorganization about 12/10/94.  You want to process each
       type of rememberSet before going on to the others.  This is necessary 
       since the WPAs need to be checked last.  (since objects they point
       to may have been migrated because they are also pointed at by objects
       which force migration, and we need to update the WPAs to point at
       such objects.  hkh 12/19/94 */

    //AltNewPage = NULL;
//walkBranch((CurrentGrandMap.fluidGet()->myEnt->fulltrace->myRoot->myBranch));
 //((BranchDescription * )0x593764)->walkBranch();

    CurrentDrainSet = Current;
    Current = NextCurrent;
checkthefuckingbranches();
    NewPage = PagePool->take ();
    Current->introduce (NewPage);   // this is ok hkh 12/19/94

    stepper = CurrentDrainSet->stepper ();
    while ((target = stepper->fetch ())) {
        if (target->myRememberSet) {
            target->myRememberSet->scavengeNew (CurrentDrainSet);
        }
        stepper->step ();
    }
    delete stepper;

    stepper = CurrentDrainSet->stepper ();
    while ((target = stepper->fetch ())) {
        if (target->myArrayRememberSet) {
            target->myArrayRememberSet->scavengeNew (CurrentDrainSet);
        }
        stepper->step ();
    }
    delete stepper;

    stepper = CurrentDrainSet->stepper ();
    while ((target = stepper->fetch ())) {
        if (target->myWeakReferenceSet) {
            target->myWeakReferenceSet->executeWeakly ();
        }
        stepper->step ();
    }
    delete stepper;

    stepper = CurrentDrainSet->stepper ();
    while ((target = stepper->fetch ())) {
        if (target->myPtrArraySet) {
            target->myPtrArraySet->cleanup ();
        }
        stepper->step ();
    }
    delete stepper;

    stepper = CurrentDrainSet->stepper ();
    while ((target = stepper->fetch ())) {
        if (target->myOutPointerSet) {
            BLAST(CLEANUP_OF_OLD_NOT_YET_IMPLEMENTED_);         // we implement code that uses this
            target->myOutPointerSet->dropInto (Old, Current, CurrentDrainSet); // this removes any deleted
            //old pages, this implementation should'nt 
// have any yet so I've added a BLAST till
        }
        stepper->step ();

    }
    delete stepper;

//  Lastly, we need to clean up the heaplet sets (bits which represent pages)
//  before exiting the GC code.  The lines with old in them make no sense
//  because there is no way the CDS can contain a old page.  hkh  12/19/94 

    EstateRecorder::handleAllEstates ();  

// This line must be here because it 
// references memory in the current drain set--if we release and protect this
// area before the call, things crash.  Also, the vtables of the objects must
// be intact because they are used by the executor code (even though they point
// to null.  This *requires* the use of extended headers or some other mechanism
// (checking for the object being forwarded) to keep from trying to jump through
// a stomped on vtable.  hkh 12/22/95
    
    while ((target = CurrentDrainSet->take ())) {
//      if (Old->contains (target)) {// this loop is part of scavengeOld notyet implemented
//          Old->remove (target);
//      }
        PagePool->release (target);
    }

    NextCurrent = CurrentDrainSet;      // which is now empty

    //AltNewPage = NULL;
    CurrentDrainSet = NULL;
//
//  I don`t think this makes sense.  There is very likely a page still
//  open which was only partly filled by the process of moving stuff out
//  of the CDS, if not, getting a new page when out of space is automatic. 

//    NewPage = PagePool->take ();
//    Current->introduce (NewPage);

checkthefuckingbranches();
}

/* Return TRUE if ptr is in a scavengeable page */
BooleanVar Heaplet::isScavengeable (void * ptr) {
    return PagePool->contains (ptr);
}

/* Updates the remembered sets for the pages referenced
    by both the old and new value of the pointer being assigned.
    The container argument is a pointer within the page holding
    the object responsible for holding the pointer.  This is
    necessary as the PrimArray classes keep their storage outside
    of the Heaplets.

I think
the *meaning* of the above is that a CPV which is pointing to an
object within the heaplet space can itself be an entry in a 
PrimArray kind of thing.  So....the "container" object with its
pointers to storage can be a long way from the actual CPV. 

    More--see the notes on checkedStore to see how we got here.
  
        INLINE void   CheckedPtrVar::store(Heaper * p) {
        Heaplet::checkedStore (&this->value, p, this);   }

    ** ptr is the address of the location which points to the old
    place (or null)  * container is a pointer to the old location (never null)
    storedPage is the memory area (rounded off by 14bits) in which
    "this" (not a local) can be found. 

    pageOf gets the two pages, one from *ptr and the other from newValue
    If not equal, forget from old page.*/
void Heaplet::actualCheckedStore (Heaper** ptr, 
                                  Heaper* newValue,
                                  void* container)
{
    Heaplet * storedPage = pageOf (container);
    BooleanVar containerIsOld = Old->contains (storedPage);
    if (containerIsOld || !isScavengeable (storedPage)) {
        Heaplet * oldPage = pageOf (*ptr);
        Heaplet * newPage = pageOf (newValue);
        if (oldPage != newPage) {
            if (oldPage != storedPage && isScavengeable (oldPage)) {
                oldPage->forget (ptr);


              if (Old->contains (oldPage)) {// for NotYetImplimented scavengeOld
                  if (containerIsOld && storedPage != oldPage) {
                      storedPage->removeOutPointer (oldPage);
                  }
//                  	Current->store (oldPage);//zzzz reg dec5 1995
              }


            }
            if (newPage != storedPage && isScavengeable (newPage)) {
                newPage->remember (ptr);
                if (containerIsOld) {
                    storedPage->addOutPointer (newPage);
                }
            }
        }
    }
}

/* Updates the remembered sets for the pages referenced
    by both the old and new value of the pointer being assigned
    to a PtrArray. */
void Heaplet::actualCheckedArrayStore (PtrArray* array,
                                       Heaper** ptr, 
                                       Heaper* newValue,
                                       Int32 index)
{
    Heaplet * storedPage = pageOf (array);
    BooleanVar containerIsOld = Old->contains (storedPage);
    if (containerIsOld) {
        Heaplet * oldPage = pageOf (*ptr);
        Heaplet * newPage = pageOf (newValue);
        if (oldPage != newPage) {
            if (isScavengeable (oldPage)) {
                oldPage->forgetArray (array, index);
              if (Old->contains (oldPage)) {// for NotYetImplimented scavengeOld 
                  if (containerIsOld && storedPage != oldPage) {
                      storedPage->removeOutPointer (oldPage);
                  }
//                  Current->store (oldPage);//zzzz reg dec5 1995
              }
            }
            if (newPage != storedPage && isScavengeable (newPage)) {
                newPage->rememberArray (array, index, NULL);
                if (containerIsOld) {
                    storedPage->addOutPointer (newPage);
                }
            }
        }
    }
}

/* Updates the remembered sets for the pages referenced
    by both the old and new value of the pointer being assigned
    to a WeakPtrArray. */
void Heaplet::actualCheckedWeakStore (WeakPtrArray* array,
                                      Heaper** ptr, 
                                      Heaper* newValue,
                                      Int32 index)
{
    Heaplet * oldPage = pageOf (*ptr);
    Heaplet * newPage = pageOf (newValue);

    if (newPage != oldPage) {
        Heaplet * storedPage = pageOf (array);
        if (*ptr && isScavengeable(oldPage)) {
            oldPage->forgetWeak (array, index);
            storedPage->removeOutPointer (oldPage);
        }

        if (isScavengeable(newValue)) {
            newPage->rememberWeak (array, index,NULL);  /* zzz reg nov 10 1994 added null to get right number of parameters */
            storedPage->addOutPointer (newPage);
        }
    }
    *ptr = newValue;
}

/* Removes the pointer from the remembered set of the page it
    references.  Called by ~CheckedPtrVar during become.
    The container argument is a pointer within the page holding
    the object responsible for holding the pointer.  This is
    necessary as the PrimArray classes keep their storage outside
    of the Heaplets. */
void Heaplet::forgetPointer (Heaper** ptr, void* container) {
    if (*ptr && (Old->contains(ptr) || Current->contains(*ptr))) {
        Heaplet * storedPage = pageOf (container);
        Heaplet * oldPage = pageOf (*ptr);
        if (pageOf(ptr) != oldPage) {
            oldPage->forget (ptr);
            if (PagePool->contains(container)) {
                storedPage->removeOutPointer (oldPage);
            }
        }
    }
}

/* Move the object to a new page if it''s still here.
   Returns the new address. */
Heaper * Heaplet::forward (Heaper* obj) {
    /* Uses the magic cookie age to indicate a forwarder.
       The first word of a forwarder is the new address.
    */
if(!obj ||!isScavengeable(obj)){
  return obj;
}
    ObjHead * head = ((ObjHead*) obj) - 1;
    if (head->size == 0) {
        BLAST(SanityViolation); // !!!! tmp debug
    }
    Int32 age = head->age;
    if (age == FORWARDER_FLAG) {
        return  heaperForwardedTo ( obj );
    }
    if (!CurrentDrainSet->contains(obj)) {
        return obj;  // includes NULL
    }
    if (age != OLD_AGE) {
        if (++age >= TenureAge) {
            age = OLD_AGE;
        }
    }else{
        abort();  // An object in old should never get this far, since it should have
                  // been returned because it is not in the CDS, and control should have
                  // returned after the very first test!!


//  note that forward and migrate don't have any conditions to terminate 
//  the recureions at a thing in Old, I think they should!

//          BLAST(HKHTHINKSTHISSHOULDNEERHAPPEN);
    }
    /* Move object and construct forwarder */
    ObjHead * newHead;
    if (age != OLD_AGE) {
        newHead = allocateWords ((unsigned int)head->size);
    } else {
        newHead = allocateOldWords ((unsigned int)head->size);
    }
    if (((unsigned int)head->size) * sizeof(Int32) > PAGESIZE)	{
        BLAST(SanityViolation);         // !!!! tmp debug
    }

//  Expounding--MEMMOVE copies the object from the old to the new location.
//  Next line generation stamps the object with age (incremented above)
//  Line after that generates nobj, a pointer to the new object.  Next
//  stamps the *old* object as forwarded, and stomps on the first word of
//  the old object (vtable) with the address of the new object.  Then (often
//  recursively) migrate is called for the particular kind of object 
//  involved.  What gets passed to migrate is a pointer to the old
//  object and a T/F indication of old status.

    MEMMOVE(newHead, head, ((unsigned int)head->size) * sizeof(Int32))	;
    newHead->age = age;
    Heaper * nobj = (Heaper*) (newHead + 1);
    head->age = FORWARDER_FLAG;
    assignForwardedTo(obj,nobj) ;
    nobj->migrate (obj, newHead->age == OLD_AGE);
    return nobj;
}

/* Return NULL if obj is in CurrentDrainSet and not forwarded,
   otherwise return the new location. */
Heaper * Heaplet::forwardOrNULL (Heaper * obj) {
    if (objIsForwarded(obj)) {
        return heaperForwardedTo ( obj );
    } else {
    if (!CurrentDrainSet->contains (obj)) {
        return obj;
    }
        return NULL;
    }
}

// Input to this module are two ** pointers.  First, pull in the contents
// of the first of them, test for NULL.  If not NULL, then test for it
// being in the scavenable memory area, and take the upper 14 bits into
// op.  Inside the call to forward nobj can come back same as obj if the
// object in question is outside the CDS.  In such a case, the *object*
// has not been moved, but the thing pointing at it has been.  In such 
// a case, we need to change the rememberSet.  The test may have been
// wrong in the first pass of changeRemember.  







void Heaplet::forwardToOld (Heaper ** oldPtr, Heaper ** newPtr) {
    Heaper * obj = *oldPtr;
    if (obj) {
        if (isScavengeable (obj)) {
            Heaplet * op = pageOf (obj);
            Heaper * nobj = Heaplet::forward (obj);
            if (obj == nobj) {
                op->changeRemembered (oldPtr, newPtr);
            } else {
                *newPtr = nobj;
                if (op != pageOf (oldPtr)) {
                    op->forget (oldPtr);
                }
                Heaplet * np = pageOf (nobj);
                if (np != pageOf (newPtr)) {
                    np->remember (newPtr);
                }
            }
        }
    }
}


/* ================= start of instance methods ================= */

/* Attempt to allocate storage in this page. */
ObjHead * Heaplet::fetchAlloc (Int32 nInt32s) {
SANITY_CHECK
    if (nInt32s <= 0) {
        BLAST(SanityViolation); // !!!! tmp debug
    }
    Int32 * newEnd = myHighWaterMark + nInt32s;
    if (newEnd >= myLastWord) {
        return NULL;
    }
    ObjHead * result = (ObjHead*) myHighWaterMark;
    myHighWaterMark = newEnd;
    int * i;
    for(i = (int *)result ; ((void *)i) < ((void *)newEnd); i++){

        if( (*(int*)i) != 0){
                cerr << "stomping on mem \n" << result << "at " << __FILE__ << __LINE__ << " so watch out, in fetchAlloc ";
        }
    }

    result->age = 5;
    result->size = nInt32s;
    return result;
}

/* Allocate storage associated with this page, going into
   overflow if necessary.  This is used for small PrimArrays */
ObjHead * Heaplet::getWords (Int32 nInt32s) {
SANITY_CHECK
    ObjHead * result = this->fetchAlloc (nInt32s+sizeof(ObjHead)/sizeof(Int32));
    if (result) {
        return result + 1; 
    }
    if (!myOverflow) {
        myOverflow =  PagePool->take ();
    }
    return myOverflow->getWords (nInt32s);
}

/* Allocate storage associated with this page, going into
   overflow if necessary.  This is used for interpage
   reference recording that must not fail. */
ObjHead * Heaplet::getBytes (Int32 nBytes) {
SANITY_CHECK
    Int32 nInt32s = (nBytes + 3) / sizeof(Int32) + sizeof(ObjHead)/sizeof(Int32); // extra for age and size
    ObjHead * result = this->fetchAlloc (nInt32s);
    if (result) {
        return result + 1; 
    }
    if (!myOverflow) {
        myOverflow =  PagePool->take ();
    }
    return myOverflow->getBytes (nBytes);  // wastes a shift, but rarely used
}

/* Add a pointer to the remember set */
void Heaplet::remember (Heaper** ptr) {
SANITY_CHECK
    if (pageOf(ptr) == this) {
        BLAST(SanityViolation);         // !!!! tmp debug
    }
    if (!myRememberSet) {
        myRememberSet = PointerReferenceSet::make (this);
    }
    myRememberSet->remember (ptr);
}

/* Remove a pointer from the remember set */
void Heaplet::forget (Heaper** ptr) {
SANITY_CHECK
    if (pageOf(ptr) == this) {
        BLAST(SanityViolation);         // !!!! tmp debug
    }
    if (myRememberSet) {
        myRememberSet->forget (ptr);
    }
}

/* Change a pointer in the remember set.  Useful for migration */
void Heaplet::changeRemembered (Heaper** oldPtr, Heaper** newPtr) {
SANITY_CHECK
//    if (pageOf(oldPtr) != this || pageOf(newPtr) == this) {   // hkh
//      BLAST(SanityViolation);         // !!!! tmp debug
//    }
    if (myRememberSet) {
        myRememberSet->change (oldPtr, newPtr);
    }
}

/* Add a pointer to the array reference set */
void Heaplet::rememberArray (PtrArray* array, Int32 index,
                             PtrArray* oldArray) {
SANITY_CHECK
    if (!myArrayRememberSet) {
        myArrayRememberSet = ArrayReferenceSet::make (this);
    }
    myArrayRememberSet->remember (array, index, oldArray);
}

/* Remove a pointer from the array reference set */
void Heaplet::forgetArray (PtrArray* array, Int32 index) {
SANITY_CHECK
    if (myArrayRememberSet) {
        myArrayRememberSet->forget (array, index);
    }
}

/* Change an entry in the array reference set */
void Heaplet::changeArray (PtrArray* oldArray, PtrArray* newArray) {
SANITY_CHECK
    if (myArrayRememberSet) {
        myArrayRememberSet->change (oldArray, newArray);
    }
}

/* Add a pointer to the weak reference set */
void Heaplet::rememberWeak (WeakPtrArray* array, Int32 index,
                            WeakPtrArray* oldArray) {
SANITY_CHECK
    if (!myWeakReferenceSet) {
        myWeakReferenceSet = ArrayReferenceSet::make (this);
    }
    myWeakReferenceSet->remember (array, index, oldArray);
}

/* Remove a pointer from the weak array reference set */
void Heaplet::forgetWeak (WeakPtrArray* array, Int32 index) {
SANITY_CHECK
    if (myWeakReferenceSet) {
        myWeakReferenceSet->forget (array, index);
    }
}

/* Change an entry in the weak reference set */
void Heaplet::changeWeak (WeakPtrArray* oldArray, WeakPtrArray* newArray) {
SANITY_CHECK
    if (myWeakReferenceSet) {
        myWeakReferenceSet->change (oldArray, newArray);
    }
}

/* Remove all references from page from remember, array, and
   weak reference sets.  In the weak case this is to prevent
   bogus finalization if an object is collected after its
   referencing weak arrays go away. */
void Heaplet::forgetFromPage (Heaplet * page) {
SANITY_CHECK
    if (myRememberSet) {
        myRememberSet->forgetFromPage (page);
    }
    if (myArrayRememberSet) {
        myArrayRememberSet->forgetFromPage (page);
    }
    if (myWeakReferenceSet) {
        myWeakReferenceSet->forgetFromPage (page);
    }
}

/* Add an outward pointer. */
void Heaplet::addOutPointer (Heaplet* other) {
if(DisableOutPointers){return;}
SANITY_CHECK
    if (!myOutPointerSet) {
        myOutPointerSet = OutPointerSet::make (this);
    }
    myOutPointerSet->reference (other);
}

/* Remove an outward pointer. */
void Heaplet::removeOutPointer (Heaplet* other) {
if(DisableOutPointers){return;}
SANITY_CHECK
    if (myOutPointerSet) {
        myOutPointerSet->unreference (other, NULL);  // hkh arg number   
    }
}

/* Record that a PtrArray resides in this page. */
void Heaplet::registerPtrArray (PtrArray* array) {
SANITY_CHECK
    if (!myPtrArraySet) {
        myPtrArraySet = PtrArraySet::make (this);
    }
    myPtrArraySet->registerPtrArray (array);
}

/* Remove a PtrArray from this page. */
void Heaplet::unregisterPtrArray (PtrArray* array) {
SANITY_CHECK
    if (myPtrArraySet) {
        myPtrArraySet->unregisterPtrArray (array);
    }
}
/* Below, see .hxx, but myHeap is the 9th (last) 32 bit word into
the stuct which is "Head of Heaplet."  The next line gens
a pointer to the start of the page plus PAGESIZE hkh */

Heaplet::Heaplet () {
    myHighWaterMark = myHeap;
    myLastWord = (Int32*) ((char*) this + PAGESIZE);
    myOverflow = NULL;
    myRememberSet = NULL;
    myArrayRememberSet = NULL;
    myWeakReferenceSet = NULL;
    myOutPointerSet = NULL;
    myPtrArraySet = NULL;
}


/*
        Class HeapletManager

        Manages the pool of empty pages.

        It would be good for this to allocate pages so that freed
        pages remain free as long as possible to catch errors that
        access freed memory.
*/

HeapletManager * HeapletManager::make () {
    return new HeapletManager ();
}

/* disable access to pages memory */
void HeapletManager::protect (Heaplet * page) {
#if sun && PROTECT_FREE_PAGES
    if (ProtectFree) {
        mprotect((caddr_t)page, PAGESIZE, PROT_NONE);
    }
#endif
}

/* enable access to pages memory */
void HeapletManager::unprotect (Heaplet * page) {
#if sun && PROTECT_FREE_PAGES
    if (ProtectFree) {
        mprotect((caddr_t)page, PAGESIZE, PROT_READ | PROT_WRITE);
    }
#endif
}

/* Return TRUE if pointer is into this pool.  hkh--this code
sends the msg "contains" to the object myPagePool, which is
a HeapletSet.  Thus the contains refered is the one defined
in scavp.ixx

*/
 
BooleanVar HeapletManager::contains (void * ptr) {
    return myPagePool->contains (ptr);
}
 
INLINE void * operator new (size_t, void * p) {
    return p;
}

/* Take a page from the free page pool.  Fails if none available. */
Heaplet * HeapletManager::take () {
    Heaplet * result = myEmptyPagePool->take ();
    if (result == NULL) {
        this->moreStorage ();
        result = myEmptyPagePool->take ();
        if (result == NULL) {
            BLAST(MEM_ALLOC_ERROR);
        }
    }
    unprotect (result);
    return new (result) Heaplet ();
}

/* Release a page to the free page pool. */
void HeapletManager::release (Heaplet * page) {
        Heaplet * next;
        for (Heaplet * ovr = page->overflow(); ovr; ovr = next) {
            next = ovr->overflow ();
memset((char *) ovr,0,PAGESIZE);
            protect (ovr);
           if (RecycleOld) {
                  myEmptyPagePool->introduce (ovr);
	   }
        }
memset((char *) page,0,PAGESIZE);
        protect (page);
    if (RecycleOld) {
        myEmptyPagePool->introduce (page);
    }
}

HeapletManager::~HeapletManager () {
    /* should release pages to OS */
    delete myEmptyPagePool;
    delete myPagePool;
}

HeapletManager::HeapletManager () {
    myEmptyPagePool = HeapletSet::make (MAXPAGES);
    myPagePool = HeapletSet::make (MAXPAGES);
    this->moreStorage ();
}
/* This section deserves an explanation.  SBRK returns a pointer to the
*old* end of the programs data segment if it was able to get the requested
amount of storage.  The function of the modulo arithmetic is to throw away
misaligned memory, in this case up to 16k - 1, and then use the rest for
pages. hkh more detail--6/21/95
 
 
----^---------------^---------------^---------------^---------------^  page boundries
                         ^                                           SBRK ret (storage)
                    -----                                            remainder size
                         -----------                                 fragmentSize
                                    ^                                storage+fragmentSize
 
Endpoint.  If remainder comes back zero, then we are alligned and don't need
to call SBRK again.  so the test should run:
 
    if (remainder) {
	 int fragmentSize = (int) (PAGESIZE - remainder);
         SBRK(fragmentSize);
         storage = (char*)storage + fragmentSize;
    }
 
Note that the addition of fragmentSize to storage has been moved inside the conditional
 
 */
extern int  globalsbrkcount;
void HeapletManager::moreStorage () {
    void * storage = (void *)SBRK(ALLOCINCR);
globalsbrkcount += ALLOCINCR;
    Int32 remainder = ((Int32)storage) % PAGESIZE;
    int fragmentSize = (int) (PAGESIZE - remainder);
    if (remainder) {
      SBRK(fragmentSize);
globalsbrkcount += fragmentSize;
      storage = ((char*)storage) + fragmentSize;
    }
#if sun && PROTECT_FREE_PAGES
    if (ProtectFree) {
        mprotect((caddr_t)storage, ALLOCINCR, PROT_NONE);
    }
#endif
    myPagePool->introduceMany
        ((Heaplet*) storage,
         (Heaplet*) ((char*)storage+ALLOCINCR-PAGESIZE));
    myEmptyPagePool->introduceMany
        ((Heaplet*) storage,
         (Heaplet*) ((char*)storage+ALLOCINCR-PAGESIZE));
}

 
/*
        Class HeapletSetStepper
*/


void HeapletSetStepper::step () {
    if (myBitIndex >= 0) {
        Int32 count = mySet->highestIndex () / 32;
        while (myWordIndex <= count) {
            while (++myBitIndex < 32) {
                myWord >>= 1;
                if (myWord & 1) {
                    return;
                }
                if (!myWord) {
                    break;
                }
            }
            UInt32 word = 0;
            while (myWordIndex < count 
                   && !(word = mySet->wordAt (++myWordIndex))) ;
            if (!word) {
                myBitIndex = - 1;
                return;
            }
            myWord = word;
            myBitIndex = 0;
            if (myWord & 1) {
                return;
            }
        }
    }
}

HeapletSetStepper::HeapletSetStepper (HeapletSet * set) {
    mySet = set;
    myWordIndex = set->lowestIndex () / 32;
    if (mySet->highestIndex () >= 0) {
        myBitIndex = 0;
        myWord = mySet->wordAt (myWordIndex);
        if (!(myWord & 1)) {
            this->step ();
        }
    } else {
        myWord = 0;
        myBitIndex = - 1;
    }
}


/*
        Class HeapletSet
*/

/* Return an empty set that can store size pages */

#ifdef UNdeFined //reg perhaps for future use


 int  HeapletSet::heapletIntersect(HeapletSet * a, HeapletSet * b){
    if (a->myTally == 0) {
        return NULL;
    }
    for (Int32 search = a->myLowest / 32; search < a->myHighest; search++) {
        if (a->myBitMap[search]) {
            UInt32 aword = a->myBitMap[search];
            UInt32 bword = b->myBitMap[search];
            if(aword&bword){
                for (Int32 bit = 1, count = 0; count < 32; bit <<= 1, count++) {
                    if (aword & bit & bword) {
                        cerr << "found intesecting HeapletSets with word = " << search << " bit = " << count << "aword & bword = " <<  (aword & bword);
                        cerr << " in " << __FILE__ << " at " << __LINE__;
                        return search*32+count;
                    }
                }
            }
        }
    }
    return 0;
    
}

#endif

HeapletSet * HeapletSet::make (Int32 size) {
    return new HeapletSet (size);
}

/* Take a page from the set.  Return NULL if set is empty */
Heaplet * OR(NULL) HeapletSet::take () {
    if (myTally == 0) {
        return NULL;
    }
    for (Int32 search = myLowest / 32; search < myHighest; search++) {
        if (myBitMap[search]) {
            UInt32 word = myBitMap[search];
            for (Int32 bit = 1, count = 0; count < 32; bit <<= 1, count++) {
                if (word & bit) {
                    myBitMap[search] &= ~bit;
                    myLowest = search * 32 + count + 1;
                    myTally--;
                    return (Heaplet*) ((myLowest - 1) * PAGESIZE);
                }
            }
        }
    }
    BLAST(SanityViolation);
    return NULL;        // compiler fodder
}

/* Remove a particular page from the set */
void HeapletSet::remove (Heaplet * page) {
    Int32 index = ((Int32)page) / PAGESIZE;
    if (index > mySize) {
        BLAST(SanityViolation);
    }
    Int32 bits = myBitMap[index / 32];
    Int32 bit = 1 << (index % 32);
    if (bits & bit) {
        myBitMap[index / 32] &= ~bit;
        myTally--;
    } else {
        BLAST(SanityViolation);
    }
}

/* Add a page to the set */
void HeapletSet::introduce (Heaplet * page) {
    Int32 index = ((Int32)page) / PAGESIZE;
    if (index > mySize) {
        BLAST(SanityViolation);
    }
    if(page != (Heaplet *)Heaplet::pageOf(page)){
	     BLAST(SanityViolation);
    }
    Int32 bits = myBitMap[index / 32];
    Int32 bit = 1 << (index % 32);
    if (!(bits & bit)) {
        myTally++;
        myBitMap[index / 32] |= 1 << (index % 32);
        if (index > myHighest) {
            myHighest = index;
        }
        if (index < myLowest) {
            myLowest = index;
        }
    } else {
        BLAST(SanityViolation);
    }
}

/* Add a page to the set */
void HeapletSet::store (Heaplet * page) {
    Int32 index = ((Int32)page) / PAGESIZE;
    if (index > mySize) {
        BLAST(SanityViolation);
    }
    Int32 bits = myBitMap[index / 32];
    Int32 bit = 1 << (index % 32);
    if (!(bits & bit)) {
        myTally++;
        myBitMap[index / 32] |= 1 << (index % 32);
        if (index > myHighest) {
            myHighest = index;
        }
        if (index < myLowest) {
            myLowest = index;
        }
    }
}

/* Add a range of pages to the set */
void HeapletSet::introduceMany (Heaplet * lowPage, Heaplet * highPage) {
    // !!!! assumes pages not yet present--fix soon
    Int32 lowIndex = ((Int32)lowPage) / PAGESIZE;
    Int32 highIndex = ((Int32)highPage) / PAGESIZE;
    if (lowIndex > mySize || highIndex > mySize || lowIndex > highIndex) {
        BLAST(SanityViolation);
    }
    myTally += highIndex - lowIndex;
    if (highIndex > myHighest) {
        myHighest = highIndex;
    }
    if (lowIndex < myLowest) {
        myLowest = lowIndex;
    }
    Int32 lowWord = (lowIndex + 31) / 32;
    Int32 highWord = highIndex / 32;
    memset (myBitMap + lowWord, 255, (int) (highWord - lowWord) * 4);
    UInt32 word = ((UInt32) - 1) << lowIndex % 32;
    myBitMap[lowIndex / 32] |= word;
    word = ((UInt32) - 1) >> (32 - (highIndex + 1) % 32);
    myBitMap[highIndex / 32] |= word;
}

Int32 HeapletSet::count () {
    return myTally;
}

HeapletSetStepper * HeapletSet::stepper () {
    return new HeapletSetStepper (this);
}

HeapletSet::~HeapletSet () {
    delete myBitMap;
}

HeapletSet::HeapletSet (Int32 size) {
    mySize = size;
    myBitMap = new UInt32[size / 32];
    memset (myBitMap, 0, (int) size / 32);
    myLowest = size;
    myHighest = - 1;
    myTally = 0;
}

/*
        Class PointerReferenceSet
*/

PointerReferenceSet * PointerReferenceSet::make (Heaplet * page) {
    void * store = page->getBytes (sizeof (PointerReferenceSet));
    return new (store) PointerReferenceSet (page);
}

/* PointerReferenceSet::remember finds the first NULL reference
 * and stores the refPtr in it, if there are none it makes an overflow
 * array and puts refPtr there.
*/

// The original incarnation of this code had errors--
// The proper strategy should be to look through the entire
// chain with each search strategy before going on to the next
// See very similar kinds of problems in the ArrayRefferenceSet
// remember documentation--though this is a little simplier.

void PointerReferenceSet::remember (Heaper ** refPtr) {
    PointerReferenceSet * ptr;
    PointerReferenceSet * oldPtr;

    for (ptr = this; ptr; ptr = ptr->myNext){
        for (Int32 i = 0; i < ptr->myCount; i++) {
           if (ptr->myRefs[i] == refPtr) {
               return;
           }
        }   
    }    

// didn`t find it in the existing--.

    for (ptr = this; ptr; ptr = ptr->myNext){
        for (Int32 i = 0; i < ptr->myCount; i++) {
            if (ptr->myRefs[i] == NULL) {
                ptr->myRefs[i] = refPtr;
                return;
            }
        }    

        oldPtr = ptr;
    }    

// did not find an empty slot for it in used space, so use next avail--

   if (oldPtr->myCount < POINTER_SET_SIZE) {
        oldPtr->myRefs[oldPtr->myCount++] = refPtr;
        return;
    }
 
// all space was used up if we fall out here, so get another set.
 
 
    
    oldPtr->myNext = PointerReferenceSet::make (oldPtr->myPage);
    ptr = oldPtr->myNext;
    ptr->myRefs[ptr->myCount++] = refPtr; /* note that myCount == 0 in this new refPtr */
    return;
}                
                 

void PointerReferenceSet::forgetFromPage (Heaplet * page) {
    for (Int32 i = 0; i < myCount; i++) {
        if (Heaplet::pageOf(myRefs[i]) == page) {
            myRefs[i] = NULL;
        }
    }
    if (myNext) {
        myNext->forgetFromPage (page);
    }
}


void PointerReferenceSet::change (Heaper ** oldRefPtr, Heaper ** newRefPtr) {
    for (Int32 i = 0; i < myCount; i++) {
        if (myRefs[i] == oldRefPtr) {
            myRefs[i] = newRefPtr;
//          return;
        }
    }    
    if (myNext) {
        myNext->change (oldRefPtr, newRefPtr);
    }
}

void PointerReferenceSet::forget (Heaper ** refPtr) {
    for (Int32 i = 0; i < myCount; i++) {
        if (myRefs[i] == refPtr) {
            myRefs[i] = NULL;
//          return;
        }
    }    
    if (myNext) {
        myNext->forget (refPtr);
    }
}
// How this works.  The ref sets as built by checked* are pointers out
// to places in memory which point into this heaplet.  This code picks
// them up one at a time, and derefs once to get the value of the
// pointer which points back into this heaplet (obj).  The
// sanity blast will happen if the object pointer pointed to by
// ref does not point back into the page.  Next the code forwards
// the object off of this page, (or finds it to already be forwarded
// in which case it returns forwarded location), or it can return the same
// if it finds the object has already been forwarded and the pointer
// fixed.  rp is the "page" (which may be
// outside of the page area entirely) where the object was originally
// located.  Next line test that the new
// location of the object is not the same as the old one, and
// that the place which points at the new and old objects is not
// itself in the drain set.  (if it is in the drain set, there is
// no point in updating it since it will be lost shortly.)  The next
// section remembers this object on the new page, and the outPointers
// are not being used yet.  1/17/95
 


void PointerReferenceSet::scavengeNew (HeapletSet * drainSet) {
    for (Int32 i = 0; i < myCount; i++) {
        Heaper ** ref = myRefs[i];
        if (ref) {
            Heaper * obj = *ref;
	    Heaplet * actualPage;
            //if ( !(actualPage = isOnOneOfMyPages(Heaplet::pageOf(obj)))) {
             //   BLAST(SanityViolation);
            //}
            Heaper * newObject = Heaplet::forward (obj);
            Heaplet * rp = Heaplet::pageOf(ref);
            rp->removeOutPointer (myPage);//zzzz
            if (newObject != obj && !drainSet->contains(rp)) {
                *ref = newObject; 
                Heaplet * newObjectPage = Heaplet::pageOf(newObject);
                if (rp != newObjectPage) {
                    newObjectPage->remember (ref);
                    if (Heaplet::isScavengeable (rp)) {
                        rp->addOutPointer (newObjectPage);
                    }
                }
            }
            myRefs[i] = NULL;
        } /* refs nulled out by forget */
    }
    if (myNext) {
        myNext->scavengeNew (drainSet);
    }
}

Heaplet*  PointerReferenceSet::isOnOneOfMyPages(Heaplet * ptr){
	for(PointerReferenceSet * me = this;me;me = me->myNext){
		if (ptr  == this->myPage ){
			return ptr;
		}
	}
	return FALSE;
}


PointerReferenceSet::PointerReferenceSet (Heaplet * page) {
    myNext = NULL;
    myPage = page;
    myCount = 0;
    for (Int32 i = 0; i < POINTER_SET_SIZE; i++) {
        myRefs[i] = (Heaper**) - 1;
    }
}


/*
        Class ArrayReferenceSet
*/

ArrayReferenceSet * ArrayReferenceSet::make (Heaplet * page) {
    void * store = page->getBytes (sizeof (ArrayReferenceSet));
    return new (store) ArrayReferenceSet (page);
}

//  Have to describe the way these work
//  before the code can be fixed.  An ARS is made of parrallel
//  (and chained!) arrays.  myArrays is pointer types to memory,
//  myIndicies is (I think) int offsets from the pointers.  In the
//  examples Bill and I have hand stepped, storage utilization is rather
//  poor, with most of the pointers being the same.  In the original
//  process of remembering a new entry, the "old" test fails
//  and a new location at count + 1 is used.  Later some of these
//  may be "forgotten" by making the pointer part NULL, leaving
//  holes which should be filled in in preference to increasing
//  the size of the array (or allocating another chained set.  If
//  oldArray is not true, I think this works ok, by finding the
//  first NULL pointer or using a location on the end of the list
//  (recursively desending).
//
//  Strategy--the for loops go through the chained sets to the end
//  where myNext is NULL.  In the first case, where there is an old
//  array which is being transfered, we just transfer the pointer
//  andl leave the index (offset) alone.  If we fail to find a match,
//  or we are not working from an old array, go through the chains  
//  again, this time looking for an identical reference.  If one (or
//  both of the above fail, then put the ref into the first location
//  which has been freed by "forget," i.e., the first zero location.
//  If there are no open locations in the entire chain, then put the 
//  new reference in the first available location in an unfilled set.
//  If the last set in the chain is filled, make a new linked set and
//  stick the reference in the first location of that one.  (Whew!)

//  Later fix--if this routine is called with the third element, i.e.,
//  an entry is being moved from one heaple to another, then the origin
//  location needs to be NULLed so that the executeWeakly section will
//  skip looking at the NULLed reference, and therefore not set up a later
//  destruction of the WPA.  oldArray = NULL was added 11/30/94.
//
//  More--what gets passed in "this" is a pointer to the new remember set.
//  A remember set is a parallel list of myArray (address pointers) and
//  myIndicies (which I think are offsets.  array is the item you want to
//  remember in one of these sets, and oldArray is the pointer value this
//  code is trying to match.  To properly null out the old ref set entry while
//  transfering, we need to know where it came from.  I think Heaplet::pageOf 
//  (oldArray) and forgetWeak will do the right thing.  There is an interesting
//  note at Heaplet::forgetFromPage re the issue of bogus finalization of WPAs.
//  
//  Note--the loop through the first section is just hunting for a place where
//  the array is already refferenced in the array ref set.

void ArrayReferenceSet::remember (PtrArray * array, Int32 index,
                                  PtrArray * oldArray)
{
    ArrayReferenceSet * ptr;
    ArrayReferenceSet * oldPtr;

    if (oldArray) {
         Heaplet::pageOf ((Heaper *)oldArray)->forgetWeak ((WeakPtrArray *)oldArray, index);//zzzzz
         for (ptr = this; ptr; ptr = ptr->myNext){
             for (Int32 i = 0; i < ptr->myCount; i++) {
                  if (ptr->myArrays[i] == oldArray && ptr->myIndices[i] == index) {
                       ptr->myArrays[i] = array;
                       return;
                  }
             }
         }
    } 

    for (ptr = this; ptr; ptr = ptr->myNext){
            for (Int32 i = 0; i < ptr->myCount; i++) {

                if (ptr->myArrays[i] == array && ptr->myIndices[i] == index) {
                    return;
                }
            }

    }

// didn`t find it in the existing--.

    for (ptr = this; ptr; ptr = ptr->myNext){
            for (Int32 i = 0; i < ptr->myCount; i++) {

                if (ptr->myArrays[i] == NULL) {
                    ptr->myArrays[i] = array;
                    ptr->myIndices[i] = index;
                    return;
                }
            }
            oldPtr = ptr;
    }

    // did not find an empty slot for it in used space, so use next avail-
    if (oldPtr->myCount < ARRAY_SET_SIZE) {//note: in 12/94 this could be outside 
        //the loop as all the space should have been found previously
        oldPtr->myArrays[oldPtr->myCount] = array;
        oldPtr->myIndices[oldPtr->myCount++] = index;
        return;
    }
    // space was used up if we fall out here, so get another set.

    oldPtr->myNext = ArrayReferenceSet::make (oldPtr->myPage);
    ptr = oldPtr->myNext;
    ptr->myArrays[ptr->myCount] = array;  /* note that ptr->myCount == 0 in this new array */
    ptr->myIndices[ptr->myCount++] = index;
    return;
}


void ArrayReferenceSet::change (PtrArray * oldArray, PtrArray * newArray) {
    for (Int32 i = 0; i < myCount; i++) {
        if (myArrays[i] == oldArray) {
            myArrays[i] = newArray;
        }
    }
    if (myNext) {
        myNext->change (oldArray, newArray);
    }
}


void ArrayReferenceSet::forget (PtrArray * array, Int32 index) {
    for (Int32 i = 0; i < myCount; i++) {
        if (myArrays[i] == array && myIndices[i] == index) {
            myArrays[i] = NULL; myIndices[i] = 0;
        //  return;    // hkh found it this way 11/30/94 zzz should remove!!
        }
    }
    if (myNext) {
        myNext->forget (array, index);
    }
}


void ArrayReferenceSet::forgetFromPage (Heaplet * page) {
    for (Int32 i = 0; i < myCount; i++) {
        if (Heaplet::pageOf(myArrays[i]) == page) {
            myArrays[i] = NULL; myIndices[i] = 0;
        }
    }
    if (myNext) {
        myNext->forgetFromPage (page);
    }
}

void ArrayReferenceSet::scavengeNew (HeapletSet * drainSet) {
    for (Int32 i = 0; i < myCount; i++) {
        PtrArray * array = myArrays[i];
        if (array) {
            Int32 index = myIndices[i];
            Heaper * obj = array->unsafeFetch(index);
            //if (Heaplet::pageOf(obj) != my Page) {// ZZZ
	    Heaplet * actualPage;
            if ( !(actualPage = isOnOneOfMyPages(Heaplet::pageOf(obj)))) {
if (actualPage != (Heaplet::pageOf(obj))){
int j;
j = 0;

}
                BLAST(SanityViolation);
            }
            if (obj) {
                Heaper * nobj = Heaplet::forward (obj);
                Heaplet * rp = Heaplet::pageOf(array);
                rp->removeOutPointer (myPage);
                if (nobj != obj  && !drainSet->contains(rp)) {
                    array->unsafeStore (index, nobj);
                    Heaplet::pageOf(nobj)->rememberArray (array, index, NULL);
                    if (Heaplet::isScavengeable (rp)) {
                        rp->addOutPointer (Heaplet::pageOf(nobj));
                    }
                }
            }
            myArrays[i] = NULL; myIndices[i] = 0;
        }
    }
    if (myNext) {
        myNext->scavengeNew (drainSet);
    }
}

//  Weak pointers do not hold on to objects for GC purposes.
//  They are used in two cases, the first is where you already
//  know the referenced object is already being held on to by
//  something else and we wish to avoid the overhead of strong
//  or checked pointers.  The other case is . . . .

//  This is the third "thing which is done" to a heaplet during GC. 
//  Most ultimate objects pointed to by WPAs have already been
//  moved, or they are intended for destruction.  The code
//  picks up myWeakReferenceSet from the heaplet.  For each
//  non zero address element in each chained set, 
//  array is a pointer to a WPA object which might be forwarded.
//  nArray is the forwarded pointer if previous actions in this
//  GC cycle moved the WPA object itself.  (A WPA object has size, count, a 
//  pointer to storage *outside* the heaplet area, and a pointer
//  to a small "executor" object.  The executor object itself
//  is just a pointer to code which cleans up after a WPA object has
//  been dropped.)

//  First function of this code is to extract a pointers to the
//  WPA object which was saved by "rememberWeak" in either the
//  current cycle or the previous GC cycle.  Then (under if
//  array) the current location of the WPA object is determined either
//  directly or by finding it forwarded and extracting the 
//  address to which it was forwarded.  If a non NULL address 
//  has been found by either method, then we use the saved index found in
//  a data structure parallel to the one used to retrive
//  array (or indirectly nArray).  Using this offset, and the
//  WPA object (which references outside-heaplet storage) the
//  code retrives an address of a possibly forwarded object which is being pointed
//  to by an entry in the WPA.  If forwarded, this mem location is itself
//  pointer to the moved object, which is why the ** for opp (object
//  pointer-pointer).  The function of the code processing 
//  opp is to determine if the ultimate object pointed to
//  has been moved away from the CDS (or is not in it) or if
//  the ultimate object itself has been forwarded.  If it *has* been
//  forwarded, correct the WPA to reflect the new location
//  (unsafeStore) and remember that this is an active WPA pointer-to-an-
//  object in the 
//  WPA ref set on the page where the ultimate object resides.
//
//  In the event the ultimate object has *not* been moved,  delete it
//  from the WPA so it will cause no trouble later and make a 
//  record of that fact for later running the executor code
//  (recordDeath)  hkh 12/6/94 <-NOT VALID !!! zzz 
//
//  More--zzz clean up later.  This code is at the *wrong level* to
//  do anything with the estateRecorder.  estateRecorder should be
//  called on a defunct WPA, and this is groveling through the *entries*
//  in a WPA, not the WPA itself.  (Unless some other code stamped the
//  object as forwarded and then NULLed the forward address, I don't know
//  how you could detect conditions to call the ER.)
//
//  Finally fixed this right!  If the WPA *itself* is not forwarded, call 
//  the estate recorder.  Otherwise, reversing the order of GC (all of a 
//  class for each heaplet before going on to the next class) made it work!
//  Now, the remaining task is to get old to work right!
//
//  The last problem picked up before Xmas 94 was due to the one exception
//  re WPA items.  If they are not to be nulled out in the WPA, then they
//  must be forwarded, OR (rare event) they must have been migrated by an
//  exception condition where one was a root.  If so, opp will be in current.
//

#define ROGER
#ifdef ROGER


void ArrayReferenceSet::executeWeakly () {
        for (Int32 i = 0; i < this->myCount; i++) {
            WeakPtrArray * array = (WeakPtrArray*) this->myArrays[i];
            Int32 idx = this->myIndices[i];
            if (array) {
                WeakPtrArray * nArray;
                if (objIsForwarded(array)) {
                    nArray = (WeakPtrArray*) heaperForwardedTo(array);
                }else{

	    Heaplet * actualPage;
                    if (!(actualPage = isOnOneOfMyPages(Heaplet::pageOf(array))) ||!Heaplet::CurrentDrainSet->contains(array)) {  // not on my page or is global OR MIGRATED PREVIOUSLY (a rare but inevitable case)
                        nArray = array;
//if (actualPage != (Heaplet::pageOf(array))){
//int j;
//j = 0;
//}
                    } else {
if (actualPage != (Heaplet::pageOf(array))){
int j;
j = 0;
}
                        nArray = NULL; 
                   }
                }
if(nArray){
  if(!nArray->storageIsOK()){
cerr << "wuf";
}
}else{
cerr << "bar";
}
                if (nArray && nArray->storageIsOK()) {                // if NULL, WPA itself not forwarded
                    Heaper * thisContainedPtr = (Heaper*)nArray->unsafeFetch(idx); 
                    if(thisContainedPtr){  
                        if (objIsForwarded(thisContainedPtr)){
                            Heaper* tmp = heaperForwardedTo(thisContainedPtr);
                            nArray->unsafeStore(idx, tmp);      
                            Heaplet::pageOf(tmp) ->rememberWeak (nArray, idx, NULL); 
                        }else{ 
			    if (!Heaplet::CurrentDrainSet->contains(thisContainedPtr)){ // true is the odd case where a WP
			    // was a root (migrated first)
				    nArray->unsafeStore(idx, thisContainedPtr);  // correct pointer// zzz hack kluge not in KEITH version ?? is this correct? nov 1995
			    
               if(Heaplet::isScavengeable(thisContainedPtr)){                 
		Heaplet::pageOf(thisContainedPtr) ->rememberWeak (nArray, idx, NULL); 
}
			    } else {
				nArray->unsafeStore(idx, NULL);  // not forwarded, NULL the ptr.
			    }  
                        }
                    }
                }else{
if(nArray->storageIsOK()){
                    EstateRecorder::recordDeath (array, idx);  // NULL i.e.,WPA not forwarded   
}
                } 
            }
        }
	if (this ->myNext) {
	            this->myNext->executeWeakly ();
	}
}
#endif// ROGER

Heaplet *  ArrayReferenceSet::isOnOneOfMyPages(Heaplet * ptr){
	for(ArrayReferenceSet * me = this;me;me = me->myNext){
		if (ptr  == this->myPage ){
			return ptr;
		}
	}
	return FALSE;
}

ArrayReferenceSet::ArrayReferenceSet (Heaplet * page) {
    myNext = NULL;
    myPage = page;
    myCount = 0;
    for (Int32 i = 0; i < ARRAY_SET_SIZE; i++) {
        myArrays[i] = (PtrArray*) - 1;
        myIndices[i] = - 1;
    }
}

/*
  Class OutPointerSet
  */

OutPointerSet * OutPointerSet::make (Heaplet * page) {
    void * store = page->getBytes (sizeof (OutPointerSet));
    return new (store) OutPointerSet (page);
}

// The original incarnation of this code had errors--
// The proper strategy should be to look through the entire
// chain with each search strategy before going on to the next
// See very similar kinds of problems in the ArrayRefferenceSet
// remember documentation--though this is a little simplier.
void OutPointerSet::reference (Heaplet * page) {
if(DisableOutPointers){return;}

    OutPointerSet * ptr;
    OutPointerSet * oldPtr;
    for (ptr = this; ptr; ptr = ptr->myNext){
        for (Int32 i = 0; i < ptr->myCount; i++) {
            if (ptr->myRefPages[i] == page) {
                ptr->myRefCounts[i]++;
                return;
            }
        }
    }    

// didn`t find it in the existing--.

    for (ptr = this; ptr; ptr = ptr->myNext){
        for (Int32 i = 0; i < ptr->myCount; i++) {
            if (ptr->myRefPages[i] == NULL) {
                ptr->myRefPages[i] = page;
                ptr->myRefCounts[i] = 1;
                return;
            }
        }
        oldPtr = ptr;
    }    

// did not find an empty slot for it in used space, so use next avail--

   if (oldPtr->myCount < OUT_POINTER_SET_SIZE) {
        oldPtr->myRefPages[oldPtr->myCount] = page;
        oldPtr->myRefCounts[oldPtr->myCount++] = 1;
        return;
    }
 
// all space was used up if we fall out here, so get another set.
 
    
    oldPtr->myNext = OutPointerSet::make (oldPtr->myPage);
    ptr = oldPtr->myNext;
    ptr->myRefPages[ptr->myCount] = page; /* note that ptr->myCount == 0 in this new array */
    ptr->myRefCounts[ptr->myCount++] = 1; /* note that ptr->myCount == 0 in this new array */
    return;
}

//  NOTE!! these next two modules ref dropSet and oldSet, neither of which actually
//  exist at this point hkh 12/19/94


void OutPointerSet::unreference (Heaplet * page, HeapletSet * dropSet) {
if(DisableOutPointers){return;}
    for (Int32 i = 0; i < myCount; i++) {
        if (myRefPages[i] == page) {
            myRefCounts[i]--;
            if (myRefCounts[i] == 0) {
//              page->forgetFromPage (myPage); //zzzzz
                if (dropSet) { { BLAST (IS_THIS_USED?) };
                    dropSet->store (myRefPages[i]);
                }
                myRefPages[i] = NULL;
            }
//          return;
        }
    }
    if (myNext) {
        myNext->unreference (page, dropSet);
    }
}
/* reg zzz hack kluge ZZZZ6 */
/* Puts remaining referenced pages into set */
void OutPointerSet::dropInto (HeapletSet * oldSet, HeapletSet * dropSet, HeapletSet * exceptSet) {
if(DisableOutPointers){return;}
    for (Int32 i = 0; i < myCount; i++) {
        Heaplet * page = myRefPages[i];
        if (page) {
BLAST(IDIDNTTHINKTHISAWSIMPLEMENTEDCORRECTLY);
            page->forgetFromPage (myPage);
            if (oldSet->contains (page) && !exceptSet->contains(page)) {
                // oldSet->remove (page);
                dropSet->store (page);
            } else {
                myRefCounts[i] = 0;
                myRefPages[i] = NULL;
            }
        }
        if (myNext) {
            myNext->dropInto (oldSet, dropSet, exceptSet);
        }
    }
}

OutPointerSet::OutPointerSet (Heaplet * page) {
    myNext = NULL;
    myPage = page;
    myCount = 0;
}

/*
        Class PtrArraySet
*/

PtrArraySet * PtrArraySet::make (Heaplet * page) {
    void * store = page->getBytes (sizeof (PtrArraySet));
    return new (store) PtrArraySet (page);
}

// The original incarnation of this code had errors--
// The proper strategy should be to look through the entire
// chain with each search strategy before going on to the next
// See very similar kinds of problems in the ArrayRefferenceSet
// remember documentation--though this is a little simplier.

void PtrArraySet::registerPtrArray (PtrArray * array) {

    PtrArraySet * ptr;
    PtrArraySet * oldPtr;

    for (ptr = this; ptr; ptr = ptr->myNext){
        for (Int32 i = 0; i < ptr->myCount; i++) {
           if (ptr->myArrays[i] == array) {
               return;
           }
        }
    }

// didn`t find it in the existing--.

    for (ptr = this; ptr; ptr = ptr->myNext){ 
        for (Int32 i = 0; i < ptr->myCount; i++) {
            if (ptr->myArrays[i] == NULL) {
                ptr->myArrays[i] = array;
                return;
            }
        }
        oldPtr = ptr;
    }

// did not find an empty slot for it in used space, so use next avail--

   if (oldPtr->myCount < PTRARRAY_SET_SIZE) {
        oldPtr->myArrays[oldPtr->myCount++] = array;
        return;
    }

// all space was used up if we fall out here, so get another set.


    
    oldPtr->myNext = PtrArraySet::make (oldPtr->myPage);
    ptr = oldPtr->myNext;  
    ptr->myArrays[ptr->myCount++] = array; /* note that myCount == 0 in this new array */
    return;
}

/* reg zzz hack kluge ZZZZ1 */
void PtrArraySet::unregisterPtrArray (PtrArray * array) {
    for (Int32 i = 0; i < myCount; i++) {
        if (myArrays[i] == array) {
            myArrays[i] = NULL; 
        }
    }
    if (myNext) {
        myNext->unregisterPtrArray (array);
    }
}

/* Remove all arrays from target reference sets. */
void PtrArraySet::cleanup () {
    for (Int32 i = 0; i < myCount; i++) {
        PtrArray * array = myArrays[i];
        if (array) {
            if (!Heaplet::isScavengeable(array)) {
                BLAST(SanityViolation);
            }
//            if (Heaplet::pageOf(array) != my Page) {
if(!isOnOneOfMyPages(Heaplet::pageOf(array))){
                BLAST(SanityViolation);
            }
            PtrArray * nArray;
            ObjHead * head = ((ObjHead*)array) - 1;
            if (head->age == FORWARDER_FLAG) {
                nArray = (PtrArray*) heaperForwardedTo(array);

            } else {
                nArray = NULL;
            }
            if (nArray) {
                if (nArray->isKindOf(cat_WeakPtrArray)) {
                    Heaplet::pageOf(nArray)->registerPtrArray (nArray);
                    EstateRecorder::changeArray ((WeakPtrArray*)array,
                                                 (WeakPtrArray*)nArray);
                }
            } else {
                if (array->isKindOf(cat_WeakPtrArray)) {
                    WeakPtrArray * wpa = (WeakPtrArray*)array;
                    EstateRecorder::changeArray (wpa, NULL);
                    for (Int32 j = 0; j < array->count (); j++) {
                        Heaper * p = array->unsafeFetch (j);
                        if (Heaplet::isScavengeable (p)) {
                            Heaplet::pageOf (p)->forgetWeak (wpa, j);
                        }
                    }
                } else {
                    for (Int32 j = 0; j < array->count (); j++) {
                        Heaper * p = array->unsafeFetch (j);
                        if (Heaplet::isScavengeable (p)) {
                            Heaplet::pageOf (p)->forgetArray (array, j);
                        }
                    }
                }
            }
            myArrays[i] = NULL;
        }
    }
    if (myNext) {
        myNext->cleanup ();
    }
}

PtrArraySet::PtrArraySet (Heaplet * page) {
    myNext = NULL;
    myPage = page;
    myCount = 0;
}

Heaplet*  PtrArraySet::isOnOneOfMyPages(Heaplet * ptr){
	for(PtrArraySet * me = this;me;me = me->myNext){
		if (ptr  == this->myPage ){
			return ptr;
		}
	}
	return FALSE;
}
/*****************************checkStack()*****************
A pervasive and pernicious problem has been Heapers that point to bogus places.
The moving memory managercaused the system to crash.  After months of study a
cause was found to be Heapers that contained pointers to auto objects that
were no longer valid.  These pointers point into the stack frame, but the routine
that owned that stack frame had exited, thus the pointer could well endup pointing to
some other routines data. 

The check in checkStack, takes the address of the stack  as an argument to checkStackInit.
The argument should point to the top of the stack that is valid for the Heapers to point at.
 
checkStack uses its argument,  dubiousStackPointer and checks it against the saved pointer.
If the saved pointer is less than (> ? which way does the stack grow?  ) the dubiousStackPointer
is BAD.

checkStack(void *) should be called on each pointer in the garbage collector.   The original
intention is to call checkStackInit from within the garbageCollect with the address of this
(&this) thus obtaining the first valid address after the calling routines stack frame.
Code should not reflect this assumption, but "theres allways something"

Note that even stack objects allocated BEFORE the garbage collector can be in
error and they will be found iff the happen to be allocated at enough stack depth.

*/
/* checkStackInit takes to address of the top of the stack and saves it for checkStack */
static void * referenceStackPointer = (void *)0xffffffff;
void checkStackInit( void * currentStackPointer)
{
        referenceStackPointer = (void *) currentStackPointer;

}
void checkStack( void * dubiousStackPointer)
{
        if(referenceStackPointer <= dubiousStackPointer|| (void *)0x3ffffff < dubiousStackPointer){
                cerr << " checkStack failure, abort";
                abort();
        }
}

/* Obj Header stuff statics */

ObjHead *objHeader(Heaper * obj){
   return ((ObjHead*) obj) - 1;
}

int objAge(Heaper *obj){
    return objHeader(obj)->age;
}

Int32 objIsForwarded(Heaper * obj){
    return objAge(obj) ==  FORWARDER_FLAG;
}

Int32 objIsOld(Heaper * obj){
    return objAge(obj) == OLD_AGE;
}

Heaper* heaperForwardedTo(Heaper * obj){
   ObjHead * head = ((ObjHead*) obj) - 1;
#ifdef EXTENDED_HEADER  
        return (Heaper*)head->objHeadPtr;
#else
        return *(Heaper**)obj;
#endif
}

void assignForwardedTo(Heaper * obj, Heaper * newValue){
   ObjHead * head = ((ObjHead*) obj) - 1;
#ifdef EXTENDED_HEADER  
         head->objHeadPtr = newValue;
#else
         *(Heaper**)obj = newValue;
#endif
        return;
}

Heaper* heaperForwardedToOrHeaper(Heaper *obj){

    ObjHead * head = ((ObjHead*) obj) - 1;
    if (head->size == 0) {
        BLAST(SanityViolation); // !!!! tmp debug
    }
    Int32 age = head->age;
    if (age == FORWARDER_FLAG) {
        return heaperForwardedTo(obj);
    }
    return (obj);
}
