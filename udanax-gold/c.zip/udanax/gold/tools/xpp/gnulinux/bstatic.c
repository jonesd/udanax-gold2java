void doStaticInit () {
  __sti_____bombx_cxx_bombc_h_version_ ();
  __sti_____cbombx_cxx_bombc_h_version_ ();
}
void doStaticTerm () {
  __std_____bombx_cxx_bombc_h_version_ ();
  __std_____cbombx_cxx_bombc_h_version_ ();
}
