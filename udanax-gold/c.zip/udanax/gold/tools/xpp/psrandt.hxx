#ifndef PSRANDT_HXX
#define PSRANDT_HXX
static char psrandt_hxx_id[] = "$Id: psrandt.hxx,v 1.1.1.1 2001/07/28 21:24:54 jrush Exp $";

#include "psrandx.hxx"
#include <stream.h>

/* tests */
/* FibonacciRandomTester runTest: #test1On: */
void  test1On (ostream& oo);


#endif /* PSRANDT_HXX */
