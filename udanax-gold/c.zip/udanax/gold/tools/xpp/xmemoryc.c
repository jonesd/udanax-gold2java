static char xmemoryc_cxx_rcsid[] = "$Id: xmemoryc.c,v 1.1.1.1 2001/07/28 21:24:54 jrush Exp $";

#include "xmemoryc.h"

void copyWords (dest, src, nWords)
	UInt32 * dest;
	UInt32 * src;
	UInt32 nWords;
{
    while (nWords--) {
	*dest++ = *src++;
    }
}


void zeroWords (dest, nWords)
	UInt32 * dest;
	UInt32 nWords;
{
    while (nWords--) {
	*dest++ = 0;
    }
}
