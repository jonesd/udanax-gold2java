
#include "xcompatx.hxx"

VERSION_ID(hsboxx_hxx,
	   "$Id: hsboxx.hxx,v 1.1.1.1 2001/07/28 21:24:54 jrush Exp $")

extern UInt32 hashSBoxes[8][256];
