/* ========================================================================== */
//
//	Copyright (c) 1989 by Xanadu Operating Company, All Rights Reserved.
//
/* ========================================================================== */
//
// The information contained herein is confidential, proprietary to Xanadu
// Operating Company, and considered a trade secret as defined in section
// 499C of the penal code of the State of California.
//
// Use of this information by anyone other than authorized employees of
// Xanadu is granted only under a written nondisclosure agreement,
// expressly prescribing the scope and manner of such use.
//
// The above copyright notice is not to be construed as evidence of
// publication or the intent to publish.
//
/* ========================================================================== */
//
//				stringx.hxx
//
//	This file exists just to suck in the system string includes.
//
//		By Michael McClary		1991
//
/* ========================================================================== */
/* $Id: stringx.hxx,v 1.1.1.1 2001/07/28 21:24:54 jrush Exp $ */

#include <string.h>

